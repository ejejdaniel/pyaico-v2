# 安裝與使用（Windows／Linux）

這份壓縮檔不含 Python 虛擬環境。安裝程式會在解壓後的資料夾裡建立 `.venv`，並依 `requirements.txt`（已釘選、測試過的版本）安裝所有套件。

## 快速開始

| 步驟 | Windows | Linux |
| --- | --- | --- |
| 0. 第一次使用：裝好下方「事先安裝」的項目 | Python 3.12 | Python 3.12、ICU、瀏覽器、中文字型 |
| 1. 解壓縮 | 解壓到任一資料夾 | `unzip ai-coscientist-*.zip` |
| 2. 安裝 | 雙擊 `install.cmd`（或在終端執行） | `cd ai-coscientist && bash install.sh` |
| 3. 設定模型 | 編輯 `config\llm.opencode.json` | 編輯 `config/llm.opencode.json` |
| 4. 使用 | `co-scientist.cmd D:\studies\demo` | `bash co-scientist.sh ~/studies/demo` |

安裝程式最後會列出檢查結果：

- **OK**：可用。
- **注意**：該功能受限，其餘照常。例如沒有瀏覽器時，報告只有 HTML、沒有 PDF。
- **缺少**：必須處理；處理後重新執行安裝即可，已裝好的部分會沿用。

## 事先安裝（每台電腦一次）

`.venv` 只裝 Python 套件；下列項目要另外裝在系統上。

### Windows（10 1903 以上或 11）

1. **Python 3.12**（必要）：從 <https://www.python.org/downloads/> 安裝，勾選「Add python.exe to PATH」。安裝程式會依序找 `py -3.12`、PATH 中的 `python`、以及使用者層級的預設安裝位置。
   - 用 conda 的話：在已 `conda activate` 某個 Python 3.12 環境的終端（例如 Anaconda Prompt）中執行 `install.cmd`；或先設定 `set COSCI_PYTHON=D:\miniconda3\envs\py312\python.exe`。安裝程式只借用這個 Python 建立 `.venv`，不會改動 conda 環境。
2. **Edge 或 Chrome**（產生 PDF 報告用）：Windows 通常已內建 Edge，不必另裝。
3. **Git for Windows**（只有無人值守執行需要，見「使用」）：<https://git-scm.com/download/win>。
4. 其餘不必另裝：系統 ICU（`icu.dll`）與 PowerShell 都是 Windows 內建。
5. **解壓到較短的路徑**，例如 `C:\ai-coscientist` 或 `D:\tools\ai-coscientist`。資料夾路徑超過約 120 個字元時，`.venv` 裡的檔案會超過 Windows 的 260 字元上限，部分套件（例如 rdkit）會無法載入；安裝程式遇到這種情況會先停下並說明。

### Linux（以 Debian／Ubuntu 為例）

```bash
sudo apt update
sudo apt install python3.12 python3.12-venv   # 必要；Ubuntu 24.04 內建 3.12
sudo apt install libicu-dev                   # 必要：工具名稱排序使用系統 ICU
sudo apt install fonts-noto-cjk               # PDF 報告的中文字型
sudo apt install git                          # 只有無人值守執行需要
```

PDF 報告用的瀏覽器：

- **Debian**：`sudo apt install chromium`。
- **Ubuntu**：請裝 Google Chrome 的 .deb 版（`wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb && sudo apt install ./google-chrome-stable_current_amd64.deb`）。Ubuntu 的 `chromium` 是 snap 版，有自己獨立的 `/tmp`，讀不到報告程式暫存的 HTML。
- 只要 `chromium`、`chromium-browser`、`google-chrome` 或 `google-chrome-stable` 其中一個在 PATH 中即可。

其他說明：

- 發行版沒有 `python3.12` 時，可用 deadsnakes PPA、pyenv 或 uv 安裝 3.12，再以 `COSCI_PYTHON=/path/to/python3.12 bash install.sh` 指定。Python 3.11 也可使用，但套件版本是在 3.12 上測試的。
- RHEL／Fedora 的對應套件：`python3.12`、`libicu`、`chromium`、`google-noto-sans-cjk-fonts`、`git`。
- 終端工具使用環境變數 `SHELL` 指定的 shell，一般是 bash；若是 `/bin/sh`，執行前先 `export SHELL=/bin/bash`。
- 在 Docker 等容器內執行時，Chrome 的沙箱需要建立命名空間，容器預設的安全設定會擋下，導致產生 PDF 失敗。啟動容器時加上 `--security-opt seccomp=unconfined`；或在主機上執行。

### 共同需求

- **網路**：安裝時要能連到 PyPI（約下載數百 MB，主要是 rdkit、scipy、PyMuPDF）。公司網路若有代理或內部鏡像，先設定好 pip（例如 `pip config set global.index-url ...`）。
- **ripgrep**（檔案搜尋工具用）：第一次搜尋時會自動從 GitHub 下載，與原版 OpenCode 相同。無法連到 GitHub 的環境請先安裝：Windows 用 `winget install BurntSushi.ripgrep.MSVC`，Debian／Ubuntu 用 `sudo apt install ripgrep`。
- **語言模型服務**：一個相容 OpenAI 介面的端點，例如 vLLM。執行時要能連到它；文獻搜尋另需能連到外部網站。

## 設定模型

模型設定只有一個檔案：`config/llm.opencode.json`。通常只要改兩處：

```json
"model": "local/deepseek-v4.1-flash",
"provider": { "local": { "options": { "baseURL": "http://192.168.1.118:8000/v1", "apiKey": "{env:LOCAL_OPENAI_API_KEY}" },
              "models": { "deepseek-v4.1-flash": { ... } } } }
```

- `baseURL`：改成你的服務位址，以 `/v1` 結尾。
- 模型名稱：`model` 的斜線後面那段，要和 `models` 裡的鍵名一致，也要和服務提供的模型名稱一致。
- **金鑰**：檔案裡只寫 `{env:LOCAL_OPENAI_API_KEY}`，不要把金鑰本身寫進任何檔案。本機免金鑰的服務可不設定，啟動器會自動補佔位值 `local`。需要金鑰時，設定環境變數：
  - Windows（只對目前視窗有效）：`set LOCAL_OPENAI_API_KEY=你的金鑰`
  - Windows（永久，之後開新視窗才生效）：`setx LOCAL_OPENAI_API_KEY 你的金鑰`
  - Linux：`export LOCAL_OPENAI_API_KEY=你的金鑰`（要永久生效就寫進 `~/.bashrc`）

改完後執行檢查，確認能連到服務：

```text
Windows：.venv\Scripts\python scripts\check_install.py
Linux：  .venv/bin/python scripts/check_install.py
```

模型設定只有這一份，介面、無人值守與紀錄模式都用它。

## 調整執行參數

和機器、服務有關的參數集中在 `config/runtime.json`。改完重新啟動就生效；刪掉某一項就回到預設值；寫錯名稱或數值時，啟動會直接說明哪裡錯。要改用另一個檔案，設定環境變數 `COSCI_RUNTIME_CONFIG=/path/to/runtime.json`。

| 參數 | 預設 | 意思 | 何時要改 |
| --- | --- | --- | --- |
| `network.max_queries` | 20 | 每個任務最多幾次網路查詢（網路搜尋、文獻搜尋、私人資料庫共用；介面與無人值守執行都適用）。`null` 表示不設上限 | 想多查或少查時 |
| `model_request.timeout_s` | 600 | 等模型回覆的秒數 | 伺服器很慢時調高 |
| `model_request.connect_timeout_s` | 30 | 連上模型服務的秒數 | 網路慢時調高 |
| `model_request.max_bytes` | 262144 | 心智圖、審查等一次請求的大小上限 | 伺服器上下文比 256k 小時調低 |
| `literature_agent.timeout_s` | 300 | 私人資料庫每次查詢最多等幾秒 | 資料庫回得慢時調高 |
| `literature_agent.poll_s` | 2 | 多久問一次私人資料庫的進度 | 通常不必改 |
| `compute.simulation_s` | 120 | 模擬的預設時間上限（秒） | 機器較慢時調高 |
| `compute.simulation_max_s` | 600 | 模擬最長可設的時間（秒），不得小於上一項 | 同上 |
| `compute.calc_check_s` | 60 | 計算檢查的時間上限（秒） | 同上 |
| `compute.inference_s` | 30 | 邏輯推論的時間上限（秒） | 同上 |

科學判斷用的門檻（例如尺度偏離、係數容差）刻意寫在程式裡，不放進這個檔：每次執行都用同一套判斷，結果才能互相比較。

## 使用

- **開啟介面**：`co-scientist.cmd [資料夾]`（Linux：`bash co-scientist.sh [資料夾]`）。一般任務和研究都用這一個入口；做研究時在介面裡輸入 `/deep` 開啟深入研究（研究指引、工具、驗證計畫與檢討），或啟動時加 `--deep`。省略資料夾時用目前所在資料夾；資料夾不存在會建立。科研技能、研究工具與工作規劃直接從安裝位置載入，不會複製進資料夾，所以永遠是目前版本；只有實際存下研究紀錄時，資料夾裡才會出現 `.research/`。做研究時，把委託說明與資料檔放進這個資料夾，再在介面中交代任務。
- **無人值守執行一個案例，並完整記錄**（進階；需要 git，它會在紀錄資料夾中建立獨立的工作目錄）：

  ```text
  co-scientist.cmd --record <紀錄資料夾> --from <資料來源資料夾> --prompt <委託文字檔> --deep
  ```

  研究案例加 `--deep`；查案、問答不加。

  同一個入口、同一個代理；紀錄資料夾必須是新的。接續上一輪：`co-scientist.cmd <上一輪的紀錄資料夾> --continue --record <新的紀錄資料夾> --prompt <接續的要求>`。

  Linux 把 `.venv\Scripts\python` 換成 `.venv/bin/python`，反斜線換成斜線。

介面需要在真正的終端中執行：Windows Terminal、PowerShell、cmd 或 Linux 終端都可以。

## 疑難排解

| 現象 | 處理 |
| --- | --- |
| `Python 3.11 or newer was not found` | 安裝 Python 3.12；或設定 `COSCI_PYTHON` 為 python 的完整路徑後重跑安裝 |
| 「路徑有 N 個字元，太長」，或 rdkit 載入時出現「檔名或副檔名太長」（Windows） | 把整個資料夾移到短路徑（例如 `C:\ai-coscientist`），執行 `install.cmd --recreate` |
| Linux 建立 `.venv` 失敗 | `sudo apt install python3.12-venv`（版本號換成實際使用的版本） |
| 套件下載失敗 | 檢查網路、代理或 pip 鏡像設定後，重新執行安裝 |
| 「系統 ICU」缺少 | Linux 安裝 `libicu-dev`（RHEL：`libicu`） |
| PDF 報告用瀏覽器「注意」 | 安裝 Chrome、Chromium 或 Edge；不裝也能用，報告只有 HTML |
| PDF 中文變方塊（Linux） | `sudo apt install fonts-noto-cjk` |
| 模型端點沒有回應 | 確認服務已啟動、`baseURL` 正確、本機能連到該主機 |
| 伺服器回 401／403 | 設定 `LOCAL_OPENAI_API_KEY` |
| 想從頭重裝 | `install.cmd --recreate`（Linux：`bash install.sh --recreate`） |

要執行離線測試，打包時須加 `--with-tests`；安裝時用 `install.cmd --dev`（Linux：`bash install.sh --dev`），之後執行 `.venv\Scripts\python -m pytest tests -q`。

## 更新到新版

把新版解壓到**另一個資料夾**，再執行一次安裝；研究資料夾不必搬動。已建立的研究資料夾保留舊版技能副本，不會被自動覆寫。要升級既有研究資料夾的技能，見 README 的「升級已有工作區」。

## 給維護者：打包

在開發用的資料夾（需要 Git）執行：

```text
python scripts/package.py                        # 產生 dist/ai-coscientist-<日期>-<commit>.zip
python scripts/package.py --with-tests           # 一併附上 tests/
python scripts/package.py --write-requirements   # 套件升級並測試後，用目前的 .venv 重新產生 requirements*.txt
```

打包只收 Git 追蹤的檔案，因此不會帶到 `.venv`、`outputs`、暫存或本機設定。下列情況會拒絕打包：

- 有尚未 commit 的修改：先 commit，或加 `--allow-dirty`；
- 檔案裡出現疑似金鑰；
- 缺少安裝必需的檔案。
