# Python Common Agent 新基底

本 worktree 以專案負責人提供的 `py_opencode` 為起點，讓一般代理作為底層，科研技能建立在其上。

安裝、打包與在另一台 Windows／Linux 電腦上使用，見 [INSTALL.md](INSTALL.md)。

**目前已完成第一批共用底層修正與可選科研擴充，不是已通過三題驗收的科研系統。** Q1／Q2 的真實驗證另行記錄，LIT 已產出並由 CLI 交付 HTML／PDF，但修訂後的依賴與來源核對仍未全部通過。原始基線保存在提交 `18de453`。

## 本次決定

- 分支：`codex/py-opencode-common`。
- 舊系統的憲法與 C0-C6 不再構成本基底的約束，不為相容而移植。
- 舊 worktree 與其紀錄保留。此處沒有複製舊 Common Runtime、研究成果、虛擬環境或含憑證的本機設定。
- `baseline/import-manifest.json` 保存 74 份匯入檔案的 SHA256 與大小，其中 6 份是未納入 Git 的衍生 egg-info；其餘原始檔案已納入基線提交。評估新增的測試不屬於原始套件。
- 原始套件標示的版本為 1.18.9，不代表功能與原版 OpenCode 等價。

## 上游壓縮對齊（2026-10-19）

已依指定 OpenCode 來源的 run／訊息 API 主線修正壓縮、過大請求重播與可選工具輸出裁剪，不再回填已涵蓋的人類原文。來源、已批准格式增量、驗證與其他差異見 [對齊與稽核報告](docs/opencode_compaction_alignment_and_differences_20261019_zh-TW.md)。這不代表整套 OpenCode 或三題科研驗收等價通過。

命令權限、實際 HTTP／程序群停止與背景子代理喚醒已接續對齊，包含忙碌交接、取消競態及摘要期間晚到通知。沒有新增資料格式；依賴版本、適配限制與驗證範圍見 [執行層對齊紀錄](docs/opencode_execution_alignment_20261019_zh-TW.md)。

修正後的新 Q1 實測仍因無進展重讀停止，沒有交付；Q2、LIT 尚未啟動。工具結果傳遞的離線重播已通過，完整科研端到端仍未驗證，詳見 [新三題實測紀錄](docs/opencode_aligned_q1q2_lit_validation_20261019_zh-TW.md)。

上述是較早一輪的結果。後續 S20 版本已接續同一會話完成 Q2，但 Q1／Q2 的因果與時間線品質未全部通過，見 [原題歸因紀錄](docs/q1_source_attribution_20261019_zh-TW.md)。使用者隨後批准 S21 溫度能力；修正與離線測試見 [逐項驗證](docs/faithful_port_verification_20261019_zh-TW.md)。

S21後已另跑完整原Q1及同會話Q2：18次模型請求、653.030秒、1227346 tokens。傳輸、保存與兩問交付完成，但Q1仍有引用混用及未查明最早交接的問題；Q2核心存在性回答成立，完整因果仍未通過。LIT未啟動。詳細結果與分層檢討見 [S21後真實驗證](docs/s21_real_question_validation_20261019_zh-TW.md)。

隨後已完成S21後全新LIT原題：68次模型請求、3047.234秒、4707955 tokens，經一次真實壓縮自行交付HTML／PDF、審查及最後回覆。傳輸與保存核對一致，但正式公式／實作、近似同分排名、事後改規則與演化歷史、文獻支持及審查仍有矛盾，**完整科研品質驗收未通過**。見 [S21後LIT實測與驗收](docs/s21_lit_real_validation_20261019_zh-TW.md)。

## 三題驗收

### Q1：根據舊紀錄查原因

> 請查這次研究最後反覆重建的原因，追到最早出錯的交接；只根據紀錄，不要重跑研究。

使用原紀錄與原問句。答案須指出有根據的原因及可核對位置，區分重建請求與真正完成重建；不可啟動原研究。

### Q2：承接第一問

> 繼續查清楚：是資料原本不存在，還是已經提供但沒有交到驗收？不確定的部分請保留。

沿同一工作階段接續，分清已確認事實、推論與未知，不把前一答案本身當成證據。測試不得提供 Codex 的已知答案。

原問句位置：`../long-running-work-memory/tmp/common_conversation_comparison_20261014_v1/questions.json`。真正開跑前須核對原紀錄範圍與截止點，不改用新的示範問題。

### LIT：自主科研與交付

從 CLI 接收原 LIT 委託，動態選擇工作，完成心智圖、假說、公式、實作、計算與趨勢計分、最多三輪樣本演化、審查及最終報告，產出 HTML／PDF 並回覆使用者。

沿用原題、來源與計分要求，不預排技能順序。樣本未優於既有最佳樣本時，依既定次數限制如實報告，不以捏造結果過關。Q1／Q2 通過不代表 LIT 通過；局部成果亦不代表端到端完成。

原 LIT 執行與設定參考：`../long-running-work-memory/outputs/common_replacement_lit_cli_20261016_v1`。新的驗證只讀取所需原始委託及資料，不繼承該次研究的答案。

## 評估與施工順序

見 [基底評估](docs/adoption-review-20261016.md)。先修會破壞三題的讀取、上下文、停止與接續問題，再驗 Q1／Q2；科研能力以新基底的技能與工具擴充點逐步接入，最後驗 LIT。不可先搬入舊系統，再把它稱為新基底。

目前需求為 Python 3.11 以上；已驗的宿主是 Windows / Python 3.12。Linux 尚未實測。

工具名稱排序使用系統 ICU（提供 Unicode 與地區字串排序的函式庫），沿原版 `localeCompare` 的比較方式。Windows 使用系統 `icu.dll`，Linux 使用 `libicui18n`，macOS 使用 `libicucore`；缺少時需先安裝系統 ICU。這次只實測 Windows，其他平台的載入方式以替身驗證；不同 ICU 版本的所有字元排序尚未證明完全一致。

模型設定的 `provider.<id>.models.<model>.temperature` 是可選布林能力；`agent.<name>.temperature` 才是溫度數值。能力為 true 時保留代理數值（含 0），未指定數值則採原版預設；false 時省略溫度；省略能力且需要判定時讀取正式 `models.dev` 目錄，成功後僅保存在程序記憶體，查詢失敗會明確報錯。精確範圍見 [S21](docs/faithful_port_schema_delta_20261019_zh-TW.md#s21模型是否支援溫度控制已批准)。

相容 OpenAI 介面的思考量設定鍵為 `options.reasoningEffort`，傳輸時轉成 `reasoning_effort`；設定中的舊 `reasoning_effort` 鍵不生效。搜尋工具在提供者恰為 `opencode` 時預設顯示，其他提供者可用既有 `OPENCODE_ENABLE_EXA` 或 `OPENCODE_ENABLE_PARALLEL` 啟用，仍受權限控制；只選搜尋服務不會啟用工具。

## 離線邊界測試

安裝本套件及開發依賴後：

```text
python -m pytest tests -q --import-mode=importlib
```

測試使用模擬模型及臨時工作目錄，不證明真實 DeepSeek 的解題能力。原基線中 12 項 `expectedFailure` 已轉為必須通過的回歸測試，並補上重啟、分頁、停止與模型輸出中斷等邊界。科研擴充測試另在 `tests/science`；缺少可選 PDF 套件時，PDF 測試會明確跳過，不能算產檔已驗證。

第一批修正範圍與限制見 [實作紀錄](docs/common-foundation-repair-20261016.md)。

真實兩問已交付：Q1 找到主要交接，但重建次數表述有誤；Q2 核心分辨成立，未重跑原研究。見 [Q1／Q2 實測核對](docs/q1q2-foundation-review-20261016.md)。這不是三題全部通過。

## 可選科研能力

`researchkit` 只透過原有技能與本機工具擴充點接入。一般查案工作不安裝它，也能使用原有 Common 工具；沒有科學 TaskSpec、Graph 或發布閘門的前置要求。

在已準備的 Python 環境安裝本專案及科研依賴：

```text
python -m pip install -e ".[science]"
python scripts/setup_research_workspace.py /path/to/research-workspace
```

若要使用已核准的 `check_inference`，另安裝選配依賴 `python -m pip install -e ".[inference]"`。
它使用本機 Z3 核對明列前提與結論，保存反例／求解紀錄；不呼叫模型、不自動下載套件，也不替科研審查判定內容合格。
使用與驗證邊界見 [工具契約](docs/check_inference_contract_20261022_zh-TW.md)。

安裝器把檔案式技能放在研究目錄的 `.opencode/skills`，工具入口放在 `.opencode/tools/research.py`。重複安裝不會默默覆蓋已修改的技能。此工具入口需要上述 Python 環境能匯入 `researchkit`。

升級已有工作區時，可提供前次保存的程式雜湊清單：

```text
python scripts/setup_research_workspace.py /path/to/research-workspace --previous-manifest /path/to/previous-run/runtime-manifest.json
```

只有與前次雜湊一致、尚未被修改的科研技能副本可更新；缺少可信舊雜湊或有本地修改就拒絕。所有檢查通過後才套用。省略選項時保留原安裝行為，不能假定更新套件會自動刷新既有副本。升級後重新開啟代理，使檔案式技能從新版副本載入；測試續跑入口使用同一更新邏輯並保留原有備份。

配置工作目錄的 `opencode.json` 後，正常啟動：

```text
opencode --dir /path/to/research-workspace
```

本 worktree 的正式 TUI 只有一個入口，一般任務與研究共用，不必手動設定環境變數：

```powershell
D:\tmptmpt\ai-coscientist-hypothesis-v1\worktrees\py-opencode-common\co-scientist.cmd D:\studies\demo
```

**深入研究是開關，預設關**（2026-10-31，專案負責人決定）：
- 關的時候是一般代理：讀檔、搜尋、寫程式、執行、接續與回答，加上重複呼叫的提醒與攔截、被擋停時交出已查到的內容。查案、問答、一般修改用這個。
- 開的時候另外載入研究能力：兩份研究指引、科研技能、研究與規劃工具、研究看板，以及開工前的驗證計畫、卡住時的暫停檢討、一輪結束時的檢討。研究題（如 LIT）用這個。
- 介面裡用 `/deep` 切換（`/deep on`、`/deep off`），從下一則訊息起生效。設定記在這個任務上，接續時沿用，畫面上會顯示。`co-scientist.cmd --deep` 讓新對話預設開啟。
- 關的時候，若看起來是研究委託，代理會提醒可以開啟，但不會自己切換。
- 一般模式在介面裡有人時，每一回合最多 40 次模型呼叫：剩 10 次時提醒代理收斂，最後一次不給工具，交出階段總結（查到什麼、出處、還不確定的、建議的下一步）；說「繼續」就開新的回合。深入研究和無人值守不受此限。數字可在設定的 `turn`（`max_calls`、`remind_before`）調整。
- 兩種模式都用使用者的語言與文字回覆（使用者寫繁體就用繁體）。

同一個入口也能無人值守地執行任務，代理和互動時完全相同（`scripts/run_tui.py`、`src/opencode/deep.py`、`src/researchkit/task_runtime.py`）。

```powershell
co-scientist.cmd D:\studies\demo --prompt 委託.txt
co-scientist.cmd D:\studies\run1 --from cases\lit\sources --prompt cases\lit\original-request.txt --deep
co-scientist.cmd D:\studies\run1 --prompt 接續.txt --continue
```

- `--prompt` 可以給多次，在同一個任務裡依序送出，例如查案的 Q1 與 Q2。
- `--from` 先把來源資料夾複製進新的工作資料夾；複製進來的檔案就是任務來源，代理的檔案工具不能修改。
- `--continue` 接續這個資料夾上一個任務，作為它的下一輪。
- `--deep` 為這個任務開啟深入研究；接續的任務沿用它原本的設定。
- `--no-review` 在深入研究開啟時，仍關閉驗證計畫與檢討。
- 無人值守時不需要終端，權限自動核准，代理發問時會得知沒有人能回答；代理的檔案工具不能寫框架的紀錄，也不能寫資料夾以外的地方。

驗收與分段測試用同一個入口的紀錄模式，沒有另外的執行器：

```powershell
co-scientist.cmd --record outputs\lit-run1 --from cases\lit\sources --prompt cases\lit\original-request.txt --deep
co-scientist.cmd outputs\lit-run1 --continue --record outputs\lit-run1-r2 --prompt 接續.txt
python scripts\run_stage.py --from outputs\lit-run1 --at mindmap --until history_check --name lit-stage1
```

- `--record RUN` 把這一輪完整記錄在新資料夾：每次模型請求與回覆、實際 HTTP 往返、對話、結果、meta 區完整性核對，以及每筆階段紀錄當時的工作區快照。任務的工作區（`RUN/workspace`）與會話狀態也獨立放在裡面，不和平常的任務混在一起；代理的工具看不到紀錄本身和旁邊的其他執行。
- 新任務配 `--from`，不給工作資料夾。接續時，工作資料夾是先前的紀錄資料夾，配 `--continue`：在原地接著做，做之前先把工作區與狀態備份到新紀錄的 `baseline/`。
- `--stop-at KIND` 在存下這種紀錄的第一筆新紀錄時結束這一輪；在紀錄資料夾寫入 `stop-request.txt`（內容是理由）也會結束。兩者都照常核對完整性，深入研究開啟時也做輪末檢討。
- `scripts/run_stage.py` 先用 `fork_run.py` 把舊執行切回某個節點，再用這個入口接續（深入研究開啟）；它只是兩步合併，不是另一個執行器。

省略資料夾時開啟目前終端所在的資料夾；資料夾不存在會建立，相對路徑以目前終端目錄解析（Linux：`bash co-scientist.sh [資料夾]`）。科研技能、研究工具、工作規劃及兩份研究指引（research-practice、work-planning）屬於深入研究，開啟時從本安裝位置載入，不複製進資料夾，因此一律是目前版本；資料夾只有在存下研究紀錄時才出現 `.research/`。用舊版安裝程式準備過的研究資料夾照樣可開：它自己的工具檔沿用，技能與指引改用本安裝的版本。

入口固定使用同一 worktree 的 `.venv` 及 `config/llm.opencode.json`，互動、無人值守與紀錄模式共用同一套設定合成程式；不另存模型或溫度設定。初始模型、端點、推理與各代理溫度由這一份檔案決定，工作區的權限、技能與其他設定沿用。日後變更模型只修改這份檔案，重新啟動生效。既有 `LOCAL_OPENAI_API_KEY` 保留；未設定時只在當次程序補上本機免認證服務的 `local` 佔位值。

入口預設顯示新對話首頁。從 TUI 選取歷史會話會恢復該會話保存的模型選擇，手動模型切換及自訂命令的明確模型設定也保持原義；不改寫舊會話或猜測模型別名。原生 `opencode`／`python -m opencode` 仍維持 OpenCode 設定優先序。入口與界線見 [統一啟動契約](docs/tui_unified_launcher_contract_delta_20261023_zh-TW.md)。

輸入與輸出均須為終端；缺少 `.venv`、依賴或有效設定會明確失敗，不自動安裝或換用其他環境。新入口已從另一個含空白目錄實際啟動，完成真實模型串流、讀檔與正式回答，見 [統一入口實測紀錄](docs/tui_unified_launcher_verification_20261023_zh-TW.md)。

十一份科研技能涵蓋研究基本紀律、定題、資料製備、文獻、心智圖、假說、代理公式、實作、樣本演化、成果審查與報告。由模型依委託選用，不由 Python 排定順序。

科研附加工具的用途與界線：

| 工具 | 用途與界線 |
| --- | --- |
| `research_record` | 保存檔案內容的不可覆寫版本與明確依賴；不是科學審核，也不宣告完成。 |
| `research_list` | 列出精確版本與檔案位置，正文用原有 `read` 讀取。 |
| `research_compare` | 比較代理數值與作者明確提供的目標符合量；不猜目標轉換、不擬合公式。 |
| `paper_search` | 查 Crossref、arXiv 或 PubMed，保存實際查詢與服務原始回覆；摘要不冒稱全文。 |
| `paper_fetch` | 保存公開文件原始內容、網址與擷取文字；失敗不改成空成功。 |
| `render_report` | 將作者撰寫的 Markdown 產為 HTML，並使用本機已安裝的 Chromium／Chrome／Edge 列印同一份 HTML 為 PDF；不下載瀏覽器，120 秒列印上限、零重試。外部文獻以 `[@鍵]` 引用、`[@鍵]: 條目` 撰寫，依首次引用編為上標 [1]、[2]，列在正文後的「參考文獻」；回執列出沒有條目、沒被引用、沒有 DOI／網址，以及對不上已保存文獻紀錄的條目。內部證據引用顯示為上標 E1、E2；`[^名稱]` 註解顯示為上標字母，集中在附錄。明選的完整原文另存為 `evidence.html` 與 `evidence.pdf`，報告只留索引；可明選正式心智圖。`$…$` 公式以 MathML 呈現。回執附正文的文風機械統計，只供參考，不擋輸出。 |

`scientific-report-writer` 的正文與參考指引要求解釋機制、假說、公式與候選的物性理由，並分開內部研究證據與外部文獻。報告工具只排版作者實際寫出的內容，不補造科學論據。正式稿先產出，再以工具回傳的真實路徑建立易讀版引用；每次產檔目錄不同，不能猜固定相鄰路徑。送審時，作者須把委託中的論述與來源支持問題帶入既有 `scope`，明選需要受審的兩份正文及相應來源。

Materializer 仍用同一組讀寫、編輯及終端工具開發程式，不另設一個程式執行框架。科學套件由使用者準備，本版不內建 DFT 環境。

研究檔案保存在工作目錄；`.research` 保存成果快照、文獻及產檔回條。模型不必填雜湊。新的內容會形成新版本，舊版仍可精確讀回；這不代表已實作舊系統的自動下游重新驗收。

紀錄模式用原始題目檔與來源目錄執行一輪，另保存請求、回覆、對話、程式身分與來源雜湊，供人工驗收。它和互動時是同一個代理，不提供答案、不插入科研步驟，也不會因工具跑完就宣布科學交付合格。原本的 `run_research_cli_case.py` 與 `run_investigation_case.py` 已併入入口（2026-10-31）：研究題、查案的 Q1 與 Q2 都經由入口執行，代理、檢討者與輪末檢討和互動時相同。

入口共用 `config/llm.opencode.json`：目前 DeepSeek 基準是 `reasoning_effort=none`、輸出上限 32000；四個工作代理（build、plan、general、explore）溫度 1.0，每次請求換新的隨機種子，壓縮、標題、摘要維持溫度 0（2026-10-31 起為預設；溫度 0 時重複同一個呼叫成了模型唯一的選擇）。可用 `--llm-config <path>` 明確選擇完整模型設定片段。入口除了資料夾，只多了無人值守與紀錄需要的選項（`--prompt`、`--from`、`--continue`、`--llm-config`、`--no-review`、`--record`、`--stop-at`），不能另外指定模型、代理或會話。工作區的權限保留，模型／溫度由所選片段統一提供。直接使用 Common CLI 的原版設定優先序不變。

紀錄模式的接續以先前紀錄的 `settings.json.config` 為模型設定來源，沿既有 `continuation.json.previous_run` 連結找到原地保存的會話與工作區。未提供新設定參數時不套用新的中央預設；明確選定才在下次啟動切換。每次接續請把最新的紀錄資料夾當成工作資料夾。`wire-NNN/` 保存實際模型 HTTP 請求與原始回覆；結果的 `model_calls` 計入這些 HTTP 請求（包含傳輸重送），不能等同科研階段數。設定快照保留憑證引用而不保存明文金鑰；網址敏感部分也不寫入紀錄。範圍與手動 `/compact` 例外見 [整頓契約](docs/llm_configuration_consolidation_proposal_20261023_zh-TW.md)。

研究接續與診斷分開處理：`--continue` 會將 `--prompt` 的原文當作真正人類訊息加入既有會話，因此只能傳入實際研究要求，不能用它投遞「只查某檔」「禁止修改其他階段」等局部測試指令，再把該會話當成原研究自主執行的證據。提示組裝使用 `scripts/check_continuation_prompt.py` 的離線副本；來源發布／讀回使用 `scripts/replay_source_reference_boundary.py`。診斷副本的對話、摘要與待辦不回灌研究會話。

新的接續紀錄中，`original-request.txt` 保存資料庫內第一則真正人類委託，`current-request.txt` 保存這次實際送入的要求；兩者不互相取代，也不代表忽略後續人類改口。舊測試紀錄維持原樣。程式退出碼 0 與 `dialogue_status=completed` 只表示本輪對話返回，`scientific_delivery=not_reviewed` 仍須人工核對，不能用檔案存在、雜湊相同或模型說「完成」取代科研驗收。

2026-10-18 的範圍縮限原因、現有副本的明示恢復方式及驗收分工見 [接續範圍修正](docs/research_scope_recovery_20261018_zh-TW.md)。該副本已受局部測試指令影響；即使恢復完成，也只能稱為人工校正範圍後的接續，不是全程自主端到端通過。

本機已另準備 `.venv`，與既有 `py312` 分開。第一次 LIT 的環境與空輸出失敗見 [實測檢討](docs/lit-foundation-first-run-review-20261016.md)，不能列為通過。

原 LIT 接續修訂的結果見 [交付修復與殘留問題](docs/lit-delivery-repair-20261016.md)：實際修檔、保留數值與 CLI 路徑交付已驗到，但尚有舊計算引用未修訂，以及把局部文獻目錄查無誤認成全部來源查無的問題。這是原案接續，不是修正後全新端到端通過。

後續補上依賴路徑及共用工具回條索引後，模型已實際修正主要計算依賴鏈，但仍未回查搜尋原文，沿用錯誤的來源否定。完整結果、成本與未通過項目見 [引用鏈與搜尋回條接續檢討](docs/lit-chain-and-receipt-repair-20261016.md)。工具可查不等於模型已查證；目前不宣稱 LIT 全部驗收通過。

摘要角色、近期回合保留及工具來源呈現的後續修正見 [摘要與來源呈現修正](docs/context-evidence-repair-20261017.md)。此處分開記錄確定性邊界與原案副本的真實核對，不把提示組裝通過當成科學驗收通過。

回條已移到工作目錄內的可重建呈現，並按工具分組；可用既有成果格式封存精確來源。
105 項確定性測試通過，但原 LIT 接續仍出現把局部來源查無擴張成全部查無的錯誤，
真實的文獻成果與下游讀回尚未通過。詳見 [來源交接實作與實測](docs/source-receipt-handoff-20261017.md)。

相容 OpenAI 介面的 `options.include_stream_usage` 目前預設為 true，向支援的服務要求串流用量。原本的 `empty_output_retry_effort` 降思考量重試已在忠實移植時移除；空輸出與暫時性錯誤依原版的完成／重試規則處理。測試入口逐次保存實際 API 呼叫，包括失敗與重試。

DeepSeek 工具回合可用模型層的 `interleaved` 設定推理回送欄位（與 `options` 同層）。官方介面使用 `{"field":"reasoning_content"}`，本機已核對的 vLLM 使用 `{"field":"reasoning"}`。它將服務回傳的推理欄位保存在對話中並送回該模型，不把它當成 CLI 正文或科研證據；容量計算會包含它，壓縮的原始紀錄仍保留。未設定時，仍依相容介面的既有轉換處理推理內容。完整問題、第二輪 LIT 的停止範圍及實測限制見 [模型協定檢討](docs/lit-protocol-review-20261016.md)。
