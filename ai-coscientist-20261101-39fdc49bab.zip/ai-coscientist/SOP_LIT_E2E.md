# LIT 端到端測試 SOP（Linux）

這份說明讓你在一台 Linux 上，從解壓縮到跑完一次完整的 LIT 研究案例。
安裝細節與疑難排解見 `INSTALL.md`。

## 0. 包裡有什麼

| 內容 | 位置 |
| --- | --- |
| 程式 | `src/`、`scripts/` |
| 安裝程式 | `install.sh`、`requirements.txt`、`requirements-dev.txt` |
| 模型設定 | `config/llm.opencode.json` |
| 離線測試 | `tests/` |
| LIT 案例輸入（原樣，未修改） | `cases/lit/sources/`（3 個檔）、`cases/lit/original-request.txt`（委託原文） |

不含：虛擬環境、任何金鑰、任何執行結果。

## 1. 事先準備（每台機器一次）

```bash
sudo apt update
sudo apt install python3.12 python3.12-venv libicu-dev fonts-noto-cjk git ripgrep
```

- PDF 報告需要瀏覽器，擇一即可：Debian 用 `sudo apt install chromium`；Ubuntu 請裝 Google Chrome 的 .deb 版（Ubuntu 的 snap 版 chromium 讀不到暫存檔）。沒有瀏覽器時，報告只有 HTML。
- 網路：安裝時要連 PyPI；執行時要連模型服務，以及文獻網站（文獻搜尋用）。
- 預設 shell 不是 bash 時，先 `export SHELL=/bin/bash`。

## 2. 解壓與安裝

```bash
unzip ai-coscientist-*.zip
cd ai-coscientist
bash install.sh --dev
```

`install.sh --dev` 會在資料夾裡建立 `.venv`，裝好釘選版本的套件和 pytest，最後自動檢查。之後的指令都用 `.venv/bin/python`。

**想用你已經有的 venv**（替代做法）：

```bash
source /path/to/your/venv/bin/activate
pip install -r requirements-dev.txt
pip install --no-deps -e .
python -X utf8 scripts/check_install.py
```

之後把下列指令中的 `.venv/bin/python` 換成 `python`（venv 保持啟用）。Python 3.12 是測試過的版本。

## 3. 設定模型

只有一個設定檔：`config/llm.opencode.json`，介面與端到端測試共用。

- `baseURL`：你的模型服務位址，以 `/v1` 結尾。
- 模型名稱：`model` 斜線後面那段，要和 `models` 裡的鍵名、服務提供的模型名稱一致。
- `limit.context`：要等於服務的最大上下文長度（目前設 262144，對應 vLLM 的 `max_model_len`）。服務較小時改小，否則請求會被退回。
- **金鑰只放環境變數**，檔案裡維持 `"apiKey": "{env:LOCAL_OPENAI_API_KEY}"`：

  ```bash
  export LOCAL_OPENAI_API_KEY=你的金鑰    # 要永久生效就寫進 ~/.bashrc
  export EXA_API_KEY=你的金鑰             # 選用：網頁搜尋；不設也能跑
  ```

檢查能不能連到服務：

```bash
.venv/bin/python -X utf8 scripts/check_install.py
```

其他和機器、服務有關的參數（網路查詢上限、等待秒數、請求大小、計算時間上限）都在 `config/runtime.json`，說明見 `INSTALL.md`「調整執行參數」。預設每個任務最多 20 次網路查詢，LIT 端到端過去約用 6–13 次。

## 4. 離線測試（約 15 分鐘，不呼叫模型）

```bash
.venv/bin/python -m pytest tests -q -p no:cacheprovider
```

預期：全部通過（約 3,400 個，6 個 skipped）。這一步只驗證安裝，不代表研究品質。

## 5. 端到端：跑一次完整 LIT

```bash
RUN=outputs/lit_e2e_$(date +%Y%m%d_%H%M)
mkdir -p outputs
nohup .venv/bin/python -X utf8 scripts/run_tui.py \
  --record "$RUN" \
  --from cases/lit/sources \
  --prompt cases/lit/original-request.txt \
  --deep \
  > "$RUN.log" 2>&1 &
```

- 全程無人值守，不要中途輸入或修改程式。
- 時間約 2.5–3.5 小時，主要看模型服務的速度；服務同時有其他工作時會變慢。
- 驗收標準：一次跑完、不中斷，正常交付，報告品質好，目標 3 小時內。

**看進度**

```bash
ls "$RUN"/request-*.json | wc -l                 # 已呼叫模型幾次（完整一次約 170–280 次）
tail -n 5 "$RUN.log"                              # 最近在做什麼
grep -ho '"kind": "[a-z_]*"' "$RUN"/workspace/.research/records/*/record.json | sort | uniq -c
```

最後一行的指令列出已存的研究紀錄。正常的順序大致是：task → prepared_data → mindmap → hypothesis → proxy_formula → history_check → leaderboard → sample_evolution → report → review → final_lca → user_report。

**正常結束的樣子**

- `$RUN.log` 最後出現 `dialogue_status=completed; error=None`。
- 前面會有模型的交付摘要，列出報告位置。

**成果在哪裡**

| 成果 | 位置 |
| --- | --- |
| 報告（HTML／PDF） | `$RUN/workspace/.research/reports/<編號>/report.html`、`report.pdf` |
| 報告原稿 | 交付摘要列出的 `report.md` |
| 研究紀錄 | `$RUN/workspace/.research/records/` |
| 每次模型呼叫的完整內容 | `$RUN/request-NNN.json`、`$RUN/response-NNN.json` |

## 6. 分段重跑（選用，開發用）

從已跑過的某一步接著跑，例如從心智圖跑到歷史檢查：

```bash
.venv/bin/python -X utf8 scripts/run_stage.py --from "$RUN" --at mindmap --until history_check \
  --name lit_stage_test
```

- `--at`：從哪一種紀錄存好之後接著跑（如 `mindmap`、`history_check:2`）。
- 省略 `--until` 就跑到結束。
- 分段結果只供開發檢查；驗收必須一次完整、不中斷地跑完。

## 7. 出問題時

先看 `INSTALL.md` 的「疑難排解」。常見的：

| 現象 | 處理 |
| --- | --- |
| 模型服務沒有回應 | 確認服務已啟動、`baseURL` 正確、這台機器連得到 |
| 401／403 | 設定 `LOCAL_OPENAI_API_KEY` |
| 請求因上下文太長被退回 | 把 `limit.context` 改成服務實際的上限 |
| PDF 中文變方塊 | `sudo apt install fonts-noto-cjk` |
| 沒有 PDF、只有 HTML | 安裝 Chrome 或 Chromium |
