## Background
In the field of photolithography, it is critical to optimize the photoresist (PR) performance to establish a precise correlation between the physical-chemical properties of the resist structure and the resulting wafer pattern. To achieve optimal lithographic fidelity, the resist must exhibit balances polymer-solvent-additive interactions while undergoing controlled photochemical reactions during exposure and development.
However, subtle variations in molecular weight distribution, polymer composition, and thermal behavior often manifest as critical defects or performance degradation on the wafer. Therefore, our goal is to design a trace wafer-level performance-specifically energy of process (EOP), local critical dimension uniformity (LCDU), line breaks, and scumming defects - back to the fundamental physical and chemical characteristics of the photoresist, thereby enabling predictive design and procese control of high-yielf patterning.

## Requirements
A well-performed photoresist must meet the following requirements
-- Composition & Structure: Photoresist common contains C, H, O, N, S, I, F...etc organic element.
(1) PR is a composed of ALG/PAG/quencher
(2) ALG must contains the acrylate functional group (*-OC(=O)C=C)
(3) PAG must contains the difloromethylsulfonate group (OS(=O)(=O)C(F)(F)-*)
(4) quencher features the structure OC(=O)c1ccccc1, in which the ring can be modified with various substituents
-- Thermal stability: structure remains stable under 150°C with polymer Tg>120°C and photoresist Tg>100°C
-- Reactivity & Kinetics: delta_H target value <0, Rmax > 3000A/s and Rmin < 0.05A/s
(1) reaction mechanism: COO-R (ALG) + photon (H+) --> COOH
-- Component Diffusion & Acid-Base Rquilibrium: the PR shold be stable under PGMEA/EL=80/20 solvent.
(1) Diffusivity Control: The diffusion length of photogenerated acids (D_acid) and quenchers/bases (D_base) must be strictly confined (e.g. range can be 1/4 of pitch during PEB) to suppress blur and maintain local critical dimension uniformity (LCDU).
(2) Acid-Base Thermodynamics (pKa): The acid generator (PAG) and quencher must possess precisely matched pKa values to ensure efficient acid neutrailization in unexposed regions, thereby optimizing the chemical threshold and minimizing scumming.
(3) Hydrophobicity (ClogP): The ClogP of the components (polymer, PAG, quencher) must be tuned within a specific range to balance solubility in PGMEA/PGME casting solvents, TMAH development and control the diffusion behavior within the resist matrix.
-- Spatial Distribution & Homogeneity:
(1) Z-Direction Profile (Surface/Substrate Affinity): The components must exhibit controlled vertical segregation (Z-distribution). Optimal surface energy alignment is required to prevent excessive migration of PAG/quencher toward the air interface or the substrate, thereby eliminating T-topping or footing profiles.
(2) XY-Direction Homogeneity (Anti-Aggregation): The polymer matrix and additives must posses high molecular compatibility to prevent phase separation or local aggregation (XY-distribution).

## PR Evaluation
Environment Condition
THe photolithography patterning process begins with coating the Underelayer (UL) and Photoresist (PR) onto the wafer under atomspheric pressure, followed by a Soft Bake (SB) at 130°C to remove solvents. Next, the wafer undergoes Exposure (EXP) using an EUV scanner (13.nm) under high vaccum to preject the target pattern. All subsequent steps retuen to atomspheric pressure, starting with a Post-Exposure Bake (PEB) at 95°C to catalyze chemical reactions, and concluding with Development (DEV) using 2.38% TMAH to dissolve the exposed aree and form the final PR pattern.
Temperature: 95~130°C
Pressure: high vaccuum during exposure and atomspheric pressure during all other process steps.
Solvent: during development, 2.38% TMAH is used.

# Measurement
ALl the following KPIs are measured with CDSEM tool, derived the values from line patterns.
-- Energy of process, EOP (key factor)
(1) Measure CDs across a range of exposure doses (from a FEM wafer) using CDSEM and plot the Dose-to-CD curve and perform linear or polynomial fitting.
(2) Closer to the target, the better.
-- Local critical dimension uniformity, LCDU
(1) LCDU is defined as the atandard deviation (sigma) of these measured CDs. LCDU=7*sigma
(2) Closer to the target, the better.
-- scum & broken defects
(1) Scum: photoresist reamining in the trenches. No scum in the smaller trench CD implies a larger process window.
(2) Broken: photoresist broken on line pattern. No broken in the smaller line CD smaller implies a larger process window.
(3) the lower the better.

In conclusion, our success criteria:
-- EOP (key factor): 40MJ+-1
-- LCDU: 4.5nm+-0.2
-- P62 Broken: < 16.7
-- P37 Scum: < 16.1

Current Materials
-- (POR) Material-TV0
(1) Polymer composition: PHS/R12/C2-AA2=35/50/15-7k
(2) PDB: C13IB2=35.44 (wt%)
(3) EOP: 53.7
(4) LCDU: 4.78
(5) P62 Broken: 18.4
(6) P37 Scum: 17

-- (POR) Material-TV1
(1) Polymer composition: PS/R17/C2-AA2-35/50/15-9k
(2) PDB: C13IB2=30.23 (wt%)
(3) EOP: 48.9
(4) LCDU: 4.81
(5) P62 Broken: 17.4
(6) P37 Scum: 16.7

Where the SMILES of PHS/R12/C2-AA2 and C13IB2:
-- PHS: CC(C)C1=CC=C(O)C=C1
-- R12: *CC(*)(C)C(=O)OC1(C)CCCC1
-- R17: *CC(*)(C)C(=O)OC(C)(C)c1ccccc1
-- C2: FC1=CC(=CC(F)=C1)[S+](C1=CC=CC=C1)C1=CC(F)=CC(F)=C1
-- AA2: *CC(*)c1ccc(C(=O)Oc2c(I)cc(I)cc2C(=O)OCC(F)(F)S(=O)(=O)[O-])cc1
-- C13: FC1=CC=C(C=C1)[S+](C1=CC(F)=CC(F)=C1)C1=CC(F)=CC(F)=C1
-- IB2: O=C([O-])c1cc(I)cc(I)c1I

## Goal
You are an chemistry and material expert that help provide hypothesis to guide new PR exploration. You should deduce what chemistry properties can fulfill the desired requirements and provide a list of guidance to help scientist select promising material for PR.

## Dataset
filename: litho_historical_data.csv
success criteria:
-- EOP (key factor): 40MJ+-1
-- LCDU: 4.5nm+-0.2
-- P62 Broken: < 16.7
-- P37 Scum: < 16.1
