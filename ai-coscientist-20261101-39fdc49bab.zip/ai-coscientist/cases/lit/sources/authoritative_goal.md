# Photolithography photoresist research task

## Objective

Propose improved chemically amplified photoresist formulations.

## Required scientific outputs

All outputs below are required as separate deliverables. Evidence for one output
does not satisfy another output.

- Scientifically auditable hypotheses about how formulation or molecular
  properties may affect wafer-pattern performance.
- Interpretable, low-cost quantitative proxies that connect formulation or
  molecular properties to the final KPI or an explicitly selected auxiliary
  condition.

The work must connect formulation or molecular properties to wafer-pattern
performance while distinguishing measured observations, computed proxies,
hypotheses, and unverified outcomes.

## Research object and available inputs

Each historical record describes a polymer formulation through component labels,
component fractions, and nominal polymer molecular weight. Some component
structures are known, while others are identified only by internal labels. Known
structures may be used directly; unknown structures must remain explicit data
gaps and must not be guessed.

### Formulation notation

A source label such as `PHS/R12/C2-AA2=35/50/15-7k` describes one
formulation, not four independent measurements:

- Slash-separated component terms align positionally with the slash-separated
  composition ratios: `PHS=35`, `R12=50`, and `C2-AA2=15`. The prepared
  record normalizes these to `0.35`, `0.50`, and `0.15`.
- The trailing `7k` is the nominal polymer molecular weight, 7 kDa. It is not
  another component or composition fraction.
- `PHS` and `R12` are separate source component labels. `C2-AA2` is one
  composite source component at one shared composition fraction; `C2` and
  `AA2` are the two supplied structure fragments associated with that composite
  term. Do not count each fragment as an additional 15% component.
- The raw files use both `C2AA2` and `C2-AA2`; prepared data normalizes both to
  `C2-AA2`. The same rule applies to analogous `C<number>-AA<number>` labels.
- At the structure level, the supplied `PHS` fragment is phenolic and
  aromatic, while `R12` is an ester-bearing polymer repeat fragment.
  In the composite term, `C2` is the positively charged sulfonium fragment
  and `AA2` is the negatively charged, difluorosulfonate-bearing polymer
  fragment. This describes the supplied structures; it does not silently assign
  every formulation label to a complete ALG/PAG/quencher role map.
- The source states that the photoresist contains polymer/ALG, PAG, and quencher
  functions, but it does not provide a complete label-to-role map or every
  loading. A scientific role must be justified from the supplied structure and
  explicit task evidence, not inferred from spelling or punctuation. Missing
  role or loading information remains a visible data gap.

Known structures supplied by the source document:

- PHS: `CC(C)C1=CC=C(O)C=C1`
- R12: `*CC(*)(C)C(=O)OC1(C)CCCC1`
- R17: `*CC(*)(C)C(=O)OC(C)(C)c1ccccc1`
- C2: `FC1=CC(=CC(F)=C1)[S+](C1=CC=CC=C1)C1=CC(F)=CC(F)=C1`
- AA2: `*CC(*)c1ccc(C(=O)Oc2c(I)cc(I)cc2C(=O)OCC(F)(F)S(=O)(=O)[O-])cc1`
- C13: `FC1=CC=C(C=C1)[S+](C1=CC(F)=CC(F)=C1)C1=CC(F)=CC(F)=C1`
- IB2: `O=C([O-])c1cc(I)cc(I)c1I`

## Primary final KPI

The primary measured quantity is energy of process (EOP), obtained from CDSEM
Dose-to-CD fitting. The desired EOP is 40 mJ with a tolerance of plus or minus
1 mJ. Closeness to 40 is better; raw EOP is neither globally
higher-is-better nor lower-is-better.

For comparison on the selected historical dataset, the evaluator uses the exact deterministic
target-satisfaction quantity:

`eop_target_alignment = -abs(EOP_mJ - 40.0)`

Higher `eop_target_alignment` is better, and 0 is the optimum. The definition,
units, target, and direction are public.

## Task measurement access and use

Measurements supplied within this task, including per-record EOP, LCDU, Broken,
Scum, and derived `eop_target_alignment` values, may be read by the planner,
research skills, Materializer, Sample, reviewers, and report writers. Their use
for scoring does not make them unreadable. This permission applies only to
this task's authorized sources; explicitly restricted sources and workspace
visibility boundaries remain in force.

The formal method specifies which fields are calculation inputs, fitting data,
or comparison targets. Permission to read measurements does not authorize
silently changing the formula, tuning parameters to inflate scores, or replacing
the implementation with an answer lookup table.

Leaderboard scores describe agreement on the selected dataset, not independent
held-out validation. Unmeasured improvements in new samples remain unverified;
proxy rankings must not be reported as measured final-KPI improvements.

## Auxiliary soft conditions

All conditions below are soft objectives in this phase. They may receive their
own interpretable low-cost proxy and participate as separate sample-ranking
indices; they are not hard rejection rules.

- LCDU: target 4.5 nm with a tolerance of plus or minus 0.2 nm; closer is better.
- P62 Broken: target below 16.7; lower is better.
- P37 Scum: target below 16.1; lower is better.
- Composition: the photoresist includes an ALG, PAG, and quencher.
- ALG structure: include an acrylate functional group.
- PAG structure: include a difluoromethylsulfonate group.
- Quencher structure: use an aromatic carboxylate motif, with substituents allowed.
- Thermal behavior: remain stable at 150 degC; polymer Tg above 120 degC and
  photoresist Tg above 100 degC.
- Reaction and development: deprotection enthalpy below zero, Rmax above
  3000 A/s, and Rmin below 0.05 A/s.
- Diffusion and acid-base balance: control acid and base diffusion during PEB,
  match acid/base thermodynamics, and balance hydrophobicity for casting and
  TMAH development.
- Spatial behavior: avoid harmful vertical segregation and lateral aggregation.

## Process context

The process includes coating, soft bake at 130 degC, EUV exposure near 13 nm
under high vacuum, post-exposure bake at 95 degC, and development in 2.38%
TMAH. Other stages occur near atmospheric pressure.

## Evidence and execution boundary

Use the prepared historical input as the authoritative historical sample set.
Duplicate formulation labels are repeated experiments and must stay as separate
records. Do not invent missing structures, measurements, fitted
constants, or literature support. A low-cost proxy must be interpretable,
source-bound, executable on every historical record, and materially cheaper than
wafer measurement. Materializer implements a frozen proxy; it does not redefine
the target. Sample evolution may improve formulations under the primary and
auxiliary proxy indices but must not claim final-KPI validation.

Formal workflow completion requires a stored Final-LCA judgment whose dependency
lineage reaches the task, scientific evidence, selected method, executable proxy
materialization, and evolved sample result. A released, bounded-reject, or
hard-block judgment is a valid scientific outcome when its evidence is complete.
After that formal closure, the human-facing response must distinguish measured
evidence, computed proxy evidence, literature support, hypotheses, and unresolved
gaps.
