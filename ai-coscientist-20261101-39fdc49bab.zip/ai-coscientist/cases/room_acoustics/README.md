# 室內聲學測試案例

- 目的：檢驗科研技能在非材料、沒有歷史量測的題目上是否通用。
- 房間是測試用的虛構房間，由 Claude 依台灣鋼筋混凝土公寓常見格局繪製：角柱、沿外牆的大樑、橫越天花板的小樑。這不是實際案例，任何結果都不得稱為真實案例的驗證。
- `sources/` 是交給系統的全部輸入；本檔與 `drawing/` 不在系統可見範圍內。委託原文是 `original-request.txt`。
- 圖面由 `drawing/make_layout.py` 產生（2026-10-30），只用 Python 標準函式庫與 matplotlib。DXF 為 R12 純文字格式，中文以 `\U+XXXX` 表示；PDF 是由讀回的 DXF 繪製，兩者內容一致。重新產生：`python drawing/make_layout.py sources`（加 `--preview` 另存檢查用 PNG）。
