"""Draw the room of the room-acoustics test case: plan and section A-A, as DXF R12 and PDF.

The room is constructed for testing (see ../README.md), drawn the way a reinforced-concrete
apartment room in Taiwan usually is: a column in a corner, a main beam along the exterior wall and
a secondary beam across the ceiling. Only the standard library and matplotlib are used. The PDF is
drawn from the DXF as read back from disk, so the two cannot differ.

    python make_layout.py OUTDIR [--preview]
        writes room_layout.dxf and room_layout.pdf; --preview adds PNG pages for checking
"""

from __future__ import annotations

import math
import re
import sys
from pathlib import Path

# Room, in mm. Origin: the inner corner of the front wall and the left wall; x runs toward the
# rear wall, y toward the right wall ("left" and "right" seen from the listening position facing
# the front wall).
L, W, H = 5600, 3500, 2800              # inner length, inner width, floor to slab soffit
T_FRONT, T_SIDE, T_REAR, SLAB = 150, 150, 200, 150
DOOR_X0, DOOR_X1, DOOR_H, DOOR_T = 4400, 5300, 2100, 45     # left wall; hinge at DOOR_X1
WIN_Y0, WIN_Y1, WIN_SILL, WIN_HEAD = 850, 2650, 900, 2100     # rear wall
COL_X0, COL_Y0 = 5150, 3050                                   # column C1, rear-right corner
B1_X0, B1_SOFFIT = 5400, 2350                                 # main beam B1 along the rear wall
b1_X0, b1_X1, b1_SOFFIT = 2750, 3050, 2450                    # secondary beam b1 across the ceiling
SPEAKERS = [(500, 950), (500, 2550)]                          # acoustic centres, current placement
EAR, EAR_Z, SPK_Z = (1900, 1750), 1200, 1200
SY = -6400                              # section A-A: drawing y = SY + height
SCALE = 50                              # 1:50 on A3 landscape
SHEET = (-2800, -8200, 18200, 6650)     # A3 at 1:50, model mm
FRAME = (-2300, -7700, 17700, 6150)

LAYERS = {  # name: (AutoCAD colour index, linetype)
    "0": (7, "CONTINUOUS"), "WALL": (7, "CONTINUOUS"), "COLUMN": (7, "CONTINUOUS"),
    "HATCH": (8, "CONTINUOUS"), "DOOR": (3, "CONTINUOUS"), "WINDOW": (4, "CONTINUOUS"),
    "BEAM": (1, "DASHED"), "EQUIP": (5, "CONTINUOUS"), "DIM": (8, "CONTINUOUS"),
    "TEXT": (7, "CONTINUOUS"), "SECTION-CUT": (7, "CONTINUOUS"), "SECTION-BEYOND": (8, "CONTINUOUS"),
    "SECTION-MARK": (1, "CONTINUOUS"), "TITLE": (7, "CONTINUOUS"),
}
LTYPES = {"CONTINUOUS": ("Solid line", []), "DASHED": ("__ __ __ __", [300.0, -150.0]),
          "CENTER": ("____ _ ____ _", [600.0, -150.0, 150.0, -150.0])}


def build() -> list[dict]:
    """Every entity of the drawing, in model mm."""
    E: list[dict] = []

    def line(layer, p, q, lt=None):
        E.append({"t": "LINE", "layer": layer, "p": p, "q": q, "lt": lt})

    def rect(layer, x0, y0, x1, y1):
        E.append({"t": "POLYLINE", "layer": layer, "pts": [(x0, y0), (x1, y0), (x1, y1), (x0, y1)],
                  "closed": True})

    def arc(layer, c, r, a0, a1):
        E.append({"t": "ARC", "layer": layer, "c": c, "r": r, "a0": a0, "a1": a1})

    def circle(layer, c, r):
        E.append({"t": "CIRCLE", "layer": layer, "c": c, "r": r})

    def text(layer, p, h, s, rot=0, ha=0, va=0):
        E.append({"t": "TEXT", "layer": layer, "p": p, "h": h, "s": s, "rot": rot, "ha": ha, "va": va})

    def cross(layer, c, a=60):
        line(layer, (c[0] - a, c[1]), (c[0] + a, c[1]))
        line(layer, (c[0], c[1] - a), (c[0], c[1] + a))

    def hatch(x0, y0, x1, y1, step=100):
        c = math.floor((y0 - x1) / step) * step
        while c <= y1 - x0:
            xa, xb = max(x0, y0 - c), min(x1, y1 - c)
            if xb - xa > 1:
                line("HATCH", (xa, xa + c), (xb, xb + c))
            c += step

    def dims(points, at, vertical=False, h=110, overshoot=150):
        """A chained dimension, exploded: line, extension lines, ticks and values.

        points: [(position along the chain, reference across it or None)], in order; at: where the
        dimension line runs across the chain."""
        def pt(u, v):
            return (v, u) if vertical else (u, v)
        us = [u for u, _ in points]
        line("DIM", pt(us[0] - overshoot, at), pt(us[-1] + overshoot, at))
        for u, ref in points:
            if ref is not None:
                s = 1 if at > ref else -1
                line("DIM", pt(u, ref + s * 80), pt(u, at + s * 120))
            line("DIM", (pt(u, at)[0] - 60, pt(u, at)[1] - 60), (pt(u, at)[0] + 60, pt(u, at)[1] + 60))
        last = len(points) - 2
        for i, ((a, _), (b, _)) in enumerate(zip(points, points[1:])):
            size, middle = round(b - a), (a + b) / 2
            fits = size > len(str(size)) * 0.62 * h + 60
            if not fits and i in (0, last) and len(points) > 2:   # a short end segment: value outside
                middle = a - 230 if i == 0 else b + 230
            if vertical:
                text("DIM", (at - 40, middle), h, str(size), 90, 1, 1)
            else:
                text("DIM", (middle, at + 40), h, str(size), 0, 1, 1)

    xo0, yo0, xo1, yo1 = -T_FRONT, -T_SIDE, L + T_REAR, W + T_SIDE

    # ---------------- plan ----------------
    for p, q in [((0, 0), (0, W)), ((0, W), (COL_X0, W)),                       # inner faces
                 ((L, COL_Y0), (L, WIN_Y1)), ((L, WIN_Y0), (L, 0)),
                 ((L, 0), (DOOR_X1, 0)), ((DOOR_X0, 0), (0, 0)),
                 ((xo0, yo0), (xo0, yo1)), ((xo0, yo1), (COL_X0, yo1)),           # outer faces
                 ((xo1, COL_Y0), (xo1, WIN_Y1)), ((xo1, WIN_Y0), (xo1, yo0)),
                 ((xo1, yo0), (DOOR_X1, yo0)), ((DOOR_X0, yo0), (xo0, yo0)),
                 ((DOOR_X0, 0), (DOOR_X0, yo0)), ((DOOR_X1, 0), (DOOR_X1, yo0)),     # jambs
                 ((L, WIN_Y0), (xo1, WIN_Y0)), ((L, WIN_Y1), (xo1, WIN_Y1))]:
        line("WALL", p, q)
    rect("COLUMN", COL_X0, COL_Y0, xo1, yo1)
    hatch(COL_X0, COL_Y0, xo1, yo1)
    rect("DOOR", DOOR_X1 - DOOR_T, 0, DOOR_X1, DOOR_X1 - DOOR_X0)     # leaf, open into the room
    arc("DOOR", (DOOR_X1, 0), DOOR_X1 - DOOR_X0, 90, 180)
    mid = (WIN_Y0 + WIN_Y1) / 2
    for x in (L, xo1):
        line("WINDOW", (x, WIN_Y0), (x, WIN_Y1))
    line("WINDOW", (L + 85, WIN_Y0), (L + 85, mid + 60))
    line("WINDOW", (L + 115, mid - 60), (L + 115, WIN_Y1))
    for x in (b1_X0, b1_X1):
        line("BEAM", (x, 0), (x, W))
    line("BEAM", (B1_X0, 0), (B1_X0, COL_Y0))
    for cx, cy in SPEAKERS:
        rect("EQUIP", cx - 250, cy - 100, cx, cy + 100)
        cross("EQUIP", (cx, cy))
    circle("EQUIP", EAR, 150)
    cross("EQUIP", EAR)
    a, b = SPEAKERS
    for p, q in [(a, b), (b, EAR), (EAR, a)]:
        line("EQUIP", p, q, "CENTER")

    text("TEXT", (4950, 350), 125, "D1", 0, 1, 2)
    text("TEXT", (6020, mid), 125, "W1", 0, 1, 2)
    text("TEXT", (4950, 3270), 125, "C1", 0, 1, 2)
    text("TEXT", ((b1_X0 + b1_X1) / 2, 2250), 110, "b1（上方）", 90, 1, 2)
    text("TEXT", ((B1_X0 + L) / 2, 450), 110, "B1（上方）", 90, 1, 2)
    text("TEXT", (620, a[1] - 190), 125, "SP-L 左喇叭", 0, 0, 3)
    text("TEXT", (620, b[1] + 190), 125, "SP-R 右喇叭", 0, 0, 1)
    text("TEXT", (EAR[0] + 220, EAR[1]), 125, "LP 聆聽位置", 0, 0, 2)
    text("TEXT", (4000, 2350), 200, "混音聆聽室", 0, 1, 2)
    text("TEXT", (4000, 2050), 125, "CH 2800", 0, 1, 2)
    text("TEXT", (-1250, W / 2), 150, "前牆", 90, 1, 2)
    text("TEXT", (6950, W / 2), 150, "後牆（外牆）", 90, 1, 2)
    text("TEXT", (2800, -1500), 150, "左牆", 0, 1, 2)
    text("TEXT", (2800, 4700), 150, "右牆", 0, 1, 2)
    for x in (-1750, 7450):                                   # section marks, looking toward -y
        line("SECTION-MARK", (x - 200, W / 2), (x + 200, W / 2))
        line("SECTION-MARK", (x, W / 2), (x, W / 2 - 300))
        line("SECTION-MARK", (x, W / 2 - 300), (x - 60, W / 2 - 190))
        line("SECTION-MARK", (x, W / 2 - 300), (x + 60, W / 2 - 190))
        text("SECTION-MARK", (x, W / 2 + 90), 200, "A", 0, 1, 1)
    text("TEXT", (2825, -1950), 250, "平面圖　S=1:50", 0, 1, 2)
    line("TEXT", (1500, -2150), (4150, -2150))

    dims([(xo0, yo0), (0, yo0), (DOOR_X0, yo0), (DOOR_X1, yo0), (L, yo0), (xo1, yo0)], -700)
    dims([(0, yo0), (L, yo0)], -1100)
    dims([(xo0, yo1), (0, yo1), (b1_X0, yo1), (b1_X1, yo1), (COL_X0, yo1), (L, yo1), (xo1, yo1)], 4250)
    dims([(yo0, xo0), (0, xo0), (W, xo0), (yo1, xo0)], -700, vertical=True)
    dims([(yo0, xo1), (0, xo1), (WIN_Y0, xo1), (WIN_Y1, xo1), (COL_Y0, xo1), (W, xo1), (yo1, xo1)], 6400,
         vertical=True)
    dims([(0, None), (a[1], 250), (b[1], 250)], 200, vertical=True, overshoot=0)
    dims([(0, None), (a[0], b[1] + 100), (EAR[0], EAR[1] + 150)], 3200, overshoot=0)

    # ---------------- section A-A (cut on the room's centre line, looking toward the left wall) ----
    def z(v):
        return SY + v

    for x0, y0, x1, y1 in [(xo0, z(-SLAB), xo1, z(0)), (xo0, z(H), xo1, z(H + SLAB)),
                           (xo0, z(0), 0, z(H)), (L, z(0), xo1, z(WIN_SILL)),
                           (L, z(WIN_HEAD), xo1, z(B1_SOFFIT)),
                           (b1_X0, z(b1_SOFFIT), b1_X1, z(H)), (B1_X0, z(B1_SOFFIT), xo1, z(H))]:
        rect("SECTION-CUT", x0, y0, x1, y1)
        hatch(x0, y0, x1, y1)
    for x in (L + 85, L + 115):
        line("WINDOW", (x, z(WIN_SILL)), (x, z(WIN_HEAD)))
    rect("SECTION-BEYOND", DOOR_X0, z(0), DOOR_X1, z(DOOR_H))
    rect("SECTION-BEYOND", DOOR_X0 + 60, z(0), DOOR_X1 - 60, z(DOOR_H - 60))
    sx = a[0]
    rect("SECTION-BEYOND", sx - 250, z(SPK_Z - 200), sx, z(SPK_Z + 200))
    line("SECTION-BEYOND", (sx - 125, z(30)), (sx - 125, z(SPK_Z - 200)))
    rect("SECTION-BEYOND", sx - 250, z(0), sx, z(30))
    cross("EQUIP", (sx, z(SPK_Z)))
    circle("EQUIP", (EAR[0], z(EAR_Z)), 80)
    cross("EQUIP", (EAR[0], z(EAR_Z)))

    text("TEXT", (700, z(0) + 60), 110, "FL ±0", 0, 0, 1)
    text("TEXT", (100, z(H) - 60), 110, "樓板底 +2800", 0, 0, 3)
    text("TEXT", ((b1_X0 + b1_X1) / 2, z(b1_SOFFIT) - 60), 110, "b1", 0, 1, 3)
    text("TEXT", (B1_X0 - 80, z((B1_SOFFIT + H) / 2)), 110, "B1", 0, 2, 2)
    text("TEXT", (5950, z((WIN_SILL + WIN_HEAD) / 2)), 110, "W1", 0, 0, 2)
    text("TEXT", ((DOOR_X0 + DOOR_X1) / 2, z(DOOR_H) + 60), 110, "D1（投影）", 0, 1, 1)
    text("TEXT", (sx + 60, z(SPK_Z + 260)), 110, "SP-L（投影）", 0, 0, 1)
    text("TEXT", (EAR[0] + 140, z(EAR_Z)), 110, "LP（耳）", 0, 0, 2)
    text("TEXT", (2825, SY - 900), 250, "剖面圖 A-A　S=1:50", 0, 1, 2)
    line("TEXT", (1250, SY - 1100), (4400, SY - 1100))

    top = z(H + SLAB)
    dims([(z(-SLAB), xo0), (z(0), xo0), (z(H), xo0), (top, xo0)], -700, vertical=True)
    dims([(z(0), xo1), (z(WIN_SILL), xo1), (z(WIN_HEAD), xo1), (z(B1_SOFFIT), xo1), (z(H), xo1), (top, xo1)],
         6400, vertical=True)
    dims([(z(0), None), (z(b1_SOFFIT), b1_X1), (z(H), None)], 3300, vertical=True, overshoot=0)
    dims([(z(0), None), (z(DOOR_H), DOOR_X0)], 4250, vertical=True, overshoot=0)
    dims([(z(0), None), (z(EAR_Z), EAR[0])], 1700, vertical=True, overshoot=0)
    dims([(xo0, top), (0, top), (b1_X0, top), (b1_X1, top), (B1_X0, top), (L, top), (xo1, top)], top + 600)

    # ---------------- notes, schedule, title block and border ----------------
    notes = [
        ("附註", 200),
        ("1. 尺寸單位為 mm；高度以完成地板面為 ±0。", 140),
        ("2. 虛線為上方的樑。剖面位置及視向見平面圖 A 標記。", 140),
        ("3. SP 為喇叭聲學中心，LP 為聆聽者耳朵位置，皆為現況擺位，高度 +1200。", 140),
        ("4. 室內目前無家具、窗簾或任何處理材料。", 140),
        ("", 140),
        ("材質及構件表", 200),
        ("牆、柱：鋼筋混凝土，水泥粉光，水性乳膠漆", 140),
        ("天花板、樑：鋼筋混凝土，水泥粉光，水性乳膠漆", 140),
        ("地板：鋼筋混凝土樓板，貼瓷磚", 140),
        ("D1：實木門，寬 900 × 高 2100，厚 45，向室內開", 140),
        ("W1：鋁框橫拉窗，6 mm 單層清玻璃，寬 1800 × 高 1200，窗台高 900", 140),
        ("C1：柱 650 × 600，室內凸出 450 × 450", 140),
        ("B1：大樑，寬 400 × 深 600（含樓板），樑底 +2350，凸出後牆內面 200", 140),
        ("b1：小樑，寬 300 × 深 500（含樓板），樑底 +2450", 140),
    ]
    y = 5700
    for s, h in notes:
        if s:
            text("TEXT", (9300, y), h, s, 0, 0, 0)
        y -= h * 2.1
    x0, y0, x1, y1 = 11700, FRAME[1], FRAME[2], -5500
    rect("TITLE", x0, y0, x1, y1)
    rows = ["案名　住宅混音聆聽室室內聲學改善", "圖名　平面圖、剖面圖 A-A", "比例　1:50（A3）　單位　mm",
            "圖號　A-01　日期　2026-10-30"]
    step = (y1 - y0) / len(rows)
    for i, s in enumerate(rows):
        top_i = y1 - i * step
        if i:
            line("TITLE", (x0, top_i), (x1, top_i))
        text("TITLE", (x0 + 200, top_i - step / 2), 150, s, 0, 0, 2)
    rect("TITLE", *SHEET)
    rect("TITLE", *FRAME)
    return E


# ---------------- DXF R12 writer ----------------

def _f(v) -> str:
    v = float(v)
    return f"{v:.1f}" if v == round(v) else f"{v:.4f}".rstrip("0")


def _dxf_string(s: str) -> str:
    """R12 keeps text in a code page; characters outside it are written as \\U+XXXX."""
    return "".join(c if ord(c) < 128 else f"\\U+{ord(c):04X}" for c in s)


def write_dxf(entities: list[dict], path: Path) -> None:
    out: list[str] = []

    def tag(code, value):
        out.append(f"{code:>3}\n{value}\n")

    def point(base, p, z=True):
        tag(base, _f(p[0]))
        tag(base + 10, _f(p[1]))
        if z:
            tag(base + 20, "0.0")

    tag(0, "SECTION"); tag(2, "HEADER")
    for name, code, value in [("$ACADVER", 1, "AC1009"), ("$DWGCODEPAGE", 3, "ANSI_1252")]:
        tag(9, name); tag(code, value)
    for name, p, z in [("$INSBASE", (0, 0), True), ("$EXTMIN", SHEET[:2], True), ("$EXTMAX", SHEET[2:], True),
                       ("$LIMMIN", SHEET[:2], False), ("$LIMMAX", SHEET[2:], False)]:
        tag(9, name); point(10, p, z)
    for name, code, value in [("$LTSCALE", 40, "1.0"), ("$TEXTSTYLE", 7, "CHT"), ("$CLAYER", 8, "0"),
                              ("$LUNITS", 70, "2"), ("$LUPREC", 70, "0")]:
        tag(9, name); tag(code, value)
    tag(0, "ENDSEC")

    tag(0, "SECTION"); tag(2, "TABLES")
    cx, cy = (SHEET[0] + SHEET[2]) / 2, (SHEET[1] + SHEET[3]) / 2
    tag(0, "TABLE"); tag(2, "VPORT"); tag(70, 1)
    tag(0, "VPORT"); tag(2, "*ACTIVE"); tag(70, 0)
    for code, value in [(10, 0), (20, 0), (11, 1), (21, 1), (12, cx), (22, cy), (13, 0), (23, 0), (14, 10), (24, 10),
                        (15, 10), (25, 10), (16, 0), (26, 0), (36, 1), (17, 0), (27, 0), (37, 0),
                        (40, SHEET[3] - SHEET[1]), (41, (SHEET[2] - SHEET[0]) / (SHEET[3] - SHEET[1])), (42, 50),
                        (43, 0), (44, 0), (50, 0), (51, 0)]:
        tag(code, _f(value))
    for code, value in [(71, 0), (72, 100), (73, 1), (74, 3), (75, 0), (76, 0), (77, 0), (78, 0)]:
        tag(code, value)
    tag(0, "ENDTAB")
    tag(0, "TABLE"); tag(2, "LTYPE"); tag(70, len(LTYPES))
    for name, (description, pattern) in LTYPES.items():
        tag(0, "LTYPE"); tag(2, name); tag(70, 0); tag(3, description); tag(72, 65); tag(73, len(pattern))
        tag(40, _f(sum(abs(v) for v in pattern)))
        for v in pattern:
            tag(49, _f(v))
    tag(0, "ENDTAB")
    tag(0, "TABLE"); tag(2, "LAYER"); tag(70, len(LAYERS))
    for name, (color, linetype) in LAYERS.items():
        tag(0, "LAYER"); tag(2, name); tag(70, 0); tag(62, color); tag(6, linetype)
    tag(0, "ENDTAB")
    tag(0, "TABLE"); tag(2, "STYLE"); tag(70, 2)
    for name, width, bigfont in [("STANDARD", "1.0", ""), ("CHT", "0.8", "chineset.shx")]:
        tag(0, "STYLE"); tag(2, name); tag(70, 0); tag(40, "0.0"); tag(41, width); tag(50, "0.0"); tag(71, 0)
        tag(42, "2.5"); tag(3, "txt"); tag(4, bigfont)
    tag(0, "ENDTAB")
    tag(0, "ENDSEC")
    tag(0, "SECTION"); tag(2, "BLOCKS"); tag(0, "ENDSEC")

    tag(0, "SECTION"); tag(2, "ENTITIES")
    for e in entities:
        kind, layer = e["t"], e["layer"]
        tag(0, kind); tag(8, layer)
        if kind == "LINE":
            if e["lt"]:
                tag(6, e["lt"])
            point(10, e["p"]); point(11, e["q"])
        elif kind == "ARC":
            point(10, e["c"]); tag(40, _f(e["r"])); tag(50, _f(e["a0"])); tag(51, _f(e["a1"]))
        elif kind == "CIRCLE":
            point(10, e["c"]); tag(40, _f(e["r"]))
        elif kind == "TEXT":
            point(10, e["p"]); tag(40, _f(e["h"])); tag(1, _dxf_string(e["s"]))
            if e["rot"]:
                tag(50, _f(e["rot"]))
            tag(7, "CHT")
            if e["ha"]:
                tag(72, e["ha"])
            if e["ha"] or e["va"]:
                point(11, e["p"])
            if e["va"]:
                tag(73, e["va"])
        elif kind == "POLYLINE":
            tag(66, 1); point(10, (0, 0)); tag(70, 1 if e["closed"] else 0)
            for p in e["pts"]:
                tag(0, "VERTEX"); tag(8, layer); point(10, p)
            tag(0, "SEQEND"); tag(8, layer)
    tag(0, "ENDSEC")
    tag(0, "EOF")
    path.write_text("".join(out), encoding="ascii", newline="\n")


# ---------------- DXF R12 reader (only what this drawing uses) ----------------

def read_dxf(path: Path) -> dict:
    lines = path.read_text(encoding="ascii").split("\n")
    tags = [(int(lines[i].strip()), lines[i + 1].rstrip("\r")) for i in range(0, len(lines) - 1, 2)]
    groups, current = [], None
    for code, value in tags:
        if code == 0:
            current = [value, []]
            groups.append(current)
        elif current is not None:
            current[1].append((code, value))
    layers, ltypes, entities, section, poly = {}, {}, [], None, None
    for kind, data in groups:
        first = dict(data)
        if kind == "SECTION":
            section = first.get(2)
            continue
        if section == "TABLES" and kind == "LAYER":
            layers[first[2]] = {"color": int(first[62]), "ltype": first[6]}
        elif section == "TABLES" and kind == "LTYPE":
            ltypes[first[2]] = [float(v) for c, v in data if c == 49]
        elif section == "ENTITIES":
            if kind == "VERTEX" and poly is not None:
                poly["pts"].append((float(first[10]), float(first[20])))
            elif kind == "SEQEND":
                poly = None
            elif kind in ("LINE", "ARC", "CIRCLE", "TEXT", "POLYLINE"):
                e = {"t": kind, "layer": first[8], "lt": first.get(6)}
                if kind == "LINE":
                    e.update(p=(float(first[10]), float(first[20])), q=(float(first[11]), float(first[21])))
                elif kind in ("ARC", "CIRCLE"):
                    e.update(c=(float(first[10]), float(first[20])), r=float(first[40]))
                    if kind == "ARC":
                        e.update(a0=float(first[50]), a1=float(first[51]))
                elif kind == "TEXT":
                    s = re.sub(r"\\U\+([0-9A-Fa-f]{4})", lambda m: chr(int(m.group(1), 16)), first[1])
                    ha, va = int(first.get(72, 0)), int(first.get(73, 0))
                    p = (float(first[11]), float(first[21])) if (ha or va) else (float(first[10]), float(first[20]))
                    e.update(p=p, h=float(first[40]), s=s, rot=float(first.get(50, 0)), ha=ha, va=va)
                else:
                    e.update(pts=[], closed=int(first.get(70, 0)) & 1 == 1)
                    poly = e
                entities.append(e)
    return {"layers": layers, "ltypes": ltypes, "entities": entities}


# ---------------- PDF / PNG from the DXF as read back ----------------

COLORS = {1: "#b0001e", 2: "#9a7b00", 3: "#00703c", 4: "#007c89", 5: "#1f4fbf", 6: "#a0008c", 7: "#000000",
          8: "#7a7a7a"}
WEIGHTS = {"WALL": 0.5, "COLUMN": 0.5, "SECTION-CUT": 0.5, "HATCH": 0.13, "DOOR": 0.25, "WINDOW": 0.3,
           "BEAM": 0.35, "EQUIP": 0.3, "DIM": 0.15, "TEXT": 0.25, "SECTION-BEYOND": 0.2, "SECTION-MARK": 0.6,
           "TITLE": 0.35}
FONTS = ["C:/Windows/Fonts/msjh.ttc", "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
         "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc", "/System/Library/Fonts/PingFang.ttc"]


def render(drawing: dict, outdir: Path, preview: bool = False) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import patches
    from matplotlib.font_manager import FontProperties
    from matplotlib.transforms import Bbox

    plt.rcParams["lines.scale_dashes"] = False
    font = next((FontProperties(fname=f) for f in FONTS if Path(f).exists()), FontProperties())
    pt = 72 / 25.4                                   # points per paper mm
    fig = plt.figure(figsize=(420 / 25.4, 297 / 25.4))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(SHEET[0], SHEET[2])
    ax.set_ylim(SHEET[1], SHEET[3])
    ax.set_aspect("equal")
    ax.axis("off")
    for e in drawing["entities"]:
        layer = drawing["layers"].get(e["layer"], {"color": 7, "ltype": "CONTINUOUS"})
        color = COLORS.get(layer["color"], "#000000")
        lw = WEIGHTS.get(e["layer"], 0.25) * pt
        pattern = drawing["ltypes"].get(e.get("lt") or layer["ltype"], [])
        style = (0, [max(abs(v) / SCALE * pt, 0.5) for v in pattern]) if pattern else "-"
        if e["t"] == "LINE":
            ax.plot([e["p"][0], e["q"][0]], [e["p"][1], e["q"][1]], color=color, lw=lw, linestyle=style,
                    solid_capstyle="butt")
        elif e["t"] == "POLYLINE":
            pts = e["pts"] + (e["pts"][:1] if e["closed"] else [])
            ax.plot([p[0] for p in pts], [p[1] for p in pts], color=color, lw=lw, linestyle=style)
        elif e["t"] == "ARC":
            ax.add_patch(patches.Arc(e["c"], 2 * e["r"], 2 * e["r"], theta1=e["a0"], theta2=e["a1"], color=color,
                                     lw=lw))
        elif e["t"] == "CIRCLE":
            ax.add_patch(patches.Circle(e["c"], e["r"], fill=False, color=color, lw=lw))
        elif e["t"] == "TEXT":
            ax.text(e["p"][0], e["p"][1], e["s"], fontproperties=font, fontsize=e["h"] / SCALE * pt / 0.8,
                    rotation=e["rot"], rotation_mode="anchor", color=color,
                    ha={0: "left", 1: "center", 2: "right"}[e["ha"]],
                    va={0: "baseline", 1: "bottom", 2: "center", 3: "top"}[e["va"]])
    fig.savefig(outdir / "room_layout.pdf")
    if not preview:
        plt.close(fig)
        return
    fig.savefig(outdir / "room_layout.png", dpi=150)

    def inches(x, y):
        return (x - SHEET[0]) / SCALE / 25.4, (y - SHEET[1]) / SCALE / 25.4
    for name, (x0, y0, x1, y1) in {"plan": (-2300, -2300, 8200, 4950), "section": (-2300, -7500, 8200, -2500),
                                   "notes": (9000, -7700, 17700, 6150)}.items():
        fig.savefig(outdir / f"check_{name}.png", dpi=300, bbox_inches=Bbox([inches(x0, y0), inches(x1, y1)]))
    plt.close(fig)


def main(outdir: str, preview: bool) -> None:
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    write_dxf(build(), out / "room_layout.dxf")
    render(read_dxf(out / "room_layout.dxf"), out, preview)


if __name__ == "__main__":
    main(sys.argv[1], "--preview" in sys.argv[2:])
