# Room acoustics design task

## Objective

Propose acoustic treatment, and loudspeaker and listener placement, for the room
drawn in `room_layout.dxf` and described in `room_brief.md`, a two-channel mixing
and critical listening room.

## Required scientific outputs

All outputs below are required as separate deliverables. Evidence for one output
does not satisfy another output.

- Scientifically auditable hypotheses about how treatment, materials, their
  placement, and loudspeaker and listener placement may affect the sound field
  at the listening position.
- Interpretable, low-cost quantitative proxies that connect design choices to
  the final KPI or an explicitly selected auxiliary condition.

The work must connect design choices to acoustic performance while
distinguishing computed predictions, literature values, hypotheses, and
unverified outcomes.

## Research object and available inputs

- `room_layout.dxf` is the authoritative drawing of the room, a plan and a
  section: walls, column, beams, door, window, finishes, dimensions, and the
  current loudspeaker and listener positions. `room_layout.pdf` is a print of
  the same drawing; where they differ, the DXF governs. A dimension or property
  the drawing does not give is not supplied.
- `room_brief.md` describes the use, the playback system, and the construction
  limits.
- The drawing and the brief are design inputs, not measurements. No measurement
  of this room, or of any treatment in it, exists. There are no historical
  designs.
- The current untreated room, with the current loudspeaker and listener
  positions shown in the drawing, is the baseline design.
- Acoustic properties of the existing surfaces and of any proposed material or
  device, for example absorption coefficients by frequency band, are not
  supplied. They must come from cited sources (standards, manufacturer data,
  textbooks, or peer-reviewed literature) with the source named. A property
  that cannot be sourced remains an explicit data gap and must not be guessed.

## Primary final KPI

The primary measured quantity is the reverberation time T20 in the octave bands
250, 500, 1000, 2000 and 4000 Hz, as it would be measured after construction at
the listening position with each loudspeaker position as a source (ISO 3382-2).
The desired value is 0.25 s with a tolerance of plus or minus 0.05 s in every
one of these bands. Closeness to 0.25 s is better; raw reverberation time is
neither globally higher-is-better nor lower-is-better.

For comparison between designs, the evaluator uses the exact deterministic
target-satisfaction quantity:

`rt_target_alignment = -max over the five bands of abs(T20_band_s - 0.25)`

Higher `rt_target_alignment` is better, and 0 is the optimum. A design is within
tolerance when `rt_target_alignment >= -0.05`. The definition, units, target,
and direction are public.

## Measurements

This task supplies no measurements. Every value of the final KPI and of the
auxiliary conditions in this work is a computed prediction and must be reported
as one. Comparisons between designs are comparisons of predictions under the
same proxies, not measured improvements.

## Auxiliary soft conditions

All conditions below are soft objectives in this phase. They may receive their
own interpretable low-cost proxy and participate as separate design-ranking
indices; they are not hard rejection rules.

- Low-frequency decay: T20 in the 63 Hz and 125 Hz octave bands at the
  listening position at most 0.40 s; shorter is better.
- Low-frequency response: with both loudspeakers playing the same signal, the
  steady-state sound pressure level at the listening position from 40 to 200 Hz,
  smoothed to 1/6 octave, varies by at most 10 dB from its highest peak to its
  deepest dip; a smaller variation is better.
- Early reflections: for each loudspeaker, every reflection reaching the
  listening position within 15 ms after the direct sound is at least 10 dB below
  the direct sound across 1 to 8 kHz; a larger margin is better.
- Flutter echo: no flutter echo between parallel hard surfaces at the listening
  position.

## Hard constraints

The construction limits, the playback conditions, and the placement limits in
`room_brief.md` are hard constraints. A design that violates any of them is not
a valid design and is not ranked.

## Evidence and execution boundary

Use `room_layout.dxf` and `room_brief.md` as the authoritative description of
the room. Do not invent
measurements, material properties, fitted constants, or literature support. A
low-cost proxy must be interpretable, source-bound, executable on every design
including the baseline, and materially cheaper than building and measuring the
treatment. Proxy scores and design rankings must not be reported as measured
improvements. Sample evolution may improve designs under the primary and
auxiliary proxy indices but must not claim final-KPI validation.

Formal workflow completion requires a stored Final-LCA judgment whose dependency
lineage reaches the task, scientific evidence, selected method, executable proxy
materialization, and evolved sample result. A released, bounded-reject, or
hard-block judgment is a valid scientific outcome when its evidence is complete.
After that formal closure, the human-facing response must distinguish computed
predictions, literature values, hypotheses, and unresolved gaps.
