@echo off
rem Open Co-Scientist in a folder. Usage: co-scientist.cmd [folder]  (default: the current folder)
setlocal
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo Run install.cmd first: "%~dp0.venv\Scripts\python.exe" is missing. 1>&2
    exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -X utf8 "%~dp0scripts\run_tui.py" %*
exit /b %errorlevel%
