#!/usr/bin/env bash
# Open Co-Scientist in a folder. Usage: bash co-scientist.sh [folder]  (default: the current folder)
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ ! -x "$DIR/.venv/bin/python" ]; then
    echo "Run 'bash install.sh' first: $DIR/.venv/bin/python is missing." >&2
    exit 1
fi
exec "$DIR/.venv/bin/python" -X utf8 "$DIR/scripts/run_tui.py" "$@"
