@echo off
rem Install into .venv next to this file. Usage: install.cmd [--dev] [--recreate]
rem Set COSCI_PYTHON=C:\path\to\python.exe to choose the Python explicitly.
setlocal
cd /d "%~dp0"
if defined COSCI_PYTHON (
    set PYCMD="%COSCI_PYTHON%"
    goto run
)
for %%V in (3.12 3.11 3.13) do (
    py -%%V -c "import sys" >nul 2>&1 && (set "PYCMD=py -%%V" & goto run)
)
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1 && (set "PYCMD=python" & goto run)
for %%V in (312 311 313) do (
    if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
        set PYCMD="%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        goto run
    )
)
echo Python 3.11 or newer was not found.
echo Install Python 3.12 from https://www.python.org/downloads/ (tick "Add python.exe to PATH"),
echo then run install.cmd again. With conda, run it from a prompt where a Python 3.12
echo environment is active, or set COSCI_PYTHON=C:\path\to\python.exe. See INSTALL.md.
set CODE=1
goto end
:run
%PYCMD% -X utf8 scripts\bootstrap.py %*
set CODE=%errorlevel%
:end
rem Keep the window open when the file was double-clicked.
echo %cmdcmdline% | findstr /i /c:"%~nx0" >nul && pause
exit /b %CODE%
