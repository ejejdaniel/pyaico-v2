#!/usr/bin/env bash
# Install into ./.venv next to this file. Usage: bash install.sh [--dev] [--recreate]
# Set COSCI_PYTHON=/path/to/python3.12 to choose the Python explicitly.
set -e
cd "$(dirname "$0")"
PY="${COSCI_PYTHON:-}"
if [ -z "$PY" ]; then
    for candidate in python3.12 python3.11 python3.13 python3; do
        if command -v "$candidate" >/dev/null 2>&1 &&
            "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' 2>/dev/null; then
            PY="$candidate"
            break
        fi
    done
fi
if [ -z "$PY" ]; then
    echo "Python 3.11 or newer was not found. Install Python 3.12 (see INSTALL.md)," >&2
    echo "or set COSCI_PYTHON=/path/to/python3.12 and run bash install.sh again." >&2
    exit 1
fi
exec "$PY" -X utf8 scripts/bootstrap.py "$@"
