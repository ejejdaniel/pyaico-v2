"""Create .venv in this folder, install the project into it, and check the result.

install.cmd (Windows) and install.sh (Linux) find a Python 3.11+ and run this file
with it. Only the standard library is used here; everything else goes into .venv.

    python scripts/bootstrap.py            # install or update
    python scripts/bootstrap.py --dev      # also pytest, for the offline tests
    python scripts/bootstrap.py --recreate # delete .venv first
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parents[1]
VENV = ROOT / ".venv"
MINIMUM, TESTED = (3, 11), (3, 12)
LONGEST_PATH = 120  # longest folder path that leaves room for the deepest file in .venv under 260


def venv_python() -> Path:
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def run(command: list) -> None:
    print("  > " + " ".join(str(part) for part in command), flush=True)
    subprocess.run([str(part) for part in command], check=True, cwd=ROOT)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="建立 .venv 並安裝本專案")
    parser.add_argument("--dev", action="store_true", help="一併安裝 pytest（執行離線測試用）")
    parser.add_argument("--recreate", action="store_true", help="先刪除既有的 .venv 再重建")
    parser.add_argument("--ignore-path-length", action="store_true",
                        help="Windows 已啟用長路徑時，略過資料夾路徑長度檢查")
    args = parser.parse_args(argv)
    sys.stdout.reconfigure(line_buffering=True)  # keep our lines in order with pip's output

    version = sys.version_info[:2]
    print(f"使用 Python {sys.version.split()[0]}：{sys.executable}")
    # Files inside .venv reach 130 characters below this folder; Windows limits a path to 260.
    if os.name == "nt" and not args.ignore_path_length and len(str(ROOT)) > LONGEST_PATH:
        print(f"這個資料夾的路徑有 {len(str(ROOT))} 個字元，太長：Windows 的路徑上限會讓部分套件（例如 rdkit）"
              f"無法載入。請把資料夾移到較短的位置（例如 C:\\ai-coscientist）再安裝。")
        return 1
    if os.name == "nt" and len(str(ROOT)) > LONGEST_PATH - 30:
        print(f"提醒：資料夾路徑有 {len(str(ROOT))} 個字元，接近 Windows 的路徑上限；建議放在較短的位置。")
    if version < MINIMUM:
        print(f"需要 Python {MINIMUM[0]}.{MINIMUM[1]} 以上；請先安裝 Python 3.12（見 INSTALL.md）。")
        return 1
    if version != TESTED:
        print(f"提醒：套件版本是在 Python {TESTED[0]}.{TESTED[1]} 上測試的；若安裝失敗，請改用 3.12。")

    if args.recreate and VENV.exists():
        print("刪除既有的 .venv")
        shutil.rmtree(VENV)
    if venv_python().exists():
        print("[1/3] 使用既有的 .venv")
    else:
        print("[1/3] 建立虛擬環境 .venv")
        try:
            venv.EnvBuilder(with_pip=True).create(VENV)
        except Exception as error:  # Debian/Ubuntu ship venv and ensurepip separately
            print(f"建立 .venv 失敗：{error}")
            if os.name != "nt":
                print(f"Debian／Ubuntu 請先安裝：sudo apt install python{version[0]}.{version[1]}-venv")
            shutil.rmtree(VENV, ignore_errors=True)
            return 1

    python = venv_python()
    requirements = "requirements-dev.txt" if args.dev else "requirements.txt"
    print(f"[2/3] 安裝套件（{requirements}；第一次需連網，約數分鐘）")
    try:
        run([python, "-m", "pip", "install", "--disable-pip-version-check", "-r", ROOT / requirements])
        run([python, "-m", "pip", "install", "--disable-pip-version-check", "--no-deps", "-e", ROOT])
    except subprocess.CalledProcessError:
        print("套件安裝失敗。請確認能連到 PyPI（或已設定 pip 的代理／內部鏡像），訊息見上方；"
              "修正後重新執行安裝即可，已安裝的部分會沿用。")
        return 1

    print("[3/3] 檢查安裝結果")
    return subprocess.run([str(python), "-X", "utf8", str(ROOT / "scripts" / "check_install.py")], cwd=ROOT).returncode


if __name__ == "__main__":
    raise SystemExit(main())
