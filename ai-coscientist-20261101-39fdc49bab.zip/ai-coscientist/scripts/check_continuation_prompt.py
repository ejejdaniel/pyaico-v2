"""Check saved requests and checkpoint-aware loop prompts in an offline session copy."""

from __future__ import annotations

import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
from unittest.mock import patch

from recording import hashes, save
from setup_research_workspace import install, upgrade_test_guidance


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--previous-trace", type=Path, required=True)
    parser.add_argument("--prompt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run, output = args.run.resolve(), args.output.resolve()
    if output.is_relative_to(run) or run.is_relative_to(output):
        raise ValueError("Diagnostic output must not overlap the saved run")
    output.mkdir(parents=True, exist_ok=False)
    before = hashes(run / "workspace")
    database = run / "state/opencode/opencode.db"
    source_db_hash = hashes(database.parent)
    workspace = output / "workspace"
    shutil.copytree(run / "workspace", workspace)
    db = output / "session.db"
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as source:
        with closing(sqlite3.connect(db)) as target:
            source.backup(target)
    project = Path(__file__).resolve().parents[1]
    manifest = json.loads((args.previous_trace / "runtime-manifest.json").read_text(encoding="utf-8"))
    changed = upgrade_test_guidance(workspace, project, manifest)
    for key, folder in {"OPENCODE_TEST_HOME": "home", "OPENCODE_CONFIG_DIR": "config",
                        "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache"}.items():
        os.environ[key] = str(output / folder)
    os.environ["OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"] = "1"
    sys.path.insert(0, str(project / "src"))
    from opencode.app import App
    from opencode.compaction import estimate_tokens, input_budget
    from opencode.context import working_context
    from opencode.loop import _with_human_ids
    from opencode.provider import openai_messages_from_history
    from opencode.store import Store, latest_human_message

    install(workspace)
    store = Store(db)
    try:
        sid = json.loads((run / "result.json").read_text(encoding="utf-8"))["result"]["sessionID"]
        history = store.messages(sid)
        original = next(m for m in history if latest_human_message([m]))
        summary = next(m for m in reversed(history) if m.get("compaction_through"))
        todos = store.todos(sid)
        # Only the diagnostic DB gets a relocated workspace. Exact saved messages
        # remain intact; the model and every tool are stopped before execution.
        store.update_session(sid, directory=str(workspace))
        app = App(workspace, store=store)
        app.generate_titles = False
        captured = []
        would_compact = False

        class Captured(Exception):
            pass

        def capture(**kwargs):
            # Execution control is not part of the model request or trace format.
            kwargs.pop("abort_event", None)
            kwargs.pop("on_update", None)
            kwargs.pop("on_tool_call", None)
            kwargs.pop("on_attempt", None)
            kwargs.pop("on_text", None)
            captured.append(kwargs)
            raise Captured()

        def capture_before_compaction(app, session_id, history, provider, model_id, **kwargs):
            nonlocal would_compact
            would_compact = True
            capture(provider=provider, model=model_id, system=kwargs["system"], tools=kwargs["tools"],
                    messages=openai_messages_from_history(working_context(history, store, session_id)))

        prompt = args.prompt.read_text(encoding="utf-8-sig")
        with patch.object(app.provider, "complete", side_effect=capture), patch.object(app, "ensure_mcp"), \
                patch("opencode.loop._maybe_compact", side_effect=capture_before_compaction):
            try:
                app.prompt(sid, prompt)
            except Captured:
                pass
        assert len(captured) == 1, "No first request captured"
        request = captured[0]
        assert request.get("tools"), "Not the work prompt assembly"
        text = "\n".join(m.get("content") or "" for m in request["messages"])
        homepage = (workspace / ".opencode/skills/research-practice/SKILL.md").read_text(encoding="utf-8")
        saved_history = store.messages(sid)
        current_request = latest_human_message(saved_history)
        # Covered requests remain exact in the database, but the checkpoint
        # replaces them on the wire. Store owns all historical replay exclusions;
        # count equal requests independently, excluding only this new request ID.
        # The wire shows each real human message with its saved ID header; the
        # newest message may also carry this step's host facts as a suffix.
        def presented(message):
            return _with_human_ids([message])[0]["content"]

        def without_facts(content):
            return content.split("\n\n<host-facts>\n", 1)[0] if isinstance(content, str) else content

        expected_original_replays = sum(
            message.get("role") == "user" and message.get("content") == presented(original)
            for message in openai_messages_from_history(_with_human_ids([
                item for item in store.context_messages(sid) if item.get("id") != current_request["id"]
            ]))
        )
        actual_original_replays = sum(
            message.get("role") == "user" and without_facts(message.get("content")) == presented(original)
            for message in request["messages"]
        )
        current_on_wire = [message for message in request["messages"]
                           if message.get("role") == "user"
                           and without_facts(message.get("content")) == presented(current_request)]
        original_preserved = any(
            message["id"] == original["id"] and message.get("content") == original["content"]
            and latest_human_message([message])
            for message in saved_history
        )
        checks = {
            "original_request_exact": original_preserved and actual_original_replays == expected_original_replays,
            "latest_summary_exact": summary["content"] in text,
            "homepage_exact": homepage in request["system"],
            "updated_completion_guidance": "## Continuation and completion" in request["system"],
            # Source Common keeps todo state in storage and tool receipts; it
            # does not inject a fresh todo projection into every model prompt.
            "todos_exact": store.todos(sid) == todos,
            "current_request_exact": current_request["content"] == prompt and len(current_on_wire) == 1,
            "saved_workspace_unchanged": hashes(run / "workspace") == before,
            "saved_database_unchanged": hashes(database.parent) == source_db_hash,
        }
        save(output / ("assembly-before-compaction.json" if would_compact else "request.json"),
             {**request, "provider": request["provider"].id, "on_text": None})
        result = {"checks": checks, "session_id": sid, "original_request_chars": len(original["content"]),
                  "summary_chars": len(summary["content"]), "homepage_chars": len(homepage),
                  "message_count": len(request["messages"]), "estimated_message_tokens": estimate_tokens(request["messages"]),
                  "input_budget": input_budget(app, request["provider"], request["model"], request["system"], request["tools"]),
                  "compaction_required_before_work_request": would_compact,
                  "guidance_updated": changed, "model_calls": 0, "research_tools_executed": 0}
        save(output / "result.json", result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        assert all(checks.values()), checks
        print("Original-request check: exact saved text, with wire replay determined by checkpoint coverage.")
        print("Prompt-assembly boundary only: no model executed and no scientific completion was verified.")
    finally:
        store.close()


if __name__ == "__main__":
    main()
