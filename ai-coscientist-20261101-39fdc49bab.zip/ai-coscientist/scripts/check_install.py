"""Check that this installation can run: packages, system libraries, browser, shell and model endpoint.

    .venv/Scripts/python scripts/check_install.py          (Windows)
    .venv/bin/python scripts/check_install.py              (Linux)
    ... --no-ping   skip contacting the model endpoint

Prints one line per item: OK, 注意 (works with a limitation) or 缺少 (must be fixed).
Never prints the API key itself. Exit code 1 when something must be fixed.
"""

from __future__ import annotations

import argparse
from importlib import import_module, metadata
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "llm.opencode.json"
KEY_ENV = "LOCAL_OPENAI_API_KEY"
LINUX = sys.platform.startswith("linux")
results = []


def report(status: str, item: str, detail: str = "", fix: str = "") -> None:
    results.append(status)
    print(f"[{status}] {item}" + (f"：{detail}" if detail else ""))
    if fix:
        print(f"       → {fix}")


def check_python() -> None:
    version = ".".join(map(str, sys.version_info[:3]))
    if sys.version_info[:2] < (3, 11):
        report("缺少", "Python", f"{version}，需要 3.11 以上", "安裝 Python 3.12 後重新執行安裝")
    else:
        report("OK", "Python", f"{version}（{sys.executable}）")


def check_packages() -> None:
    wanted = {}
    for line in (ROOT / "requirements.txt").read_text(encoding="utf-8").splitlines():
        match = re.match(r"^([A-Za-z0-9_.-]+)==([^\s;]+)", line.strip())
        if match:
            wanted[match[1]] = match[2]
    missing, different = [], []
    for name, pinned in wanted.items():
        try:
            installed = metadata.version(name)
        except metadata.PackageNotFoundError:
            missing.append(name)
            continue
        if installed != pinned:
            different.append(f"{name} {installed}（測試版本 {pinned}）")
    if missing:
        report("缺少", "Python 套件", "、".join(missing), "重新執行 install.cmd 或 bash install.sh")
    elif different:
        report("注意", "Python 套件版本與測試版本不同", "、".join(different))
    else:
        report("OK", "Python 套件", f"{len(wanted)} 個，版本與 requirements.txt 相同")
    modules = ["opencode", "researchkit", "planningkit", "researchkit.tools", "pymupdf", "latex2mathml", "rdkit.Chem", "z3",
               "numpy", "scipy", "matplotlib", "ase", "textual", "tree_sitter_bash", "tree_sitter_powershell"]
    failed = []
    for module in modules:
        try:
            import_module(module)
        except Exception as error:  # report every broken import, not only the first
            failed.append(f"{module}（{type(error).__name__}: {error}）")
    if failed:
        report("缺少", "模組載入", "；".join(failed), "重新執行安裝；若仍失敗，把這行訊息交給維護者")
    else:
        report("OK", "模組載入", "本專案與科研、推論、模擬套件都可匯入")


def check_icu() -> None:
    try:
        from opencode.collation import _locale_compare
        _locale_compare("a", "b")
    except Exception as error:
        fix = ("Debian／Ubuntu：sudo apt install libicu-dev（或發行版的 libicuNN）；RHEL／Fedora：sudo dnf install libicu"
               if LINUX else "需要 Windows 10 1903 以上內建的 icu.dll")
        report("缺少", "系統 ICU（工具名稱排序）", str(error), fix)
    else:
        report("OK", "系統 ICU（工具名稱排序）")


def check_shell() -> None:
    from opencode.tools.shell import _shell_executable
    shell = _shell_executable({})
    if LINUX and Path(shell).name != "bash":
        fix = ("目前的 SHELL 是 " + os.environ.get("SHELL", "（未設定）") + "；執行前設定 export SHELL=/bin/bash"
               if shutil.which("bash") else "安裝 bash：sudo apt install bash")
        report("注意", "終端工具", f"使用 {shell}，模型寫的 bash 指令可能不相容", fix)
    else:
        report("OK", "終端工具", shell)
    from opencode.paths import data_dir
    rg = shutil.which("rg") or next((str(p) for p in [data_dir() / "bin" / ("rg.exe" if os.name == "nt" else "rg")]
                                     if p.is_file()), None)
    if rg:
        report("OK", "ripgrep（搜尋工具）", rg)
    else:
        report("注意", "ripgrep（搜尋工具）", "第一次搜尋檔案時會自動從 GitHub 下載",
               "無法連到 GitHub 的環境請先安裝：Windows：winget install BurntSushi.ripgrep.MSVC；"
               "Debian／Ubuntu：sudo apt install ripgrep")
    if shutil.which("git"):
        report("OK", "git", shutil.which("git"))
    else:
        report("注意", "git", "找不到；介面可用，但用 --from 建立無人值守任務時需要它",
               "Windows：安裝 Git for Windows；Debian／Ubuntu：sudo apt install git")


def check_browser() -> None:
    from researchkit.report_pdf import _browser_executable
    try:
        browser = _browser_executable()
    except RuntimeError:
        fix = ("Debian／Ubuntu：sudo apt install chromium（或安裝 Google Chrome）" if LINUX
               else "安裝 Microsoft Edge 或 Google Chrome（Windows 通常已內建 Edge）")
        report("注意", "PDF 報告用瀏覽器", "找不到 Chrome／Chromium／Edge；報告只會有 HTML", fix)
        return
    report("OK", "PDF 報告用瀏覽器", str(browser))
    if LINUX:
        fonts = ""
        if shutil.which("fc-list"):
            fonts = subprocess.run(["fc-list", ":lang=zh", "family"], capture_output=True, text=True).stdout.strip()
        if fonts:
            report("OK", "中文字型（PDF 報告）", fonts.splitlines()[0])
        else:
            report("注意", "中文字型（PDF 報告）", "找不到中文字型，PDF 中文會顯示成方塊",
                   "Debian／Ubuntu：sudo apt install fonts-noto-cjk")


def check_model(ping: bool) -> None:
    try:
        config = json.loads(CONFIG.read_text(encoding="utf-8"))
        provider_id, model = config["model"].split("/", 1)
        options = config["provider"][provider_id]["options"]
        base_url = options["baseURL"].rstrip("/")
    except (OSError, ValueError, KeyError, AttributeError) as error:
        report("缺少", "模型設定", f"{CONFIG} 無法讀取：{error}", "見 INSTALL.md「設定模型」")
        return
    report("OK", "模型設定", f"{config['model']} @ {base_url}（{CONFIG.relative_to(ROOT)}）")
    key = os.environ.get(KEY_ENV)
    uses_env_key = f"{{env:{KEY_ENV}}}" in str(options.get("apiKey", ""))
    if uses_env_key and not key:
        report("注意", f"環境變數 {KEY_ENV}", "未設定；啟動器會用佔位值 local（本機免金鑰服務可用）",
               "若服務需要金鑰，見 INSTALL.md「設定模型」")
    elif uses_env_key:
        report("OK", f"環境變數 {KEY_ENV}", "已設定（不顯示內容）")
    if not ping:
        return
    import httpx
    headers = {"Authorization": f"Bearer {key or 'local'}"} if uses_env_key else {}
    try:
        response = httpx.get(f"{base_url}/models", headers=headers, timeout=5)
    except httpx.HTTPError as error:
        report("注意", "模型端點連線", f"{base_url} 沒有回應（{type(error).__name__}）",
               "確認服務已啟動、網址正確、本機能連到該主機；可加 --no-ping 略過這項")
        return
    if response.status_code in (401, 403):
        report("注意", "模型端點連線", f"伺服器回 {response.status_code}，需要正確的金鑰", f"設定 {KEY_ENV}")
    elif response.is_success:
        names = []
        try:
            names = [item.get("id") for item in response.json().get("data", []) if isinstance(item, dict)]
        except ValueError:
            pass
        served = model in names if names else None
        detail = "可連線" + ("" if served is None else ("，提供此模型" if served else f"，但清單沒有 {model}"))
        report("OK" if served is not False else "注意", "模型端點連線", detail,
               "" if served is not False else f"伺服器提供：{'、'.join(map(str, names[:5]))}；請修正 config 中的 model")
    else:
        report("注意", "模型端點連線", f"伺服器回 {response.status_code}")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="檢查安裝是否可用")
    parser.add_argument("--no-ping", action="store_true", help="不連線測試模型端點")
    args = parser.parse_args(argv)
    for check in (check_python, check_packages, check_icu, check_shell, check_browser):
        try:
            check()
        except Exception as error:  # one broken check must not hide the others
            report("缺少", check.__name__, f"{type(error).__name__}: {error}")
    check_model(not args.no_ping)
    windows = os.name == "nt"
    if "缺少" in results:
        print("\n有必須處理的項目（標為「缺少」）；處理後重新執行安裝，或只重跑本檢查。")
        return 1
    print("\n安裝可用。" + ("有「注意」項目時，相關功能受限，其餘可正常使用。" if "注意" in results else ""))
    print("開啟介面：" + (r"co-scientist.cmd [資料夾]" if windows else "bash co-scientist.sh [資料夾]")
          + "（預設為目前所在資料夾，不存在會建立；一般任務與研究都用它）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
