"""Small real-model protocol test, not a scientific end-to-end test."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import sys
import threading
import time
from unittest.mock import patch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-url", default="http://192.168.1.118:8000/v1")
    parser.add_argument("--model", default="deepseek-ai/DeepSeek-V4-Flash-0731")
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    for key, name in {"OPENCODE_CONFIG_DIR": "config", "OPENCODE_TEST_HOME": "home",
                      "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache",
                      "TEMP": "temp", "TMP": "temp"}.items():
        path = root / name
        path.mkdir(exist_ok=True)
        os.environ[key] = str(path)
    os.environ["OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"] = "1"
    project = root / "workspace"
    project.mkdir()
    (project / ".git").mkdir()
    # These are explicitly synthetic protocol fixtures, never LIT research inputs.
    (project / "meeting.txt").write_text("Protocol fixture: meeting date is 2026-11-05.\n", encoding="utf-8")
    (project / "room.txt").write_text("Protocol fixture: assigned room is Delta-42.\n", encoding="utf-8")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    import httpx
    from opencode.app import App
    from opencode.provider import Client
    from opencode.store import Store

    config = {"model": "local/" + args.model, "provider": {"local": {
        "options": {"baseURL": args.base_url, "apiKey": "local"},
        "models": {args.model: {"interleaved": {"field": "reasoning"},
                               "limit": {"context": 131072, "output": 12000},
                               "options": {"reasoningEffort": "medium", "include_stream_usage": True}}},
    }}, "agent": {"build": {"temperature": 0, "steps": 8}}}
    requests, completions, outcomes = [], [], []
    trace_lock = threading.Lock()
    send = httpx.Client.send
    async_send = httpx.AsyncClient.send
    complete = Client.complete

    def save(name, value):
        (root / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

    def traced_send(client, request, **kwargs):
        record = request.method == "POST" and str(request.url).endswith("/chat/completions")
        if record:
            with trace_lock:
                requests.append(json.loads(request.content))
                index = len(requests)
                save(f"wire-request-{index:02}.json", requests[-1])
        response = send(client, request, **kwargs)
        if record:
            if kwargs.get("stream"):
                original_lines = response.iter_lines
                def traced_lines():
                    with (root / f"wire-response-{index:02}.sse").open("w", encoding="utf-8") as log:
                        for line in original_lines():
                            log.write(line + "\n")
                            log.flush()
                            yield line
                response.iter_lines = traced_lines
            else:
                save(f"wire-response-{index:02}.json", response.json())
        return response

    async def traced_async_send(client, request, **kwargs):
        record = request.method == "POST" and str(request.url).endswith("/chat/completions")
        if record:
            with trace_lock:
                requests.append(json.loads(request.content))
                index = len(requests)
                save(f"wire-request-{index:02}.json", requests[-1])
        response = await async_send(client, request, **kwargs)
        if record:
            if kwargs.get("stream"):
                original_lines = response.aiter_lines
                async def traced_lines():
                    with (root / f"wire-response-{index:02}.sse").open("w", encoding="utf-8") as log:
                        async for line in original_lines():
                            log.write(line + "\n")
                            log.flush()
                            yield line
                response.aiter_lines = traced_lines
            else:
                save(f"wire-response-{index:02}.json", response.json())
        return response

    def traced_complete(client, **kwargs):
        started = time.monotonic()
        result = complete(client, **kwargs)
        with trace_lock:
            completions.append(asdict(result))
            index = len(completions)
            save(f"completion-{index:02}.json", {**completions[-1], "seconds": time.monotonic() - started})
        print(f"Call {index}: tools={[c.name for c in result.tool_calls]}; "
              f"reasoning_chars={len(result.reasoning_content or '')}; seconds={time.monotonic()-started:.1f}", flush=True)
        return result

    started = time.monotonic()
    error = None
    store = Store(root / "session.db")
    try:
        with patch.object(httpx.Client, "send", traced_send), \
             patch.object(httpx.AsyncClient, "send", traced_async_send), \
             patch.object(Client, "complete", traced_complete):
            app = App(project, store=store, config=config, auto_approve=True)
            app.generate_titles = False
            sid = app.create_session()["id"]
            outcomes.append(app.prompt(sid, "Read meeting.txt and report the meeting date. Be brief.", on_text=lambda _: None))
            store.close()
            store = Store(root / "session.db")
            app = App(project, store=store, config=config, auto_approve=True)
            app.generate_titles = False
            outcomes.append(app.prompt(sid, "Now read room.txt and give both the meeting date and the room. Be brief."))
            save("messages.json", store.messages(sid))
    except Exception as exc:
        error = str(exc)
    finally:
        store.close()
    protocol_values = [c["reasoning_content"] for c in completions if c.get("reasoning_content")]
    replayed = [m.get("reasoning") for r in requests[1:] for m in r["messages"] if m["role"] == "assistant"]
    checks = {
        "two_turns_completed": len(outcomes) == 2 and all(r["status"] == "completed" for r in outcomes),
        "first_date": bool(outcomes) and "2026-11-05" in outcomes[0]["text"],
        "second_date_and_room": len(outcomes) == 2 and "2026-11-05" in outcomes[1]["text"] and "Delta-42" in outcomes[1]["text"],
        "reasoning_observed": bool(protocol_values),
        "first_reasoning_returned_exactly": bool(protocol_values) and protocol_values[0] in replayed,
        "all_assistant_wire_messages_have_field": all("reasoning" in m for r in requests for m in r["messages"] if m["role"] == "assistant"),
        "stream_and_nonstream": any(r.get("stream") for r in requests) and any(not r.get("stream") for r in requests),
    }
    result = {"error": error, "checks": checks, "seconds": time.monotonic()-started,
              "requests": len(requests), "outcomes": outcomes,
              "scope": "synthetic protocol continuity only; not a LIT test or performance A/B"}
    save("result.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "outcomes"}, ensure_ascii=False, indent=2))
    return 0 if not error and all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
