"""Compare one frozen request with and without historical reasoning; never run tools."""

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import httpx

from scripts.replay_compaction_boundary import digest, exchange, load, save


def prepare_pair(original):
    if original.get("stream") is True:
        raise ValueError("Only saved non-streaming requests are supported.")
    summaries = [m for m in original["messages"] if m["role"] == "assistant"
                 and (m.get("content") or "").startswith("<previous-summary>\n")]
    if len(summaries) != 1:
        raise ValueError("Expected exactly one frozen summary.")
    retained, removed = deepcopy(original), deepcopy(original)
    changes = []
    for index, message in enumerate(removed["messages"]):
        if message["role"] != "assistant":
            continue
        for field in ("reasoning", "reasoning_content"):
            if field not in message or message[field] in (None, ""):
                continue
            if not isinstance(message[field], str):
                raise ValueError("Historical reasoning must be text.")
            changes.append({"message_index": index, "field": field,
                            "characters": len(message[field]), "sha256": digest(message[field])})
            message[field] = ""
    if not changes:
        raise ValueError("No historical reasoning to compare.")
    restored = deepcopy(removed)
    for change in changes:
        index, field = change["message_index"], change["field"]
        restored["messages"][index][field] = original["messages"][index][field]
    if restored != original or retained != original:
        raise ValueError("Unexpected request changes.")
    # Empty existing fields preserve the wire shape; current reasoning_effort is untouched.
    checks = {
        "changes": changes, "retained_equals_original": True,
        "only_historical_reasoning_emptied": True,
        "generation_controls": {k: v for k, v in original.items() if k not in ("messages", "tools")},
        "tools_sha256": digest(original.get("tools")),
        "summary_sha256": digest(summaries[0]),
        "messages_without_historical_reasoning_sha256": digest(removed["messages"]),
        "retained_request_sha256": digest(retained), "removed_request_sha256": digest(removed),
    }
    return retained, removed, checks


def execute_pair(client, base_url, original, output):
    output = Path(output)
    retained, removed, checks = prepare_pair(original)
    save(output / "boundary-checks.json", checks)
    results = {"calls": 0, "tools_executed": 0, "research_restarted": False,
               "order": ["retained", "removed"], "arms": {}, "semantic_quality": "not_reviewed"}
    for label, payload in (("retained", retained), ("removed", removed)):
        response, meta = exchange(client, base_url, payload, output, label)
        message = response["choices"][0]["message"]
        text = message.get("content") or ""
        calls = message.get("tool_calls") or []
        (output / f"{label}.answer.md").write_text(text, encoding="utf-8")
        results["calls"] += 1
        results["arms"][label] = {**meta, "has_text_answer": bool(text.strip()),
                                  "returned_tool_calls": calls}
        save(output / "result.json", results)
        if meta["finish_reason"] not in ("stop", "tool_calls") or not (text.strip() or calls):
            raise RuntimeError(f"{label} returned no complete response; comparison stopped without retry.")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-url")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if args.execute and not args.base_url:
        parser.error("--execute requires --base-url")
    before = hashlib.sha256(args.request.read_bytes()).hexdigest()
    original = load(args.request)
    retained, removed, checks = prepare_pair(original)
    args.output.mkdir(parents=True, exist_ok=False)
    save(args.output / "input-manifest.json", {"path": str(args.request.resolve()), "sha256": before})
    save(args.output / "boundary-checks.json", checks)
    save(args.output / "prepared-retained.json", retained)
    save(args.output / "prepared-removed.json", removed)
    try:
        if args.execute:
            with httpx.Client(timeout=httpx.Timeout(600, connect=15)) as client:
                available = client.get(args.base_url.rstrip("/") + "/models")
                available.raise_for_status()
                if original["model"] not in [m["id"] for m in available.json()["data"]]:
                    raise RuntimeError("Recorded model unavailable; no model requests sent.")
                result = execute_pair(client, args.base_url, original, args.output)
                print(json.dumps(result, ensure_ascii=False))
    except Exception as error:
        save(args.output / "error.json", {"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        after = hashlib.sha256(args.request.read_bytes()).hexdigest()
        save(args.output / "input-integrity.json", {"before": before, "after": after, "unchanged": before == after})
        if before != after:
            raise RuntimeError("Original request changed during the comparison.")
    print(str(args.output.resolve()))


if __name__ == "__main__":
    main()
