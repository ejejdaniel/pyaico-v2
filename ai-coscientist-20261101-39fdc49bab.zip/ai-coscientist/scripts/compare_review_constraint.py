"""Compare a saved review request answered freely and under a JSON schema (generation-time constraint).

Replays one wire request several times per condition, interleaved, with a distinct seed per run.
Records whether the reply parses and matches the schema, the decisions, time, and the full
reply, so the reasons can be read afterwards. Nothing in the original run changes.

    python scripts/compare_review_constraint.py WIRE_DIR OUT.jsonl --runs 3
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import httpx
import jsonschema

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from researchkit.reviewer import _unwrap_json_fence  # noqa: E402

LOCATOR = {"type": "object", "properties": {"file_id": {"type": "string"}, "start_line": {"type": "integer"},
                                            "end_line": {"type": "integer"}},
           "required": ["file_id", "start_line", "end_line"], "additionalProperties": False}
SUBJECT = {"anyOf": [
    {"type": "object", "properties": {"file_id": {"type": "string"}, "start_line": {"type": "integer"},
                                      "end_line": {"type": "integer"}, "quote": {"type": "string"}},
     "required": ["file_id", "start_line", "end_line", "quote"], "additionalProperties": False},
    {"type": "object", "properties": {"required_subject": {"type": "integer"}},
     "required": ["required_subject"], "additionalProperties": False}]}
# The reason comes before the decision so the model writes its reasoning before judging.
CHECK = {"type": "object", "properties": {
    "subject": SUBJECT, "evidence": {"type": "array", "items": LOCATOR}, "reason": {"type": "string"},
    "decision": {"type": "string", "enum": ["supported", "conditional", "contradicted", "unsupported", "unassessed"]}},
    "required": ["subject", "evidence", "reason", "decision"], "additionalProperties": False}
SCHEMA = {"type": "object", "properties": {"checks": {"type": "array", "minItems": 1, "items": CHECK}},
          "required": ["checks"], "additionalProperties": False}


def run_once(url, base, constrained, seed):
    body = dict(base, stream=False, seed=seed)
    body.pop("stream_options", None)
    if constrained:
        body["response_format"] = {"type": "json_schema",
                                   "json_schema": {"name": "review_checks", "strict": True, "schema": SCHEMA}}
    started = time.monotonic()
    response = httpx.post(url, json=body, timeout=httpx.Timeout(2400.0, connect=30))
    elapsed = round(time.monotonic() - started, 1)
    data = response.json()
    choice = (data.get("choices") or [{}])[0]
    text = (choice.get("message") or {}).get("content") or ""
    row = {"constrained": constrained, "seed": seed, "http": response.status_code, "elapsed_s": elapsed,
           "finish": choice.get("finish_reason"), "usage": data.get("usage"), "text": text}
    try:
        value = json.loads(_unwrap_json_fence(text))
        row["parsed"] = True
        checks = value.get("checks") if isinstance(value, dict) else None
        row["checks"] = checks if isinstance(checks, list) else []
        try:
            jsonschema.validate(value, SCHEMA)
            row["schema_ok"] = True
        except jsonschema.ValidationError as error:
            row["schema_ok"] = False
            row["schema_error"] = error.message[:200]
    except ValueError as error:
        row.update(parsed=False, error=str(error)[:200], checks=[])
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("wire", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--url", default="http://192.168.1.118:8000/v1/chat/completions")
    args = parser.parse_args()
    base = json.loads((args.wire / "request.body.json").read_text(encoding="utf-8"))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    for index in range(args.runs):
        for constrained in (False, True):
            row = run_once(args.url, base, constrained, seed=2000 + index)
            with args.out.open("a", encoding="utf-8") as output:
                output.write(json.dumps(row, ensure_ascii=False) + "\n")
            decisions = {}
            for check in row["checks"]:
                if isinstance(check, dict):
                    decisions[check.get("decision")] = decisions.get(check.get("decision"), 0) + 1
            print("constrained" if constrained else "free", index + 1, "parsed", row.get("parsed"),
                  "schema", row.get("schema_ok"), row["elapsed_s"], "s", decisions, flush=True)


if __name__ == "__main__":
    main()
