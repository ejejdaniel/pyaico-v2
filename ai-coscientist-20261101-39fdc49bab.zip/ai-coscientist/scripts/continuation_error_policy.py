"""When an observed real-model continuation should stop on ordinary tool errors.

Common already saves every tool-error receipt and returns it to the agent on the
next request, and Common's doom_loop permission covers identical repeated calls.
Stopping a test run on the first validation error removes the agent's chance to
correct its arguments and turns a recoverable receipt into an inconclusive run.

This policy keeps generation/publication boundaries strict (those tools may have
spent model calls or committed records) and lets other tools fail and be
corrected, stopping only on repetition without progress.

Usage in a new observer (subclass a base Observation that does NOT stop on every
error, e.g. ``.tmp/research-origin-live/continue_once.py``)::

    class Observation(RecoverableToolErrors, base.Observation):
        pass
"""
from __future__ import annotations

# Tools whose failure may follow a model generation or a committed write. The
# base observers already stop on these; this policy leaves them unchanged.
BOUNDARY_TOOLS = frozenset({"research_method_explore", "research_review", "research_inference", "research_record"})


class RepeatedToolErrorPolicy:
    """Stop only when errors repeat without progress.

    * the same tool returns the same error text ``repeat_limit`` times in a row, or
    * ``consecutive_limit`` tool calls in a row fail, whatever the tool.
    A successful call of a tool resets that tool's streak and the overall streak.
    """

    def __init__(self, repeat_limit: int = 2, consecutive_limit: int = 5):
        if repeat_limit < 1 or consecutive_limit < 1:
            raise ValueError("limits must be positive")
        self.repeat_limit = repeat_limit
        self.consecutive_limit = consecutive_limit
        self._streaks: dict[str, tuple[str, int]] = {}
        self._consecutive = 0

    def observe(self, tool: str, *, error: str | None) -> str | None:
        """Record one finished call; return a stop reason or None."""
        if error is None:
            self._streaks.pop(tool, None)
            self._consecutive = 0
            return None
        self._consecutive += 1
        previous, count = self._streaks.get(tool, (None, 0))
        count = count + 1 if previous == error else 1
        self._streaks[tool] = (error, count)
        if count >= self.repeat_limit:
            return (f"{tool} returned the same error {count} times in a row after the agent saw the receipt; "
                    f"stopping as no progress. Last error: {error[:500]}")
        if self._consecutive >= self.consecutive_limit:
            return (f"{self._consecutive} consecutive tool calls failed without a successful call; "
                    f"stopping as no progress. Last: {tool}: {error[:500]}")
        return None


def latest_tool_receipt(apps, session_id: str, tool: str) -> str:
    """Return the newest saved receipt text for ``tool`` in the session.

    Common saves the receipt before publishing tool.completed, so this reads the
    exact error the agent will see. Falls back to an empty string.
    """
    for app in apps:
        try:
            messages = app.store.messages(session_id)
        except Exception:
            continue
        for message in reversed(messages):
            if message.get("role") == "tool" and message.get("name") == tool:
                content = message.get("content")
                return content if isinstance(content, str) else repr(content)
    return ""


class RecoverableToolErrors:
    """Observer mixin: ordinary tool errors stay with the agent until they repeat."""

    error_policy_factory = RepeatedToolErrorPolicy

    def _error_policy(self) -> RepeatedToolErrorPolicy:
        policy = getattr(self, "_recoverable_error_policy", None)
        if policy is None:
            policy = self._recoverable_error_policy = self.error_policy_factory()
        return policy

    def tool_finished(self, event):
        tool = event.get("tool") or ""
        if tool in BOUNDARY_TOOLS:
            return super().tool_finished(event)
        if event.get("title") != "error":
            self._error_policy().observe(tool, error=None)
            return super().tool_finished(event)
        error = latest_tool_receipt(getattr(self, "apps", []), event.get("sessionID") or "", tool)
        reason = self._error_policy().observe(tool, error=error or "error")
        if reason:
            self.stop(reason)
        # Otherwise the saved receipt goes back to the agent; nothing is retried here.
