"""Resume the frozen no-reasoning arm through the real loop, then ask the original Q2."""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import threading
import time
from unittest.mock import patch

import httpx

from scripts.replay_compaction_boundary import load, save
from opencode.app import App
from opencode.provider import Client, Completion, ToolCall, _check_abort
from opencode.store import Store
from opencode.skills import render as render_skills
from opencode.tools.util import relocate_text


def hashes(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file() and ".git" not in p.parts}


class PreparedOnly(Exception):
    pass


class ResumeStore(Store):
    """Test entry only: reuse the saved human turn, never append a continuation hint."""

    resume_human = None

    def add_message(self, session_id, role, data):
        if role == "user" and self.resume_human is not None:
            human = self.resume_human
            if human["sessionID"] != session_id or data.get("content") != human["content"]:
                raise ValueError("Resume must use the exact original human request.")
            self.resume_human = None
            return deepcopy(human)
        return super().add_message(session_id, role, data)


def without_reasoning(messages):
    result = deepcopy(messages)
    for item in result:
        if item["role"] == "assistant":
            item.pop("reasoning_content", None)
            item["reasoning"] = ""
    return result


def remap(value, old_case, new_case):
    return json.loads(relocate_text(json.dumps(value, ensure_ascii=False), new_case, [old_case]))


def restore(store, source_db, archive, frozen, workspace):
    sids = {m["sessionID"] for m in archive}
    if len(sids) != 1 or any(m.get("compaction_through") for m in archive):
        raise ValueError("Expected one uncompacted saved prefix.")
    sid = sids.pop()
    # Read only the session identity. Later messages, todos and conclusions are not imported.
    with sqlite3.connect(source_db.as_uri() + "?mode=ro", uri=True) as source:
        source.row_factory = sqlite3.Row
        session = dict(source.execute("SELECT * FROM session WHERE id=?", (sid,)).fetchone())
    session["directory"] = str(workspace)
    session["meta"] = json.dumps({"turn": 0, "read_files": sorted({
        m["metadata"]["path"] for m in archive if m.get("role") == "tool"
        and isinstance(m.get("metadata"), dict) and m["metadata"].get("path")})})
    columns = list(session)
    store._conn.execute(f"INSERT INTO session ({','.join(columns)}) VALUES ({','.join('?' for _ in columns)})",
                        [session[k] for k in columns])
    for message in archive:
        store._conn.execute("INSERT INTO message (id,session_id,role,data,created) VALUES (?,?,?,?,?)",
                            (message["id"], sid, message["role"], json.dumps(message), message["created"]))
    store._conn.commit()
    first_call = frozen["messages"][3]["tool_calls"][0]["id"]
    split = next(i for i, m in enumerate(archive)
                 if any(c["id"] == first_call for c in m.get("tool_calls") or []))
    if split <= 0:
        raise ValueError("Missing original compaction boundary.")
    summary = frozen["messages"][1]["content"]
    assert summary.startswith("<previous-summary>\n") and summary.endswith("\n</previous-summary>")
    store.commit_compaction(sid, archive[split - 1]["id"], summary[19:-20])
    humans = [m for m in archive if m["role"] == "user"]
    if len(humans) != 1 or humans[0]["content"] != frozen["messages"][2]["content"]:
        raise ValueError("Original Q1 mismatch.")
    store.resume_human = humans[0]
    return sid


def saved_completion(response, old_case, new_case):
    choice = response["choices"][0]
    if choice["finish_reason"] != "tool_calls":
        raise ValueError("Expected the saved, unexecuted tool request.")
    message = response["choices"][0]["message"]
    calls = [ToolCall(c["id"], c["function"]["name"],
                      remap(json.loads(c["function"]["arguments"]), old_case, new_case))
             for c in message["tool_calls"]]
    return Completion(text=message.get("content") or "", tool_calls=calls,
                      reasoning_content=message.get("reasoning") or message.get("reasoning_content"),
                      usage=response.get("usage") or {}, model=response.get("model"),
                      finish_reason=choice["finish_reason"])


class ContinuationClient(Client):
    def __init__(self, auth, config, *, frozen, response, old_case, output, execute, added_skill_index=None):
        super().__init__(auth, config)
        self.frozen, self.response = frozen, response
        self.old_case, self.output = old_case, output
        self.execute = execute
        self.injected = False
        self.added_skill_index = added_skill_index

    def complete(self, **kwargs):
        _check_abort(kwargs.get("abort_event"))
        kwargs = dict(kwargs)
        kwargs["system"] = remap(kwargs["system"], self.old_case, self.output)
        kwargs["messages"] = without_reasoning(remap(kwargs["messages"], self.old_case, self.output))
        if not self.injected:
            actual = [{"role": "system", "content": kwargs["system"]}, *kwargs["messages"]]
            expected = remap(self.frozen["messages"], self.old_case, self.output)
            save(self.output / "restored-prompt.json", actual)
            save(self.output / "expected-prompt.json", expected)
            comparable = deepcopy(actual)
            if self.added_skill_index:
                addition = "\n\n" + self.added_skill_index
                if comparable[0]["content"].count(addition) != 1:
                    raise ValueError("Expected exactly the approved bundled skill index addition.")
                comparable[0]["content"] = comparable[0]["content"].replace(addition, "", 1)
            if comparable != expected:
                raise ValueError("Restored prompt differs from the frozen arm; no model call made.")
            tools = [{"type": "function", "function": t} for t in kwargs["tools"]]
            if tools != remap(self.frozen["tools"], self.old_case, self.output):
                raise ValueError("Tool definitions differ from the frozen arm.")
            save(self.output / "restore-checks.json", {
                "prompt_equal_except_case_path_relocation": not bool(self.added_skill_index), "tools_equal": True,
                "approved_added_skill_index": self.added_skill_index,
                "all_other_prompt_content_equal": True,
                "new_human_messages_before_q1": 0, "summary_recomputed": False,
                "old_case": str(self.old_case), "new_case": str(self.output),
            })
            self.injected = True
            if not self.execute:
                raise PreparedOnly()
            print("Saved B response accepted; executing its original tool request.", flush=True)
            return saved_completion(self.response, self.old_case, self.output)
        return super().complete(**kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--arm", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-url", default="http://192.168.1.118:8000/v1")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--answer-review-skill", choices=["investigate"])
    args = parser.parse_args()
    old_case, output = args.case.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    repository = Path(__file__).resolve().parents[1]
    implementation = {str(p.relative_to(repository)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (repository / "src").rglob("*")
                      if p.is_file() and p.suffix in {".py", ".md", ".txt", ".html"}}
    save(output / "implementation-manifest.json", implementation)
    settings = load(old_case / "settings.json")
    source = Path(settings["source"])
    before = hashes(source)
    if before != load(old_case / "source-manifest.json"):
        raise ValueError("Captured source differs from the original test.")
    workspace = output / "workspace"
    shutil.copytree(source, workspace)
    subprocess.run(["git", "init", "--quiet", str(workspace)], check=True)
    for key, folder in {"OPENCODE_CONFIG_DIR": "config", "OPENCODE_TEST_HOME": "home",
                        "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache",
                        "TEMP": "temp", "TMP": "temp"}.items():
        target = output / folder
        target.mkdir(exist_ok=True)
        os.environ[key] = str(target)
    os.environ["OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"] = "1"
    os.environ.setdefault("LOCAL_OPENAI_API_KEY", "local")
    import tempfile
    tempfile.tempdir = str(output / "temp")
    files = [args.archive, args.arm / "removed.request.json", args.arm / "removed.response.bin"]
    originals = {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    archive, frozen, response = (load(p) for p in files)
    # Only the original prefix is copied; no later Q1/Q2 answer or summary is accessible here.
    archive_copy = output / args.archive.resolve().relative_to(old_case)
    archive_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.archive, archive_copy)
    config = deepcopy(settings["config"])
    if args.answer_review_skill:
        config.setdefault("skills", {}).setdefault("paths", []).append(
            str(Path(__file__).resolve().parents[1] / "src/opencode/skill_assets"))
        config.setdefault("agent", {}).setdefault(config.get("default_agent", "build"), {}).setdefault(
            "options", {})["answer_review_skill"] = args.answer_review_skill
    config["provider"]["local"]["options"]["baseURL"] = args.base_url
    questions = load(old_case / "questions.json")
    used_steps = sum(m["role"] == "assistant" for m in archive)
    assert used_steps == 14 and frozen["messages"][2]["content"] == questions[0]
    save(output / "input-manifest.json", originals)
    save(output / "settings.json", {"config": config, "original_steps_used": used_steps,
                                    "questions": questions, "historical_reasoning_replayed": False})
    raw_client = httpx.Client
    raw_async_client = httpx.AsyncClient
    requests = []
    requests_lock = threading.Lock()

    class WireClient(raw_client):
        def send(self, request, **kwargs):
            if request.method != "POST" or not request.url.path.endswith("/chat/completions"):
                return super().send(request, **kwargs)
            body = json.loads(request.content)
            assert all(not m.get("reasoning") and not m.get("reasoning_content") for m in body["messages"])
            for key in ("model", "max_tokens", "reasoning_effort"):
                assert body.get(key) == frozen.get(key)
            with requests_lock:
                index = len(requests) + 1
                entry = {"index": index, "started": time.time(), "finished": False}
                requests.append(entry)
                (output / f"request-{index:03}.json").write_bytes(request.content)
                save(output / "calls.json", requests)
            print(f"Model call {index} started", flush=True)
            started = time.monotonic()
            try:
                answer = super().send(request, **kwargs)
                answer.read()
                (output / f"response-{index:03}.json").write_bytes(answer.content)
                with requests_lock:
                    entry.update(seconds=time.monotonic() - started, http_status=answer.status_code, finished=True)
                    if answer.status_code == 200:
                        data = answer.json()
                        entry.update(usage=data.get("usage", {}), finish_reason=data["choices"][0].get("finish_reason"))
                return answer
            finally:
                with requests_lock:
                    save(output / "calls.json", requests)
                print(f"Model call {index} returned", flush=True)

    class WireAsyncClient(raw_async_client):
        async def send(self, request, **kwargs):
            if request.method != "POST" or not request.url.path.endswith("/chat/completions"):
                return await super().send(request, **kwargs)
            body = json.loads(request.content)
            assert all(not m.get("reasoning") and not m.get("reasoning_content") for m in body["messages"])
            for key in ("model", "max_tokens", "reasoning_effort"):
                assert body.get(key) == frozen.get(key)
            with requests_lock:
                index = len(requests) + 1
                entry = {"index": index, "started": time.time(), "finished": False}
                requests.append(entry)
                (output / f"request-{index:03}.json").write_bytes(request.content)
                save(output / "calls.json", requests)
            print(f"Model call {index} started", flush=True)
            started = time.monotonic()
            try:
                answer = await super().send(request, **kwargs)
                await answer.aread()
                (output / f"response-{index:03}.json").write_bytes(answer.content)
                with requests_lock:
                    entry.update(seconds=time.monotonic() - started, http_status=answer.status_code, finished=True)
                    if answer.status_code == 200:
                        data = answer.json()
                        entry.update(usage=data.get("usage", {}), finish_reason=data["choices"][0].get("finish_reason"))
                return answer
            finally:
                with requests_lock:
                    save(output / "calls.json", requests)
                print(f"Model call {index} returned", flush=True)

    results = []
    store = ResumeStore(output / "session.db")
    try:
        sid = restore(store, old_case / "session.db", archive, frozen, workspace)
        app = App(workspace, store=store, auto_approve=True, config=config)
        app.generate_titles = False
        client = ContinuationClient(app.auth, config, frozen=frozen, response=response,
                                    old_case=old_case, output=output, execute=args.execute,
                                    added_skill_index=render_skills({args.answer_review_skill: app.skills[args.answer_review_skill]})
                                    if args.answer_review_skill else None)
        app.provider = client
        default_steps = app.agents[app.default_agent].steps or int(config.get("steps") or 100)
        app.agents[app.default_agent].steps = default_steps - used_steps
        original_ask = app.permissions.ask

        def guarded_ask(**kwargs):
            if kwargs.get("permission") == "doom_loop":
                app.abort(sid)
                raise RuntimeError("Repeated identical tool calls; experiment stopped for review.")
            return original_ask(**kwargs)

        app.permissions.ask = guarded_ask
        if args.execute:
            with raw_client(timeout=15) as client_http:
                available = client_http.get(args.base_url.rstrip("/") + "/models")
                available.raise_for_status()
                assert frozen["model"] in [m["id"] for m in available.json()["data"]]
        with patch("opencode.provider.httpx.Client", WireClient), \
             patch("opencode.provider.httpx.AsyncClient", WireAsyncClient):
            for index, question in enumerate(questions, 1):
                started = time.monotonic()
                if index == 2:
                    app.agents[app.default_agent].steps = default_steps
                result = app.prompt(sid, question)
                results.append({"question": question, "result": result, "seconds": time.monotonic() - started})
                (output / f"q{index}-answer.md").write_text(result.get("text") or "", encoding="utf-8")
                save(output / "result.json", {"session_id": sid, "turns": results, "model_calls": len(requests),
                                              "semantic_quality": "not_reviewed"})
                print(f"Q{index} delivered: {result.get('status')}", flush=True)
                if result.get("status") != "completed":
                    break
    except PreparedOnly:
        print("Offline restoration matches the saved arm; no tools or models executed.", flush=True)
    except Exception as error:
        save(output / "error.json", {"type": type(error).__name__, "message": str(error)})
        raise
    finally:
        store.close()
        save(output / "input-integrity.json", {
            "implementation_unchanged": all(hashlib.sha256((repository / p).read_bytes()).hexdigest() == h
                                            for p, h in implementation.items()),
            "input_files_unchanged": all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in originals.items()),
            "source_unchanged": hashes(source) == before,
            "copied_source_unchanged": all((workspace / p).is_file() and hashlib.sha256((workspace / p).read_bytes()).hexdigest() == h
                                           for p, h in before.items()),
        })
    print(str(output), flush=True)


if __name__ == "__main__":
    main()
