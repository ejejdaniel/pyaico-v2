"""Cut a saved research run back to one of its nodes, as a new run that can be continued.

    python scripts/fork_run.py --from outputs/<run> --at mindmap --output outputs/<checkpoint>

A node is the moment a record of a kind was saved (--at KIND, KIND:N for the N-th one, or
--at-record <hash prefix>). The new run holds the workspace and the conversation as they were right
after that record's tool call: later messages are dropped, the to-do list is the last one written
before the cut, and workspace files are taken from the snapshot the runner saved at that node, or,
for runs without one, files created after the cut are removed. Review skills written after the cut (at the
end of a round, opencode/round_review.py) are dropped too. Paths into the source run folder in the kept
messages point at the new one, so the continued run cannot find the source run's later work. The source run
is not changed.
Continue the checkpoint through the one entry, co-scientist <checkpoint> --continue --record <run> --prompt
<request> (run_stage.py does both).
A stage test is a development aid: an accepted result still needs one uninterrupted run.
"""

from __future__ import annotations

import argparse
from contextlib import closing
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3

COPIED = ("workspace", "state", "config", "data", "home", "cache", "temp")
FILES = ("settings.json", "runtime-manifest.json", "source-manifest.json", "original-request.txt",
         "meta-baseline.json")
PROJECT = Path(__file__).resolve().parents[1]
CURRENT_SKILLS = (PROJECT / "src" / "researchkit" / "skills", PROJECT / "src" / "planningkit" / "skills")


def refresh_skills(database: Path, installed: Path, current=CURRENT_SKILLS) -> list[str]:
    """Give each skill loaded before the cut the current version of its text.

    v34 loaded every skill in its first minutes, so a stage continued from its mind map would still
    read the old guidance in its own history. The skill tool's result is the SKILL.md body; this
    swaps the body the run installed for the current one, as if the run had loaded the current skill.
    """
    from opencode.config import _frontmatter
    bodies = {}
    for root in current:
        for path in Path(root).glob("*/SKILL.md"):
            meta, body = _frontmatter(path.read_text(encoding="utf-8"))
            if isinstance(meta.get("name"), str):
                bodies[meta["name"]] = body.strip()
    refreshed = []
    with closing(sqlite3.connect(database)) as connection:
        for key, data in connection.execute("SELECT id, data FROM message WHERE role = 'tool'").fetchall():
            value = json.loads(data)
            match = re.match(r'<skill_content name="([^"]+)">', value.get("content") or "")
            if value.get("name") != "skill" or not match or match.group(1) not in bodies:
                continue
            name = match.group(1)
            old_file = installed / name / "SKILL.md"
            if not old_file.is_file():
                continue
            old, new = _frontmatter(old_file.read_text(encoding="utf-8"))[1].strip(), bodies[name]
            if old == new or old not in value["content"]:
                continue
            value["content"] = value["content"].replace(old, new)
            metadata = value.get("metadata")
            if isinstance(metadata, dict) and isinstance(metadata.get("output"), str):
                metadata["output"] = metadata["output"].replace(old, new)
            connection.execute("UPDATE message SET data = ? WHERE id = ?", (json.dumps(value, ensure_ascii=False), key))
            refreshed.append(name)
        connection.commit()
    return refreshed


def _records(workspace: Path) -> list[tuple[float, str, str]]:
    """(saved at, kind, record path) of every record, in save order."""
    found = []
    for path in (workspace / ".research" / "records").glob("*/record.json"):
        if path.parent.name.startswith(".staging-"):
            continue
        kind = json.loads(path.read_text(encoding="utf-8")).get("kind")
        found.append((path.stat().st_mtime, kind, path.relative_to(workspace).as_posix()))
    return sorted(found)


def node_record(workspace: Path, at: str | None, record: str | None) -> tuple[float, str, str]:
    saved = _records(workspace)
    if record:
        matches = [item for item in saved if item[2].split("/")[2].startswith(record)]
        if len(matches) != 1:
            raise ValueError(f"--at-record {record} matches {len(matches)} records")
        return matches[0]
    kind, _, nth = at.partition(":")
    of_kind = [item for item in saved if item[1] == kind]
    index = int(nth or 1)
    if not 1 <= index <= len(of_kind):
        kinds = sorted({item[1] for item in saved})
        raise ValueError(f"The run has {len(of_kind)} {kind} record(s), not a #{index}; kinds saved: {', '.join(kinds)}")
    return of_kind[index - 1]


def _cut_index(rows, path: str) -> int:
    """Index of the last message to keep: the tool result that saved the record, and the other results
    of the same assistant turn."""
    folder = path.split("/")[2]
    hits = [i for i, (_, role, _, data) in enumerate(rows) if role == "tool" and folder in data]
    if not hits:
        raise ValueError(f"No tool result in the conversation mentions {path}")
    index = hits[0]
    while index + 1 < len(rows) and rows[index + 1][1] == "tool":
        index += 1
    return index


def _todos(kept) -> list[dict] | None:
    """The to-do list as the last todowrite call before the cut left it, or None when there was none."""
    latest = None
    for _, role, _, data in kept:
        if role != "assistant":
            continue
        for call in json.loads(data).get("tool_calls") or []:
            if call.get("name") == "todowrite":
                arguments = call.get("arguments")
                if isinstance(arguments, str):
                    arguments = json.loads(arguments)
                latest = (arguments or {}).get("todos") or []
    return latest


def cut_conversation(database: Path, path: str, original: Path | None = None, workspace: Path | None = None) -> dict:
    with closing(sqlite3.connect(database)) as connection:
        rows = connection.execute("SELECT id, role, created, data FROM message ORDER BY created, rowid").fetchall()
        index = _cut_index(rows, path)
        kept, dropped = rows[:index + 1], rows[index + 1:]
        connection.executemany("DELETE FROM message WHERE id = ?", [(row[0],) for row in dropped])
        todos = _todos(kept)
        if todos is not None or dropped:
            (session,), = connection.execute("SELECT id FROM session WHERE parent_id IS NULL").fetchall()
            connection.execute("DELETE FROM todo WHERE session_id = ?", (session,))
            for number, item in enumerate(todos or [], 1):
                connection.execute("INSERT INTO todo (session_id, todo_id, content, status, priority) VALUES (?, ?, ?, ?, ?)",
                                   (session, str(item.get("id") or number), item.get("content", ""),
                                    item.get("status", "pending"), item.get("priority")))
        for session, meta in connection.execute("SELECT id, meta FROM session").fetchall():
            value = json.loads(meta or "{}")
            if isinstance(value.get("read_files"), list) and original and workspace:
                # The edit-after-read rule must not see files that no longer exist at the cut.
                prefix = str(original).lower()
                value["read_files"] = [item for item in value["read_files"]
                                       if not item.lower().startswith(prefix)
                                       or (workspace / item[len(prefix):].lstrip("\\/")).exists()]
                connection.execute("UPDATE session SET meta = ? WHERE id = ?", (json.dumps(value), session))
        connection.commit()
    return {"messages_kept": len(kept), "messages_dropped": len(dropped), "cut_message": rows[index][0],
            "todos": len(todos or [])}


def relocate_conversation(database: Path, old: Path, new: Path) -> int:
    """Point the kept conversation at the checkpoint: each path into the source run folder (its workspace,
    its saved tool outputs), in any message or in the files read so far, becomes the same path in the new
    one. Returns how many messages changed.

    A stage run (2026-11-01) was compacted, took the source run's workspace from its own summary, read the
    finished delivery there that the source run made after the node, and reported it as its own."""
    pairs = [(str(old).replace("\\", "\\\\"), str(new).replace("\\", "\\\\")), (str(old), str(new)),
             (old.as_posix(), new.as_posix())]
    # Only the folder itself: run_v5 must not turn run_v50 into another path.
    patterns = [(re.compile(re.escape(before) + r"(?![\w.-])", re.I), after) for before, after in pairs]

    def swap(value):
        if isinstance(value, str):
            for pattern, after in patterns:
                value = pattern.sub(lambda _: after, value)
            return value
        if isinstance(value, list):
            return [swap(item) for item in value]
        if isinstance(value, dict):
            return {key: swap(item) for key, item in value.items()}
        return value

    changed = 0
    with closing(sqlite3.connect(database)) as connection:
        for key, data in connection.execute("SELECT id, data FROM message").fetchall():
            value = json.loads(data)
            moved = swap(value)
            if moved != value:
                connection.execute("UPDATE message SET data = ? WHERE id = ?", (json.dumps(moved, ensure_ascii=False), key))
                changed += 1
        for session, meta in connection.execute("SELECT id, meta FROM session").fetchall():
            value = json.loads(meta or "{}")
            if isinstance(value.get("read_files"), list):
                value["read_files"] = [swap(item).lower() if isinstance(item, str) else item
                                       for item in value["read_files"]]
                connection.execute("UPDATE session SET meta = ? WHERE id = ?", (json.dumps(value), session))
        connection.commit()
    return changed


def roll_back_workspace(workspace: Path, cut: float, original: Path) -> dict:
    """Without a node snapshot: remove what was created after the cut, and say what was only modified.

    Times come from the original run's files; the copies all carry the time of the copy.
    """
    removed, modified = [], []
    for path in sorted(workspace.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        if ".git" in path.relative_to(workspace).parts:
            continue
        info = (original / path.relative_to(workspace)).stat()
        if path.is_file() and info.st_ctime > cut:
            path.unlink()
            removed.append(path.relative_to(workspace).as_posix())
        elif path.is_dir() and info.st_ctime > cut and not any(path.iterdir()):
            path.rmdir()
        elif path.is_file() and info.st_mtime > cut:
            modified.append(path.relative_to(workspace).as_posix())
    log = workspace / ".opencode" / "executions.jsonl"
    if log.relative_to(workspace).as_posix() in modified:
        # Commands run after the cut did not happen in the checkpoint.
        from datetime import datetime
        lines = [line for line in log.read_text(encoding="utf-8").splitlines(keepends=True)
                 if not line.strip() or datetime.fromisoformat(json.loads(line)["time"]).timestamp() <= cut]
        log.write_text("".join(lines), encoding="utf-8")
        modified.remove(log.relative_to(workspace).as_posix())
    return {"removed_files": removed, "modified_after_cut": modified}


def roll_back_reviews(task: Path, cut: float) -> list[str]:
    """The task's review skills as they were at the cut (opencode/round_review.py). A version written after
    it holds lessons the run had not learned at the node, so it is dropped and the last earlier one restored."""
    dropped = []
    review = task / "review"
    for folder in sorted(path for path in review.iterdir() if path.is_dir()) if review.is_dir() else []:
        history = folder / "history"
        numbered = sorted((int(path.stem.split(".")[1]), path) for path in history.glob("SKILL.*.md")
                          if path.stem.split(".")[1].isdigit()) if history.is_dir() else []
        kept = []
        for number, path in numbered:
            if path.stat().st_mtime > cut:
                path.unlink()
                (history / f"lessons.{number}.json").unlink(missing_ok=True)
                dropped.append(path.relative_to(task).as_posix())
            else:
                kept.append((number, path))
        current = folder / "SKILL.md"
        if current.is_file() and current.stat().st_mtime > cut:
            current.unlink()
            (folder / "lessons.json").unlink(missing_ok=True)
            dropped.append(current.relative_to(task).as_posix())
            if kept:
                number, path = kept[-1]
                path.replace(current)
                if (history / f"lessons.{number}.json").is_file():
                    (history / f"lessons.{number}.json").replace(folder / "lessons.json")
            else:
                shutil.rmtree(folder)
    return dropped


def fork(source: Path, output: Path, *, at: str | None = None, record: str | None = None,
         current_skills=CURRENT_SKILLS) -> dict:
    """current_skills: folders whose skills replace those loaded before the cut; () keeps the old text."""
    source, output = source.resolve(), output.resolve()
    if not (source / "workspace").is_dir() or not (source / "state/opencode/opencode.db").is_file():
        raise ValueError(f"{source} has no saved workspace and state")
    if output.exists():
        raise ValueError(f"{output} already exists")
    cut, kind, path = node_record(source / "workspace", at, record)
    snapshot = source / "checkpoints" / path.split("/")[2] / "workspace"
    output.mkdir(parents=True)
    for name in COPIED:
        origin = snapshot if name == "workspace" and snapshot.is_dir() else source / name
        if origin.exists():
            shutil.copytree(origin, output / name, copy_function=shutil.copy2)
    for name in FILES:
        if (source / name).is_file():
            shutil.copy2(source / name, output / name)
    with closing(sqlite3.connect((source / "state/opencode/opencode.db").as_uri() + "?mode=ro", uri=True)) as connection:
        (session,), = connection.execute("SELECT id FROM session WHERE parent_id IS NULL").fetchall()
    workspace = ({"removed_files": [], "modified_after_cut": [], "from_snapshot": str(snapshot)}
                 if snapshot.is_dir() else roll_back_workspace(output / "workspace", cut, source / "workspace"))
    conversation = cut_conversation(output / "state/opencode/opencode.db", path, source / "workspace",
                                    output / "workspace")
    conversation["messages_relocated"] = relocate_conversation(output / "state/opencode/opencode.db", source, output)
    refreshed = refresh_skills(output / "state/opencode/opencode.db", source / "workspace" / ".opencode" / "skills",
                               current_skills) if current_skills else []
    reviews = roll_back_reviews(output / "state/opencode/task" / session, cut)
    summary = {"forked_from": str(source), "node": {"kind": kind, "record": path,
               "minutes": round((cut - os.path.getctime(source)) / 60, 1)},
               "session_id": session, **conversation, "skills_refreshed": refreshed,
               "reviews_dropped": reviews, **workspace}
    # A recorded continuation (scripts/recording.py) reads the session to continue from continuation.json.
    (output / "continuation.json").write_text(json.dumps({"session_id": session, "fork": summary}, ensure_ascii=False,
                                                         indent=2), encoding="utf-8")
    (output / "fork.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--from", dest="source", type=Path, required=True, help="a saved run folder")
    where = parser.add_mutually_exclusive_group(required=True)
    where.add_argument("--at", help="record kind of the node, optionally :N for the N-th (mindmap, history_check:2)")
    where.add_argument("--at-record", help="hash prefix of the node record")
    parser.add_argument("--output", type=Path, required=True, help="new checkpoint folder")
    parser.add_argument("--keep-old-skills", action="store_true",
                        help="leave the skill text the run loaded before the cut as it was")
    args = parser.parse_args(argv)
    summary = fork(args.source, args.output, at=args.at, record=args.at_record,
                   current_skills=() if args.keep_old_skills else CURRENT_SKILLS)
    print(json.dumps({key: value for key, value in summary.items() if key != "removed_files"}, ensure_ascii=False, indent=2))
    print(f"removed {len(summary['removed_files'])} files created after the cut")
    if summary["modified_after_cut"]:
        print("WARNING: these files were changed after the cut and could not be rolled back: "
              + ", ".join(summary["modified_after_cut"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
