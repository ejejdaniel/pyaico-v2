"""Authoritative model configuration for managed research runners and the TUI launcher.

These helpers do not change Common's loader or persist a separate configuration
schema. Importing this module does not import Common or capture its environment.
The selection and audit fields below exist only for the current invocation.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import re
from types import SimpleNamespace
from urllib.parse import urlsplit, urlunsplit


MODEL_FIELDS = ("model", "provider", "enabled_providers", "disabled_providers")
AGENT_FIELDS = ("model", "temperature")
BUILTIN_AGENTS = ("build", "plan", "general", "explore", "compaction", "title", "summary")
_MISSING = object()


@dataclass(frozen=True)
class LLMSelection:
    config: dict
    source: str
    directory: Path
    resume: bool
    model_override: str | None
    base_url: str | None
    switch_model: bool
    messages: tuple[str, ...]


@dataclass(frozen=True)
class EffectiveConfiguration:
    config: dict
    saved_config: dict
    source: str
    messages: tuple[str, ...]


def _object(value, path: str) -> dict:
    if not isinstance(value, dict):
        raise ValueError(f"{path} must be an object")
    return value


def _model_reference(value, path: str) -> tuple[str, str]:
    if not isinstance(value, str) or "/" not in value:
        raise ValueError(f"{path} must use provider/model")
    provider, model = value.split("/", 1)
    if not provider.strip() or not model.strip():
        raise ValueError(f"{path} must use nonempty provider/model")
    return provider, model


def validate_llm_fragment(config: dict) -> None:
    """Check the approved fragment shape without importing environment consumers."""
    _object(config, "LLM configuration")
    unknown = set(config) - {*MODEL_FIELDS, "agent"}
    if unknown:
        raise ValueError(f"Unsupported LLM configuration keys: {', '.join(sorted(unknown))}")
    if "model" not in config or "provider" not in config:
        raise ValueError("LLM configuration requires model and provider")
    references = [("model", config["model"])]
    providers = _object(config["provider"], "provider")
    for name, provider in providers.items():
        _object(provider, f"provider.{name}")
        if "options" in provider:
            _object(provider["options"], f"provider.{name}.options")
        definitions = _object(provider.get("models", {}), f"provider.{name}.models")
        for model, definition in definitions.items():
            _object(definition, f"provider.{name}.models.{model}")
            for field in ("options", "limit"):
                if field in definition:
                    _object(definition[field], f"provider.{name}.models.{model}.{field}")
    for key in ("enabled_providers", "disabled_providers"):
        if key in config and (not isinstance(config[key], list)
                              or any(not isinstance(item, str) for item in config[key])):
            raise ValueError(f"{key} must be an array of provider names")
    agents = _object(config.get("agent", {}), "agent")
    for name, agent in agents.items():
        _object(agent, f"agent.{name}")
        unknown = set(agent) - set(AGENT_FIELDS)
        if unknown:
            raise ValueError(f"Unsupported agent.{name} keys: {', '.join(sorted(unknown))}")
        if "model" in agent:
            references.append((f"agent.{name}.model", agent["model"]))
        temperature = agent.get("temperature")
        if temperature is not None and (
            isinstance(temperature, bool) or not isinstance(temperature, (int, float))
            or not math.isfinite(temperature)
        ):
            raise ValueError(f"agent.{name}.temperature must be a finite number or omitted")
    for path, reference in references:
        provider, model = _model_reference(reference, path)
        if provider not in providers or model not in providers[provider].get("models", {}):
            raise ValueError(f"{path} references {reference!r}, which needs its own explicit provider model definition")
        if provider in config.get("disabled_providers", []):
            raise ValueError(f"{path} references disabled provider {provider!r}")
        if config.get("enabled_providers") and provider not in config["enabled_providers"]:
            raise ValueError(f"{path} references provider {provider!r} outside enabled_providers")


def _managed_fields(config: dict) -> dict:
    result = {key: deepcopy(config[key]) for key in MODEL_FIELDS if key in config}
    agents = _object(config.get("agent", {}), "agent")
    result["agent"] = {
        name: {key: deepcopy(raw[key]) for key in AGENT_FIELDS if key in raw}
        for name, raw in agents.items() if isinstance(raw, dict)
        and any(key in raw for key in AGENT_FIELDS)
    }
    return result


def public_endpoint_url(value: str) -> str:
    """Return an endpoint suitable for logs, without URL-carried credentials."""
    parts = urlsplit(value)
    return urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[-1], parts.path, "", ""))


def _safe_value(value, path: str) -> str:
    if value is _MISSING:
        return "<未指定>"
    sensitive = ("apikey", "api_key", "authorization", "credential", "password", "secret", "token", "headers")
    if any(marker in path.lower() for marker in sensitive):
        return "<已遮蔽>"
    if isinstance(value, str) and "://" in value:
        parts = urlsplit(value)
        # Endpoints can contain embedded credentials or signed query parameters.
        if parts.username or parts.password or parts.query or parts.fragment:
            value = public_endpoint_url(value) + " <敏感網址部分已遮蔽>"
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def configuration_changes(before: dict, after: dict, *, before_source: str, after_source: str) -> list[str]:
    """Describe every owned leaf changed/removed, without dumping credentials."""
    changes = []

    def visit(old, new, path):
        if isinstance(old, dict) or isinstance(new, dict):
            old_items = old if isinstance(old, dict) else {}
            new_items = new if isinstance(new, dict) else {}
            for key in sorted(set(old_items) | set(new_items)):
                visit(old_items.get(key, _MISSING), new_items.get(key, _MISSING),
                      f"{path}.{key}" if path else key)
            return
        if old != new:
            changes.append(f"{path}: {_safe_value(old, path)} ({before_source}) -> "
                           f"{_safe_value(new, path)} ({after_source})")

    visit(_managed_fields(before), _managed_fields(after), "")
    return changes


def _preserve_placeholders(config: dict, directory: Path, saved_directory: Path) -> None:
    """Keep file references meaningful when the snapshot lives in another folder."""
    def relocate_file(match):
        path = Path(match[1]).expanduser()
        absolute = (directory / path).resolve() if not path.is_absolute() else path
        try:
            reference = os.path.relpath(absolute, saved_directory)
        except ValueError:  # Different Windows drives require an absolute path.
            reference = str(absolute)
        if "}" in reference:
            raise ValueError("A file placeholder cannot be preserved at the saved location: its path contains '}'")
        return "{file:" + reference + "}"

    def visit(value):
        if isinstance(value, dict):
            return {key: visit(item) for key, item in value.items()}
        if isinstance(value, list):
            return [visit(item) for item in value]
        if isinstance(value, str):
            return re.sub(r"\{file:([^}]+)\}", relocate_file, value)
        return value

    config.update(visit(config))


def _sanitize_recorded_config(config: dict, messages: list[str], path: str = "") -> None:
    for key in list(config):
        value = config[key]
        child_path = f"{path}.{key}" if path else key
        if key.lower() == "apikey" and not (
            isinstance(value, str) and re.fullmatch(r"\{(?:env|file):[^}]+\}", value)
        ):
            del config[key]
            messages.append(f"{child_path} 的明文憑證未保存；續跑需重新提供相同來源設定檔，"
                            "或使用既有環境／AuthStore 憑證。")
        elif key.lower() == "baseurl" and isinstance(value, str) and not re.fullmatch(
            r"\{(?:env|file):[^}]+\}", value
        ):
            public_url = public_endpoint_url(value)
            if public_url != value:
                config[key] = public_url
                messages.append(f"{child_path} 原網址的帳密、查詢參數及片段未保存；"
                                "續跑需明確提供原設定來源，或由環境／檔案引用提供完整網址。")
        elif isinstance(value, dict):
            _sanitize_recorded_config(value, messages, child_path)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                if isinstance(item, dict):
                    _sanitize_recorded_config(item, messages, f"{child_path}[{index}]")


def select_llm_configuration(
    default_path: Path, *, llm_config: Path | None = None,
    saved_config: dict | None = None, saved_source: str | Path | None = None,
    resume: bool = False, model: str | None = None, base_url: str | None = None,
) -> LLMSelection:
    """Select fresh/saved authority; legacy overrides never invent model definitions."""
    if llm_config is not None and (model is not None or base_url is not None):
        raise ValueError("--llm-config conflicts with --model and --base-url; edit the selected file instead")
    messages = []
    if resume and llm_config is None:
        if not isinstance(saved_config, dict):
            raise ValueError("Saved settings.json.config is missing or malformed; explicitly provide --llm-config")
        config = _managed_fields(saved_config)
        source = str(saved_source or "settings.json.config")
        directory = Path(saved_source).resolve().parent if saved_source else Path.cwd()
    else:
        path = Path(llm_config if llm_config is not None else default_path).resolve()
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"Unable to read UTF-8 JSON LLM configuration {path}: {exc}") from exc
        source, directory = str(path), path.parent
        if resume and not isinstance(saved_config, dict):
            messages.append("舊 settings.json.config 缺失或格式不正確；無法由該檔證實舊模型設定，本次採明確指定檔案。")
    validate_llm_fragment(config)
    before_override = deepcopy(config)
    if model is not None:
        if not isinstance(model, str) or not model.strip():
            raise ValueError("--model must be a nonempty API model name")
        config["model"] = "local/" + model
        validate_llm_fragment(config)
    if base_url is not None:
        if not isinstance(base_url, str) or not base_url.strip():
            raise ValueError("--base-url must be a nonempty URL")
    messages.extend(configuration_changes(before_override, config, before_source=source,
                                          after_source="明確舊參數覆寫"))
    if resume and llm_config is not None and isinstance(saved_config, dict):
        messages.extend(configuration_changes(saved_config, config,
                                              before_source=str(saved_source or "settings.json.config"),
                                              after_source=source))
    switch_model = not resume or llm_config is not None or model is not None
    messages.insert(0, f"模型設定來源：{source}；{'本次明確選擇根會話模型' if switch_model else '沿用既有會話模型選擇'}。")
    return LLMSelection(config, source, directory, resume, model, base_url, switch_model, tuple(messages))


def compose_llm_configuration(workspace_config: dict, selection: LLMSelection, *,
                              saved_directory: Path | None = None, root_agent: str | None = None,
                              session_model: str | None = None) -> EffectiveConfiguration:
    """Overlay only the approved authoritative fields, before App construction."""
    from opencode.config import _substitute, validate_config
    from opencode.provider import Client

    _object(workspace_config, "Workspace configuration")
    validate_llm_fragment(selection.config)
    saved = deepcopy(workspace_config)
    for key in MODEL_FIELDS:
        saved.pop(key, None)
        if key in selection.config:
            saved[key] = deepcopy(selection.config[key])
    agents = _object(saved.setdefault("agent", {}), "agent")
    for raw in agents.values():
        if isinstance(raw, dict):
            for key in AGENT_FIELDS:
                raw.pop(key, None)
    for name, raw in selection.config.get("agent", {}).items():
        if name not in agents:
            agents[name] = {}
        _object(agents[name], f"agent.{name}").update(deepcopy(raw))
    # Resolve the selected fragment only. Workspace values have already passed
    # through Common's normal loader and must not be substituted a second time.
    resolved_fragment = json.loads(_substitute(json.dumps(selection.config, ensure_ascii=False), selection.directory))
    validate_llm_fragment(resolved_fragment)
    effective = deepcopy(saved)
    for key in MODEL_FIELDS:
        if key in resolved_fragment:
            effective[key] = resolved_fragment[key]
    for name, raw in resolved_fragment.get("agent", {}).items():
        effective["agent"][name].update(raw)
    messages = list(selection.messages)
    chosen_model = None
    if selection.base_url is not None:
        if root_agent is None:
            from opencode.agent import build_agents, default_agent_name

            root_agent = default_agent_name(effective, build_agents(effective, worktree=selection.directory))
        chosen_model = (explicit_root_model(effective, selection, root_agent)
                        or effective["agent"].get(root_agent, {}).get("model")
                        or session_model or effective["model"])
        provider_id, _ = _model_reference(chosen_model, "Selected root model")
        options = effective["provider"].get(provider_id, {}).get("options", {})
        if "baseURL" not in options:
            raise ValueError(f"--base-url for {chosen_model!r} requires existing provider.{provider_id}.options.baseURL")
        before_url = deepcopy(effective)
        options["baseURL"] = selection.base_url
        saved["provider"][provider_id]["options"]["baseURL"] = selection.base_url
        messages.extend(configuration_changes(before_url, effective, before_source=selection.source,
                                              after_source="明確 --base-url 覆寫"))
        affected = [name for name, raw in effective["agent"].items()
                    if isinstance(raw, dict) and raw.get("model", "").startswith(provider_id + "/")]
        models = ", ".join(effective["provider"][provider_id].get("models", {}))
        messages.append(f"--base-url 依本次根角色 {root_agent} 選用的 {chosen_model}，覆寫 "
                        f"provider.{provider_id}.options.baseURL；同 provider 模型共用此網址：{models}；"
                        f"明訂該 provider 的角色：{', '.join(affected) or '無'}。")
    validate_config(effective)
    client = Client(SimpleNamespace(get=lambda _: None), effective)
    references = [effective["model"]] + [raw["model"] for raw in effective["agent"].values()
                                           if isinstance(raw, dict) and raw.get("model")]
    if chosen_model:
        references.append(chosen_model)
    for reference in dict.fromkeys(references):
        provider, model = client.resolve(reference)  # Explicit reference bypasses OPENCODE_MODEL.
        client.output_limit(provider, model)  # Both operations are offline, without catalog or credentials.
    messages.extend(configuration_changes(workspace_config, saved, before_source="正常合併後的工作區／環境設定",
                                          after_source=selection.source))
    for name in sorted(set(BUILTIN_AGENTS) | set(agents)):
        raw = agents.get(name, {})
        temperature = raw.get("temperature") if isinstance(raw, dict) else None
        messages.append(f"agent.{name}.temperature：{temperature if temperature is not None else '未指定；依 Common 預設'}。")
    # The runtime copy keeps real credentials. The existing settings.config
    # snapshot keeps expressions only; it never acquires a cleartext API key.
    _preserve_placeholders(saved, selection.directory,
                           Path(saved_directory).resolve() if saved_directory else selection.directory)
    _sanitize_recorded_config(saved, messages)
    return EffectiveConfiguration(effective, saved, selection.source, tuple(messages))


def saved_llm_config(base_url=None, model=None) -> dict:
    """The model configuration a run saves (its settings.json "config"), from this installation's shared file."""
    selection = select_llm_configuration(
        Path(__file__).resolve().parents[1] / "config/llm.opencode.json", base_url=base_url, model=model)
    return compose_llm_configuration({}, selection).saved_config


def explicit_root_model(config: dict, selection: LLMSelection, root_agent: str) -> str | None:
    """Return the existing explicit prompt argument, or preserve resumed selection."""
    if not selection.switch_model:
        return None
    if selection.model_override is not None:
        return "local/" + selection.model_override
    return (config.get("agent", {}).get(root_agent, {}).get("model") or config["model"])
