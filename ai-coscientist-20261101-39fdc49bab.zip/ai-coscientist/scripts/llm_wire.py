"""Runner-scoped observation of model HTTP requests, without provider changes.

Use ``with WireRecorder(output, endpoints=model_endpoints(client))`` around the
whole runner. The patch covers clients created by child agents and local tools,
including the asynchronous clients used by Common's cancellation path. Only
POSTs to explicitly resolved model endpoints are recorded; transport selection,
timeouts, retries, response decoding and cancellation remain httpx's work.
"""
from __future__ import annotations

from contextlib import ExitStack
from datetime import datetime, timezone
import errno as errno_codes
import json
from pathlib import Path
import threading
import time
from unittest.mock import patch

import httpx


_CONTEXT_LOCK = threading.Lock()
_REQUEST_HEADERS = {"content-type", "content-length", "accept", "accept-encoding", "user-agent"}
_RESPONSE_HEADERS = {"content-type", "content-length", "content-encoding", "transfer-encoding",
                     "date", "server", "retry-after", "x-request-id", "request-id"}


def model_endpoints(client) -> set[str]:
    """Use the provider URLs already assembled by the actual configured client."""
    return {provider.base_url.rstrip("/") + ("/messages" if provider.api == "anthropic"
                                             else "/chat/completions")
            for provider in client.providers.values() if provider.base_url}


def _endpoint(url: str | httpx.URL) -> tuple:
    parsed = httpx.URL(url)
    # Credentials and query parameters do not identify the model API route.
    return parsed.scheme, parsed.host, parsed.port, parsed.path


def _public_url(url: httpx.URL) -> str:
    # Do not store userinfo or query values: either may contain credentials.
    return str(url.copy_with(username=None, password=None, query=None, fragment=None))


def _save(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# Windows socket codes; the descriptions are ours, never the system's message text.
_WINSOCK = {  # winerror -> (name, our description)
    10050: ("WSAENETDOWN", "the local network is down"),
    10051: ("WSAENETUNREACH", "no route to the network"),
    10053: ("WSAECONNABORTED", "the connection was aborted on this machine"),
    10054: ("WSAECONNRESET", "the peer reset the connection"),
    10060: ("WSAETIMEDOUT", "no reply to the connection attempt before the system gave up"),
    10061: ("WSAECONNREFUSED", "the host answered but nothing accepts connections on that port"),
    10064: ("WSAEHOSTDOWN", "the host is down"),
    10065: ("WSAEHOSTUNREACH", "no route to the host"),
    11001: ("WSAHOST_NOT_FOUND", "the host name did not resolve"),
    11002: ("WSATRY_AGAIN", "temporary name resolution failure"),
    11004: ("WSANO_DATA", "the host name has no address"),
    # Windows system codes from asyncio's Proactor (ConnectEx) path, where Python's
    # errno is a generic EINVAL; trust winerror there.
    64: ("ERROR_NETNAME_DELETED", "the connection was dropped by the network or the peer"),
    121: ("ERROR_SEM_TIMEOUT", "no reply to the connection attempt before the system gave up"),
    1225: ("ERROR_CONNECTION_REFUSED", "the host answered but nothing accepts connections on that port"),
    1231: ("ERROR_NETWORK_UNREACHABLE", "no route to the network"),
    1232: ("ERROR_HOST_UNREACHABLE", "no route to the host"),
    1236: ("ERROR_CONNECTION_ABORTED", "the connection was aborted on this machine"),
}
_POSIX = {
    "ECONNREFUSED": "the host answered but nothing accepts connections on that port",
    "ETIMEDOUT": "no reply before the system gave up",
    "EHOSTUNREACH": "no route to the host",
    "ENETUNREACH": "no route to the network",
    "ECONNRESET": "the peer reset the connection",
    "ECONNABORTED": "the connection was aborted",
    "EPIPE": "the connection was closed while sending",
}


def _chain(error: BaseException) -> list[BaseException]:
    """The exception and its causes, outermost first (httpx -> httpcore -> OSError)."""
    seen, found, current = set(), [], error
    while current is not None and id(current) not in seen and len(found) < 12:
        seen.add(id(current))
        found.append(current)
        current = current.__cause__ or current.__context__
    return found


def _os_error(error: BaseException) -> dict | None:
    """Codes of the innermost OSError, without its message, filename or arguments."""
    inner = next((e for e in reversed(_chain(error)) if isinstance(e, OSError)), None)
    if inner is None:
        return None
    winerror = getattr(inner, "winerror", None)
    code = inner.errno if isinstance(inner.errno, int) else None
    name = errno_codes.errorcode.get(code) if code is not None else None
    detail = {"type": type(inner).__name__, "errno": code, "errno_name": name,
              "winerror": winerror if isinstance(winerror, int) else None}
    known = _WINSOCK.get(detail["winerror"]) if detail["winerror"] is not None else _WINSOCK.get(code)
    if known:
        detail["winerror_name"], detail["meaning"] = known
        if detail["winerror"] is not None and code != detail["winerror"]:
            detail["errno_note"] = "errno is Python's generic mapping of this Windows code; read winerror"
    elif name in _POSIX:
        detail["meaning"] = _POSIX[name]
    elif isinstance(inner, TimeoutError) and code is None:
        detail["meaning"] = "a timeout set by the client expired"
    return detail


class _ResponseRecord:
    def __init__(self, folder: Path):
        self.folder = folder
        self.complete = self.closed = False
        self.raw_bytes = 0
        self.lock = threading.RLock()
        self.started = time.monotonic()
        self.timing = {"started_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                       "response_headers_after_s": None, "first_chunk_after_s": None,
                       "last_chunk_after_s": None, "failed_after_s": None, "closed_after_s": None}
        (folder / "response.raw.bin").touch(exist_ok=False)
        self.record()

    def elapsed(self) -> float:
        return round(time.monotonic() - self.started, 3)

    def mark(self, key: str, *, once: bool = False) -> None:
        with self.lock:
            if once and self.timing[key] is not None:
                return
            self.timing[key] = self.elapsed()
            _save(self.folder / "timing.json", self.timing)

    def record(self) -> None:
        with self.lock:
            _save(self.folder / "response-stream.json", {
                "complete": self.complete, "closed": self.closed, "raw_bytes": self.raw_bytes})

    def chunk(self, chunk: bytes) -> None:
        with self.lock:
            with (self.folder / "response.raw.bin").open("ab") as output:
                output.write(chunk)
            self.raw_bytes += len(chunk)
            self.mark("first_chunk_after_s", once=True)
            self.mark("last_chunk_after_s")
            self.record()

    def fail(self, error: BaseException, phase: str = "request") -> None:
        # Exception messages/tracebacks may repeat an auth header or signed URL,
        # so only class names, numeric OS codes and our own descriptions are kept.
        # The original exception is re-raised unchanged.
        with self.lock:
            with (self.folder / "error.txt").open("a", encoding="utf-8") as output:
                output.write(type(error).__name__ + "\n")
            self.mark("failed_after_s")
            path = self.folder / "error.json"
            entries = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
            entries.append({"type": type(error).__name__, "chain": [type(e).__name__ for e in _chain(error)],
                            "phase": phase, "elapsed_s": self.timing["failed_after_s"],
                            "raw_bytes_before_error": self.raw_bytes, "os_error": _os_error(error)})
            _save(path, entries)
            self.record()


class _SyncStream(httpx.SyncByteStream):
    def __init__(self, inner, record):
        self.inner, self.record = inner, record

    def __iter__(self):
        try:
            for chunk in self.inner:
                self.record.chunk(chunk)
                yield chunk
            self.record.complete = True
        except GeneratorExit:
            raise
        except BaseException as error:
            self.record.fail(error, "stream")
            raise
        finally:
            self.record.record()

    def close(self):
        try:
            self.inner.close()
        except BaseException as error:
            self.record.fail(error, "close")
            raise
        finally:
            self.record.closed = True
            self.record.mark("closed_after_s")
            self.record.record()


class _AsyncStream(httpx.AsyncByteStream):
    def __init__(self, inner, record):
        self.inner, self.record = inner, record

    async def __aiter__(self):
        try:
            async for chunk in self.inner:
                self.record.chunk(chunk)
                yield chunk
            self.record.complete = True
        except GeneratorExit:
            raise
        except BaseException as error:
            self.record.fail(error, "stream")
            raise
        finally:
            self.record.record()

    async def aclose(self):
        try:
            await self.inner.aclose()
        except BaseException as error:
            self.record.fail(error, "close")
            raise
        finally:
            self.record.closed = True
            self.record.mark("closed_after_s")
            self.record.record()


class _SyncTransport(httpx.BaseTransport):
    def __init__(self, inner, recorder):
        self.inner, self.recorder = inner, recorder

    def handle_request(self, request):
        record = self.recorder.begin(request)
        if record is None:
            return self.inner.handle_request(request)
        try:
            response = self.inner.handle_request(request)
        except BaseException as error:
            record.fail(error)
            raise
        self.recorder.received(record, response, _SyncStream)
        return response


class _AsyncTransport(httpx.AsyncBaseTransport):
    def __init__(self, inner, recorder):
        self.inner, self.recorder = inner, recorder

    async def handle_async_request(self, request):
        record = self.recorder.begin(request)
        if record is None:
            return await self.inner.handle_async_request(request)
        try:
            response = await self.inner.handle_async_request(request)
        except BaseException as error:
            record.fail(error)
            raise
        self.recorder.received(record, response, _AsyncStream)
        return response


class WireRecorder:
    """Capture existing wire-* artifacts within one process-wide runner context.

    HTTP model payloads are the buffered JSON requests produced by the provider.
    This observer never reads ahead on a network response. It also supports
    MockTransport's already-buffered ByteStream responses without substituting
    decoded ``response.content`` for raw bytes. Contexts must not overlap;
    requests within one context can run concurrently on multiple threads.
    """

    def __init__(self, output: str | Path, *, endpoints):
        self.output = Path(output)
        self.endpoints = {_endpoint(url) for url in endpoints}
        self.count = 0
        self._number = 0
        self._lock = threading.Lock()
        self._stack = None

    def __enter__(self):
        if not _CONTEXT_LOCK.acquire(blocking=False):
            raise RuntimeError("WireRecorder contexts must not overlap")
        stack = ExitStack()
        try:
            self.output.mkdir(parents=True, exist_ok=True)
            sync_select = httpx.Client._transport_for_url
            async_select = httpx.AsyncClient._transport_for_url

            def select_sync(client, url):
                return _SyncTransport(sync_select(client, url), self)

            def select_async(client, url):
                return _AsyncTransport(async_select(client, url), self)

            stack.enter_context(patch.object(httpx.Client, "_transport_for_url", select_sync))
            stack.enter_context(patch.object(httpx.AsyncClient, "_transport_for_url", select_async))
        except BaseException:
            stack.close()
            _CONTEXT_LOCK.release()
            raise
        self._stack = stack
        return self

    def __exit__(self, *exc):
        try:
            return self._stack.__exit__(*exc)
        finally:
            self._stack = None
            _CONTEXT_LOCK.release()

    def begin(self, request: httpx.Request):
        if request.method != "POST" or _endpoint(request.url) not in self.endpoints:
            return None
        # Do not decode/re-encode JSON: whitespace and byte representation are
        # part of the evidence. Common sends buffered JSON request bodies.
        body = request.content
        with self._lock:
            while True:
                self._number += 1
                folder = self.output / f"wire-{self._number:03}"
                try:
                    folder.mkdir()
                    break
                except FileExistsError:
                    continue
            self.count += 1
            (folder / "request.body.json").write_bytes(body)
            _save(folder / "request-http.json", {
                "method": request.method, "url": _public_url(request.url),
                "headers": {k: v for k, v in request.headers.items() if k.lower() in _REQUEST_HEADERS},
                "credential_headers_saved": False,
            })
            (folder / "network-attempt.started").touch(exist_ok=False)
            return _ResponseRecord(folder)

    def received(self, record, response, stream_type):
        record.mark("response_headers_after_s")
        _save(record.folder / "response-http.json", {
            "status_code": response.status_code,
            "headers": {k: v for k, v in response.headers.items() if k.lower() in _RESPONSE_HEADERS},
        })
        if response.is_stream_consumed and isinstance(response.stream, httpx.ByteStream):
            # A buffered MockTransport response has already been consumed in
            # memory. ByteStream retains its exact original (possibly encoded)
            # bytes, and replaying it does not consume any network or alter the
            # response's consumed/closed state.
            for chunk in response.stream:
                record.chunk(chunk)
            record.complete, record.closed = True, response.is_closed
            record.record()
        else:
            response.stream = stream_type(response.stream, record)
