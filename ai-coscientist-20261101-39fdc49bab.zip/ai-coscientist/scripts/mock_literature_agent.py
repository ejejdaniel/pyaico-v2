"""Mock A2A literature agent for offline development and tests. NOT a real data source.

Stands in for the organisation's literature agent until its real API is available.
It speaks A2A 0.3 JSON-RPC over HTTP (agent card, message/send, tasks/get,
tasks/cancel), splits a question into sub-questions, matches them against a small
SYNTHETIC corpus and returns a synthesis with references. Everything it returns is
labelled MOCK. The corpus avoids the topics of the acceptance cases on purpose.

Markers in the query select behaviours for tests:
  [mock:fail]     the task fails
  [mock:clarify]  the agent asks for more input (answer with the same taskId)
  [mock:slow]     the task never finishes (timeout and cancel)
  [mock:direct]   the agent answers with a message instead of a task

    python scripts/mock_literature_agent.py --port 8765
"""

from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import re
import threading
import uuid


CORPUS = [
    {"id": "MOCK-DOC-001", "title": "Ionic conductivity of a synthetic polymer electrolyte versus temperature",
     "authors": ["A. Example"], "year": 2021, "source": "internal report (mock)",
     "abstract": "Conductivity rose about tenfold between 20 and 60 C. Above 70 C the film softened and the "
                 "measurement became unstable.",
     "keywords": ["electrolyte", "conductivity", "temperature", "polymer"]},
    {"id": "MOCK-DOC-002", "title": "Salt concentration and conductivity in mock electrolyte films",
     "authors": ["B. Placeholder", "C. Sample"], "year": 2022, "source": "internal report (mock)",
     "abstract": "Conductivity peaked at an intermediate salt concentration; higher loading caused ion pairing "
                 "and lower conductivity.",
     "keywords": ["electrolyte", "salt", "concentration", "conductivity"]},
    {"id": "MOCK-DOC-003", "title": "Coke formation on a synthetic zeolite catalyst",
     "authors": ["D. Example"], "year": 2019, "source": "internal report (mock)",
     "abstract": "Coke deposits grew with time on stream and reduced activity by half after 40 hours. Oxidative "
                 "regeneration recovered most of the activity.",
     "keywords": ["catalyst", "zeolite", "coke", "deactivation", "regeneration"]},
    {"id": "MOCK-DOC-004", "title": "Cure time of a mock epoxy adhesive at different humidity",
     "authors": ["E. Placeholder"], "year": 2020, "source": "internal report (mock)",
     "abstract": "Higher humidity shortened gel time but lowered final lap-shear strength by about 15 percent.",
     "keywords": ["adhesive", "epoxy", "cure", "humidity", "strength"]},
    {"id": "MOCK-DOC-005", "title": "Corrosion inhibitor dose and steel corrosion rate in a test loop",
     "authors": ["F. Sample"], "year": 2018, "source": "internal report (mock)",
     "abstract": "Corrosion rate fell with inhibitor dose up to a plateau; beyond it extra inhibitor gave no "
                 "further benefit.",
     "keywords": ["corrosion", "inhibitor", "dose", "steel"]},
    {"id": "MOCK-DOC-006", "title": "Cathode particle size and rate capability in mock cells",
     "authors": ["G. Example", "H. Placeholder"], "year": 2023, "source": "external paper (mock)",
     "abstract": "Smaller particles improved rate capability but increased side reactions and capacity fade.",
     "keywords": ["cathode", "particle", "size", "rate", "battery", "fade"]},
]
MARKER = re.compile(r"\[mock:(fail|clarify|slow|direct)\]")
POLLS_BEFORE_DONE = 1


def _words(text):
    return set(re.findall(r"[a-z]{3,}", text.lower()))


def decompose(query):
    text = MARKER.sub("", query)
    parts = [p.strip(" .,") for p in re.split(r"\?|;|\band\b|、|，|；|？", text) if p.strip(" .,")]
    return parts[:4] or [text.strip()]


def search(question, limit=2):
    words = _words(question)
    scored = []
    for doc in CORPUS:
        overlap = len(words & (_words(doc["title"] + " " + doc["abstract"]) | set(doc["keywords"])))
        if overlap:
            scored.append((overlap, doc["id"], doc))
    return [doc for _, _, doc in sorted(scored, key=lambda s: (-s[0], s[1]))[:limit]]


def answer(query):
    sub_questions = decompose(query)
    lines, references = ["[MOCK SYNTHESIS: synthetic data for interface testing, not real literature]"], {}
    for question in sub_questions:
        found = search(question)
        if not found:
            lines.append(f"- {question}: no matching documents in the mock corpus.")
            continue
        for doc in found:
            references[doc["id"]] = {k: doc[k] for k in ("id", "title", "authors", "year", "source")}
        lines.append(f"- {question}: " + " ".join(
            f"{doc['abstract'].split('.')[0]} [{doc['id']}]." for doc in found))
    return [{"artifactId": uuid.uuid4().hex, "name": "synthesis", "parts": [
        {"kind": "text", "text": "\n".join(lines)},
        {"kind": "data", "data": {"sub_questions": sub_questions, "references": list(references.values())}}]}]


class MockAgent:
    def __init__(self):
        self.tasks = {}
        self.lock = threading.Lock()
        self.url = None

    def card(self):
        return {"name": "Mock Enterprise Literature Agent (MOCK)", "version": "0.0-mock",
                "description": "Synthetic stand-in for the organisation's literature agent. Not a real source.",
                "url": self.url, "protocolVersion": "0.3.0", "preferredTransport": "JSONRPC",
                "capabilities": {"streaming": False, "pushNotifications": False},
                "defaultInputModes": ["text/plain"], "defaultOutputModes": ["text/plain", "application/json"],
                "skills": [{"id": "literature-synthesis", "name": "Literature synthesis",
                            "description": "Decompose a question, search literature, summarise with references.",
                            "tags": ["literature", "mock"]}]}

    def _status(self, state, text=None):
        status = {"state": state}
        if text:
            status["message"] = {"kind": "message", "role": "agent", "messageId": uuid.uuid4().hex,
                                 "parts": [{"kind": "text", "text": text}]}
        return status

    def send(self, params):
        message = params.get("message") or {}
        query = " ".join(p.get("text", "") for p in message.get("parts") or [] if p.get("kind") == "text")
        context = message.get("contextId") or uuid.uuid4().hex
        marker = MARKER.search(query)
        mode = marker.group(1) if marker else None
        with self.lock:
            if message.get("taskId") in self.tasks:
                task = self.tasks[message["taskId"]]
                original = task.pop("_query")
                task["_query"] = original + " " + query
                task["_mode"], task["_polls"] = None, 0
                task["status"] = self._status("working")
                return self._public(task)
            if mode == "direct":
                return {"kind": "message", "role": "agent", "messageId": uuid.uuid4().hex, "contextId": context,
                        "parts": answer(query)[0]["parts"]}
            task = {"kind": "task", "id": uuid.uuid4().hex, "contextId": context,
                    "status": self._status("submitted"), "artifacts": [], "history": [message],
                    "_query": query, "_mode": mode, "_polls": 0}
            self.tasks[task["id"]] = task
            return self._public(task)

    def get(self, params):
        with self.lock:
            task = self.tasks.get(params.get("id"))
            if task is None:
                raise KeyError(params.get("id"))
            state = task["status"]["state"]
            if state in ("submitted", "working"):
                task["_polls"] += 1
                if task["_mode"] == "slow":
                    task["status"] = self._status("working")
                elif task["_mode"] == "fail":
                    task["status"] = self._status("failed", "MOCK failure requested by [mock:fail].")
                elif task["_mode"] == "clarify":
                    task["status"] = self._status("input-required",
                                                  "MOCK: which material system and property should I focus on?")
                elif task["_polls"] > POLLS_BEFORE_DONE:
                    task["artifacts"] = answer(task["_query"])
                    task["status"] = self._status("completed")
                else:
                    task["status"] = self._status("working")
            return self._public(task)

    def cancel(self, params):
        with self.lock:
            task = self.tasks.get(params.get("id"))
            if task is None:
                raise KeyError(params.get("id"))
            if task["status"]["state"] not in ("completed", "failed", "canceled"):
                task["status"] = self._status("canceled")
            return self._public(task)

    @staticmethod
    def _public(task):
        return {k: v for k, v in task.items() if not k.startswith("_")}


def make_handler(agent):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _send(self, status, body):
            data = json.dumps(body).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path in ("/.well-known/agent-card.json", "/.well-known/agent.json"):
                self._send(200, agent.card())
            else:
                self._send(404, {"error": "not found"})

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or 0)
            try:
                request = json.loads(self.rfile.read(length))
            except ValueError:
                return self._send(200, {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            methods = {"message/send": agent.send, "tasks/get": agent.get, "tasks/cancel": agent.cancel}
            method = methods.get(request.get("method"))
            if method is None:
                return self._send(200, {"jsonrpc": "2.0", "id": request.get("id"),
                                        "error": {"code": -32601, "message": "Method not found"}})
            try:
                result = method(request.get("params") or {})
            except KeyError:
                return self._send(200, {"jsonrpc": "2.0", "id": request.get("id"),
                                        "error": {"code": -32001, "message": "Task not found"}})
            self._send(200, {"jsonrpc": "2.0", "id": request.get("id"), "result": result})

    return Handler


def serve(port=0, host="127.0.0.1"):
    """Start the mock in a background thread; returns (server, base_url)."""
    agent = MockAgent()
    server = ThreadingHTTPServer((host, port), make_handler(agent))
    agent.url = f"http://{host}:{server.server_address[1]}"
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, agent.url


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    server, url = serve(args.port)
    print(f"Mock A2A literature agent (MOCK data) at {url}", flush=True)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        server.shutdown()


if __name__ == "__main__":
    main()
