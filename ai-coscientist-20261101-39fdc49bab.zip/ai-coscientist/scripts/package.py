"""Build a portable zip of this project without any virtual environment.

    python scripts/package.py                    # dist/ai-coscientist-<date>-<commit>.zip
    python scripts/package.py --with-tests       # also ship tests/ (to verify an install)
    python scripts/package.py --write-requirements   # refresh requirements*.txt from this environment

The zip holds the files Git tracks (so no .venv, outputs, caches or local settings),
minus docs/ and tests/ unless asked for. The recipient unzips it and runs
install.cmd (Windows) or install.sh (Linux); INSTALL.md explains the rest.
Uses only the standard library, except --write-requirements, which reads the
installed packages of the Python that runs it.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
NAME = "ai-coscientist"
OPTIONAL = {"docs": "--with-docs", "tests": "--with-tests"}
# Values that look like credentials. Settings must read keys from the environment ({env:NAME}).
SECRETS = [
    # A literal apiKey that looks random (placeholders such as "local" are fine).
    (re.compile(r'"apiKey"\s*:\s*"(?!\{env:)(?=[^"]{16,}")(?=(?:[^"\d]*\d){3})[^"]+"'),
     "an apiKey written into a file instead of {env:NAME}"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{20,}"), "an OpenAI-style secret key"),
    (re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}"), "an Anthropic secret key"),
    (re.compile(r"\bghp_[A-Za-z0-9]{36}\b"), "a GitHub token"),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "an AWS access key"),
]
DEV_ONLY = {"pytest", "iniconfig", "pluggy"}


def git(*args: str) -> str:
    try:
        return subprocess.run(["git", *args], cwd=ROOT, check=True, capture_output=True, text=True,
                              encoding="utf-8").stdout
    except (OSError, subprocess.CalledProcessError) as error:
        raise SystemExit(f"打包需要在 Git 工作目錄中執行，且能呼叫 git：{error}") from None


def selected_files(with_parts: set[str]) -> list[str]:
    tracked = [name for name in git("ls-files", "-z").split("\0") if name]
    return sorted(name for name in tracked
                  if name.split("/", 1)[0] not in OPTIONAL or name.split("/", 1)[0] in with_parts)


def dirty(files: list[str]) -> list[str]:
    changed = git("status", "--porcelain", "--untracked-files=no", "-z").split("\0")
    paths = {entry[3:] for entry in changed if len(entry) > 3}
    return sorted(paths & set(files))


def secret_findings(files: list[str]) -> list[str]:
    found = []
    for name in files:
        data = (ROOT / name).read_bytes()
        if b"\0" in data[:4096]:
            continue  # binary
        text = data.decode("utf-8", errors="replace")
        for pattern, label in SECRETS:
            if pattern.search(text):
                found.append(f"{name}: {label}")
    return found


def build(args) -> Path:
    files = selected_files({part for part, flag in OPTIONAL.items() if getattr(args, flag[2:].replace("-", "_"))})
    missing = [name for name in ("requirements.txt", "install.cmd", "install.sh", "INSTALL.md",
                                 "scripts/bootstrap.py", "scripts/check_install.py") if name not in files]
    if missing:
        raise SystemExit("缺少安裝必需的檔案（須先納入 Git）：" + "、".join(missing))
    for name in ("requirements.txt", "requirements-dev.txt", "install.cmd", "install.sh"):
        if name in files and not (ROOT / name).read_bytes().isascii():
            raise SystemExit(f"{name} 必須只含 ASCII：pip 與 Windows cmd 會以系統編碼（例如 cp950）讀取它。")
    changed = dirty(files)
    if changed and not args.allow_dirty:
        raise SystemExit("下列檔案有尚未 commit 的修改；請先 commit，或加 --allow-dirty 以目前內容打包：\n  "
                         + "\n  ".join(changed))
    secrets = secret_findings(files)
    if secrets:
        raise SystemExit("發現疑似密鑰，拒絕打包：\n  " + "\n  ".join(secrets))
    commit = git("rev-parse", "--short=10", "HEAD").strip()
    stamp = datetime.now(timezone.utc)
    label = f"{NAME}-{stamp:%Y%m%d}-{commit}" + ("-dirty" if changed else "")
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    target = output / f"{label}.zip"
    info = {"name": NAME, "commit": git("rev-parse", "HEAD").strip(), "uncommitted_changes": changed,
            "built_at": stamp.isoformat(timespec="seconds"), "includes": sorted({f.split("/", 1)[0] for f in files}),
            "tested_python": "3.12", "install": {"windows": "install.cmd", "linux": "bash install.sh"}}
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in [*files, "PACKAGE_INFO.json"]:
            entry = zipfile.ZipInfo(f"{NAME}/{name}", date_time=stamp.timetuple()[:6])
            entry.create_system = 3  # Unix, so unzip keeps the modes below
            entry.external_attr = (0o755 if name.endswith(".sh") else 0o644) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            data = (json.dumps(info, ensure_ascii=False, indent=2) + "\n").encode("utf-8") \
                if name == "PACKAGE_INFO.json" else (ROOT / name).read_bytes()
            archive.writestr(entry, data)
    size = target.stat().st_size / 1024 / 1024
    print(f"已建立 {target}（{len(files) + 1} 個檔案，{size:.1f} MB）")
    if changed:
        print("注意：包含尚未 commit 的修改：" + "、".join(changed))
    print("收件者：解壓縮後，Windows 執行 install.cmd，Linux 執行 bash install.sh；細節見 INSTALL.md。")
    return target


def write_requirements() -> None:
    """Pin every package the project needs, as installed in this (tested) environment."""
    from importlib import metadata
    from packaging.markers import default_environment
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name

    import tomllib

    # pyproject.toml, not the installed metadata: an editable install keeps the metadata of when it was made.
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    extras = ["science", "inference", "simulation"]
    roots = [*project["dependencies"], *(text for extra in extras for text in project["optional-dependencies"][extra])]
    platforms = {"win32": {"sys_platform": "win32", "platform_system": "Windows", "os_name": "nt"},
                 "linux": {"sys_platform": "linux", "platform_system": "Linux", "os_name": "posix"}}

    def closure(environment):
        needed, seen, pending = {}, set(), [Requirement(text) for text in roots]
        while pending:
            requirement = pending.pop()
            if requirement.marker is not None and not requirement.marker.evaluate({**environment, "extra": ""}):
                continue
            name = canonicalize_name(requirement.name)
            wanted = {"", *requirement.extras} - {extra for (known, extra) in seen if known == name}
            if name in DEV_ONLY or not wanted:
                continue
            try:
                found = needed.get(name) or metadata.distribution(requirement.name)
            except metadata.PackageNotFoundError:
                raise SystemExit(f"目前的環境沒有安裝 {requirement.name}；請在已測試的 .venv 中執行。") from None
            needed[name] = found
            seen.update((name, extra) for extra in wanted)
            for text in found.requires or []:
                child = Requirement(text)
                # A child counts when its marker holds for the base package or one of the extras asked for.
                if child.marker is None or any(child.marker.evaluate({**environment, "extra": extra})
                                               for extra in wanted):
                    child.marker = None
                    pending.append(child)
        return needed

    by_platform = {key: closure({**default_environment(), **values}) for key, values in platforms.items()}
    names = sorted(set().union(*by_platform.values()))
    # ASCII only: pip reads requirement files in the locale encoding (cp950 on a Chinese Windows).
    lines = ["# Generated by: python scripts/package.py --write-requirements (tested on Windows, Python "
             f"{sys.version_info.major}.{sys.version_info.minor}).", "# install.cmd / bash install.sh install these."]
    for name in names:
        dist = next(found[name] for found in by_platform.values() if name in found)
        only = [key for key, found in by_platform.items() if name in found]
        marker = "" if len(only) == len(platforms) else f' ; sys_platform == "{only[0]}"'
        lines.append(f"{dist.metadata['Name']}=={dist.version}{marker}")
    (ROOT / "requirements.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    pytest = metadata.version("pytest")
    (ROOT / "requirements-dev.txt").write_text(
        "# For the offline tests (python -m pytest tests -q); package with --with-tests to ship tests/.\n"
        f"-r requirements.txt\npytest=={pytest}\n", encoding="utf-8", newline="\n")
    print(f"已更新 requirements.txt（{len(names)} 個套件）與 requirements-dev.txt")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="打包本專案（不含虛擬環境）")
    parser.add_argument("--output", default=str(ROOT / "dist"), help="輸出資料夾，預設 dist/")
    parser.add_argument("--with-tests", action="store_true", help="一併打包 tests/")
    parser.add_argument("--with-docs", action="store_true", help="一併打包 docs/（開發紀錄）")
    parser.add_argument("--allow-dirty", action="store_true", help="允許以尚未 commit 的檔案內容打包")
    parser.add_argument("--write-requirements", action="store_true",
                        help="只從執行本程式的 Python 環境重新產生 requirements*.txt，不打包")
    args = parser.parse_args(argv)
    if args.write_requirements:
        write_requirements()
    else:
        build(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
