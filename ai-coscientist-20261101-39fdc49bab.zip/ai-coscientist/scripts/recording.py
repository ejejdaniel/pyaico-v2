"""What a recorded run adds to the one entry (co-scientist --record): a record of the round for people to check.

    co-scientist --record <run> --from <source> --prompt <request>            a new task
    co-scientist <earlier run> --continue --record <run> --prompt <request>   its next round

The task runs as every task runs (run_tui.build_app and run_tui.run_round): the same agent, the same reviewer
and the same round review. The record adds, around it:

- a run folder of its own: the task's workspace (a copy of the source, as a git work tree) and its state
  (sessions database, task skills, settings), apart from the person's other work. A continuation goes on in
  place, in the run its earlier record leads to, after a backup of the workspace and state as they were;
- each model request and response, the wire traffic, the transcript, the sessions and the result;
- the meta region's integrity: the installation, the task's sources and the task skills are hashed when the
  round starts, checked whenever a record is saved and when it ends; a round that changed them does not count;
- the record itself and the runs beside it hidden from the agent's tools (opencode/hidden.py);
- a snapshot of the workspace at each stage record (fork_run.py cuts a run back to one), an end at the first
  new record of a kind (--stop-at), and an end when a person writes stop-request.txt into the record folder.

A process exit is not scientific acceptance.
"""

from __future__ import annotations

from contextlib import closing, redirect_stdout
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time

if __package__:
    from .llm_configuration import select_llm_configuration
    from .llm_wire import WireRecorder, model_endpoints
else:
    from llm_configuration import select_llm_configuration
    from llm_wire import WireRecorder, model_endpoints

PROJECT = Path(__file__).resolve().parents[1]
# Names of the records a recorded run writes beside the agent's workspace, distinct enough that an output line
# naming one is dropped wherever it appears. Other records (settings.json, result.json, state/) are hidden by
# their path alone.
HOST_RECORDS = [r"(?:request|response|error)-\d{3,}\.json", r"wire-\d{3,}", r"cli-transcript\.txt",
                r"runtime-manifest\.json", r"source-manifest\.json", r"original-request\.txt",
                r"current-request\.txt", r"workspace-(?:before|after)\.json", r"meta-(?:baseline|violation)\.json",
                r"round-review\.json", r"framework-issues\.md", r"stop-request\.txt", r"pause-review-\d+\.json",
                r"verification-plan\.json", r"answer-\d+\.md"]
# The meta region's hashes when the round started, and what changed in it (opencode/integrity.py).
META_BASELINE = "meta-baseline.json"
META_VIOLATION = "meta-violation.json"
# The review at the end of the round (opencode/round_review.py), and the framework issues it raised for people.
ROUND_REVIEW = "round-review.json"
FRAMEWORK_ISSUES = "framework-issues.md"
# A review the round paused for when its work stalled (opencode/loop.py _pause_for_review), numbered in order.
PAUSE_REVIEW = "pause-review-{}.json"
# The task's verification plan, written by the reviewer before the first step (opencode/verification.py).
VERIFICATION_PLAN = "verification-plan.json"
# Written into the record folder by a person to end the round now (its text is their reason). The round ends as
# a stage stop does: its integrity is checked and it is reviewed, unlike an interrupted run.
STOP_REQUEST = "stop-request.txt"
# The run folder's own folders besides the workspace, and the environment variables that point at them.
PRIVATE = {"OPENCODE_CONFIG_DIR": "config", "OPENCODE_TEST_HOME": "home", "XDG_DATA_HOME": "data",
           "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache", "TEMP": "temp", "TMP": "temp"}
# Records that end a stage. The run saves the workspace as it was when each was saved
# (checkpoints/<record folder>/workspace), so fork_run.py can cut the run back to it.
NODE_KINDS = ("prepared_data", "literature", "mindmap", "hypothesis", "history_check", "leaderboard",
              "sample_evolution", "report", "review")


def hashes(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def hidden_paths(runs, *, visible, keep) -> dict:
    """The agent's config["hidden"] (see opencode/hidden.py): this run's records and the runs beside it.

    Each run folder's entries are hidden except `visible` (the workspace and the folders the agent's
    own tools use) and the folders leading to them. The folder holding a run is hidden the same way,
    so other runs' results are out of sight, unless it also holds something the agent uses (`keep`:
    the project with its interpreter, the source data).
    """
    runs = [run.resolve() for run in dict.fromkeys(runs)]
    visible = [path.resolve() for path in visible]
    keep = [path.resolve() for path in keep]
    roots = list(runs)
    for run in runs:
        if run.parent not in roots and not any(item.is_relative_to(run.parent) for item in keep):
            roots.append(run.parent)
    # Other runs' folder names are dropped from output too, except a name that is also part of a path
    # the agent uses. Names are matched as whole words; a short name, or one without a digit, "-" or
    # "_", is too likely to be an ordinary word.
    own = {part.casefold() for path in visible + keep for part in path.parts}
    names = list(HOST_RECORDS)
    for root in roots[len(runs):]:
        names.extend(re.escape(entry.name) for entry in sorted(root.iterdir())
                     if not any(path.is_relative_to(entry) for path in visible)
                     and re.search(r"[\d_-]", entry.name) and len(entry.name) >= 8 and entry.name.casefold() not in own)
    return {"roots": [str(path) for path in roots], "visible": [str(path) for path in visible], "names": names}


class NodeWatcher(threading.Thread):
    """Snapshot the workspace at each node record, and end the run at the first new record of stop_at, or
    when a person asks for the round to end by writing stop_request (its text is their reason)."""

    def __init__(self, workspace: Path, checkpoints: Path, stop_at: str | None, on_stop, verify=None,
                 stop_request: Path | None = None):
        super().__init__(daemon=True)
        self.workspace, self.checkpoints, self.stop_at, self.on_stop = workspace, checkpoints, stop_at, on_stop
        # verify() lists what changed in the meta region since the start; checked whenever records appear.
        self.verify, self.violation = verify, None
        self.seen = set(self._records())
        self.stopped_at = None
        self.stop_request, self.requested = stop_request, None
        self.halt = threading.Event()

    def _records(self):
        folder = self.workspace / ".research" / "records"
        return [path for path in folder.glob("*/record.json") if not path.parent.name.startswith(".staging-")]

    def run(self):
        while not self.halt.wait(1.0):
            if self.stop_request is not None and self.requested is None and self.stop_request.is_file():
                try:
                    reason = " ".join(self.stop_request.read_text(encoding="utf-8-sig").split())
                except (OSError, UnicodeDecodeError):
                    reason = ""
                self.requested = reason or "(no reason given)"
                print(f"\n[stage] stopping at the person's request: {self.requested}", flush=True)
                self.on_stop()
            fresh = False
            for path in sorted(set(self._records()) - self.seen, key=lambda item: item.stat().st_mtime):
                self.seen.add(path)
                try:
                    kind = json.loads(path.read_text(encoding="utf-8")).get("kind")
                except (OSError, ValueError):
                    self.seen.discard(path)
                    continue
                fresh = True
                if kind in NODE_KINDS:
                    target = self.checkpoints / path.parent.name / "workspace"
                    if not target.exists():
                        shutil.copytree(self.workspace, target, copy_function=shutil.copy2,
                                        ignore=shutil.ignore_patterns("__pycache__"))
                if self.stop_at and kind == self.stop_at and self.stopped_at is None:
                    self.stopped_at = path.relative_to(self.workspace).as_posix()
                    print(f"\n[stage] stopping at {kind} {path.parent.name[:8]}", flush=True)
                    self.on_stop()
            if fresh and self.verify is not None and self.violation is None:
                found = self.verify()
                if found:
                    self.violation = found
                    print("\n[integrity] the meta region changed while the run worked; stopping it: "
                          + "; ".join(found[:5]), flush=True)
                    self.on_stop()


def state_run(run: Path) -> Path:
    """Follow existing record links to the run whose workspace and state a continuation works in."""
    current = run.resolve()
    seen = set()
    while current not in seen:
        seen.add(current)
        if (current / "workspace").is_dir() and (current / "state/opencode/opencode.db").is_file():
            return current
        link = current / "continuation.json"
        if not link.is_file():
            raise ValueError(f"No saved workspace/state or continuation link at {current}")
        previous = json.loads(link.read_text(encoding="utf-8")).get("previous_run")
        if not isinstance(previous, str) or not previous.strip():
            raise ValueError(f"Invalid previous_run continuation link at {current}")
        target = Path(previous)
        current = (target if target.is_absolute() else current / target).resolve()
    raise ValueError("Cyclic previous_run continuation links")


def continuation_session(run: Path) -> str:
    """Recover an earlier run's root session without opening the live Store."""
    if not (run / "result.json").is_file():
        # A continuation stopped before it finished has no result yet, but recorded its session when it started.
        link = run / "continuation.json"
        session = json.loads(link.read_text(encoding="utf-8")).get("session_id") if link.is_file() else None
        if isinstance(session, str) and session.strip():
            return session
        raise ValueError(f"{run} has neither result.json nor a continuation session id; it cannot be resumed")
    result = json.loads((run / "result.json").read_text(encoding="utf-8"))["result"]
    if not isinstance(result, dict):
        raise ValueError("The saved result must be an object")
    if "sessionID" in result:
        return result["sessionID"]
    sessions = json.loads((run / "sessions.json").read_text(encoding="utf-8"))
    if not isinstance(sessions, list) or any(
        not isinstance(item, dict) or not isinstance(item.get("session"), dict)
        or "parentID" not in item["session"] for item in sessions
    ):
        raise ValueError("The saved sessions cannot identify a root session")
    roots = [item["session"] for item in sessions if item["session"]["parentID"] is None]
    if len(roots) != 1:
        raise ValueError("Expected exactly one saved root session for continuation")
    saved = roots[0]
    if any(not isinstance(saved.get(key), str) or not saved[key].strip() for key in ("id", "directory")):
        raise ValueError("The saved root session identity or directory is missing")
    database = state_run(run) / "state/opencode/opencode.db"
    with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
        actual = connection.execute("SELECT id, directory FROM session WHERE parent_id IS NULL").fetchall()
    if len(actual) != 1 or actual[0] != (saved["id"], saved["directory"]):
        raise ValueError("The saved root session identity or directory disagrees with the database")
    return saved["id"]


def original_request(run: Path, session_id: str) -> str:
    """Read the historical commission without opening/migrating the live Store."""
    database = state_run(run) / "state/opencode/opencode.db"
    with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
        rows = connection.execute(
            "SELECT data FROM message WHERE session_id = ? AND role = 'user' ORDER BY created, rowid",
            (session_id,),
        )
        for row in rows:
            message = json.loads(row[0])
            if not message.get("synthetic") and not message.get("compaction_through"):
                text = message.get("content")
                if not isinstance(text, str) or not text.strip():
                    raise ValueError("The saved original human request is empty or malformed")
                return text
    raise ValueError("No saved original human request; refusing to substitute the continuation request")


class Tee:
    def __init__(self, terminal, file):
        self.terminal, self.file = terminal, file

    def reconfigure(self, **kwargs):
        configure = getattr(self.terminal, "reconfigure", None)
        if callable(configure):
            configure(**kwargs)

    def write(self, text):
        self.file.write(text)
        self.file.flush()
        self.terminal.write(text)
        self.terminal.flush()
        return len(text)

    def flush(self):
        self.file.flush()
        self.terminal.flush()

    def isatty(self):
        return False


def recording_client(record: Path):
    """A model client that saves each request, response and error in the record folder."""
    from opencode.provider import Client

    lock = threading.Lock()
    count = [0]

    class RecordedClient(Client):
        def _openai(self, provider, key, model, system, messages, tools, temperature, on_text, *, on_update=None,
                    on_tool_call=None, abort_event=None, **options):
            # options: any further request options of Client._openai (e.g. response_format), passed through unchanged.
            with lock:
                count[0] += 1
                index = count[0]
            begin = time.monotonic()
            request = {"provider": provider.id, "model": model, "system": system, "messages": messages,
                       "tools": tools, "temperature": temperature, **options}
            save(record / f"request-{index:03}.json", request)
            print(f"\n[model {index} start]", flush=True)
            try:
                response = super()._openai(provider, key, model, system, messages, tools, temperature, on_text,
                                           on_update=on_update, on_tool_call=on_tool_call, abort_event=abort_event,
                                           **options)
            except Exception as exc:
                partial = getattr(exc, "partial", None)
                save(record / f"error-{index:03}.json", {"error": str(exc), "seconds": time.monotonic() - begin,
                     "partial": {"text": partial.text, "tool_calls": [vars(c) for c in partial.tool_calls],
                                 "reasoning_content": partial.reasoning_content,
                                 "usage": partial.usage, "finish_reason": partial.finish_reason} if partial else None})
                raise
            save(record / f"response-{index:03}.json", {
                "text": response.text, "tool_calls": [vars(c) for c in response.tool_calls],
                "usage": response.usage, "finish_reason": response.finish_reason,
                "reasoning_content": response.reasoning_content,
                "seconds": time.monotonic() - begin,
            })
            print(f"\n[model {index} end; tools={[c.name for c in response.tool_calls]}]", flush=True)
            return response

    return RecordedClient


def record_round(record: Path, prompts: list[str], *, build, run, prepare=None, source: Path | None = None,
                 prior: Path | None = None, llm_config: Path | None = None, no_review: bool = False,
                 deep: bool = False, supervised: bool = False, stop_at: str | None = None, prompt_files=()) -> int:
    """One recorded round: a new task copied from source, or with prior (an earlier record folder) that
    task's next round. build and run are the entry's run_tui.build_app and run_tui.run_round; deep turns deep
    research on for the task (opencode/deep.py); supervised lets the prompt files play a person at the keyboard
    (a general-mode turn's call budget, opencode/loop.py).

    Everything that can be checked before the run is checked before anything is written."""
    from opencode import integrity

    record = Path(record).resolve()
    prior = Path(prior).resolve() if prior else None
    settings = json.loads((prior / "settings.json").read_text(encoding="utf-8")) if prior else None
    source = Path(settings["source"]) if prior else Path(source).resolve()
    if record.is_relative_to(source) or source.is_relative_to(record):
        raise ValueError("The record folder must not overlap the source folder")
    if prior and (record.is_relative_to(prior) or prior.is_relative_to(record)):
        raise ValueError("The record folder must not overlap the earlier run")
    if not prompts or not all(text.strip() for text in prompts):
        raise ValueError("An explicit human request is required; no continuation request is inferred")
    if prior:
        session_id = continuation_session(prior)
        commission = original_request(prior, session_id)
        runtime = state_run(prior)
        if record.is_relative_to(runtime) or runtime.is_relative_to(record):
            raise ValueError("The record folder must not overlap the earlier run's workspace and state")
        database = runtime / "state/opencode/opencode.db"
        with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as connection:
            session_agent, session_model = connection.execute(
                "SELECT agent, model FROM session WHERE id = ?", (session_id,)).fetchone()
    else:
        session_id, commission, runtime, session_agent, session_model = None, prompts[0], None, None, None
    home = runtime or record  # the run folder: the workspace, its state and its checkpoints
    workspace = home / "workspace"
    sources = sorted(hashes(source))
    if prior and (prior / META_BASELINE).is_file():
        # A continuation starts only from a workspace whose installed guidance, tools and task sources the
        # previous stage left as they were; the installation itself may change between stages.
        before = integrity.workspace_part(json.loads((prior / META_BASELINE).read_text(encoding="utf-8")))
        moved = integrity.changes(before, integrity.workspace_part(integrity.snapshot(PROJECT, workspace, sources)))
        if moved:
            raise ValueError("The previous stage changed the meta region of its workspace, so it is not continued: "
                             + "; ".join(moved[:10]))
    selection = select_llm_configuration(
        PROJECT / "config/llm.opencode.json", llm_config=llm_config,
        saved_config=settings.get("config") if settings else None,
        saved_source=str(prior / "settings.json") if prior else None, resume=bool(prior))
    record.mkdir(parents=True, exist_ok=False)
    source_hashes = hashes(source)
    if prior:
        backup = record / "baseline"
        backup.mkdir()
        for name in ("workspace", "state", "data", "temp", "config"):
            if (runtime / name).exists():
                shutil.copytree(runtime / name, backup / name)
        save(record / "workspace-before.json", hashes(workspace))
        save(record / "continuation.json", {"previous_run": str(prior), "session_id": session_id,
                                            "baseline": str(backup)})
    else:
        shutil.copytree(source, workspace)
        subprocess.run(["git", "init", "--quiet", str(workspace)], check=True)
    (record / "original-request.txt").write_text(commission, encoding="utf-8")
    (record / "current-request.txt").write_text(prompts[0], encoding="utf-8")
    save(record / "source-manifest.json", source_hashes)
    save(record / "runtime-manifest.json", {"src/" + p: h for p, h in hashes(PROJECT / "src").items()})
    for key, name in PRIVATE.items():
        path = home / name
        path.mkdir(exist_ok=True)
        os.environ[key] = str(path)
    os.environ["OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"] = "1"
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    # Generated programs should use the same ready interpreter as this process.
    os.environ["PATH"] = str(Path(sys.executable).parent) + os.pathsep + os.environ.get("PATH", "")
    sys.dont_write_bytecode = True
    import tempfile
    tempfile.tempdir = str(home / "temp")
    from opencode import task_skills
    from opencode.paths import data_dir, truncation_dir
    from opencode.provider import Client

    if prior:
        # A session is one task; each continuation is its next round (docs/design_meta_task_zones_20261030_zh-TW.md §10).
        task_skills.set_round(session_id, task_skills.current_round(session_id) + 1)
    round_number = task_skills.current_round(session_id) if prior else 1
    # The meta region as this round starts it, with the task skills kept in this run's state (review skills
    # change only between rounds): checked whenever a record is saved and when the round ends.
    task_state = {"task": task_skills.state_root()}
    if prepare:
        # What the framework installs into the workspace (deep research's skill copies) is in the meta region
        # from the start, so building the app afterwards changes nothing in it.
        prepare(workspace)
    baseline = integrity.snapshot(PROJECT, workspace, sources, task_state)
    save(record / META_BASELINE, baseline)
    # This run's records and other runs read as missing to the agent's tools.
    hidden = hidden_paths([home, record], visible=[workspace, home / "temp", data_dir() / "plans", truncation_dir()],
                          keep=[PROJECT, Path(sys.executable), source])
    app, effective, model = build(workspace, unattended=True, sources=sources, selection=selection,
                                  saved_directory=record, root_agent=session_agent, session_model=session_model,
                                  extra_config={"hidden": hidden})
    save(record / "settings.json", {"config": effective.saved_config, "python": sys.executable, "source": str(source),
                                    "prompt": str(Path(prompt_files[0]).resolve()) if prompt_files else None,
                                    "prompts": [str(Path(path).resolve()) for path in prompt_files], "hidden": hidden})
    app.generate_titles = False
    app.supervised = supervised
    app.provider = recording_client(record)(app.auth, app.config)
    pauses, planned = [], {}

    def meta_changes():
        return integrity.changes(baseline, integrity.snapshot(PROJECT, workspace, sources, task_state))

    def adopt_review_area():
        """What the framework's reviewer just wrote becomes the review area's baseline; the round's later
        checks hold the agent to it."""
        fresh = integrity.snapshot(PROJECT, workspace, sources, task_state)
        for key in [key for key in baseline if key.startswith("task/")]:
            del baseline[key]
        baseline.update({key: value for key, value in fresh.items() if key.startswith("task/")})
        save(record / META_BASELINE, baseline)

    def guard():
        """Why the reviewer must not write now: a round whose meta region changed does not count."""
        return "the meta region changed during this round, so it does not count" if meta_changes() else None

    def wrote(kind, saved):
        """The reviewer's hooks are the same for every task (researchkit/task_runtime.py); this run adopts what
        the reviewer wrote as the review area's baseline and keeps each record."""
        if kind == "pause" and saved.get("status") == "skipped":
            return
        if saved.get("status") != "skipped":
            adopt_review_area()
        if kind == "plan":
            planned.update(saved)
            save(record / VERIFICATION_PLAN, saved)
        else:
            pauses.append(saved.get("status"))
            save(record / PAUSE_REVIEW.format(len(pauses)), saved)

    def stop_run():
        for item in app.store.list_sessions():
            if item.get("parentID") is None:
                app.abort(item["id"])

    watcher = NodeWatcher(workspace, home / "checkpoints", stop_at, stop_run, meta_changes,
                          stop_request=record / STOP_REQUEST)
    wire = WireRecorder(record, endpoints=model_endpoints(Client(None, effective.config)))
    checked = {}

    def before_review():
        """The round's last integrity check comes before its review: the review skill it writes is the next
        round's to start with, not a change of this round's meta region."""
        watcher.halt.set()
        watcher.join(timeout=5)
        checked["meta"] = watcher.violation or meta_changes()
        return "the meta region changed during this round, so it does not count" if checked["meta"] else None

    started = time.monotonic()
    round_started = time.time()
    outcome, error, interrupted = {}, None, False
    watcher.start()
    try:
        with (record / "cli-transcript.txt").open("w", encoding="utf-8") as transcript:
            with redirect_stdout(Tee(sys.stdout, transcript)):
                for message in effective.messages:
                    print("[model configuration] " + message)
                print(f"[model configuration] explicit model: {model or '(saved session / agent selection)'}")
                with wire:
                    outcome = run(app, workspace, prompts, model=model, session=session_id, no_review=no_review,
                                  deep=deep, sources=sources, started=round_started, guard=guard, wrote=wrote,
                                  before_review=before_review, ended=lambda: {
                                      "model_calls": wire.count, "stopped_at": watcher.stopped_at, "stop_at": stop_at,
                                      "stop_requested": watcher.requested})
    except (Exception, SystemExit) as exc:
        error = str(exc)
    except KeyboardInterrupt:
        interrupted = True
        raise
    finally:
        if "meta" not in checked:
            before_review()
        meta = checked["meta"]
        if meta:
            save(record / META_VIOLATION, meta)
        save(record / "sessions.json", [{"session": s, "messages": app.store.messages(s["id"])}
                                         for s in app.store.list_sessions()])
        app.store.close()
        turns = outcome.get("turns") or []
        last = (turns[-1].get("result") or {}) if turns else {}
        error = error or next((turn["error"] for turn in turns if turn.get("error")), None)
        review = outcome.get("review") or {"status": "skipped", "reason": "the run was interrupted" if interrupted
                                           else f"the round ended before its review: {error}"}
        save(record / ROUND_REVIEW, review)
        if review.get("framework_issues") or review.get("refused"):
            from opencode.round_review import issues_markdown
            (record / FRAMEWORK_ISSUES).write_text(issues_markdown(review), encoding="utf-8")
        save(record / "result.json", {
            "result": {**last, "sessionID": outcome.get("session") or session_id} if (last or outcome) else {},
            **({"turns": [{"question": turn["question"], "status": (turn.get("result") or {}).get("status"),
                           **({"error": turn["error"]} if turn.get("error") else {}), "seconds": turn["seconds"]}
                          for turn in turns]} if len(prompts) > 1 else {}),
            "error": error, "model_calls": wire.count,
            "seconds": time.monotonic() - started,
            "original_source_unchanged": hashes(source) == source_hashes,
            "copied_source_unchanged": all((workspace / p).is_file() and hashlib.sha256((workspace / p).read_bytes()).hexdigest() == h
                                           for p, h in source_hashes.items()),
            "scientific_delivery": "not_reviewed",
            "round": round_number,
            "round_review": review.get("status"),
            **({"verification_plan": planned.get("status")} if planned else {}),
            **({"pause_reviews": pauses} if pauses else {}),
            "meta_region_unchanged": not meta,
            **({"meta_region_changes": meta[:50]} if meta else {}),
            **({"stopped_at": watcher.stopped_at} if watcher.stopped_at else {}),
            **({"stop_requested": watcher.requested} if watcher.requested else {}),
        })
        if prior:
            save(record / "workspace-after.json", hashes(workspace))
        (record / "answer.md").write_text(last.get("text", "") or "", encoding="utf-8")
        if len(prompts) > 1:
            for number, turn in enumerate(turns, 1):
                (record / f"answer-{number}.md").write_text((turn.get("result") or {}).get("text", "") or "",
                                                           encoding="utf-8")
    print(f"Record: {record}; dialogue_status={last.get('status')}; error={error}; "
          "scientific_delivery=not_reviewed (process completion is not research acceptance)")
    print(f"[round review] round {round_number}: {review.get('status')}; " + (
        review.get("reason") or review.get("error") or
        f"{len(review.get('lessons') or [])} lessons, {len(review.get('framework_issues') or [])} framework issues, "
        f"{len(review.get('refused') or [])} entries not written ({ROUND_REVIEW})"))
    if meta:
        print(f"[integrity] the meta region changed during this run ({len(meta)} entries, {META_VIOLATION}); "
              "the run does not count: " + "; ".join(meta[:5]))
        return 1
    if watcher.stopped_at:
        print(f"[stage] ended at {watcher.stopped_at} as requested (--stop-at {stop_at})")
        return 0
    if watcher.requested:
        print(f"[stage] ended at the person's request ({STOP_REQUEST}): {watcher.requested}")
        return 0
    return 0 if not error and len(turns) == len(prompts) and all(
        (turn.get("result") or {}).get("status") == "completed" for turn in turns) else 1
