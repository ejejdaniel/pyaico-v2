"""Render an explicitly selected formal mindmap.json to standalone HTML or SVG."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

from researchkit.mindmap_render import render_html, render_svg
from researchkit.mindmap_schema import parse_map


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="Output .html or .svg file.")
    parser.add_argument("--force", action="store_true", help="Replace an existing output file.")
    args = parser.parse_args()
    source, destination = args.input.resolve(), args.output.resolve()
    if source == destination:
        raise ValueError("The output must not replace the source map")
    if destination.suffix.lower() not in {".html", ".svg"}:
        raise ValueError("The output filename must end in .html or .svg")
    if destination.exists() and not args.force:
        raise FileExistsError(destination)
    raw = source.read_bytes()
    value = parse_map(raw.decode("utf-8"))
    if destination.suffix.lower() == ".svg":
        rendered = render_svg(value, namespace="standalone-mindmap")
    else:
        rendered = render_html(value, {
            "record_ref": "獨立正式 JSON；此命令未解析保存紀錄",
            "source_path": str(source),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "title": value["title"],
            "kind": "mindmap",
        }, namespace="standalone-mindmap")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(rendered, encoding="utf-8", newline="")
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
