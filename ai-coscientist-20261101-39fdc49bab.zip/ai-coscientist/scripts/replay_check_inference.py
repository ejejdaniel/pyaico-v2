"""Developer-only replay of a recorded claim; never calls a model or network.

The engineer authors the fixed formalization below from explicitly selected
saved text. This is not an autonomous formalization, a new scientific review,
or a source of physical observations. No historical artifact is rewritten.
"""

from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager
from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
import re
import shutil
import socket
from types import SimpleNamespace
from unittest.mock import patch

import httpx

from opencode.permission import Broker, Rule
from researchkit import inference, records, review, reviewer
from researchkit.tools import TOOLS


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / "outputs/report_real_llm_20261021_v1/workspace"
REVIEW_SOURCE = PROJECT / "outputs/report_review_bound_claim_real_20261022_v1"
DEFAULT_OUTPUT = PROJECT / "outputs/check_inference_offline_20261022_v1/replay"
REPORT_REF = ".research/records/bb5227fc0a78c424c2fdbcdc6166221f6ee26297ecad796597c4602d11e2580b/record.json"
FORMULA_REF = ".research/records/398c19585a05f6ce18c71c303d7dcf5ff715ad6b8725ef3ab2eb6d3b81265f91/record.json"
REPORT_PATH = "reports/formal_report.md"
FORMULA_PATH = "lit_research/records/proxy_formula.md"
GOAL_QUOTE = "靈敏度與脫保護速率（∝ 1/Ea）相關"
PREMISE_QUOTE = (
    "deprotection activation energy (Ea) → faster/more deprotection per acid → higher\n"
    "sensitivity → lower EOP."
)


def _json(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _save(path, value):
    path.write_bytes(records.encoded(value) + b"\n")


def _hashes(paths):
    return {str(path): records.digest(path.read_bytes()) for path in sorted(set(paths))}


def _closure_files(source):
    """Follow only explicit immutable dependencies and manifest snapshot paths."""
    verified = records._read_dependencies(source, [REPORT_REF])
    paths = []
    for ref, manifest in verified.items():
        path = records.local_path(source, ref)
        paths.append(path)
        paths.extend(records.local_path(path.parent, entry["snapshot"])
                     for entry in manifest["files"])
    return verified, paths


def _copy_closure(source, destination, paths):
    destination.mkdir(parents=True, exist_ok=False)
    for original in paths:
        relative = original.relative_to(source.resolve())
        if relative.parts[:2] != (".research", "records"):
            raise ValueError(f"Frozen source is outside the records allowlist: {relative}")
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, target)
        if target.read_bytes() != original.read_bytes():
            raise ValueError(f"Copied evidence changed: {relative}")
    records._read_dependencies(destination, [REPORT_REF])


def _problem():
    """An explicit engineering-authored model, not Python semantic inference."""
    return {
        "scope": (
            "Offline engineering-authored check of the rate ∝ 1/Ea subclaim in formal_report.md:138. "
            "Only test the necessary equal-product condition for a common reciprocal constant. "
            "Do not assess the complete EOP formula, Mw exponent, physical kinetics or measured samples."
        ),
        "goal": {
            "source": {"record_ref": REPORT_REF, "source_path": REPORT_PATH,
                       "start_line": 138, "end_line": 138, "quote": GOAL_QUOTE},
            "expr": "(= (* E1 r1) (* E2 r2))",
            "interpretation": (
                "A common reciprocal relation r=C/E requires E1*r1=E2*r2 in two comparable contexts. "
                "This necessary condition is weaker than proving a reciprocal law over a domain. "
                "The engineering author selected this abstraction; scientific adequacy remains unassessed."
            ),
        },
        "variables": [
            {"name": "E1", "sort": "Real", "unit": "Ea proxy scale",
             "meaning": "Ea indicator in hypothetical comparable context 1; not a measured activation energy."},
            {"name": "E2", "sort": "Real", "unit": "Ea proxy scale",
             "meaning": "Ea indicator in hypothetical comparable context 2; not a measured activation energy."},
            {"name": "r1", "sort": "Real", "unit": "1",
             "meaning": "Normalized relative deprotection rate in context 1; no observed rate is supplied."},
            {"name": "r2", "sort": "Real", "unit": "1",
             "meaning": "Normalized relative deprotection rate in context 2; no observed rate is supplied."},
        ],
        "premises": [
            {"id": "qualitative_rate", "origin": "source",
             "expr": "(=> (< E1 E2) (> r1 r2))",
             "sources": [{"record_ref": FORMULA_REF, "source_path": FORMULA_PATH,
                          "start_line": 10, "end_line": 12, "quote": PREMISE_QUOTE}],
             "interpretation": (
                 "Engineering author translates the cited qualitative lower-Ea/faster-deprotection statement "
                 "as an ordering implication; source origin identifies text provenance, not established physical truth. "
                 "The source does not specify a quantitative reciprocal law."
             )},
            {"id": "positive_domain", "origin": "assumption",
             "expr": "(and (> E1 0) (> E2 0) (> r1 0) (> r2 0))", "sources": [],
             "interpretation": (
                 "Engineering-added positive-domain restriction for the two hypothetical comparable contexts; "
                 "not a source measurement. Other conditions are assumed comparable in this abstraction."
             )},
            {"id": "chosen_comparison", "origin": "assumption", "expr": "(< E1 E2)", "sources": [],
             "interpretation": (
                 "Engineering-added ordering chooses a nonvacuous hypothetical comparison. "
                 "It supplies no sample identity or measured value."
             )},
        ],
    }


def _context(root):
    permissions = [Rule("*", "*", "deny"), Rule("read", "*", "allow"),
                   Rule("check_inference", "*", "allow")]
    for name in (".research/inference-runs", ".research/records"):
        permissions.extend((Rule("edit", name, "allow"), Rule("edit", name + "/*", "allow")))
    return SimpleNamespace(directory=root, worktree=root, session_id="offline-inference-replay",
                           agent=SimpleNamespace(permission=permissions),
                           app=SimpleNamespace(permissions=Broker(auto=True)))


@contextmanager
def _offline_only():
    attempts = []

    def blocked(*args, **kwargs):
        attempts.append("Forbidden model or network entry was called")
        raise AssertionError(attempts[-1])

    with ExitStack() as stack:
        for owner, name in ((reviewer, "complete_once"), (httpx.HTTPTransport, "handle_request"),
                            (httpx.AsyncHTTPTransport, "handle_async_request"),
                            (socket, "create_connection"), (socket.socket, "connect")):
            stack.enter_context(patch.object(owner, name, blocked))
        yield attempts


def _rational(text):
    """Independently parse only exact rational Z3 values; never eval arbitrary text."""
    tokens = re.findall(r"\(|\)|[^\s()]+", text)
    position = 0

    def parse():
        nonlocal position
        if position >= len(tokens):
            raise ValueError("Incomplete exact rational value")
        token = tokens[position]
        position += 1
        if token != "(":
            if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", token):
                raise ValueError(f"Not an exact rational value: {text}")
            return Fraction(token)
        if position >= len(tokens):
            raise ValueError("Missing rational operator")
        operator = tokens[position]
        position += 1
        left = parse()
        value = -left if operator == "-" else left / parse() if operator == "/" else None
        if value is None or position >= len(tokens) or tokens[position] != ")":
            raise ValueError(f"Unsupported rational expression: {text}")
        position += 1
        return value

    result = parse()
    if position != len(tokens):
        raise ValueError(f"Trailing rational tokens: {text}")
    return result


def _verify_countermodels(outcome):
    checks = {}
    for query in outcome["queries"]:
        if query["status"] != "sat":
            raise AssertionError(f"Saved case did not produce a witness for {query['name']}: {query}")
        values = {name: _rational(value) for name, value in query["values"].items()}
        e1, e2, r1, r2 = (values[name] for name in ("E1", "E2", "r1", "r2"))
        source_holds = not e1 < e2 or r1 > r2
        assumptions_hold = all(value > 0 for value in values.values()) and e1 < e2
        goal_holds = e1 * r1 == e2 * r2
        assert source_holds, "Solver witness violates the source ordering premise"
        if query["name"].startswith("full_"):
            assert assumptions_hold, "Solver witness violates explicitly added assumptions"
        if query["name"].endswith("counterexample"):
            assert not goal_holds, "Solver witness is not a countermodel to the equal-product condition"
        checks[query["name"]] = {
            "exact_rational_values": {name: str(value) for name, value in values.items()},
            "source_ordering_holds": source_holds, "added_assumptions_hold": assumptions_hold,
            "equal_product_goal_holds": goal_holds,
        }
    return checks


def _selected_frozen_paths(source, arguments):
    paths = []
    for locator in arguments["files"]:
        manifest = records.local_path(source, locator["record_ref"])
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == locator["source_path"]]
        paths.extend((manifest, records.local_path(manifest.parent, entry["snapshot"])))
    return paths


def _review_boundary(root, ctx, saved_source, output, receipt):
    original_args = _json(saved_source / "live/arguments.json")
    expanded = deepcopy(original_args)
    wanted = ("input.json", "result.json", "full_counterexample.smt2", "full_counterexample.txt")
    appended = []
    for filename in wanted:
        entry, = [item for item in receipt["files"] if Path(item["source_path"]).name == filename]
        appended.append({"record_ref": receipt["record_path"], "source_path": entry["source_path"]})
    expanded["files"].extend(appended)
    reviewer._selection(expanded)
    system, message, verified, snapshots, selection = reviewer._input(expanded, ctx)
    _save(output / "review-arguments-not-sent.json", expanded)
    _save(output / "review-request-not-sent.json", {
        "offline_note": "Prepared locally only; NOT sent to any model. This is not a model response.",
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": message}],
    })
    original = _json(saved_source / "live/final-answer-002.txt")
    replayed = reviewer._assemble(original["checks"], expanded, selection).encode("utf-8")
    old_review = (saved_source / "live/review.json").read_bytes()
    assert replayed == old_review, "Expanding the packet changed the historical review bytes"
    dependencies = list(dict.fromkeys(item["record_ref"] for item in expanded["files"]))
    review.validate(root, replayed, dependencies, verified)
    (output / "historical-review-reassembled.json").write_bytes(replayed)
    reviewer._recheck_sources(expanded, ctx, verified, snapshots)

    # A test-authored structural probe is kept outside .research/records. Its
    # unassessed decision deliberately does not impersonate a scientific review.
    def file_id(locator):
        return next(key for key, item in selection.items()
                    if (item["record_ref"], item["source_path"]) ==
                    (locator["record_ref"], locator["source_path"]))

    def whole_file(locator):
        key = file_id(locator)
        return {"file_id": key, "start_line": 1, "end_line": len(selection[key]["lines"])}

    probe = [{
        "subject": {"file_id": file_id({"record_ref": REPORT_REF, "source_path": REPORT_PATH}),
                    "start_line": 138, "end_line": 138, "quote": GOAL_QUOTE},
        "evidence": [whole_file(appended[0]), whole_file(appended[1]),
                     {"file_id": file_id({"record_ref": FORMULA_REF, "source_path": FORMULA_PATH}),
                      "start_line": 9, "end_line": 14}],
        "decision": "unassessed",
        "reason": (
            "工程作者建立的離線結構檢查，並非新的科學審查或模型回答。只驗證原主張、形式化輸入、"
            "求解結果與來源文字可依既有引用契約接續；形式化的科學充分性與原主張仍未經新審查。"
            "求解器數值是形式反例，不是材料量測。此檔案不發布為正式 review 成果。"
        ),
    }]
    probe_bytes = reviewer._assemble(probe, expanded, selection).encode("utf-8")
    review.validate(root, probe_bytes, dependencies, verified)
    (output / "structural-probe-unassessed.json").write_bytes(probe_bytes)
    _save(output / "structural-probe-locators.json", {"checks": probe})
    missing_old = not any(check["subject"]["file_id"] == "F1"
                          and check["subject"]["start_line"] <= 138 <= check["subject"]["end_line"]
                          for check in original["checks"])
    assert expanded["files"][:len(original_args["files"])] == original_args["files"]
    return {"original_selected_file_count": len(original_args["files"]),
            "appended_selected_file_count": len(appended), "historical_checks": len(original["checks"]),
            "historical_review_bytes_unchanged": True, "historical_line_138_still_unassessed": missing_old,
            "structural_probe_validated": True, "probe_scientific_decision": "unassessed",
            "new_review_published": False, "request_sent": False}


def replay(output, *, source=SOURCE, saved_review=REVIEW_SOURCE):
    """Run the recorded evidence boundary only; helpers are developer interfaces."""
    source, saved_review, output = source.resolve(), saved_review.resolve(), output.resolve()
    if output.exists():
        raise FileExistsError(f"Replay output already exists; preserve it: {output}")
    if output.is_relative_to(source) or output.is_relative_to(saved_review):
        raise ValueError("Replay output must not be inside original saved evidence")
    verified, original_paths = _closure_files(source)
    args = _json(saved_review / "live/arguments.json")
    packet_paths = [saved_review / "live" / name
                    for name in ("arguments.json", "final-answer-002.txt", "review.json")]
    sparse_paths = _selected_frozen_paths(saved_review / "workspace", args)
    for original in sparse_paths:
        complete = source / original.relative_to(saved_review / "workspace")
        if original.read_bytes() != complete.read_bytes():
            raise ValueError(f"Sparse review packet differs from complete frozen source: {original}")
    protected_paths = original_paths + packet_paths + sparse_paths
    before = _hashes(protected_paths)
    output.mkdir(parents=True)
    _save(output / "source-hashes-before.json", before)
    root = output / "workspace"
    _copy_closure(source, root, original_paths)
    copied_paths = [root / original.relative_to(source) for original in original_paths]
    copied_before = _hashes(copied_paths)
    (output / "AUTHOR_NOTE.txt").write_text(
        "這是工程作者選題並編寫形式化的離線重播，並非新的 LLM 回答或科學審查。\n"
        "原報告第 138 行是被檢查的主張；公式說明第 10–12 行提供定性前提。\n"
        "正值、可比較情境與 E1<E2 是明列的人為假設，並非來源觀測。\n"
        "只檢查共同反比常數的必要條件 E1*r1=E2*r2，不能由此認證完整反比律或 EOP 模型。\n"
        "求解器輸出僅是數學反例，不是虛構材料樣本，也不是觀測數據。\n"
        "來源閉包只複製 record.json 與其 manifest 列明的快照，沒有複製可變工作檔。\n"
        "新審查請求只準備並保存，未發送；獨立 structural-probe 的 decision 為 unassessed，"
        "只驗證引用結構，沒有發布正式 review。原審查 11 項保留原位元組。\n",
        encoding="utf-8",
    )
    ctx = _context(root)
    with _offline_only() as blocked_attempts:
        problem = inference.validate_input(_problem())
        inference.validate_sources(root, problem)
        tool, = [tool for tool in TOOLS if tool.name == "check_inference"]
        result = tool.execute(problem, ctx)
        receipt = json.loads(result.output)
        _save(output / "tool-receipt.json", receipt)
        committed = records.read_record(root, receipt["record_path"])
        assert committed["kind"] == "implementation"
        assert committed["depends_on"] == [REPORT_REF, FORMULA_REF]
        result_entry, = [entry for entry in committed["files"] if entry["source_path"].endswith("/result.json")]
        outcome = _json(records.local_path(root, receipt["record_path"]).parent / result_entry["snapshot"])
        witnesses = _verify_countermodels(outcome)
        _save(output / "independent-rational-witness-checks.json", witnesses)
        boundary = _review_boundary(root, ctx, saved_review, output, receipt)
        assert not blocked_attempts, "Offline replay attempted a model/network call"
    after = _hashes(protected_paths)
    copied_after = _hashes(copied_paths)
    _save(output / "source-hashes-after.json", after)
    assert before == after, "Original evidence was modified"
    assert copied_before == copied_after, "Copied original evidence was modified"
    summary = {
        "scope": "Developer-authored, source-bound offline inference and review-citation boundary replay",
        "entry": "registered check_inference Tool.execute with existing permission Broker",
        "source_record_count": len(verified), "source_snapshot_count": len(original_paths) - len(verified),
        "source_byte_count": sum(path.stat().st_size for path in original_paths),
        "original_evidence_unchanged": True, "copied_original_evidence_unchanged": True,
        "record_path": receipt["record_path"], "solver_version": outcome["solver_version"],
        "query_statuses": {query["name"]: query["status"] for query in outcome["queries"]},
        "independent_exact_rational_witness_checks": True, "blocked_network_attempts": blocked_attempts,
        "live_model_calls": 0, "scientific_acceptance": False, "full_end_to_end_passed": False,
        "remaining_unproven_boundary": (
            "A live scientific author must select and justify the formalization, and a newly commissioned reviewer "
            "must interpret the new source-bound evidence. No live model or full workflow was executed."
        ),
        "review_boundary": boundary,
    }
    _save(output / "offline-summary.json", summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT,
                        help="New developer diagnostic folder; existing evidence is never overwritten")
    args = parser.parse_args(argv)
    result = replay(args.output)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
