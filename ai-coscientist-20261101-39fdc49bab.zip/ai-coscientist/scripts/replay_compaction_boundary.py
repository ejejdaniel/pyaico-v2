"""Replay two saved requests without running any returned tools or modifying a session."""

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import time

import httpx

from opencode.compaction import _summary_messages


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def prepare_request(original, archived, archive_path):
    assert original["messages"][0]["role"] == "system"
    assert original["messages"][-1]["role"] == "user"
    wire_history = original["messages"][1:-1]
    batch = deepcopy(archived[:len(wire_history)])
    assert len(batch) == len(wire_history)
    for stored, wire in zip(batch, wire_history):
        assert stored["role"] == wire["role"]
        if wire["role"] == "tool":
            assert stored["tool_call_id"] == wire["tool_call_id"]
            assert stored["content"] in wire["content"]
            stored["content"] = wire["content"]
        elif wire["role"] == "assistant":
            # The saved wire request owns protocol visibility. Do not restore
            # reasoning that was deliberately absent from that request.
            stored.pop("reasoning_content", None)
            reasoning = wire.get("reasoning_content", wire.get("reasoning"))
            if reasoning is not None:
                stored["reasoning_content"] = reasoning
    rebuilt = _summary_messages(batch, archive_path)
    assert len(rebuilt) == len(wire_history) + 1
    for i, (old, new) in enumerate(zip(wire_history, rebuilt)):
        if old["role"] == "assistant":
            protocol_fields = {"reasoning", "reasoning_content"}
            assert {k: v for k, v in old.items() if k not in protocol_fields | {"content"}} == {
                k: v for k, v in new.items() if k not in protocol_fields | {"content"}}
            rebuilt[i] = dict(old, content=new["content"])
        elif old["role"] == "tool":
            # The product compactor bounds old tool outputs to 2000 UTF-16
            # units. Only that content projection may change in this replay.
            assert {k: v for k, v in old.items() if k != "content"} == {
                k: v for k, v in new.items() if k != "content"}
        else:
            assert old == new
    prepared = deepcopy(original)
    prepared["messages"] = [deepcopy(original["messages"][0]), *rebuilt]
    assert {k: v for k, v in prepared.items() if k != "messages"} == {
        k: v for k, v in original.items() if k != "messages"}
    return prepared


def continuation_request(original, summary, archive_path, *, reasoning=None, summary_model=None):
    assert isinstance(summary, str)
    prepared = deepcopy(original)
    checkpoints = [i for i, m in enumerate(prepared["messages"])
                   if m["role"] == "assistant" and (m.get("content") or "").startswith("<previous-summary>\n")]
    if not checkpoints:
        checkpoints = [i for i, message in enumerate(prepared["messages"]) if i > 0
                       and message["role"] == "assistant"
                       and prepared["messages"][i - 1] == {"role": "user", "content": "What did we do so far?"}]
    assert len(checkpoints) == 1, "Saved request must identify exactly one summary boundary."
    checkpoint = prepared["messages"][checkpoints[0]]
    checkpoint["content"] = summary
    field = "reasoning" if "reasoning" in checkpoint else "reasoning_content"
    if summary_model and original.get("model") != summary_model:
        if reasoning and reasoning.strip():
            checkpoint["content"] = reasoning + ("\n\n" + summary if summary else "")
        if field in checkpoint:
            checkpoint[field] = ""
    elif reasoning is not None or field in checkpoint:
        checkpoint[field] = reasoning or ""
    return prepared


def exchange(client, base_url, payload, output, label):
    assert payload.get("stream") is not True, "This replay accepts saved non-streaming requests only."
    save(output / f"{label}.request.json", payload)
    started = time.monotonic()
    response = client.post(base_url.rstrip("/") + "/chat/completions", json=payload,
                           headers={"Authorization": "Bearer local"})
    (output / f"{label}.response.bin").write_bytes(response.content)
    meta = {"seconds": time.monotonic() - started, "http_status": response.status_code}
    save(output / f"{label}.meta.json", meta)
    response.raise_for_status()
    result = response.json()
    meta["usage"] = result.get("usage", {})
    meta["finish_reason"] = result["choices"][0].get("finish_reason")
    save(output / f"{label}.meta.json", meta)
    return result, meta


def execute(client, base_url, compact_request, answer_request, archive_path, output):
    output = Path(output)
    summary_response, summary_meta = exchange(client, base_url, compact_request, output, "compaction")
    summary = summary_response["choices"][0]["message"]
    if summary.get("tool_calls"):
        name = summary["tool_calls"][0].get("function", {}).get("name", "")
        raise ValueError(f"Tool call not allowed while generating summary: {name}")
    text = summary.get("content") or ""
    (output / "summary.md").write_text(text, encoding="utf-8")
    following = continuation_request(answer_request, text, archive_path,
                                     reasoning=summary.get("reasoning_content", summary.get("reasoning")),
                                     summary_model=compact_request.get("model"))
    answer_response, answer_meta = exchange(client, base_url, following, output, "continuation")
    answer = answer_response["choices"][0]["message"]
    (output / "answer.md").write_text(answer.get("content") or "", encoding="utf-8")
    result = {
        "calls": 2, "tools_executed": 0, "research_restarted": False,
        "compaction": summary_meta, "continuation": answer_meta,
        "returned_tool_calls": answer.get("tool_calls") or [],
        "has_text_answer": bool((answer.get("content") or "").strip()),
        "semantic_quality": "not_reviewed",
    }
    save(output / "result.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compaction-request", type=Path, required=True)
    parser.add_argument("--continuation-request", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base-url")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if args.execute and not args.base_url:
        parser.error("--execute requires an explicit --base-url")
    paths = [args.compaction_request, args.continuation_request, args.archive]
    originals = {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    old, answer, archived = (load(p) for p in paths)
    archive_path = str(args.archive.resolve())
    new = prepare_request(old, archived, archive_path)
    args.output.mkdir(parents=True, exist_ok=False)
    save(args.output / "prepared-compaction.json", new)
    source_messages = [m for m in old["messages"][1:-1] if m["role"] != "assistant"]
    projected_sources = [m for m in new["messages"][1:-1] if m["role"] != "assistant"]
    save(args.output / "boundary-checks.json", {
        "original_files": originals, "source_messages_unchanged": source_messages == projected_sources,
        "source_messages_sha256": digest(source_messages),
        "generation_controls_unchanged": True, "uses_product_summary_assembler": True,
        "continuation_policy": "replace only the summary; keep tools, human question, results and reasoning",
    })
    if args.execute:
        with httpx.Client(timeout=httpx.Timeout(600, connect=15)) as client:
            response = client.get(args.base_url.rstrip("/") + "/models")
            response.raise_for_status()
            if new["model"] not in [m["id"] for m in response.json()["data"]]:
                raise RuntimeError("The recorded model is not available; no model requests sent.")
            result = execute(client, args.base_url, new, answer, archive_path, args.output)
            print(json.dumps({k: v for k, v in result.items() if k != "returned_tool_calls"}, ensure_ascii=False))
    for p in paths:
        assert hashlib.sha256(p.read_bytes()).hexdigest() == originals[str(p.resolve())]
    print(str(args.output.resolve()))


if __name__ == "__main__":
    main()
