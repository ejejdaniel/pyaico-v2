"""Replay one saved model request under different decoding settings and classify the replies.

Used to separate causes of the v9 repeat loop: the same saved input is sent again with
only temperature and the reasoning switch changed. Each reply is classified as
repeat (the same tool call that was just refused), other_tool, text, or no_result
(output limit or nothing usable). Results go to a JSONL file; nothing is changed in
the original run.

    python scripts/replay_decoding_conditions.py WIRE_DIR OUT.jsonl --repeats 5
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import time

import httpx

CONDITIONS = [
    {"name": "t0_noreason", "temperature": 0, "reasoning": False},
    {"name": "t06_noreason", "temperature": 0.6, "reasoning": False},
    {"name": "t0_reason", "temperature": 0, "reasoning": True},
    {"name": "t06_reason", "temperature": 0.6, "reasoning": True},
]


def last_call(body):
    """The tool call that the last tool message answered (the refused one)."""
    calls = {}
    for message in body["messages"]:
        for call in message.get("tool_calls") or []:
            calls[call["id"]] = call["function"]
    last = body["messages"][-1]
    function = calls.get(last.get("tool_call_id"))
    return None if function is None else (function["name"], json.loads(function["arguments"] or "{}"))


def stream(url, body, key, logprobs=None):
    content, reasoning, calls, finish, usage = [], [], {}, None, None
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    with httpx.Client(timeout=httpx.Timeout(900.0, connect=30.0)) as client:
        with client.stream("POST", url, json=body, headers=headers) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                chunk = json.loads(data)
                usage = chunk.get("usage") or usage
                for choice in chunk.get("choices") or []:
                    if logprobs is not None:
                        logprobs.extend((choice.get("logprobs") or {}).get("content") or [])
                    delta = choice.get("delta") or {}
                    content.append(delta.get("content") or "")
                    reasoning.append(delta.get("reasoning_content") or delta.get("reasoning") or "")
                    for item in delta.get("tool_calls") or []:
                        slot = calls.setdefault(item.get("index", 0), {"name": "", "arguments": ""})
                        function = item.get("function") or {}
                        slot["name"] += function.get("name") or ""
                        slot["arguments"] += function.get("arguments") or ""
                    finish = choice.get("finish_reason") or finish
    return "".join(content), "".join(reasoning), [calls[i] for i in sorted(calls)], finish, usage


def classify(text, calls, finish, refused):
    if finish in ("length", "max_tokens"):
        return "no_result"
    for call in calls:
        try:
            arguments = json.loads(call["arguments"] or "{}")
        except ValueError:
            arguments = None
        if refused and call["name"] == refused[0] and arguments == refused[1]:
            return "repeat"
    if calls:
        return "other_tool"
    return "text" if text.strip() else "no_result"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("wire", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--url", default="http://192.168.1.118:8000/v1/chat/completions")
    parser.add_argument("--conditions", nargs="*")
    parser.add_argument("--temperatures", nargs="*", type=float,
                        help="instead of the fixed conditions, these temperatures with reasoning off")
    parser.add_argument("--logprobs", action="store_true", help="one call per condition, saving token logprobs")
    args = parser.parse_args()
    base = json.loads((args.wire / "request.body.json").read_text(encoding="utf-8"))
    refused = last_call(base)
    key = os.environ.get("LOCAL_OPENAI_API_KEY")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    chosen = [c for c in CONDITIONS if not args.conditions or c["name"] in args.conditions]
    if args.temperatures:
        chosen = [{"name": f"t{t:g}_noreason", "temperature": t, "reasoning": False} for t in args.temperatures]
    if args.logprobs:
        for condition in chosen:
            body = dict(base, temperature=condition["temperature"], seed=1, logprobs=True, top_logprobs=5,
                        reasoning_effort="none")
            tokens = []
            text, reasoning, calls, finish, usage = stream(args.url, body, key, tokens)
            with args.out.open("a", encoding="utf-8") as output:
                output.write(json.dumps({"condition": condition["name"], "calls": calls, "finish_reason": finish,
                                         "logprobs": tokens}, ensure_ascii=False) + "\n")
            print(condition["name"], "tokens with logprobs:", len(tokens), flush=True)
        return
    for condition in chosen:
        for repeat in range(1, args.repeats + 1):
            # Without a seed this server returned the same sample every time (v9 replay, 2026-10-25),
            # so each repeat gets its own seed to make the repeats independent samples.
            body = dict(base, temperature=condition["temperature"], seed=1000 + repeat)
            if condition["reasoning"]:
                body.pop("reasoning_effort", None)
            else:
                body["reasoning_effort"] = "none"
            started = time.monotonic()
            try:
                text, reasoning, calls, finish, usage = stream(args.url, body, key)
                row = {"condition": condition["name"], "repeat": repeat,
                       "outcome": classify(text, calls, finish, refused), "finish_reason": finish,
                       "text_chars": len(text), "reasoning_chars": len(reasoning),
                       "calls": [{"name": c["name"], "arguments": c["arguments"][:300]} for c in calls],
                       "text_head": text[:300], "reasoning_tail": reasoning[-400:], "usage": usage}
            except Exception as error:  # record and continue; the run is an experiment
                row = {"condition": condition["name"], "repeat": repeat, "outcome": "error",
                       "error": type(error).__name__}
            row["elapsed_s"] = round(time.monotonic() - started, 1)
            with args.out.open("a", encoding="utf-8") as output:
                output.write(json.dumps(row, ensure_ascii=False) + "\n")
            print(condition["name"], repeat, row["outcome"], row.get("finish_reason"), row["elapsed_s"], flush=True)


if __name__ == "__main__":
    main()
