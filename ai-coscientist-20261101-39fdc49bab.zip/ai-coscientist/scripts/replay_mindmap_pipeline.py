"""Replay three saved author replies through S24; never contact a model.

Inputs are explicit saved events and original source files. This runner verifies
plumbing and rendering, not whether a current model can produce the replies.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
from types import SimpleNamespace
import threading
from unittest.mock import patch

from opencode.permission import Broker, Rule
from opencode.provider import Completion
from opencode.skills import discover
from researchkit import records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install


def _saved_events(events_path: Path):
    event_lines = events_path.read_bytes().splitlines(keepends=True)
    if len(event_lines) != 3:
        raise ValueError("Select exactly the three saved original stage events, in execution order")
    replies = []
    purposes = (
        "observe-source-for-method-embryos", "mindmap-upper-system-skeleton",
        "mindmap-architecture-audit-and-evidence-deepening",
    )
    previous_sequence = -1
    for raw, purpose in zip(event_lines, purposes):
        event = json.loads(raw)
        sequence = event.get("event_sequence")
        if (event.get("skill_id") != "mindmap-builder"
                or event.get("event_type") != "skill_workflow_model_turn"
                or event.get("purpose") != "skill-workflow.mindmap-builder." + purpose
                or type(sequence) is not int or sequence <= previous_sequence):
            raise ValueError("Saved events must be the original mindmap-builder stages in execution order")
        previous_sequence = sequence
        calls = [call for call in event["tool_calls"] if call["name"] == "return_skill_stage_result"]
        if len(calls) != 1 or not isinstance(calls[0]["arguments"], dict):
            raise ValueError("Each saved event must contain exactly one original stage-result object")
        replies.append(calls[0]["arguments"])
    return event_lines, replies


def replay(events_path: Path, task_path: Path, source_paths: list[Path], output: Path) -> dict:
    event_lines, replies = _saved_events(events_path)
    paths = [task_path, *source_paths]
    if len({path.name for path in paths}) != len(paths):
        raise ValueError("Explicit source basenames must be unique for this replay")
    source_bytes = [(path, path.read_bytes()) for path in paths]
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "workspace"
    workspace.mkdir()
    install(workspace)
    inputs = workspace / "inputs"
    inputs.mkdir()
    choices, source_receipts = [], []
    for index, (source, raw) in enumerate(source_bytes):
        target = inputs / source.name
        target.write_bytes(raw)
        saved = records.publish(workspace, kind="task" if index == 0 else "evidence",
                                title=source.name, files=[target.relative_to(workspace).as_posix()],
                                depends_on=[])
        source_receipts.append(saved)
        choices.append({"record_ref": saved["record_path"], "source_path": saved["files"][0]["source_path"]})
    ctx = SimpleNamespace(
        directory=workspace, worktree=workspace, session_id="saved-mindmap-offline-replay",
        abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")], temperature=0),
        app=SimpleNamespace(permissions=Broker(auto=True),
                            skills=discover(workspace, workspace, {})),
    )
    args = {
        "scope": "依明選任務與原始來源建立方法心智圖。本次由離線傳輸替身回放保存的三階段回答，"
                 "只驗證程序、保存與繪圖接入，不代表新模型的科研判斷。",
        "task_ref": source_receipts[0]["record_path"], "files": choices,
    }
    (output / "tool-input.json").write_bytes(records.encoded(args))
    count = 0

    def complete(_ctx, *, system, messages):
        nonlocal count
        if count >= len(replies):
            raise AssertionError("Unexpected repair/additional model request in the saved replay")
        count += 1
        request = {"system": system, "messages": messages}
        (output / f"stage-{count}-request.json").write_bytes(records.encoded(request))
        (output / f"stage-{count}-original-event.json").write_bytes(event_lines[count - 1])
        # Only adapt the old tool-result transport to the new text JSON transport.
        # The scientific object is unchanged.
        return Completion(text=json.dumps(replies[count - 1], ensure_ascii=False),
                          finish_reason="stop", model="saved-reply-offline")

    with patch("researchkit.mindmap.complete_once", side_effect=complete), patch(
            "socket.create_connection", side_effect=AssertionError("Offline replay must not use the network")):
        tool = next(tool for tool in TOOLS if tool.name == "research_mindmap")
        receipt = json.loads(tool.execute(args, ctx).output)
    if count != 3:
        raise AssertionError("The actual generation entry did not execute all three stages")
    (output / "mindmap-receipt.json").write_bytes(records.encoded(receipt))
    formal = next(item for item in receipt["files"] if Path(item["source_path"]).name == "mindmap.json")
    if json.loads(Path(formal["snapshot"]).read_bytes()) != replies[2]:
        raise AssertionError("Saved final map differs from the original stage reply")
    for n in range(1, 4):
        request = json.loads((output / f"stage-{n}-request.json").read_bytes())
        message = request["messages"][0]["content"]
        for source, raw in source_bytes:
            if json.dumps(raw.decode("utf-8-sig"), ensure_ascii=False) not in message:
                raise AssertionError(f"Stage {n} did not retain the complete selected source: {source}")
    report_source = workspace / "report.md"
    report_source.write_text(
        "# 保存心智圖的離線程序回放\n\n"
        "本報告展示舊版保存的模型結果經新入口、凍結紀錄與繪圖器接入的內容。"
        "三階段回答均來自既有紀錄；沒有發出新的模型請求，也沒有重新進行科研計算。\n\n"
        "下方心智圖與完整方法定義由同一份已核對的正式 JSON 產生，沒有人工補圖或改寫方法。"
        "原紀錄的架構與深化結果相同，因此此回放不證明深化改善科學品質。\n",
        encoding="utf-8",
    )
    selector = {"record_ref": receipt["record_path"], "source_path": formal["source_path"]}
    rendered = json.loads(next(tool for tool in TOOLS if tool.name == "render_report").execute(
        {"markdown_path": "report.md", "mindmap_files": [selector]}, ctx).output)
    (output / "report-receipt.json").write_bytes(records.encoded(rendered))
    # Keep the original event subset and hashes alongside inspectable outputs.
    shutil.copyfile(events_path, output / "original-events.jsonl")
    rows = [
        "# 心智圖生成與報告接入離線回放",
        "",
        "真實模型請求：0。新入口實際執行三個階段，傳輸替身按順序回傳原始保存的科學物件。",
        "這不是完整研究端到端測試，也不驗證模型能力或科學結論。",
        "",
        f"- 保存事件來源：`{events_path.resolve()}`",
        f"- 保存事件 SHA-256：`{records.digest(events_path.read_bytes())}`",
        f"- 新心智圖紀錄：`{receipt['record_path']}`",
        f"- HTML：`{rendered['html_path']}`",
        f"- PDF：`{rendered['pdf_path']}`",
        f"- PDF 頁數：{rendered['pages']}",
        "",
        "每階段的 request 檔是新技能實際組出的 system/messages，未傳給任何模型。"
        "original-event 檔保留舊版實際回覆，不冒充本次新模型回覆。",
        "",
        "## 原始來源",
        "",
    ]
    rows.extend(f"- `{source.resolve()}`：`{records.digest(raw)}`，{len(raw)} bytes"
                for source, raw in source_bytes)
    (output / "README.md").write_text("\n".join(rows) + "\n", encoding="utf-8")
    return rendered


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--task", type=Path, required=True)
    parser.add_argument("--source", action="append", type=Path, default=[])
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()
    print(json.dumps(replay(options.events, options.task, options.source, options.output),
                     ensure_ascii=False, indent=2))
