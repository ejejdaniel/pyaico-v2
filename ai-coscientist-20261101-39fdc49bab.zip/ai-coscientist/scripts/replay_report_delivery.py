"""Scripted offline saved-report delivery through native App/Loop and tools.

This is a private boundary diagnostic, not a research workflow or an autonomous
writing test. The supplied Markdown is a saved human-edited draft (the v6 case
was edited in the current conversation), never a new model completion. Only
explicitly selected manifests/snapshots are copied; historical settings, secrets,
sessions and other workspace files are not opened. CLI runs use the real local
PDF exporter. Unit tests may stub only its final export_pdf function.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch
from urllib.parse import quote


USED_TOOLS = {"skill", "read", "write", "render_report"}
FINAL_CONTROL = "離線腳本已消費報告工具回條；沒有新的模型寫作、科學審查或全流程驗收。"
ERROR_CONTROL = "離線腳本已保存失敗回條並停止；沒有重試或宣稱交付完成。"
COMPANION_LINK = "../formal/report.html"


def _json(path):
    return json.loads(Path(path).read_bytes().decode("utf-8-sig"))


def render_arguments(response: Path) -> dict:
    """Use only saved tool arguments, not the saved model's completion claims."""
    calls = [call for call in _json(response).get("tool_calls", [])
             if call.get("name") == "render_report"]
    if len(calls) != 1:
        raise ValueError("Saved response must contain exactly one render_report call")
    arguments = calls[0]["arguments"]
    if (not isinstance(arguments, dict) or "markdown_path" not in arguments
            or set(arguments) - {"markdown_path", "evidence_files", "mindmap_files"}):
        raise ValueError("Saved render_report arguments do not match the existing contract")
    from researchkit.report_evidence import validate_choices
    for field in ("evidence_files", "mindmap_files"):
        validate_choices(arguments.get(field, []), label=field)
    return arguments


def selected_paths(workspace: Path, arguments: list[dict]) -> list[Path]:
    """Resolve selected bytes with the real resolver; never follow dependencies."""
    from researchkit.report_evidence import resolve
    from researchkit.records import local_path
    choices = list({(item["record_ref"], item["source_path"]): item
                    for args in arguments for field in ("evidence_files", "mindmap_files")
                    for item in args.get(field, [])}.values())
    resolve(workspace, choices)
    paths = []
    for choice in choices:
        manifest = local_path(workspace, choice["record_ref"])
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == choice["source_path"]]
        paths.extend((manifest, local_path(manifest.parent, entry["snapshot"])))
    return list(dict.fromkeys(paths))


def adapt_companion(text: str, markdown_path: Path, formal_html: Path) -> tuple[str, dict]:
    """Adapt only the previously authored HTML target, preserving all fragments."""
    from scripts.replay_research_review_handoff import _sha
    target = quote(Path(os.path.relpath(formal_html, markdown_path.parent)).as_posix(), safe="/")
    count = text.count(COMPANION_LINK)
    if not count or target in text:
        raise ValueError("Companion needs unambiguous existing ../formal/report.html links")
    adapted = text.replace(COMPANION_LINK, target)
    if adapted.replace(target, COMPANION_LINK) != text:
        raise AssertionError("Companion adaptation changed more than the link target")
    return adapted, {
        "operation": "Mechanical link-target adaptation from the actual formal render receipt",
        "old_target": COMPANION_LINK, "new_target": target, "occurrences": count,
        "original_sha256": _sha(text.encode("utf-8")),
        "adapted_sha256": _sha(adapted.encode("utf-8")),
        "body_equal_after_reversing_target_adaptation": True,
        "new_model_output": False, "original_saved_draft_modified": False,
    }


def replay(source_workspace: Path, response: Path, markdown: Path, output: Path,
           commission: str, *, companion_response: Path | None = None,
           companion_markdown: Path | None = None) -> dict:
    """Exercise native skill/read/write/render and the next model-input boundary."""
    from scripts.replay_research_review_handoff import _jsonable, _offline_network, _save, _sha
    from scripts.setup_research_workspace import install
    import researchkit

    source_workspace, response, markdown, output = [Path(path).resolve()
        for path in (source_workspace, response, markdown, output)]
    if bool(companion_response) != bool(companion_markdown):
        raise ValueError("Companion response and saved Markdown must be supplied together")
    if not isinstance(commission, str) or not commission.strip():
        raise ValueError("An explicit nonblank diagnostic commission is required")
    sources = [(response, markdown)]
    if companion_response:
        sources.append((Path(companion_response).resolve(), Path(companion_markdown).resolve()))
    arguments = [render_arguments(item[0]) for item in sources]
    selected = selected_paths(source_workspace, arguments)
    skills_root = Path(researchkit.__file__).parent / "skills"
    guidance = [skills_root / "scientific-report-writer/SKILL.md",
                skills_root / "scientific-report-writer/references/report-delivery.md"]
    originals = [*selected, *guidance, *(p for pair in sources for p in pair)]
    if (output.exists() or output.is_relative_to(source_workspace)
            or source_workspace.is_relative_to(output)
            or any(p.is_relative_to(output) for p in originals)):
        raise ValueError("Output must be new and separate from the explicitly selected sources")
    original_bytes = {path: path.read_bytes() for path in originals}
    bodies = [original_bytes[body].decode("utf-8") for _, body in sources]
    if any(not body.strip() for body in bodies):
        raise ValueError("Saved report Markdown is empty; no demonstration fallback")
    before = {str(path): _sha(raw) for path, raw in original_bytes.items()}
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "workspace"
    (workspace / ".git").mkdir(parents=True)
    for path in selected:
        destination = workspace / path.relative_to(source_workspace)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(original_bytes[path])
    saved_inputs = []
    for index, (_, source) in enumerate(sources):
        destination = workspace / "saved-inputs" / ("formal.md" if index == 0 else "companion.md")
        destination.parent.mkdir(exist_ok=True)
        destination.write_bytes(original_bytes[source])
        saved_inputs.append(destination)
        (output / f"historical-response-{index + 1}.json").write_bytes(original_bytes[sources[index][0]])
    (output / "outer-requests").mkdir()
    (output / "commission.txt").write_text(commission, encoding="utf-8")
    _save(output / "source-hashes.json", before)
    _save(output / "historical-render-arguments.json", arguments)
    _save(output / "selected-files.json", [path.relative_to(source_workspace).as_posix() for path in selected])
    env = {}
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                 "XDG_STATE_HOME", "XDG_CACHE_HOME", "TEMP", "TMP"):
        folder = output / name.lower()
        folder.mkdir()
        env[name] = str(folder)
    env.update(OPENCODE_DISABLE_CLAUDE_CODE_PROMPT="1", OPENCODE_DISABLE_PROJECT_CONFIG="0")
    result = {
        "scope": "Scripted offline native report-delivery boundary replay",
        "outer_provider": "scripted_offline_test_provider",
        "draft_origin": "Saved human-edited Markdown; v6 was edited in the current conversation",
        "autonomous_skill_selection_proven": False, "autonomous_writing_quality_proven": False,
        "scientific_acceptance": False, "full_end_to_end_passed": False,
        "new_model_calls": 0, "live_http_calls": 0, "visual_inspection_performed": False,
        "guidance_in_next_model_input": {}, "read_files_in_next_model_input": [],
        "render_receipts_consumed": [], "exposed_tools_by_request": [],
        "tool_scope_note": "Native edit permission also exposes editing aliases; only skill/read/write/render_report are scripted",
        "source_copy_scope": "Only explicitly selected manifests/snapshots and supplied saved Markdown",
        "earliest_remaining_boundary": "native_skill_to_next_model_input",
        "delivery_acceptance_exercised": False,
    }
    requests, blocked, loopback, receipts = [], [], [], []
    store, session, failure = None, None, None

    def deny_http(request):
        blocked.append("HTTP request forbidden: " + str(request.url))
        raise AssertionError(blocked[-1])

    try:
        with patch.dict(os.environ, env), _offline_network(deny_http, blocked, loopback):
            from opencode.app import App
            from opencode.provider import Completion, ToolCall
            from opencode.store import Store

            install(workspace)
            config = {
                "model": "offline/scripted-report-replay",
                "provider": {"offline": {"options": {"baseURL": "https://replay.invalid/v1",
                    "apiKey": "offline-not-a-real-api-key"},
                    "models": {"scripted-report-replay": {"limit": {"context": 1048576, "output": 32000}}}}},
                "enabled_providers": ["offline"], "mcp": {}, "lsp": False, "skills": {},
                "permission": {"*": "deny", "read": "allow", "skill": "allow",
                               "edit": "allow", "render_report": "allow"},
                "agent": {"build": {"steps": 12}}, "default_agent": "build",
                "compaction": {"auto": False, "prune": False},
                "instructions": _json(workspace / ".opencode/opencode.json")["instructions"],
            }
            _save(output / "offline-config.json", config)
            store = Store(output / "session.db")
            app = App(workspace, store=store, auto_approve=False, config=config)
            app.generate_titles = False
            session = app.create_session(title="Scripted offline report delivery", model=config["model"])["id"]
            skill = app.skills["scientific-report-writer"]
            reference = skill.location.parent / "references/report-delivery.md"
            for origin, installed in zip(guidance, (skill.location, reference)):
                assert original_bytes[origin] == installed.read_bytes(), "Installed guidance changed during replay"
            outputs = [workspace / "sources/report_zh.md", workspace / "sources/report_zh_easy.md"]
            copied_sources = [workspace / path.relative_to(source_workspace) for path in selected]
            read_paths = [*copied_sources, *saved_inputs]
            pending = []

            def emit(calls):
                pending[:] = calls
                assert all(call.name in USED_TOOLS for call in calls)
                return Completion(tool_calls=calls, finish_reason="tool-calls")

            def call(call_id, name, args):
                return ToolCall(call_id, name, args)

            def outer(**kwargs):
                request = _jsonable(kwargs)
                request["_offline_diagnostic"] = {"provider": "scripted_offline_test_provider"}
                requests.append(request)
                step = len(requests)
                _save(output / "outer-requests" / f"request-{step:03}.json", request)
                result["exposed_tools_by_request"].append(sorted(t["name"] for t in kwargs.get("tools") or []))
                for previous in pending:
                    stored, = [m for m in store.messages(session)
                               if m.get("role") == "tool" and m.get("tool_call_id") == previous.id]
                    consumed, = [m for m in kwargs["messages"]
                                 if m.get("role") == "tool" and m.get("tool_call_id") == previous.id]
                    assert stored["content"] == consumed["content"], "Tool content changed before next input"
                    receipts.append(stored)
                    if stored.get("metadata", {}).get("error"):
                        _save(output / "error-receipt.json", stored)
                        result["earliest_remaining_boundary"] = previous.id + "_returned_error"
                        return Completion(text=ERROR_CONTROL, finish_reason="stop")
                    assert not stored.get("metadata", {}).get("truncated"), "Tool receipt was truncated"
                    if previous.name == "skill":
                        assert skill.body.strip() in consumed["content"]
                        result["guidance_in_next_model_input"]["SKILL.md"] = True
                    if previous.name == "read":
                        path = Path(previous.arguments["filePath"])
                        expected = "\n".join(f"{i}: {line}" for i, line in enumerate(
                            path.read_text(encoding="utf-8").splitlines(), 1))
                        assert expected in consumed["content"], "Read omitted or changed source lines"
                        if path == reference:
                            result["guidance_in_next_model_input"]["references/report-delivery.md"] = True
                        else:
                            result["read_files_in_next_model_input"].append(path.relative_to(workspace).as_posix())
                    if previous.name == "render_report":
                        rendered = json.loads(stored["content"])
                        result["render_receipts_consumed"].append(rendered)
                        _save(output / f"{previous.id}-receipt.json", stored)
                        _save(output / f"{previous.id}-consumption.json", request)
                pending.clear()
                if step == 1:
                    return emit([call("writer-skill", "skill", {"name": "scientific-report-writer"})])
                if step == 2:
                    return emit([call("delivery-reference", "read", {"filePath": str(reference)})])
                if step == 3:
                    result["earliest_remaining_boundary"] = "selected_sources_to_next_model_input"
                    return emit([call(f"source-{i:02}", "read", {"filePath": str(path)})
                                 for i, path in enumerate(read_paths)])
                if step == 4:
                    result["earliest_remaining_boundary"] = "saved_formal_write"
                    return emit([call("formal-write", "write", {"filePath": str(outputs[0]), "content": bodies[0]})])
                if step == 5:
                    assert outputs[0].read_bytes() == original_bytes[markdown], "Native write changed saved formal Markdown"
                    result["formal_written_bytes_exact"] = True
                    result["earliest_remaining_boundary"] = "formal_render_to_outer"
                    return emit([call("formal-render", "render_report", {**arguments[0], "markdown_path": str(outputs[0])})])
                if step == 6 and len(sources) == 2:
                    formal_html = Path(result["render_receipts_consumed"][0]["html_path"])
                    companion, adaptation = adapt_companion(bodies[1], outputs[1], formal_html)
                    _save(output / "companion-link-adaptation.json", adaptation)
                    result["companion_link_adaptation"] = adaptation
                    result["earliest_remaining_boundary"] = "adapted_companion_write"
                    return emit([call("companion-write", "write", {"filePath": str(outputs[1]), "content": companion})])
                if step == 7 and len(sources) == 2:
                    adaptation = result["companion_link_adaptation"]
                    assert outputs[1].read_bytes().decode("utf-8").replace(
                        adaptation["new_target"], adaptation["old_target"]) == bodies[1]
                    result["companion_written_body_exact_except_target"] = True
                    result["earliest_remaining_boundary"] = "companion_render_to_outer"
                    return emit([call("companion-render", "render_report", {**arguments[1], "markdown_path": str(outputs[1])})])
                assert step == (8 if len(sources) == 2 else 6), "Unexpected inference or retry"
                assert len(result["render_receipts_consumed"]) == len(sources)
                result["earliest_remaining_boundary"] = "autonomous_authorship_scientific_review_and_visual_inspection_not_exercised"
                result["report_tool_handoff_passed"] = True
                return Completion(text=FINAL_CONTROL, finish_reason="stop")

            app.provider.complete = outer
            result["app_result"] = app.prompt(session, commission)
            assert not blocked, "Forbidden network operation attempted"
    except BaseException as exc:
        failure = exc
        result["diagnostic_error"] = {"type": type(exc).__name__, "message": str(exc)}
    finally:
        if store is not None:
            if session is not None:
                history = store.messages(session)
                _save(output / "session-history.json", history)
                _save(output / "session.json", store.get_session(session))
                result["actual_tools_used"] = sorted({call["name"] for m in history for call in m.get("tool_calls") or []})
            store.close()
        after = {str(path): _sha(path.read_bytes()) for path in original_bytes}
        result["source_unchanged"] = before == after
        result["selected_copies_unchanged"] = all(
            (workspace / path.relative_to(source_workspace)).read_bytes() == original_bytes[path] for path in selected)
        result["pdf_files_exist"] = [Path(item["pdf_path"]).is_file() for item in result["render_receipts_consumed"]]
        result["outer_request_count"] = len(requests)
        result["blocked_network_attempts"] = blocked
        result["loopback_wakeup_connections"] = loopback
        _save(output / "source-integrity.json", {"before": before, "after": after, "unchanged": before == after})
        _save(output / "tool-receipts.json", receipts)
        _save(output / "outer-requests.json", requests)
        _save(output / "result.json", result)
    if failure:
        raise failure
    assert result["source_unchanged"] and result["selected_copies_unchanged"]
    assert set(result["actual_tools_used"]) <= USED_TOOLS
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-workspace", type=Path, required=True)
    parser.add_argument("--response", type=Path, required=True)
    parser.add_argument("--markdown", type=Path, required=True)
    parser.add_argument("--companion-response", type=Path)
    parser.add_argument("--companion-markdown", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--commission", type=Path, required=True)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    sys.path[:0] = [str(project), str(project / "src")]
    result = replay(args.source_workspace, args.response, args.markdown, args.output,
                    args.commission.read_text(encoding="utf-8-sig"),
                    companion_response=args.companion_response, companion_markdown=args.companion_markdown)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result.get("report_tool_handoff_passed"):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
