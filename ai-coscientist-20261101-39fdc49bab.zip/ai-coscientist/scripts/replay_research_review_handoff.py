"""Offline saved-response replay through Common, research_review, and outer input.

The outer provider below is a test script, not an autonomous planner. The review
provider and validators are real. Its offline HTTP transport wraps supported
historical OpenAI text completions in synthetic SSE framing for S26; this is not
an original stream capture. Original bytes are retained separately. Nothing here
judges scientific claims, executes research, or publishes a review/Final LCA.
All JSON emitted by this script is private diagnostic output.
"""

from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager
from dataclasses import asdict, is_dataclass
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import shutil
import socket
import sys
from unittest.mock import patch

import httpx


CAPTURE_FILES = (
    "arguments.json", "opencode.json", "request.body.json", "response.body.bin",
    "response-http.json", "parsed-completion.json",
)
ALLOWED_TOOLS = {"read", "skill", "research_review"}
AUDIT_WRITE_TOOLS = {"write", "edit"}
OFFLINE_KEY = "offline-replay-not-a-real-api-key"
FINAL_CONTROL = "離線回放已到達外層結案請求；未生成新的科學結論。"
ERROR_CONTROL = "離線回放已保存錯誤回條並停止；未重試、未發布、未生成新的科學結論。"


def _save(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _files(root: Path):
    """Do not follow saved symlinks/junctions into another workspace."""
    for path in sorted(root.iterdir()):
        if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
            raise ValueError(f"Saved workspace contains a link: {path}")
        if path.is_dir():
            yield from _files(path)
        elif path.is_file():
            yield path


def _hashes(root: Path) -> dict:
    return {p.relative_to(root).as_posix(): _sha(p.read_bytes()) for p in _files(root)}


def _source_hashes(source: Path) -> dict:
    # Deliberately do not read settings.json or any other historical credential file.
    result = {name: _sha((source / name).read_bytes()) for name in CAPTURE_FILES}
    result.update({"workspace/" + name: digest for name, digest in _hashes(source / "workspace").items()})
    return result


_OMIT = object()


def _jsonable(value):
    """Keep request data; omit callbacks/events rather than stringify them."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if is_dataclass(value) and not isinstance(value, type):
        return _jsonable(asdict(value))
    if isinstance(value, dict):
        return {key: converted for key, item in value.items()
                if isinstance(key, str) and (converted := _jsonable(item)) is not _OMIT}
    if isinstance(value, (list, tuple)):
        return [converted for item in value if (converted := _jsonable(item)) is not _OMIT]
    return _OMIT


def _selected_files(workspace: Path, arguments: dict) -> list[dict]:
    from researchkit.records import local_path

    selected = []
    for locator in arguments["files"]:
        manifest_path = local_path(workspace, locator["record_ref"])
        manifest_bytes = manifest_path.read_bytes()
        assert _sha(manifest_bytes) == locator["record_ref"].split("/")[2], "Changed record identity"
        manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
        matches = [item for item in manifest["files"] if item["source_path"] == locator["source_path"]]
        assert len(matches) == 1, "Selection must resolve exactly one frozen file"
        item = matches[0]
        path = local_path(manifest_path.parent, item["snapshot"])
        raw = path.read_bytes()
        assert len(raw) == item["bytes"] and _sha(raw) == item["sha256"], "Changed selected snapshot"
        selected.append({"locator": locator, "path": path.relative_to(workspace).as_posix(),
                         "sha256": _sha(raw), "bytes": len(raw), "content": raw.decode("utf-8-sig")})
    return selected


def _expected_review_input(arguments: dict, selected: list[dict]) -> str:
    # Literal transport framing, not interpretation of any scientific content.
    sections = ["Review commission (scope):", json.dumps(arguments["scope"], ensure_ascii=False),
                "Reviewed record references (reviewed_refs):",
                json.dumps(arguments["reviewed_refs"], ensure_ascii=False)]
    for number, item in enumerate(selected, 1):
        lines = item["content"].replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if lines[-1] == "":
            lines.pop()
        sections.extend(["Selected frozen file:",
                         json.dumps({"file_id": f"F{number}", **item["locator"]}, ensure_ascii=False),
                         "Numbered UTF-8 lines (JSON array; numbers are not source content):",
                         json.dumps(list(enumerate(lines, 1)), ensure_ascii=False)])
    return "\n".join(sections)


def _historical_content(raw: bytes):
    """Extract protocol content for byte equality checks only, without judging it."""
    try:
        data = json.loads(raw)
        if isinstance(data, dict) and isinstance(data.get("choices"), list) and data["choices"]:
            return data["choices"][0]["message"]["content"]
        if isinstance(data, dict) and isinstance(data.get("content"), list):
            return "".join(block.get("text") or "" for block in data["content"]
                           if block.get("type") == "text")
    except (ValueError, KeyError, TypeError, IndexError):
        pass
    return None


def _synthetic_openai_sse(raw: bytes) -> bytes:
    """Reframe one saved text completion, never infer or repair its contents."""
    data = json.loads(raw)
    choices = data.get("choices") if isinstance(data, dict) else None
    if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
        raise ValueError("Offline SSE adaptation requires exactly one saved OpenAI completion")
    choice = choices[0]
    message = choice.get("message")
    if (not isinstance(message, dict) or message.get("role") != "assistant"
            or not isinstance(message.get("content"), str)):
        raise ValueError("Offline SSE adaptation requires a saved assistant text message")
    text_fields = {"content", "reasoning", "reasoning_content"}
    if any(message.get(name) is not None and not isinstance(message[name], str)
           for name in text_fields):
        raise ValueError("Offline SSE adaptation supports only literal text and reasoning")
    if any(value is not None for name, value in message.items() if name not in text_fields | {"role"}):
        raise ValueError("Offline SSE adaptation does not support additional message content")
    if "finish_reason" not in choice or not isinstance(choice["finish_reason"], (str, type(None))):
        raise ValueError("Offline SSE adaptation requires the original finish reason")
    if "usage" in data and data["usage"] is not None and not isinstance(data["usage"], dict):
        raise ValueError("Offline SSE adaptation requires an object-valued original usage")
    delta = {name: value for name, value in message.items() if name in text_fields}
    event = {"choices": [{"delta": delta, "finish_reason": choice["finish_reason"]}]}
    if "usage" in data:
        event["usage"] = data["usage"]
    return ("data: " + json.dumps(event, ensure_ascii=False, allow_nan=False)
            + "\n\ndata: [DONE]\n\n").encode("utf-8")


@contextmanager
def _offline_network(receive, blocked: list, loopback: list):
    """Guard before App construction; retain asyncio's local socket-pair wakeup."""
    original_client, original_async = httpx.Client, httpx.AsyncClient
    original_connect, original_connect_ex = socket.socket.connect, socket.socket.connect_ex
    original_sendto, original_getaddrinfo = socket.socket.sendto, socket.getaddrinfo

    def deny(*args, **kwargs):
        blocked.append("Unapproved real HTTP/socket operation")
        raise AssertionError(blocked[-1])

    def is_loopback(address):
        if not isinstance(address, tuple) or not address:
            return False
        try:
            return ipaddress.ip_address(address[0]).is_loopback
        except ValueError:
            return False

    def connect(sock, address):
        if not is_loopback(address):
            return deny()
        loopback.append({"operation": "connect", "address": list(address)})
        return original_connect(sock, address)

    def connect_ex(sock, address):
        if not is_loopback(address):
            return deny()
        loopback.append({"operation": "connect_ex", "address": list(address)})
        return original_connect_ex(sock, address)

    def sendto(sock, data, *args):
        if not args or not is_loopback(args[-1]):
            return deny()
        return original_sendto(sock, data, *args)

    def getaddrinfo(host, *args, **kwargs):
        if host != "localhost" and not is_loopback((host, 0)):
            return deny()
        return original_getaddrinfo(host, *args, **kwargs)

    def client(*args, **kwargs):
        if "transport" in kwargs:
            return deny()
        return original_client(*args, transport=httpx.MockTransport(receive),
                               **{**kwargs, "trust_env": False})

    def async_client(*args, **kwargs):
        if "transport" in kwargs:
            return deny()
        return original_async(*args, transport=httpx.MockTransport(receive),
                              **{**kwargs, "trust_env": False})

    with ExitStack() as stack:
        for target, replacement in (
            ("httpx.HTTPTransport.handle_request", deny),
            ("httpx.AsyncHTTPTransport.handle_async_request", deny),
            ("httpx.Client", client), ("httpx.AsyncClient", async_client),
            ("socket.create_connection", deny), ("socket.getaddrinfo", getaddrinfo),
            ("socket.socket.connect", connect), ("socket.socket.connect_ex", connect_ex),
            ("socket.socket.sendto", sendto),
        ):
            stack.enter_context(patch(target, replacement))
        yield


def _config(source_config: dict, workspace: Path) -> dict:
    from opencode.config import merge_config

    config = json.loads(json.dumps(source_config))
    if not isinstance(config.get("model"), str) or "/" not in config["model"]:
        raise ValueError("Saved capture must select an explicit provider/model")
    provider_id = config["model"].split("/", 1)[0]
    if provider_id not in (config.get("provider") or {}):
        raise ValueError("Saved capture must contain its selected provider configuration")
    for provider in config["provider"].values():
        options = provider.setdefault("options", {})
        options.pop("baseUrl", None)
        options["baseURL"], options["apiKey"] = "https://replay.invalid/v1", OFFLINE_KEY
    config["enabled_providers"] = [provider_id]
    config["mcp"], config["lsp"] = {}, False
    config["skills"] = {}  # Only locally installed guidance; no external directories.
    config["permission"] = {"*": "deny", **{name: "allow" for name in sorted(ALLOWED_TOOLS)}}
    # Common file permissions compare workspace-relative paths.
    config["permission"]["edit"] = {"*": "deny", ".research/review-runs": "allow",
                                    ".research/review-runs/*": "allow"}
    agent = config.setdefault("agent", {}).setdefault("build", {})
    agent["permission"] = config["permission"].copy()
    agent["steps"] = 8
    config["default_agent"] = "build"
    config["compaction"] = {**config.get("compaction", {}), "auto": False, "prune": False}
    installed = json.loads((workspace / ".opencode/opencode.json").read_text(encoding="utf-8"))
    config = merge_config(config, {"instructions": installed["instructions"]})
    return config


def replay(source: Path, output: Path, arguments: dict, commission: str) -> dict:
    """Replay one supplied commission and one saved HTTP response, without live I/O."""
    source, output = Path(source).resolve(), Path(output).resolve()
    if output.exists() or output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError("Output must be new and must not contain or be contained by source")
    if not isinstance(commission, str) or not commission.strip():
        raise ValueError("An explicit nonblank outer commission is required")
    from researchkit.reviewer import _selection
    _selection(arguments)
    arguments = json.loads(json.dumps(arguments))
    before = _source_hashes(source)
    original_arguments = json.loads((source / "arguments.json").read_text(encoding="utf-8-sig"))
    original_request_bytes = (source / "request.body.json").read_bytes()
    original_body = json.loads(original_request_bytes.decode("utf-8-sig"))
    source_config = json.loads((source / "opencode.json").read_text(encoding="utf-8-sig"))
    response_bytes = (source / "response.body.bin").read_bytes()
    response_http = json.loads((source / "response-http.json").read_text(encoding="utf-8-sig"))
    selected = _selected_files(source / "workspace", arguments)
    expected_input = _expected_review_input(arguments, selected)
    historical_content = _historical_content(response_bytes)
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "workspace"
    shutil.copytree(source / "workspace", workspace)
    copied_before = _hashes(workspace)
    assert copied_before == {p.removeprefix("workspace/"): h for p, h in before.items()
                             if p.startswith("workspace/")}, "Workspace copy changed source bytes"
    assert all((workspace / item["path"]).read_bytes() == (source / "workspace" / item["path"]).read_bytes()
               for item in selected), "Selected source bytes changed in the copy"
    (workspace / ".git").mkdir(exist_ok=True)
    (output / "outer-requests").mkdir()
    _save(output / "source-hashes.json", before)
    _save(output / "arguments.json", arguments)
    _save(output / "historical-arguments.json", original_arguments)
    (output / "historical-request.body.json").write_bytes(original_request_bytes)
    _save(output / "selected-files.json", [{k: v for k, v in item.items() if k != "content"} for item in selected])
    (output / "commission.txt").write_text(commission, encoding="utf-8")
    blocked, loopback, http_requests, outer_requests = [], [], [], []
    result = {
        "scope": "Scripted offline Common -> research_review -> outer consumption boundary replay",
        "outer_provider": "scripted_offline_test_provider",
        "review_response_origin": "historical_response_bytes",
        "autonomous_skill_selection_proven": False, "scientific_acceptance": False,
        "full_end_to_end_passed": False, "live_http_calls": 0,
        "historical_http_replays": 0, "request_scope_unchanged": arguments["scope"] == original_arguments["scope"],
        "request_arguments_unchanged": arguments == original_arguments,
        "request_body_unchanged": None, "review_receipt_error": None,
        "review_receipt_truncated": None, "provider_to_store_content_exact": None,
        "store_to_outer_content_exact": None, "outer_final_context_captured": False,
        "source_hash_scope": [*CAPTURE_FILES, "workspace/** (all regular files; no links)"],
        "source_unchanged": None, "selected_files_unchanged": None,
        "earliest_remaining_boundary": "scripted_outer_to_materializer_skill",
        "no_new_scientific_conclusion": True,
        "preflight_validation": "Selection and frozen-byte integrity checked before App; rejection here is not a runtime handoff test",
        "delivery_acceptance_exercised": False, "selected_delivery_created": False,
        "delivery_acceptance_note": "research_record is denied; this new session does not select a delivery or exercise delivery acceptance",
    }
    env = {}
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                 "XDG_STATE_HOME", "XDG_CACHE_HOME", "TEMP", "TMP"):
        folder = output / name.lower()
        folder.mkdir()
        env[name] = str(folder)
    env["OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"] = "1"
    env["OPENCODE_DISABLE_PROJECT_CONFIG"] = "0"
    store, session, failure = None, None, None

    def receive(request):
        assert request.method == "POST" and request.url.host == "replay.invalid", "Unexpected HTTP request"
        assert request.url.path in {"/v1/chat/completions", "/v1/messages"}, "Directory/catalog download is forbidden"
        assert not http_requests, "Review replay must issue exactly one HTTP request, without retries"
        assert (request.headers.get("authorization") == "Bearer " + OFFLINE_KEY
                or request.headers.get("x-api-key") == OFFLINE_KEY), "Only the explicit offline key is permitted"
        body = json.loads(request.content)
        http_requests.append(body)
        (output / "request.body.bin").write_bytes(request.content)
        _save(output / "request.body.json", body)
        assert not body.get("tools"), "Review must be a single no-tools completion"
        openai_stream = request.url.path == "/v1/chat/completions"
        if openai_stream:
            assert body.get("stream") is True, "S26 OpenAI review must use the existing stream transport"
        else:
            assert not body.get("stream"), "Anthropic review retains the non-streaming transport"
        users = [m for m in body["messages"] if m.get("role") == "user"]
        assert len(users) == 1 and users[0].get("content") == expected_input, "HTTP scope/files differ from supplied arguments"
        assert len(body["messages"]) == (1 if request.url.path.endswith("/messages") else 2), "Parent history leaked into review"
        for field in ("model", "max_tokens", "temperature"):
            assert body.get(field) == original_body.get(field), f"Saved provider parameter changed: {field}"
        result["request_body_unchanged"] = body == original_body
        if result["request_body_unchanged"] and result["request_arguments_unchanged"]:
            result["scenario"] = "exact_saved_request"
            result["scenario_note"] = "原請求內容與保存請求相同；回覆仍為歷史輸出，沒有新模型推論。"
        elif not result["request_arguments_unchanged"]:
            result["scenario"] = "changed_commission_with_historical_response"
            result["scenario_note"] = "新委託（若為窄委託，即新窄委託）的合成接線情境，回覆仍為歷史廣責任輸出；不是新委託的新審查回覆。"
        else:
            result["scenario"] = "changed_request_with_historical_response"
            result["scenario_note"] = "審查參數相同，但完整 HTTP 請求已改變；回覆仍為歷史輸出，不代表修改後指引的新審查。"
        _save(output / "request-comparison.json", {
            key: result[key] for key in ("request_scope_unchanged", "request_arguments_unchanged",
                                        "request_body_unchanged", "scenario", "scenario_note")})
        (output / "response.body.bin").write_bytes(response_bytes)
        _save(output / "response-http.json", response_http)
        transport_bytes, transport_headers = response_bytes, response_http["headers"]
        if openai_stream and response_http["status_code"] < 400:
            transport_bytes = _synthetic_openai_sse(response_bytes)
            transport_headers = {"content-type": "text/event-stream"}
            (output / "synthetic-response.sse.bin").write_bytes(transport_bytes)
            result["review_response_origin"] = (
                "historical_openai_completion_with_synthetic_sse_framing_not_original_stream")
        result["historical_http_replays"] += 1
        return httpx.Response(response_http["status_code"], headers=transport_headers,
                              content=transport_bytes, request=request)

    try:
        with patch.dict(os.environ, env), _offline_network(receive, blocked, loopback):
            from opencode.app import App
            from opencode.provider import Completion, ToolCall
            from opencode.store import Store
            from scripts.setup_research_workspace import install

            install(workspace)
            config = _config(source_config, workspace)
            _save(output / "offline-config.json", config)
            store = Store(output / "session.db")
            app = App(workspace, store=store, auto_approve=False, config=config)
            app.generate_titles = False
            result["turn_extension_registered"] = app.turn_extension_factory is not None
            rules = [{"permission": "*", "pattern": "*", "action": "deny"},
                     *[{"permission": name, "pattern": "*", "action": "allow"} for name in sorted(ALLOWED_TOOLS)]]
            rules.extend({"permission": "edit", "pattern": pattern, "action": action}
                         for pattern, action in config["permission"]["edit"].items())
            session = app.create_session(agent="build", model=config["model"], title="Scripted offline review replay",
                                         permission=rules)["id"]

            def receipt(call_id):
                matches = [m for m in store.messages(session)
                           if m.get("role") == "tool" and m.get("tool_call_id") == call_id]
                assert len(matches) == 1, f"Expected one stored receipt for {call_id}"
                return matches[0]

            def tool(call_id, name, args):
                return Completion(tool_calls=[ToolCall(call_id, name, args)], finish_reason="tool-calls")

            def outer(**kwargs):
                request = _jsonable(kwargs)
                request["_offline_diagnostic"] = {
                    "provider": "scripted_offline_test_provider",
                    "omitted_non_json_fields": [k for k, v in kwargs.items() if _jsonable(v) is _OMIT],
                }
                outer_requests.append(request)
                index = len(outer_requests)
                _save(output / "outer-requests" / f"request-{index:03}.json", request)
                exposed = {item["name"] for item in kwargs.get("tools") or []}
                # Existing write tools become visible with a scoped edit rule;
                # execution still denies every path outside the audit directory.
                assert exposed == ALLOWED_TOOLS | AUDIT_WRITE_TOOLS, f"Unexpected tool permissions: {sorted(exposed)}"
                if index == 1:
                    return tool("replay-materializer", "skill", {"name": "materializer"})
                previous = {2: "replay-materializer", 3: "replay-verification", 4: "replay-review", 5: "replay-final-lca"}
                assert index in previous, "Unexpected extra outer inference/retry"
                saved = receipt(previous[index])
                if index == 4:
                    _save(output / "review-receipt.json", saved)
                    _save(output / "outer-consumption-request.json", request)
                    result["review_receipt_error"] = bool(saved.get("metadata", {}).get("error"))
                    result["review_receipt_truncated"] = bool(saved.get("metadata", {}).get("truncated"))
                    consumed = [m for m in kwargs["messages"]
                                if m.get("role") == "tool" and m.get("tool_call_id") == "replay-review"]
                    assert len(consumed) == 1, "Outer request lost the review receipt"
                    result["store_to_outer_content_exact"] = consumed[0].get("content") == saved["content"]
                    assert result["store_to_outer_content_exact"], "Stored receipt changed before outer consumption"
                    if not result["review_receipt_error"]:
                        content = saved["content"]
                        if result["review_receipt_truncated"]:
                            content = Path(saved["metadata"]["outputPath"]).read_bytes().decode("utf-8")
                        result["provider_to_store_content_exact"] = content == historical_content
                        assert result["provider_to_store_content_exact"], "Provider content changed before storage"
                        (output / "review-provider-content.txt").write_text(content, encoding="utf-8", newline="")
                        result["outer_consumption"] = "preview_only" if result["review_receipt_truncated"] else "full_content"
                if saved.get("metadata", {}).get("error"):
                    _save(output / "error-receipt.json", saved)
                    result["earliest_remaining_boundary"] = previous[index] + "_returned_error"
                    return Completion(text=ERROR_CONTROL, finish_reason="stop")
                if index == 2:
                    result["earliest_remaining_boundary"] = "materializer_verification_to_outer"
                    return tool("replay-verification", "read", {
                        "filePath": str(app.skills["materializer"].location.parent / "references/verification.md")})
                if index == 3:
                    result["earliest_remaining_boundary"] = "research_review_to_outer"
                    return tool("replay-review", "research_review", arguments)
                if index == 4:
                    result["earliest_remaining_boundary"] = "final_lca_guidance_to_outer"
                    return tool("replay-final-lca", "skill", {"name": "final-lca"})
                _save(output / "outer-final-context.json", request)
                result["outer_final_context_captured"] = True
                result["earliest_remaining_boundary"] = "new_scientific_review_and_outer_judgment_not_exercised"
                return Completion(text=FINAL_CONTROL, finish_reason="stop")

            # This replaces only the outer inference; review_provider calls the
            # unchanged _openai/_anthropic HTTP path, not Client.complete.
            app.provider.complete = outer
            result["app_result"] = app.prompt(session, commission)
            assert not blocked, "A forbidden network operation was attempted"
    except BaseException as exc:
        failure = exc
        result["diagnostic_error"] = {"type": type(exc).__name__, "message": str(exc)}
    finally:
        if store is not None:
            if session is not None:
                history = store.messages(session)
                _save(output / "session-history.json", history)
                _save(output / "session.json", store.get_session(session))
                result["session_id"] = session
                result["publication_tool_calls"] = sum(
                    call.get("name") == "research_record" for m in history for call in m.get("tool_calls") or [])
            store.close()
        try:
            after = _source_hashes(source)
        except (OSError, ValueError) as exc:
            after = {}
            result["source_integrity_error"] = str(exc)
        result["source_unchanged"] = before == after
        final_hashes = _hashes(workspace)
        result["copied_original_files_unchanged"] = all(final_hashes.get(p) == h for p, h in copied_before.items())
        result["selected_files_unchanged"] = all(
            final_hashes.get(item["path"]) == item["sha256"] for item in selected) and result["source_unchanged"]
        result["research_records_unchanged"] = {
            p: h for p, h in final_hashes.items() if p.startswith(".research/records/")
        } == {p: h for p, h in copied_before.items() if p.startswith(".research/records/")}
        result["outer_request_count"] = len(outer_requests)
        result["blocked_network_attempts"] = blocked
        result["loopback_wakeup_connections"] = loopback
        _save(output / "source-integrity.json", {"before": before, "after": after,
              "unchanged": result["source_unchanged"], "scope": result["source_hash_scope"]})
        _save(output / "outer-requests.json", outer_requests)
        _save(output / "result.json", result)
    if failure is not None:
        raise failure
    assert result["source_unchanged"], "Historical capture changed"
    assert result["copied_original_files_unchanged"] and result["selected_files_unchanged"], "Copied source bytes changed"
    assert result["research_records_unchanged"] and result.get("publication_tool_calls") == 0, "Unexpected publication"
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--arguments", type=Path, required=True,
                        help="Existing three-field research_review JSON; no inferred/default scope")
    parser.add_argument("--commission", type=Path, required=True,
                        help="Explicit UTF-8 outer commission; no built-in scientific example")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    sys.path[:0] = [str(project), str(project / "src")]
    result = replay(args.source, args.output,
                    json.loads(args.arguments.read_text(encoding="utf-8-sig")),
                    args.commission.read_text(encoding="utf-8-sig"))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
