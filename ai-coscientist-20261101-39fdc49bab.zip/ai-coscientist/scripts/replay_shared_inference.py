"""Developer-only saved-evidence handoff replay, with no live model or network.

The deterministic provider controls transport only. The formalization and all
scientific stage objects are selected from immutable saved evidence; no new
scientific answer is authored here. Replaying a historical deepening answer
after adding new evidence does not prove that answer incorporated the evidence.
"""

from __future__ import annotations

import argparse
from contextlib import ExitStack, contextmanager
from copy import deepcopy
from dataclasses import replace
import json
import os
from pathlib import Path
import shutil
import socket
from types import SimpleNamespace
from unittest.mock import patch
import urllib.request

import httpx

from opencode.app import App
from opencode.loop import ToolContext
from opencode.permission import Rule
from opencode.provider import Client, Completion, ToolCall
from opencode.store import Store
from opencode.tools.util import ensure_access
from researchkit import inference, mindmap, records, report_evidence
from researchkit.tools import TOOLS
from scripts import replay_check_inference as prior


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = PROJECT / "outputs/report_real_llm_20261021_v1/workspace"
SAVED_INFERENCE = PROJECT / "outputs/check_inference_offline_20261022_v1/replay-final"
DEFAULT_OUTPUT = PROJECT / "outputs/shared_inference_offline_20261022_v1/replay-final"
ARCHITECTURE_REF = ".research/records/7c5489f149d079a97c3ff9ecafd6e942d60f25d8c71a8786008fc0059ab34434/record.json"
DEEPENING_REF = ".research/records/00d4db3a6b4a0bdc5d14eee96dafdb36c40b81702a4e01ebf283e07b75988ff4/record.json"
STAGES = ("observation", "architecture", "deepening")


def _load(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _save(path, value):
    path.write_bytes(records.encoded(value) + b"\n")


def _entry(root, ref, filename):
    record = records.read_record(root, ref)
    matches = [item for item in record["files"] if Path(item["source_path"]).name == filename]
    if len(matches) != 1:
        raise ValueError(f"Select exactly one frozen {filename}: {ref}")
    item = matches[0]
    path = records.local_path(records.local_path(root, ref).parent, item["snapshot"])
    return {"record_ref": ref, "source_path": item["source_path"]}, path


def _saved_packet(source, saved_inference):
    """Require real saved inputs before creating any replay destination."""
    verified, closure = prior._closure_files(source)
    architecture_locator, architecture_path = _entry(source, ARCHITECTURE_REF, "checkpoint.json")
    _, deepening_path = _entry(source, DEEPENING_REF, "checkpoint.json")
    architecture, deepening = _load(architecture_path), _load(deepening_path)
    if "deepening" in architecture or "architecture" not in architecture:
        raise ValueError("The selected saved architecture must stop before deepening")
    if any(architecture[name] != deepening[name] for name in ("observation", "architecture")):
        raise ValueError("Saved deepening does not preserve the selected architecture prefix")
    saved_receipt_path = saved_inference / "tool-receipt.json"
    saved_receipt = _load(saved_receipt_path)
    input_locator, input_path = _entry(saved_inference / "workspace", saved_receipt["record_path"], "input.json")
    problem = inference.validate_input(_load(input_path))
    inference.validate_sources(source, problem)
    guidance_root = source / ".opencode/skills/mindmap-builder"
    guidance = [guidance_root / "SKILL.md", *[
        guidance_root / "references" / f"{name}.md" for name in STAGES]]
    for path in guidance:
        if not path.read_bytes():
            raise ValueError(f"Saved stage guidance is empty: {path}")
    protected = [*closure, saved_receipt_path, input_path,
                 saved_inference / "workspace" / saved_receipt["record_path"], *guidance]
    return SimpleNamespace(
        verified=verified, closure=closure, architecture=architecture, deepening=deepening,
        architecture_locator=architecture_locator, problem=problem, input_locator=input_locator,
        input_path=input_path, guidance=guidance, guidance_root=guidance_root, protected=protected,
    )


@contextmanager
def _offline_only():
    attempts = []

    def blocked(*args, **kwargs):
        attempts.append("Forbidden live provider or network entry was called")
        raise AssertionError(attempts[-1])

    with ExitStack() as stack:
        for owner, name in ((Client, "complete"), (httpx.Client, "request"),
                            (httpx.AsyncClient, "request"), (httpx.HTTPTransport, "handle_request"),
                            (httpx.AsyncHTTPTransport, "handle_async_request"),
                            (socket, "create_connection"), (socket.socket, "connect"),
                            (socket.socket, "connect_ex"), (urllib.request, "urlopen")):
            stack.enter_context(patch.object(owner, name, blocked))
        stack.enter_context(patch("researchkit.review_provider.complete_once", blocked))
        stack.enter_context(patch("researchkit.reviewer.complete_once", blocked))
        yield attempts


def _permissions(output):
    rules = [Rule("*", "*", "deny"), Rule("read", "*", "allow")]
    rules.append(Rule("external_directory", str(output / "isolated-data") + "/*", "allow"))
    rules.extend(Rule(name, "*", "allow") for name in
                 ("check_inference", "research_mindmap", "research_record"))
    for path in (".research/inference-runs", ".research/mindmaps", ".research/records"):
        rules.extend([Rule("edit", path, "allow"), Rule("edit", path + "/*", "allow")])
    return rules


def _tool_message(messages, name):
    call_ids = {call["id"] for message in messages for call in message.get("tool_calls", [])
                if call["function"]["name"] == name}
    selected = [item for item in messages
                if item.get("role") == "tool" and item.get("tool_call_id") in call_ids]
    if len(selected) != 1:
        raise AssertionError(f"Expected exactly one actual outer tool message for {name}")
    return selected[0]


def _tool_content(messages, name):
    message = _tool_message(messages, name)
    return message, json.loads(message["content"])


def _replay_loop(root, output, packet, store):
    """Exercise the unmodified Common loop, store and provider serialization."""
    app = App(root, store=store, config={"compaction": {"auto": False, "prune": False}}, auto_approve=True)
    app.generate_titles = False
    selected_tools = {tool.name: tool for tool in TOOLS
                      if tool.name in {"check_inference", "research_mindmap", "research_record"}}
    app.extra_tools = list(selected_tools.values())
    app.agents["build"] = replace(app.agents["build"], permission=_permissions(output), steps=6,
                                  prompt="Developer-only deterministic saved-evidence boundary replay.")
    session = app.create_session(title="Offline shared inference boundary replay")
    sid = session["id"]
    ctx = ToolContext(app, sid, app.agents["build"], "offline", "offline", 0, root, root, set(), 1,
                      abort=app.abort_event(sid))
    systems = mindmap._load_systems(ctx)
    if mindmap._system_hashes(systems) != packet.architecture["system_sha256"]:
        raise ValueError("Saved checkpoint guidance mismatch; historical hashes must not be rewritten")
    base_args = {key: deepcopy(packet.architecture[key]) for key in ("scope", "task_ref", "files")}
    base_args["resume_from"] = deepcopy(packet.architecture_locator)
    requests, stage_requests, receipts = [], [], {}

    def saved_deepening(_ctx, *, system, messages, **kwargs):
        if stage_requests:
            raise AssertionError("Unexpected extra stage or repair call in saved deepening replay")
        if system != systems["deepening"] or kwargs:
            raise AssertionError("Only the exact saved-guidance deepening request is expected")
        request = {"system": system, "messages": deepcopy(messages)}
        stage_requests.append(request)
        _save(output / "deepening-request-not-sent.json", request)
        text = messages[0]["content"]
        choices = [*base_args["files"], *receipts["resume_args"]["additional_evidence"]]
        selected = report_evidence.resolve(root, choices)
        for source in selected:
            if mindmap._json(source["text"]) not in text:
                raise AssertionError(f"Deepening omitted literal selected bytes: {source['source_path']}")
        for stage in ("observation", "architecture"):
            if mindmap._json(packet.architecture[stage]) not in text:
                raise AssertionError(f"Deepening omitted the complete earlier {stage} object")
        _save(output / "deepening-selected-source-identities.json", [
            {key: item[key] for key in ("record_ref", "source_path", "sha256", "bytes")}
            for item in selected])
        # Historical scientific output is reused unchanged as a transport probe.
        # It predates the new solver result and is NOT a revision based on it.
        return Completion(text=json.dumps(packet.deepening["deepening"], ensure_ascii=False),
                          finish_reason="stop", model="saved-historical-deepening-offline")

    def provider_complete(**kwargs):
        request = {key: deepcopy(kwargs[key]) for key in ("system", "messages", "tools")}
        requests.append(request)
        index = len(requests)
        _save(output / f"outer-provider-request-{index:02d}-not-sent.json", request)
        if index == 1:
            if not any(item["name"] == "check_inference" for item in request["tools"]):
                raise AssertionError("The actual outer action space did not register check_inference")
            return Completion(tool_calls=[ToolCall("offline-inference", "check_inference", packet.problem)],
                              finish_reason="tool_calls")
        if index == 2:
            message, receipt = _tool_content(request["messages"], "check_inference")
            receipts["inference"] = receipt
            result_locator, result_path = _entry(root, receipt["record_path"], "result.json")
            if receipt["result"] != _load(result_path):
                raise AssertionError("The outer's next request lost the committed inference result")
            witnesses = prior._verify_countermodels(receipt["result"])
            _save(output / "independent-rational-witness-checks.json", witnesses)
            _save(output / "outer-inference-tool-message.json", message)
            input_locator, _ = _entry(root, receipt["record_path"], "input.json")
            resume = {**base_args, "additional_evidence": [input_locator, result_locator]}
            receipts["resume_args"] = resume
            _save(output / "mindmap-resume-input.json", resume)
            return Completion(tool_calls=[ToolCall("offline-deepening", "research_mindmap", resume)],
                              finish_reason="tool_calls")
        if index == 3:
            message, receipt = _tool_content(request["messages"], "research_mindmap")
            receipts["mindmap"] = receipt
            _save(output / "outer-mindmap-tool-message.json", message)
            note = root / "engineering-provenance-only.md"
            note.write_text(
                "# 工程作者的來源鏈續接紀錄\n\n"
                "本檔只記錄離線傳輸及來源鏈，不是模型撰寫的科學修正。\n\n"
                "新求解器結果已經由實際 Common 工具回條進入外層下一次模型請求；"
                "原始來源及新 input.json、result.json 已完整進入 deepening 請求。\n\n"
                "deepening 回覆重播自舊保存成果，早於新增反例；其內容未因反例重新推理。"
                "因此本次沒有證明模型接受或正確解釋反例，也沒有證明任何科學修正。\n\n"
                f"新求解器紀錄：`{receipts['inference']['record_path']}`\n\n"
                f"新保存心智圖：`{receipt['record_path']}`\n\n"
                f"原 architecture：`{ARCHITECTURE_REF}`\n\n"
                f"原 deepening 回覆來源：`{DEEPENING_REF}`\n",
                encoding="utf-8",
            )
            note_args = {"kind": "implementation", "title": "Engineering provenance-only replay note; no scientific revision",
                         "files": [note.name], "depends_on": [receipts["inference"]["record_path"], receipt["record_path"]]}
            _save(output / "downstream-provenance-input.json", note_args)
            return Completion(tool_calls=[ToolCall("offline-provenance", "research_record", note_args)],
                              finish_reason="tool_calls")
        if index == 4:
            _save(output / "outer-downstream-tool-message.json", _tool_message(request["messages"], "research_record"))
            return Completion(text="Offline transport replay ended. No new scientific judgment was produced.",
                              finish_reason="stop")
        raise AssertionError("Unexpected additional outer request in the deterministic boundary replay")

    app.provider = SimpleNamespace(
        resolve=lambda _: (SimpleNamespace(id="offline", context=131072), "saved-boundary-replay"),
        complete=provider_complete,
    )
    with patch("researchkit.mindmap.complete_once", saved_deepening):
        paused = json.loads(selected_tools["research_mindmap"].execute(
            {**base_args, "pause_after": "architecture"}, ctx).output)
        if paused["record_path"] != ARCHITECTURE_REF or stage_requests:
            raise AssertionError("Architecture pause must return the selected checkpoint without model calls")
        _save(output / "architecture-pause-receipt.json", paused)
        result = app.prompt(sid, "Developer-authorized offline replay of the explicitly saved formalization and evidence handoffs.")
        if len(requests) != 4 or len(stage_requests) != 1:
            raise AssertionError("Expected four outer requests and only one saved deepening response")
        if result["status"] != "completed":
            raise AssertionError("The deterministic outer transport replay did not finish")
        stored_messages = store.messages(sid)
        _save(output / "outer-stored-messages.json", stored_messages)
        downstream_message, = [message for message in stored_messages
                               if message["role"] == "tool" and message["name"] == "research_record"]
        downstream_metadata = downstream_message.get("metadata") or {}
        downstream_raw = downstream_message["content"]
        # Common may bound the long missing-working-file notice. Read its exact
        # existing saved-output path for developer verification, without claiming
        # that the full notice reached the next provider request.
        if downstream_metadata.get("truncated"):
            saved_output = Path(downstream_metadata["outputPath"])
            ensure_access(ctx, saved_output, "read")
            downstream_raw = saved_output.read_text(encoding="utf-8")
        receipts["downstream"] = json.loads(downstream_raw)
        checkpoint_ref = receipts["mindmap"]["depends_on"][-1]
        checkpoint_locator, checkpoint_path = _entry(root, checkpoint_ref, "checkpoint.json")
        checkpoint = _load(checkpoint_path)
        if checkpoint["additional_evidence"] != receipts["resume_args"]["additional_evidence"]:
            raise AssertionError("Completed checkpoint lost its supplemental evidence selection")
        if any(checkpoint[name] != packet.deepening[name] for name in STAGES):
            raise AssertionError("Saved stage objects were altered in boundary replay")
        # Omission must inherit the previously frozen supplemental selection.
        republish_args = {**base_args, "resume_from": checkpoint_locator}
        republished = json.loads(selected_tools["research_mindmap"].execute(republish_args, ctx).output)
        if len(stage_requests) != 1 or republished["depends_on"] != receipts["mindmap"]["depends_on"]:
            raise AssertionError("Completed resume must inherit evidence and publish without model calls")
        _save(output / "completed-checkpoint-republish-input.json", republish_args)
        _save(output / "completed-checkpoint-republish-receipt.json", republished)
    for name in ("inference", "mindmap", "downstream"):
        _save(output / f"{name}-receipt.json", receipts[name])
    closure = records._read_dependencies(root, [receipts["downstream"]["record_path"]])
    for required in (receipts["inference"]["record_path"], receipts["mindmap"]["record_path"],
                     checkpoint_ref, ARCHITECTURE_REF, prior.REPORT_REF, prior.FORMULA_REF):
        if required not in closure:
            raise AssertionError(f"Downstream provenance closure lost {required}")
    _save(output / "downstream-record-closure.json", closure)
    return {
        "outer_provider_request_count": len(requests), "outer_tool_names": list(selected_tools),
        "inference_record": receipts["inference"]["record_path"],
        "mindmap_record": receipts["mindmap"]["record_path"], "deepening_checkpoint": checkpoint_locator,
        "downstream_provenance_record": receipts["downstream"]["record_path"],
        "downstream_record_count": len(closure),
        "query_statuses": {item["name"]: item["status"] for item in receipts["inference"]["result"]["queries"]},
        "saved_stage_response_calls": {"observation": 0, "architecture": 0, "deepening": len(stage_requests)},
        "original_selected_file_count": len(base_args["files"]), "supplemental_selected_file_count": 2,
        "counterexample_in_next_outer_provider_request": True,
        "next_outer_request_result_equals_frozen_result": True,
        "complete_original_and_supplemental_text_in_deepening_request": True,
        "earlier_stage_objects_unchanged": True, "completed_resume_inherits_evidence_without_model": True,
        "architecture_pause_without_model": True,
        "downstream_outer_receipt_truncated": bool(downstream_metadata.get("truncated")),
        "downstream_receipt_verified_from_common_saved_output": bool(downstream_metadata.get("truncated")),
    }


def replay(output, *, source=SOURCE, saved_inference=SAVED_INFERENCE):
    output, source, saved_inference = output.resolve(), source.resolve(), saved_inference.resolve()
    if output.exists():
        raise FileExistsError(f"Replay output already exists; preserve it: {output}")
    if output.is_relative_to(source) or output.is_relative_to(saved_inference):
        raise ValueError("Replay output must be outside the original saved evidence")
    packet = _saved_packet(source, saved_inference)
    before = prior._hashes(packet.protected)
    output.mkdir(parents=True)
    _save(output / "source-hashes-before.json", before)
    root = output / "workspace"
    prior._copy_closure(source, root, packet.closure)
    (root / ".git").mkdir()  # Stop local configuration discovery at this isolated workspace.
    for path in packet.guidance:
        target = root / ".opencode/skills/mindmap-builder" / path.relative_to(packet.guidance_root)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    copied = [root / path.relative_to(source) for path in packet.closure]
    copied_before = prior._hashes(copied)
    _save(output / "saved-formalization-input.json", packet.problem)
    _save(output / "saved-historical-deepening-reply.json", packet.deepening["deepening"])
    _save(output / "saved-input-identities.json", {
        "source_workspace": str(source), "saved_inference_workspace": str(saved_inference / "workspace"),
        "formalization_locator": packet.input_locator, "architecture_locator": packet.architecture_locator,
        "historical_deepening_record": DEEPENING_REF, "system_sha256": packet.architecture["system_sha256"],
    })
    environment = {
        "OPENCODE_TEST_HOME": str(output / "isolated-home"), "OPENCODE_CONFIG_DIR": str(output / "isolated-config"),
        "XDG_CONFIG_HOME": str(output / "isolated-config"), "XDG_DATA_HOME": str(output / "isolated-data"),
        "XDG_STATE_HOME": str(output / "isolated-state"), "XDG_CACHE_HOME": str(output / "isolated-cache"),
    }
    with patch.dict(os.environ, environment), _offline_only() as attempts:
        store = Store(output / "outer-session.db")
        try:
            boundary = _replay_loop(root, output, packet, store)
        finally:
            store.close()
        if attempts:
            raise AssertionError("The offline replay attempted a live provider or network call")
    after = prior._hashes(packet.protected)
    _save(output / "source-hashes-after.json", after)
    if before != after or copied_before != prior._hashes(copied):
        raise AssertionError("Historical frozen source bytes were modified")
    summary = {
        "scope": "Saved-evidence Common outer-loop, local inference and mindmap evidence handoff replay",
        "saved_source_record_count": len(packet.verified), "saved_source_snapshot_count": len(packet.closure) - len(packet.verified),
        "live_model_calls": 0, "blocked_network_or_provider_attempts": attempts,
        "scientific_acceptance": False, "semantic_acceptance": False, "full_end_to_end_passed": False,
        "original_evidence_unchanged": True, "copied_original_evidence_unchanged": True,
        "formalization_authorship": "Previously saved engineering-authored formalization; not a new model choice",
        "deepening_response_authorship": "Historical saved model object predating the new proof; unchanged transport probe only",
        "downstream_authorship": "Engineering-authored provenance-only implementation note; no scientific revision",
        "remaining_unproven_boundary": "A live scientific author must interpret the newly received counterexample and produce a source-bound scientific revision; this replay cannot establish semantic uptake or acceptance.",
        "boundary": boundary,
    }
    _save(output / "offline-summary.json", summary)
    (output / "AUTHOR_NOTE.txt").write_text(
        "此目錄是工程離線邊界重播；真實模型與網路呼叫皆為零。\n"
        "形式化輸入來自已保存的工程作者版本，本次僅重新執行本機 Z3。\n"
        "外層實際 Common 迴圈、權限、工具分派、SQLite 保存與 provider 訊息序列化均有執行。\n"
        "外層 provider 是確定性的傳輸替身，工具選擇不代表自主科研選擇。\n"
        "新增反例與原始來源完整進入 deepening 請求，但回覆重播自更早的模型成果。\n"
        "此回覆未重新解讀新增證據；新 mindmap 記錄只證明資料流與來源鏈，不代表科研改善。\n"
        "下游 implementation 僅保存工程作者的來源鏈說明；沒有手寫科研修正、審查或科學接受。\n"
        "未執行完整端到端科研流程；仍缺真實模型收到反例後的科學解釋、修正與獨立審查。\n",
        encoding="utf-8",
    )
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args(argv)
    print(json.dumps(replay(args.output), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
