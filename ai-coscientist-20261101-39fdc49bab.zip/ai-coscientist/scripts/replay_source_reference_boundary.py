"""Replay a captured publication offline, preserving its original body and session."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
from unittest.mock import patch

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install


def hashes(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob("*") if p.is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--session", required=True)
    parser.add_argument("--record", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = args.run.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    before = hashes(source)
    workspace = output / "producer"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    # Preserve the old record/dependencies and actual numerical work as-is.
    shutil.copytree(source / "workspace/.research/records", workspace / ".research/records")
    old = records.read_record(workspace, args.record)
    old_folder = workspace / Path(args.record).parent
    for item in old["files"]:
        path = records.local_path(workspace, item["source_path"])
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(old_folder / item["snapshot"], path)
    db = output / "session.db"
    original_db = source / "state/opencode/opencode.db"
    with sqlite3.connect(original_db.as_uri() + "?mode=ro", uri=True) as original:
        with sqlite3.connect(db) as copied:
            original.backup(copied)
    env = {"OPENCODE_TEST_HOME": str(output / "home"), "OPENCODE_CONFIG_DIR": str(output / "config"),
           "XDG_DATA_HOME": str(output / "data"), "XDG_STATE_HOME": str(output / "state")}
    with patch.dict(os.environ, env):
        install(workspace)
        store = Store(db)
        try:
            store.update_session(args.session, directory=str(workspace))
            app = App(workspace, store=store, auto_approve=True, config={})
            ctx = ToolContext(app, args.session, app.agents["build"], "offline", "replay", 0,
                              workspace, workspace, set(), 1)
            tool = next(t for t in TOOLS if t.name == "research_record")
            response = tool.execute({"kind": old["kind"], "title": old["title"],
                "files": [f["source_path"] for f in old["files"]], "depends_on": old["depends_on"]}, ctx)
            saved = json.loads(response.output)
            manifest = records.read_record(workspace, saved["record_path"])
            original_entries = {f["source_path"]: f for f in old["files"]}
            assert all(f == next(n for n in manifest["files"] if n["source_path"] == path)
                       for path, f in original_entries.items()), "Original prose changed"
            extras = [f for f in manifest["files"] if f["source_path"] not in original_entries]
            assert extras, "Captured inline reference was not bundled"
            consumer = output / "consumer"
            folder = consumer / Path(saved["record_path"]).parent
            shutil.copytree(workspace / Path(saved["record_path"]).parent, folder)
            # Nothing from the original session is available to this consumer.
            presented = records.present(consumer, {"record_path": saved["record_path"],
                                                   **records.read_record(consumer, saved["record_path"])})
            source_receipts = store.source_receipts(args.session, {"websearch", "webfetch", "paper_search", "paper_fetch"})
            readback = []
            for item in presented["files"]:
                data = Path(item["snapshot"]).read_bytes()
                assert records.digest(data) == item["sha256"]
                if item["source_path"] not in original_entries and item["source_path"].endswith(".json"):
                    receipt = json.loads(data)
                    assert receipt == source_receipts[receipt[-1]["id"]]
                readback.append(item["snapshot"])
            assert before == hashes(source), "Original run changed"
            assert hashes(source / "workspace/.research/records") == {
                p: h for p, h in hashes(workspace / ".research/records").items()
                if not p.startswith(Path(saved["record_path"]).parent.name + "/")}, "Old records changed"
            result = {"scope": "offline captured source-publication-consumer boundary, not LLM/E2E",
                      "old_record": args.record, "new_record": saved["record_path"],
                      "old_files": len(old["files"]), "new_files": len(manifest["files"]),
                      "original_run_unchanged": True, "original_prose_unchanged": True,
                      "old_records_unchanged": True, "source_call_reply_attachments_exact": True,
                      "isolated_readback_paths": readback}
            (output / "result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
            print(json.dumps(result, indent=2, ensure_ascii=False))
        finally:
            store.close()


if __name__ == "__main__":
    main()
