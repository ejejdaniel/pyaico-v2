"""Run research_mindmap alone against the real model on a copy of a saved workspace.

Reuses the exact research_mindmap arguments a saved run's agent chose, so the
sources and scope are the agent's own. Only the mind-map tool runs: no other
research step, review or report. The saved run's folder is not changed.

    python scripts/run_mindmap_live.py --run outputs/lit_real_20261025_v12 \
        --request request-039.json --output outputs/mindmap_live_20261026_v1
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
from types import SimpleNamespace

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))

from opencode.permission import Broker, Rule  # noqa: E402
from opencode.provider import Client  # noqa: E402
from opencode.skills import discover  # noqa: E402
from researchkit import mindmap, records  # noqa: E402
from researchkit.tools import TOOLS  # noqa: E402


def saved_arguments(request_path: Path) -> dict:
    """The last research_mindmap call recorded in a saved request."""
    body = json.loads(request_path.read_text(encoding="utf-8"))
    calls = [json.loads(call["function"]["arguments"])
             for message in body["messages"] for call in message.get("tool_calls") or []
             if call["function"]["name"] == "research_mindmap"]
    if not calls:
        raise ValueError(f"No research_mindmap call in {request_path}")
    return calls[-1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True, help="saved run folder (with workspace/ and settings.json)")
    parser.add_argument("--request", required=True, help="saved request file holding the research_mindmap call")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, help="decoding seed sent with every request (repeats need distinct seeds)")
    args = parser.parse_args()

    run, output = args.run.resolve(), args.output.resolve()
    settings = json.loads((run / "settings.json").read_text(encoding="utf-8"))
    tool_args = saved_arguments(run / args.request)
    output.mkdir(parents=True, exist_ok=False)
    workspace = output / "workspace"
    # The previous map attempts are left out so the new run starts from the same sources.
    shutil.copytree(run / "workspace", workspace, ignore=shutil.ignore_patterns("mindmaps"))
    (output / "tool-input.json").write_bytes(records.encoded(tool_args))

    os.environ.setdefault("LOCAL_OPENAI_API_KEY", "local")
    config = json.loads(json.dumps(settings["config"]).replace(
        "{env:LOCAL_OPENAI_API_KEY}", os.environ["LOCAL_OPENAI_API_KEY"]))
    if args.seed is not None:
        provider_id, model_id = config["model"].split("/", 1)
        options = config["provider"][provider_id]["models"][model_id].setdefault("options", {})
        options["seed"] = args.seed
    client = Client(SimpleNamespace(get=lambda _: None), config)
    temperature = config["agent"]["build"].get("temperature")
    ctx = SimpleNamespace(
        directory=workspace, worktree=workspace, session_id="mindmap-live", message_id="m", call_id="c",
        abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")], temperature=temperature),
        app=SimpleNamespace(permissions=Broker(auto=True), skills=discover(workspace, workspace, {}),
                            provider=client, abort_event=lambda _: None,
                            store=SimpleNamespace(get_session=lambda _: {"model": config["model"]})),
    )

    stages = []
    original = mindmap.complete_once

    def recorded(ctx_, **kwargs):
        started = time.monotonic()
        try:
            result = original(ctx_, **kwargs)
        except Exception as error:
            stages.append({"seconds": round(time.monotonic() - started, 1), "error": str(error)[:2000]})
            raise
        stages.append({"seconds": round(time.monotonic() - started, 1), "finish": result.finish_reason,
                       "usage": result.usage, "schema": (kwargs.get("response_schema") or ("",))[0],
                       "output_constraint": (kwargs.get("frozen") or {}).get("output_constraint")})
        (output / f"stage-{len(stages)}-reply.txt").write_text(result.text or "", encoding="utf-8")
        print(f"stage {len(stages)}: {stages[-1]['seconds']}s finish={result.finish_reason} "
              f"usage={result.usage}", flush=True)
        return result

    mindmap.complete_once = recorded
    tool = next(tool for tool in TOOLS if tool.name == "research_mindmap")
    started = time.monotonic()
    try:
        receipt = json.loads(tool.execute(tool_args, ctx).output)
        status = "completed"
    except Exception as error:
        receipt, status = {"error": str(error)}, "failed"
        print("FAILED:", error, flush=True)
    finally:
        mindmap.complete_once = original
    summary = {"status": status, "seconds": round(time.monotonic() - started, 1), "model": config["model"],
               "temperature": temperature, "seed": args.seed, "source_run": str(run), "source_request": args.request,
               "stages": stages, "receipt": receipt}
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(status, summary["seconds"], "s", flush=True)
    return 0 if status == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
