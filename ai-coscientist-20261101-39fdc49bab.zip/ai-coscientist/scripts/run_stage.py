"""Run one stage of a research case from a node of an earlier run, with the current code.

    python scripts/run_stage.py --from outputs/<run> --at mindmap --until history_check --name <stage run>
        [--llm-config <model configuration>]

Cuts <run> back to the node (fork_run.py) into outputs/<stage run>/checkpoint, continues that
conversation with the current skills and tools through the one entry (co-scientist <checkpoint>
--continue --record <trace>), and ends when a new record of the --until kind is saved; omit --until
to run to the end. The trace is outputs/<stage run>/trace. The original run is not changed, so the same node can
be run again after each fix. A stage result is a development check; acceptance needs one
uninterrupted run.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]
CONTINUE = PROJECT / "scripts" / "cases" / "continue-request.txt"


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--from", dest="source", type=Path, required=True)
    where = parser.add_mutually_exclusive_group(required=True)
    where.add_argument("--at", help="node record kind, optionally :N")
    where.add_argument("--at-record", help="hash prefix of the node record")
    parser.add_argument("--until", help="end at the first new record of this kind")
    parser.add_argument("--name", required=True, help="folder under outputs/ for the checkpoint and trace")
    parser.add_argument("--llm-config", type=Path)
    parser.add_argument("--no-review", action="store_true", help="skip the review at the end of the stage's round")
    args = parser.parse_args(argv)
    sys.path.insert(0, str(PROJECT / "scripts"))
    from fork_run import fork

    folder = (PROJECT / "outputs" / args.name).resolve()
    if folder.exists():
        parser.error(f"{folder} already exists")
    checkpoint, trace = folder / "checkpoint", folder / "trace"
    summary = fork(args.source, checkpoint, at=args.at, record=args.at_record)
    print(f"[stage] checkpoint at {summary['node']['kind']} {summary['node']['record'].split('/')[2][:8]} "
          f"({summary['node']['minutes']} min into {args.source.name}); {summary['messages_kept']} messages kept",
          flush=True)
    if summary["modified_after_cut"]:
        print("[stage] WARNING: changed after the cut, not rolled back: " + ", ".join(summary["modified_after_cut"]),
              flush=True)
    command = [sys.executable, "-X", "utf8", str(PROJECT / "scripts" / "run_tui.py"), str(checkpoint), "--continue",
               "--record", str(trace), "--prompt", str(CONTINUE), "--deep"]  # a research stage
    if args.until:
        command += ["--stop-at", args.until]
    if args.llm_config:
        command += ["--llm-config", str(args.llm_config)]
    if args.no_review:
        command.append("--no-review")
    return subprocess.run(command, cwd=PROJECT).returncode


if __name__ == "__main__":
    raise SystemExit(main())
