"""Co-Scientist: the one entry for every task, interactive or not.

    co-scientist.cmd [folder]                                        (Windows; bash co-scientist.sh on Linux)
    co-scientist.cmd [folder] --prompt <request> [--from <source>] [--continue]
    co-scientist.cmd --record <run> --from <source> --prompt <request>
    co-scientist.cmd <earlier run> --continue --record <run> --prompt <request> [--stop-at <kind>]

Without --prompt it opens the TUI. With --prompt the same agent works with nobody at the keyboard; with
--record it also keeps a record of the round for people to check (scripts/recording.py). There is no other
runner: acceptance runs and stage tests go through here too.

The folder is the current directory unless one is given, and is created when it does not exist.
The general agent, the research skills and tools and the optional work planning come from this
installation; nothing is copied into the folder, so it always runs the current version, and
research records appear in it only when the work saves some. The model configuration is this
installation's config/llm.opencode.json.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys
from types import SimpleNamespace

PROJECT_ROOT = Path(__file__).resolve().parents[1]
# This installation's own code, ahead of whatever the interpreter has installed: a copy of the framework (run
# while the working copy is being changed) runs its own code, as the meta region's hashes say it does.
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))
# The two pages an installed research folder lists in its instructions; these copies are replaced
# by this installation's own pages.
INSTALLED_GUIDES = {".opencode/skills/research-practice/SKILL.md", ".opencode/skills/work-planning/SKILL.md"}
TOOL_MODULE = "researchkit.planning_adapter"


def deep_skill_sources() -> dict:
    """The installation's research and planning skill folders, which deep research copies into a folder."""
    import planningkit
    import researchkit
    return {"research": Path(researchkit.__file__).parent / "skills",
            "planning": Path(planningkit.__file__).parent / "skills"}


def install_deep_skills(directory: Path) -> dict:
    from opencode import deep
    return deep.install_copies(directory, deep_skill_sources())


def research_config(config: dict, directory: Path) -> dict:
    """A folder's own configuration, with this installation's research and planning capabilities installed as
    deep research: the guides, the skills and the tools (with their turn extension). A task has them while deep
    research is on for it, which is off unless the person turns it on (/deep in the interface, --deep here;
    opencode/deep.py)."""
    from opencode import deep
    if __package__:
        from .setup_research_workspace import RESEARCH_TOOL_OUTPUT
    else:
        from setup_research_workspace import RESEARCH_TOOL_OUTPUT

    # The skill list and the skill tool show where a skill is. A recorded run installs copies in its workspace
    # before it starts (recording.py), so its agent is not pointed into the framework's source; a person's own
    # folder gets nothing written, and keeps the installation's folders.
    sources = deep_skill_sources()
    copies = {name: directory / deep.COPIES / name for name in sources}
    if not all(path.is_dir() for path in copies.values()):
        copies = sources
    research, planning = copies["research"], copies["planning"]
    guides = [str(research / "research-practice" / "SKILL.md"), str(planning / "work-planning" / "SKILL.md")]
    combined = {**config,
                "instructions": [item for item in config.get("instructions") or [] if item not in INSTALLED_GUIDES]}
    combined.setdefault("tool_output", dict(RESEARCH_TOOL_OUTPUT))
    # Network queries per task (webfetch, websearch, paper_search, literature_agent): config/runtime.json;
    # a folder's own config may change it.
    from opencode import runtime_settings
    combined.setdefault("network", {"max_queries": runtime_settings.get("network.max_queries")})
    # A folder set up by the earlier installer imports the same tools from its own .opencode/tools.
    own = any((directory / ".opencode" / folder / name).exists()
              for folder in ("tools", "tool") for name in ("research.py", "planning.py"))
    combined["deep"] = {"instructions": guides, "skills": [str(research), str(planning)],
                        "tool_modules": [] if own or TOOL_MODULE in (config.get("tool_modules") or []) else [TOOL_MODULE]}
    return combined


def folder_tool_warning(directory: Path) -> str | None:
    """A folder's own tool files run inside the framework's process; name them before they load.

    The interface keeps loading them (a person may have written them on purpose); unattended research
    runs refuse any that appear after the run started (docs/design_meta_task_zones_20261030_zh-TW.md).
    """
    if __package__:
        from .setup_research_workspace import COMBINED_STUB, OLD_RESEARCH_STUB, PLANNING_STUB, RESEARCH_STUB
    else:
        from setup_research_workspace import COMBINED_STUB, OLD_RESEARCH_STUB, PLANNING_STUB, RESEARCH_STUB
    installed = {COMBINED_STUB, OLD_RESEARCH_STUB, PLANNING_STUB, RESEARCH_STUB}
    own = [path for name in ("tools", "tool") for path in sorted((directory / ".opencode" / name).glob("*.py"))
           if path.read_bytes() not in installed]
    if not own:
        return None
    names = "、".join(path.relative_to(directory).as_posix() for path in own)
    return (f"注意：這個資料夾有 {len(own)} 個自訂工具檔，啟動時會在 Co-Scientist 本身的程序內執行，"
            f"能讀寫它碰得到的一切：{names}。請確認是你信任的檔案。")


def _llm():
    if __package__:
        from .llm_configuration import compose_llm_configuration, explicit_root_model, select_llm_configuration
    else:
        from llm_configuration import compose_llm_configuration, explicit_root_model, select_llm_configuration
    return compose_llm_configuration, explicit_root_model, select_llm_configuration


def _no_input(questions):
    """Nobody answers in an unattended run: the question tool tells the agent so and it goes on
    (opencode/tools/extra.py). Without this the question would wait for a reply that never comes."""
    raise EOFError("an unattended run reads no input")


def build_app(directory: Path, *, llm_config: Path | None = None, unattended: bool = False, sources=None,
              selection=None, saved_directory: Path | None = None, root_agent: str | None = None,
              session_model: str | None = None, extra_config: dict | None = None):
    """The agent every task gets, interactive or not: this installation's general agent with the research and
    planning capabilities (research_config) and its model configuration. Unattended, nobody approves
    permissions or answers questions, and the agent's own file tools are refused the framework's records,
    everything outside the folder and the task's sources (opencode/integrity.py). A recorded run passes its
    saved model selection, the continued session's agent and model, and what its tools must not see
    (scripts/recording.py). Returns (app, effective configuration, model)."""
    compose, explicit, select = _llm()
    from opencode.app import App
    from opencode.config import load_config

    os.environ.setdefault("LOCAL_OPENAI_API_KEY", "local")
    # Without a search tool the model scraped search-engine pages with webfetch (33 calls, no
    # results); research runs already search through Exa, which needs no key.
    os.environ.setdefault("OPENCODE_ENABLE_EXA", "1")
    os.environ.setdefault("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    workspace_config = research_config(load_config(directory), directory)
    if unattended:
        from opencode import integrity
        workspace_config["protected"] = integrity.protected(sorted(sources or []))
    selection = selection or select(PROJECT_ROOT / "config/llm.opencode.json", llm_config=llm_config)
    effective = (compose(workspace_config, selection, saved_directory=saved_directory, root_agent=root_agent,
                         session_model=session_model) if saved_directory else compose(workspace_config, selection))
    config = {**effective.config, **(extra_config or {})}
    runtime = (App(directory, config=config, auto_approve=True, question_callback=_no_input)
               if unattended else App(directory, config=config))
    return runtime, effective, explicit(effective.config, selection, root_agent or runtime.default_agent)


def run_round(runtime, directory: Path, prompts: list[str], *, model=None, session: str | None = None,
              resume: bool = False, no_review: bool = False, deep: bool = False, sources=None,
              started: float | None = None, guard=None, wrote=None, before_review=None, ended=None,
              report=print) -> dict:
    """One round of a task with nobody at the keyboard, on an app build_app made, as the interface runs it: the
    same reviewer hooks (researchkit/task_runtime.py) and a review at the end. Each prompt is a human message,
    in order, in one session: a new task; with resume the folder's last task, as its next round; or the
    session given (a recorded continuation sets its round itself). Only an aborted turn or an error keeps the
    later prompts from being sent. deep turns deep research on for the task (opencode/deep.py); a continued
    task keeps its own setting otherwise. The verification plan, the pause review and the round review come
    only with deep research.

    A recorded run watches the reviewer through guard() and wrote(kind, record), checks the round once more
    in before_review() (a reason it returns skips the review), and adds facts for the review with ended()."""
    import time
    from opencode import task_skills
    from researchkit import task_runtime

    here = Path(directory).resolve()
    if session:
        saved = runtime.store.get_session(session)["directory"]
        if Path(saved).resolve() != here:
            # A copied run keeps the historical paths in its messages; only its working folder moves.
            report(f"[continuation] workspace: {saved} -> {here}")
            runtime.store.update_session(session, directory=str(here))
        session_id = session
    elif resume:
        tops = [item for item in runtime.store.list_sessions() if item.get("parentID") is None
                and item.get("directory") and Path(item["directory"]).resolve() == here]
        if not tops:
            raise ValueError("Nothing to continue: this folder holds no earlier task")
        session_id = max(tops, key=lambda item: (item.get("time") or {}).get("updated") or 0)["id"]
        task_skills.set_round(session_id, task_skills.current_round(session_id) + 1)
    else:
        session_id = runtime.create_session(model=model)["id"]
    from opencode import deep as deep_research
    if deep:
        deep_research.set_on(runtime.store, session_id, True)
    started = time.time() if started is None else started
    task_runtime.attach(runtime, workspace=directory, sources=sources, started=started, no_review=no_review,
                        guard=guard, wrote=wrote)
    turns = []
    for text in prompts:
        begun = time.monotonic()
        try:
            result = runtime.prompt(session_id, text, model=model)
        except Exception as exc:  # noqa: BLE001 - the round ends here and is still reviewed
            turns.append({"question": text, "error": str(exc), "seconds": time.monotonic() - begun})
            break
        turns.append({"question": text, "result": result, "seconds": time.monotonic() - begun})
        report(result.get("text", ""))
        if result.get("status") == "aborted":
            # A stage stop, a person's stop request or a changed meta region ends the round. A turn the loop's
            # own guard stopped (a repeat limit) still got a reply, so the next message comes, as a person
            # would send it: Q2 was never asked after Q1 hit the repeat limit (2026-10-31).
            break
    round_ = task_skills.current_round(session_id)
    last = turns[-1] if turns else {}
    checked = before_review() if before_review else None  # the round's last check comes before its review
    reason = ("turned off with --no-review" if no_review else checked
              or (None if deep_research.is_on(runtime, session_id) else "deep research is off for this task"))
    if reason:
        review = {"status": "skipped", "reason": reason}
    else:
        report(f"[round review] reviewing round {round_} for the task's next round")
        review = task_runtime.round_review(
            runtime, session_id, workspace=directory, round_=round_,
            commission=task_runtime.first_request(runtime.store, session_id),
            request=task_runtime.latest_request(runtime.store, session_id),
            answer=(last.get("result") or {}).get("text") or "", since=started,
            sources=sources if sources is not None else task_runtime.task_sources(directory),
            ended={"status": (last.get("result") or {}).get("status") or "error", "seconds": time.time() - started,
                   **({"error": last["error"]} if last.get("error") else {}), **(ended() if ended else {})})
    report(f"[round review] round {round_}: {review.get('status')}")
    return {"session": session_id, "round": round_, "turns": turns, "review": review}


def run_unattended(directory: Path, prompts: list[str], *, llm_config: Path | None = None, resume: bool = False,
                   no_review: bool = False, deep: bool = False, supervised: bool = False, sources=None,
                   report=print) -> dict:
    """One round of a task in a folder, with nobody at the keyboard (build_app, then run_round). supervised: the
    prompts play a person at the keyboard, so a general-mode turn has its call budget (opencode/loop.py)."""
    runtime, effective, model = build_app(directory, llm_config=llm_config, unattended=True, sources=sources)
    runtime.generate_titles = False
    runtime.supervised = supervised
    outcome = run_round(runtime, directory, prompts, model=model, resume=resume, no_review=no_review, deep=deep,
                        sources=sources, report=report)
    return {**outcome, "app": runtime, "effective": effective, "model": model}


def _copy_source(source: Path, directory: Path) -> list[str]:
    """A fresh task folder from a source folder, as a git work tree; the copied files are the task's sources."""
    import shutil
    import subprocess

    if directory.exists() and any(directory.iterdir()):
        raise ValueError(f"--from needs a new or empty folder: {directory}")
    shutil.copytree(source, directory, dirs_exist_ok=True)
    subprocess.run(["git", "init", "--quiet", str(directory)], check=True)
    return sorted(path.relative_to(directory).as_posix() for path in directory.rglob("*")
                  if path.is_file() and ".git" not in path.relative_to(directory).parts)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("folder", nargs="?", type=Path,
                        help="工作資料夾；預設為目前所在資料夾，不存在會建立，相對路徑以目前目錄解析")
    parser.add_argument("--dir", type=Path, help=argparse.SUPPRESS)  # the earlier spelling of folder
    parser.add_argument("--prompt", type=Path, action="append",
                        help="無人值守：把這個檔案的內容當成一則訊息送出；可給多次，在同一個任務裡依序送出")
    parser.add_argument("--from", dest="source", type=Path,
                        help="無人值守：先把這個資料夾的檔案複製進工作資料夾（工作資料夾須不存在或是空的）")
    parser.add_argument("--continue", dest="resume", action="store_true",
                        help="無人值守：接續這個資料夾上一個任務，作為它的下一輪")
    parser.add_argument("--llm-config", type=Path, help="模型設定檔；預設為本安裝的 config/llm.opencode.json")
    parser.add_argument("--no-review", action="store_true",
                        help="無人值守：不寫驗證計畫，也不做暫停時與輪末的檢討")
    parser.add_argument("--record", type=Path, metavar="RUN",
                        help="無人值守：把這一輪完整記錄在新資料夾 RUN（每次模型請求與回覆、對話、結果、meta 區完整性、"
                             "階段快照），任務的工作區與狀態也獨立放在裡面。新任務配 --from（不給工作資料夾）；"
                             "接續時工作資料夾是先前的紀錄資料夾，配 --continue。在 RUN 裡寫入 stop-request.txt 可結束這一輪")
    parser.add_argument("--stop-at", metavar="KIND",
                        help="配 --record：存下這種紀錄的第一筆新紀錄時結束這一輪（分段測試，見 fork_run.py）")
    parser.add_argument("--supervised", action="store_true",
                        help="無人值守的測試：把每個 --prompt 檔當成在場的人送出的下一則訊息，一般模式照有人在旁的方式"
                             "套用每回合呼叫額度（介面中有人時本來就套用）")
    parser.add_argument("--deep", action="store_true",
                        help="深入研究：研究指引與工具、驗證計畫、暫停與輪末檢討都開啟（預設關）；"
                             "無人值守時套用到這個任務，介面中是新對話的預設，可再用 /deep 切換")
    args = parser.parse_args(argv)
    if args.folder is not None and args.dir is not None:
        parser.error("give the folder once")
    if args.stop_at and not args.record:
        parser.error("--stop-at goes with --record")
    if args.record and args.resume and args.source:
        parser.error("a recorded continuation takes its sources from the earlier run, not --from")
    if args.record and not args.resume and (args.folder or args.dir or not args.source):
        parser.error("a new recorded task is copied from --from into RUN/workspace; give no folder")
    if args.record and args.resume and not (args.folder or args.dir):
        parser.error("a recorded continuation needs the earlier record folder")
    directory = (args.folder or args.dir or Path.cwd()).resolve()
    if directory.exists() and not directory.is_dir():
        print(f"Co-Scientist 啟動失敗：不是資料夾：{directory}", file=sys.stderr)
        return 1
    if args.prompt:
        for stream in (sys.stdout, sys.stderr):
            reconfigure = getattr(stream, "reconfigure", None)
            if callable(reconfigure):
                # A redirected Windows console cannot encode every model character (as in opencode/cli.py).
                reconfigure(errors="backslashreplace")
        try:
            prompts = [path.read_text(encoding="utf-8-sig") for path in args.prompt]
            if not all(text.strip() for text in prompts):
                raise ValueError("a prompt file is empty")
            if args.record:
                if __package__:
                    from . import recording
                else:
                    import recording
                return recording.record_round(
                    args.record, prompts, build=build_app, run=run_round, prepare=install_deep_skills,
                    source=args.source,
                    prior=directory if args.resume else None, llm_config=args.llm_config, no_review=args.no_review,
                    deep=args.deep, supervised=args.supervised, stop_at=args.stop_at, prompt_files=args.prompt)
            sources = _copy_source(args.source.resolve(), directory) if args.source else None
            directory.mkdir(parents=True, exist_ok=True)
            outcome = run_unattended(directory, prompts, llm_config=args.llm_config, resume=args.resume,
                                     no_review=args.no_review, deep=args.deep, supervised=args.supervised,
                                     sources=sources)
        except (ImportError, OSError, RuntimeError, ValueError) as exc:
            print(f"Co-Scientist 啟動失敗：{exc}", file=sys.stderr)
            return 1
        turns = outcome["turns"]
        return 0 if turns and len(turns) == len(prompts) and all(
            (turn.get("result") or {}).get("status") == "completed" for turn in turns) else 1
    if args.source or args.resume or args.no_review or args.record or args.supervised:
        parser.error("--from, --continue, --no-review, --record and --supervised go with --prompt")
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("Co-Scientist 啟動失敗：請在互動終端直接執行 co-scientist.cmd，輸入與輸出都必須是終端；"
              "無人值守請用 --prompt。", file=sys.stderr)
        return 1

    try:
        from opencode import tui
        from researchkit import task_runtime

        directory.mkdir(parents=True, exist_ok=True)
        warning = folder_tool_warning(directory)
        if warning:
            print(warning, file=sys.stderr)
        runtime, effective, model = build_app(directory, llm_config=args.llm_config)
        # The reviewer's hooks, as in every task: the verification plan before the first step, and a review
        # when the work stalls (researchkit/task_runtime.py).
        task_runtime.attach(runtime, workspace=directory)
    except (ImportError, OSError, RuntimeError, ValueError) as exc:
        print(f"Co-Scientist 啟動失敗：{exc}", file=sys.stderr)
        return 1

    initial = SimpleNamespace(agent=runtime.default_agent, model=model, deep=args.deep)
    for message in effective.messages:
        print(message)
    tui.run(runtime, initial)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
