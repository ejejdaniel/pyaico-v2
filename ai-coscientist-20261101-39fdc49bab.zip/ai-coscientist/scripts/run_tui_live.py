"""Drive the TUI headlessly with the real model and save screenshots.

A live check of tool cards, the running status line and queued prompts against a
real provider and real tools. It types into a throwaway project, never a research
workspace. Screenshots (SVG) and a text summary go to --output.

    python scripts/run_tui_live.py --output outputs/tui_live_<date>
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from llm_configuration import compose_llm_configuration, select_llm_configuration  # noqa: E402
from opencode.app import App  # noqa: E402
from opencode.store import Store  # noqa: E402
from opencode.tui import OpenCodeTUI, PromptInput  # noqa: E402

FIRST = ("列出這個資料夾的檔案，讀 notes.txt，把其中的 beta 改成 gamma，"
         "然後用 bash 執行 python count.py 並告訴我輸出。")
SECOND = "再把 notes.txt 最後加一行 delta，然後只回答「完成」。"


def prepare(project: Path):
    project.mkdir(parents=True)
    subprocess.run(["git", "init", "--quiet", str(project)], check=True)
    (project / "notes.txt").write_text("alpha\nbeta\n", encoding="utf-8")
    (project / "count.py").write_text("print(sum(range(10)), 'α')\n", encoding="utf-8")


async def exercise(ui, output: Path, log):
    shots = 0

    async def shot(pilot, label):
        nonlocal shots
        shots += 1
        await pilot.pause(0.1)
        path = ui.save_screenshot(filename=f"{shots:02d}-{label}.svg", path=str(output))
        log.append({"shot": Path(path).name, "footer": str(ui.query_one("#footer").content)})

    async with ui.run_test(size=(140, 45)) as pilot:
        await shot(pilot, "home")
        ui.query_one(PromptInput).load_text(FIRST)
        await pilot.press("enter")
        started = time.monotonic()
        queued = False
        while time.monotonic() - started < 600:
            await pilot.pause(1.0)
            if not queued and time.monotonic() - started > 3:
                await shot(pilot, "running")
                ui.query_one(PromptInput).load_text(SECOND)  # typed while the first turn runs
                await pilot.press("enter")
                await shot(pilot, "queued")
                queued = True
            if queued and ui.running_session is None and not getattr(ui, "queued", None):
                break
        await pilot.pause(1.0)
        await shot(pilot, "done")
        await pilot.press("ctrl+x", "e")
        await shot(pilot, "expanded")


def main():
    sys.stdout.reconfigure(encoding="utf-8")  # screen text includes spinner glyphs
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        os.environ[key] = str(output / "runtime" / key)
    os.environ.setdefault("LOCAL_OPENAI_API_KEY", "local")  # the local server's placeholder, as in the case runner
    project = output / "project"
    prepare(project)
    selection = select_llm_configuration(ROOT / "config/llm.opencode.json")
    config = compose_llm_configuration({}, selection).config
    runtime = App(project, store=Store(output / "session.db"), auto_approve=True, config=config)
    log = []
    asyncio.run(exercise(OpenCodeTUI(runtime), output, log))
    final = {"notes.txt": (project / "notes.txt").read_text(encoding="utf-8"), "screens": log}
    (output / "summary.json").write_text(json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(final, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
