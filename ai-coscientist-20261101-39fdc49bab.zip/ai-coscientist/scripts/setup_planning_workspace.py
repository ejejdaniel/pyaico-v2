"""Install optional general work planning in an existing explicit workspace."""

from __future__ import annotations

import argparse
from pathlib import Path

if __package__:
    from .setup_research_workspace import _prepare_packs, load_previous_manifest
else:
    from setup_research_workspace import _prepare_packs, load_previous_manifest


def _prepare_install(workspace: Path, previous_manifest: dict | None = None, *, skills: Path | None = None):
    return _prepare_packs(workspace, previous_manifest, research=False, planning=True, planning_skills=skills)


def install(workspace: Path, previous_manifest: dict | None = None) -> None:
    _, apply = _prepare_install(workspace, previous_manifest)
    apply()


def main(argv=None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("workspace", type=Path)
    parser.add_argument("--previous-manifest", type=Path,
                        help="Saved runtime-manifest.json authorizing replacement of untouched old skills")
    args = parser.parse_args(argv)
    previous = load_previous_manifest(args.previous_manifest) if args.previous_manifest is not None else None
    install(args.workspace, previous)
    print(f"Work planning installed in {args.workspace.resolve()}")


if __name__ == "__main__":
    main()
