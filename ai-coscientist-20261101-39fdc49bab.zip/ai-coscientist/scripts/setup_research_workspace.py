"""Install the optional research skill/tool pack in an explicit workspace."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Callable


RESEARCH_STUB = b"from researchkit.tools import TOOLS, TURN_EXTENSION\n"
OLD_RESEARCH_STUB = b"from researchkit.tools import TOOLS\n"
PLANNING_STUB = b"from planningkit.tools import TOOLS, TURN_EXTENSION\n"
COMBINED_STUB = b"from researchkit.planning_adapter import TOOLS, TURN_EXTENSION\n"
# Research runs are long: a smaller tool result keeps the conversation for the research. The loop
# saves any longer result in full and says where; a project config that sets tool_output wins.
RESEARCH_TOOL_OUTPUT = {"max_bytes": 16 * 1024}


def _static_tool_names(path: Path, content: bytes) -> list[str]:
    """Inspect exports without running user code, imports, or tool factories.

    Only statically named Tool instances and literal TOOLS lists are known
    compatible. Dynamic exports require the user to resolve compatibility.
    """
    def unknown():
        raise ValueError(f"Cannot statically verify custom tool exports: {path}")

    try:
        tree = ast.parse(content, filename=str(path))
    except (SyntaxError, ValueError) as exc:
        raise ValueError(f"Cannot parse custom tool exports: {path}") from exc
    tool_aliases = set()
    constructor_aliases = set()
    values = {}
    exports = []

    def safe_expression(node):
        # These expressions execute at module load time. Function/lambda bodies
        # do not, but defaults do. Never accept a hidden export mutation inside
        # an otherwise static Tool constructor.
        if isinstance(node, ast.Lambda):
            for default in [*node.args.defaults, *node.args.kw_defaults]:
                if default is not None:
                    safe_expression(default)
            return
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in constructor_aliases:
                unknown()
        if isinstance(node, (ast.NamedExpr, ast.Await, ast.Yield, ast.YieldFrom, ast.ListComp,
                             ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            unknown()
        for child in ast.iter_child_nodes(node):
            safe_expression(child)

    def value(node):
        if isinstance(node, ast.Name) and node.id in values:
            return values[node.id]
        if isinstance(node, (ast.List, ast.Tuple)):
            return [value(item) for item in node.elts]
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in tool_aliases:
            name = node.args[0] if node.args else next((k.value for k in node.keywords if k.arg == "name"), None)
            if not isinstance(name, ast.Constant) or not isinstance(name.value, str) or not name.value:
                unknown()
            return ("tool", name.value)
        try:
            return ast.literal_eval(node)
        except (ValueError, TypeError):
            unknown()

    def bind(name, item):
        nonlocal exports
        if name == "TURN_EXTENSION":
            raise ValueError(f"Unknown TURN_EXTENSION conflicts with installation: {path}")
        tool_aliases.discard(name)
        constructor_aliases.discard(name)
        values[name] = item
        if name == "TOOLS":
            if not isinstance(item, list) or any(not isinstance(t, tuple) or len(t) != 2 or t[0] != "tool" for t in item):
                unknown()
            exports = [t[1] for t in item]

    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                name = alias.asname or alias.name.split(".")[0]
                if alias.name == "*" or name == "TOOLS":
                    unknown()
                bind(name, None)
                if isinstance(node, ast.ImportFrom) and node.module == "opencode.tools.types" and alias.name == "Tool":
                    tool_aliases.add(name)
                if isinstance(node, ast.ImportFrom) and node.module == "opencode.tools.types" and alias.name in {"Tool", "schema", "prop"}:
                    constructor_aliases.add(name)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.decorator_list:
                unknown()
            for default in [*node.args.defaults, *node.args.kw_defaults, node.returns]:
                if default is not None:
                    safe_expression(default)
            for arg in [*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs,
                        *([node.args.vararg] if node.args.vararg else []),
                        *([node.args.kwarg] if node.args.kwarg else [])]:
                if arg.annotation is not None:
                    safe_expression(arg.annotation)
            bind(node.name, None)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(not isinstance(target, ast.Name) for target in targets) or node.value is None:
                unknown()
            if isinstance(node, ast.AnnAssign):
                safe_expression(node.annotation)
            safe_expression(node.value)
            item = value(node.value)
            for target in targets:
                bind(target.id, item)
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
            continue
        elif isinstance(node, ast.Pass):
            continue
        else:
            unknown()
    return exports


def _tool_files(workspace: Path) -> dict[Path, bytes]:
    found = {}
    for name in ("tools", "tool"):
        root = workspace / ".opencode" / name
        if root.exists() and not root.is_dir():
            raise ValueError(f"Installation parent is not a directory: {root}")
        if not root.resolve().is_relative_to(workspace):
            raise ValueError(f"Installation directory escapes workspace: {root}")
        for path in sorted(root.glob("*.py")):
            if not path.resolve().is_relative_to(workspace) or not path.is_file():
                raise ValueError(f"Invalid tool installation path: {path}")
            found[path] = path.read_bytes()
    return found


def _validate_previous_manifest(manifest: dict) -> None:
    if not isinstance(manifest, dict):
        raise ValueError("Previous runtime manifest must be a JSON object")
    for name, digest in manifest.items():
        if (not isinstance(name, str) or not name or not isinstance(digest, str)
                or len(digest) != 64 or any(c not in "0123456789abcdefABCDEF" for c in digest)):
            raise ValueError(f"Invalid SHA-256 entry in previous runtime manifest: {name!r}")


def load_previous_manifest(path: Path) -> dict:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    _validate_previous_manifest(manifest)
    return manifest


def _installed_bytes(path: Path) -> bytes | None:
    for parent in path.parents:
        if parent.exists():
            if not parent.is_dir():
                raise ValueError(f"Installation parent is not a directory: {parent}")
            break
    if path.exists():
        if not path.is_file():
            raise ValueError(f"Installation target is not a file: {path}")
        return path.read_bytes()
    return None


def _prepare_install(workspace: Path, previous_manifest: dict | None = None, *,
                     skills: Path | None = None, planning: bool = False) -> tuple[list[str], Callable[[], None]]:
    return _prepare_packs(workspace, previous_manifest, research=True, planning=planning, research_skills=skills)


def _prepare_packs(workspace: Path, previous_manifest: dict | None = None, *,
                   research: bool, planning: bool, research_skills: Path | None = None,
                   planning_skills: Path | None = None) -> tuple[list[str], Callable[[], None]]:
    """Validate the entire installation before returning its deferred write step.

    The runner can preserve its existing baseline between validation and writes.
    No new persisted plan or manifest format is involved.
    """
    if previous_manifest is not None:
        _validate_previous_manifest(previous_manifest)
    workspace = workspace.resolve()
    if planning and not workspace.is_dir():
        raise ValueError(f"Planning workspace must be an existing directory: {workspace}")
    plugins = _tool_files(workspace)
    plugin = workspace / ".opencode" / "tools" / "research.py"
    planning_plugin = workspace / ".opencode" / "tools" / "planning.py"
    previous = _installed_bytes(plugin)
    previous_planning = _installed_bytes(planning_plugin)
    if previous not in (None, RESEARCH_STUB, OLD_RESEARCH_STUB, COMBINED_STUB):
        raise ValueError(f"Existing plugin differs: {plugin}")
    if previous_planning not in (None, PLANNING_STUB):
        raise ValueError(f"Existing plugin differs: {planning_plugin}")
    install_research_skills = research
    research = research or previous is not None
    planning = planning or previous_planning is not None or previous == COMBINED_STUB
    packs = []
    names = {}
    if research:
        import researchkit
        from researchkit.tools import TOOLS
        if install_research_skills:
            packs.append((research_skills or Path(researchkit.__file__).parent / "skills", "researchkit", "research-practice"))
        names.update({tool.name: plugin for tool in TOOLS})
    if planning:
        import planningkit
        packs.append((planning_skills or Path(planningkit.__file__).parent / "skills", "planningkit", "work-planning"))
        from planningkit.tools import TOOLS as PLANNING_TOOLS
        names.update({tool.name: planning_plugin for tool in PLANNING_TOOLS})
    for path, raw in plugins.items():
        if path in (plugin, planning_plugin):
            continue
        for name in _static_tool_names(path, raw):
            if name in names:
                raise ValueError(f"Conflicting tool name {name!r}: {path} and {names[name]}")
            names[name] = path
    changes = []
    expected_contents = []
    for skills, package, _ in packs:
        if not skills.is_dir():
            raise ValueError(f"Packaged skills are missing: {skills}")
        for source in sorted(skills.rglob("*")):
            if not source.is_file():
                continue
            relative = source.relative_to(skills)
            destination = workspace / ".opencode" / "skills" / relative
            if not destination.resolve().is_relative_to(workspace):
                raise ValueError(f"Installation target escapes workspace: {destination}")
            current = _installed_bytes(destination)
            replacement = source.read_bytes()
            expected_contents.append((destination, current))
            if current == replacement:
                continue
            if current is not None:
                if previous_manifest is None:
                    raise ValueError(f"Existing skill differs; refusing silent replacement: {destination}")
                key = f"src/{package}/skills/" + relative.as_posix()
                expected = previous_manifest.get(key)
                if expected is None:
                    raise ValueError(f"Missing previous hash; refusing replacement: {destination}")
                if hashlib.sha256(current).hexdigest() != expected.lower():
                    raise ValueError(f"Installed guidance was edited; refusing replacement: {destination}")
            changes.append((destination, replacement))
    content = COMBINED_STUB if planning else RESEARCH_STUB
    # Keep the root config (including JSONC comments and provider settings) intact.
    config_path = workspace / ".opencode" / "opencode.json"
    previous_config = _installed_bytes(config_path)
    config = json.loads(previous_config.decode("utf-8")) if previous_config is not None else {}
    if not isinstance(config, dict):
        raise ValueError(f"Project config must be an object: {config_path}")
    instructions = config.get("instructions", [])
    if not isinstance(instructions, list) or not all(isinstance(p, str) for p in instructions):
        raise ValueError(f"Project instructions must be a string list: {config_path}")
    for _, _, skill_name in packs:
        homepage = f".opencode/skills/{skill_name}/SKILL.md"
        if homepage not in instructions:
            instructions = [*instructions, homepage]
    config = {**config, "instructions": instructions}
    if research and "tool_output" not in config:
        config["tool_output"] = dict(RESEARCH_TOOL_OUTPUT)
    backup = plugin.with_suffix(".py.pre-turn-extension.bak")
    previous_backup = _installed_bytes(backup)
    if previous == OLD_RESEARCH_STUB and previous_backup not in (None, OLD_RESEARCH_STUB):
        raise ValueError(f"Existing plugin backup differs: {backup}")
    config_content = (json.dumps(config, ensure_ascii=False, indent=2) + "\n").replace("\n", os.linesep).encode("utf-8")
    expected_contents.extend([(config_path, previous_config), (plugin, previous), (backup, previous_backup),
                              (planning_plugin, previous_planning)])
    for destination, _ in expected_contents:
        if not destination.resolve().is_relative_to(workspace):
            raise ValueError(f"Installation target escapes workspace: {destination}")

    def apply() -> None:
        # A runner's baseline copy can take time. Recheck every target before any
        # write so an intervening user edit cannot be overwritten by this plan.
        if _tool_files(workspace) != plugins:
            raise ValueError(f"Tool installation changed after validation: {workspace}")
        for destination, expected in expected_contents:
            if not destination.resolve().is_relative_to(workspace):
                raise ValueError(f"Installation target changed after validation: {destination}")
            if _installed_bytes(destination) != expected:
                raise ValueError(f"Installation target changed after validation; refusing replacement: {destination}")
        for destination, replacement in changes:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(replacement)
        plugin.parent.mkdir(parents=True, exist_ok=True)
        if previous == OLD_RESEARCH_STUB and previous_backup is None:
            with backup.open("xb") as stream:
                stream.write(previous)
        if research and previous != content:
            plugin.write_bytes(content)
        if research and previous_planning is not None:
            planning_plugin.unlink()
        elif planning and not research and previous_planning != PLANNING_STUB:
            planning_plugin.write_bytes(PLANNING_STUB)
        if previous_config != config_content:
            config_path.write_bytes(config_content)

    return [str(destination) for destination, _ in changes], apply


def install(workspace: Path, previous_manifest: dict | None = None, *, planning: bool = False) -> None:
    _, apply = _prepare_install(workspace, previous_manifest, planning=planning)
    apply()


def upgrade_test_guidance(workspace, project, previous_manifest, *, planning=False):
    """Update only untouched installed guidance in a folder the earlier installer set up (the offline
    continuation diagnostic does, on its copy); the one entry installs nothing."""
    changed, apply = _prepare_install(workspace, previous_manifest,
                                      skills=project / "src/researchkit/skills", planning=planning)
    apply()
    return changed


def main(argv=None) -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("workspace", type=Path)
    parser.add_argument("--previous-manifest", type=Path,
                        help="Saved runtime-manifest.json authorizing replacement of untouched old skills")
    parser.add_argument("--planning", action="store_true", help="Also install optional general work planning")
    args = parser.parse_args(argv)
    previous = load_previous_manifest(args.previous_manifest) if args.previous_manifest is not None else None
    install(args.workspace, previous, planning=args.planning)
    print(f"Research skills/tools installed in {args.workspace.resolve()}")


if __name__ == "__main__":
    main()
