"""Python port of the OpenCode coding agent (reference: opencode v1.18.9)."""

__version__ = "1.18.9"

VERSION = __version__
