"""Private terminal presentation helpers; never create runtime state or artifacts.

Live assistant prose arrives through App.prompt(on_text=...), and formal
results through session.result. message.updated only invalidates saved history;
its body can precede the runtime's draft classification.
"""

from __future__ import annotations

import difflib
from collections.abc import Iterable
from dataclasses import dataclass, field

from rich.cells import cell_len
from rich.console import Group, RenderableType
from rich.markdown import Markdown
from rich.padding import Padding
from rich.panel import Panel
from rich.text import Text

from opencode.store import latest_human_message


# OpenCode 1.18.9 packages/tui/src/theme/assets/opencode.json, dark theme.
BACKGROUND = "#0a0a0a"
PANEL = "#141414"
ELEMENT = "#1e1e1e"
FOREGROUND = "#eeeeee"
MUTED = "#808080"
PRIMARY = "#fab283"
SECONDARY = "#5c9cf5"
ERROR = "#e06c75"
SUCCESS = "#7fd88f"
INFO = "#56b6c2"

# Collapsed tool cards show this many body lines; the rest is one click away.
TOOL_PREVIEW_LINES = 8
# Argument keys tried in order for the one-line summary of a call.
_PRIMARY_KEYS = ("filePath", "path", "command", "pattern", "url", "query", "description", "name", "prompt")
_EDIT_TOOLS = {"edit", "write"}


def _clip(value: str, width: int) -> str:
    value = " ".join(str(value).split())
    if cell_len(value) <= width:
        return value
    while value and cell_len(value) > width - 1:
        value = value[:-1]
    return value + "…"


def tool_primary_argument(tool_input: dict) -> str:
    """Pick the argument a reader most needs to identify the call."""
    for key in _PRIMARY_KEYS:
        value = tool_input.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def tool_diff_lines(tool: str, tool_input: dict) -> list[str] | None:
    """A unified diff derived from the call's own arguments, or None.

edit carries both sides of the change. write carries only the new content, so
it is shown as added lines; the previous file body is not known here.
"""
    path = tool_input.get("filePath") or ""
    if tool == "edit" and isinstance(tool_input.get("oldString"), str) and isinstance(tool_input.get("newString"), str):
        old, new = tool_input["oldString"].splitlines(), tool_input["newString"].splitlines()
    elif tool == "write" and isinstance(tool_input.get("content"), str):
        old, new = [], tool_input["content"].splitlines()
    else:
        return None
    return list(difflib.unified_diff(old, new, f"a/{path}", f"b/{path}", lineterm="", n=3))


def _diff_text(lines: list[str]) -> Text:
    text = Text()
    for line in lines:
        if line.startswith(("+++", "---")):
            style = f"bold {MUTED}"
        elif line.startswith("@@"):
            style = INFO
        elif line.startswith("+"):
            style = SUCCESS
        elif line.startswith("-"):
            style = ERROR
        else:
            style = MUTED
        text.append(line + "\n", style=style)
    text.rstrip()
    return text


@dataclass(eq=False)
class ToolCard:
    """One tool call: a summary line and a body that collapses when long.

Identity matters: the TUI keeps the same object across re-renders, so the
expanded flag survives history refreshes.
"""
    tool: str
    title: str
    output: str
    metadata: dict = field(default_factory=dict)
    input: dict = field(default_factory=dict)
    expanded: bool = False

    @property
    def error(self) -> bool:
        # A shell command that exited nonzero failed even though the tool call itself succeeded.
        return bool(self.metadata.get("error")) or self.metadata.get("exit") not in (None, 0)

    def body_lines(self) -> tuple[list[str], bool]:
        """Return (lines, is_diff). Errors always show their message, not a diff."""
        diff = None if self.error else tool_diff_lines(self.tool, self.input)
        if diff:
            return diff, True
        return self.output.splitlines(), False

    @property
    def collapsible(self) -> bool:
        return len(self.body_lines()[0]) > TOOL_PREVIEW_LINES

    def summary(self) -> Text:
        lines, is_diff = self.body_lines()
        marker = "✗" if self.error else ("◆" if is_diff else "●")
        argument = tool_primary_argument(self.input) or (self.title if self.title != self.tool else "")
        line = Text()
        line.append(marker + " ", style=ERROR if self.error else PRIMARY)
        line.append(self.tool or self.title or "Tool", style=f"bold {ERROR if self.error else FOREGROUND}")
        if argument:
            line.append("  " + _clip(argument, 72), style=FOREGROUND)
        if is_diff:
            added = sum(1 for item in lines if item.startswith("+") and not item.startswith("+++"))
            removed = sum(1 for item in lines if item.startswith("-") and not item.startswith("---"))
            line.append(f"  +{added}", style=SUCCESS)
            line.append(f" -{removed}", style=ERROR)
        else:
            line.append(f"  · {len(lines)} 行", style=MUTED)
        if self.metadata.get("truncated"):
            line.append("  · 輸出已截斷", style=MUTED)
        return line

    def __rich__(self) -> RenderableType:
        lines, is_diff = self.body_lines()
        shown = lines if self.expanded else lines[:TOOL_PREVIEW_LINES]
        parts: list[RenderableType] = [self.summary()]
        if shown:
            body = _diff_text(shown) if is_diff else Text("\n".join(shown), style=ERROR if self.error else MUTED)
            parts.append(Padding(body, (0, 0, 0, 2)))
        hidden = len(lines) - len(shown)
        if hidden > 0:
            parts.append(Text(f"  … 還有 {hidden} 行（點擊或 Ctrl+X E 展開）", style=MUTED))
        elif self.expanded and len(lines) > TOOL_PREVIEW_LINES:
            parts.append(Text("  （點擊收合）", style=MUTED))
        return Group(*parts)


def visible_history(messages: Iterable[dict]) -> list[dict]:
    """Project saved messages without exposing explicitly undelivered drafts.

This is only for history already owned by the session. It must not be used to
refresh live assistant prose: an in-flight draft may not have its marker yet.
"""
    return [message for message in messages if message.get("answer_review_role") != "draft"]


def saved_history(store, session_id: str) -> list[dict]:
    """Project completed history using the Store's existing review authority.

An interrupted provider can leave content before the draft marker is assigned.
For an actual reviewed turn, that failed/uncompleted content was never delivered.
Keep its explicit error, without presenting the undelivered body as an answer.
"""
    reviewed = False
    result = []
    for message in visible_history(store.messages(session_id)):
        human = latest_human_message([message])
        if human is not None:
            reviewed = store.answer_review(session_id, human["id"]) is not None
        if (reviewed and message.get("role") == "assistant" and not message.get("synthetic")
                and message.get("answer_review_role") != "answer"
                and (message.get("error") or not message.get("finish_reason"))):
            if message.get("error"):
                result.append(dict(message, content=""))
            continue
        result.append(message)
    return result


def final_response(result: dict, messages: list[dict]) -> str:
    """Omit only a result whose exact saved source already displays its body.

The caller supplies safely loaded, visible history. A presenter may return
documents absent from that history. Neither the last message nor text suffixes
identify a result's source; only the producer's messageID does.
"""
    text = result.get("text") or ""
    source_id = result.get("messageID")
    for message in messages:
        if (source_id is not None and message.get("id") == source_id
                and message.get("role") == "assistant"
                and message.get("answer_review_role") != "draft"
                and not message.get("synthetic") and not message.get("error")
                and text == (message.get("content") or "")):
            return ""
    return text


def with_tool_inputs(messages: list[dict]) -> list[dict]:
    """Attach each saved tool result's own call arguments, matched by call id."""
    calls = {}
    for message in messages:
        for call in message.get("tool_calls") or []:
            if isinstance(call, dict) and call.get("id"):
                calls[call["id"]] = call
    result = []
    for message in messages:
        call = calls.get(message.get("tool_call_id")) if message.get("role") == "tool" else None
        if call is not None and isinstance(call.get("arguments"), dict):
            message = dict(message, input=call["arguments"])
        result.append(message)
    return result


def message_renderable(message: dict) -> RenderableType:
    """Render saved content and declared metadata without reconstructing status."""
    role = message.get("role")
    body = message.get("content") or ""
    if role == "tool":
        tool_input = message.get("input")
        return ToolCard(tool=message.get("name") or "", title=message.get("title") or "",
                        output=body, metadata=message.get("metadata") or {},
                        input=tool_input if isinstance(tool_input, dict) else {})
    if message.get("synthetic"):
        return Group(Text("工作通知", style=MUTED), Markdown(body))
    if role == "user":
        return Panel(Text(body, style=FOREGROUND), border_style=PRIMARY, padding=(1, 2))
    heading = message.get("agent") or "Assistant"
    if message.get("error"):
        return Group(Text(str(heading), style=ERROR), Markdown(body), Text(str(message["error"]), style=ERROR))
    return Group(Text(str(heading), style=PRIMARY), Markdown(body))
