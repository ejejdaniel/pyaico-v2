"""Built-in and configured agents."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from opencode.paths import config_dir, data_dir, tmp_dir, truncation_dir
from opencode.permission import Rule, from_config, merge
from opencode.prompts import load as load_prompt


@dataclass
class Agent:
    name: str
    description: str = ""
    mode: str = "primary"  # primary | subagent | all
    native: bool = False
    hidden: bool = False
    prompt: str | None = None
    model: str | None = None
    temperature: float | None = None
    top_p: float | None = None
    steps: int | None = None
    color: str | None = None
    permission: list[Rule] = field(default_factory=list)
    options: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "mode": self.mode,
            "native": self.native,
            "hidden": self.hidden,
            "model": self.model,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "steps": self.steps,
            "color": self.color,
            "permission": [
                {"permission": rule.permission, "pattern": rule.pattern, "action": rule.action}
                for rule in self.permission
            ],
        }


def _whitelist(skill_dirs: list[Path]) -> dict[str, str]:
    patterns = [
        str(tmp_dir() / "**"),
        str(data_dir() / "plans" / "*"),
        *[str(path / "*") for path in skill_dirs],
    ]
    return {pattern: "allow" for pattern in patterns}


def _defaults(skill_dirs: list[Path]) -> list[Rule]:
    external = {"*": "ask", **_whitelist(skill_dirs)}
    return from_config(
        {
            "*": "allow",
            "doom_loop": "ask",
            "external_directory": external,
            "question": "deny",
            "plan_enter": "deny",
            "plan_exit": "deny",
            "read": {
                "*": "allow",
                "*.env": "ask",
                "*.env.*": "ask",
                "*.env.example": "allow",
            },
        }
    )


def _user_rules(config: dict) -> list[Rule]:
    permission = config.get("permission") or {}
    rules = from_config(permission if isinstance(permission, dict) else {})
    tools = config.get("tools") or {}
    if isinstance(tools, dict):
        mapped: dict = {}
        for name, enabled in tools.items():
            action = "allow" if enabled else "deny"
            if name in {"write", "edit", "patch", "apply_patch"}:
                mapped["edit"] = action
            else:
                mapped[name] = action
        rules = merge(from_config(mapped), rules)
    return rules


def _agent_rules(raw: dict) -> list[Rule]:
    permission = raw.get("permission") or {}
    rules = from_config(permission if isinstance(permission, dict) else {})
    tools = raw.get("tools") or {}
    if isinstance(tools, dict):
        mapped: dict = {}
        for name, enabled in tools.items():
            action = "allow" if enabled else "deny"
            if name in {"write", "edit", "patch", "apply_patch"}:
                mapped["edit"] = action
            else:
                mapped[name] = action
        rules = merge(from_config(mapped), rules)
    return rules


def build_agents(config: dict, *, worktree: Path, skill_dirs: list[Path] | None = None) -> dict[str, Agent]:
    skill_dirs = skill_dirs or []
    defaults = _defaults(skill_dirs)
    user = _user_rules(config)
    readonly_external = {"*": "ask", **_whitelist(skill_dirs)}
    plan_edit = {
        "*": "deny",
        str(Path(".opencode") / "plans" / "*.md"): "allow",
        str(data_dir() / "plans" / "*.md"): "allow",
    }
    agents: dict[str, Agent] = {
        "build": Agent(
            name="build",
            description="The default agent. Executes tools based on configured permissions.",
            mode="primary",
            native=True,
            permission=merge(defaults, from_config({"question": "allow", "plan_enter": "allow"}), user),
        ),
        "plan": Agent(
            name="plan",
            description="Plan mode. Disallows all edit tools.",
            mode="primary",
            native=True,
            permission=merge(
                defaults,
                from_config(
                    {
                        "question": "allow",
                        "plan_exit": "allow",
                        "task": {"general": "deny"},
                        "external_directory": {str(data_dir() / "plans" / "*"): "allow"},
                        "edit": plan_edit,
                    }
                ),
                user,
            ),
        ),
        "general": Agent(
            name="general",
            description="General-purpose agent for researching complex questions and executing multi-step tasks. Use this agent to execute multiple units of work in parallel.",
            mode="subagent",
            native=True,
            permission=merge(defaults, from_config({"todowrite": "deny"}), user),
        ),
        "explore": Agent(
            name="explore",
            description=(
                'Fast agent specialized for exploring codebases. Use this when you need to quickly find files by patterns '
                '(eg. "src/components/**/*.tsx"), search code for keywords (eg. "API endpoints"), or answer questions about the codebase. '
                'When calling this agent, specify the desired thoroughness level: "quick", "medium", or "very thorough".'
            ),
            mode="subagent",
            native=True,
            prompt=load_prompt("explore.txt"),
            permission=merge(
                defaults,
                from_config(
                    {
                        "*": "deny",
                        "grep": "allow",
                        "glob": "allow",
                        "list": "allow",
                        "bash": "allow",
                        "webfetch": "allow",
                        "websearch": "allow",
                        "read": "allow",
                        "external_directory": readonly_external,
                    }
                ),
                user,
            ),
        ),
        "compaction": Agent(
            name="compaction",
            mode="primary",
            native=True,
            hidden=True,
            prompt=load_prompt("compaction.txt"),
            permission=merge(defaults, from_config({"*": "deny"}), user),
        ),
        "title": Agent(
            name="title",
            mode="primary",
            native=True,
            hidden=True,
            temperature=0.5,
            prompt=load_prompt("title.txt"),
            permission=merge(defaults, from_config({"*": "deny"}), user),
        ),
        "summary": Agent(
            name="summary",
            mode="primary",
            native=True,
            hidden=True,
            prompt=load_prompt("summary.txt"),
            permission=merge(defaults, from_config({"*": "deny"}), user),
        ),
    }

    configured = config.get("agent") or {}
    if isinstance(configured, dict):
        for name, raw in configured.items():
            if not isinstance(raw, dict):
                continue
            if raw.get("disable") is True:
                agents.pop(name, None)
                continue
            current = agents.get(name)
            prompt = raw.get("prompt") or (current.prompt if current else None)
            permission = merge(
                current.permission if current else merge(defaults, user),
                _agent_rules(raw),
            )
            steps = raw.get("steps", raw.get("maxSteps"))
            agents[name] = Agent(
                name=name,
                description=raw.get("description") or (current.description if current else ""),
                mode=raw.get("mode") or (current.mode if current else "all"),
                native=bool(current and current.native),
                hidden=bool(raw.get("hidden", current.hidden if current else False)),
                prompt=prompt,
                model=raw.get("model") or (current.model if current else None),
                temperature=raw.get("temperature", current.temperature if current else None),
                top_p=raw.get("top_p", current.top_p if current else None),
                steps=int(steps) if steps else (current.steps if current else None),
                color=raw.get("color"),
                permission=permission,
                options=raw.get("options") or {},
            )
    # Upstream keeps saved truncated output readable unless that exact directory
    # was explicitly denied, even when a broader external-directory rule denies.
    output_glob = str(truncation_dir() / "*")
    for agent in agents.values():
        if not any(rule.permission == "external_directory" and rule.pattern == output_glob
                   and rule.action == "deny" for rule in agent.permission):
            agent.permission = merge(agent.permission, from_config({"external_directory": {output_glob: "allow"}}))
    # silence unused in case callers pass worktree for future plan paths
    _ = worktree
    _ = os
    _ = config_dir
    return agents


def default_agent_name(config: dict, agents: dict[str, Agent]) -> str:
    wanted = config.get("default_agent")
    if wanted:
        agent = agents.get(wanted)
        if agent is None:
            raise ValueError(f'default agent "{wanted}" not found')
        if agent.mode == "subagent":
            raise ValueError(f'default agent "{wanted}" is a subagent')
        if agent.hidden:
            raise ValueError(f'default agent "{wanted}" is hidden')
        return agent.name
    for agent in agents.values():
        if agent.mode != "subagent" and not agent.hidden:
            return agent.name
    raise ValueError("no primary visible agent found")


def provider_prompt(model_id: str) -> str:
    if "muse-spark" in model_id:
        return load_prompt("meta.txt")
    if "gpt-4" in model_id or "o1" in model_id or "o3" in model_id:
        return load_prompt("beast.txt")
    if "gpt" in model_id:
        if "codex" in model_id:
            return load_prompt("codex.txt")
        return load_prompt("gpt.txt")
    if "gemini-" in model_id:
        return load_prompt("gemini.txt")
    if "claude" in model_id:
        return load_prompt("anthropic.txt")
    lowered = model_id.lower()
    if "trinity" in lowered:
        return load_prompt("trinity.txt")
    if "kimi" in lowered:
        return load_prompt("kimi.txt")
    return load_prompt("default.txt")
