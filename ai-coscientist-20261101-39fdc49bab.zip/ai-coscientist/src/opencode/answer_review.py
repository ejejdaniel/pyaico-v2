"""Opt-in, same-agent answer verification. The host does not judge the answer."""

from opencode.store import latest_human_message


def configured_skill(agent):
    name = agent.options.get("answer_review_skill")
    if name is None:
        return None
    if not isinstance(name, str) or not name.strip():
        raise ValueError("answer_review_skill must be a nonblank skill name or null")
    if agent.hidden and agent.name in {"title", "summary", "compaction"}:
        raise ValueError("Auxiliary agents cannot enable answer review")
    return name


def authorize(app, session_id, agent, name):
    if agent.hidden and agent.name in {"title", "summary", "compaction"}:
        raise PermissionError("An active answer review cannot switch to an auxiliary agent")
    app.permissions.ask(session_id=session_id, permission="skill", patterns=[name],
                        ruleset=agent.permission, always=[name], metadata={"name": name})


def guidance(app, name):
    skill = app.skills.get(name)
    if skill is None:
        raise ValueError(f"Answer review skill is not available: {name}")
    from opencode.config import _frontmatter
    text = skill.location.read_text(encoding="utf-8")
    _, body = _frontmatter(text)
    return (f"Skill: {name}\nSource: {skill.location}\n"
            f"Reference directory: {skill.location.parent}\n\n{body or text}")


def resume(app, session_id, user_message_id, text):
    if not isinstance(user_message_id, str) or not user_message_id.strip():
        raise ValueError("resume_user_message_id must be a nonblank string")
    history = app.store.messages(session_id)
    human = latest_human_message(history)
    if human is None or human["id"] != user_message_id or human.get("content") != text:
        raise ValueError("Resume requires the latest original human message and its exact text")
    state = app.store.answer_review(session_id, user_message_id)
    if state is None or state["phase"] == "delivered" or state["steps_used"] >= state["step_limit"]:
        raise ValueError("This human turn has no unfinished answer review with remaining steps")
    by_id = {m["id"]: m for m in history}
    if state["phase"] == "checking":
        for field, expected in (("draft_message_id", "draft"), ("notice_message_id", "check")):
            message = by_id.get(state[field])
            if (message is None or message["role"] != "assistant"
                    or message.get("answer_review_role") != expected
                    or (expected == "check" and not message.get("synthetic"))):
                raise ValueError("Saved answer review references are missing or invalid")
    return human, state


def notice(user_message_id, draft_message_id, skill_text):
    return (
        "[宿主交付前核對；不是新的人類要求，也不是已驗證結論]\n"
        f"Original human message: {user_message_id}\n"
        f"Candidate assistant message: {draft_message_id}\n"
        "The candidate has been saved as a draft, not delivered. This is the one verification "
        "phase for this human turn, using the same agent, permissions, tools and remaining steps. "
        "Check its principal claims against original evidence. You may use tools, correct or "
        "withdraw the draft, or deliver a bounded account of what remains unknown. "
        "Earlier assistant answers and summaries are not independent evidence. "
        "Do not repeat completed work merely to show activity. "
        "Your next text-only answer after any necessary tool work will be delivered; "
        "the host will not judge whether your reasoning is correct.\n\n"
        "File-backed verification guidance (loaded by the host, not a claimed tool execution):\n"
        + skill_text
    )
