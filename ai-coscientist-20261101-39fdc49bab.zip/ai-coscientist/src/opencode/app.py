"""Runtime that ties config, storage, providers, tools, and the agent loop together."""

from __future__ import annotations

import importlib.util
import json
import logging
import sys
import threading
from pathlib import Path

from opencode.agent import build_agents, default_agent_name
from opencode.auth import AuthStore
from opencode.bus import Bus
from opencode.config import load_config, worktree_of, validate_config
from opencode.deep import load as load_deep
from opencode.instructions import collect as collect_instructions
from opencode.loop import run as run_loop, save_prompt
from opencode.lsp import LspClient, LspError, resolve_config
from opencode.mcp import McpHub
from opencode.paths import ensure_dirs
from opencode.permission import Broker, PermissionRejected
from opencode.provider import Client, ProviderError
from opencode.skills import discover
from opencode.store import Store, new_id
from opencode.tools.types import Tool, ToolResult
from opencode.tools.util import start_output_cleanup


class App:
    def __init__(
        self,
        directory: Path | None = None,
        *,
        store: Store | None = None,
        auto_approve: bool = False,
        permission_callback=None,
        question_callback=None,
        config: dict | None = None,
    ):
        ensure_dirs()
        start_output_cleanup()
        self.directory = (directory or Path.cwd()).resolve()
        self.worktree = worktree_of(self.directory)
        self.config = config if config is not None else load_config(self.directory)
        validate_config(self.config)
        self.auth = AuthStore()
        self.store = store or Store()
        self.bus = Bus()
        self.permissions = Broker(callback=permission_callback, auto=auto_approve)
        self.permissions.abort_event = self.abort_event
        self.question_callback = question_callback
        self.provider = Client(self.auth, self.config)
        self.skills = discover(self.directory, self.worktree, self.config)
        # What deep research adds while a task has it on (opencode/deep.py); its skills are read where they
        # are installed, like the folder's own.
        self.deep = load_deep(self.directory, self.worktree, self.config)
        self.agents = build_agents(self.config, worktree=self.worktree, skill_dirs=[
            skill.location.parent for skill in [*self.skills.values(), *self.deep.skills.values()]])
        self.default_agent = default_agent_name(self.config, self.agents)
        self.instructions = collect_instructions(self.directory, self.worktree, self.config)
        self.mcp = McpHub(self.config, self.directory)
        self.mcp.interactive = sys.stdin.isatty()
        self.extra_tools, self.turn_extension_factory = _load_local_tools(
            self.directory, self.config.get("tool_modules") or ())
        self._lsp: dict[tuple, LspClient] = {}
        self._lsp_lock = threading.Lock()
        self._aborts: dict[str, threading.Event] = {}
        self._execution_lock = threading.RLock()
        self._running: set[str] = set()
        # Execution-only controls: no persisted task/status schema is introduced.
        self._background: dict[str, threading.Event] = {}
        self._background_inputs: dict[str, list[tuple[str, str, int, str | None]]] = {}
        self._task_waiters: dict[str, list[tuple[threading.Event, dict]]] = {}
        self._task_parents: dict[str, str] = {}
        self._pending_notifications: dict[str, set[str]] = {}
        self._waiters: dict[str, list[tuple[threading.Event, dict]]] = {}
        self._questions: dict[str, dict] = {}
        self._question_lock = threading.Lock()
        self._question_seq = 0
        self._mcp_started = False
        self._mcp_lock = threading.Lock()
        self.generate_titles = True

    def ensure_mcp(self) -> None:
        with self._mcp_lock:
            if self._mcp_started:
                return
            self._mcp_started = True
        self.mcp.connect_all()

    def abort_event(self, session_id: str) -> threading.Event:
        with self._execution_lock:
            return self._aborts.setdefault(session_id, threading.Event())

    def abort(self, session_id: str) -> None:
        with self._execution_lock:
            descendants = {session_id}
            pending = [session_id]
            while pending:
                parent = pending.pop()
                # Cancellation follows current invocations, including jobs
                # registered before their thread starts, not historical ancestry.
                children = {child for child, owner in self._task_parents.items() if owner == parent}
                for child in children - descendants:
                    descendants.add(child)
                    pending.append(child)
            for target in descendants:
                self.abort_event(target).set()
                self._pending_notifications.pop(target, None)
                control = self._background.get(target)
                if control is not None:
                    control.set()
                self.permissions.abort(target)
                self.bus.publish("session.status", {"sessionID": target, "status": "stopping"})
            with self._question_lock:
                for question in self._questions.values():
                    if question["sessionID"] in descendants:
                        question["event"].set()

    def create_session(self, agent: str | None = None, model: str | None = None, title: str = "",
                       permission: list[dict] | None = None) -> dict:
        agent_name = agent or self.default_agent
        return self.store.create_session(
            directory=str(self.directory),
            agent=agent_name,
            model=model,
            title=title,
            permission=permission,
        )

    def session_model(self, session_id: str) -> str | None:
        return self.store.get_session(session_id).get("model")

    def prompt(self, session_id: str, text: str, **kwargs) -> dict:
        parent_id = kwargs.pop("_parent_id", None)
        control = kwargs.pop("_background_control", None)
        tools = kwargs.pop("tools", None)
        if tools is not None:
            if not isinstance(tools, dict) or any(not isinstance(k, str) or not isinstance(v, bool) for k, v in tools.items()):
                raise ValueError("tools must map tool names to booleans")
            if tools:
                self.store.update_session(session_id, permission=[
                    {"permission": name, "pattern": "*", "action": "allow" if enabled else "deny"}
                    for name, enabled in tools.items()])
        waiter = None
        with self._execution_lock:
            if ((parent_id is not None and self.abort_event(parent_id).is_set())
                    or (control is not None and (control.is_set() or self._background.get(session_id) is not control))):
                self.abort_event(session_id).set()
                raise ProviderError("aborted")
            if session_id in self._running or (session_id in self._background and control is None):
                queued = save_prompt(self, session_id, text, **{
                    key: value for key, value in kwargs.items() if key in {"agent", "model", "parts"}})
                self._pending_notifications.setdefault(session_id, set()).add(queued["id"])
                waiter = (threading.Event(), {})
                self._waiters.setdefault(session_id, []).append(waiter)
            else:
                if not kwargs.get("_continue") and kwargs.get("resume_user_message_id") is None:
                    kwargs["_saved_user"] = save_prompt(self, session_id, text, **{
                        key: value for key, value in kwargs.items() if key in {"agent", "model", "parts"}})
                self._running.add(session_id)
                if parent_id is not None:
                    self._task_parents[session_id] = parent_id
                self._aborts[session_id] = threading.Event()
        if waiter:
            while not waiter[0].wait(0.05):
                pass
            if "error" in waiter[1]:
                raise waiter[1]["error"]
            return waiter[1]["result"]
        return self._execute(session_id, text, **kwargs)

    def _finish_waiters(self, session_id, *, result=None, error=None):
        for event, box in self._waiters.pop(session_id, []):
            box["error" if error is not None else "result"] = error if error is not None else result
            event.set()

    def _execute(self, session_id: str, text: str, **kwargs) -> dict:
        """Own one session until pending notifications or the idle handoff finish."""
        released = False
        try:
            self.ensure_mcp()
            self.bus.publish("session.status", {"sessionID": session_id, "status": "busy"})
            while True:
                try:
                    result = run_loop(self, session_id, text, **kwargs)
                except ProviderError:
                    if not self.abort_event(session_id).is_set():
                        raise
                    result = {"text": "Stopped: aborted. Work is saved; no completion is claimed.",
                              "sessionID": session_id, "messageID": None,
                              "status": "aborted", "info": self.store.get_session(session_id)}
                with self._execution_lock:
                    if (result.get("status") == "completed" and not self.abort_event(session_id).is_set()
                            and self._pending_notifications.get(session_id)):
                        text = ""
                        kwargs = {name: kwargs[name] for name in ("depth", "on_text", "on_tool_result") if name in kwargs}
                        kwargs["_continue"] = True
                        continue
                    self._running.remove(session_id)
                    if session_id not in self._background:
                        self._task_parents.pop(session_id, None)
                    released = True
                    # Only the final execution return owns delivery. A presenter
                    # or a saved message alone may precede a failed commit/export.
                    self.bus.publish("session.result", {
                        "resultID": new_id("res"), "sessionID": session_id,
                        "messageID": result.get("messageID"),
                        "text": result["text"], "status": result["status"],
                    })
                    self._finish_waiters(session_id, result=result)
                    self.bus.publish("session.status", {"sessionID": session_id, "status": "idle"})
                    return result
        except KeyboardInterrupt:
            self.abort(session_id)
            with self._execution_lock:
                self._finish_waiters(session_id, error=ProviderError("aborted"))
                self._running.discard(session_id)
                if session_id not in self._background:
                    self._task_parents.pop(session_id, None)
                released = True
                self.bus.publish("session.status", {"sessionID": session_id, "status": "idle"})
            raise
        except BaseException as exc:
            with self._execution_lock:
                self._finish_waiters(session_id, error=exc)
                self._running.discard(session_id)
                if session_id not in self._background:
                    self._task_parents.pop(session_id, None)
                released = True
                self.bus.publish("session.status", {"sessionID": session_id, "status": "idle"})
            raise
        finally:
            if not released:
                with self._execution_lock:
                    self._running.discard(session_id)
                    if session_id not in self._background:
                        self._task_parents.pop(session_id, None)
                    self.bus.publish("session.status", {"sessionID": session_id, "status": "idle"})

    def run_prompt(self, session_id: str, text: str, **kwargs) -> dict:
        parent_id = kwargs.pop("_parent_id", self.store.get_session(session_id).get("parentID"))
        abort = kwargs.pop("_abort_event", None)
        if parent_id is None:
            return self.prompt(session_id, text, **kwargs)
        return self.spawn_background(session_id, text, kwargs.get("agent") or self.default_agent,
                                     kwargs.get("depth", 0), parent_id, model=kwargs.get("model"),
                                     _wait=True, _notify=False, _abort_event=abort)

    def _context_snapshot(self, session_id: str) -> tuple[list[dict], set[str]]:
        with self._execution_lock:
            history = self.store.context_messages(session_id)
            observed = {m["id"] for m in history}
            checkpoint = next((m for m in history if m.get("compaction_through")), None)
            if checkpoint:
                stored = self.store.messages(session_id)
                positions = {m["id"]: i for i, m in enumerate(stored)}
                at = positions[checkpoint["id"]]
                # Earlier notifications are represented by the accepted summary,
                # retained tail or exact overflow replay, according to Store.
                observed.update(m["id"] for m in stored[:at])
            return history, observed & self._pending_notifications.get(session_id, set())

    def _acknowledge_notifications(self, session_id: str, observed: set[str]) -> None:
        with self._execution_lock:
            pending = self._pending_notifications.get(session_id)
            if pending is not None:
                pending.difference_update(observed)
                if not pending:
                    self._pending_notifications.pop(session_id, None)

    def _has_pending_notifications(self, session_id: str) -> bool:
        with self._execution_lock:
            return bool(self._pending_notifications.get(session_id))

    def _continue_background(self, session_id: str, depth: int = 0) -> None:
        try:
            self._execute(session_id, "", _continue=True, depth=depth)
        except Exception as exc:
            self.bus.publish("session.error", {"sessionID": session_id, "error": str(exc)})
            logging.getLogger(__name__).warning("Background continuation stopped; saved work retained", exc_info=True)

    def spawn_background(self, session_id: str, text: str, agent: str, depth: int, parent_id: str, *,
                         model: str | None = None, _wait: bool = False, _notify: bool = True,
                         _abort_event: threading.Event | None = None):
        control = threading.Event()
        waiter = (threading.Event(), {}) if _wait else None
        existing = False
        while True:
            with self._execution_lock:
                if _abort_event is not None and _abort_event.is_set():
                    raise ProviderError("Task cancelled")
                if self.abort_event(parent_id).is_set():
                    control.set()
                    self.abort_event(session_id).set()
                    if _wait:
                        raise ProviderError("aborted")
                    return
                current = self._background.get(session_id)
                if current is None or not current.is_set():
                    if current is not None:
                        self._background_inputs.setdefault(session_id, []).append((text, agent, depth, model))
                        existing = True
                    else:
                        self._background[session_id] = control
                        self._background_inputs[session_id] = []
                        self._task_parents[session_id] = parent_id
                    if waiter:
                        self._task_waiters.setdefault(session_id, []).append(waiter)
                    break
            # A cancelled job cannot accept extensions. Its runner still owns
            # the session until cleanup finishes, so wait without holding the
            # execution lock before registering this new invocation.
            cancellation = _abort_event if _abort_event is not None else self.abort_event(parent_id)
            cancellation.wait(0.05)

        def worker():
            next_text = text
            options = dict(agent=agent, depth=depth, model=model)
            while True:
                error = None
                try:
                    result = self.prompt(session_id, next_text, **options,
                                         _parent_id=parent_id, _background_control=control)
                    body = result.get("text") or ""
                    state = "completed" if result.get("status") == "completed" else "error"
                    cancelled = result.get("status") == "aborted"
                except Exception as exc:
                    error = exc
                    body = str(exc)
                    state = "error"
                    cancelled = control.is_set() or self.abort_event(session_id).is_set()
                    self.bus.publish("session.error", {"sessionID": session_id, "error": str(exc)})
                with self._execution_lock:
                    if self._background.get(session_id) is not control:
                        return
                    stopped = cancelled or control.is_set() or self.abort_event(session_id).is_set()
                    queued = self._background_inputs.get(session_id)
                    if state == "completed" and not stopped:
                        if queued:
                            next_text, next_agent, next_depth, next_model = queued.pop(0)
                            options = dict(agent=next_agent, depth=next_depth, model=next_model)
                            continue
                        if self._pending_notifications.get(session_id):
                            next_text = ""
                            options = dict(depth=depth, _continue=True)
                            continue
                    # Deciding there is no more work and publishing completion
                    # share the same lock with enqueueing, so a late extension
                    # either joins this job or starts a new one after it settles.
                    self._background.pop(session_id)
                    self._background_inputs.pop(session_id, None)
                    self._task_parents.pop(session_id, None)
                    for event, box in self._task_waiters.pop(session_id, []):
                        failure = ProviderError("Task cancelled") if stopped else error
                        box["error" if failure else "result"] = failure if failure else result
                        event.set()
                    if stopped:
                        self._finish_waiters(session_id, error=ProviderError("aborted"))
                        return
                    if not _notify:
                        return
                    notification = self.store.add_message(parent_id, "user", {
                        "content": f'<task_notification id="{session_id}" state="{state}">\n{body}\n</task_notification>',
                        "synthetic": True,
                    })
                    self._pending_notifications.setdefault(parent_id, set()).add(notification["id"])
                    self.bus.publish("task.completed", {"sessionID": parent_id, "task": session_id, "state": state})
                    if parent_id not in self._running and not self.abort_event(parent_id).is_set():
                        self._running.add(parent_id)
                        threading.Thread(target=self._continue_background, args=(parent_id, max(0, depth - 1)),
                                         daemon=True, name="opencode-background-continue").start()
                    return

        if not existing:
            threading.Thread(target=worker, daemon=True, name="opencode-background-task").start()
        if waiter:
            try:
                while not waiter[0].wait(0.05):
                    if _abort_event is not None and _abort_event.is_set():
                        with self._execution_lock:
                            if not waiter[0].is_set():
                                self.abort(session_id)
                                raise ProviderError("Task cancelled")
            except KeyboardInterrupt:
                self.abort(session_id)
                raise
            finally:
                with self._execution_lock:
                    waiters = self._task_waiters.get(session_id)
                    if waiters and waiter in waiters:
                        waiters.remove(waiter)
                        if not waiters:
                            self._task_waiters.pop(session_id, None)
            if "error" in waiter[1]:
                raise waiter[1]["error"]
            return waiter[1]["result"]

    def ask_questions(self, session_id: str, questions: list, *,
                      abort_event: threading.Event | None = None) -> list[list[str]]:
        abort = abort_event if abort_event is not None else self.abort_event(session_id)
        if abort.is_set():
            raise RuntimeError("Question cancelled: execution stopped")
        if self.question_callback:
            callback_done = threading.Event()
            callback_result = {}

            def respond():
                try:
                    callback_result["answers"] = self.question_callback(questions)
                except BaseException as error:
                    callback_result["error"] = error
                finally:
                    callback_done.set()

            threading.Thread(target=respond, daemon=True, name="opencode-question-callback").start()
            while not callback_done.wait(0.05):
                if abort.is_set():
                    break
            if abort.is_set():
                raise RuntimeError("Question cancelled: execution stopped")
            if "error" in callback_result:
                raise callback_result["error"]
            return callback_result["answers"]
        with self._question_lock:
            self._question_seq += 1
            request_id = f"que_{self._question_seq:06d}"
            box = {"id": request_id, "sessionID": session_id, "questions": questions, "answers": None, "event": threading.Event()}
            self._questions[request_id] = box
        try:
            self.bus.publish("question.asked", {"id": request_id, "sessionID": session_id, "questions": questions})
            while not box["event"].wait(0.05):
                if abort.is_set():
                    break
        finally:
            with self._question_lock:
                self._questions.pop(request_id, None)
        if abort.is_set():
            raise RuntimeError("Question cancelled: execution stopped; no answer was supplied")
        return box["answers"] or [[] for _ in questions]

    def reply_question(self, request_id: str, answers: list) -> bool:
        with self._question_lock:
            box = self._questions.get(request_id)
        if not box:
            return False
        box["answers"] = answers
        box["event"].set()
        return True

    def pending_questions(self) -> list[dict]:
        with self._question_lock:
            items = list(self._questions.values())
        return [{"id": item["id"], "sessionID": item["sessionID"], "questions": item["questions"]} for item in items]

    def shell(self, session_id: str, command: str) -> dict:
        from opencode.tools.shell import _bash

        with self._execution_lock:
            if session_id in self._running or session_id in self._background:
                raise RuntimeError("This session is already running; no new command was started")
            self._running.add(session_id)
            self._aborts[session_id] = threading.Event()
        try:
            self.bus.publish("session.status", {"sessionID": session_id, "status": "busy"})
            session = self.store.get_session(session_id)
            agent = self.agents.get(session.get("agent") or self.default_agent)
            ctx = type("Ctx", (), {})()
            ctx.app = self
            ctx.session_id = session_id
            ctx.agent = agent
            ctx.directory = self.directory
            ctx.worktree = self.worktree
            ctx.read_files = set()
            ctx.turn = int((session.get("meta") or {}).get("turn") or 0)
            ctx.message_id = ""
            ctx.call_id = ""
            ctx.depth = 0
            ctx.switch_agent = None
            try:
                result = _bash({"command": command}, ctx)
            except PermissionRejected as exc:
                result = ToolResult(output=str(exc), title="rejected")
            self.store.add_message(session_id, "user", {"content": f"$ {command}"})
            self.store.add_message(session_id, "assistant", {"content": result.output, "agent": agent.name if agent else "build"})
            return {"output": result.output, "title": result.title}
        except KeyboardInterrupt:
            self.abort(session_id)
            raise
        finally:
            with self._execution_lock:
                if self._pending_notifications.get(session_id) and not self.abort_event(session_id).is_set():
                    threading.Thread(target=self._continue_background, args=(session_id,),
                                     daemon=True, name="opencode-background-continue").start()
                else:
                    self._running.discard(session_id)
                    self._finish_waiters(session_id, error=ProviderError(
                        "aborted" if self.abort_event(session_id).is_set() else "Shell execution stopped"))
                    self.bus.publish("session.status", {"sessionID": session_id, "status": "idle"})

    def lsp_operation(self, operation: str, path: Path, line: int, character: int, query: str | None, *,
                      abort_event: threading.Event | None = None) -> ToolResult:
        if abort_event is not None and abort_event.is_set():
            raise LspError("aborted")
        command, env, initialization = resolve_config(path, self.config)
        if not command:
            return ToolResult(
                output="No LSP server is configured for this file, and none was found on PATH.",
                title="lsp",
            )
        key = (tuple(command), str(self.worktree), json.dumps(env, sort_keys=True), json.dumps(initialization, sort_keys=True))
        while not self._lsp_lock.acquire(timeout=0.05):
            if abort_event is not None and abort_event.is_set():
                raise LspError("aborted")
        try:
            if abort_event is not None and abort_event.is_set():
                raise LspError("aborted")
            client = self._lsp.get(key)
            if client is None:
                client = LspClient(command, self.worktree, env=env, initialization=initialization)
                client.start(abort_event=abort_event)
                self._lsp[key] = client
        finally:
            self._lsp_lock.release()
        result = client.operation(operation, path, line, character, query, abort_event=abort_event)
        return ToolResult(title=operation, output=json.dumps(result, indent=2, default=str))


    def summarize(self, session_id: str) -> str:
        self.ensure_mcp()
        history = self.store.messages(session_id)
        transcript = "\n".join(f"{item.get('role')}: {item.get('content') or ''}" for item in history)[-60_000:]
        provider, model_id = self.provider.resolve(self.store.get_session(session_id).get("model"))
        agent = self.agents.get("summary")
        completion = self.provider.complete(
            provider=provider,
            model=model_id,
            system=agent.prompt if agent else "Summarize the work.",
            messages=[{"role": "user", "content": transcript or "Empty session."}],
            tools=None,
            abort_event=self.abort_event(session_id),
        )
        return completion.text or ""


def _load_local_tools(directory: Path, modules=()) -> tuple[list[Tool], object]:
    """Tools and the turn extension from the folder's .opencode/tools files, then from config tool_modules.

    tool_modules names importable modules (the co-scientist launcher gives the research tools this
    way, so a folder needs no copies). A folder whose own tool file re-exports the same objects (an
    earlier research install) loads them once.
    """
    tools: list[Tool] = []
    factory = None

    def take(module, label):
        nonlocal factory
        if hasattr(module, "TURN_EXTENSION"):
            candidate = module.TURN_EXTENSION
            if not callable(candidate):
                raise RuntimeError(f"TURN_EXTENSION must be callable: {label}")
            if factory is not None and candidate is not factory:
                raise RuntimeError(f"Multiple TURN_EXTENSION exports; refusing to select one: {label}")
            factory = candidate
        exported = getattr(module, "TOOLS", None) or []
        for item in exported:
            if isinstance(item, Tool) and not any(item is known for known in tools):
                tools.append(item)

    roots = [directory / ".opencode" / "tools", directory / ".opencode" / "tool"]
    for root in roots:
        if not root.is_dir():
            continue
        for path in root.glob("*.py"):
            spec = importlib.util.spec_from_file_location(f"opencode_local_{path.stem}", path)
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            try:
                spec.loader.exec_module(module)
            except Exception as exc:
                raise RuntimeError(f"Cannot load configured tool extension {path}: {exc}") from exc
            take(module, path)
    if isinstance(modules, str) or not all(isinstance(name, str) and name for name in modules):
        raise RuntimeError("tool_modules must be a list of importable module names")
    for name in modules:
        try:
            module = importlib.import_module(name)
        except Exception as exc:
            raise RuntimeError(f"Cannot load configured tool module {name}: {exc}") from exc
        take(module, name)
    return tools, factory
