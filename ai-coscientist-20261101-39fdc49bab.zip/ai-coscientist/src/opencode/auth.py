"""API keys. Environment variables override the auth file, which matches `opencode auth`."""

from __future__ import annotations

import json
import os
from pathlib import Path

from opencode.paths import data_dir

ENV_KEYS = {
    "openai": ["OPENAI_API_KEY"],
    "anthropic": ["ANTHROPIC_API_KEY"],
    "google": ["GEMINI_API_KEY", "GOOGLE_GENERATIVE_AI_API_KEY", "GOOGLE_API_KEY"],
    "groq": ["GROQ_API_KEY"],
    "openrouter": ["OPENROUTER_API_KEY"],
    "xai": ["XAI_API_KEY"],
    "mistral": ["MISTRAL_API_KEY"],
    "deepseek": ["DEEPSEEK_API_KEY"],
    "together": ["TOGETHER_API_KEY"],
    "fireworks": ["FIREWORKS_API_KEY"],
    "cerebras": ["CEREBRAS_API_KEY"],
    "exa": ["EXA_API_KEY"],
    "parallel": ["PARALLEL_API_KEY"],
}


class AuthStore:
    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "auth.json")

    def _read(self) -> dict:
        content = os.environ.get("OPENCODE_AUTH_CONTENT")
        if content:
            try:
                data = json.loads(content)
                if isinstance(data, dict):
                    return data
            except json.JSONDecodeError:
                pass
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write(self, data: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self.path.chmod(0o600)
        descriptor = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2)

    def get(self, provider: str) -> str | None:
        import os

        for env_name in ENV_KEYS.get(provider, []):
            value = os.environ.get(env_name)
            if value:
                return value
        record = self._read().get(provider) or {}
        if isinstance(record, dict):
            key = record.get("key") or record.get("apiKey") or record.get("token")
            if isinstance(key, str) and key:
                return key
        return None

    def set(self, provider: str, key: str) -> None:
        data = self._read()
        normalized = provider.rstrip("/")
        if normalized != provider:
            data.pop(provider, None)
        data.pop(normalized + "/", None)
        data[normalized] = {"type": "api", "key": key}
        self._write(data)

    def remove(self, provider: str) -> None:
        data = self._read()
        data.pop(provider, None)
        data.pop(provider.rstrip("/"), None)
        self._write(data)

    def providers(self) -> list[str]:
        names = set(self._read())
        import os

        for provider, envs in ENV_KEYS.items():
            if any(os.environ.get(name) for name in envs):
                names.add(provider)
        return sorted(names)
