"""In-process event fanout for the HTTP event stream and the CLI."""

from __future__ import annotations

import queue
import threading
import time


class Bus:
    def __init__(self):
        self._subs: list[queue.Queue] = []
        self._lock = threading.Lock()

    def subscribe(self) -> queue.Queue:
        box: queue.Queue = queue.Queue()
        with self._lock:
            self._subs.append(box)
        return box

    def unsubscribe(self, box: queue.Queue) -> None:
        with self._lock:
            if box in self._subs:
                self._subs.remove(box)

    def publish(self, event_type: str, properties: dict | None = None) -> None:
        payload = {"type": event_type, "properties": properties or {}, "time": time.time()}
        with self._lock:
            subs = list(self._subs)
        for box in subs:
            box.put_nowait(payload)
