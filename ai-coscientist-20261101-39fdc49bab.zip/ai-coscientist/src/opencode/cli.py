"""OpenCode command line."""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from opencode import __version__
from opencode.app import App
from opencode.provider import ProviderError


def main(argv: list[str] | None = None) -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            # Legacy redirected Windows terminals cannot encode every model character.
            reconfigure(errors="backslashreplace")
    parser = argparse.ArgumentParser(prog="opencode", description="OpenCode coding agent (Python)")
    parser.add_argument("--version", action="version", version=f"opencode {__version__}")
    parser.add_argument("--print-logs", action="store_true")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARN", "ERROR"])
    parser.add_argument("--pure", action="store_true", help="ignore local plugins")
    parser.add_argument("--dir", default=None, help="project directory")
    parser.add_argument("--model", "-m", default=None, help="provider/model")
    parser.add_argument("--agent", "-a", default=None)
    parser.add_argument("--auto", action="store_true", help="approve permission prompts")
    sub = parser.add_subparsers(dest="command")

    run = sub.add_parser("run", help="send one prompt")
    run.add_argument("message", nargs="*")
    run.add_argument("--session", "-s")
    run.add_argument("--continue", dest="continue_session", action="store_true")

    serve = sub.add_parser("serve", help="start the HTTP server")
    _network(serve)
    web = sub.add_parser("web", help="start the server and open the web UI")
    _network(web)
    sub.add_parser("models", help="list models")
    sub.add_parser("providers", help="list providers")
    auth = sub.add_parser("auth", help="store a provider API key")
    auth.add_argument("provider")
    auth.add_argument("--key")
    agents = sub.add_parser("agent", help="list agents")
    agents.add_argument("action", nargs="?", default="list")
    session = sub.add_parser("session", help="list, export, or import sessions")
    session.add_argument("action", nargs="?", default="list")
    session.add_argument("target", nargs="?")
    mcp = sub.add_parser("mcp", help="list MCP servers or sign in with OAuth")
    mcp.add_argument("action", nargs="?", default="list")
    mcp.add_argument("name", nargs="?")
    sub.add_parser("stats", help="local usage counts")
    debug = sub.add_parser("debug", help="debug config")
    debug.add_argument("action", nargs="?", default="config")
    export = sub.add_parser("export", help="export a session as JSON")
    export.add_argument("session_id", nargs="?")
    import_cmd = sub.add_parser("import", help="import a session JSON file")
    import_cmd.add_argument("file")

    args = parser.parse_args(argv)
    if args.print_logs:
        os.environ["OPENCODE_PRINT_LOGS"] = "1"
    if args.log_level:
        os.environ["OPENCODE_LOG_LEVEL"] = args.log_level
    if args.pure:
        os.environ["OPENCODE_PURE"] = "1"
    directory = Path(args.dir).resolve() if args.dir else Path.cwd()
    if args.command in {None, "run", "serve", "web", "models", "providers", "agent", "session", "mcp", "stats", "debug", "export", "import"}:
        app = _app(directory, auto=args.auto)
    else:
        app = None

    if args.command is None:
        _interactive(app, args)
        return
    if args.command == "run":
        message = " ".join(args.message).strip()
        if message == "-" or (not message and not sys.stdin.isatty()):
            message = sys.stdin.read()
        if not message:
            _interactive(app, args)
            return
        session_id = _pick_session(app, args)
        _print_prompt(app, session_id, message, args)
        return
    if args.command == "serve":
        _serve(app, args, open_browser=False)
        return
    if args.command == "web":
        _serve(app, args, open_browser=True)
        return
    if args.command == "models":
        _models(app)
        return
    if args.command == "providers":
        _providers(app)
        return
    if args.command == "auth":
        _auth(args)
        return
    if args.command == "agent":
        for agent in app.agents.values():
            if agent.hidden:
                continue
            print(f"{agent.name:16} {agent.mode:10} {agent.description}")
        return
    if args.command == "session":
        _session_cmd(app, args)
        return
    if args.command == "mcp":
        if args.action == "auth":
            if not args.name:
                raise SystemExit("usage: opencode mcp auth <name>")
            try:
                app.mcp.authenticate(args.name)
            except Exception as exc:
                raise SystemExit(str(exc)) from exc
            print(app.mcp.servers[args.name].status()["status"])
            return
        app.ensure_mcp()
        for item in app.mcp.servers.values():
            status = item.status()
            line = f"{status['name']:20} {status['status']:12} {status['error']}"
            if status.get("authorizationUrl"):
                line += f" {status['authorizationUrl']}"
            print(line)
        if not app.mcp.servers:
            print("no MCP servers configured")
        return
    if args.command == "stats":
        sessions = app.store.list_sessions()
        messages = sum(len(app.store.messages(item["id"])) for item in sessions)
        print(f"sessions {len(sessions)}")
        print(f"messages {messages}")
        return
    if args.command == "debug":
        print(json.dumps({"directory": str(app.directory), "worktree": str(app.worktree), "config": app.config}, indent=2, default=str))
        return
    if args.command == "export":
        session_id = args.session_id or _latest(app)
        print(json.dumps({"session": app.store.get_session(session_id), "messages": app.store.messages(session_id)}, indent=2))
        return
    if args.command == "import":
        _import(app, Path(args.file))
        return
    parser.print_help()


def _network(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--hostname", default="127.0.0.1")
    parser.add_argument("--password", default=None)


def _app(directory: Path, auto: bool) -> App:
    def permission_callback(pending):
        if not sys.stdin.isatty():
            print(f"denied {pending.permission} {pending.patterns}", file=sys.stderr)
            return "reject"
        print(f"\nPermission: {pending.permission} {pending.patterns}", file=sys.stderr)
        answer = input("Allow? [y]es / [a]lways / [n]o > ").strip().lower()
        if answer in {"y", "yes"}:
            return "once"
        if answer in {"a", "always"}:
            return "always"
        return "reject"

    def question_callback(questions):
        answers = []
        for question in questions:
            prompt = question.get("question") if isinstance(question, dict) else str(question)
            options = question.get("options") or [] if isinstance(question, dict) else []
            print(f"\n{prompt}")
            for index, option in enumerate(options, start=1):
                label = option.get("label") if isinstance(option, dict) else str(option)
                print(f"  {index}. {label}")
            raw = input("> ").strip()
            if raw.isdigit() and 1 <= int(raw) <= len(options):
                option = options[int(raw) - 1]
                label = option.get("label") if isinstance(option, dict) else str(option)
                answers.append([label])
            elif raw:
                answers.append([raw])
            else:
                answers.append([])
        return answers

    app = App(
        directory,
        auto_approve=auto,
        permission_callback=None if auto else permission_callback,
        question_callback=question_callback,
    )
    return app


def _pick_session(app: App, args) -> str:
    if getattr(args, "session", None):
        return args.session
    if getattr(args, "continue_session", False):
        return _latest(app)
    created = app.create_session(agent=args.agent, model=args.model)
    return created["id"]


def _latest(app: App) -> str:
    sessions = [item for item in app.store.list_sessions(str(app.directory)) if not item.get("parentID")]
    if not sessions:
        raise SystemExit("no sessions")
    return sessions[0]["id"]


def _print_prompt(app: App, session_id: str, message: str, args) -> None:
    streamed = []

    def on_text(piece: str) -> None:
        streamed.append(piece)
        print(piece, end="", flush=True)

    try:
        result = app.prompt(session_id, message, agent=args.agent, model=args.model,
                            on_text=on_text, on_tool_result=_file_presenter(app))
    except ProviderError as exc:
        raise SystemExit(str(exc)) from exc
    _print_final_result(app, session_id, result, "".join(streamed))
    if result.get("text") and not sys.stdout.isatty():
        return
    print()


def _file_presenter(app: App):
    """Show tool-produced file locations without parsing model prose."""
    shown = set()

    def present(result):
        files = result.metadata.get("files")
        if not isinstance(files, list):
            return
        for name in files:
            if not isinstance(name, str) or not name:
                continue
            path = (app.directory / name).resolve()
            if path in shown or not path.is_file():
                continue
            shown.add(path)
            print(f"\n[File] {path}", flush=True)

    return present


def _interactive(app: App, args) -> None:
    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            from opencode.tui import run
        except ModuleNotFoundError as exc:
            if exc.name == "textual" or (exc.name or "").startswith("textual."):
                raise SystemExit("全螢幕介面需要 textual==8.2.8；請安裝專案依賴後重試。") from exc
            raise
        session_id = (_pick_session(app, args)
                      if getattr(args, "continue_session", False) or getattr(args, "session", None) else None)
        run(app, args, session_id=session_id)
        return
    session_id = _pick_session(app, args) if getattr(args, "continue_session", False) or getattr(args, "session", None) else app.create_session(agent=args.agent, model=args.model)["id"]
    print(f"opencode {__version__}  session {session_id}")
    print("type /help for commands, /quit to exit")
    while True:
        try:
            line = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not line:
            continue
        if line.startswith("/"):
            switched = _slash(app, session_id, line, args)
            if isinstance(switched, str) and switched.startswith("ses_"):
                session_id = switched
            continue
        try:
            _print_prompt(app, session_id, line, args)
        except SystemExit as exc:
            print(f"\n{exc}")
            continue
        print()


def _print_final_result(app: App, session_id: str, result: dict, streamed: str) -> None:
    text = result.get("text") or ""
    last_body = next((m.get("content") or "" for m in reversed(app.store.messages(session_id))
                      if m.get("role") == "assistant" and not m.get("synthetic") and not m.get("error")), "")
    if text and not (text == last_body and streamed.endswith(text)):
        print("\n\n[Final response]\n" + text, flush=True)


def _slash(app: App, session_id: str, line: str, args):
    parts = line.split(maxsplit=1)
    name = parts[0][1:]
    rest = parts[1] if len(parts) > 1 else ""
    if name in {"quit", "exit"}:
        raise SystemExit(0)
    if name == "help":
        print("/help /new /sessions /agent <name> /model <provider/model> /compact /undo /export /quit")
        return True
    if name == "new":
        created = app.create_session(agent=args.agent, model=args.model, title=rest)
        print(created["id"])
        return created["id"]
    if name == "sessions":
        for item in app.store.list_sessions(str(app.directory)):
            if item.get("parentID"):
                continue
            print(f"{item['id']}  {item.get('title') or '(untitled)'}")
        return True
    if name == "agent":
        if rest:
            if rest not in app.agents:
                print("unknown agent")
                return True
            app.store.update_session(session_id, agent=rest)
            args.agent = rest
            print(f"agent {rest}")
        else:
            print(app.store.get_session(session_id).get("agent"))
        return True
    if name == "model":
        if rest:
            args.model = rest
            app.store.update_session(session_id, model=rest)
            print(f"model {rest}")
        else:
            print(app.store.get_session(session_id).get("model") or app.config.get("model") or "(default)")
        return True
    if name == "compact":
        print(app.summarize(session_id))
        return True
    if name == "undo":
        restored = app.store.revert(session_id)
        print("\n".join(restored) or "nothing to undo")
        return True
    if name == "export":
        print(json.dumps({"session": app.store.get_session(session_id), "messages": app.store.messages(session_id)}, indent=2))
        return True
    command = (app.config.get("command") or {}).get(name)
    if isinstance(command, dict):
        template = command.get("template") or ""
        text = template.replace("$ARGUMENTS", rest).replace("$1", rest)
        result = app.prompt(session_id, text, agent=command.get("agent") or args.agent,
                            model=command.get("model") or args.model, on_tool_result=_file_presenter(app))
        print(result.get("text") or "")
        return True
    print(f"unknown command /{name}")
    return True


def _serve(app: App, args, open_browser: bool) -> None:
    from opencode.server import Server

    port = args.port or (4096 if open_browser else 0)
    server = Server(app, host=args.hostname, port=port, password=args.password)
    print(f"opencode server listening on {server.url}", flush=True)
    if open_browser:
        import webbrowser

        webbrowser.open(server.url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print()


def _models(app: App) -> None:
    for provider in app.provider.available():
        models = provider.models or [provider.default_model]
        for model in models:
            if model:
                print(f"{provider.id}/{model}")


def _providers(app: App) -> None:
    for provider in app.provider.providers.values():
        ready = "ready" if app.provider.key_for(provider) or provider.id == "ollama" else "missing key"
        print(f"{provider.id:16} {provider.api:10} {ready}")


def _auth(args) -> None:
    from opencode.auth import AuthStore

    key = args.key or getpass.getpass(f"{args.provider} API key: ")
    if not key:
        raise SystemExit("empty key")
    AuthStore().set(args.provider, key)
    print(f"saved {args.provider}")


def _session_cmd(app: App, args) -> None:
    if args.action == "list":
        for item in app.store.list_sessions(str(app.directory)):
            print(f"{item['id']}  {item.get('title') or '(untitled)'}")
        return
    if args.action == "export" and args.target:
        print(json.dumps({"session": app.store.get_session(args.target), "messages": app.store.messages(args.target)}, indent=2))
        return
    if args.action == "import" and args.target:
        _import(app, Path(args.target))
        return
    raise SystemExit("usage: opencode session [list|export <id>|import <file>]")


def _import(app: App, path: Path) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    info = data.get("session") or {}
    created = app.create_session(agent=info.get("agent"), model=info.get("model"), title=info.get("title") or path.stem)
    for message in data.get("messages") or []:
        app.store.add_message(created["id"], message.get("role") or "user", message)
    print(created["id"])


if __name__ == "__main__":
    main()
