"""Native ICU support for the source's default String.localeCompare sorting.

ICU and locale data are host dependencies. Their versions can change ordering;
this module does not substitute code-point sorting when ICU is unavailable.
"""

from __future__ import annotations

import ctypes
import ctypes.util
from functools import cmp_to_key, lru_cache
import re
import sys
import weakref


_FUNCTIONS = ("ucol_open", "ucol_setAttribute", "ucol_strcoll", "ucol_close")
_NORMALIZATION_MODE = 4
_ON = 17


def _library_names() -> list[str]:
    if sys.platform == "win32":
        return ["icu.dll"]
    if sys.platform == "darwin":
        return ["/usr/lib/libicucore.A.dylib"]
    if sys.platform.startswith("linux"):
        found = ctypes.util.find_library("icui18n")
        return list(dict.fromkeys([found, "libicui18n.so"] if found else ["libicui18n.so"]))
    return []


def _load_icu():
    failures = []
    for name in _library_names():
        try:
            # Windows 10 1903+ exposes the C API in the system ICU DLL.
            library = ctypes.CDLL(name, winmode=0x00000800) if sys.platform == "win32" else ctypes.CDLL(name)
        except OSError as error:
            failures.append(str(error))
            continue
        suffixes = [""]
        if match := re.search(r"\.so\.(\d+)", name):
            suffixes.append("_" + match[1])
        # An unversioned SONAME may still export ICU's renamed C entry points.
        # ICU release versions are represented by an unsigned byte.
        suffixes.extend(f"_{major}" for major in range(255, 0, -1))
        for suffix in dict.fromkeys(suffixes):
            if all(hasattr(library, function + suffix) for function in _FUNCTIONS):
                return library, suffix
        failures.append(f"{name} does not expose the required ICU collation C API")
    detail = "; ".join(failures) or f"unsupported platform {sys.platform}"
    raise RuntimeError(f"ICU collation is required but unavailable. Install the system ICU runtime. {detail}")


class _Collator:
    def __init__(self, locale: str | None = None):
        self._library, suffix = _load_icu()
        open_collator = getattr(self._library, "ucol_open" + suffix)
        open_collator.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_int32)]
        open_collator.restype = ctypes.c_void_p
        set_attribute = getattr(self._library, "ucol_setAttribute" + suffix)
        set_attribute.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_int32)]
        set_attribute.restype = None
        self._compare = getattr(self._library, "ucol_strcoll" + suffix)
        self._compare.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint16), ctypes.c_int32,
                                 ctypes.POINTER(ctypes.c_uint16), ctypes.c_int32]
        self._compare.restype = ctypes.c_int
        close = getattr(self._library, "ucol_close" + suffix)
        close.argtypes = [ctypes.c_void_p]
        close.restype = None
        status = ctypes.c_int32(0)
        self._handle = open_collator(locale.encode("utf-8") if locale is not None else None, ctypes.byref(status))
        if not self._handle or status.value > 0:
            if self._handle:
                close(self._handle)
            raise RuntimeError(f"Cannot open ICU collator (UErrorCode {status.value})")
        self._finalizer = weakref.finalize(self, close, self._handle)
        # ECMA-402 requires canonical equivalence. ICU defaults normalization
        # off for many locales, unlike the source's Intl.Collator behavior.
        status.value = 0
        set_attribute(self._handle, _NORMALIZATION_MODE, _ON, ctypes.byref(status))
        if status.value > 0:
            self._finalizer()
            raise RuntimeError(f"Cannot enable ICU collation normalization (UErrorCode {status.value})")

    def compare(self, left: str, right: str) -> int:
        encoding = "utf-16-le" if sys.byteorder == "little" else "utf-16-be"
        a = left.encode(encoding, errors="surrogatepass")
        b = right.encode(encoding, errors="surrogatepass")
        left_units = (ctypes.c_uint16 * (len(a) // 2)).from_buffer_copy(a)
        right_units = (ctypes.c_uint16 * (len(b) // 2)).from_buffer_copy(b)
        return self._compare(self._handle, left_units, len(left_units), right_units, len(right_units))


@lru_cache(maxsize=1)
def _default_collator() -> _Collator:
    return _Collator()


def _locale_compare(left: str, right: str) -> int:
    return _default_collator().compare(left, right)


_locale_key = cmp_to_key(_locale_compare)
