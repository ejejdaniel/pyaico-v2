"""OpenCode-style anchored summaries, preserving recent complete tool exchanges."""

from __future__ import annotations

from copy import deepcopy
import json
import re

from opencode.provider import ProviderError, openai_messages_from_history


TOOL_OUTPUT_MAX_CHARS = 2_000
CONTINUE_PROMPT = "Continue if you have next steps, or stop and ask for clarification if you are unsure how to proceed."
# In an unattended run nobody can answer a question, so stopping to ask ends the work early.
UNATTENDED_CONTINUE_PROMPT = (
    "Continue with the next steps of the work. This run is unattended: no user can answer questions, so record "
    "open questions and assumptions in your notes instead of stopping to ask. If the commissioned work is already "
    "delivered, check the delivered results against the saved work once; when they agree, give your final answer "
    "instead of starting new work. Do not write a summary of the conversation as a reply; the summary above "
    "already preserves it."
)

# Shared by the upstream V1 compactor via core/session/compaction.buildPrompt.
SUMMARY_TEMPLATE = """Output exactly the Markdown structure shown inside <template> and keep the section order unchanged. Do not include the <template> tags in your response.
<template>
## Objective
- [one or two brief sentences describing what the user is trying to accomplish]

## Important Details
- [constraints/preferences, decisions and why, important facts/assumptions, exact context needed to continue, or "(none)"]

## Work State
### Completed
- [finished work, verified facts, or changes made; otherwise "(none)"]

### Active
- [current work, partial changes, or investigation state; otherwise "(none)"]

### Blocked
- [blockers, failing commands, or unknowns; otherwise "(none)"]

## Next Move
1. [immediate concrete action, or "(none)"]
2. [next action if known, or "(none)"]

## Relevant Files
- [file or directory path: why it matters, or "(none)"]
</template>

Rules:
- Keep every section, even when empty.
- Use terse bullets, not prose paragraphs.
- Preserve exact file paths, symbols, commands, error strings, URLs, and identifiers when known.
- Do not mention the summary process or that context was compacted."""


def _chars(value: str) -> int:
    # JavaScript String.length counts UTF-16 code units, including astral pairs.
    return len(value.encode("utf-16-le", errors="surrogatepass")) // 2


def estimate_tokens(value) -> int:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return (_chars(text) + 2) // 4


def settings(app) -> dict:
    cfg = app.config.get("compaction")
    if cfg is None:
        return {}
    if not isinstance(cfg, dict):
        raise ProviderError("compaction must be an object")
    for name in ("tail_turns", "preserve_recent_tokens", "reserved"):
        value = cfg.get(name)
        if name in cfg and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            raise ProviderError(f"compaction.{name} must be a nonnegative integer")
    for name in ("auto", "prune"):
        if name in cfg and not isinstance(cfg[name], bool):
            raise ProviderError(f"compaction.{name} must be a boolean")
    return cfg


def usable_budget(app, provider, model: str) -> int:
    if provider.context == 0:
        return 0
    output_limit = getattr(app.provider, "output_limit", None)
    reserve = output_limit(provider, model) if output_limit else min(8192, provider.context // 4)
    model_config = getattr(app.provider, "_model_config", None)
    limits = (model_config(provider.id, model).get("limit") or {}) if model_config else {}
    explicit = limits.get("input", 0)
    if isinstance(explicit, bool) or not isinstance(explicit, int) or explicit < 0:
        raise ProviderError("Model input limit must be a nonnegative integer")
    if explicit:
        return max(0, explicit - settings(app).get("reserved", min(20000, reserve)))
    return max(0, provider.context - reserve)


def input_budget(app, provider, model: str, system: str = "", tools=None) -> int:
    return usable_budget(app, provider, model) - estimate_tokens([system, tools or []])


def usage_overflow(app, session_id: str, provider, model: str) -> bool:
    """Use the latest completed response's actual usage when it is available, plus what came after it.

    That usage covers the response's prompt and reply; the next request also carries the tool
    results and messages saved since. v41's response used 229,684 of 230,144 tokens, so nothing was
    compacted; its tool results took the next prompt to 230,400, and the provider refused it.
    """
    if settings(app).get("auto") is False or provider.context == 0:
        return False
    added = []
    for message in reversed(app.store.messages(session_id)):
        if message.get("compaction_through"):
            if not message.get("error") and message.get("finish_reason"):
                return False
            continue
        if message.get("error"):
            continue
        if message.get("role") != "assistant" or "tokens" not in message:
            added.append(message.get("content") or "")
            continue
        tokens = message.get("tokens") or {}
        count = tokens.get("total_tokens") or tokens.get("total") or (
            (tokens.get("prompt_tokens") or tokens.get("input_tokens") or 0)
            + (tokens.get("completion_tokens") or tokens.get("output_tokens") or 0)
            + (tokens.get("cache_read_input_tokens") or 0)
            + (tokens.get("cache_creation_input_tokens") or 0)
        )
        return count + (estimate_tokens(added) if added else 0) >= usable_budget(app, provider, model)
    return False


def exchanges(history: list[dict]) -> list[list[dict]]:
    # Upstream stores tool calls/results together in one assistant message.
    groups: list[list[dict]] = []
    pending: set[str] = set()
    for message in history:
        if groups and (pending or message.get("role") == "tool"):
            groups[-1].append(message)
        else:
            groups.append([message])
        pending.update(c["id"] for c in message.get("tool_calls") or [])
        if message.get("role") == "tool":
            pending.discard(message.get("tool_call_id"))
    return groups


def retained_split(groups: list[list[dict]], budget: int, turns: int = 2, *, model_ref: str | None = None) -> int:
    if turns <= 0:
        return len(groups)
    starts = [i for i, group in enumerate(groups)
              if any(m.get("role") == "user" and not m.get("compaction_through") for m in group)]
    if not starts:
        return len(groups)
    ends = [*starts[1:], len(groups)]
    split, total = len(groups), 0
    for start, end in reversed(list(zip(starts, ends))[-turns:]):
        turn = [m for group in groups[start:end] for m in group]
        cost = estimate_tokens(openai_messages_from_history(turn, model_ref=model_ref))
        if total + cost <= budget:
            total += cost
            split = start
            continue
        # An oversized preceding turn can contribute a suffix too. Never cut
        # inside a complete tool exchange or truncate its text here.
        for candidate in range(start + 1, end):
            suffix = [m for group in groups[candidate:end] for m in group]
            if estimate_tokens(openai_messages_from_history(suffix, model_ref=model_ref)) <= budget - total:
                split = candidate
                break
        break
    return split if split > 0 else len(groups)


# A task with a review (opencode/task_skills.opening): the summary is written knowing its lessons. Its Next Move
# is where the work resumes, and one drawn from the history alone would send the agent back into what a lesson
# stopped, as acoustics round 2's request to go on from where round 1 stopped did (2026-10-31).
REVIEW_NOTE = (
    "The <task-review> above holds a reviewer's lessons from earlier rounds of this task. The agent receives them "
    "again after the summary, so do not copy them into it. Where the history ends in work that a lesson says to "
    "stop or to do another way, the Next Move follows the lesson, not the history.")


# A summary written in a stall (opencode/progress.py) must not turn the stalled stretch's suspicion into the
# work's state: round 1's summary listed "suspected numpy comparison fault" as its Active work (2026-10-31).
STALL_NOTE = (
    "The last {count} model calls made no progress the host can see: nothing new saved in the project, no new "
    "source, no project file read for the first time. Write what the agent "
    "concluded in that stretch, such as a suspected cause or a diagnosis, as an unconfirmed hypothesis under "
    "Active or Blocked, not as an established fact; a Next Move that builds on it first checks it by hand or "
    "against a source.")


def build_prompt(previous_summary: str = "", review: str = "", stall: int = 0) -> str:
    opening = (
        "Update the anchored summary below using the conversation history above.\n"
        "Preserve still-true details, remove stale details, and merge in the new facts.\n"
        f"<previous-summary>\n{previous_summary}\n</previous-summary>"
        if previous_summary else "Create a new anchored summary from the conversation history."
    )
    lessons = f"\n\n{review}\n{REVIEW_NOTE}" if review else ""
    stalled = "\n\n" + STALL_NOTE.format(count=stall) if stall else ""
    return opening + lessons + stalled + "\n\n" + SUMMARY_TEMPLATE


def _slice_chars(text: str, limit: int) -> str:
    return text.encode("utf-16-le", errors="surrogatepass")[:limit * 2].decode("utf-16-le", errors="replace")


def _summary_messages(batch: list[dict], archive=None, summary: str = "", *, model_ref: str | None = None,
                      review: str = "", stall: int = 0) -> list[dict]:
    # archive is retained for saved-request replay callers; no archive prose is
    # injected into the upstream summary prompt.
    presented = []
    for original in batch:
        if (original.get("compaction_through") and not original.get("error")
                and original.get("finish_reason")):
            continue
        if original.get("error") and not (original["error"] == "aborted"
                                          and (original.get("content") or original.get("tool_calls"))):
            continue
        message = deepcopy(original)
        if message.get("role") == "tool":
            if (message.get("metadata") or {}).get("compacted") is not None:
                message["content"] = "[Old tool result content cleared]"
                message.pop("attachments", None)
            body = message.get("content") or ""
            if _chars(body) > TOOL_OUTPUT_MAX_CHARS:
                omitted = _chars(body) - TOOL_OUTPUT_MAX_CHARS
                message["content"] = _slice_chars(body, TOOL_OUTPUT_MAX_CHARS) + (
                    f"\n[Tool output truncated for compaction: omitted {omitted} chars]"
                )
            message.pop("attachments", None)
        elif message.get("role") == "user":
            markers = [f"[Attached {a.get('mime', 'application/octet-stream')}: {a.get('filename') or 'file'}]"
                       for a in message.pop("attachments", None) or []]
            if markers:
                message["content"] = (message.get("content") or "") + "\n" + "\n".join(markers)
        presented.append(message)
    return [*openai_messages_from_history(presented, model_ref=model_ref),
            {"role": "user", "content": build_prompt(summary, review, stall)}]


def compact(app, session_id: str, history: list[dict], provider, model_id: str,
            *, system: str = "", tools=None, force: bool = False, reserved_tokens: int = 0,
            overflow: bool = False) -> None:
    config = settings(app)
    if not force and not usage_overflow(app, session_id, provider, model_id):
        return
    if not force and config.get("auto") is False:
        return
    if not history:
        return
    if app.abort_event(session_id).is_set():
        raise ProviderError("Compaction aborted; previous context retained")

    stored = app.store.messages(session_id)
    originals = {m["id"]: m for m in stored}
    # Ordinary tool presentation adds receipt headers. Summarize authoritative
    # tool bodies, otherwise those headers can consume the entire 2000-char cap.
    history = [originals.get(m.get("id"), m) for m in history]
    replay = None
    if overflow:
        users = [i for i, m in enumerate(history) if m.get("role") == "user" and not m.get("compaction_through")]
        if len(users) >= 2:
            replay = history[users[-1]]
            history = history[:users[-1]]
    previous = next((m for m in reversed(history) if m.get("compaction_through") and not m.get("error")
                     and m.get("finish_reason")), None)
    summary = (previous.get("content") or "") if previous else ""
    if summary.startswith("<previous-summary>\n") and summary.endswith("\n</previous-summary>"):
        summary = summary[len("<previous-summary>\n"):-len("\n</previous-summary>")]
    summary = summary.strip()
    summary_agent = app.agents.get("compaction")
    instructions = summary_agent.prompt if summary_agent else "Summarize the work so it can continue."
    target = summary_agent.model if summary_agent else None
    compact_provider, compact_model = app.provider.resolve(target) if target else (provider, model_id)
    groups = exchanges([m for m in history if not (m.get("compaction_through") and not m.get("error")
                       and m.get("finish_reason"))])
    recent_budget = config.get("preserve_recent_tokens", min(8000, max(2000, usable_budget(app, compact_provider, compact_model) // 4)))
    split = retained_split(groups, recent_budget, config.get("tail_turns", 2),
                           model_ref=f"{compact_provider.id}/{compact_model}")
    older = [m for group in groups[:split] for m in group]
    if not older and not summary:
        return

    archive = app.store.archive_messages(session_id, stored)
    from opencode.progress import stalled
    from opencode.task_skills import opening
    from opencode.deep import skills as installed_skills

    review, _ = opening(app.store, session_id, installed_skills(app))
    stall, _, _ = stalled(app, session_id)
    request = _summary_messages(older, archive, summary, model_ref=f"{compact_provider.id}/{compact_model}",
                                review=review, stall=stall)
    positions = {m["id"]: index for index, m in enumerate(stored)}
    covered = [m["id"] for m in older]
    if previous:
        covered.append(previous["compaction_through"])
    through = max(covered, key=positions.__getitem__)
    checkpoint = app.store.commit_compaction(session_id, through, "",
        replay_from=replay["id"] if replay else None,
        assistant={"agent": "compaction", "model": f"{compact_provider.id}/{compact_model}",
                   "tokens": {}, "finish_reason": None, "reasoning_content": None})

    def record_summary(partial):
        if partial.tool_calls:
            raise ProviderError(f"Tool call not allowed while generating summary: {partial.tool_calls[0].name}", partial)
        app.store.update_message(session_id, checkpoint["id"], content=partial.text,
                                 reasoning_content=partial.reasoning_content, tokens=partial.usage,
                                 finish_reason=partial.finish_reason)

    try:
        result = app.provider.complete(provider=compact_provider, model=compact_model,
                                       system=instructions, messages=request, tools=None,
                                       temperature=summary_agent.temperature if summary_agent else None,
                                       abort_event=app.abort_event(session_id), on_update=record_summary)
        record_summary(result)
    except ProviderError as error:
        partial = error.partial
        overflow_error = is_context_overflow(error)
        message = (("Conversation history too large to compact - exceeds model context limit" if replay else
                    "Session too large to compact - context exceeds model limit even after stripping media")
                   if overflow_error else str(error))
        app.store.update_message(session_id, checkpoint["id"], **{
            "content": partial.text if partial else "",
            "agent": "compaction", "model": f"{compact_provider.id}/{compact_model}",
            "tokens": partial.usage if partial else {},
            "finish_reason": "error" if overflow_error else (partial.finish_reason if partial else None),
            "reasoning_content": partial.reasoning_content if partial else None,
            "error": "aborted" if app.abort_event(session_id).is_set() else message,
        })
        if overflow_error:
            raise ProviderError(message, partial) from error
        raise
    if replay:
        replay_text = _summary_messages([replay])[0]["content"]
        continuation = {"role": "user", "content": replay_text, "synthetic": True}
        for name in ("agent", "model"):
            if name in replay:
                continuation[name] = replay[name]
    else:
        # Upstream assumes media caused an overflow it cannot replay; a long session of tool
        # results overflows with none (v41), and the agent was told about attachments it never had.
        media = any(m.get("attachments") for m in history)
        warning = ("" if not overflow else
                   "The previous request exceeded the provider's size limit due to large media attachments. "
                   "The conversation was compacted and media files were removed from context. If the user was asking "
                   "about attached images or files, explain that the attachments were too large to process and suggest "
                   "they try again with smaller or fewer files.\n\n" if media else
                   "The previous request exceeded the provider's size limit, so the conversation was compacted.\n\n")
        unattended = getattr(getattr(app, "permissions", None), "auto", False)
        prompt = UNATTENDED_CONTINUE_PROMPT if unattended else CONTINUE_PROMPT
        continuation = {"role": "user", "content": warning + prompt, "synthetic": True}
    if app.abort_event(session_id).is_set():
        app.store.update_message(session_id, checkpoint["id"], content=result.text,
                                 reasoning_content=result.reasoning_content, tokens=result.usage,
                                 finish_reason=result.finish_reason, error="aborted")
        raise ProviderError("Compaction aborted; previous context retained")
    app.store.add_message(session_id, "user", continuation)
    app.bus.publish("session.compacted", {"sessionID": session_id})


def is_context_overflow(error: ProviderError) -> bool:
    # Provider transport diagnostics only; this never classifies task semantics.
    text = str(error).lower()
    return bool(re.match(r"^(?:[\w.-]+\s+)?413:", text)) or any(marker in text for marker in (
        "context_length_exceeded", "maximum context length", "context window exceeded",
        "prompt is too long", "input is too long", "request_too_large", "provider http 413",
    ))


def prune(app, session_id: str) -> None:
    """Mark sufficiently old completed tool outputs without changing saved text."""
    if not (app.config.get("compaction") or {}).get("prune"):
        return
    total = 0
    pruned = 0
    candidates = []
    turns = 0
    for message in reversed(app.store.messages(session_id)):
        if message.get("role") == "user":
            turns += 1
        if turns < 2:
            if message.get("role") == "assistant" and message.get("compaction_through"):
                # The Python checkpoint represents V1's summary plus its
                # preceding compaction-user marker, which counts as a turn.
                turns += 1
            continue
        if message.get("role") == "assistant" and message.get("compaction_through"):
            break
        if message.get("role") != "tool":
            continue
        metadata = message.get("metadata") or {}
        if metadata.get("error") or message.get("name") == "skill":
            continue
        if metadata.get("compacted") is not None:
            break
        size = estimate_tokens(message.get("content") or "")
        total += size
        if total <= 40_000:
            continue
        pruned += size
        candidates.append(message["id"])
    if pruned > 20_000:
        import time
        app.store.mark_tools_compacted(session_id, candidates, int(time.time() * 1000))
