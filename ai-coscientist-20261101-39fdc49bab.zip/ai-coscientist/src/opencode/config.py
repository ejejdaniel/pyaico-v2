"""Load and merge opencode.json / opencode.jsonc the same way the TypeScript config service does."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

import yaml

from opencode.hidden import validate as validate_hidden
from opencode.jsonc import loads
from opencode.paths import config_dir, home


def _truthy(name: str) -> bool:
    return os.environ.get(name, "").lower() in {"true", "1"}


def _substitute(text: str, directory: Path) -> str:
    text = re.sub(r"\{env:([^}]+)\}", lambda match: os.environ.get(match[1], ""), text)

    def file_value(match):
        prefix = text[text.rfind("\n", 0, match.start()) + 1:match.start()].lstrip()
        if prefix.startswith("//"):
            return match[0]
        path = Path(match[1]).expanduser()
        if not path.is_absolute():
            path = directory / path
        value = path.read_text(encoding="utf-8").strip()
        return json.dumps(value, ensure_ascii=False)[1:-1]

    return re.sub(r"\{file:([^}]+)\}", file_value, text)


def _is_dict(value) -> bool:
    return isinstance(value, dict)


def validate_config(config: dict) -> None:
    """Validate approved configuration fields before runtime consumers use them."""
    if "hidden" in config:
        validate_hidden(config["hidden"])
    if "protected" in config:  # paths the agent's own file tools may not write (opencode/integrity.py)
        protected = config["protected"]
        if not isinstance(protected, list) or not all(isinstance(item, str) and item.strip() for item in protected):
            raise ValueError("protected must be a list of path patterns")
    if "deep" in config:  # what deep research adds while a task has it on (opencode/deep.py)
        deep = config["deep"]
        if not isinstance(deep, dict):
            raise ValueError("deep must be an object")
        for key in ("instructions", "skills", "tool_modules"):
            if key in deep and (not isinstance(deep[key], list)
                                or not all(isinstance(item, str) and item.strip() for item in deep[key])):
                raise ValueError(f"deep.{key} must be a list of names")
    if "turn" in config:  # the call budget of a supervised general-mode turn (opencode/loop.py _turn_budget)
        turn = config["turn"]
        if not isinstance(turn, dict):
            raise ValueError("turn must be an object")
        if "max_calls" in turn and (type(turn["max_calls"]) is not int or turn["max_calls"] < 2):
            raise ValueError("turn.max_calls must be an integer of at least 2")
        if "remind_before" in turn and (type(turn["remind_before"]) is not int or turn["remind_before"] < 0):
            raise ValueError("turn.remind_before must be a whole number")
    if "progress" in config:  # when the work counts as stalled, and when it is paused (opencode/progress.py)
        progress = config["progress"]
        if not isinstance(progress, dict):
            raise ValueError("progress must be an object")
        for key in ("stall_after", "pause_after"):
            if key in progress and (type(progress[key]) is not int or progress[key] < 1):
                raise ValueError(f"progress.{key} must be a positive integer")
    if "compaction" in config:
        compaction = config["compaction"]
        if not isinstance(compaction, dict):
            raise ValueError("compaction must be an object")
        for key in ("tail_turns", "preserve_recent_tokens", "reserved"):
            if key in compaction and (type(compaction[key]) is not int or compaction[key] < 0):
                raise ValueError(f"compaction.{key} must be a nonnegative integer")
        if "prune" in compaction and type(compaction["prune"]) is not bool:
            raise ValueError("compaction.prune must be a boolean")
    providers = config.get("provider")
    for provider_name, provider in (providers.items() if isinstance(providers, dict) else []):
        models = provider.get("models") if isinstance(provider, dict) else None
        for model_name, model in (models.items() if isinstance(models, dict) else []):
            if isinstance(model, dict) and "temperature" in model and type(model["temperature"]) is not bool:
                raise ValueError(f"provider.{provider_name}.models.{model_name}.temperature must be a boolean")
            if isinstance(model, dict) and "modalities" in model:
                validate_modalities(model["modalities"], f"provider.{provider_name}.models.{model_name}.modalities")
            limits = model.get("limit") if isinstance(model, dict) else None
            if isinstance(limits, dict) and "input" in limits:
                value = limits["input"]
                # The approved Python contract is narrower than V1's Schema.Finite.
                if type(value) is not int or value < 0:
                    raise ValueError(f"provider.{provider_name}.models.{model_name}.limit.input must be a nonnegative integer")
    if "lsp" in config:
        lsp = config["lsp"]
        if type(lsp) is not bool and not isinstance(lsp, dict):
            raise ValueError("lsp must be a boolean or an object")
        for name, server in (lsp.items() if isinstance(lsp, dict) else []):
            if not isinstance(server, dict):
                raise ValueError(f"lsp.{name} must be an object")
            if "disabled" in server and type(server["disabled"]) is not bool:
                raise ValueError(f"lsp.{name}.disabled must be a boolean")
            # The source's Disabled branch ignores other fields on disabled entries.
            if server.get("disabled") is True:
                continue
            if "env" in server:
                env = server["env"]
                if not isinstance(env, dict) or any(not isinstance(key, str) or not isinstance(value, str) for key, value in env.items()):
                    raise ValueError(f"lsp.{name}.env must be an object mapping strings to strings")
            if "initialization" in server:
                initialization = server["initialization"]
                if not isinstance(initialization, dict) or any(not isinstance(key, str) for key in initialization):
                    raise ValueError(f"lsp.{name}.initialization must be an object with string keys")
    if "tool_output" in config:
        output = config["tool_output"]
        if not isinstance(output, dict):
            raise ValueError("tool_output must be an object")
        for key in ("max_lines", "max_bytes"):
            if key in output and (type(output[key]) is not int or output[key] <= 0):
                raise ValueError(f"tool_output.{key} must be a positive integer")
    if "experimental" in config:
        experimental = config["experimental"]
        if not isinstance(experimental, dict):
            raise ValueError("experimental must be an object")
        if "continue_loop_on_deny" in experimental and type(experimental["continue_loop_on_deny"]) is not bool:
            raise ValueError("experimental.continue_loop_on_deny must be a boolean")


def validate_modalities(value, path: str = "Model modalities") -> None:
    """The upstream config permits either direction to be omitted independently."""
    if not isinstance(value, dict):
        raise ValueError(f"{path} must be an object")
    for direction in ("input", "output"):
        if direction not in value:
            continue
        items = value[direction]
        if not isinstance(items, list) or any(
                not isinstance(item, str) or item not in {"text", "audio", "image", "video", "pdf"}
                for item in items):
            raise ValueError(f"{path}.{direction} must be an array of text, audio, image, video, or pdf")


def merge_config(base: dict, incoming: dict) -> dict:
    result = dict(base)
    for key, value in incoming.items():
        if key == "instructions" and isinstance(result.get(key), list) and isinstance(value, list):
            seen = list(result[key])
            for item in value:
                if item not in seen:
                    seen.append(item)
            result[key] = seen
            continue
        if _is_dict(result.get(key)) and _is_dict(value):
            result[key] = merge_config(result[key], value)
            continue
        result[key] = value
    return result


def _read_file(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    if not text.strip():
        return {}
    data = loads(_substitute(text, path.parent))
    if not isinstance(data, dict):
        return {}
    for legacy in ("theme", "keybinds", "tui"):
        data.pop(legacy, None)
    validate_config(data)
    return data


def _find_up(filename: str, start: Path, stop: Path) -> list[Path]:
    found: list[Path] = []
    current = start.resolve()
    stop = stop.resolve()
    while True:
        candidate = current / filename
        if candidate.is_file():
            found.append(candidate)
        if current == stop or current.parent == current:
            break
        if stop == current or stop in current.parents:
            parent = current.parent
            if parent == current:
                break
            # walk toward filesystem root, but stop once we leave the worktree
            if stop not in parent.parents and parent != stop:
                break
            current = parent
            continue
        break
    return found


def worktree_of(directory: Path) -> Path:
    current = directory.resolve()
    stop = current
    while True:
        if (current / ".git").exists():
            return current
        if current.parent == current:
            return stop
        current = current.parent


def directories(directory: Path, worktree: Path) -> list[Path]:
    """Global, nearest-first project .opencode folders, home, then explicit override."""
    directory = directory.resolve()
    worktree = worktree.resolve()
    chain: list[Path] = []
    current = directory
    while True:
        chain.append(current)
        if current == worktree or current.parent == current:
            break
        current = current.parent
    extra = [config_dir()]
    if not _truthy("OPENCODE_DISABLE_PROJECT_CONFIG"):
        extra.extend(item / ".opencode" for item in chain if (item / ".opencode").is_dir())
    if (home() / ".opencode").is_dir():
        extra.append(home() / ".opencode")
    config_override = os.environ.get("OPENCODE_CONFIG_DIR")
    if config_override:
        extra.append(Path(config_override))
    return list(dict.fromkeys(item.resolve() for item in extra))


def load_config(directory: Path | None = None) -> dict:
    directory = (directory or Path.cwd()).resolve()
    worktree = worktree_of(directory)
    result: dict = {}

    global_dir = config_dir()
    for name in ("config.json", "opencode.json", "opencode.jsonc"):
        result = merge_config(result, _read_file(global_dir / name))

    custom = os.environ.get("OPENCODE_CONFIG")
    if custom:
        result = merge_config(result, _read_file(Path(custom)))

    if not _truthy("OPENCODE_DISABLE_PROJECT_CONFIG"):
        for file in _project_files(directory, worktree):
            result = merge_config(result, _read_file(file))
    override = os.environ.get("OPENCODE_CONFIG_DIR")
    for folder in directories(directory, worktree):
        if folder.name == ".opencode" or (override and folder == Path(override).resolve()):
            for name in ("opencode.json", "opencode.jsonc"):
                result = merge_config(result, _read_file(folder / name))
        result = merge_config(result, _load_markdown_agents(folder))
        result = merge_config(result, _load_markdown_commands(folder))

    content = os.environ.get("OPENCODE_CONFIG_CONTENT")
    if content:
        parsed = loads(_substitute(content, directory))
        if isinstance(parsed, dict):
            validate_config(parsed)
            result = merge_config(result, parsed)

    permission_env = os.environ.get("OPENCODE_PERMISSION")
    if permission_env:
        try:
            extra = json.loads(permission_env)
        except json.JSONDecodeError:
            extra = None
        if isinstance(extra, dict):
            result["permission"] = merge_config(result.get("permission") or {}, extra)

    # Deprecated `mode` entries become primary agents.
    modes = result.get("mode") or {}
    if isinstance(modes, dict):
        agents = dict(result.get("agent") or {})
        for name, mode in modes.items():
            if isinstance(mode, dict):
                agents[name] = merge_config(agents.get(name) or {}, {**mode, "mode": "primary"})
        result["agent"] = agents

    result.setdefault("agent", {})
    result.setdefault("plugin", [])
    validate_config(result)
    return result


def _project_files(directory: Path, worktree: Path) -> list[Path]:
    found: list[Path] = []
    current = directory.resolve()
    while True:
        found.extend(current / name for name in ("opencode.jsonc", "opencode.json") if (current / name).is_file())
        if current == worktree.resolve() or current.parent == current:
            break
        current = current.parent
    # Reverse directory and within-directory order: JSON then JSONC, root first.
    found.reverse()
    unique: list[Path] = []
    seen: set[Path] = set()
    for path in found:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(resolved)
    return unique


def _frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    end = None
    for index, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = index
            break
    if end is None:
        return {}, text
    source = "\n".join(lines[1:end])
    try:
        meta = yaml.safe_load(source) or {}
    except yaml.YAMLError:
        sanitized = []
        for line in lines[1:end]:
            match = re.match(r"^([a-zA-Z_][a-zA-Z0-9_]*)\s*:\s*(.*)$", line)
            if match and ":" in match[2] and not match[2].startswith(('"', "'")):
                sanitized.extend([f"{match[1]}: |-", "  " + match[2]])
            else:
                sanitized.append(line)
        meta = yaml.safe_load("\n".join(sanitized)) or {}
    if not isinstance(meta, dict):
        raise ValueError("YAML frontmatter must be an object")
    body = "\n".join(lines[end + 1 :]).strip()
    return meta, body


def _load_markdown_agents(folder: Path) -> dict:
    agents: dict = {}
    for sub in ("agent", "agents"):
        root = folder / sub
        if not root.is_dir():
            continue
        for path in root.rglob("*.md"):
            try:
                meta, body = _frontmatter(path.read_text(encoding="utf-8"))
            except (OSError, yaml.YAMLError, ValueError):
                continue
            name = str(meta.get("name") or path.relative_to(root).with_suffix("").as_posix())
            entry = {**meta, "prompt": body}
            entry.pop("name", None)
            agents[name] = entry
    if not agents:
        return {}
    return {"agent": agents}


def _load_markdown_commands(folder: Path) -> dict:
    commands: dict = {}
    for sub in ("command", "commands"):
        root = folder / sub
        if not root.is_dir():
            continue
        for path in root.rglob("*.md"):
            try:
                meta, body = _frontmatter(path.read_text(encoding="utf-8"))
            except (OSError, yaml.YAMLError, ValueError):
                continue
            name = str(meta.get("name") or path.relative_to(root).with_suffix("").as_posix())
            commands[name] = {**meta, "template": body}
            commands[name].pop("name", None)
    if not commands:
        return {}
    return {"command": commands}
