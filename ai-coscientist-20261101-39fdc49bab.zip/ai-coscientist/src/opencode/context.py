"""Current working state beside the committed summary and uncovered history."""

from __future__ import annotations

import json

from opencode.store import latest_human_message
from opencode.tools.util import truncate

def working_context(history: list[dict], store, session_id: str) -> list[dict]:
    """Do not select history again after Store.context_messages has applied its checkpoint.

    The caller budgets this complete presentation with the normal compactor.
    These projections do not change saved messages or todo status.
    """
    shown = [_attribute_account(m, store, session_id) if m.get("answer_review_role") else m for m in history]
    return [*_answer_review_context(history, store, session_id), *shown]


def _attribute_account(message, store, session_id):
    if (message.get("role") != "assistant" or not (message.get("content") or "").strip()
            or message.get("synthetic") or message.get("compaction_through")):
        return message
    origin = "Incomplete assistant output" if message.get("error") else "Prior assistant account"
    role = message.get("answer_review_role")
    if role == "draft":
        origin = "Undelivered assistant draft"
    elif role == "answer":
        origin = "Previously delivered assistant answer"
    identifier = message.get("id", "unknown")
    copy = _saved_message_copy(store, session_id, identifier)
    location = f"; saved original: {copy}" if copy else ""
    return dict(message, content=(
        f"[{origin}; message {identifier}{location}; not independent evidence or host verification]\n"
        + message["content"]
    ))


def _answer_review_context(history, store, session_id):
    human = latest_human_message(store.messages(session_id))
    state = store.answer_review(session_id, human["id"]) if human else None
    if not state or state["phase"] != "checking":
        return []
    shown = {m.get("id") for m in history}
    original = {m["id"]: m for m in store.messages(session_id)}
    result = []
    for field in ("draft_message_id", "notice_message_id"):
        identifier = state[field]
        if identifier in shown:
            continue
        message = original.get(identifier)
        if message is None:
            raise ValueError("Active answer review lost a saved message; no answer delivered")
        copy = _saved_message_copy(store, session_id, identifier)
        body = truncate(message.get("content") or "", max_bytes=8192, max_lines=200,
                        label="active-answer-review", saved_path=copy)
        result.append(dict(message, content=(
            f"[Active answer review; original message {identifier}; full saved text: {copy}]\n" + body)))
    return result


def _saved_message_copy(store, session_id: str, message_id: str):
    path = store._receipt_index_path(session_id, "history", "conversation").parent / f"{message_id}.json"
    return path if path.is_file() else None
