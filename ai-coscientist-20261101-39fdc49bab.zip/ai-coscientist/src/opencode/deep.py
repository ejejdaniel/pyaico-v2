"""Deep research: capabilities a task has only while it is turned on (the interface's /deep, the entry's --deep).

The host application installs them in config["deep"]: instruction files, skill folders and tool modules (their
tools and their turn extension), apart from the general agent's own. A task, its top session, has them while
its meta["deep"] is true; a subagent follows its task. It is off by default: a task gets the general agent and
its guards, and with deep research on, also the research guidance and tools, the verification plan and the
reviews (opencode/verification.py, opencode/round_review.py).

The project lead's decision (2026-10-31). Two investigation questions run with the research machinery always
attached went through records, reviews, rendered reports and formal deliveries: 214 model calls in 76
minutes. Guidance asking for proportion held for one of them; for the other, the research reviewer pulled the
work back to the research standard.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib
from pathlib import Path

# Said in the system prompt when deep research is installed but off for the task.
HINT = ("Deep research is off for this task: the research guidance, research tools, verification plan and "
        "reviews are not loaded. If the request is a study that needs them (a mechanism, a design, a "
        "prediction, a scored or reviewed report), say that the person can turn deep research on (/deep in the "
        "interface, --deep for an unattended run), and meanwhile do what the general tools allow.")


# Where a folder keeps its copies of deep research's skills; opencode/integrity.py hashes them with the meta region.
COPIES = ".opencode/deep"


def install_copies(workspace, sources: dict) -> dict:
    """Copy each skill folder into the workspace and return {name: its copy}.

    The skill list and the skill tool show where a skill is. Pointing into the framework's source, they led an
    agent (2026-11-01) to read the framework's code and to import its modules; a copy keeps the same guidance at
    a path in the task's own folder. Only files that differ are written, and files gone from the source are
    removed, so installing again changes nothing that is already current.
    """
    copies = {}
    for name, source in sources.items():
        source, target = Path(source), Path(workspace) / COPIES / name
        wanted = {path.relative_to(source): path for path in sorted(source.rglob("*"))
                  if path.is_file() and "__pycache__" not in path.parts}
        for relative, path in wanted.items():
            destination, data = target / relative, path.read_bytes()
            if not destination.is_file() or destination.read_bytes() != data:
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
        for path in sorted(target.rglob("*"), reverse=True) if target.is_dir() else []:
            if path.is_file() and path.relative_to(target) not in wanted:
                path.unlink()
            elif path.is_dir() and not any(path.iterdir()):
                path.rmdir()
        copies[name] = target
    return copies


@dataclass
class Deep:
    """What deep research adds: instruction documents (path, text), skills by name, tools, a turn extension."""

    instructions: list = field(default_factory=list)
    skills: dict = field(default_factory=dict)
    tools: list = field(default_factory=list)
    extension: object = None

    def __bool__(self) -> bool:
        return bool(self.instructions or self.skills or self.tools or self.extension)


def load(directory: Path, worktree: Path, config: dict) -> Deep:
    """Deep research as config["deep"] installs it: {"instructions": [...], "skills": [...], "tool_modules": [...]}."""
    from opencode.instructions import _expand_glob, _read
    from opencode.skills import _scan
    from opencode.tools.types import Tool

    spec = config.get("deep") or {}
    instructions = []
    for raw in spec.get("instructions") or []:
        for match in _expand_glob(raw, directory, worktree):
            text = _read(match)
            if text.strip():
                instructions.append((str(match), text))
    skills: dict = {}
    for raw in spec.get("skills") or []:
        path = Path(raw)
        _scan(path if path.is_absolute() else directory / path, skills)
    tools, extension = [], None
    for name in spec.get("tool_modules") or []:
        try:
            module = importlib.import_module(name)
        except Exception as exc:
            raise RuntimeError(f"Cannot load the deep research tool module {name}: {exc}") from exc
        candidate = getattr(module, "TURN_EXTENSION", None)
        if candidate is not None:
            if not callable(candidate):
                raise RuntimeError(f"TURN_EXTENSION must be callable: {name}")
            if extension is not None and candidate is not extension:
                raise RuntimeError(f"Multiple TURN_EXTENSION exports; refusing to select one: {name}")
            extension = candidate
        for item in getattr(module, "TOOLS", None) or []:
            if isinstance(item, Tool) and not any(item is known for known in tools):
                tools.append(item)
    return Deep(list(dict(instructions).items()), skills, tools, extension)


def skills(app) -> dict:
    """Every skill the installation provides, the general agent's and deep research's (whose copies come
    first): for a tool that reads an installed skill's files, which runs only while deep research is on, and for
    the skill charter's framework names. LIT through the switch (2026-10-31) looked only in app.skills, and the
    mind-map tool failed for want of mindmap-builder."""
    installed = getattr(app, "deep", None)
    return {**(getattr(app, "skills", None) or {}), **(installed.skills if installed else {})}


def tools(app) -> list:
    """The folder's own tools, then deep research's that the folder does not give: every tool a task can have.

    A check for a tool, or a list of the tools that bring in outside sources, needs both. From the switch
    (2026-10-31) until 2026-11-01 the research turn looked only in the folder's own tools, found no research
    tools, and sent none of its host facts: no board, no delivery checks, no skill text after compaction, no
    report rules once the rounds had stopped."""
    own = list(getattr(app, "extra_tools", None) or [])
    names = {tool.name for tool in own}
    installed = getattr(app, "deep", None)
    return [*own, *(tool for tool in (getattr(installed, "tools", None) or []) if tool.name not in names)]


def is_on(app, session_id: str | None) -> bool:
    """Whether deep research is on for the task this session works for."""
    if not session_id:
        return False
    from opencode.task_skills import root_session

    try:
        return bool((app.store.get_session(root_session(app.store, session_id)).get("meta") or {}).get("deep"))
    except Exception:  # a session the store does not hold
        return False


def set_on(store, session_id: str, on: bool) -> None:
    """Turn deep research on or off for a task, from its next message."""
    meta = dict(store.get_session(session_id).get("meta") or {})
    meta["deep"] = bool(on)
    store.update_session(session_id, meta=meta)
