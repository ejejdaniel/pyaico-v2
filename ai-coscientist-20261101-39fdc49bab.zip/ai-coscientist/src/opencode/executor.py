"""One entry point for starting processes (stage 1 of docs/design_executor_20261026_zh-TW.md).

Every place that starts a program says what the program is for (its purpose) and
asks this module to start it. Stage 1 has only the local backend: the process is
started exactly as before (`subprocess.Popen` / `subprocess.run`, looked up when
called), and each launch is written to an audit log. Later stages decide here,
from the purpose and the policy, whether to run the program in a sandbox
(bubblewrap) and in which environment (pixi).

The audit records every start. A synchronous `run` also records its exit; a
started process reports its exit code in its own tool result (shell metadata,
simulation result.json, solver result), so it is not duplicated here.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import threading
import time
import uuid

PURPOSES = {
    "agent_command": "A command the model wrote (shell tool)",
    "agent_code": "Code the model wrote, run by a framework tool (calc properties, optimizer benchmark)",
    "agent_search": "A read-only search the model asked for (grep, glob)",
    "framework_compute": "Framework-written computation (simulation routes, solvers)",
    "framework_helper": "Framework utility programs (path conversion, PDF printing)",
    "server": "A long-running server the user configured (LSP, MCP)",
}
AUDIT_FILE = ".opencode/executions.jsonl"
_ARGS_LIMIT = 400

_scope: ContextVar[dict | None] = ContextVar("opencode_executor_scope", default=None)
_write_lock = threading.Lock()


@dataclass(frozen=True)
class Launch:
    """What a process is for. The backend and sandbox are decided from this, not by the caller."""

    purpose: str
    note: str = ""
    environment: str = "default"

    def __post_init__(self):
        if self.purpose not in PURPOSES:
            raise ValueError(f"unknown launch purpose {self.purpose!r}; one of {', '.join(PURPOSES)}")


@contextmanager
def scope(directory, session_id=None, tool=None, call_id=None):
    """Attribute launches inside a tool call to that call, and audit them in its workspace."""
    token = _scope.set({"directory": Path(directory), "session": session_id, "tool": tool, "call": call_id})
    try:
        yield
    finally:
        _scope.reset(token)


def _summary(args) -> str:
    text = args if isinstance(args, str) else " ".join(str(part) for part in args)
    return text if len(text) <= _ARGS_LIMIT else text[:_ARGS_LIMIT] + "…"


def _audit(launch, args, cwd, **fields):
    context = _scope.get()
    if context is None:
        return  # outside a tool call there is no workspace to attribute the launch to
    entry = {
        "time": datetime.now(timezone.utc).isoformat(timespec="seconds"), "purpose": launch.purpose,
        "note": launch.note, "tool": context["tool"], "session": context["session"], "call": context["call"],
        "backend": "local", "sandboxed": False, "environment": launch.environment, "network": "host",
        "cwd": str(cwd or ""), "args": _summary(args), **fields,
    }
    try:
        path = context["directory"] / AUDIT_FILE
        line = json.dumps(entry, ensure_ascii=False, default=str) + "\n"
        with _write_lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as stream:
                stream.write(line)
    except OSError:
        pass  # auditing must never stop the work it describes


def spawn(args, launch: Launch, **kwargs):
    """Start a process for this purpose and return its Popen. Stage 1: local, unchanged."""
    process = subprocess.Popen(args, **kwargs)
    _audit(launch, args, kwargs.get("cwd"), event="start", id=uuid.uuid4().hex[:12],
           pid=getattr(process, "pid", None))
    return process


def run(args, launch: Launch, **kwargs):
    """Run a process to completion for this purpose; the same arguments and result as subprocess.run."""
    started = time.monotonic()
    try:
        result = subprocess.run(args, **kwargs)
    except subprocess.TimeoutExpired:
        _audit(launch, args, kwargs.get("cwd"), event="run", returncode=None, outcome="timeout",
               elapsed_s=round(time.monotonic() - started, 3))
        raise
    _audit(launch, args, kwargs.get("cwd"), event="run", returncode=getattr(result, "returncode", None),
           elapsed_s=round(time.monotonic() - started, 3))
    return result
