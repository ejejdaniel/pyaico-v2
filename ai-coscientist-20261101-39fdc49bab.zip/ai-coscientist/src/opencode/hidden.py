"""Host files kept out of the agent's sight.

A host that runs the agent, such as a test runner, keeps its own records near the agent's
workspace: model requests and responses, settings, the session database and other runs. It lists
them in config["hidden"]:

    {"roots": [folder, ...],     # folders whose entries are hidden; the folder itself is not
     "visible": [path, ...],     # paths inside a root that stay visible, with the folders leading to them
     "names": [regex, ...]}      # entry names distinct enough that any output line naming them is dropped

The file tools then treat a hidden path as missing, a shell command that names one is answered as
a missing file without running, and shell output lines that name one are dropped. A path the file
tools are given is judged by where it points; a path word in command or output text counts only
when it names something that exists, since text is full of words that merely look like paths. This
is bookkeeping in the tools, not a sandbox: a program that builds a hidden path while it runs and
prints what it reads is not caught.
"""

from __future__ import annotations

import glob
import json
import os
import re
from functools import lru_cache
from itertools import islice
from pathlib import Path

KEYS = ("roots", "visible", "names")
# A shell word: double-quoted, single-quoted, or a run of characters that are not shell syntax.
_WORD = re.compile(r'"([^"]*)"|\'([^\']*)\'|([^\s\'"`;|&<>(){}]+)')
_CWD = {"cd", "chdir", "pushd", "push-location", "set-location", "sl"}
_WILDCARD = re.compile(r"[*?\[]")
_MSYS_DRIVE = re.compile(r"^/(?:cygdrive/|mnt/)?([A-Za-z])(?=/|$)")
_SEPARATOR = re.compile(r"[\\/]")
_GLOB_LIMIT = 5000
# A name with no regular-expression syntax other than escaped characters.
_LITERAL = re.compile(r"(?:\\.|[^.^$*+?{}\[\]\\|()])+")
_NAME_WORD = re.compile(r"[\w.-]+")


def _fold(text: str) -> str:
    return text.casefold() if os.name == "nt" else text


def _absolute(text: str, cwd: str) -> str | None:
    """A normalized absolute spelling of a path word, or None when it cannot name a file here."""
    if not text or text.startswith("~") or "\0" in text:
        return None
    if os.name == "nt":
        text = _MSYS_DRIVE.sub(lambda match: match.group(1) + ":", text)
        if re.fullmatch(r"[A-Za-z]:", text):
            text += "/"
    try:
        path = text if os.path.isabs(text) else os.path.join(cwd, text)
        return os.path.normcase(os.path.normpath(path))
    except (TypeError, ValueError):
        return None


def _inside(folder: str, path: str) -> bool:
    return path == folder or path.startswith(folder.rstrip("\\/") + os.sep)


def _words(text: str, nested: bool = False):
    for match in _WORD.finditer(text):
        quoted = match.group(1) if match.group(1) is not None else match.group(2)
        if quoted is None:
            yield match.group(3)
            continue
        yield quoted
        if not nested:
            # Code inside quotes (python -c "...") names paths in its own quoted strings.
            yield from _words(quoted, nested=True)


def _candidates(word: str):
    yield word
    if "=" in word:
        yield word.rsplit("=", 1)[1]


def _spellings(word: str):
    """A path word as written, without trailing punctuation, and before a "path:line:" colon (grep -n)."""
    yield word
    trimmed = word.rstrip(".,;:)]}>")
    if trimmed and trimmed != word:
        yield trimmed
    colon = word.find(":", 2 if re.match(r"[A-Za-z]:", word) else 1)
    if colon > 0:
        yield word[:colon]


class Hidden:
    def __init__(self, roots=(), visible=(), names=()):
        here = os.getcwd()
        self.roots = [key for key in (_absolute(str(path), here) for path in roots) if key]
        self.visible = [key for key in (_absolute(str(path), here) for path in visible) if key]
        # Plain names (most of them: other runs' folders) are looked up as whole words; the rest are
        # patterns. Searching hundreds of alternatives on every output line would be slow.
        literal = [name for name in names if _LITERAL.fullmatch(name)]
        self.literals = {_fold(re.sub(r"\\(.)", r"\1", name)) for name in literal}
        patterns = [name for name in names if name not in literal]
        flags = re.IGNORECASE if os.name == "nt" else 0
        self.patterns = (re.compile(r"(?<![\w.-])(?:" + "|".join(f"(?:{name})" for name in patterns) + r")(?![\w-])",
                                    flags) if patterns else None)

    def name_in(self, text: str) -> str | None:
        """The first hidden name the text mentions, or None."""
        if self.literals:
            for word in _NAME_WORD.findall(text):
                if _fold(word) in self.literals or _fold(word.rsplit(".", 1)[0]) in self.literals:
                    return word
        found = self.patterns.search(text) if self.patterns is not None else None
        return found.group(0) if found else None

    def hides(self, path, cwd=None) -> bool:
        key = _absolute(str(path), str(cwd) if cwd is not None else os.getcwd())
        return key is not None and self._hidden(key)

    def _hidden(self, key: str) -> bool:
        if not any(key != root and _inside(root, key) for root in self.roots):
            return False
        # A visible path stays visible, and so does every folder on the way to it.
        return not any(_inside(item, key) or _inside(key, item) for item in self.visible)

    def _present(self, word: str, base: str, hidden: bool = True) -> bool:
        """Whether a path word read from text names an existing hidden (or, with hidden=False, visible) path.

        Text is full of words that only look like paths here, such as a document's relative links
        ("../references/x.md"), so a word counts only when it names something that exists.
        """
        for spelling in _spellings(word):
            key = _absolute(spelling, base)
            if key is not None and self._hidden(key) == hidden and os.path.lexists(key):
                return True
        return False

    def _named(self, candidate: str, base: str) -> bool:
        match = _WILDCARD.search(candidate)
        if match is None:
            return self._present(candidate, base)
        pattern = _absolute(candidate, base)
        if pattern is None:
            return False
        prefix = candidate[:match.start()]
        # The folder the wildcard lists: the prefix itself when it ends at a separator ("../*.json"),
        # else the folder holding the partial name ("../req*").
        folder = (_absolute(prefix or ".", base) if not prefix or prefix[-1] in "\\/"
                  else os.path.dirname(_absolute(prefix, base) or "")) or ""
        if not any(_inside(root, folder) for root in self.roots) or any(_inside(item, folder) for item in self.visible):
            return False
        return any(self._hidden(_absolute(item, base) or "")
                   for item in islice(glob.iglob(pattern), _GLOB_LIMIT))

    def command(self, command: str, cwd) -> str | None:
        """The first hidden path or name a shell command mentions, or None."""
        if found := self.name_in(command):
            return found
        base, after_cd = str(cwd), False
        for word in _words(command):
            for candidate in _candidates(word):
                if self._named(candidate, base):
                    return candidate
            if after_cd:
                base = _absolute(word, base) or base
            after_cd = word.lower() in _CWD
        return None

    def _bases(self, command: str, cwd: str) -> list[str]:
        bases, base, after_cd = [cwd], cwd, False
        for word in _words(command or ""):
            if after_cd and (target := _absolute(word, base)):
                base = target
                bases.append(base)
            after_cd = word.lower() in _CWD
        return bases

    def _listed(self, command: str, bases: list[str]) -> list[str]:
        """Folders the command may list whose entries include hidden ones.

        A listing (ls, dir, Get-ChildItem) prints bare entry names, read from the listed folder:
        the folder the command ran in or moved to, or a folder word it names, such as "..".
        """
        folders = [key for key in (_absolute(".", base) for base in bases) if key]
        for word in _words(command or ""):
            for base in bases:
                key = _absolute(word, base)
                if key is not None and os.path.isdir(key):
                    folders.append(key)
        return [folder for folder in dict.fromkeys(folders)
                if any(_inside(root, folder) for root in self.roots) and not self._hidden(folder)]

    def _entry_hidden(self, line: str, listed: list[str]) -> bool:
        """Whether a listing line names a hidden entry of a listed folder by its last word (ls -l, dir)."""
        words = line.split()
        name = words[-1].rstrip("/*@=|") if words else ""
        if not name or name in (".", "..") or _SEPARATOR.search(name):
            return False
        return (any(self._present(name, folder) for folder in listed)
                and not any(self._present(name, folder, hidden=False) for folder in listed))

    def _line_hidden(self, line: str, bases: list[str], listed: list[str] = ()) -> bool:
        if self.name_in(line) or (listed and self._entry_hidden(line, listed)):
            return True
        for word in _words(line):
            for candidate in _candidates(word):
                # Only words with a folder separator: a bare word ("state") is too often just a word.
                if not _SEPARATOR.search(candidate) or _WILDCARD.search(candidate):
                    continue
                # A relative path is read from the folder the command ran in or any folder it moved
                # to; it is hidden when it exists hidden from one and visible from none.
                if (any(self._present(candidate, base) for base in bases)
                        and not (len(bases) > 1 and any(self._present(candidate, base, hidden=False) for base in bases))):
                    return True
        return False

    def clean(self, text: str, cwd, command: str = "") -> str:
        """The text without the lines that name a hidden path."""
        if not text:
            return text
        bases = self._bases(command, str(cwd))
        listed = self._listed(command, bases)
        return "\n".join(line for line in text.split("\n") if not self._line_hidden(line, bases, listed))


def validate(spec) -> None:
    if not isinstance(spec, dict) or set(spec) - set(KEYS):
        raise ValueError("hidden must be an object with roots, visible and names")
    for key in KEYS:
        items = spec.get(key, [])
        if not isinstance(items, list) or any(not isinstance(item, str) or not item.strip() for item in items):
            raise ValueError(f"hidden.{key} must be a list of nonempty strings")
    for key in ("roots", "visible"):
        if any(not os.path.isabs(item) for item in spec.get(key, [])):
            raise ValueError(f"hidden.{key} must list absolute paths")
    for name in spec.get("names", []):
        try:
            re.compile(name)
        except re.error as error:
            raise ValueError(f"hidden.names has an invalid pattern {name!r}: {error}") from None


@lru_cache(maxsize=8)
def _parsed(text: str) -> Hidden:
    spec = json.loads(text)
    return Hidden(spec.get("roots", ()), spec.get("visible", ()), spec.get("names", ()))


def from_config(config) -> Hidden | None:
    spec = config.get("hidden") if isinstance(config, dict) else None
    return _parsed(json.dumps(spec, sort_keys=True)) if spec else None


def for_context(ctx) -> Hidden | None:
    return from_config(getattr(getattr(ctx, "app", None), "config", None))


def missing(path) -> FileNotFoundError:
    """The error a hidden path gives: the same as a path that does not exist."""
    return FileNotFoundError(f"{path} does not exist.")


def visible_path(path: Path, hidden: Hidden | None) -> bool:
    return hidden is None or not hidden.hides(path)
