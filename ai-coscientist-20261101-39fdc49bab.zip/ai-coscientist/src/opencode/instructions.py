"""Project instruction files: AGENTS.md, CLAUDE.md, and config.instructions."""

from __future__ import annotations

import os
from pathlib import Path
from threading import RLock
from weakref import WeakKeyDictionary

from opencode.paths import config_dir, home


_claims = WeakKeyDictionary()
_claim_lock = RLock()


def _read(path: Path) -> str:
    try:
        if path.is_file():
            return path.read_text(encoding="utf-8")
    except OSError:
        return ""
    return ""


def _find_up(name: str, start: Path, stop: Path) -> list[Path]:
    found: list[Path] = []
    current = start.resolve()
    stop = stop.resolve()
    while True:
        candidate = current / name
        if candidate.is_file():
            found.append(candidate)
        if current == stop or current.parent == current:
            break
        parent = current.parent
        if stop != parent and stop not in parent.parents:
            break
        current = parent
    return found


def _expand_glob(pattern: str, directory: Path, worktree: Path) -> list[Path]:
    pattern = os.path.expanduser(pattern)
    path = Path(pattern)
    if path.is_absolute():
        if any(char in pattern for char in "*?["):
            return sorted(Path(path.anchor).glob(str(path.relative_to(path.anchor))))
        return [path] if path.is_file() else []
    current = directory.resolve()
    stop = worktree.resolve()
    matches = []
    while True:
        matches.extend(item for item in sorted(current.glob(pattern)) if item.is_file())
        if current == stop or stop not in current.parents:
            break
        current = current.parent
    return matches


def collect(directory: Path, worktree: Path, config: dict,
            *, previous: list[tuple[str, str]] | None = None) -> list[tuple[str, str]]:
    """Return (path, text) instruction documents, global file first, then the first project filename that exists."""
    items: list[tuple[str, str]] = []
    if not os.environ.get("OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"):
        global_candidates = [config_dir() / "AGENTS.md", home() / ".claude" / "CLAUDE.md"]
    else:
        global_candidates = [config_dir() / "AGENTS.md"]
    for path in global_candidates:
        text = _read(path)
        if text.strip():
            items.append((str(path), text))
        if path.is_file():
            break

    if not os.environ.get("OPENCODE_DISABLE_PROJECT_CONFIG"):
        names = ["AGENTS.md", "CONTEXT.md"]
        if not os.environ.get("OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"):
            names = ["AGENTS.md", "CLAUDE.md", "CONTEXT.md"]
        for name in names:
            matches = _find_up(name, directory, worktree)
            if matches:
                for match in matches:
                    text = _read(match)
                    if text.strip():
                        items.append((str(match), text))
                break

    for raw in config.get("instructions") or []:
        if not isinstance(raw, str):
            continue
        if raw.startswith("http://") or raw.startswith("https://"):
            cached = dict(previous or [])
            items.append((raw, cached[raw] if raw in cached else _fetch(raw)))
            continue
        for match in _expand_glob(raw, directory, worktree):
            text = _read(match)
            if text.strip():
                items.append((str(match), text))
    # A file may be selected by the default names and by config.instructions.
    # Upstream's systemPaths is a set, so its instructions are included once.
    return list(dict(items).items())


def _fetch(url: str) -> str:
    try:
        import httpx
    except ImportError:
        return ""
    try:
        response = httpx.get(url, timeout=5, follow_redirects=True)
        if response.status_code >= 400:
            return ""
        return response.text
    except Exception:
        return ""


def render(items: list[tuple[str, str]]) -> str:
    if not items:
        return ""
    return "\n".join(f"Instructions from: {path}\n{text}" for path, text in items if text)


def clear(app, message_id: str) -> None:
    """Release the per-assistant-message claims after its tools finish."""
    with _claim_lock:
        messages = _claims.get(app)
        if messages is not None:
            messages.pop(message_id, None)


def resolve(ctx, filepath: Path) -> list[tuple[str, str]]:
    """Load nearby instruction files using active read receipts as authority."""
    root = ctx.directory.resolve()
    target = filepath.resolve()
    current = target.parent
    system = {str(Path(path).resolve()) for path, _ in getattr(ctx.app, "instructions", [])
              if not path.startswith(("http://", "https://"))}
    history = ctx.app.store.context_messages(ctx.session_id) if hasattr(ctx.app.store, "context_messages") else []
    already = set()
    for message in history:
        if message.get("role") != "tool" or message.get("name") != "read":
            continue
        metadata = message.get("metadata") or {}
        if message.get("error") or metadata.get("error") or metadata.get("compacted") is not None:
            continue
        loaded = metadata.get("loaded")
        if isinstance(loaded, list):
            already.update(item for item in loaded if isinstance(item, str))
    names = ["AGENTS.md", "CONTEXT.md"]
    if not os.environ.get("OPENCODE_DISABLE_CLAUDE_CODE_PROMPT"):
        names.insert(1, "CLAUDE.md")
    message_id = getattr(ctx, "message_id", None)
    results = []
    while current != root and current.is_relative_to(root):
        found = next((current / name for name in names if (current / name).is_file()), None)
        current = current.parent
        if found is None or found == target or str(found) in system or str(found) in already:
            continue
        if message_id is not None:
            with _claim_lock:
                messages = _claims.setdefault(ctx.app, {})
                claimed = messages.setdefault(message_id, set())
                if str(found) in claimed:
                    continue
                claimed.add(str(found))
        text = _read(found)
        if text:
            results.append((str(found), f"Instructions from: {found}\n{text}"))
    return results
