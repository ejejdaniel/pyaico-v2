"""The meta region of a research run: files the agent must not change (docs/design_meta_task_zones_20261030_zh-TW.md §3).

Whatever scores, keeps the accounts or allocates resources stays out of the agent's reach: the
installation's code, configuration and runner, the guidance and tools installed into the workspace,
and the task's own source files. Two guards, because a shell command is not path-limited until the
executor's sandbox exists:

- the agent's own file tools (write, edit, apply_patch) are refused these paths (protected, kept in
  config["protected"]); the framework's tools still save their records and ledgers, under the
  run's ordinary permissions;
- the runner hashes the region when the run starts (snapshot) and compares it whenever a record is
  saved and when the run ends; a continuation is refused when the previous stage changed it.

Framework ledgers inside .opencode (executions.jsonl, history, planning, sources) change while a run
works, so they are not hashed; the file tools are still refused them.

The refusal is not a permission rule: the framework's tools ask the same edit permission when they
save, so a denying rule stopped them too (the mind map, the planning ledger and the research review
in the first real run with it, 2026-10-31).
"""

from __future__ import annotations

import hashlib
from pathlib import Path
import sysconfig

from opencode.permission import wildcard_match

INSTALLATION = ("src", "config", "scripts")
WORKSPACE = (".opencode/opencode.json", ".opencode/opencode.jsonc", ".opencode/skills", ".opencode/skill",
             ".opencode/tools", ".opencode/tool", ".opencode/deep")
# Workspace paths the agent's file tools may not write (patterns relative to the workspace).
PROTECTED = (".opencode/*", ".research/records/*")
# A file outside the workspace: a relative path that leaves it, or an absolute path on another drive.
OUTSIDE = ("../*", "?:*")


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _files(root: Path):
    if root.is_file():
        yield root
    elif root.is_dir():
        for path in sorted(root.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                yield path


def _packages() -> str:
    """One hash of the installed distribution names: a package added to the framework's own environment."""
    purelib = Path(sysconfig.get_paths()["purelib"])
    names = sorted(path.name for path in purelib.glob("*.dist-info")) if purelib.is_dir() else []
    return hashlib.sha256("\n".join(names).encode("utf-8")).hexdigest()


def snapshot(project: Path, workspace: Path, sources, extra: dict[str, Path] | None = None) -> dict[str, str]:
    """{label: sha256} of the meta region: installation, installed guidance and tools, task sources, packages.

    extra names further folders by label, such as the task skills kept in a run's state (task_skills.py):
    they may change between runs, so workspace_part leaves them out."""
    found = {}
    for label, folder in (extra or {}).items():
        for path in _files(Path(folder)):
            found[f"{label}/" + path.relative_to(folder).as_posix()] = _digest(path)
    for name in INSTALLATION:
        for path in _files(project / name):
            found["install/" + path.relative_to(project).as_posix()] = _digest(path)
    for name in WORKSPACE:
        for path in _files(workspace / name):
            found["workspace/" + path.relative_to(workspace).as_posix()] = _digest(path)
    for name in sources:
        path = workspace / name
        found["workspace/" + name] = _digest(path) if path.is_file() else "missing"
    found["environment/site-packages"] = _packages()
    return found


def workspace_part(found: dict) -> dict:
    """The entries a stage's agent could have changed: the installation changes between stages by design."""
    return {key: value for key, value in found.items() if key.startswith("workspace/")}


def changes(before: dict, after: dict) -> list[str]:
    """Every entry changed, added or removed, one line each, in a stable order."""
    lines = [f"changed: {key}" for key in sorted(before.keys() & after.keys()) if before[key] != after[key]]
    lines += [f"added: {key}" for key in sorted(after.keys() - before.keys())]
    lines += [f"removed: {key}" for key in sorted(before.keys() - after.keys())]
    return lines


def protected(sources) -> list[str]:
    """What the agent's own file tools may not write (config["protected"]): the meta region, the framework's
    ledgers and records, the task's sources and everything outside the workspace. Patterns are matched as
    permission patterns are, against the path relative to the workspace."""
    return [*PROTECTED, *OUTSIDE, *sources]


def refuses(patterns, relative: str) -> bool:
    """Whether a path, relative to the workspace, is one of the protected patterns."""
    return any(wildcard_match(relative, pattern) for pattern in patterns or ())
