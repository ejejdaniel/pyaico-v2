"""Agent loop: prompt, tool calls, permissions, compaction, and titles."""

from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from concurrent.futures import Future, TimeoutError as FutureTimeout
import base64
import copy
import re
from types import SimpleNamespace
from urllib.parse import urlsplit, unquote, parse_qs
from urllib.request import url2pathname
from itertools import count
from jsonschema import validate as validate_arguments
from dataclasses import dataclass, field, replace
from pathlib import Path

from opencode.agent import provider_prompt
from opencode import answer_review, executor
from opencode.collation import _locale_key
from opencode.compaction import compact, estimate_tokens, input_budget, usage_overflow, is_context_overflow, prune
from opencode.context import working_context
from opencode.deep import HINT as DEEP_HINT, is_on as deep_is_on, skills as installed_skills, tools as deep_tools
from opencode.instructions import collect as collect_instructions, render as render_instructions, clear as clear_instructions
from opencode.progress import stalled
from opencode.prompts import load as load_prompt
from opencode.provider import Completion, ProviderError, openai_messages_from_history, repair_tool_calls, tool_call_error
from opencode.permission import PermissionRejected, Rule
from opencode.skills import discover, render as render_skills
from opencode.store import new_id, latest_human_message
from opencode.tools import builtin_tools, tools_for
from opencode.tools.types import Tool, ToolResult, external_source_names
from opencode.tools.util import tool_error, truncate, truncate_output
from opencode.turn import context_text, create_extension


@dataclass
class ToolContext:
    app: object
    session_id: str
    agent: object
    message_id: str
    call_id: str
    depth: int
    directory: Path
    worktree: Path
    read_files: set[str]
    turn: int
    switch_agent: str | None = None
    abort: threading.Event | None = None


@dataclass
class RunResult:
    text: str
    session_id: str
    message_id: str | None = None
    info: dict = field(default_factory=dict)


# Unattended: after this many refusals of a repeated call in a row, the turn ends (v9 repeated ~80 times).
REPEAT_REFUSAL_LIMIT = 3


class _ToolDispatch:
    """Own one assistant's tool calls while its provider stream is still open."""

    def __init__(self, app, session_id, assistant_id, agent, tools, depth, read_files, turn, on_result):
        self.app, self.session_id, self.assistant_id = app, session_id, assistant_id
        self.agent, self.depth = agent, depth
        # The source executes from the same last-definition-wins tool record
        # that is supplied to the model, including repaired calls.
        self.tools = list({tool.name: tool for tool in tools}.values())
        self.read_files, self.turn, self.on_result = read_files, turn, on_result
        self.abort = app.abort_event(session_id)
        self.attempt_abort = self.abort
        self.lock = threading.RLock()
        self.calls, self.active, self.futures, self.receipts = [], {}, {}, set()
        self.settled = {}
        self.partial = Completion()
        self.recent = []
        self.rejected = False
        self.stuck = False
        self.switch_agent = None
        self.closed = False

    def records(self):
        return [vars(call) for call in self.calls]

    def begin_attempt(self, attempt, abort_event):
        with self.lock:
            # A retry creates a new SDK dispatch scope. Completed source parts
            # remain in history; only this attempt's callback deduplication resets.
            self.futures = {}
            self.attempt_abort = abort_event

    def record(self, partial):
        with self.lock:
            if self.closed:
                return
            if partial.text != self.partial.text or partial.reasoning_content != self.partial.reasoning_content:
                self.recent.clear()
            self.partial = partial
            self.app.store.update_message(self.session_id, self.assistant_id,
                content=partial.text, reasoning_content=partial.reasoning_content,
                tool_calls=self.records(),
                incomplete_tool_calls=[vars(call) for call in partial.tool_calls if call.id not in self.futures],
                tokens=partial.usage, finish_reason=partial.finish_reason)

    def start(self, original):
        with self.lock:
            if original.id in self.futures:
                return self.futures[original.id]
            if self.closed:
                raise ProviderError("Tool dispatch already stopped")
            call, = repair_tool_calls(Completion(tool_calls=[original]), _tool_payload(self.tools)).tool_calls
            index = self.active.get(call.id)
            if index is None:
                index = len(self.calls)
                self.calls.append(call)
                self.active[call.id] = index
                self.settled[index] = Future()
            else:
                # processor.ensureToolCall reuses a still-running part and
                # updates its input. The new SDK attempt still executes it.
                self.calls[index] = call
            future = self.futures[call.id] = Future()
            # The call as the model sent it: different calls refused for the same schema error all become one
            # "invalid" call, and LIT (2026-11-01) was told three different deliveries were identical.
            signature = original.name + ":" + json.dumps(original.arguments, separators=(",", ":"),
                                                         ensure_ascii=False, default=str)
            if any(item[0] == index for item in self.recent):
                self.recent = [(position, signature if position == index else value) for position, value in self.recent]
            else:
                self.recent.append((index, signature))
            doom = len(self.recent) >= 3 and [item[1] for item in self.recent[-3:]] == [signature] * 3
            # Also catch one identical call per step repeated across steps of this turn.
            turns = self.app.__dict__.setdefault("_turn_tool_calls", {})
            for key in [key for key in turns if key[0] == self.session_id and key[1] != self.turn]:
                del turns[key]
            this_turn = turns.setdefault((self.session_id, self.turn), {})
            this_turn[(self.assistant_id, index)] = signature
            # "within": the source's check inside one reply. "across": this step's calls so far are
            # exactly the previous two steps' calls, e.g. the same two reads in three steps running.
            # A step that repeats one call but changes another (edit, then rerun tests) is not caught.
            steps = list(dict.fromkeys(step for step, _ in this_turn))[-3:]

            def calls_of(step):
                return sorted(value for (owner, _), value in this_turn.items() if owner == step)

            repeated = (len(steps) == 3 and steps[-1] == self.assistant_id
                        and calls_of(steps[0]) == calls_of(steps[1]) == calls_of(steps[2]))
            # "again": this step's calls so far are exactly the previous step's. The call runs, and its
            # result says so: Q1 (2026-10-31) sent the same command five times, and the first word of it
            # came with the third, as a refusal.
            again = (len(steps) >= 2 and steps[-1] == self.assistant_id
                     and calls_of(steps[-2]) == calls_of(steps[-1]))
            doom = "within" if doom else ("across" if repeated else ("again" if again else None))
            self.app.store.update_message(self.session_id, self.assistant_id,
                tool_calls=self.records(),
                incomplete_tool_calls=[vars(item) for item in self.partial.tool_calls if item.id not in self.futures])
            attempt_abort = self.attempt_abort

        def worker():
            try:
                self.execute(call, doom, attempt_abort)
            except BaseException as error:
                future.set_exception(error)
            else:
                future.set_result(None)

        threading.Thread(target=worker, daemon=True, name="opencode-stream-tool").start()
        return future

    def save(self, call, result, *, index=None):
        with self.lock:
            index = self.active.get(call.id) if index is None else index
            if self.closed or index is None or index in self.receipts:
                return False
            call = self.calls[index]
            message = {"tool_call_id": call.id, "name": call.name, "content": result.output,
                       "title": result.title, "metadata": result.metadata}
            if result.attachments:
                message["attachments"] = result.attachments
            _save_tool_message(self.app, self.session_id,
                               {"id": self.assistant_id, "role": "assistant", "tool_calls": [vars(call)]}, message)
            self.receipts.add(index)
            self.active.pop(call.id, None)
            self.settled[index].set_result(None)
            return True

    def execute(self, call, doom, abort_event):
        ctx = ToolContext(self.app, self.session_id, self.agent, self.assistant_id, call.id,
                          self.depth, self.app.directory, self.app.worktree, self.read_files, self.turn,
                          abort=abort_event)
        try:
            if abort_event.is_set():
                raise RuntimeError("Tool execution aborted")
            refusals = self.app.__dict__.setdefault("_repeat_refusals", {})
            key = (self.session_id, self.turn)
            if doom == "across" and getattr(self.app.permissions, "auto", False):
                # Unattended runs approve every ask; hand cross-step repetition back instead.
                # A model that keeps repeating after being told ends the turn (status repeat_limit).
                refusals[key] = refusals.get(key, 0) + 1
                if refusals[key] >= REPEAT_REFUSAL_LIMIT:
                    with self.lock:
                        self.stuck = True
                name = call.arguments.get("tool", call.name) if call.name == "invalid" else call.name
                raise ValueError(
                    f"{name} was called with identical arguments three times in a row (this step repeats "
                    "the previous two steps' tool calls exactly); repeating it will not change the result. Read "
                    "the earlier result, check the command or arguments for a mistake, or choose a different "
                    "approach.")
            if doom in ("within", "across"):
                self.app.permissions.ask(session_id=self.session_id, permission="doom_loop",
                    patterns=[call.name], ruleset=self.agent.permission, always=[call.name],
                    metadata={"tool": call.name, "input": call.arguments}, abort_event=abort_event)
            if error := tool_call_error(call):
                raise ValueError(error)
            tool = next((item for item in self.tools if item.name == call.name), None)
            if tool is None:
                raise ValueError(f"unknown tool {call.name}")
            refusals.pop(key, None)  # a call that runs ends the run of refused repeats
            budget = network_budget(self.app.config)
            used = None
            if call.name in NETWORK_TOOLS and budget:
                counts = self.app.__dict__.setdefault("_network_queries", {})
                with self.lock:
                    if counts.get(key, 0) >= budget:
                        raise ValueError(network_limit_notice(budget))
                    counts[key] = used = counts.get(key, 0) + 1
            self.app.bus.publish("tool.running", {"sessionID": self.session_id, "tool": call.name, "input": call.arguments})
            validate_arguments(call.arguments or {}, tool.parameters)
            with executor.scope(ctx.directory, self.session_id, call.name, call.id):
                result = tool.execute(call.arguments or {}, ctx)
            if not isinstance(result, ToolResult):
                result = ToolResult(output=str(result))
            if "truncated" not in result.metadata:
                limits = self.app.config.get("tool_output") or {}
                result.output, metadata = truncate_output(result.output,
                    max_lines=limits.get("max_lines", 2000), max_bytes=limits.get("max_bytes", 51200), agent=self.agent)
                result.metadata.update(metadata)
            if used is not None:
                result.output += f"\n\n[本任務聯網查詢已用 {used}/{budget} 次" + (
                    "；已用完，請依目前結果作答]" if used >= budget else "]")
            if doom == "again":
                result.output += "\n\n" + REPEAT_AGAIN
        except Exception as error:
            result = tool_error(error)
            result.metadata["error"] = True
            with self.lock:
                self.rejected = self.rejected or (isinstance(error, PermissionRejected) and not abort_event.is_set())
        with self.lock:
            if ctx.switch_agent:
                self.switch_agent = ctx.switch_agent
        if not self.save(call, result):
            return
        if self.on_result:
            self.on_result(ToolResult(output=truncate(result.output, label="tool"), title=result.title,
                                       metadata=result.metadata, attachments=result.attachments,
                                       tool=call.name,
                                       input=dict(call.arguments) if isinstance(call.arguments, dict) else {}))
        self.app.bus.publish("tool.completed", {"sessionID": self.session_id, "tool": call.name, "title": result.title})

    def finish(self, error=None):
        """Normal finish waits for tools; failed streams give cleanup 250ms."""
        pending = list(self.futures.values())
        if error is None:
            try:
                for future in pending:
                    while True:
                        if self.abort.is_set():
                            raise ProviderError("Model request aborted", self.partial)
                        try:
                            future.result(timeout=0.05)
                            break
                        except FutureTimeout:
                            if future.done():
                                raise
                            continue
            except BaseException as failure:
                self.finish(failure)
                raise
        deadline = time.monotonic() + 0.25
        with self.lock:
            pending_parts = [self.settled[index] for index in self.active.values()]
        for future in pending_parts:
            try:
                future.result(timeout=max(0, deadline - time.monotonic()))
            except BaseException:
                pass
        with self.lock:
            if error is not None:
                # Pending inputs have never run. Preserve their raw partial input
                # separately and pair the saved call with an interrupted result.
                for call in self.partial.tool_calls:
                    if call.id not in self.futures and call.id not in self.active:
                        index = len(self.calls)
                        self.calls.append(replace(call, arguments={}))
                        self.active[call.id] = index
                        self.settled[index] = Future()
                self.app.store.update_message(self.session_id, self.assistant_id, tool_calls=self.records())
            for index in list(self.active.values()):
                self.save(self.calls[index], ToolResult(output="Error: Tool execution aborted", title="error", metadata={"error": True}), index=index)
            self.closed = True
        _save_reads(self.app, self.session_id, self.read_files, self.turn)
        clear_instructions(self.app, self.assistant_id)


def save_prompt(app, session_id: str, text: str, *, agent=None, model=None, parts=None) -> dict:
    session = app.store.get_session(session_id)
    name = agent or session.get("agent") or app.default_agent
    if name not in app.agents:
        raise ValueError(f'Agent not found: "{name}"')
    provider, model_id = app.provider.resolve(model or app.agents[name].model or session.get("model"))
    data = {"id": new_id("msg"), "content": text, "agent": name, "model": f"{provider.id}/{model_id}"}
    if parts:
        texts = []
        attachments = []
        for part in parts:
            if not isinstance(part, dict):
                raise ValueError("Invalid user message part")
            if part.get("type", "text") == "text":
                texts.append(part.get("text", ""))
            elif part.get("type") == "file":
                attachment = {key: part[key] for key in ("mime", "url", "filename") if key in part}
                if not attachment.get("url") or not attachment.get("mime"):
                    raise ValueError("File parts require url and mime")
                url = urlsplit(attachment["url"])
                if url.scheme == "data" and attachment["mime"] == "text/plain":
                    header, payload = attachment["url"].split(",", 1)
                    body = base64.b64decode(payload).decode("utf-8", errors="replace") if ";base64" in header else unquote(payload)
                    texts.extend(["Called the Read tool with the following input: " + json.dumps(
                        {"filePath": attachment.get("filename")}, separators=(",", ":")), body])
                elif url.scheme == "file":
                    path = Path(url2pathname(("//" + url.netloc if url.netloc else "") + url.path))
                    args = {"filePath": str(path)}
                    params = parse_qs(url.query)
                    if params.get("start"):
                        args["offset"] = max(int(params["start"][0]), 1)
                        if params.get("end"):
                            args["limit"] = int(params["end"][0]) - args["offset"] + 1
                    texts.append("Called the Read tool with the following input: " + json.dumps(args, separators=(",", ":")))
                    if attachment["mime"] == "text/plain" or path.is_dir():
                        from opencode.tools.files import _read
                        read_app = copy.copy(app)
                        read_app.permissions = SimpleNamespace(ask=lambda **_: None)
                        ctx = ToolContext(read_app, session_id, app.agents[name], data["id"], "", 0,
                                          app.directory, app.worktree, set(), 0)
                        try:
                            result = _read(args, ctx)
                            texts.append(result.output)
                            attachments.extend(result.attachments or [])
                        except Exception as exc:
                            texts.append(f"Read tool failed to read {path} with the following error: {exc}")
                        finally:
                            clear_instructions(read_app, data["id"])
                        continue
                    attachment["url"] = f"data:{attachment['mime']};base64," + base64.b64encode(path.read_bytes()).decode("ascii")
                attachments.append(attachment)
            else:
                raise ValueError(f"Unsupported message part: {part.get('type')}")
        data["content"] = "\n".join(texts) if texts else text
        if attachments:
            data["attachments"] = attachments
    return app.store.add_message(session_id, "user", data)


def run(
    app,
    session_id: str,
    text: str,
    *,
    agent: str | None = None,
    model: str | None = None,
    depth: int = 0,
    on_text=None,
    on_tool_result=None,
    parts: list | None = None,
    resume_user_message_id: str | None = None,
    _continue: bool = False,
    _saved_user: dict | None = None,
) -> dict:
    # Refresh file-backed guidance once per user turn, not once per App lifetime.
    app.instructions = collect_instructions(app.directory, app.worktree, app.config,
                                            previous=app.instructions)
    app.skills = discover(app.directory, app.worktree, app.config)
    session = app.store.get_session(session_id)
    prior_review = None
    if _continue:
        resumed_human = latest_human_message(app.store.messages(session_id))
        if resumed_human is None:
            raise ValueError("Background continuation requires a saved human request")
        prior_review = app.store.answer_review(session_id, resumed_human["id"])
        if prior_review and prior_review["phase"] != "delivered":
            resumed_human, review = answer_review.resume(app, session_id, resumed_human["id"], resumed_human["content"])
        else:
            review = None
    else:
        resumed_human, review = (answer_review.resume(app, session_id, resume_user_message_id, text)
                                 if resume_user_message_id is not None else (None, None))
    if resumed_human is not None and parts:
        raise ValueError("Resume cannot replace the original human message with parts")
    _close_unfinished_tools(app, session_id)
    source_tools = external_source_names([*builtin_tools(), *deep_tools(app)])
    app.store.export_tool_history(session_id, source_tools=source_tools)
    agent_name = agent or session.get("agent") or app.default_agent
    agent_info = app.agents.get(agent_name)
    if agent_info is None:
        raise ValueError(f'Agent not found: "{agent_name}"')
    review_name = (None if _continue and prior_review and prior_review["phase"] == "delivered"
                   else review["skill_name"] if review else answer_review.configured_skill(agent_info))
    review_guidance = None
    if review_name is not None:
        answer_review.authorize(app, session_id, agent_info, review_name)
        if not review or review["phase"] == "collecting":
            review_guidance = answer_review.guidance(app, review_name)
    provider, model_id = app.provider.resolve(model or agent_info.model or session.get("model"))
    model_ref = f"{provider.id}/{model_id}"
    if session.get("model") != model_ref or session.get("agent") != agent_name:
        app.store.update_session(session_id, model=model_ref, agent=agent_name)

    user_message = resumed_human or _saved_user or save_prompt(app, session_id, text, agent=agent_name, model=model_ref, parts=parts)
    app.store.export_work_history(session_id)
    app.bus.publish("message.updated", {"sessionID": session_id})
    auxiliary = agent_info.hidden and agent_info.name in {"title", "summary", "compaction"}
    # Deep research (opencode/deep.py) is read once a turn: a switch takes effect from the next message.
    deep_on = deep_is_on(app, session_id)
    extension = None if auxiliary else create_extension(app, session_id, user_message["id"], deep=deep_on)
    extension_context = context_text(extension)
    if not _continue and not session.get("title") and getattr(app, "generate_titles", True):
        _title(app, session_id, text, provider, model_id)

    app.ensure_mcp()
    read_files = set((session.get("meta") or {}).get("read_files") or [])
    abort = app.abort_event(session_id)
    extension_notices = set()
    todo_nudged = False
    answer_nudged = False
    # The repeat guard ended the turn: one more step, without tools, reports what was found (STOP_REPORT).
    stop_report = False
    recent_results, repeat_notices = [], set()
    steps = agent_info.steps if agent_info.steps is not None else float("inf")
    if review_name is not None and review is None:
        review_steps = steps if steps != float("inf") else int(app.config.get("steps") or 100)
        review = app.store.start_answer_review(session_id, user_message["id"], review_name, review_steps)
    if review:
        steps = review["step_limit"] - review["steps_used"]
    last_text = ""
    last_message_id = None
    turn = int((session.get("meta") or {}).get("turn") or 0) + 1
    # Reserve the snapshot turn before any tool can change a file.
    _save_reads(app, session_id, read_files, turn)
    status = "completed"
    context_agent = agent_info.name
    compaction_steps = 0

    for step in count():
        if review and step >= steps:
            status = "step_limit"
            break
        if abort.is_set():
            app.store.add_message(session_id, "assistant", {"content": last_text, "agent": agent_info.name, "error": "aborted"})
            break
        active_session = app.store.get_session(session_id)
        latest_user = latest_human_message(app.store.messages(session_id))
        if latest_user and latest_user["id"] != user_message["id"]:
            user_message = latest_user
            agent_name = latest_user.get("agent") or agent_name
            provider, model_id = app.provider.resolve(latest_user.get("model"))
            model_ref = f"{provider.id}/{model_id}"
            app.store.update_session(session_id, agent=agent_name, model=model_ref)
            extension = create_extension(app, session_id, user_message["id"], deep=deep_on)
            extension_context = context_text(extension)
            review = None
            review_name = None
        agent_info = app.agents.get(agent_name) or agent_info
        session_rules = [Rule(**rule) for rule in active_session.get("permission") or []]
        agent_info = replace(agent_info, permission=[*agent_info.permission, *session_rules])
        if review:
            answer_review.authorize(app, session_id, agent_info, review_name)
        auxiliary = agent_info.hidden and agent_info.name in {"title", "summary", "compaction"}
        if agent_info.name != context_agent:
            extension_context = context_text(extension) if not auxiliary else ""
            context_agent = agent_info.name
        tools = (
            []
            if agent_info.hidden and agent_info.name in {"title", "summary", "compaction"}
            else tools_for(agent_info, [*app.mcp.tool_specs(), *app.extra_tools, *_deep_tools(app, deep_on)],
                           model_id=model_id,
                           provider_id=provider.id, agents=app.agents, config=app.config)
        )
        if step == 0 and not auxiliary and deep_on:
            # Before the system prompt is built: it carries the plan from the first request on.
            _plan_verification(app, session_id, active_session)
        system = _system(app, agent_info, model_id, provider.id, session_id, deep=deep_on)
        # Installed extensions: keep the system prompt static so the provider's
        # prefix cache survives, and send per-step host facts after the history.
        labelled = extension is not None and not auxiliary
        if labelled:
            system += "\n\n" + load_prompt("context-labels.txt")
        lessons, lessons_reminder = _task_review(app, active_session, session_id, auxiliary or not deep_on)
        # Counted where it is shown: as a host fact, or as the trigger of the lessons' reminder.
        stall, progress_facts, stretch = (stalled(app, session_id, active_session, source_tools)
                                          if not auxiliary and (labelled or lessons) else (0, "", []))
        budget = _turn_budget(app, active_session, deep_on, auxiliary)
        budget_note = _budget_note(budget, step)
        if budget and step >= budget[0] - 1 and not stop_report:
            # The person's turn has used its calls: this last one, without tools, reports where the work stands.
            stop_report, status, last_text = True, "call_limit", ""
            app.store.add_message(session_id, "assistant", {
                "content": "[宿主執行檢查；非人類委託、非模型結論]\n" + CALL_LIMIT_REPORT, "synthetic": True})
            app.store.export_work_history(session_id)
        if stall and deep_on and not stop_report and _pause_for_review(app, session_id, stretch):
            # Counted again: the progress check now tells of the pause, and a new review version moves to the
            # newest message.
            active_session = app.store.get_session(session_id)
            lessons, lessons_reminder = _task_review(app, active_session, session_id, auxiliary or not deep_on)
            stall, progress_facts, stretch = stalled(app, session_id, active_session, source_tools)
        if not stall:
            lessons_reminder = ""  # the lessons' one line comes back when the work stalls
        host_facts = "\n\n".join(part for part in (
            _with_progress(extension_context, progress_facts) if labelled else "", budget_note) if part)
        budget_system = system + "".join("\n\n" + part for part in (host_facts, lessons, lessons_reminder) if part)
        payload = _tool_payload(tools) if tools and not stop_report else None
        internal_tools = [*tools, Tool("invalid", "Do not use", {
            "type": "object", "properties": {"tool": {"type": "string"}, "error": {"type": "string"}},
            "required": ["tool", "error"],
        }, lambda args, ctx: ToolResult(title="Invalid Tool",
            output=f"The arguments provided to the tool are invalid: {args['error']}"))]
        history, observed_notifications = app._context_snapshot(session_id)
        history = _relocate(app, session_id, _present_history(history, app.store, session_id))
        foreground = _relocate(app, session_id, working_context(history, app.store, session_id))
        if usage_overflow(app, session_id, provider, model_id):
            # Local todo/review extensions remain in addition to the summary.
            reserve = estimate_tokens(openai_messages_from_history(working_context([], app.store, session_id)))
            reserve = max(reserve, estimate_tokens(openai_messages_from_history(foreground))
                          - estimate_tokens(openai_messages_from_history(history)))
            _maybe_compact(app, session_id, history, provider, model_id, system=budget_system, tools=payload,
                           reserved_tokens=reserve)
            compaction_steps += 2  # Schedule and process are separate source loop iterations.
            app.store.export_work_history(session_id)
            history, observed_notifications = app._context_snapshot(session_id)
            history = _relocate(app, session_id, _present_history(history, app.store, session_id))
            foreground = _relocate(app, session_id, working_context(history, app.store, session_id))
            if labelled:
                # The facts were read before compaction; what it dropped (a skill's text) shows only in new ones.
                extension_context = context_text(extension)
                host_facts = _with_progress(extension_context, progress_facts)
        messages = _with_host_facts(openai_messages_from_history(
            _reminders(_with_human_ids(foreground) if labelled else foreground, agent_info), model_ref=model_ref),
            host_facts, session_id, review=lessons, reminder=lessons_reminder)
        if not review and step + compaction_steps + 1 >= (agent_info.steps if agent_info.steps is not None else float("inf")):
            messages.append({"role": "assistant", "content": load_prompt("max-steps.txt")})
        if review:
            app.store.reserve_answer_review_step(session_id, user_message["id"])
        # The source re-enters its loop after each compaction; it does not impose
        # a separate one-retry cap on foreground context-overflow recovery.
        for context_attempt in count():
            assistant_id = new_id("msg")
            app.store.add_message(session_id, "assistant", {
                "id": assistant_id, "content": "", "agent": agent_info.name, "model": model_ref,
            })
            streamed_text = []
            tool_dispatch = _ToolDispatch(app, session_id, assistant_id, agent_info, internal_tools,
                                          depth, read_files, turn, on_tool_result)

            def record_text(chunk):
                streamed_text.append(chunk)
                with tool_dispatch.lock:
                    tool_dispatch.partial = replace(tool_dispatch.partial, text="".join(streamed_text))
                    tool_dispatch.recent.clear()
                app.store.update_message(session_id, assistant_id, content="".join(streamed_text))
                app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
                if on_text and not review:
                    on_text(chunk)

            def record_update(partial):
                tool_dispatch.record(partial)

            try:
                app._acknowledge_notifications(session_id, observed_notifications)

                def model_call():
                    return app.provider.complete(
                        provider=provider, model=model_id, system=system, messages=messages,
                        tools=payload, temperature=agent_info.temperature,
                        on_text=record_text,
                        on_update=record_update,
                        on_tool_call=None if stop_report else tool_dispatch.start,
                        on_attempt=tool_dispatch.begin_attempt,
                        abort_event=abort,
                    )

                completion = model_call()
                if _empty_reply(completion) and not abort.is_set():
                    # LIT v26 ended at its ninth call: the server reported 330 generated tokens and streamed
                    # neither text nor a tool call, and the empty reply was taken as the final answer. Ask
                    # once more (a new seed when the provider draws one per request); a second empty reply
                    # is an error, not a completed turn.
                    logging.getLogger(__name__).warning(
                        "Empty model reply (no text, no tool calls, finish_reason=%s, %s completion tokens); "
                        "asking once more", completion.finish_reason, (completion.usage or {}).get("completion_tokens"))
                    completion = model_call()
                    if _empty_reply(completion):
                        raise ProviderError("The model returned an empty reply twice (no text and no tool call); "
                                            "the turn was stopped instead of being taken as a final answer",
                                            partial=completion)
                if stop_report:
                    # The report step offers no tools; a call it names anyway is not run.
                    completion = replace(completion, tool_calls=[])
                for call in completion.tool_calls:
                    tool_dispatch.start(call)
                tool_dispatch.finish()
                break
            except BaseException as exc:
                partial = getattr(exc, "partial", None) or tool_dispatch.partial
                if partial is not None:
                    tool_dispatch.partial = partial
                tool_dispatch.finish(exc)
                failure = {"error": "aborted" if abort.is_set() or isinstance(exc, KeyboardInterrupt) else str(exc),
                           "tool_calls": tool_dispatch.records()}
                if partial is not None:
                    failure.update(content=partial.text, reasoning_content=partial.reasoning_content,
                                   finish_reason=partial.finish_reason, tokens=partial.usage,
                                   incomplete_tool_calls=[vars(c) for c in partial.tool_calls if c.id not in tool_dispatch.futures])
                app.store.update_message(session_id, assistant_id, **failure)
                if (not isinstance(exc, ProviderError) or not is_context_overflow(exc)
                        or (app.config.get("compaction") or {}).get("auto") is False):
                    raise
                history, observed_notifications = app._context_snapshot(session_id)
                history = _relocate(app, session_id, _present_history(history, app.store, session_id))
                compact(app, session_id, history, provider, model_id, system=budget_system, tools=payload,
                        force=True, overflow=True)
                compaction_steps += 2
                app.store.export_work_history(session_id)
                history, observed_notifications = app._context_snapshot(session_id)
                history = _relocate(app, session_id, _present_history(history, app.store, session_id))
                foreground = _relocate(app, session_id, working_context(history, app.store, session_id))
                if labelled:
                    extension_context = context_text(extension)
                    host_facts = _with_progress(extension_context, progress_facts)
                messages = _with_host_facts(openai_messages_from_history(
                    _reminders(_with_human_ids(foreground) if labelled else foreground, agent_info),
                    model_ref=model_ref), host_facts, session_id, review=lessons, reminder=lessons_reminder)
                if not review and step + compaction_steps + 1 >= (agent_info.steps if agent_info.steps is not None else float("inf")):
                    messages.append({"role": "assistant", "content": load_prompt("max-steps.txt")})
        completion = repair_tool_calls(completion, _tool_payload(internal_tools))
        assistant_data = {
                "id": assistant_id,
                "content": completion.text or "",
                "tool_calls": tool_dispatch.records(),
                "agent": agent_info.name,
                "model": model_ref,
                "tokens": completion.usage,
                "finish_reason": completion.finish_reason,
                "reasoning_content": completion.reasoning_content,
                "incomplete_tool_calls": [],
            }
        if completion.tool_calls:
            todo_nudged = False  # Work resumed after a reminder; a later stop may be reminded again.
        if (not completion.tool_calls and not (completion.text or "").strip() and step > 0 and not answer_nudged
                and not stop_report and not auxiliary and step + 1 < steps and not abort.is_set()):
            # A TUI search ended on an empty reply after a repeat notice: the person got no answer.
            answer_nudged = True
            app.store.update_message(session_id, assistant_id, **assistant_data)
            app.store.add_message(session_id, "assistant", {
                "content": "[宿主執行檢查；非人類委託、非模型結論]\n" + ANSWER_NOW, "synthetic": True})
            app.store.export_work_history(session_id)
            app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
            continue
        if (not completion.tool_calls and not todo_nudged and not stop_report and not auxiliary and step + 1 < steps
                and not abort.is_set() and getattr(app.permissions, "auto", False)
                and completion.finish_reason not in _NOT_A_FINAL_STOP):
            # Unattended: nobody can answer, so a text-only stop with open todos ends the run
            # early. Remind once, before the answer is drafted or delivered; a second stop is
            # handled as usual.
            pending = _unfinished_todos(app, session_id)
            # A delivery check comes first: one with gaps is reported by the turn feedback below,
            # and after a clean one the work is done. Its stale todo list needs no model call: v42
            # spent six minutes rewriting nine finished items and repeating its final answer.
            delivery = None
            if pending and extension is not None and hasattr(extension, "delivery_state"):
                try:
                    delivery = extension.delivery_state()
                except Exception:
                    logging.getLogger(__name__).warning("Delivery state check failed", exc_info=True)
            if pending and delivery is None:
                todo_nudged = True
                app.store.update_message(session_id, assistant_id, **assistant_data)
                app.store.add_message(session_id, "assistant", {
                    "content": "[宿主執行檢查；非人類委託、非模型結論]\n"
                               + _todo_nudge(pending),
                    "synthetic": True,
                })
                app.store.export_work_history(session_id)
                app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
                continue
        review_feedback = None
        if review and not completion.tool_calls and not stop_report:
            assistant_data["answer_review_role"] = "draft"
            if not abort.is_set():
                try:
                    review_feedback = extension.feedback() if extension else None
                    if review_feedback is not None and (not isinstance(review_feedback, str) or not review_feedback.strip()):
                        raise TypeError("Turn feedback must be nonblank text or None")
                except Exception:
                    app.store.update_message(session_id, assistant_id, **assistant_data)
                    app.store.export_work_history(session_id)
                    raise
                if abort.is_set():
                    app.store.update_message(session_id, assistant_id, **assistant_data)
                    break
                if not review_feedback:
                    if review["phase"] == "checking":
                        # Rendering can fail independently of inference; do not mark
                        # delivery committed until the installed presenter succeeds.
                        try:
                            reviewed_final = extension.present(completion.text, "completed") if extension else completion.text
                            if not isinstance(reviewed_final, str):
                                raise TypeError("Turn presentation must be text")
                        except Exception:
                            app.store.update_message(session_id, assistant_id, **assistant_data)
                            app.store.export_work_history(session_id)
                            raise
                        if abort.is_set():
                            app.store.update_message(session_id, assistant_id, **assistant_data)
                            break
                        saved_assistant = app.store.commit_answer_review(session_id, user_message["id"], assistant_data)
                        app.store.export_work_history(session_id)
                        app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
                        _save_reads(app, session_id, read_files, turn)
                        try:
                            prune(app, session_id)
                        except Exception:
                            logging.getLogger(__name__).warning("Tool output pruning failed", exc_info=True)
                        return {"text": reviewed_final, "sessionID": session_id, "status": "completed",
                                "messageID": saved_assistant["id"], "info": app.store.get_session(session_id)}
                    if step + 1 < steps:
                        notification = answer_review.notice(user_message["id"], assistant_id, review_guidance)
                        app.store.commit_answer_review(session_id, user_message["id"], assistant_data, notification)
                        review = app.store.answer_review(session_id, user_message["id"])
                        app.store.export_work_history(session_id)
                        app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
                        if on_text:
                            on_text("\n[交付前核對：草稿已保存，正在查證，尚未交付結論。]\n")
                        continue
        saved_assistant = app.store.update_message(session_id, assistant_id, **assistant_data)
        last_text = completion.text
        last_message_id = saved_assistant["id"]
        app.bus.publish("message.updated", {"sessionID": session_id, "messageID": assistant_id})
        if stop_report:
            break
        if review and completion.tool_calls and completion.text and on_text:
            on_text(completion.text)
        if abort.is_set() and not completion.tool_calls:
            break
        if not completion.tool_calls:
            if completion.finish_reason in {None, "tool_calls", "tool-calls"}:
                continue
            if completion.finish_reason in {"content_filter", "content-filter", "refusal"}:
                app.store.update_message(session_id, assistant_id,
                                         error="The response was blocked by the provider's content filter")
                raise ProviderError("The response was blocked by the provider's content filter", completion)
            if completion.finish_reason in {"length", "max_tokens", "max-tokens"}:
                # Text cut off by the output limit is not a final answer.
                status = "output_limit"
                break
            feedback = review_feedback if review else (
                extension.feedback() if extension and not auxiliary and step + 1 < steps else None)
            if feedback is not None and (not isinstance(feedback, str) or not feedback.strip()):
                raise TypeError("Turn feedback must be nonblank text or None")
            if feedback and feedback not in extension_notices:
                app.store.add_message(session_id, "assistant", {
                    "content": "[宿主執行檢查；非人類委託、非模型結論]\n" + feedback,
                    "synthetic": True,
                })
                app.store.export_work_history(session_id)
                extension_notices.add(feedback)
                continue
            if review:
                # No remaining step for the one verification phase: retain the
                # candidate, then use the ordinary step-limit exit, not the draft.
                continue
            if app._has_pending_notifications(session_id):
                continue
            break

        if completion.tool_calls and not auxiliary:
            repeated = _repeated_result(app, session_id, assistant_id, tool_dispatch.records(), recent_results)
            if repeated and repeated not in repeat_notices:
                # Commands that differ slightly can still return the same answer each time; the
                # call-level repeat check cannot see that. Say so once per repeated result.
                repeat_notices.add(repeated)
                app.store.add_message(session_id, "assistant", {
                    "content": "[宿主執行檢查；非人類委託、非模型結論]\n" + _repeat_result_notice(repeated[0]),
                    "synthetic": True,
                })
                app.store.export_work_history(session_id)
        if tool_dispatch.switch_agent:
            agent_name = tool_dispatch.switch_agent
            agent_info = app.agents.get(agent_name) or agent_info
        if extension and not abort.is_set():
            current_agent = app.agents.get(app.store.get_session(session_id).get("agent")) or agent_info
            auxiliary = current_agent.hidden and current_agent.name in {"title", "summary", "compaction"}
            extension_context = context_text(extension) if not auxiliary else ""
        if tool_dispatch.rejected and (app.config.get("experimental") or {}).get("continue_loop_on_deny") is not True:
            break
        if tool_dispatch.stuck:
            status = "repeat_limit"
            last_text = ""
            if stop_report or auxiliary or abort.is_set():
                break
            # Q1 (2026-10-31) read for 38 calls, then repeated one command until this stop, and the turn
            # ended with nothing of what it had read. One more step, without tools, reports it.
            stop_report = True
            app.store.add_message(session_id, "assistant", {
                "content": "[宿主執行檢查；非人類委託、非模型結論]\n" + STOP_REPORT, "synthetic": True})
            app.store.export_work_history(session_id)
            continue
    _save_reads(app, session_id, read_files, turn)
    status = "aborted" if abort.is_set() else status
    if status != "completed":
        notice = "Stopped: " + status + ". Work is saved; no completion is claimed."
        # The report a guard stop asked for comes after the notice; it is not a completed answer.
        last_text = notice + ("\n\n" + last_text.strip() if stop_report and (last_text or "").strip() else "")
    final_text = extension.present(last_text, status) if extension and not auxiliary else last_text
    if not isinstance(final_text, str):
        raise TypeError("Turn presentation must be text")
    try:
        prune(app, session_id)
    except Exception:
        logging.getLogger(__name__).warning("Tool output pruning failed", exc_info=True)
    return {"text": final_text,
            "sessionID": session_id, "status": status,
            "messageID": last_message_id if status == "completed" else None,
            "info": app.store.get_session(session_id)}


REPEATED_RESULTS = 3
# Tools that query a network service; config network.max_queries caps their calls per task.
NETWORK_TOOLS = {"webfetch", "websearch", "codesearch", "paper_search", "paper_fetch", "literature_agent"}
# Every task replies in the person's language and script (the project lead, 2026-10-31: a general-mode answer
# to a question written in Traditional Chinese came in Simplified Chinese).
LANGUAGE = ("Write your replies, and any explanation or note meant for the person, in the language and script of "
            "the person's messages: Traditional Chinese when they write Traditional Chinese, not Simplified.")
# A person's turn in a general-mode task with someone at the keyboard has this many model calls (config "turn":
# max_calls, remind_before). With remind_before calls left the agent is told so, and the last call, without
# tools, reports where the work stands; the person can say go on. Q1 in general mode (2026-10-31) took 180
# calls and 19 minutes before it answered, with nothing asking it to converge.
TURN_MAX_CALLS = 40
TURN_REMIND_BEFORE = 10
CALL_LIMIT_REPORT = ("這一回合的模型呼叫次數已用完，工具已關閉。請只用文字回覆使用者：到目前為止查到了什麼（附出處）、"
                     "哪些還不確定、建議的下一步，並說明使用者可以要你繼續。不要呼叫工具。")
STOP_REPORT = ("宿主擋下了反覆相同的工具呼叫，這一輪到此結束，工具已關閉。請只用文字回覆使用者：到目前為止查到了什麼"
               "（附出處）、哪些還無法確認，並明說工作沒有完成。不要呼叫工具。")
REPEAT_AGAIN = ("Note from the host: this step repeats the previous step's tool calls exactly (same tools, same "
                "arguments). A third identical step in a row is treated as a loop. Use this result to move on, "
                "check the command for a mistake, or try a different approach.")
ANSWER_NOW = ("你停了下來但沒有給出任何回答。請根據目前已取得的結果直接回答使用者：說明找到了什麼、出處，"
              "以及哪些仍無法確認；不要再查詢。")


def network_budget(config: dict) -> int | None:
    value = (config.get("network") or {}).get("max_queries") if isinstance(config.get("network"), dict) else None
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else None


def network_limit_notice(budget: int) -> str:
    return (f"已達本任務的聯網查詢上限（{budget} 次），這次查詢沒有執行。請依目前已取得的結果作答，"
            "說明找到了什麼、出處，以及哪些仍無法確認；需要更多查詢時請請使用者決定。")


def _empty_reply(completion) -> bool:
    """Generated tokens that arrived as nothing: no text, no reasoning and no tool call.

    A terminal reply that is simply empty still ends the turn, as in OpenCode; only a reply whose
    usage reports generated tokens that never reached the stream (LIT v26) is asked again.
    """
    generated = (completion.usage or {}).get("completion_tokens") if isinstance(completion.usage, dict) else None
    return (not completion.tool_calls and not (completion.text or "").strip()
            and not (completion.reasoning_content or "").strip()
            and isinstance(generated, int) and generated > 0)


def _repeated_result(app, session_id: str, assistant_id: str, calls: list[dict],
                     recent: list[tuple]) -> tuple | None:
    """Append this step's tool results to `recent`; return (tool, digest) when the same tool has
    returned the same output REPEATED_RESULTS times in a row."""
    ids = {call.get("id") for call in calls}
    try:
        history = app.store.messages(session_id)
        start = next((index for index in range(len(history) - 1, -1, -1)
                      if history[index].get("id") == assistant_id), None)
    except Exception:
        return None
    if start is None:
        return None
    saved = [m for m in history[start + 1:] if m.get("role") == "tool" and m.get("tool_call_id") in ids]
    for message in saved:
        content = (message.get("content") or "").strip()
        if content:
            recent.append((message.get("name"), hashlib.sha256(content.encode("utf-8")).hexdigest()))
    del recent[:-REPEATED_RESULTS]
    if len(recent) == REPEATED_RESULTS and len(set(recent)) == 1:
        return recent[-1]
    return None


def _repeat_result_notice(tool: str) -> str:
    return (f"工具 {tool} 已連續 {REPEATED_RESULTS} 次回傳完全相同的結果。再執行一次不會得到新資訊："
            "請依這個結果做出決定並往下一步走、改用不同的方法，或用正式的工具或紀錄保存這次比較，"
            "而不是重跑同樣的計算。")


# Finish reasons that mean the model did not deliberately stop with an answer.
_NOT_A_FINAL_STOP = {None, "tool_calls", "tool-calls", "length", "max_tokens", "max-tokens",
                     "content_filter", "content-filter", "refusal"}


def _unfinished_todos(app, session_id: str) -> list[dict]:
    try:
        todos = app.store.todos(session_id)
    except Exception:
        return []
    return [todo for todo in todos if todo.get("status") not in ("completed", "cancelled")]


def _todo_nudge(pending: list[dict]) -> str:
    # A short preview only: todo text is not otherwise copied into the model's context.
    def preview(text):
        text = " ".join(str(text or "").split())
        return text if len(text) <= 80 else text[:79] + "…"

    items = "\n".join(f"- [{todo.get('status')}] {preview(todo.get('content'))}" for todo in pending[:12])
    more = f"\n- …and {len(pending) - 12} more" if len(pending) > 12 else ""
    return (f"這輪無人值守，沒有使用者能回答問題；你的待辦清單仍有 {len(pending)} 項未完成：\n{items}{more}\n"
            "請繼續下一項工作，把待確認的問題記在筆記裡，而不是停下來等待回覆。若工作確實無法繼續，"
            "請說明原因並更新待辦清單的狀態；再次停止時，本輪即結束。")


def _relocate(app, session_id: str, messages: list[dict]) -> list[dict]:
    return messages


def _with_human_ids(history: list[dict]) -> list[dict]:
    """Show each real human message's saved ID to the model; stored messages are unchanged."""
    result = []
    for message in history:
        if (message.get("role") == "user" and not message.get("synthetic") and not message.get("compaction_through")
                and isinstance(message.get("content"), str) and message.get("id")):
            message = dict(message, content=f'<human id="{message["id"]}">\n{message["content"]}\n</human>')
        result.append(message)
    return result


# Host facts are sent in sections. Each section is attached to the message where its content last
# changed and stays there on later requests, so an unchanged section adds no new tokens and the
# request prefix stays identical; a changed section moves to the newest message. Pins live in this
# process only: a new process, or a compaction that drops the pinned message, sends a section again.
_FACT_PINS: dict[str, dict[str, tuple]] = {}
# The task review is pinned the same way, as one block of its own: (anchor, text) by session.
_REVIEW_PINS: dict[str, tuple] = {}


def _fact_sections(facts: str) -> list[tuple[str, str]]:
    """(key, text) for each blank-line-separated section; the key ignores digits, so a count can change.

    Joining the texts with a blank line gives back the facts exactly.
    """
    parts = []
    for part in facts.split("\n\n"):
        if parts and not part.strip():
            parts[-1] += "\n\n" + part  # a longer blank run stays inside the section before it
        else:
            parts.append(part)
    sections, seen = [], {}
    for part in parts:
        base = re.sub(r"\d+", "#", part.strip().split("\n", 1)[0])[:80]
        seen[base] = seen.get(base, 0) + 1
        sections.append((f"{base}|{seen[base]}", part))
    return sections


def _anchor(message: dict, index: int) -> tuple:
    if message.get("role") == "tool" and message.get("tool_call_id"):
        return ("tool", message["tool_call_id"])
    content = json.dumps(message.get("content"), ensure_ascii=False, sort_keys=True)
    return (message.get("role"), index, hashlib.sha256(content.encode("utf-8")).hexdigest())


def _with_host_facts(messages: list[dict], facts: str, session_id: str | None = None, *,
                     review: str = "", reminder: str = "") -> list[dict]:
    """Attach the host facts to tool results or human messages, each section where it last changed.

    A separate trailing user message made every step look like a new human
    turn, and the model restated itself each step (LIT v4), so sections are a
    tagged suffix of a tool result or human message. They are never stored:
    the saved receipt is the content before them. Without a session_id every
    section goes to the last message, as for a one-off request.

    review and reminder are the task review (task_skills.opening). The review is pinned like a section:
    sent with the message it first came with in this process (a run's round is one process, so the
    round's first message) and again with the newest message once that one is gone (a compaction). The
    reminder goes after the newest message, except when the review itself is there.
    """
    if not facts and not review and not reminder:
        return messages
    result = list(messages)
    last = result[-1] if result else None
    pins = _FACT_PINS.setdefault(session_id, {}) if session_id is not None else {}
    if last is None or last.get("role") not in {"tool", "user"} or not isinstance(last.get("content"), str):
        # Nothing to attach to: send everything in a message of its own, and pin afresh next step.
        pins.clear()
        _REVIEW_PINS.pop(session_id, None)
        blocks = [f"<host-facts>\n{facts}\n</host-facts>" if facts else "", review or reminder]
        result.append({"role": "user", "content": "\n\n".join(block for block in blocks if block)})
        return result
    anchors = {_anchor(message, index): index for index, message in enumerate(result)}
    newest = _anchor(last, len(result) - 1)

    def place(pinned, text):
        """The pin when its message is still sent with its text unchanged; otherwise the newest message."""
        if pinned is None or pinned[1] != text or pinned[0] not in anchors \
                or not isinstance(result[anchors[pinned[0]]].get("content"), str):
            return newest, text
        return pinned

    placed = {}
    if facts:
        current = _fact_sections(facts)
        for key in set(pins) - {key for key, _ in current}:
            del pins[key]
        sections = {}
        for key, text in current:
            pins[key] = pinned = place(pins.get(key), text)
            sections.setdefault(anchors[pinned[0]], []).append(text)
        for index, texts in sections.items():
            placed.setdefault(index, []).append("<host-facts>\n" + "\n\n".join(texts) + "\n</host-facts>")
    review_at = None
    if review:
        pinned = place(_REVIEW_PINS.get(session_id) if session_id is not None else None, review)
        if session_id is not None:
            _REVIEW_PINS[session_id] = pinned
        review_at = anchors[pinned[0]]
        placed.setdefault(review_at, []).append(review)
    if reminder and review_at != len(result) - 1:
        placed.setdefault(len(result) - 1, []).append(reminder)
    for index, blocks in placed.items():
        result[index] = dict(result[index], content=result[index]["content"] + "\n\n" + "\n\n".join(blocks))
    return result


def _with_progress(facts: str, progress: str) -> str:
    """The extension's host facts, then the progress check (opencode/progress.py), nearest the newest message."""
    return "\n\n".join(part for part in (facts, progress) if part)


def _plan_verification(app, session_id: str, session: dict) -> None:
    """Have the task's verification plan written before the agent's first step, when the host application
    supplies a planner (app.plan_verification(session_id) -> the plan's record; task_runtime does) and the
    task has none for this round (opencode/verification.py: a written plan holds for the task, a verdict that
    none is needed for its round). It is a review skill, so from this step on it comes with the round's first
    message like the lessons do."""
    hook = getattr(app, "plan_verification", None)
    if hook is None or session.get("parentID") is not None:
        return
    from opencode.task_skills import current_round, root_session
    from opencode.verification import planned

    root = root_session(app.store, session_id)
    if not planned(root, current_round(root)):
        hook(session_id)


def _pause_for_review(app, session_id: str, stretch: list[dict]) -> bool:
    """Pause a stalled task for a review of the round so far, when the host application supplies one
    (app.pause_review(session_id, stall) -> the review's record; the research runner does).

    The pause comes when progress.pause_after calls of the stall came after the later of the last review and
    the last pause. It is kept in the session's meta (so it holds across processes) and told by the progress
    check, a host fact on the newest tool result; the context labels say what to do after it. A message of its
    own would look like a new turn: in _r2d the agent answered one with a summary and no tool call, which ended
    its turn and the round. True when the work was paused; a new review version then moves to the newest
    message."""
    hook = getattr(app, "pause_review", None)
    if hook is None:
        return False
    from opencode.progress import pause_after, since
    from opencode.task_skills import last_review

    meta = dict(app.store.get_session(session_id).get("meta") or {})
    pauses = [pause.get("time", 0.0) for pause in meta.get("pauses") or []]
    waiting = since(stretch, max([last_review(app.store, session_id), *pauses]))
    if waiting < pause_after(app.config):
        return False
    record = hook(session_id, waiting) or {}
    if record.get("status") == "skipped":
        return False
    meta = dict(app.store.get_session(session_id).get("meta") or {})  # the review may take a while
    meta["pauses"] = [*(meta.get("pauses") or []), {"time": time.time(), "stall": waiting,
                                                    "status": record.get("status")}]
    app.store.update_session(session_id, meta=meta)
    return True


def _task_review(app, session: dict, session_id: str, auxiliary: bool) -> tuple[str, str]:
    """The task review and its reminder for this step's messages (task_skills.opening), in a task's top
    session only: a subagent starts a short history of its own, with the review in its system prompt."""
    if auxiliary or session.get("parentID") is not None:
        return "", ""
    from opencode.task_skills import opening

    return opening(app.store, session_id, installed_skills(app))


def _reminders(history: list[dict], agent) -> list[dict]:
    """Present the default SessionReminders branch without rewriting user input."""
    prompt = (load_prompt("plan.txt") if agent.name == "plan" else
              load_prompt("build-switch.txt") if agent.name == "build" and any(
                  m.get("role") == "assistant" and m.get("agent") == "plan" for m in history) else None)
    if prompt is None:
        return history
    result = list(history)
    for index in range(len(result) - 1, -1, -1):
        if result[index].get("role") == "user":
            result[index] = dict(result[index], content=(result[index].get("content") or "") + "\n\n" + prompt)
            break
    return result


def _save_tool_message(app, session_id: str, assistant: dict, message: dict) -> None:
    saved = app.store.add_message(session_id, "tool", message)
    app.store.export_tool_history(session_id, [assistant, saved])


def _present_history(history: list[dict], store=None, session_id: str | None = None) -> list[dict]:
    result = []
    for message in history:
        if message.get("role") != "tool":
            result.append(message)
            continue
        if (message.get("metadata") or {}).get("compacted") is not None:
            shown = dict(message, content="[Old tool result content cleared]")
            shown.pop("attachments", None)
            result.append(shown)
            continue
        result.append(message)
    return result


def _close_unfinished_tools(app, session_id: str) -> None:
    pending = {}
    for message in app.store.context_messages(session_id):
        if message.get("role") == "assistant":
            for call in message.get("tool_calls") or []:
                pending.setdefault(call["id"], []).append(call)
        elif message.get("role") == "tool":
            replies = pending.get(message.get("tool_call_id"), [])
            if replies:
                replies.pop(0)
    for calls in pending.values():
        for call in calls:
            app.store.add_message(session_id, "tool", {
                "tool_call_id": call["id"], "name": call["name"],
                "content": "Error: previous execution was interrupted before a result was saved. "
                           "Side effects are unknown; inspect state before retrying. This tool was not replayed.",
            })


def _tool_payload(tools) -> list[dict]:
    # request.ts sorts the tool record with localeCompare, then rebuilds a JS
    # object. Integer-index property names enumerate first even after that sort.
    by_name = {tool.name: tool for tool in tools}
    names = sorted(by_name, key=_locale_key)
    indices = [name for name in names if name.isascii() and name.isdecimal()
               and len(name) <= 10 and str(int(name)) == name and int(name) < 2 ** 32 - 1]
    index_set = set(indices)
    names = sorted(indices, key=int) + [name for name in names if name not in index_set]
    return [{"name": name, "description": by_name[name].description,
             "parameters": by_name[name].parameters} for name in names]


def _turn_budget(app, session: dict, deep_on: bool, auxiliary: bool) -> tuple[int, int] | None:
    """(max calls, remind before) for this turn of the person's: only in a general-mode task's own session with
    someone at the keyboard. Deep research has its own pause reviews, and in an unattended run nobody can say
    go on. Someone is at the keyboard unless every permission is approved by itself; app.supervised says so
    outright (a test run whose prompt files play that person). config "turn" may change the numbers."""
    supervised = getattr(app, "supervised", None)
    if supervised is None:
        supervised = not getattr(app.permissions, "auto", False)
    if deep_on or auxiliary or not supervised or session.get("parentID") is not None:
        return None
    turn = app.config.get("turn") if isinstance(app.config.get("turn"), dict) else {}
    return turn.get("max_calls", TURN_MAX_CALLS), turn.get("remind_before", TURN_REMIND_BEFORE)


def _budget_note(budget, step: int) -> str:
    """The host's word that the turn's calls are running out, from remind_before calls left; empty before."""
    if not budget:
        return ""
    limit, remind = budget
    left = limit - step - 1  # the calls that remain after this one; the last of them has no tools
    if left > remind or left <= 0:
        return ""
    return (f"回合額度（宿主計數，不是判斷）：這是使用者這一回合的第 {step + 1}/{limit} 次模型呼叫，之後還剩 {left} 次，"
            "最後一次不給工具。請收斂：整理目前查到的（附出處）、還不確定的、建議的下一步，在次數用完前回覆；"
            "使用者可以要你繼續。")


def _deep_tools(app, on: bool) -> list:
    """Deep research's tools while the task has it on, apart from those the folder's own tool files give."""
    installed = getattr(app, "deep", None)
    if not on or not installed:
        return []
    names = {tool.name for tool in app.extra_tools}
    return [tool for tool in installed.tools if tool.name not in names]


def _system(app, agent, model_id: str, provider_id: str, session_id: str | None = None, *,
            deep: bool = False) -> str:
    """The system prompt. With deep research on (opencode/deep.py) it adds deep research's instructions and
    skills, and the task's review skills; with it installed but off, one line says how to turn it on."""
    installed = getattr(app, "deep", None)
    parts = []
    if agent.prompt:
        parts.append(agent.prompt)
    else:
        parts.append(provider_prompt(model_id))
    parts.append(
        "\n".join(
            [
                f"You are powered by the model named {model_id}. The exact model ID is {provider_id}/{model_id}",
                "Here is some useful information about the environment you are running in:",
                "<env>",
                f"  Working directory: {app.directory}",
                f"  Workspace root folder: {app.worktree}",
                f"  Is directory a git repo: {'yes' if (app.worktree / '.git').exists() else 'no'}",
                f"  Platform: {__import__('sys').platform}",
                f"  Today's date: {__import__('datetime').date.today().strftime('%a %b %d %Y')}",
                "</env>",
            ]
        )
    )
    if agent.name not in {"title", "summary", "compaction"}:
        parts.append(LANGUAGE)
    instructions = render_instructions([*app.instructions, *(installed.instructions if deep and installed else [])])
    if instructions:
        parts.append(instructions)
    mcp = app.mcp.instructions()
    if mcp:
        parts.append(mcp)
    skills = render_skills({**app.skills, **(installed.skills if deep and installed else {})}, agent)
    if skills and agent.name not in {"title", "summary", "compaction"}:
        parts.append(skills)
    if installed and not deep and agent.name not in {"title", "summary", "compaction"}:
        parts.append(DEEP_HINT)
    if session_id and deep and agent.name not in {"title", "summary", "compaction"}:
        # Lessons a reviewer wrote between rounds of this task (opencode/round_review.py); the same all round.
        # A top session also gets them with its messages (_task_review), and the prompt says so.
        from opencode.task_skills import standing

        try:
            top = app.store.get_session(session_id).get("parentID") is None
        except KeyError:
            top = False
        parts.append(standing(app.store, session_id, installed_skills(app), repeated=top))
    return "\n".join(part for part in parts if part)


def _previous_agent_was_plan(app, session_id: str) -> bool:
    for message in reversed(app.store.messages(session_id)):
        if message.get("role") == "assistant":
            return message.get("agent") == "plan"
    return False


def _save_reads(app, session_id: str, read_files: set[str], turn: int) -> None:
    meta = dict(app.store.get_session(session_id).get("meta") or {})
    meta["read_files"] = sorted(read_files)
    meta["turn"] = turn
    app.store.update_session(session_id, meta=meta)


def _title(app, session_id: str, text: str, provider, model_id: str) -> None:
    abort = app.abort_event(session_id)
    session = app.store.get_session(session_id)
    if session.get("parentID") or session.get("title"):
        return
    history = app.store.context_messages(session_id)
    humans = [m for m in history if m.get("role") == "user" and not m.get("synthetic")]
    if len(humans) != 1:
        return
    context = history[:history.index(humans[0]) + 1]

    def worker():
        try:
            title_agent = app.agents.get("title")
            if title_agent is None:
                return
            title_provider, title_model = app.provider.resolve(title_agent.model) if title_agent.model else (provider, model_id)
            completion = app.provider.complete(
                provider=title_provider,
                model=title_model,
                system=title_agent.prompt or "",
                messages=[{"role": "user", "content": "Generate a title for this conversation:\n"},
                          *openai_messages_from_history(context, model_ref=f"{title_provider.id}/{title_model}")],
                tools=None,
                temperature=title_agent.temperature,
                abort_event=abort,
            )
            cleaned = re.sub(r"<think>[\s\S]*?</think>\s*", "", completion.text or "")
            title = next((line.strip() for line in cleaned.splitlines() if line.strip()), "")
            if len(title) > 100:
                title = title[:97] + "..."
            if title and not abort.is_set():
                app.store.update_session(session_id, title=title)
                app.bus.publish("session.updated", {"sessionID": session_id, "title": title})
        except Exception:
            return

    threading.Thread(target=worker, daemon=True).start()


def _maybe_compact(app, session_id: str, history: list[dict], provider, model_id: str, **kwargs) -> None:
    compact(app, session_id, history, provider, model_id, **kwargs)
