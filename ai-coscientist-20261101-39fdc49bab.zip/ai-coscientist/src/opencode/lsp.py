"""Minimal LSP client over stdio (Content-Length framing)."""

from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time
from pathlib import Path
from shutil import which
from urllib.parse import urljoin, urlparse
from urllib.request import pathname2url, url2pathname
from opencode import executor


class LspError(RuntimeError):
    pass


def _check_abort(abort_event) -> None:
    if abort_event is not None and abort_event.is_set():
        raise LspError("aborted")


def _uri(path: Path) -> str:
    return urljoin("file:", pathname2url(str(path.resolve())))


class LspClient:
    def __init__(self, command: list[str], root: Path, *, env: dict | None = None, initialization: dict | None = None, timeout: float = 45.0):
        self.command = command
        self.root = root
        self.env = env or {}
        self.initialization = initialization or {}
        self.timeout = timeout
        self.process: subprocess.Popen | None = None
        self._lock = threading.Lock()
        self._write_lock = threading.Lock()
        self._pending: dict[int, queue.Queue] = {}
        self._id = 0
        self._opened: dict[str, tuple[int, str]] = {}
        self._sync_kind = None
        self._diagnostic_condition = threading.Condition()
        self._push_diagnostics: dict[str, list[dict]] = {}
        self._pull_diagnostics: dict[str, list[dict]] = {}
        self._published: dict[str, tuple[float, int | None]] = {}
        self._diagnostic_registrations: dict[str, dict] = {}
        self._diagnostic_generation = 0
        self._static_diagnostics = False

    def start(self, *, abort_event=None) -> None:
        _check_abort(abort_event)
        if self.process and self.process.poll() is None:
            return
        self.process = executor.spawn(
            self.command, executor.Launch("server", "lsp"),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            cwd=self.root,
            env={**os.environ, **self.env},
            bufsize=0,
        )
        self._opened.clear()
        self._push_diagnostics.clear()
        self._pull_diagnostics.clear()
        self._published.clear()
        self._diagnostic_registrations.clear()
        process = self.process

        def pump():
            try:
                while True:
                    payload = _read(process.stdout)
                    if "method" in payload:
                        if "id" not in payload and payload["method"] == "textDocument/publishDiagnostics":
                            self._publish_diagnostics(payload.get("params") or {})
                        continue
                    with self._lock:
                        pending = self._pending.get(payload.get("id"))
                    if pending:
                        pending.put(payload)
            except Exception as exc:
                with self._lock:
                    pending = list(self._pending.values())
                for box in pending:
                    box.put(exc)

        threading.Thread(target=pump, daemon=True).start()
        try:
            self._initialize(abort_event=abort_event)
        except Exception:
            self.stop()
            raise

    def _initialize(self, *, abort_event=None) -> None:
        initialized = self.request(
            "initialize",
            {
                "processId": self.process.pid,
                "rootUri": _uri(self.root),
                "initializationOptions": self.initialization,
                "capabilities": {
                    "textDocument": {
                        "hover": {"contentFormat": ["plaintext", "markdown"]},
                        "definition": {},
                        "references": {},
                        "documentSymbol": {},
                        "callHierarchy": {},
                    },
                    "workspace": {"symbol": {}},
                },
                "workspaceFolders": [{"uri": _uri(self.root), "name": self.root.name}],
            },
            abort_event=abort_event,
        )
        sync = ((initialized or {}).get("capabilities") or {}).get("textDocumentSync")
        self._sync_kind = sync.get("change") if isinstance(sync, dict) else sync
        diagnostic_provider = ((initialized or {}).get("capabilities") or {}).get("diagnosticProvider")
        self._static_diagnostics = diagnostic_provider is not None and diagnostic_provider is not False
        self.notify("initialized", {})

    def open_file(self, path: Path) -> int:
        key = str(path.resolve())
        text = path.read_text(encoding="utf-8", errors="replace")
        previous = self._opened.get(key)
        if previous:
            return previous[0]
        language = {
            ".py": "python",
            ".ts": "typescript",
            ".tsx": "typescriptreact",
            ".js": "javascript",
            ".jsx": "javascriptreact",
            ".go": "go",
            ".rs": "rust",
            ".json": "json",
        }.get(path.suffix.lower(), "plaintext")
        with self._diagnostic_condition:
            self._push_diagnostics.pop(key, None)
            self._pull_diagnostics.pop(key, None)
        self.notify(
            "textDocument/didOpen",
            {"textDocument": {"uri": _uri(path), "languageId": language, "version": 0, "text": text}},
        )
        self._opened[key] = (0, text)
        return 0

    def _publish_diagnostics(self, params: dict) -> None:
        key = _file_path(params.get("uri", ""))
        if key is None:
            return
        with self._diagnostic_condition:
            self._push_diagnostics[key] = params.get("diagnostics") or []
            self._published[key] = (time.monotonic(), params.get("version"))
            self._diagnostic_condition.notify_all()

    @property
    def diagnostics(self) -> dict[str, list[dict]]:
        with self._diagnostic_condition:
            return {key: _dedupe_diagnostics(self._push_diagnostics.get(key, []) + self._pull_diagnostics.get(key, []))
                    for key in self._push_diagnostics.keys() | self._pull_diagnostics.keys()}

    def wait_for_diagnostics(self, path: Path, version: int, *, mode: str = "document", after: float | None = None, timeout: float | None = None, abort_event=None) -> None:
        _check_abort(abort_event)
        key = str(path.resolve())
        started = time.monotonic() if after is None else after
        limit = (10.0 if mode == "full" else 5.0) if timeout is None else timeout
        deadline = started + limit
        with self._diagnostic_condition:
            while time.monotonic() < deadline:
                _check_abort(abort_event)
                published = self._published.get(key)
                if published:
                    when, reported_version = published
                    fresh = (reported_version is None or reported_version == version) and (when >= started or reported_version == version)
                    if fresh and time.monotonic() - when >= 0.15:
                        return
                self._diagnostic_condition.wait(min(0.05, max(0, deadline - time.monotonic())))
        _check_abort(abort_event)

    def operation(self, operation: str, path: Path, line: int, character: int, query: str | None = None, *, abort_event=None):
        _check_abort(abort_event)
        started = time.monotonic()
        version = self.open_file(path)
        self.wait_for_diagnostics(path, version, after=started, abort_event=abort_event)
        position = {"line": line - 1, "character": character - 1}
        document = {"uri": _uri(path)}
        params = {"textDocument": document, "position": position}
        methods = {"goToDefinition": "textDocument/definition", "findReferences": "textDocument/references",
                   "hover": "textDocument/hover", "documentSymbol": "textDocument/documentSymbol",
                   "workspaceSymbol": "workspace/symbol", "goToImplementation": "textDocument/implementation",
                   "prepareCallHierarchy": "textDocument/prepareCallHierarchy"}
        if operation in {"incomingCalls", "outgoingCalls"}:
            return self.request("callHierarchy/" + operation, {"item": {"uri": _uri(path), "range": {"start": position, "end": position}, "name": "", "kind": 12}}, abort_event=abort_event)
        if operation == "findReferences":
            params = {**params, "context": {"includeDeclaration": True}}
        elif operation == "documentSymbol":
            params = {"textDocument": document}
        elif operation == "workspaceSymbol":
            params = {"query": query or ""}
        return self.request(methods[operation], params, abort_event=abort_event)

    def request(self, method: str, params: dict, *, timeout: float | None = None, close_on_timeout: bool = True, abort_event=None):
        _check_abort(abort_event)
        with self._lock:
            if self.process is None or self.process.poll() is not None or self.process.stdin is None or self.process.stdout is None:
                raise LspError("LSP server is not running")
            self._id += 1
            message_id = self._id
            message = {"jsonrpc": "2.0", "id": message_id, "method": method, "params": params}
            messages = queue.Queue()
            self._pending[message_id] = messages
        try:
            with self._write_lock:
                _check_abort(abort_event)
                _write(self.process.stdin, message)
            deadline = time.monotonic() + (self.timeout if timeout is None else timeout)
            while True:
                _check_abort(abort_event)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    if close_on_timeout:
                        self.stop()
                    raise LspError(f"LSP request timed out: {method}")
                try:
                    payload = messages.get(timeout=min(0.05, remaining) if abort_event is not None else remaining)
                except queue.Empty:
                    continue
                _check_abort(abort_event)
                if isinstance(payload, Exception):
                    self.stop()
                    raise payload
                if payload.get("id") == message_id:
                    if "error" in payload:
                        raise LspError(str(payload["error"]))
                    return payload.get("result")
        finally:
            with self._lock:
                self._pending.pop(message_id, None)

    def notify(self, method: str, params: dict) -> None:
        with self._write_lock:
            if self.process is None or self.process.stdin is None:
                raise LspError("LSP server is not running")
            _write(self.process.stdin, {"jsonrpc": "2.0", "method": method, "params": params})

    def stop(self) -> None:
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=2)
        if self.process:
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                if stream:
                    stream.close()


def _write(stream, payload: dict) -> None:
    raw = json.dumps(payload).encode("utf-8")
    stream.write(f"Content-Length: {len(raw)}\r\n\r\n".encode("ascii") + raw)
    stream.flush()


def _file_path(uri: str) -> str | None:
    parsed = urlparse(uri)
    if parsed.scheme != "file":
        return None
    path = ("//" + parsed.netloc if parsed.netloc else "") + parsed.path
    return str(Path(url2pathname(path)).resolve())


def _dedupe_diagnostics(items: list[dict]) -> list[dict]:
    seen = set()
    result = []
    for item in items:
        key = json.dumps({field: item.get(field) for field in ("code", "severity", "message", "source", "range")}, sort_keys=True)
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _read(stream) -> dict:
    headers = b""
    while b"\r\n\r\n" not in headers:
        chunk = stream.read(1)
        if not chunk:
            raise LspError("LSP server closed the stream")
        headers += chunk
        if len(headers) > 65536:
            raise LspError("LSP header too large")
    header_text, _ = headers.split(b"\r\n\r\n", 1)
    length = 0
    for line in header_text.decode("ascii", "replace").split("\r\n"):
        if line.lower().startswith("content-length:"):
            length = int(line.split(":", 1)[1].strip())
    body = b""
    while len(body) < length:
        chunk = stream.read(length - len(body))
        if not chunk:
            raise LspError("LSP response ended early")
        body += chunk
    return json.loads(body.decode("utf-8"))


def detect_command(path: Path, config: dict) -> list[str] | None:
    lsp = config.get("lsp")
    if lsp is False:
        return None
    if isinstance(lsp, dict):
        for name, spec in lsp.items():
            if not isinstance(spec, dict) or spec.get("disabled"):
                continue
            if isinstance(spec, dict) and spec.get("command"):
                extensions = spec.get("extensions")
                if extensions and path.suffix.lower() not in extensions:
                    continue
                command = spec["command"]
                return command if isinstance(command, list) else [command]
            if name == "pyright" and path.suffix.lower() == ".py":
                binary = which("pyright-langserver")
                if binary:
                    return [binary, "--stdio"]
    suffix = path.suffix.lower()
    if suffix == ".py":
        if isinstance(lsp, dict) and (lsp.get("pyright") or {}).get("disabled"):
            return None
        for candidate in (["pyright-langserver", "--stdio"], ["pylsp"]):
            if which(candidate[0]):
                return candidate
    if suffix in {".ts", ".tsx", ".js", ".jsx"}:
        if isinstance(lsp, dict) and (lsp.get("typescript") or {}).get("disabled"):
            return None
        binary = which("typescript-language-server")
        if binary:
            return [binary, "--stdio"]
    return None


def resolve_config(path: Path, config: dict) -> tuple[list[str] | None, dict, dict]:
    command = detect_command(path, config)
    if command is None:
        return None, {}, {}
    specifications = config.get("lsp")
    for name, spec in (specifications if isinstance(specifications, dict) else {}).items():
        if not isinstance(spec, dict) or spec.get("disabled"):
            continue
        extensions = spec.get("extensions")
        if extensions and path.suffix.lower() not in extensions:
            continue
        configured = spec.get("command")
        configured = [configured] if isinstance(configured, str) else configured
        builtin = (name == "pyright" and path.suffix.lower() == ".py") or (name == "typescript" and path.suffix.lower() in {".ts", ".tsx", ".js", ".jsx"})
        if configured == command or (configured is None and builtin):
            return command, dict(spec.get("env") or {}), dict(spec.get("initialization") or {})
    return command, {}, {}
