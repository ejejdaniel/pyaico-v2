"""Model Context Protocol client for local stdio servers and remote HTTP servers."""

from __future__ import annotations

import json
import os
import queue
import re
import subprocess
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path

import httpx

from opencode.lsp import LspError
from opencode.mcp_oauth import ClientRegistrationRequired, McpAuthStore, OAuthConfig, OAuthError, access_token_valid, obtain_token
from opencode.tools.types import Tool, ToolResult
from opencode.tools.util import _abort_event
from opencode import executor

PROTOCOL = "2024-11-05"


class Unauthorized(RuntimeError):
    def __init__(self, www_authenticate: str | None = None):
        super().__init__("MCP server returned 401")
        self.www_authenticate = www_authenticate


@dataclass
class McpServer:
    name: str
    command: list[str] = field(default_factory=list)
    cwd: str | None = None
    env: dict = field(default_factory=dict)
    timeout: float = 30
    url: str = ""
    headers: dict = field(default_factory=dict)
    oauth: object = None
    process: subprocess.Popen | None = None
    tools: list[dict] = field(default_factory=list)
    instructions: str = ""
    error: str = ""
    connected: bool = False
    _disabled: bool = False
    _needs_client_registration: bool = False
    needs_auth: bool = False
    auth_url: str = ""
    session_id: str | None = None
    _lock: threading.RLock = field(default_factory=threading.RLock)
    _messages: queue.Queue = field(default_factory=queue.Queue)
    _state_lock: threading.Lock = field(default_factory=threading.Lock)
    _generation: int = 0
    _supports_tools: bool = False
    _refresh_running: bool = False
    _refresh_pending: bool = False
    _id: int = 0
    _sse_post: str | None = None
    _sse_client: httpx.Client | None = None
    _notification_client: httpx.Client | None = None
    _http_pending: dict[int, queue.Queue] = field(default_factory=dict)
    _http_progress: dict[object, queue.Queue] = field(default_factory=dict)
    _http_clients: dict[int, httpx.Client] = field(default_factory=dict)

    def status(self) -> dict:
        if self._disabled:
            state = "disabled"
        elif self._needs_client_registration:
            state = "needs_client_registration"
        elif self.needs_auth:
            state = "needs_auth"
        elif self.error:
            state = "failed"
        elif self.connected:
            state = "connected"
        else:
            state = "disconnected"
        return {
            "name": self.name,
            "status": state,
            "error": self.error,
            "authorizationUrl": self.auth_url,
            "tools": [_tool_name(self.name, tool.get("name") or "tool") for tool in self.tools],
        }


class McpHub:
    def __init__(self, config: dict, directory: Path, *, auth_store: McpAuthStore | None = None):
        self.directory = directory
        self.servers: dict[str, McpServer] = {}
        self.auth_store = auth_store or McpAuthStore()
        self.interactive = False
        raw = config.get("mcp") or {}
        if not isinstance(raw, dict):
            return
        timeout_ms = ((config.get("experimental") or {}).get("mcp_timeout")) or 30000
        for name, spec in raw.items():
            if not isinstance(spec, dict):
                continue
            if spec.get("enabled") is False:
                self.servers[name] = McpServer(name=name, _disabled=True)
                continue
            timeout = int(spec.get("timeout") or timeout_ms) / 1000
            if spec.get("type") == "remote" or spec.get("url"):
                self.servers[name] = McpServer(
                    name=name,
                    url=str(spec.get("url") or ""),
                    headers={str(key): str(value) for key, value in (spec.get("headers") or {}).items()},
                    oauth=spec.get("oauth", True),
                    timeout=timeout,
                )
                continue
            command = spec.get("command") or []
            if isinstance(command, str):
                command = [command]
            if not command:
                continue
            cwd = spec.get("cwd") or str(directory)
            if cwd and not Path(cwd).is_absolute():
                cwd = str(directory / cwd)
            self.servers[name] = McpServer(
                name=name,
                command=list(command),
                cwd=cwd,
                env=dict(spec.get("environment") or {}),
                timeout=timeout,
            )

    def connect_all(self) -> None:
        for server in self.servers.values():
            if server._disabled:
                continue
            if server.url:
                self.connect_remote(server)
            elif server.command:
                self.connect(server)

    def connect(self, server: McpServer) -> None:
        try:
            self._close(server)
            server._messages = queue.Queue()
            env = os.environ.copy()
            env.update(server.env)
            server.process = executor.spawn(
                server.command, executor.Launch("server", "mcp"),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                cwd=server.cwd,
                env=env,
                bufsize=0,
            )
            stream = server.process.stdout
            messages = server._messages
            generation = server._generation

            def pump():
                try:
                    while True:
                        line = stream.readline()
                        if not line:
                            raise LspError("MCP server closed the stream")
                        if line.strip():
                            payload = json.loads(line)
                            if not self._handle_notification(server, payload, generation):
                                messages.put(payload)
                except Exception as exc:
                    messages.put(exc)
                    self._connection_closed(server, generation)

            threading.Thread(target=pump, daemon=True).start()
            self._finish_initialize(server, self._rpc, self._notify)
        except Exception as exc:
            server.error = str(exc)
            self._close(server)

    def connect_remote(self, server: McpServer, *, opener=None) -> None:
        self._close(server)
        server._needs_client_registration = False
        try:
            token = self._bearer(server, opener=opener)
            self._remote_initialize(server, token)
        except Unauthorized as exc:
            self._close(server)
            if server.oauth is False:
                server.error = "Unauthorized"
                server.connected = False
                return
            if not self.interactive and opener is None:
                server.needs_auth = True
                server.connected = False
                server.error = f"Authentication required. Run: opencode mcp auth {server.name}"
                server.auth_url = ""
                _ = exc
                return
            try:
                token = self._bearer(server, opener=opener, force=True, www_authenticate=exc.www_authenticate)
                self._remote_initialize(server, token)
            except Exception as auth_error:
                server.error = str(auth_error)
                self._close(server)
                server.needs_auth = True
                if isinstance(auth_error, ClientRegistrationRequired) or "registration" in str(auth_error) or "client_id" in str(auth_error):
                    server._needs_client_registration = True
                    server.error = "Server does not support dynamic client registration. Please provide clientId in config."
        except Exception as exc:
            server.error = str(exc)
            self._close(server)

    def authenticate(self, name: str, *, opener=None, block: bool = True) -> str:
        server = self.servers.get(name)
        if server is None or not server.url:
            raise KeyError(name)
        self.interactive = True
        if block:
            self.connect_remote(server, opener=opener)
            if server.error and not server.connected:
                raise OAuthError(server.error)
            return server.auth_url
        box: dict = {}
        ready = threading.Event()

        def capture(url: str) -> None:
            box["url"] = url
            server.auth_url = url
            ready.set()
            if opener:
                opener(url)

        def worker():
            try:
                self.connect_remote(server, opener=capture)
                box["ok"] = server.connected
                box["error"] = server.error
            except Exception as exc:
                box["error"] = str(exc)
            finally:
                ready.set()

        threading.Thread(target=worker, daemon=True).start()
        ready.wait(30)
        return box.get("url") or server.auth_url

    def tool_specs(self) -> list[Tool]:
        specs: list[Tool] = []
        for server in self.servers.values():
            if not server.connected:
                continue
            for tool in server.tools:
                name = tool.get("name") or "tool"
                exposed = _tool_name(server.name, name)
                description = tool.get("description") or f"MCP tool {name} from {server.name}"
                parameters = tool.get("inputSchema") or {"type": "object", "properties": {}}
                specs.append(Tool(exposed, description, parameters, _caller(server, name, self)))
        return specs

    def instructions(self) -> str:
        blocks = []
        for server in self.servers.values():
            if not server.connected or not server.instructions:
                continue
            blocks.append(f'<server name="{server.name}">\n{server.instructions}\n</server>')
        if not blocks:
            return ""
        return "<mcp_instructions>\n" + "\n".join(blocks) + "\n</mcp_instructions>"

    def call(self, server: McpServer, name: str, arguments: dict, *, abort_event=None) -> tuple[str, list[dict]]:
        if server.url:
            result = self._remote_rpc(server, "tools/call", {"name": name, "arguments": arguments or {}}, abort_event=abort_event)
        else:
            result = self._rpc(server, "tools/call", {"name": name, "arguments": arguments or {}}, abort_event=abort_event)
        return _project_result(result)

    def _bearer(self, server: McpServer, *, opener=None, force: bool = False, www_authenticate: str | None = None) -> str | None:
        if server.oauth is False:
            return None
        entry = self.auth_store.get(server.name, server.url) or {}
        tokens = dict(entry.get("tokens") or {})
        if not force and access_token_valid(tokens):
            return tokens["accessToken"]
        if not force and tokens.get("refreshToken"):
            try:
                return obtain_token(server.url, server.name, OAuthConfig.from_value(server.oauth), self.auth_store, interactive=False)
            except OAuthError:
                return None
        if not force:
            return None
        if not self.interactive and opener is None:
            return None
        tokens.pop("accessToken", None)
        self.auth_store.update(server.name, tokens=tokens, serverUrl=server.url)
        return obtain_token(
            server.url,
            server.name,
            OAuthConfig.from_value(server.oauth),
            self.auth_store,
            opener=opener,
            www_authenticate=www_authenticate,
        )

    def _finish_initialize(self, server: McpServer, rpc, notify) -> None:
        init = rpc(
            server,
            "initialize",
            {
                "protocolVersion": PROTOCOL,
                "capabilities": {},
                "clientInfo": {"name": "opencode-python", "version": "1.18.9"},
            },
        )
        server.instructions = (((init or {}).get("instructions")) or "").strip()
        notify(server, "notifications/initialized", {})
        server._supports_tools = "tools" in ((init or {}).get("capabilities") or {})
        server.tools = self._list_tools(server, rpc) if server._supports_tools else []
        server.error = ""
        server.connected = True
        server.needs_auth = False
        server._needs_client_registration = False

    def _list_tools(self, server: McpServer, rpc) -> list[dict]:
        listed = rpc(server, "tools/list", {}) or {}
        return listed.get("tools") or []

    def _handle_notification(self, server: McpServer, payload: dict, generation: int) -> bool:
        if payload.get("method") != "notifications/tools/list_changed" or "id" in payload:
            return False
        with server._state_lock:
            if generation != server._generation or not server.connected or not server._supports_tools:
                return True
            server._refresh_pending = True
            if server._refresh_running:
                return True
            server._refresh_running = True

        def refresh():
            while True:
                with server._state_lock:
                    if generation != server._generation:
                        return
                    if not server.connected or not server._refresh_pending:
                        server._refresh_running = False
                        return
                    server._refresh_pending = False
                try:
                    with server._lock:
                        listed = self._list_tools(server, self._remote_rpc if server.url else self._rpc)
                    with server._state_lock:
                        if generation == server._generation and server.connected:
                            server.tools = listed
                except Exception:
                    # Upstream retains the last accepted catalog when refresh fails.
                    pass

        threading.Thread(target=refresh, daemon=True).start()
        return True

    def _connection_closed(self, server: McpServer, generation: int) -> None:
        with server._state_lock:
            if generation != server._generation or not server.connected:
                return
            server.connected = False
            server.error = "Connection closed"
            server.tools = []
            server.instructions = ""

    def _remote_initialize(self, server: McpServer, token: str | None) -> None:
        server._token = token

        def rpc(target, method, params):
            return self._remote_rpc(target, method, params)

        def notify(target, method, params):
            self._remote_notify(target, method, params)

        try:
            self._finish_initialize(server, rpc, notify)
        except Unauthorized:
            raise
        except Exception:
            self._close(server)
            self._open_sse(server, token)
            self._finish_initialize(server, rpc, notify)
        if not server._sse_post:
            self._start_http_notifications(server, token)

    def _remote_rpc(self, server: McpServer, method: str, params: dict, *, abort_event=None):
        with _request_lock(server._lock, abort_event):
            token = getattr(server, "_token", None)
            if server._sse_post:
                return self._sse_rpc(server, method, params, token, abort_event=abort_event)
            return self._http_rpc(server, method, params, token, abort_event=abort_event)

    def _remote_notify(self, server: McpServer, method: str, params: dict) -> None:
        token = getattr(server, "_token", None)
        body = {"jsonrpc": "2.0", "method": method, "params": params}
        url = server._sse_post or server.url
        with httpx.Client(timeout=server.timeout) as client:
            response = client.post(url, headers=self._http_headers(server, token), json=body)
        if response.status_code == 401:
            raise Unauthorized(response.headers.get("www-authenticate"))
        response.raise_for_status()

    def _http_rpc(self, server: McpServer, method: str, params: dict, token: str | None, *, abort_event=None):
        _check_abort(abort_event)
        server._id += 1
        message_id = server._id
        body = _request_message(message_id, method, params)
        messages = queue.Queue()
        client = httpx.Client(timeout=server.timeout)
        generation = server._generation
        progress_token = (params.get("_meta") or {}).get("progressToken")
        with server._state_lock:
            server._http_pending[message_id] = messages
            server._http_clients[message_id] = client
            if progress_token is not None:
                server._http_progress[progress_token] = messages

        def receive():
            try:
                with client.stream("POST", server.url, headers=self._http_headers(server, token), json=body) as response:
                    if response.status_code == 401:
                        raise Unauthorized(response.headers.get("www-authenticate"))
                    response.raise_for_status()
                    session = response.headers.get("mcp-session-id")
                    if session and generation == server._generation:
                        server.session_id = session
                    if "text/event-stream" in response.headers.get("content-type", ""):
                        for _, data in _iter_sse(response):
                            try:
                                payload = json.loads(data)
                            except json.JSONDecodeError:
                                continue
                            if not self._handle_notification(server, payload, generation):
                                messages.put(payload)
                            if payload.get("id") == message_id and "method" not in payload:
                                return
                        raise LspError("MCP event stream did not include a JSON-RPC response")
                    response.read()
                    messages.put(response.json())
            except Exception as exc:
                messages.put(exc)

        thread = threading.Thread(target=receive, daemon=True)
        thread.start()
        try:
            return self._await_response(server, messages, message_id, method, progress_token=(params.get("_meta") or {}).get("progressToken"), abort_event=abort_event)
        finally:
            with server._state_lock:
                server._http_pending.pop(message_id, None)
                server._http_clients.pop(message_id, None)
                if progress_token is not None:
                    server._http_progress.pop(progress_token, None)
            client.close()
            thread.join(timeout=1)

    def _start_http_notifications(self, server: McpServer, token: str | None) -> None:
        """The optional Streamable HTTP GET stream carries notifications while idle."""
        client = httpx.Client(timeout=server.timeout)
        server._notification_client = client
        generation = server._generation

        def receive():
            try:
                with client.stream("GET", server.url, headers={**self._http_headers(server, token), "Accept": "text/event-stream"}) as response:
                    if response.status_code == 405:
                        return
                    response.raise_for_status()
                    if "text/event-stream" not in response.headers.get("content-type", ""):
                        return
                    # Header acquisition is bounded; a notification stream may then remain idle.
                    response.request.extensions["timeout"]["read"] = None
                    for _, data in _iter_sse(response):
                        if generation != server._generation:
                            return
                        try:
                            payload = json.loads(data)
                        except json.JSONDecodeError:
                            continue
                        if self._handle_notification(server, payload, generation):
                            continue
                        message_id = ((payload.get("params") or {}).get("progressToken")
                                      if payload.get("method") == "notifications/progress" else payload.get("id"))
                        with server._state_lock:
                            pending = (server._http_progress if payload.get("method") == "notifications/progress" else server._http_pending).get(message_id)
                        if pending:
                            pending.put(payload)
            except (httpx.HTTPError, OSError, RuntimeError):
                # A server may omit this optional transport; POST requests remain usable.
                pass
            finally:
                client.close()
                if server._notification_client is client:
                    server._notification_client = None

        threading.Thread(target=receive, daemon=True).start()

    def _open_sse(self, server: McpServer, token: str | None) -> None:
        client = httpx.Client(timeout=server.timeout)
        request = client.build_request("GET", server.url, headers={**self._http_headers(server, token), "Accept": "text/event-stream"})
        try:
            response = client.send(request, stream=True)
            if response.status_code == 401:
                raise Unauthorized(response.headers.get("www-authenticate"))
            response.raise_for_status()
            request.extensions["timeout"]["read"] = None
            events = _iter_sse(response)
        except Exception:
            client.close()
            raise
        server._sse_client = client
        server._sse_response = response
        generation = server._generation
        messages = server._messages
        ready = threading.Event()
        handshake = {}

        def pump():
            try:
                for event, data in events:
                    if event == "endpoint":
                        endpoint = data.strip()
                        server._sse_post = endpoint if endpoint.startswith("http") else _join_url(server.url, endpoint)
                        ready.set()
                        continue
                    if event in {"message", ""} and data:
                        try:
                            payload = json.loads(data)
                            if not self._handle_notification(server, payload, generation):
                                messages.put(payload)
                        except json.JSONDecodeError:
                            continue
            except (httpx.HTTPError, OSError) as exc:
                messages.put(exc)
                handshake["error"] = exc
            finally:
                ready.set()
                self._connection_closed(server, generation)

        threading.Thread(target=pump, daemon=True).start()
        if not ready.wait(server.timeout) or not server._sse_post:
            client.close()
            raise LspError("SSE MCP server did not send an endpoint") from handshake.get("error")

    def _sse_rpc(self, server: McpServer, method: str, params: dict, token: str | None, *, abort_event=None):
        _check_abort(abort_event)
        server._id += 1
        message_id = server._id
        body = _request_message(message_id, method, params)
        posted = queue.Queue()
        client = httpx.Client(timeout=server.timeout)

        def send():
            try:
                response = client.post(server._sse_post, headers=self._http_headers(server, token), json=body)
                if response.status_code == 401:
                    raise Unauthorized(response.headers.get("www-authenticate"))
                response.raise_for_status()
                posted.put(None)
            except Exception as exc:
                posted.put(exc)

        thread = threading.Thread(target=send, daemon=True)
        thread.start()
        try:
            result = _wait_message(posted, time_after(server.timeout), abort_event, method)
            if isinstance(result, Exception):
                raise result
            return self._await_response(server, server._messages, message_id, method, progress_token=(params.get("_meta") or {}).get("progressToken"), abort_event=abort_event)
        finally:
            # This POST belongs to one request; the shared SSE stream stays open.
            client.close()
            thread.join(timeout=1)

    def _http_headers(self, server: McpServer, token: str | None) -> dict:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": PROTOCOL,
        }
        headers.update(server.headers)
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if server.session_id:
            headers["Mcp-Session-Id"] = server.session_id
        return headers

    def _rpc(self, server: McpServer, method: str, params: dict, *, abort_event=None):
        with _request_lock(server._lock, abort_event):
            if server.process is None or server.process.stdin is None or server.process.stdout is None:
                raise LspError("MCP server is not running")
            server._id += 1
            message_id = server._id
            _write_stdio(server.process.stdin, _request_message(message_id, method, params))
            return self._await_response(server, server._messages, message_id, method, progress_token=(params.get("_meta") or {}).get("progressToken"), abort_event=abort_event)

    def _await_response(self, server: McpServer, messages: queue.Queue, message_id: int, method: str, *, progress_token=None, abort_event=None):
        deadline = time_after(server.timeout)
        while True:
            payload = _wait_message(messages, deadline, abort_event, method)
            if isinstance(payload, Exception):
                raise payload
            if "method" in payload:
                if (progress_token is not None and method == "tools/call" and payload.get("method") == "notifications/progress"
                        and (payload.get("params") or {}).get("progressToken") == progress_token):
                    deadline = time_after(server.timeout)
                continue
            if payload.get("id") != message_id:
                continue
            if "error" in payload:
                raise LspError(json.dumps(payload["error"]))
            return payload.get("result")

    def _notify(self, server: McpServer, method: str, params: dict) -> None:
        with server._lock:
            if server.process is None or server.process.stdin is None:
                return
            _write_stdio(server.process.stdin, {"jsonrpc": "2.0", "method": method, "params": params})

    def _close(self, server: McpServer) -> None:
        with server._state_lock:
            server._generation += 1
            server._refresh_running = False
            server._refresh_pending = False
            pending = list(server._http_pending.values())
            clients = list(server._http_clients.values())
            server._http_pending.clear()
            server._http_progress.clear()
            server._http_clients.clear()
        for messages in pending:
            messages.put(LspError("MCP connection closed"))
        for client in clients:
            client.close()
        server.connected = False
        server.tools = []
        server.instructions = ""
        process = server.process
        if process is not None:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
            for stream in (process.stdin, process.stdout, process.stderr):
                if stream:
                    stream.close()
        if server._sse_client:
            server._sse_client.close()
            server._sse_client = None
        if server._notification_client:
            server._notification_client.close()
            server._notification_client = None
        server._sse_post = None
        server.session_id = None
        server._messages = queue.Queue()

    def close(self) -> None:
        for server in self.servers.values():
            self._close(server)


def _write_stdio(stream, payload: dict) -> None:
    stream.write(json.dumps(payload, separators=(",", ":")).encode("utf-8") + b"\n")
    stream.flush()


def _check_abort(abort_event) -> None:
    if abort_event is not None and abort_event.is_set():
        raise LspError("aborted")


@contextmanager
def _request_lock(lock, abort_event):
    while True:
        _check_abort(abort_event)
        if lock.acquire(timeout=0.05):
            break
    try:
        _check_abort(abort_event)
        yield
    finally:
        lock.release()


def _wait_message(messages, deadline, abort_event, method):
    while True:
        _check_abort(abort_event)
        remaining = deadline - time_after(0)
        if remaining <= 0:
            raise LspError(f"MCP request timed out: {method}")
        try:
            payload = messages.get(timeout=min(0.05, remaining) if abort_event is not None else remaining)
        except queue.Empty:
            continue
        _check_abort(abort_event)
        return payload


def _request_message(message_id: int, method: str, params: dict) -> dict:
    return {"jsonrpc": "2.0", "id": message_id, "method": method, "params": params}


def _tool_name(server: str, tool: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]", "_", server) + "_" + re.sub(r"[^a-zA-Z0-9_-]", "_", tool)


def _project_result(result) -> tuple[str, list[dict]]:
    content = (result or {}).get("content") or []
    if not content and (result or {}).get("structuredContent") is not None:
        content = [{"type": "text", "text": json.dumps(result["structuredContent"], ensure_ascii=False, separators=(",", ":"))}]
    texts = []
    attachments = []
    for block in content:
        if isinstance(block, str):
            texts.append(block)
            continue
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text":
            texts.append(block.get("text") or "")
        elif block.get("type") == "image" and block.get("data"):
            mime = block.get("mimeType") or "image/png"
            attachments.append({"mime": mime, "url": f"data:{mime};base64,{block['data']}"})
            texts.append(f"[image {mime}]")
    if not texts and not attachments:
        texts.append(json.dumps(result))
    if (result or {}).get("isError"):
        raise RuntimeError("\n".join(texts))
    return "\n".join(texts), attachments


def _caller(server: McpServer, name: str, hub: McpHub):
    def execute(args: dict, ctx) -> ToolResult:
        abort_event = _abort_event(ctx)
        ctx.app.permissions.ask(
            session_id=ctx.session_id,
            permission=_tool_name(server.name, name),
            patterns=["*"],
            ruleset=ctx.agent.permission,
            always=["*"],
            metadata={"server": server.name},
            abort_event=abort_event,
        )
        output, attachments = hub.call(server, name, args, abort_event=abort_event)
        return ToolResult(title=f"{server.name}/{name}", output=output, attachments=attachments)

    return execute


def _sse_json(body: str, message_id: int) -> dict:
    found = None
    for event, data in _iter_sse_text(body):
        if not data:
            continue
        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            continue
        if payload.get("id") == message_id and "method" not in payload:
            found = payload
        _ = event
    if found is None:
        raise LspError("MCP event stream did not include a JSON-RPC response")
    return found


def _iter_sse(response: httpx.Response):
    event = "message"
    data_lines: list[str] = []
    for line in response.iter_lines():
        if line == "":
            if data_lines:
                yield event, "\n".join(data_lines)
            event = "message"
            data_lines = []
            continue
        if line.startswith("event:"):
            event = line[len("event:") :].strip()
        elif line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())
    if data_lines:
        yield event, "\n".join(data_lines)


def _iter_sse_text(body: str):
    event = "message"
    data_lines: list[str] = []
    for line in body.splitlines():
        if line == "":
            if data_lines:
                yield event, "\n".join(data_lines)
            event = "message"
            data_lines = []
            continue
        if line.startswith("event:"):
            event = line[len("event:") :].strip()
        elif line.startswith("data:"):
            data_lines.append(line[len("data:") :].lstrip())
    if data_lines:
        yield event, "\n".join(data_lines)


def _join_url(base: str, endpoint: str) -> str:
    from urllib.parse import urljoin

    return urljoin(base if base.endswith("/") else base + "/", endpoint)


def time_after(seconds: float) -> float:
    import time

    return time.monotonic() + seconds
