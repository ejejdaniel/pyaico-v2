"""OAuth 2.1 for remote MCP servers: discovery, PKCE, dynamic registration, and a localhost callback."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import threading
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import httpx

from opencode.paths import data_dir

OAUTH_CALLBACK_PORT = 19876
OAUTH_CALLBACK_PATH = "/mcp/oauth/callback"
CALLBACK_TIMEOUT = 300


class OAuthError(RuntimeError):
    pass


class ClientRegistrationRequired(OAuthError):
    pass


@dataclass
class OAuthConfig:
    client_id: str | None = None
    client_secret: str | None = None
    scope: str | None = None
    callback_port: int | None = None
    redirect_uri: str | None = None

    @classmethod
    def from_value(cls, value) -> "OAuthConfig":
        if not isinstance(value, dict):
            return cls()
        return cls(
            client_id=value.get("clientId") or value.get("client_id"),
            client_secret=value.get("clientSecret") or value.get("client_secret"),
            scope=value.get("scope"),
            callback_port=value.get("callbackPort") or value.get("callback_port"),
            redirect_uri=value.get("redirectUri") or value.get("redirect_uri"),
        )


class McpAuthStore:
    def __init__(self, path: Path | None = None):
        self.path = path or (data_dir() / "mcp-auth.json")
        self._lock = threading.Lock()

    def _read(self) -> dict:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write(self, data: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self.path.chmod(0o600)
        descriptor = os.open(self.path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2)

    def get(self, name: str, server_url: str | None = None) -> dict | None:
        with self._lock:
            entry = self._read().get(name)
        if not isinstance(entry, dict):
            return None
        if server_url and entry.get("serverUrl") != server_url:
            return None
        return entry

    def update(self, name: str, **fields) -> dict:
        with self._lock:
            data = self._read()
            entry = dict(data.get(name) or {})
            entry.update(fields)
            data[name] = entry
            self._write(data)
            return entry

    def remove(self, name: str) -> None:
        with self._lock:
            data = self._read()
            data.pop(name, None)
            self._write(data)


def pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")
    return verifier, challenge


def parse_www_authenticate(header: str | None) -> str | None:
    if not header:
        return None
    for key in ("resource_metadata", "resource-metadata"):
        match = re.search(rf'{key}="([^"]+)"', header, re.I)
        if match:
            return match.group(1)
    return None


def _origin(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}"


def discover(client: httpx.Client, server_url: str, www_authenticate: str | None = None) -> dict:
    metadata_url = parse_www_authenticate(www_authenticate)
    candidates = []
    if metadata_url:
        candidates.append(metadata_url)
    origin = _origin(server_url)
    path = urllib.parse.urlparse(server_url).path.rstrip("/")
    candidates.append(f"{origin}/.well-known/oauth-protected-resource{path}")
    candidates.append(f"{origin}/.well-known/oauth-protected-resource")
    resource = None
    last_error = "OAuth protected resource metadata was not found"
    for candidate in candidates:
        try:
            response = client.get(candidate, headers={"Accept": "application/json"})
        except httpx.HTTPError as exc:
            last_error = str(exc)
            continue
        if response.status_code >= 400:
            last_error = f"{candidate} returned {response.status_code}"
            continue
        try:
            resource = response.json()
        except json.JSONDecodeError:
            continue
        if isinstance(resource, dict) and resource.get("authorization_servers"):
            break
        resource = None
    if not resource:
        raise OAuthError(last_error)
    issuer = resource["authorization_servers"][0].rstrip("/")
    auth_meta = None
    for candidate in (
        f"{issuer}/.well-known/oauth-authorization-server",
        f"{issuer}/.well-known/openid-configuration",
    ):
        response = client.get(candidate, headers={"Accept": "application/json"})
        if response.status_code >= 400:
            continue
        try:
            auth_meta = response.json()
        except json.JSONDecodeError:
            continue
        if isinstance(auth_meta, dict) and auth_meta.get("authorization_endpoint") and auth_meta.get("token_endpoint"):
            break
        auth_meta = None
    if not auth_meta:
        raise OAuthError(f"Authorization server metadata was not found for {issuer}")
    scopes = resource.get("scopes_supported") or []
    return {
        "resource": resource.get("resource") or server_url,
        "issuer": issuer,
        "authorization_endpoint": auth_meta["authorization_endpoint"],
        "token_endpoint": auth_meta["token_endpoint"],
        "registration_endpoint": auth_meta.get("registration_endpoint"),
        "scope": " ".join(scopes) if isinstance(scopes, list) else str(scopes or ""),
    }


def register_client(client: httpx.Client, registration_endpoint: str, redirect_uri: str, scope: str | None) -> dict:
    body = {
        "redirect_uris": [redirect_uri],
        "client_name": "OpenCode",
        "client_uri": "https://opencode.ai",
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "none",
    }
    if scope:
        body["scope"] = scope
    response = client.post(registration_endpoint, json=body, headers={"Accept": "application/json"})
    if response.status_code >= 400:
        raise OAuthError(f"Dynamic client registration failed ({response.status_code}): {response.text[:500]}")
    data = response.json()
    if not data.get("client_id"):
        raise OAuthError("Dynamic client registration did not return client_id")
    return data


def authorization_url(
    endpoint: str,
    *,
    client_id: str,
    redirect_uri: str,
    code_challenge: str,
    state: str,
    resource: str,
    scope: str | None,
) -> str:
    query = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
        "resource": resource,
    }
    if scope:
        query["scope"] = scope
    return endpoint + ("&" if "?" in endpoint else "?") + urllib.parse.urlencode(query)


def exchange_code(
    client: httpx.Client,
    token_endpoint: str,
    *,
    code: str,
    redirect_uri: str,
    client_id: str,
    code_verifier: str,
    resource: str,
    client_secret: str | None = None,
) -> dict:
    form = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri,
        "client_id": client_id,
        "code_verifier": code_verifier,
        "resource": resource,
    }
    if client_secret:
        form["client_secret"] = client_secret
    return _token_request(client, token_endpoint, form)


def refresh_tokens(
    client: httpx.Client,
    token_endpoint: str,
    *,
    refresh_token: str,
    client_id: str,
    resource: str,
    client_secret: str | None = None,
) -> dict:
    form = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": client_id,
        "resource": resource,
    }
    if client_secret:
        form["client_secret"] = client_secret
    return _token_request(client, token_endpoint, form)


def _token_request(client: httpx.Client, token_endpoint: str, form: dict) -> dict:
    response = client.post(token_endpoint, data=form, headers={"Accept": "application/json"})
    if response.status_code >= 400:
        raise OAuthError(f"Token request failed ({response.status_code}): {response.text[:500]}")
    data = response.json()
    if not data.get("access_token"):
        raise OAuthError("Token response did not include access_token")
    return data


def tokens_from_response(data: dict, previous: dict | None = None) -> dict:
    expires_in = data.get("expires_in")
    refresh = data.get("refresh_token") or (previous or {}).get("refreshToken")
    return {
        "accessToken": data["access_token"],
        "refreshToken": refresh,
        "expiresAt": (time.time() + float(expires_in)) if expires_in else None,
        "scope": data.get("scope"),
    }


def access_token_valid(tokens: dict | None) -> bool:
    if not tokens or not tokens.get("accessToken"):
        return False
    expires = tokens.get("expiresAt")
    if expires and float(expires) <= time.time() + 60:
        return False
    return True


class _CallbackState:
    def __init__(self):
        self.code: str | None = None
        self.error: str | None = None
        self.event = threading.Event()


def listen_for_callback(redirect_uri: str, state: str):
    """Bind the loopback callback server. Returns `(wait, close)` after the port is listening."""
    parsed = urllib.parse.urlparse(redirect_uri)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or OAUTH_CALLBACK_PATH
    box = _CallbackState()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            return

        def do_GET(self):
            request = urllib.parse.urlparse(self.path)
            if request.path != path:
                self.send_response(404)
                self.end_headers()
                return
            query = urllib.parse.parse_qs(request.query)
            got_state = (query.get("state") or [""])[0]
            if got_state != state:
                body = b"OAuth state did not match."
                self.send_response(400)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if query.get("error"):
                box.error = query["error"][0]
            else:
                box.code = (query.get("code") or [""])[0]
            box.event.set()
            body = b"<html><body><p>OpenCode authorization complete. You can close this window.</p></body></html>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    try:
        httpd = ThreadingHTTPServer((host, port), Handler)
    except OSError as exc:
        raise OAuthError(f"Could not listen for the OAuth callback on {redirect_uri}: {exc}") from exc
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    closed = False

    def close() -> None:
        nonlocal closed
        if closed:
            return
        closed = True
        httpd.shutdown()
        httpd.server_close()

    def wait(timeout: float = CALLBACK_TIMEOUT) -> str:
        try:
            if not box.event.wait(timeout):
                raise OAuthError("OAuth callback timed out")
            if box.error:
                raise OAuthError(f"OAuth authorization failed: {box.error}")
            if not box.code:
                raise OAuthError("OAuth callback did not include a code")
            return box.code
        finally:
            close()

    return wait, close


def wait_for_callback(redirect_uri: str, state: str, timeout: float = CALLBACK_TIMEOUT) -> str:
    wait, _close = listen_for_callback(redirect_uri, state)
    return wait(timeout)


def redirect_uri_for(config: OAuthConfig) -> str:
    if config.redirect_uri:
        return config.redirect_uri
    port = config.callback_port or OAUTH_CALLBACK_PORT
    return f"http://127.0.0.1:{port}{OAUTH_CALLBACK_PATH}"


def obtain_token(
    server_url: str,
    name: str,
    config: OAuthConfig,
    store: McpAuthStore,
    *,
    opener=None,
    client: httpx.Client | None = None,
    www_authenticate: str | None = None,
    interactive: bool = True,
) -> str:
    """Return a bearer token, running the browser flow when the stored token cannot be refreshed."""
    own_client = client is None
    http = client or httpx.Client(timeout=30, follow_redirects=True)
    try:
        entry = store.get(name, server_url) or {}
        tokens = entry.get("tokens") or {}
        if access_token_valid(tokens):
            return tokens["accessToken"]
        meta = None
        if tokens.get("refreshToken"):
            try:
                meta = discover(http, server_url, www_authenticate)
                client_id = (entry.get("clientInfo") or {}).get("clientId") or config.client_id
                secret = config.client_secret or (entry.get("clientInfo") or {}).get("clientSecret")
                if client_id:
                    refreshed = refresh_tokens(
                        http,
                        meta["token_endpoint"],
                        refresh_token=tokens["refreshToken"],
                        client_id=client_id,
                        resource=meta["resource"],
                        client_secret=secret,
                    )
                    saved = tokens_from_response(refreshed, tokens)
                    store.update(name, tokens=saved, serverUrl=server_url)
                    return saved["accessToken"]
            except OAuthError:
                meta = None
        if not interactive:
            raise OAuthError("MCP authentication requires user authorization")
        return _interactive_grant(http, server_url, name, config, store, opener, www_authenticate, meta)
    finally:
        if own_client:
            http.close()


def _interactive_grant(http, server_url, name, config: OAuthConfig, store: McpAuthStore, opener, www_authenticate, meta) -> str:
    meta = meta or discover(http, server_url, www_authenticate)
    redirect = redirect_uri_for(config)
    scope = config.scope or meta.get("scope") or None
    entry = store.get(name, server_url) or {}
    client_info = entry.get("clientInfo") or {}
    client_id = config.client_id or client_info.get("clientId")
    client_secret = config.client_secret or client_info.get("clientSecret")
    if not client_id:
        if not meta.get("registration_endpoint"):
            raise ClientRegistrationRequired("Server does not support dynamic client registration. Please provide clientId in config.")
        registered = register_client(http, meta["registration_endpoint"], redirect, scope)
        client_id = registered["client_id"]
        client_secret = registered.get("client_secret")
        store.update(
            name,
            serverUrl=server_url,
            clientInfo={
                "clientId": client_id,
                "clientSecret": client_secret,
                "clientSecretExpiresAt": registered.get("client_secret_expires_at"),
            },
        )
    verifier, challenge = pkce_pair()
    state = secrets.token_hex(32)
    url = authorization_url(
        meta["authorization_endpoint"],
        client_id=client_id,
        redirect_uri=redirect,
        code_challenge=challenge,
        state=state,
        resource=meta["resource"],
        scope=scope,
    )
    wait, close = listen_for_callback(redirect, state)
    try:
        (opener or webbrowser.open)(url)
        code = wait()
    finally:
        close()
    granted = exchange_code(
        http,
        meta["token_endpoint"],
        code=code,
        redirect_uri=redirect,
        client_id=client_id,
        code_verifier=verifier,
        resource=meta["resource"],
        client_secret=client_secret,
    )
    saved = tokens_from_response(granted)
    store.update(name, tokens=saved, serverUrl=server_url)
    return saved["accessToken"]
