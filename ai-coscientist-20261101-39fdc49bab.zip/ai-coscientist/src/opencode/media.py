"""Image and PDF attachments sent to vision-capable model APIs."""

from __future__ import annotations

import base64
import re

SYNTHETIC_ATTACHMENT_PROMPT = "Attached media from tool result:"


def sniff_mime(data: bytes, fallback: str = "application/octet-stream") -> str:
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"GIF8"):
        return "image/gif"
    if data.startswith(b"BM"):
        return "image/bmp"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data.startswith(b"%PDF-"):
        return "application/pdf"
    return fallback


def is_vision_mime(mime: str) -> bool:
    if mime == "application/pdf":
        return True
    return mime.startswith("image/") and mime not in {"image/svg+xml", "image/vnd.fastbidsheet"}


def data_url(mime: str, raw: bytes) -> str:
    encoded = base64.standard_b64encode(raw).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def attachment_from_bytes(raw: bytes, mime: str, *, filename: str = "") -> dict | None:
    mime = sniff_mime(raw, mime)
    if not is_vision_mime(mime):
        return None
    item = {"mime": mime, "url": data_url(mime, raw)}
    if filename:
        item["filename"] = filename
    return item


def parse_data_url(url: str) -> tuple[str, str] | None:
    match = re.match(r"data:([^;,]+);base64,(.+)", url, re.S)
    if not match:
        return None
    return match.group(1), re.sub(r"\s", "", match.group(2))


def openai_media_part(attachment: dict) -> dict | None:
    url = attachment.get("url") or ""
    mime = attachment.get("mime") or "application/octet-stream"
    if not url:
        return None
    if mime == "application/pdf":
        return {
            "type": "file",
            "file": {
                "filename": attachment.get("filename") or "file.pdf",
                "file_data": url,
            },
        }
    if mime.startswith("image/") or url.startswith("data:image/"):
        return {"type": "image_url", "image_url": {"url": url}}
    return None


def anthropic_media_block(attachment: dict) -> dict | None:
    url = attachment.get("url") or ""
    mime = attachment.get("mime") or ""
    parsed = parse_data_url(url)
    if parsed:
        media_type, data = parsed
        mime = media_type or mime
        if mime == "application/pdf":
            return {"type": "document", "source": {"type": "base64", "media_type": mime, "data": data}}
        if mime.startswith("image/"):
            return {"type": "image", "source": {"type": "base64", "media_type": mime, "data": data}}
        return None
    if mime.startswith("image/") and url.startswith("http"):
        return {"type": "image", "source": {"type": "url", "url": url}}
    if mime == "application/pdf" and url.startswith("http"):
        return {"type": "document", "source": {"type": "url", "url": url}}
    return None
