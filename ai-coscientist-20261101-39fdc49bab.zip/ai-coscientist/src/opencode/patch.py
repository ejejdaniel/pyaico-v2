"""Apply the OpenCode patch envelope (*** Begin Patch / *** End Patch)."""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Chunk:
    old_lines: list[str]
    new_lines: list[str]
    change_context: str | None = None
    is_end_of_file: bool = False


@dataclass
class Hunk:
    type: str
    path: str
    contents: str = ""
    move_path: str | None = None
    chunks: list[Chunk] = field(default_factory=list)


def _strip_heredoc(text: str) -> str:
    import re

    match = re.match(r"^(?:cat\s+)?<<['\"]?(\w+)['\"]?\s*\n([\s\S]*?)\n\1\s*$", text)
    if match:
        return match.group(2)
    return text


def parse_patch(patch_text: str) -> list[Hunk]:
    cleaned = _strip_heredoc(patch_text.strip())
    lines = cleaned.split("\n")
    try:
        begin = next(index for index, line in enumerate(lines) if line.strip() == "*** Begin Patch")
        end = next(index for index, line in enumerate(lines) if line.strip() == "*** End Patch")
    except StopIteration as exc:
        raise ValueError("Invalid patch format: missing Begin/End markers") from exc
    if begin >= end:
        raise ValueError("Invalid patch format: missing Begin/End markers")

    hunks: list[Hunk] = []
    index = begin + 1
    while index < end:
        line = lines[index]
        if any(line.startswith(prefix) and not line[len(prefix):].strip() for prefix in ("*** Add File:", "*** Delete File:", "*** Update File:")):
            index += 1
            continue
        if line.startswith("*** Add File:"):
            path = line[len("*** Add File:") :].strip()
            content, index = _add_content(lines, index + 1, end)
            hunks.append(Hunk(type="add", path=path, contents=content))
            continue
        if line.startswith("*** Delete File:"):
            path = line[len("*** Delete File:") :].strip()
            hunks.append(Hunk(type="delete", path=path))
            index += 1
            continue
        if line.startswith("*** Update File:"):
            path = line[len("*** Update File:") :].strip()
            index += 1
            move_path = None
            if index < end and lines[index].startswith("*** Move to:"):
                move_path = lines[index][len("*** Move to:") :].strip()
                index += 1
            chunks, index = _update_chunks(lines, index, end)
            hunks.append(Hunk(type="update", path=path, move_path=move_path, chunks=chunks))
            continue
        index += 1
    if not hunks:
        raise ValueError("Invalid patch: no file operations")
    return hunks


def _add_content(lines: list[str], start: int, end: int) -> tuple[str, int]:
    collected: list[str] = []
    index = start
    while index < end and not lines[index].startswith("***"):
        if lines[index].startswith("+"):
            collected.append(lines[index][1:])
        index += 1
    return "".join(line + "\n" for line in collected), index


def _update_chunks(lines: list[str], start: int, end: int) -> tuple[list[Chunk], int]:
    chunks: list[Chunk] = []
    index = start
    while index < end and not lines[index].startswith("***"):
        if not lines[index].startswith("@@"):
            index += 1
            continue
        context = lines[index][2:].strip() or None
        index += 1
        old: list[str] = []
        new: list[str] = []
        eof = False
        while index < end and not lines[index].startswith("@@") and not lines[index].startswith("***"):
            change = lines[index]
            if change == "*** End of File":
                eof = True
                index += 1
                break
            if change.startswith(" "):
                old.append(change[1:])
                new.append(change[1:])
            elif change.startswith("-"):
                old.append(change[1:])
            elif change.startswith("+"):
                new.append(change[1:])
            index += 1
        chunks.append(Chunk(old_lines=old, new_lines=new, change_context=context, is_end_of_file=eof))
    return chunks, index


def _normalize(text: str) -> str:
    return (
        text.replace("‘", "'")
        .replace("’", "'")
        .replace("‚", "'")
        .replace("‛", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("„", '"')
        .replace("‟", '"')
        .replace("‐", "-")
        .replace("‑", "-")
        .replace("‒", "-")
        .replace("–", "-")
        .replace("—", "-")
        .replace("―", "-")
        .replace("…", "...")
        .replace("\u00a0", " ")
    )


def _try_match(lines: list[str], pattern: list[str], start: int, compare, eof: bool) -> int:
    if eof:
        from_end = len(lines) - len(pattern)
        if from_end >= start and all(compare(lines[from_end + j], pattern[j]) for j in range(len(pattern))):
            return from_end
    for index in range(start, len(lines) - len(pattern) + 1):
        if all(compare(lines[index + j], pattern[j]) for j in range(len(pattern))):
            return index
    return -1


def _seek(lines: list[str], pattern: list[str], start: int, eof: bool = False) -> int:
    if not pattern:
        return -1
    for compare in (
        lambda a, b: a == b,
        lambda a, b: a.rstrip() == b.rstrip(),
        lambda a, b: a.strip() == b.strip(),
        lambda a, b: _normalize(a.strip()) == _normalize(b.strip()),
    ):
        found = _try_match(lines, pattern, start, compare, eof)
        if found != -1:
            return found
    return -1


def apply_chunks(original: str, chunks: list[Chunk], file_path: str) -> str:
    bom = original.startswith("\ufeff")
    text = original[1:] if bom else original
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    replacements: list[tuple[int, int, list[str]]] = []
    cursor = 0
    for chunk in chunks:
        if chunk.change_context:
            context_at = _seek(lines, [chunk.change_context], cursor)
            if context_at == -1:
                raise ValueError(f"Failed to find context '{chunk.change_context}' in {file_path}")
            cursor = context_at + 1
        if not chunk.old_lines:
            insertion = len(lines) - 1 if lines and lines[-1] == "" else len(lines)
            replacements.append((insertion, 0, list(chunk.new_lines)))
            continue
        pattern = list(chunk.old_lines)
        new_slice = list(chunk.new_lines)
        found = _seek(lines, pattern, cursor, chunk.is_end_of_file)
        if found == -1 and pattern and pattern[-1] == "":
            pattern = pattern[:-1]
            if new_slice and new_slice[-1] == "":
                new_slice = new_slice[:-1]
            found = _seek(lines, pattern, cursor, chunk.is_end_of_file)
        if found == -1:
            preview = "\n".join(chunk.old_lines)
            raise ValueError(f"Failed to find expected lines in {file_path}:\n{preview}")
        replacements.append((found, len(pattern), new_slice))
        cursor = found + len(pattern)
    result = list(lines)
    for start, old_len, new_segment in reversed(sorted(replacements, key=lambda item: item[0])):
        del result[start : start + old_len]
        for offset, line in enumerate(new_segment):
            result.insert(start + offset, line)
    if not result or result[-1] != "":
        result.append("")
    joined = "\n".join(result)
    return ("\ufeff" + joined) if bom else joined


def unified_diff(old: str, new: str, path: str) -> str:
    diff = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=path,
        tofile=path,
    )
    return "".join(diff)


def apply_hunks(hunks: list[Hunk], root: Path) -> list[str]:
    changed: list[str] = []
    for hunk in hunks:
        path = Path(hunk.path)
        if not path.is_absolute():
            path = root / path
        path = path.resolve()
        if hunk.type == "add":
            path.parent.mkdir(parents=True, exist_ok=True)
            text = hunk.contents
            if text and not text.endswith("\n"):
                text += "\n"
            path.write_text(text, encoding="utf-8")
            changed.append(str(path))
        elif hunk.type == "delete":
            path.unlink()
            changed.append(str(path))
        elif hunk.type == "update":
            if not path.is_file():
                raise FileNotFoundError(path)
            original = path.read_text(encoding="utf-8")
            updated = apply_chunks(original, hunk.chunks, str(path))
            destination = path
            if hunk.move_path:
                destination = Path(hunk.move_path)
                if not destination.is_absolute():
                    destination = root / destination
                destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(updated, encoding="utf-8")
            if destination != path and path.exists():
                path.unlink()
            changed.append(str(destination))
    return changed
