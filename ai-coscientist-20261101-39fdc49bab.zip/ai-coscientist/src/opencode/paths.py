"""XDG-style locations used by OpenCode, with Windows fallbacks."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

APP = "opencode"


def home() -> Path:
    override = os.environ.get("OPENCODE_TEST_HOME")
    if override:
        return Path(override)
    return Path.home()


def _xdg(name: str, fallback: Path) -> Path:
    value = os.environ.get(name)
    if value:
        return Path(value)
    return fallback


def data_dir() -> Path:
    return _xdg("XDG_DATA_HOME", Path.home() / ".local" / "share") / APP


def app_root() -> Path:
    """Directory that contains this project's pyproject.toml."""
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file():
            return parent
    return here.parents[2]


def config_dir() -> Path:
    return _xdg("XDG_CONFIG_HOME", Path.home() / ".config") / APP


def state_dir() -> Path:
    return _xdg("XDG_STATE_HOME", Path.home() / ".local" / "state") / APP


def cache_dir() -> Path:
    return _xdg("XDG_CACHE_HOME", Path.home() / ".cache") / APP


def tmp_dir() -> Path:
    return Path(tempfile.gettempdir()) / APP


def log_dir() -> Path:
    return data_dir() / "log"


def truncation_dir() -> Path:
    return data_dir() / "tool-output"


def ensure_dirs() -> None:
    for path in (
        data_dir(),
        config_dir(),
        state_dir(),
        cache_dir(),
        tmp_dir(),
        log_dir(),
        data_dir() / "plans",
        truncation_dir(),
    ):
        path.mkdir(parents=True, exist_ok=True)
