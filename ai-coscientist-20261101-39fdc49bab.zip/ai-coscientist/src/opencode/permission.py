"""Permission rules. The last matching rule wins, same as the TypeScript agent."""

from __future__ import annotations

import os
import re
import threading
from dataclasses import dataclass, field


Action = str  # allow | ask | deny


@dataclass
class Rule:
    permission: str
    pattern: str
    action: str


def wildcard_match(value: str, pattern: str) -> bool:
    normalized = value.replace("\\", "/")
    escaped = pattern.replace("\\", "/")
    escaped = re.sub(r"[.+^${}()|[\]\\]", lambda match: "\\" + match.group(0), escaped)
    escaped = escaped.replace("*", ".*").replace("?", ".")
    if escaped.endswith(" .*"):
        escaped = escaped[:-3] + "( .*)?"
    flags = re.DOTALL
    if os.name == "nt":
        flags |= re.IGNORECASE
    return re.search("^" + escaped + "$", normalized, flags) is not None


def expand_home(pattern: str) -> str:
    if pattern == "~":
        return str(os.path.expanduser("~"))
    if pattern.startswith("~/"):
        return str(os.path.expanduser("~")) + pattern[1:]
    if pattern.startswith("$HOME/"):
        return str(os.path.expanduser("~")) + pattern[5:]
    if pattern.startswith("$HOME"):
        return str(os.path.expanduser("~")) + pattern[5:]
    return pattern


def from_config(permission: dict | None) -> list[Rule]:
    rules: list[Rule] = []
    if not permission:
        return rules
    for key, value in permission.items():
        if isinstance(value, str):
            rules.append(Rule(permission=key, pattern="*", action=value))
            continue
        if isinstance(value, dict):
            for pattern, action in value.items():
                if isinstance(action, str):
                    rules.append(Rule(permission=key, pattern=expand_home(pattern), action=action))
    return rules


def merge(*rulesets: list[Rule]) -> list[Rule]:
    out: list[Rule] = []
    for rules in rulesets:
        out.extend(rules)
    return out


def evaluate(permission: str, pattern: str, *rulesets: list[Rule]) -> Rule:
    rules = [rule for ruleset in rulesets for rule in ruleset]
    for rule in reversed(rules):
        if wildcard_match(permission, rule.permission) and wildcard_match(pattern, rule.pattern):
            return rule
    return Rule(permission=permission, pattern="*", action="ask")


_EDIT_TOOLS = {"edit", "write", "apply_patch"}
_READ_TOOLS = {"list_mcp_resources", "list_mcp_resource_templates", "read_mcp_resource"}


def permission_key(tool: str) -> str:
    if tool in _EDIT_TOOLS:
        return "edit"
    if tool in _READ_TOOLS:
        return "read"
    return tool


def disabled(tools: list[str], ruleset: list[Rule]) -> set[str]:
    hidden: set[str] = set()
    for tool in tools:
        key = permission_key(tool)
        match = None
        for rule in reversed(ruleset):
            if wildcard_match(key, rule.permission):
                match = rule
                break
        if match and match.pattern == "*" and match.action == "deny":
            hidden.add(tool)
    return hidden


class PermissionDenied(Exception):
    def __init__(self, permission: str, pattern: str):
        super().__init__(f"permission denied: {permission} ({pattern})")
        self.permission = permission
        self.pattern = pattern


class PermissionRejected(Exception):
    pass


class PermissionCorrected(Exception):
    pass


@dataclass
class Pending:
    id: str
    session_id: str
    permission: str
    patterns: list[str]
    always: list[str]
    metadata: dict
    event: threading.Event = field(default_factory=threading.Event)
    reply: str | None = None
    message: str | None = None


class Broker:
    """Interactive permission prompts. `auto` approves asks; otherwise a callback or the HTTP API replies."""

    def __init__(self, callback=None, auto: bool = False):
        self.callback = callback
        self.auto = auto
        self._pending: dict[str, Pending] = {}
        self._pending_aborts: dict[str, threading.Event | None] = {}
        self._approved: list[Rule] = []
        self._lock = threading.Lock()
        self._seq = 0
        self.abort_event = None

    def ask(
        self,
        *,
        session_id: str,
        permission: str,
        patterns: list[str],
        ruleset: list[Rule],
        always: list[str] | None = None,
        metadata: dict | None = None,
        abort_event: threading.Event | None = None,
    ) -> None:
        always = [] if always is None else always
        abort = abort_event if abort_event is not None else self.abort_event(session_id) if self.abort_event else None
        if abort and abort.is_set():
            raise PermissionRejected("Execution stopped")
        metadata = metadata or {}
        needs_ask = False
        with self._lock:
            approved = list(self._approved)
        for pattern in patterns:
            rule = evaluate(permission, pattern, ruleset, approved)
            if rule.action == "deny":
                raise PermissionDenied(permission, pattern)
            if rule.action == "ask":
                needs_ask = True
        if not needs_ask:
            return
        if self.auto:
            return
        with self._lock:
            self._seq += 1
            request_id = f"per_{self._seq:06d}"
            pending = Pending(
                id=request_id,
                session_id=session_id,
                permission=permission,
                patterns=list(patterns),
                always=list(always),
                metadata=metadata,
            )
            self._pending[request_id] = pending
            self._pending_aborts[request_id] = abort
        try:
            if self.callback:
                # A UI callback can block outside our control. Stop this wait
                # on cancellation and never apply its eventual stale reply.
                callback_done = threading.Event()
                callback_result = {}

                def respond():
                    try:
                        callback_result["reply"] = self.callback(pending)
                    except BaseException as error:
                        callback_result["error"] = error
                    finally:
                        callback_done.set()

                threading.Thread(target=respond, daemon=True, name="opencode-permission-callback").start()
                while not callback_done.wait(0.05):
                    if abort and abort.is_set():
                        break
                if not (abort and abort.is_set()):
                    if "error" in callback_result:
                        raise callback_result["error"]
                    self.reply(request_id, callback_result.get("reply") or "reject")
            else:
                while not pending.event.wait(0.05):
                    if abort and abort.is_set():
                        break
        finally:
            with self._lock:
                self._pending.pop(request_id, None)
                self._pending_aborts.pop(request_id, None)
        if abort and abort.is_set():
            raise PermissionRejected("Execution stopped")
        if pending.reply == "reject" and pending.message:
            raise PermissionCorrected(pending.message)
        if pending.reply == "reject" or pending.reply is None:
            raise PermissionRejected(pending.message or "The user rejected this action.")

    def abort(self, session_id: str) -> None:
        with self._lock:
            for pending in self._pending.values():
                if pending.session_id == session_id:
                    pending.reply = "reject"
                    pending.message = "Execution stopped"
                    pending.event.set()

    def reply(self, request_id: str, reply: str, message: str | None = None) -> bool:
        with self._lock:
            pending = self._pending.get(request_id)
            if not pending:
                return False
            abort = self._pending_aborts.get(request_id)
            if abort is not None and abort.is_set():
                # Do not let a callback/HTTP reply arriving during cancellation
                # install an approval that would affect the next attempt.
                self._pending.pop(request_id, None)
                self._pending_aborts.pop(request_id, None)
                pending.event.set()
                return False
            if reply not in {"once", "always", "reject"}:
                raise ValueError("Unknown permission reply")
            pending.reply = reply
            pending.message = message
            if reply == "always":
                self._approved.extend(Rule(pending.permission, pattern, "allow") for pattern in pending.always)
            for other in self._pending.values():
                if other is pending or other.session_id != pending.session_id:
                    continue
                other_abort = self._pending_aborts.get(other.id)
                if other_abort is not None and other_abort.is_set():
                    continue
                if reply == "reject":
                    other.reply = "reject"
                    other.event.set()
                elif reply == "always" and all(
                    evaluate(other.permission, pattern, self._approved).action == "allow"
                    for pattern in other.patterns
                ):
                    other.reply = "always"
                    other.event.set()
            pending.event.set()
        return True

    def list_pending(self) -> list[dict]:
        with self._lock:
            items = list(self._pending.values())
        return [
            {
                "id": item.id,
                "sessionID": item.session_id,
                "permission": item.permission,
                "patterns": item.patterns,
                "always": item.always,
                "metadata": item.metadata,
            }
            for item in items
        ]
