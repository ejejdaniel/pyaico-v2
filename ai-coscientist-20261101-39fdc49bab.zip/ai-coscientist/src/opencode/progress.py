"""How long the work has gone without progress the host can see, counted by the host; no model judges it.

The weight of the agent's own recent conclusions follows its progress (prompts/context-labels.txt): while
the work moves, its recent history is the best guide; in a stretch with no progress, what it concluded
there is an unconfirmed hypothesis. Acoustics round 1 (2026-10-31) spent its last 52 calls testing one
suspected cause without saving anything, and both runs of round 2 went straight back to it; a compaction
summary of round 1 kept the suspicion as the work's current state.

Progress is anything new: a file created or changed in the project outside the framework's own folders,
caches and environments (records and fetched documents included), a successful reply of a tool that brings
in an outside source, or a project file consulted that no earlier call of the task named (an investigation
moves on by reading). A change to the files the recent calls keep naming, or to a copy of one, is not: that
is the same work going on; nor is going over the same files again. It is counted from saved times, so it
holds across processes and rounds: a round that starts after a stalled one starts stalled.

A stall long enough since the last review pauses the work for a review of the round so far, when the host
application supplies one (loop._pause_for_review; the research runner does).
"""

from __future__ import annotations

from collections import Counter
import os
from pathlib import Path
import re

STALL_AFTER = 15
# A stall this long since the later of the last saved progress and the last review pauses the work for a
# review of the round so far (loop._pause_for_review; the host application supplies the review).
PAUSE_AFTER = 30
# The files a stalled stretch keeps naming are its focus: rewriting them, or saving a copy of one, is more of
# the same work, not progress. Acoustics round 2 (_r2c) rewrote the module it kept probing twice, once with a
# backup copy, and each rewrite reset the count. The focus is read from this many recent calls.
FOCUS_WINDOW = 30
# The framework's own records of the work (not the work), caches and package folders.
SKIPPED = {".git", ".opencode", "__pycache__", ".pytest_cache", ".mypy_cache", "node_modules"}
# A folder this large is not a task's workspace (a person's whole repository, say): it is not counted.
MAX_FILES = 20_000
_PATH = re.compile(r"[\w.\\/-]+\.[A-Za-z0-9]{1,8}")
# A Python snippet names a project module by importing it: "import room_model as rm, early_reflections as er".
_IMPORT = re.compile(r"(?:^|[;\"'\s])(?:import|from)\s+([^\n;\"']*)")


def _setting(config, name: str, default: int) -> int:
    value = ((config or {}).get("progress") or {}).get(name, default)
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 1 else default


def stall_after(config) -> int:
    return _setting(config, "stall_after", STALL_AFTER)


def pause_after(config) -> int:
    return _setting(config, "pause_after", PAUSE_AFTER)


def _files(directory) -> dict[str, list[Path]] | None:
    """Project files by name, without the skipped folders and Python environments; None past MAX_FILES."""
    found: dict[str, list[Path]] = {}
    total = 0
    for root, folders, files in os.walk(directory):
        folders[:] = [name for name in folders
                      if name not in SKIPPED and not os.path.exists(os.path.join(root, name, "pyvenv.cfg"))]
        total += len(files)
        if total > MAX_FILES:
            return None
        for name in files:
            found.setdefault(name, []).append(Path(root, name))
    return found


def _failed(message: dict) -> bool:
    metadata = message.get("metadata") or {}
    code = metadata.get("exit")
    return bool(metadata.get("error")) or (isinstance(code, int) and not isinstance(code, bool) and code != 0)


def _reworked(path: Path, changed: float, directory: Path, calls: list[dict], named: list[set]) -> bool:
    """Whether the change at `changed` reworked what the calls before it kept naming: the file itself, or, for
    a copy (its name holds the other's, as a backup's does), the file it copies. A new file the work then uses
    (a test it writes and runs) was not named before it existed, so writing it is progress (_r2d)."""
    before = [names for message, names in zip(calls, named) if (message.get("created") or 0.0) < changed]
    counts = Counter(name for names in before[-FOCUS_WINDOW:] for name in names)
    relative = path.relative_to(directory).as_posix()
    return counts[relative] >= 2 or any(
        count >= 2 and other != relative and len(Path(other).stem) >= 4 and Path(other).stem in path.stem
        for other, count in counts.items())


def check(store, session_id: str, directory, source_tools=(), messages=None) -> tuple[int, list[dict], dict, set]:
    """(model calls since the last saved progress, those calls' assistant messages, project files by name,
    the files the stalled calls kept reworking).

    A change to a file the calls before it had named at least twice (of their last FOCUS_WINDOW), or to a copy of
    one, is the same work going on, not progress. A folder past MAX_FILES gives (0, [], {}, set())."""
    files = _files(directory)
    if files is None:
        return 0, [], {}, set()
    directory = Path(directory)
    messages = store.messages(session_id) if messages is None else messages
    calls = [message for message in messages if message.get("role") == "assistant" and message.get("tool_calls")
             and not message.get("compaction_through")]
    named = [_names(message, files, directory) for message in calls]
    changes = []
    for paths in files.values():
        for path in paths:
            try:
                changes.append((path.stat().st_mtime, path))
            except OSError:
                continue
    saved = 0.0
    for changed, path in sorted(changes, key=lambda item: item[0], reverse=True):
        if not _reworked(path, changed, directory, calls, named):
            saved = changed  # the newest change that is progress
            break
    for message in messages:
        if message.get("role") == "tool" and message.get("name") in source_tools and not _failed(message):
            saved = max(saved, message.get("created") or 0.0)
    # Reading is how a task that saves little moves on, an investigation above all: a call that consults a
    # project file no earlier call of the task named is progress too; going over the same files is not.
    seen: set[str] = set()
    for message, names in zip(calls, named):
        if names - seen:
            saved = max(saved, message.get("created") or 0.0)
        seen |= names
    stretch = [message for message in calls if (message.get("created") or 0.0) > saved]
    reworked = {path.relative_to(directory).as_posix() for changed, path in changes if changed > saved}
    return len(stretch), stretch, files, reworked


def since(stretch: list[dict], moment: float) -> int:
    """How many of the stretch's calls came after the moment (the last review, say)."""
    return sum(1 for message in stretch if (message.get("created") or 0.0) > moment)


def _names(message: dict, files: dict, directory) -> set[str]:
    """The project files one model call names: by file name, or as a Python module it imports."""
    named = set()
    for call in message.get("tool_calls") or []:
        text = " ".join(str(value) for value in (call.get("arguments") or {}).values()) \
            if isinstance(call.get("arguments"), dict) else str(call.get("arguments") or "")
        names = [re.split(r"[\\/]", token)[-1] for token in _PATH.findall(text)]
        names += [f"{word}.py" for clause in _IMPORT.findall(text) for word in re.findall(r"[A-Za-z_]\w*", clause)]
        for name in names:
            matches = files.get(name, [])
            if len(matches) == 1:
                named.add(matches[0].relative_to(directory).as_posix())
    return named


def _named(stretch: list[dict], files: dict, directory) -> Counter:
    """The project files the stretch's calls name, each counted once per call."""
    return Counter(name for message in stretch for name in _names(message, files, directory))


def stalled(app, session_id: str, session: dict | None = None, sources=None) -> tuple[int, str, list[dict]]:
    """(model calls in the current stall, its host-facts section, those calls), or (0, "", []) when the work
    is moving.

    Only a task's top session is counted: a subagent may be meant to read without saving. sources: the
    names of the tools that bring in outside sources, when the caller has them."""
    directory = getattr(app, "directory", None)
    session = session or app.store.get_session(session_id)
    if directory is None or session.get("parentID") is not None:
        return 0, "", []
    config = getattr(app, "config", None) or {}
    if sources is None:
        from opencode import deep
        from opencode.tools import builtin_tools
        from opencode.tools.types import external_source_names

        sources = external_source_names([*builtin_tools(config), *deep.tools(app)])
    messages = app.store.messages(session_id)
    count, stretch, files, reworked = check(app.store, session_id, directory, sources, messages)
    if count < stall_after(config):
        return 0, "", []
    humans = [m for m in messages
              if m.get("role") == "user" and not m.get("synthetic") and not m.get("compaction_through")]
    latest = humans[-1]["created"] if humans else 0.0
    before = sum(1 for message in stretch if (message.get("created") or 0.0) < latest)
    tools = Counter(call.get("name") for message in stretch for call in message.get("tool_calls") or [])
    named = _named(stretch, files, Path(directory))
    pauses = [pause for pause in (session.get("meta") or {}).get("pauses") or [] if pause.get("time", 0.0) > latest]
    text = (f"Progress check (counted by the host from saved times, not a judgment): the last {count} model calls "
            f"made no progress the host can see: no new or changed project file outside the framework's folders"
            + (", apart from files they kept reworking" if reworked else "")
            + ", no record, no outside source, and no project file read that earlier calls had not named."
            + (f" {before} of them came before the latest human message." if before else "")
            + f" Their tool calls: {', '.join(f'{name} {n}' for name, n in tools.most_common())}."
            + (f" Project files they name most: {', '.join(f'{path} ({n})' for path, n in named.most_common(3))}."
               if named else "")
            + (f" Files they changed after naming them again and again, which is the same work going on: "
               f"{', '.join(sorted(reworked))}." if reworked else "")
            + (f" The host paused the work for a review after {pauses[-1].get('stall')} of these calls; "
               + ("the task review in view is the one written then." if pauses[-1].get("status") == "written"
                  else "that review wrote no new version.") if pauses else ""))
    return count, text, stretch
