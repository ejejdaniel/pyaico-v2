from importlib.resources import files


def load(name: str) -> str:
    path = files("opencode.prompts").joinpath(name)
    return path.read_text(encoding="utf-8")
