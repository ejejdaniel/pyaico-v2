"""Chat providers. OpenAI-compatible APIs and the Anthropic Messages API."""

from __future__ import annotations

import asyncio
import json
import math
import os
import random
import re
import threading
import time
from dataclasses import dataclass, field, replace
from concurrent.futures import Future, TimeoutError as FutureTimeout
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import httpx
from jsonschema import ValidationError, validate as validate_arguments

from opencode import runtime_settings
from opencode.auth import AuthStore
from opencode.config import validate_modalities
from opencode.media import SYNTHETIC_ATTACHMENT_PROMPT, anthropic_media_block, openai_media_part


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class Completion:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: dict = field(default_factory=dict)
    model: str = ""
    finish_reason: str | None = None
    reasoning_content: str | None = None


@dataclass
class ProviderInfo:
    id: str
    api: str
    name: str
    base_url: str
    env: list[str]
    models: list[str]
    default_model: str | None
    api_key: str | None = None
    context: int = 128_000


BUILTIN: dict[str, ProviderInfo] = {
    "openai": ProviderInfo(
        "openai",
        "openai",
        "OpenAI",
        "https://api.openai.com/v1",
        ["OPENAI_API_KEY"],
        ["gpt-4.1", "gpt-4.1-mini", "gpt-4o", "gpt-4o-mini", "o3", "o4-mini", "gpt-5"],
        "gpt-4.1",
        context=128_000,
    ),
    "anthropic": ProviderInfo(
        "anthropic",
        "anthropic",
        "Anthropic",
        "https://api.anthropic.com/v1",
        ["ANTHROPIC_API_KEY"],
        ["claude-sonnet-4-5", "claude-opus-4-1", "claude-3-5-haiku-latest", "claude-sonnet-4-0"],
        "claude-sonnet-4-5",
        context=200_000,
    ),
    "google": ProviderInfo(
        "google",
        "openai",
        "Google",
        "https://generativelanguage.googleapis.com/v1beta/openai",
        ["GEMINI_API_KEY", "GOOGLE_GENERATIVE_AI_API_KEY", "GOOGLE_API_KEY"],
        ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
        "gemini-2.5-flash",
        context=1_000_000,
    ),
    "groq": ProviderInfo(
        "groq",
        "openai",
        "Groq",
        "https://api.groq.com/openai/v1",
        ["GROQ_API_KEY"],
        ["llama-3.3-70b-versatile", "openai/gpt-oss-120b"],
        "llama-3.3-70b-versatile",
        context=128_000,
    ),
    "openrouter": ProviderInfo(
        "openrouter",
        "openai",
        "OpenRouter",
        "https://openrouter.ai/api/v1",
        ["OPENROUTER_API_KEY"],
        ["openai/gpt-4.1", "anthropic/claude-sonnet-4.5", "google/gemini-2.5-flash"],
        "openai/gpt-4.1",
        context=128_000,
    ),
    "xai": ProviderInfo(
        "xai",
        "openai",
        "xAI",
        "https://api.x.ai/v1",
        ["XAI_API_KEY"],
        ["grok-3", "grok-3-mini"],
        "grok-3",
        context=131_072,
    ),
    "mistral": ProviderInfo(
        "mistral",
        "openai",
        "Mistral",
        "https://api.mistral.ai/v1",
        ["MISTRAL_API_KEY"],
        ["mistral-large-latest", "mistral-small-latest"],
        "mistral-large-latest",
        context=128_000,
    ),
    "deepseek": ProviderInfo(
        "deepseek",
        "openai",
        "DeepSeek",
        "https://api.deepseek.com/v1",
        ["DEEPSEEK_API_KEY"],
        ["deepseek-chat", "deepseek-reasoner"],
        "deepseek-chat",
        context=128_000,
    ),
    "together": ProviderInfo(
        "together",
        "openai",
        "Together",
        "https://api.together.xyz/v1",
        ["TOGETHER_API_KEY"],
        ["meta-llama/Llama-3.3-70B-Instruct-Turbo"],
        "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        context=128_000,
    ),
    "ollama": ProviderInfo(
        "ollama",
        "openai",
        "Ollama",
        os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/") + "/v1",
        [],
        [],
        None,
        api_key="ollama",
        context=32_000,
    ),
}


def _api_from_npm(npm: str | None, explicit: str | None) -> str:
    if explicit:
        lowered = explicit.lower()
        if "anthropic" in lowered:
            return "anthropic"
        if "google" in lowered and "openai" not in lowered:
            return "google"
        return "openai"
    if not npm:
        return "openai"
    if "anthropic" in npm:
        return "anthropic"
    return "openai"


class ProviderError(RuntimeError):
    def __init__(self, message: str, partial: Completion | None = None):
        super().__init__(message)
        self.partial = partial


def _check_abort(abort_event: threading.Event | None, partial: Completion | None = None) -> None:
    if abort_event is not None and abort_event.is_set():
        raise ProviderError("Model request aborted", partial)


class _RequestAbort(threading.Event):
    """Stop one model attempt and its tools without stopping the owning session."""

    def __init__(self, source):
        super().__init__()
        self.source = source

    def is_set(self):
        return super().is_set() or (self.source is not None and self.source.is_set())

    def wait(self, timeout=None):
        deadline = time.monotonic() + timeout if timeout is not None else None
        while not self.is_set():
            remaining = deadline - time.monotonic() if deadline is not None else 0.05
            if remaining <= 0:
                return False
            super().wait(min(remaining, 0.05))
        return True


def _run_cancellable(request, abort_event: threading.Event):
    """Run async HTTP from the synchronous provider, joining its cleanup on stop.

    The one owned thread runs cancellable socket I/O; it is never abandoned on
    cancellation. The caller uses a blocking Event wait (at most 20 wakeups/s)
    because threading.Event has no callback or multi-event wait interface.
    """
    _check_abort(abort_event)
    finished = threading.Event()
    state: dict = {}
    lock = threading.Lock()

    async def run():
        with lock:
            state["loop"] = asyncio.get_running_loop()
            state["task"] = asyncio.current_task()
        try:
            _check_abort(abort_event)
            return await request()
        finally:
            # Remove cancellation targets before asyncio.run can close its loop.
            with lock:
                state.pop("loop", None)
                state.pop("task", None)

    def worker():
        try:
            state["result"] = asyncio.run(run())
        except BaseException as exc:
            state["error"] = exc
        finally:
            finished.set()

    thread = threading.Thread(target=worker, name="opencode-provider-request")
    thread.start()
    cancelled = False

    def cancel_request():
        nonlocal cancelled
        with lock:
            loop, task = state.get("loop"), state.get("task")
            if not cancelled and loop is not None and not task.done():
                loop.call_soon_threadsafe(task.cancel)
                cancelled = True

    try:
        while not finished.wait(0.05):
            if abort_event.is_set() and not cancelled:
                cancel_request()
    except BaseException:
        # Also stop a request whose worker has not registered its task yet.
        # Clearing only the current task would miss this startup boundary.
        abort_event.set()
        cancel_request()
        raise
    finally:
        # Do not report stopped while an HTTP request or its cleanup is alive.
        thread.join()
    _check_abort(abort_event)
    error = state.get("error")
    if error is not None:
        if isinstance(error, asyncio.CancelledError):
            raise ProviderError("Model request aborted") from None
        raise error
    return state["result"]


def _post(url, headers, body, timeout, abort_event):
    if abort_event is None:
        with httpx.Client(timeout=timeout) as client:
            return client.post(url, headers=headers, json=body)

    async def request():
        async with httpx.AsyncClient(timeout=timeout) as client:
            return await client.post(url, headers=headers, json=body)

    return _run_cancellable(request, abort_event)


# Temperature and media capabilities share the original in-memory catalog,
# fetch deadline, cancellation path, and lock; no second catalog request/cache.
_temperature_catalog: dict[tuple[str, str], dict] | None = None
_temperature_catalog_lock = threading.Lock()
_temperature_catalog_timeout = 10.0


def _default_temperature(model: str) -> float | None:
    """ProviderTransform.temperature, in source order, using the API model ID."""
    name = model.lower()
    if "north-mini-code" in name:
        return 1.0
    if "qwen" in name:
        return 0.55
    if "claude" in name:
        return None
    if "gemini" in name:
        patterns = (r"gemini-2[.-]5(?:[.-]|$)", r"gemini-3-(?:flash|pro)(?:[.-]|$)",
                    r"gemini-3[.-]1(?:[.-]|$)", r"gemini-3[.-]5-flash(?!-lite)(?:[.-]|$)")
        return 1.0 if any(re.search(pattern, name) for pattern in patterns) else None
    if any(value in name for value in ("glm-4.6", "glm-4.7", "minimax-m2")):
        return 1.0
    if "kimi-k2" in name:
        return 1.0 if any(value in name for value in ("thinking", "k2.", "k2p", "k2-5")) else 0.6
    return None


def _catalog_temperature(provider_id: str, model: str, abort_event: threading.Event | None) -> bool:
    definition = _catalog_model(provider_id, model, abort_event)
    return definition["temperature"] if definition is not None else False


def _catalog_model(provider_id: str, model: str, abort_event: threading.Event | None) -> dict | None:
    """Read the authoritative catalog once per process, without a disk cache."""
    global _temperature_catalog
    signal = abort_event if abort_event is not None else threading.Event()
    _check_abort(signal)
    while not _temperature_catalog_lock.acquire(timeout=0.05):
        _check_abort(signal)
    try:
        _check_abort(signal)
        if _temperature_catalog is None:
            async def request():
                # The source's ten-second fetch deadline includes its two
                # transient retries and the complete response body.
                async with asyncio.timeout(_temperature_catalog_timeout):
                    async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                        for attempt in range(3):
                            try:
                                response = await client.get("https://models.dev/api.json")
                                response.raise_for_status()
                                return response.json()
                            except httpx.HTTPError as error:
                                status = error.response.status_code if isinstance(error, httpx.HTTPStatusError) else None
                                transient = (status in {408, 429} or (status is not None and status >= 500)
                                             or isinstance(error, httpx.TransportError))
                                if not transient or attempt == 2:
                                    raise
                                await asyncio.sleep(0.2 * 2 ** attempt * random.uniform(0.8, 1.2))

            try:
                data = _run_cancellable(request, signal)
            except ProviderError:
                raise
            except TimeoutError as error:
                raise ProviderError("Model temperature catalog request exceeded its 10-second deadline") from error
            except (httpx.HTTPError, ValueError) as error:
                raise ProviderError(f"Cannot load model temperature catalog: {error}") from error
            if not isinstance(data, dict):
                raise ProviderError("Model temperature catalog must be an object")
            catalog = {}
            for key, provider in data.items():
                if not isinstance(provider, dict) or not isinstance(provider.get("models"), dict):
                    raise ProviderError(f"Invalid model temperature catalog provider: {key}")
                for name, definition in provider["models"].items():
                    if not isinstance(definition, dict):
                        raise ProviderError(f"Invalid model temperature catalog model: {key}/{name}")
                    value = definition.get("temperature")
                    # fromModelsDevModel uses model.temperature ?? false.
                    if value is None:
                        value = False
                    if type(value) is not bool:
                        raise ProviderError(f"Invalid temperature capability in catalog: {key}/{name}")
                    modalities = definition.get("modalities", {})
                    try:
                        validate_modalities(modalities, f"catalog {key}/{name}.modalities")
                    except ValueError as error:
                        raise ProviderError(str(error)) from error
                    # ModelsDev's schema requires both directions when the
                    # optional modalities object is present (unlike config).
                    if "modalities" in definition and any(direction not in modalities for direction in ("input", "output")):
                        raise ProviderError(f"Invalid modalities capability in catalog: {key}/{name}")
                    catalog[key, name] = {"temperature": value, **{
                        direction: {kind: kind in modalities.get(direction, [])
                                    for kind in ("text", "audio", "image", "video", "pdf")}
                        for direction in ("input", "output")
                    }}
            _check_abort(signal)
            _temperature_catalog = catalog
        return _temperature_catalog.get((provider_id, model))
    finally:
        _temperature_catalog_lock.release()


def _raise_http_error(response, url: str, message: str) -> None:
    # Preserve transport metadata through Python's existing exception chain,
    # without adding provider-result or persisted message fields.
    cause = httpx.HTTPStatusError(message, request=httpx.Request("POST", url), response=response)
    raise ProviderError(message) from cause


def _stream(url, headers, body, timeout, consume, abort_event):
    if abort_event is None:
        with httpx.Client(timeout=timeout) as client:
            with client.stream("POST", url, headers=headers, json=body) as response:
                if response.status_code >= 400:
                    raw = response.read().decode("utf-8", "replace")
                    _raise_http_error(response, url, f"{response.status_code}: {raw[:2000]}")
                for line in response.iter_lines():
                    if consume(line) is False:
                        break
        return

    async def request():
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, headers=headers, json=body) as response:
                if response.status_code >= 400:
                    raw = (await response.aread()).decode("utf-8", "replace")
                    _raise_http_error(response, url, f"{response.status_code}: {raw[:2000]}")
                async for line in response.aiter_lines():
                    _check_abort(abort_event)
                    if consume(line) is False:
                        break

    _run_cancellable(request, abort_event)


def _check_completion(completion: Completion) -> Completion:
    # The processor records every finish reason, including length and empty
    # responses. The session loop owns terminal/error interpretation.
    return completion


def _finish_reason(reason: str | None, *, anthropic: bool = False) -> str:
    # AI SDK provider reasons enter the session through LLMAISDK.finishReason.
    # Unsupported/missing reasons become unknown, not transport failures.
    if anthropic:
        return {"end_turn": "stop", "stop_sequence": "stop", "pause_turn": "stop",
                "max_tokens": "length", "tool_use": "tool-calls", "refusal": "content-filter"}.get(reason, "unknown")
    return {"stop": "stop", "length": "length", "content_filter": "content-filter",
            "function_call": "tool-calls", "tool_calls": "tool-calls"}.get(reason, "unknown")


def request_timeout() -> httpx.Timeout:
    """How long one model request may wait for data and for the connection: config/runtime.json."""
    return httpx.Timeout(float(runtime_settings.get("model_request.timeout_s")),
                         connect=float(runtime_settings.get("model_request.connect_timeout_s")))


def _retry_delay(error: ProviderError, attempt: int, provider_id: str = "") -> float | None:
    """SessionRetry's transient-error selection and delay, in seconds."""
    text = str(error)
    lower = text.lower()
    cause = error.__cause__
    response = cause.response if isinstance(cause, httpx.HTTPStatusError) else None
    match = re.match(r"^(?:[\w.-]+\s+)?(\d{3}):", text)
    status = response.status_code if response is not None else (int(match[1]) if match else None)
    if status == 413 or any(marker in lower for marker in (
        "context_length_exceeded", "maximum context length", "context window exceeded",
        "prompt is too long", "input is too long", "request_too_large",
    )):
        return None
    retryable = status in {408, 409, 429} or (status is not None and status >= 500)
    retryable = retryable or (status == 404 and provider_id.startswith("openai"))
    if status is None:
        cause = error.__cause__
        retryable = isinstance(cause, (httpx.NetworkError, httpx.RemoteProtocolError, httpx.DecodingError))
        retryable = retryable or (isinstance(cause, httpx.TimeoutException) and not isinstance(cause, httpx.PoolTimeout))
        retryable = retryable or any(marker in lower for marker in ("rate increased too quickly", "rate limit", "too many requests"))
        try:
            detail = json.loads(text)
        except (ValueError, TypeError):
            detail = None
        if isinstance(detail, dict):
            code = detail.get("code")
            inner = detail.get("error") if isinstance(detail.get("error"), dict) else {}
            retryable = retryable or (isinstance(code, str) and any(value in code for value in ("exhausted", "unavailable")))
            if detail.get("type") == "error":
                retryable = retryable or inner.get("type") == "too_many_requests" or "rate_limit" in str(inner.get("code", ""))
    if not retryable:
        return None
    headers = getattr(response, "headers", None) if response is not None else None
    limit = 2_147_483.647
    if headers is not None:
        for key, divisor in (("retry-after-ms", 1000), ("retry-after", 1)):
            value = headers.get(key)
            if not value:
                continue
            try:
                numeric = re.match(r"^[\s]*([+-]?(?:Infinity|(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?))", value)
                if numeric is None:
                    raise ValueError
                delay = float(numeric[1]) / divisor
                if key == "retry-after" and math.isfinite(delay):
                    delay = math.ceil(delay * 1000) / 1000
                return max(0, min(delay, limit))
            except (ValueError, OverflowError):
                if key == "retry-after":
                    try:
                        delay = (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds()
                        if delay > 0:
                            return min(math.ceil(delay * 1000) / 1000, limit)
                    except (TypeError, ValueError, OverflowError):
                        pass
        return min(2.0 ** min(attempt, 22), limit)
    return min(2.0 ** min(attempt, 5), 30)


class Client:
    def __init__(self, auth: AuthStore, config: dict):
        self.auth = auth
        self.config = config
        self.providers = self._assemble()

    def _assemble(self) -> dict[str, ProviderInfo]:
        providers = {
            key: ProviderInfo(
                id=value.id,
                api=value.api,
                name=value.name,
                base_url=value.base_url,
                env=list(value.env),
                models=list(value.models),
                default_model=value.default_model,
                api_key=value.api_key,
                context=value.context,
            )
            for key, value in BUILTIN.items()
        }
        configured = self.config.get("provider") or {}
        if isinstance(configured, dict):
            for provider_id, raw in configured.items():
                if not isinstance(raw, dict):
                    continue
                current = providers.get(provider_id)
                options = raw.get("options") or {}
                models_raw = raw.get("models") or {}
                model_ids = list(models_raw) if isinstance(models_raw, dict) else []
                api = _api_from_npm(raw.get("npm"), raw.get("api") or (options.get("api") if isinstance(options, dict) else None))
                base = None
                key = None
                if isinstance(options, dict):
                    base = options.get("baseURL") or options.get("baseUrl")
                    key = options.get("apiKey")
                if api == "google" and not base:
                    api = "openai"
                    base = "https://generativelanguage.googleapis.com/v1beta/openai"
                providers[provider_id] = ProviderInfo(
                    id=provider_id,
                    api=api if api != "google" else "openai",
                    name=raw.get("name") or (current.name if current else provider_id),
                    base_url=(base or (current.base_url if current else "")).rstrip("/"),
                    env=list(raw.get("env") or (current.env if current else [])),
                    models=model_ids or (current.models if current else []),
                    default_model=(model_ids[0] if model_ids else (current.default_model if current else None)),
                    api_key=key or (current.api_key if current else None),
                    context=current.context if current else 128_000,
                )
        disabled = set(self.config.get("disabled_providers") or [])
        enabled = self.config.get("enabled_providers")
        if enabled:
            allowed = set(enabled)
            providers = {key: value for key, value in providers.items() if key in allowed}
        for name in disabled:
            providers.pop(name, None)
        return providers

    def key_for(self, provider: ProviderInfo) -> str | None:
        if provider.api_key:
            return provider.api_key
        env_key = self.auth.get(provider.id)
        if env_key:
            return env_key
        for name in provider.env:
            value = os.environ.get(name)
            if value:
                return value
        return None

    def available(self) -> list[ProviderInfo]:
        ready = []
        for provider in self.providers.values():
            if provider.id == "ollama" or self.key_for(provider):
                ready.append(provider)
        return ready

    def resolve(self, model: str | None) -> tuple[ProviderInfo, str]:
        chosen = model or os.environ.get("OPENCODE_MODEL") or self.config.get("model")
        if chosen and "/" in chosen:
            provider_id, model_id = chosen.split("/", 1)
            provider = self.providers.get(provider_id)
            if provider is None:
                raise ProviderError(f"Unknown provider '{provider_id}'. Known: {', '.join(sorted(self.providers))}")
            return self._model_provider(provider, model_id), model_id
        if chosen and chosen in self.providers:
            provider = self.providers[chosen]
            if not provider.default_model:
                raise ProviderError(f"Provider '{chosen}' has no default model. Set model to provider/model.")
            return self._model_provider(provider, provider.default_model), provider.default_model
        for provider in self.available():
            if provider.default_model:
                return self._model_provider(provider, provider.default_model), provider.default_model
        raise ProviderError(
            "No model is configured. Set model in opencode.json (provider/model) or export an API key "
            "(OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, ...)."
        )

    def _model_config(self, provider_id: str, model: str) -> dict:
        return ((self.config.get("provider") or {}).get(provider_id, {}).get("models") or {}).get(model, {})

    def _model_provider(self, provider: ProviderInfo, model: str) -> ProviderInfo:
        context = (self._model_config(provider.id, model).get("limit") or {}).get("context", provider.context)
        if isinstance(context, bool) or not isinstance(context, int) or context < 0:
            raise ProviderError("Model context limit must be a nonnegative integer")
        return replace(provider, context=context)

    def output_limit(self, provider: ProviderInfo, model: str) -> int:
        limits = self._model_config(provider.id, model).get("limit") or {}
        value = limits.get("output", 32000)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ProviderError("Model output limit must be a nonnegative integer")
        return min(value, 32000) or 32000

    def _temperature(self, provider: ProviderInfo, model: str, value: float | None,
                     abort_event: threading.Event | None) -> float | None:
        definition = self._model_config(provider.id, model)
        explicit = "temperature" in definition
        if explicit and type(definition["temperature"]) is not bool:
            raise ProviderError("Model temperature capability must be a boolean")
        if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)):
            raise ProviderError("Temperature must be a finite number or omitted")
        candidate = value if value is not None else _default_temperature(model)
        if candidate is None or (explicit and definition["temperature"] is False):
            return None
        capable = definition["temperature"] if explicit else _catalog_temperature(provider.id, model, abort_event)
        return candidate if capable else None

    def _modalities(self, provider: ProviderInfo, model: str, direction: str,
                    abort_event: threading.Event | None = None) -> dict[str, bool]:
        definition = self._model_config(provider.id, model)
        modalities = definition.get("modalities", {})
        try:
            validate_modalities(modalities)
        except ValueError as error:
            raise ProviderError(str(error)) from error
        if direction in modalities:
            return {kind: kind in modalities[direction] for kind in ("text", "audio", "image", "video", "pdf")}
        # Use the provider/model actually sent on the wire. Config alias ID
        # resolution is not implemented by the current Python provider.
        existing = _catalog_model(provider.id, model, abort_event)
        if existing is not None:
            return dict(existing[direction])
        return {kind: kind == "text" for kind in ("text", "audio", "image", "video", "pdf")}

    def _prepare_messages(self, provider: ProviderInfo, model: str, messages: list[dict],
                          abort_event: threading.Event | None = None) -> list[dict]:
        """Apply unsupportedParts at the request boundary without editing history."""
        capabilities = None

        def prepare(part):
            nonlocal capabilities
            if not isinstance(part, dict):
                return part
            kind = part.get("type")
            filename = None
            if kind == "image_url":
                image = part.get("image_url")
                url = image.get("url", "") if isinstance(image, dict) else ""
                if not isinstance(url, str):
                    return part
                if re.fullmatch(r"data:([^;]+);base64,", url):
                    return {"type": "text", "text": "ERROR: Image file is empty or corrupted. Please provide a valid image."}
            elif kind == "file":
                file = part.get("file")
                if not isinstance(file, dict):
                    return part
                url = file.get("file_data", "")
                filename = file.get("filename")
                if not isinstance(url, str):
                    return part
            else:
                return part
            mime = None
            if url.startswith("data:"):
                match = re.match(r"data:([^;,]+)[;,]", url)
                if match:
                    mime = match[1]
            elif kind == "file" and url.startswith(("https://", "http://")):
                # openai_media_part creates file objects only for declared PDF
                # attachments; preserve that contract for remote PDF URLs.
                mime = "application/pdf"
            modality = "pdf" if mime == "application/pdf" else "image" if mime and mime.startswith("image/") else None
            if modality is None:
                return part
            if capabilities is None:
                capabilities = self._modalities(provider, model, "input", abort_event)
            if capabilities[modality]:
                return part
            name = f'"{filename}"' if filename else modality
            return {"type": "text", "text": f"ERROR: Cannot read {name} (this model does not support {modality} input). Inform the user."}

        return [{**message, "content": [prepare(part) for part in message["content"]]}
                if message.get("role") == "user" and isinstance(message.get("content"), list) else message
                for message in messages]

    def complete(
        self,
        *,
        provider: ProviderInfo,
        model: str,
        system: str,
        messages: list[dict],
        tools: list[dict] | None = None,
        temperature: float | None = None,
        on_text=None,
        on_update=None,
        on_tool_call=None,
        on_attempt=None,
        abort_event: threading.Event | None = None,
    ) -> Completion:
        _check_abort(abort_event)
        key = self.key_for(provider)
        if not key and provider.id != "ollama":
            raise ProviderError(f"Missing API key for provider '{provider.id}'.")
        temperature = self._temperature(provider, model, temperature, abort_event)
        # Like temperature preparation, catalog failures must not enter the
        # model-response retry loop. Direct protocol callers also prepare below.
        messages = self._prepare_messages(provider, model, messages, abort_event)
        attempt = 0
        callback_lock = threading.Lock()
        while True:
            _check_abort(abort_event)
            request_abort = _RequestAbort(abort_event) if on_tool_call is not None or on_attempt is not None else abort_event
            tool_futures, tool_failures, dispatched = [], [], set()

            def finished_tool(future, failures=tool_failures, cancel=request_abort):
                try:
                    error = future.exception()
                except BaseException as failure:
                    error = failure
                if error is not None:
                    with callback_lock:
                        failures.append(error)
                    cancel.set()

            def dispatch(call):
                if call.id in dispatched:
                    return
                dispatched.add(call.id)
                try:
                    future = on_tool_call(call)
                except Exception as error:
                    raise ProviderError(str(error)) from error
                if isinstance(future, Future):
                    tool_futures.append(future)
                    future.add_done_callback(finished_tool)

            try:
                if on_attempt is not None:
                    on_attempt(attempt, request_abort)
                updates = {"on_update": on_update} if on_update is not None else {}
                if on_tool_call is not None:
                    updates["on_tool_call"] = dispatch
                if provider.api == "anthropic":
                    result = self._anthropic(
                        provider, key or "", model, system, messages, tools or [], temperature, on_text,
                        abort_event=request_abort, **updates,
                    )
                else:
                    result = self._openai(provider, key or "ollama", model, system, messages, tools or [], temperature, on_text,
                                          abort_event=request_abort, **updates)
                if on_tool_call is not None:
                    for call in result.tool_calls:
                        dispatch(call)
                    for future in tool_futures:
                        while True:
                            _check_abort(request_abort, replace(result, finish_reason=None))
                            try:
                                future.result(timeout=0.05)
                                break
                            except FutureTimeout as error:
                                if future.done():
                                    raise ProviderError(str(error), replace(result, finish_reason=None)) from error
                                continue
                            except Exception as error:
                                raise ProviderError(str(error), replace(result, finish_reason=None)) from error
                _check_abort(abort_event, result)
                if on_update is not None:
                    on_update(result)
                return result
            except (ProviderError, httpx.HTTPError) as original:
                if isinstance(request_abort, _RequestAbort):
                    # LLM.Stream.scoped releases its signal before SessionRetry
                    # waits, so old cooperative tools stop during backoff.
                    request_abort.set()
                exc = original if isinstance(original, ProviderError) else ProviderError(str(original))
                if exc is not original:
                    exc.__cause__ = original
                partial = exc.partial
                _check_abort(abort_event, partial)
                if tool_failures:
                    raise ProviderError(str(tool_failures[0]), partial) from tool_failures[0]
                attempt += 1
                delay = _retry_delay(exc, attempt, provider.id)
                if delay is not None:
                    if abort_event is None:
                        time.sleep(delay)
                    elif abort_event.wait(delay):
                        _check_abort(abort_event, partial)
                    continue
                raise exc
            finally:
                if isinstance(request_abort, _RequestAbort):
                    request_abort.set()

    def _openai(self, provider, key, model, system, messages, tools, temperature, on_text, *, abort_event=None,
                on_update=None, on_tool_call=None, response_format=None) -> Completion:
        messages = self._prepare_messages(provider, model, messages, abort_event)
        payload_messages = []
        if system:
            payload_messages.append({"role": "system", "content": _sanitize_text(system)})
        interleaved = self._model_config(provider.id, model).get("interleaved")
        if interleaved not in (None, False) and interleaved not in (
                {"field": "reasoning_content"}, {"field": "reasoning"}):
            raise ProviderError("Supported interleaved field: reasoning_content or reasoning")
        for message in messages:
            item = {k: v for k, v in message.items() if k not in {"reasoning_content", "reasoning"}}
            if isinstance(item.get("content"), str):
                item["content"] = _sanitize_text(item["content"])
            elif isinstance(item.get("content"), list):
                item["content"] = [dict(part, text=_sanitize_text(part["text"]))
                                   if part.get("type") == "text" else part for part in item["content"]]
            if interleaved and item.get("role") == "assistant":
                # Empty is a protocol placeholder, never reconstructed reasoning.
                item[interleaved["field"]] = _sanitize_text(_reasoning_text(message) or "")
            elif item.get("role") == "assistant" and _reasoning_text(message):
                # The pinned AI SDK converter also lowers ordinary reasoning
                # parts when no interleaved-field transform was configured.
                item["reasoning_content"] = _sanitize_text(_reasoning_text(message))
            payload_messages.append(item)
        body: dict = {"model": model, "messages": payload_messages}
        body["max_tokens"] = self.output_limit(provider, model)
        options = self._model_config(provider.id, model).get("options") or {}
        if "top_p" in options:
            body["top_p"] = options["top_p"]
        if "seed" in options:
            # Some local servers reuse one fixed seed when none is sent, so repeated runs
            # of the same input are identical; an explicit seed makes repeats meaningful.
            # "random" draws a new seed for every request, so a retry of the same input
            # is a new sample instead of the same reply again.
            body["seed"] = random.randrange(2**31) if options["seed"] == "random" else options["seed"]
        # The pinned compatible SDK overwrites the snake_case option with the
        # validated camelCase value, omitting it when that value is absent.
        if "reasoningEffort" in options:
            effort = options["reasoningEffort"]
            if not isinstance(effort, str):
                raise ProviderError("reasoningEffort must be a string")
            body["reasoning_effort"] = effort
        if tools:
            body["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": tool["name"],
                        "description": tool["description"],
                        "parameters": tool["parameters"],
                    },
                }
                for tool in tools
            ]
        if temperature is not None:
            body["temperature"] = temperature
        if response_format is not None:
            # Generation-time output constraint (OpenAI-compatible json_schema).
            body["response_format"] = response_format
        timeout = request_timeout()
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        url = provider.base_url.rstrip("/") + "/chat/completions"
        if on_text or on_update or on_tool_call:
            body["stream"] = True
            if options.get("include_stream_usage", True):
                body["stream_options"] = {"include_usage": True}
            return self._openai_stream(url, headers, body, timeout, model, on_text,
                                       abort_event=abort_event, on_update=on_update, on_tool_call=on_tool_call)
        response = _post(url, headers, body, timeout, abort_event)
        if response.status_code >= 400:
            _raise_http_error(response, url, f"{provider.id} {response.status_code}: {response.text[:2000]}")
        data = _response_json(response)
        choices = data.get("choices") if isinstance(data, dict) else None
        if (not isinstance(choices, list) or not choices or not isinstance(choices[0], dict)
                or not isinstance(choices[0].get("message"), dict)):
            raise ProviderError("Model response is missing a completion message")
        choice = choices[0]
        message = choice["message"]
        calls = []
        for call in message.get("tool_calls") or []:
            function = call.get("function") or {}
            calls.append(
                ToolCall(
                    id=call.get("id") or f"call_{len(calls)}",
                    name=function.get("name") or "",
                    arguments=_parse_args(function.get("arguments"), strict=True),
                )
            )
        return _check_completion(Completion(
            text=message.get("content") or "",
            tool_calls=calls,
            usage=data.get("usage") or {},
            model=model,
            finish_reason=_finish_reason(choice.get("finish_reason")),
            reasoning_content=_reasoning_text(message),
        ))

    def _openai_stream(self, url, headers, body, timeout, model, on_text, *, abort_event=None,
                       on_update=None, on_tool_call=None) -> Completion:
        text_parts: list[str] = []
        reasoning_parts: list[str] = []
        calls: dict[int, dict] = {}
        usage: dict = {}
        finish_reason = None
        def consume(line):
            nonlocal usage, finish_reason
            ready = []
            if not line or not line.startswith("data:"):
                return
            data = line[len("data:") :].strip()
            if data == "[DONE]":
                return False
            try:
                event = json.loads(data)
            except json.JSONDecodeError as error:
                raise ProviderError("Invalid JSON in model stream", snapshot()) from error
            if not isinstance(event, dict):
                raise ProviderError("Model stream event must be an object", snapshot())
            if event.get("error"):
                error = event["error"]
                message = error.get("message") if isinstance(error, dict) else str(error)
                raise ProviderError(message or str(error), snapshot())
            if event.get("usage"):
                usage = event["usage"]
            for choice in (event.get("choices") or [])[:1]:
                if choice.get("finish_reason"):
                    finish_reason = _finish_reason(choice["finish_reason"])
                delta = choice.get("delta") or {}
                reasoning = _reasoning_text(delta)
                if reasoning is not None:
                    reasoning_parts.append(reasoning)
                piece = delta.get("content") or ""
                if piece:
                    text_parts.append(piece)
                    if on_text:
                        on_text(piece)
                for call in delta.get("tool_calls") or []:
                    index = call.get("index", len(calls))
                    function = call.get("function") or {}
                    if index not in calls:
                        if not isinstance(call.get("id"), str) or not isinstance(function.get("name"), str):
                            raise ProviderError("Model tool call is missing id or function.name", snapshot())
                        calls[index] = {"id": call["id"], "name": function["name"], "arguments": "", "finished": False}
                    slot = calls[index]
                    if slot["finished"]:
                        continue
                    if function.get("arguments"):
                        slot["arguments"] += function["arguments"]
                    try:
                        json.loads(slot["arguments"])
                        slot["finished"] = True
                        ready.append(ToolCall(slot["id"], slot["name"], _parse_args(slot["arguments"])))
                    except (ValueError, TypeError):
                        pass
            if on_update is not None:
                on_update(snapshot())
            if on_tool_call is not None:
                for call in ready:
                    on_tool_call(call)

        def snapshot(*, strict=False):
            return Completion(
                text="".join(text_parts),
                tool_calls=[
                    ToolCall(id=slot["id"], name=slot["name"], arguments=_parse_args(slot["arguments"], strict=strict))
                    for index, slot in sorted(calls.items())
                ],
                usage=usage,
                model=model,
                finish_reason=finish_reason if strict else None,
                reasoning_content="".join(reasoning_parts) if reasoning_parts else None,
            )

        try:
            _stream(url, headers, body, timeout, consume, abort_event)
            if on_tool_call is not None:
                for slot in calls.values():
                    if not slot["finished"]:
                        on_tool_call(ToolCall(slot["id"], slot["name"], _parse_args(slot["arguments"])))
            completion = snapshot(strict=True)
        except ProviderError as error:
            _check_abort(abort_event, snapshot())
            if error.partial is None:
                error.partial = snapshot()
            raise
        except httpx.HTTPError as error:
            raise ProviderError(str(error), snapshot()) from error
        if completion.finish_reason is None:
            completion.finish_reason = "unknown"
        return _check_completion(completion)

    def _anthropic(self, provider, key, model, system, messages, tools, temperature, on_text, *, abort_event=None,
                   on_update=None, on_tool_call=None) -> Completion:
        messages = self._prepare_messages(provider, model, messages, abort_event)
        body: dict = {
            "model": model,
            "max_tokens": self.output_limit(provider, model),
            "messages": _anthropic_messages(messages),
        }
        if system:
            body["system"] = _sanitize_text(system)
        if tools:
            body["tools"] = [
                {"name": tool["name"], "description": tool["description"], "input_schema": tool["parameters"]}
                for tool in tools
            ]
        if temperature is not None:
            body["temperature"] = temperature
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        url = provider.base_url.rstrip("/") + "/messages"
        timeout = request_timeout()
        if on_text or on_update or on_tool_call:
            body["stream"] = True
            return self._anthropic_stream(url, headers, body, timeout, model, on_text,
                                          abort_event=abort_event, on_update=on_update, on_tool_call=on_tool_call)
        response = _post(url, headers, body, timeout, abort_event)
        if response.status_code >= 400:
            _raise_http_error(response, url, f"{provider.id} {response.status_code}: {response.text[:2000]}")
        data = _response_json(response)
        if not isinstance(data, dict) or not isinstance(data.get("content"), list):
            raise ProviderError("Model response is missing completion content")
        text: list[str] = []
        reasoning: list[str] = []
        calls: list[ToolCall] = []
        for block in data.get("content") or []:
            if block.get("type") == "text":
                text.append(block.get("text") or "")
            elif block.get("type") == "thinking":
                reasoning.append(block.get("thinking") or "")
            elif block.get("type") == "tool_use":
                calls.append(
                    ToolCall(
                        id=block.get("id") or f"call_{len(calls)}",
                        name=block.get("name") or "",
                        arguments=_parse_args(block.get("input"), strict=True),
                    )
                )
        return _check_completion(Completion(text="".join(text), tool_calls=calls, usage=data.get("usage") or {}, model=model,
                                            finish_reason=_finish_reason(data.get("stop_reason"), anthropic=True),
                                            reasoning_content="".join(reasoning) if reasoning else None))

    def _anthropic_stream(self, url, headers, body, timeout, model, on_text, *, abort_event=None,
                          on_update=None, on_tool_call=None) -> Completion:
        text: list[str] = []
        reasoning: list[str] = []
        blocks: dict[int, dict] = {}
        usage: dict = {}
        finish_reason = None

        def consume(line):
            nonlocal usage, finish_reason
            if not line.startswith("data:"):
                return
            data = line[len("data:") :].strip()
            try:
                event = json.loads(data)
            except json.JSONDecodeError as error:
                raise ProviderError("Invalid JSON in model stream", snapshot()) from error
            if not isinstance(event, dict):
                raise ProviderError("Model stream event must be an object", snapshot())
            kind = event.get("type")
            if kind == "message_start":
                usage = (event.get("message") or {}).get("usage") or usage
            elif kind == "content_block_start":
                index = event.get("index", 0)
                block = event.get("content_block") or {}
                blocks[index] = {
                    "type": block.get("type"),
                    "id": block.get("id"),
                    "name": block.get("name"),
                    "text": block.get("text") or "",
                    "input": json.dumps(block["input"]) if block.get("input") else "",
                }
                if block.get("type") == "thinking" and block.get("thinking") is not None:
                    reasoning.append(block["thinking"])
                if block.get("type") == "text" and block.get("text"):
                    text.append(block["text"])
                    if on_text:
                        on_text(block["text"])
            elif kind == "content_block_delta":
                index = event.get("index", 0)
                slot = blocks.setdefault(index, {"type": "text", "text": "", "input": ""})
                delta = event.get("delta") or {}
                if delta.get("type") == "text_delta":
                    piece = delta.get("text") or ""
                    slot["text"] = slot.get("text", "") + piece
                    text.append(piece)
                    if on_text:
                        on_text(piece)
                elif delta.get("type") == "thinking_delta":
                    reasoning.append(delta.get("thinking") or "")
                elif delta.get("type") == "input_json_delta":
                    if slot.get("input") == "{}":
                        slot["input"] = ""
                    slot["input"] = slot.get("input", "") + (delta.get("partial_json") or "")
            elif kind == "message_delta":
                reason = (event.get("delta") or {}).get("stop_reason")
                if reason is not None:
                    finish_reason = _finish_reason(reason, anthropic=True)
                extra = event.get("usage") or {}
                usage = {**usage, **extra}
            elif kind == "content_block_stop":
                block = blocks.get(event.get("index", 0), {})
                if block.get("type") == "tool_use" and on_tool_call is not None:
                    on_tool_call(ToolCall(block.get("id") or "", block.get("name") or "",
                                          _parse_args(block.get("input") or {})))
            elif kind == "error":
                error = event.get("error") or {}
                raise ProviderError(error.get("message") or str(error), snapshot())
            if on_update is not None:
                on_update(snapshot())

        def snapshot(*, strict=False):
            calls = []
            for index in sorted(blocks):
                block = blocks[index]
                if block.get("type") == "tool_use":
                    calls.append(
                        ToolCall(
                            id=block.get("id") or f"call_{index}",
                            name=block.get("name") or "",
                            arguments=_parse_args(block.get("input") or {}, strict=strict),
                        )
                    )
            return Completion(text="".join(text), tool_calls=calls, usage=usage, model=model,
                              finish_reason=finish_reason if strict else None, reasoning_content="".join(reasoning) if reasoning else None)

        try:
            _stream(url, headers, body, timeout, consume, abort_event)
            completion = snapshot(strict=True)
        except ProviderError as error:
            _check_abort(abort_event, snapshot())
            if error.partial is None:
                error.partial = snapshot()
            raise
        except httpx.HTTPError as error:
            raise ProviderError(str(error), snapshot()) from error
        if completion.finish_reason is None:
            completion.finish_reason = "unknown"
        return _check_completion(completion)


def _response_json(response):
    try:
        return response.json()
    except ValueError as error:
        raise ProviderError("Invalid JSON in model response") from error


def _reasoning_text(message: dict) -> str | None:
    # Official DeepSeek and vLLM use different wire names for the same text.
    value = message.get("reasoning_content")
    return value if value is not None else message.get("reasoning")


def _sanitize_text(text: str) -> str:
    # Match ProviderTransform.sanitizeSurrogates before JSON transport.
    return text.encode("utf-16-le", errors="surrogatepass").decode("utf-16-le", errors="replace")


class _InvalidArguments(dict):
    """Keep parse diagnostics in memory without adding serialized tool fields."""

    def __init__(self, value, error):
        super().__init__(value)
        self.error = error


def tool_call_error(call: ToolCall) -> str | None:
    return call.arguments.error if isinstance(call.arguments, _InvalidArguments) else None


def repair_tool_calls(completion: Completion, tools: list[dict] | None) -> Completion:
    """Apply the source's one repair attempt before tool persistence/execution."""
    available = {tool["name"]: tool for tool in tools or []}

    def error_for(call, name):
        if name not in available:
            return f"Model tried to call unavailable tool '{name}'. Available tools: {', '.join(available)}."
        error = tool_call_error(call)
        if error is None:
            try:
                validate_arguments(call.arguments, available[name]["parameters"])
            except ValidationError as failure:
                error = failure.message
        return f"Invalid input for tool {name}: {error}" if error else None

    repaired = []
    for call in completion.tool_calls:
        error = error_for(call, call.name)
        if error is None:
            repaired.append(call)
            continue
        lower = call.name.lower()
        if lower != call.name and lower in available:
            # AI SDK reparses once. A failed lowercase repair remains an error
            # for the original call; it does not invoke repair a second time.
            after_repair = error_for(call, lower)
            repaired.append(ToolCall(call.id, call.name if after_repair else lower,
                            _InvalidArguments(call.arguments, after_repair) if after_repair else call.arguments))
        else:
            repaired.append(ToolCall(call.id, "invalid", {"tool": call.name, "error": error}))
    return replace(completion, tool_calls=repaired)


def _parse_args(raw, *, strict=False) -> dict:
    if isinstance(raw, dict):
        return raw
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {}
    if not isinstance(raw, str):
        return _InvalidArguments({"value": raw}, "Tool arguments must be an object")
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return _InvalidArguments({"_raw": raw}, "Tool arguments are not valid JSON")
    return parsed if isinstance(parsed, dict) else _InvalidArguments({"value": parsed}, "Tool arguments must be an object")


def _anthropic_messages(messages: list[dict]) -> list[dict]:
    converted = []
    for message in messages:
        role = message.get("role")
        if role == "tool":
            converted.append(
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": message.get("tool_call_id"),
                            "content": _sanitize_text(message.get("content") or ""),
                        }
                    ],
                }
            )
            continue
        if role == "assistant" and message.get("tool_calls"):
            content = []
            if message.get("content"):
                content.append({"type": "text", "text": _sanitize_text(message["content"])})
            for call in message["tool_calls"]:
                name, arguments = _tool_call_parts(call)
                content.append(
                    {
                        "type": "tool_use",
                        "id": call["id"],
                        "name": name,
                        "input": arguments,
                    }
                )
            converted.append({"role": "assistant", "content": content})
            continue
        content = message.get("content") or ""
        if isinstance(content, list):
            blocks = _anthropic_blocks(content)
            if blocks:
                converted.append({"role": role, "content": blocks})
            continue
        if content:
            converted.append({"role": role, "content": _sanitize_text(content)})
    return _merge_roles(converted)


def _tool_call_parts(call: dict) -> tuple[str, dict]:
    function = call.get("function")
    if isinstance(function, dict):
        arguments = function.get("arguments")
        if isinstance(arguments, str):
            arguments = _parse_args(arguments)
        return function.get("name") or "", arguments or {}
    arguments = call.get("arguments") if "arguments" in call else call.get("input")
    if isinstance(arguments, str):
        arguments = _parse_args(arguments)
    return call.get("name") or "", arguments or {}


def _anthropic_blocks(parts: list) -> list:
    blocks = []
    for part in parts:
        if not isinstance(part, dict):
            continue
        if part.get("type") == "text":
            if part.get("text"):
                blocks.append({"type": "text", "text": _sanitize_text(part["text"])})
            continue
        if part.get("type") == "image_url":
            url = (part.get("image_url") or {}).get("url") or ""
            block = anthropic_media_block({"mime": "image/png", "url": url})
            if block:
                blocks.append(block)
            continue
        if part.get("type") == "file":
            file_info = part.get("file") or {}
            block = anthropic_media_block(
                {"mime": "application/pdf", "url": file_info.get("file_data") or "", "filename": file_info.get("filename")}
            )
            if block:
                blocks.append(block)
    return blocks


def _merge_roles(messages: list[dict]) -> list[dict]:
    merged: list[dict] = []
    for message in messages:
        if merged and merged[-1]["role"] == message["role"] == "user" and isinstance(merged[-1]["content"], list):
            content = message["content"]
            if isinstance(content, list):
                merged[-1]["content"].extend(content)
                continue
        merged.append(message)
    return merged


def ordered_history(history: list[dict]) -> list[dict]:
    """Keep tool replies adjacent when a background notification arrives mid-batch."""
    results = {}
    for index, message in enumerate(history):
        if message.get("role") == "tool":
            results.setdefault(message.get("tool_call_id"), []).append((index, message))
    consumed = set()
    ordered = []
    for index, message in enumerate(history):
        if index in consumed:
            continue
        ordered.append(message)
        consumed.add(index)
        for call in message.get("tool_calls") or []:
            replies = results.get(call["id"], [])
            while replies and replies[0][0] in consumed:
                replies.pop(0)
            if replies:
                position, result = replies.pop(0)
                ordered.append(result)
                consumed.add(position)
    return ordered


def openai_messages_from_history(history: list[dict], *, include_reasoning: bool = True,
                                 model_ref: str | None = None) -> list[dict]:
    """Convert stored session messages into OpenAI chat messages.

    Tool results stay text. Images and PDFs are appended as a user message because
    OpenAI-compatible tool messages only accept a string.
    """
    output = []
    pending_media: list[dict] = []
    skipped_calls = {}

    def flush_media() -> None:
        if not pending_media:
            return
        output.append(
            {
                "role": "user",
                "content": [{"type": "text", "text": SYNTHETIC_ATTACHMENT_PROMPT}, *pending_media],
            }
        )
        pending_media.clear()

    for message in ordered_history(history):
        role = "assistant" if message.get("compaction_through") else message.get("role")
        if role == "assistant" and message.get("error") and not (
                message["error"] == "aborted" and (message.get("content") or message.get("tool_calls"))):
            for call in message.get("tool_calls") or []:
                skipped_calls[call["id"]] = skipped_calls.get(call["id"], 0) + 1
            continue
        if role == "tool" and skipped_calls.get(message.get("tool_call_id"), 0):
            skipped_calls[message.get("tool_call_id")] -= 1
            continue
        if role != "tool":
            flush_media()
        if message.get("compaction_through"):
            # V1 presents its compaction request before the summary. This
            # generated request is not another human turn in session storage.
            output.append({"role": "user", "content": "What did we do so far?"})
        if role == "user":
            output.append({"role": "user", "content": _user_content(message)})
        elif role == "assistant":
            item = {"role": "assistant", "content": message.get("content") or ""}
            if include_reasoning and message.get("reasoning_content") is not None:
                reasoning = message["reasoning_content"]
                if model_ref and message.get("model") and message["model"] != model_ref:
                    if reasoning.strip():
                        item["content"] = reasoning + ("\n\n" + item["content"] if item["content"] else "")
                else:
                    item["reasoning_content"] = reasoning
            calls = message.get("tool_calls") or []
            if calls:
                item["tool_calls"] = [
                    {
                        "id": call["id"],
                        "type": "function",
                        "function": {
                            "name": call["name"],
                            "arguments": json.dumps(call.get("arguments") or {}),
                        },
                    }
                    for call in calls
                ]
            output.append(item)
        elif role == "tool":
            compacted = (message.get("metadata") or {}).get("compacted") is not None
            output.append(
                {
                    "role": "tool",
                    "tool_call_id": message.get("tool_call_id"),
                    "content": "[Old tool result content cleared]" if compacted else (message.get("content") or ""),
                }
            )
            for attachment in ([] if compacted else message.get("attachments") or []):
                part = openai_media_part(attachment)
                if part:
                    pending_media.append(part)
    flush_media()
    return output


def _user_content(message: dict):
    text = _text_of(message)
    parts = []
    for attachment in message.get("attachments") or []:
        part = openai_media_part(attachment)
        if part:
            parts.append(part)
    if not parts:
        return text
    content = []
    if text:
        content.append({"type": "text", "text": text})
    content.extend(parts)
    return content


def _text_of(message: dict) -> str:
    if message.get("content"):
        return message["content"]
    parts = message.get("parts") or []
    return "\n".join(part.get("text", "") for part in parts if part.get("type") == "text")
