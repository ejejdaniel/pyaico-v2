"""The review at the end of a round of a task (docs/design_meta_task_zones_20261030_zh-TW.md §10, step 3).

A session is one task and may run for several rounds. When a round ends, a reviewer reads what the
round left, with the task's previous review, and writes two things:

- the next version of the task's review skill: lessons the working agent reads in its later rounds
  (task_skills.write_review; the system prompt carries it, see task_skills.standing);
- framework issues: faults of the framework or the environment, for the people who maintain them.

The reviewer runs no tools. It gets an evidence package in which every item has an id: the commission,
how the round ended, the round's tool calls (failures with their output), its last reply, the task's
sources and skills, the previous review's lessons, and what the caller adds, such as the research
board. Every lesson and issue cites ids from it. An entry that cites none, or an id the package does
not hold, is not written (skill charter article 4). The framework, not the model, turns the ids into
locations the next round can check; a lesson carried over from the previous review keeps the evidence
it had there.

It makes one model call through a function its caller supplies; a reply that fails the format gets one
repair call.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path
import re
import shutil

from opencode import task_skills

SKILL = "lessons-from-earlier-rounds"
CAUSES = ("framework", "environment")
# Beside the review skill: its lessons with their evidence, for the next review. Earlier versions are kept
# in history/ as lessons.<n>.json beside SKILL.<n>.md.
LESSONS_FILE = "lessons.json"
# Bytes for each part of the evidence package; the whole stays far below one model request's limit.
LIMITS = {"commission": 8000, "request": 4000, "answer": 6000, "extra": 12000, "tools": 28000,
          "sources": 20000, "source": 8000, "method": 1500, "detail": 600, "target": 160}
MAX_SOURCES = 60
TEXT_SHARE = 2 / 3  # of the charter's size limit, for the reviewer's own text; the evidence locations take the rest

_ENTRY = {"type": "object", "additionalProperties": False}
_IDS = {"type": "array", "items": {"type": "string"}}
SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["description", "lessons", "dropped", "framework_issues"],
    "properties": {
        "description": {"type": "string"},
        "lessons": {"type": "array", "items": {**_ENTRY, "required": ["lesson", "evidence"],
                                               "properties": {"lesson": {"type": "string"}, "evidence": _IDS}}},
        "dropped": {"type": "array", "items": {**_ENTRY, "required": ["lesson", "reason", "evidence"],
                                               "properties": {"lesson": {"type": "string"},
                                                              "reason": {"type": "string"}, "evidence": _IDS}}},
        "framework_issues": {"type": "array", "items": {
            **_ENTRY, "required": ["issue", "cause", "evidence"],
            "properties": {"issue": {"type": "string"}, "cause": {"type": "string", "enum": list(CAUSES)},
                           "evidence": _IDS}}},
    },
}
FIELDS = {"lessons": ("lesson", "evidence"), "dropped": ("lesson", "reason", "evidence"),
          "framework_issues": ("issue", "cause", "evidence")}


@dataclass(frozen=True)
class Item:
    """One piece of evidence. cites: for a previous lesson, the evidence it had (a citation resolves to it)."""
    id: str
    title: str
    where: str
    text: str
    cites: tuple = ()


def instructions(rules: dict) -> str:
    """The reviewer's system prompt. Its rules are the charter's (articles 1, 3 and 4)."""
    budget = int(rules["max_chars"] * TEXT_SHARE)
    return f"""You are the reviewer between two rounds of one task. A session is one task; it may run for several rounds, and the working agent that ran this round runs the next one. You run no tools and change nothing in the task: you read the evidence package in the user message and reply with one JSON object.

Write two things.

1. lessons: the new version of this task's review skill. The working agent reads it throughout its later rounds, in place of the previous version. Keep the previous lessons that still hold (cite their P id), revise those the new evidence changes, and list in dropped those it overturns, with the reason. P ids name the previous review's lessons in the package; the first review has none, and a lesson's text needs no label of its own. V ids name the checks of the task's verification plan, written before the first round: a lesson may say which of them is still not ready, or that one should change, and why. A lesson tells the working agent what to do differently in this task and why: a step that failed or cost much time and what works instead, an input it misread and what the input says, a check it skipped, a tool it wrote whose known-answer tests do not check what the tool is used for (article 4). A few lessons that change what the next round does are better than many general ones. If nothing in the evidence calls for a lesson, return none.
2. framework_issues: faults that are not the working agent's judgment, for the people who maintain the framework. Cause "framework": a tool or check that misbehaved, guidance that misled, a capability that was missing. Cause "environment": the network, installed software or the machine failed. Add a lesson as well only when the working agent can work around the fault within the rules.

Rules (skill charter {rules['version']}):
- Evidence (article 4): every lesson, dropped lesson and issue cites at least one id from the package, such as T12, S2 or P1. Cite only what the package shows. An entry with no citation, or with an id the package does not hold, is not written.
- Rank (article 1): lessons rank below the commission and below every rule, check, tool contract and scoring definition of the framework. Never relax, replace or reinterpret them, and never change what the commission asks for or how it is judged.
- Facts: claim no work done and no result holding beyond what the evidence shows. Work the round did not reach is not a fault in itself when the round was stopped before it, for example at a stage the person chose; judge the work that was done.
- Size (article 3): the description and all lessons together stay under {budget} characters.
- Language: write in the language and script of the commission (Traditional Chinese when it is written in Traditional Chinese).

Reply with JSON only, in this shape: {{"description": "one sentence: what the next round should take from these lessons", "lessons": [{{"lesson": "...", "evidence": ["T12"]}}], "dropped": [{{"lesson": "...", "reason": "...", "evidence": ["P1", "T30"]}}], "framework_issues": [{{"issue": "...", "cause": "framework", "evidence": ["T7"]}}]}}"""


def _bytes(text: str) -> int:
    return len(text.encode("utf-8"))


def _clip(text: str, limit: int, *, tail: bool = False) -> str:
    data = text.encode("utf-8")
    if len(data) <= limit:
        return text
    if tail:
        return f"(… {len(data) - limit} earlier bytes not shown) " + data[-limit:].decode("utf-8", "ignore")
    return data[:limit].decode("utf-8", "ignore") + f" (… cut; {len(data)} bytes in all)"


def _one_line(value) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, sort_keys=True)
    return " ".join(text.split())


def task_sessions(store, root: str) -> list[dict]:
    """The task's sessions: the top one first, then its subagents' in the order they began."""
    mine = [item for item in store.list_sessions() if task_skills.root_session(store, item["id"]) == root]
    return sorted(mine, key=lambda item: (item["id"] != root, (item.get("time") or {}).get("created") or 0))


_TARGETS = ("command", "filePath", "path", "kind", "name", "pattern", "url", "query", "description")


def _target(arguments) -> str:
    if isinstance(arguments, dict):
        for key in _TARGETS:
            value = arguments.get(key)
            if isinstance(value, str) and value.strip():
                return _one_line(value)
    return _one_line(arguments if arguments is not None else "")


def _failure(message: dict) -> str | None:
    """How a tool reply failed: an error the tool raised, or a command's nonzero exit; None when neither."""
    metadata = message.get("metadata") or {}
    if metadata.get("error"):
        return "error"
    code = metadata.get("exit")
    if isinstance(code, int) and not isinstance(code, bool) and code != 0:
        return f"exit {code}"
    return None


def _receipt(store, session_id: str, message_id: str, directory: Path) -> str:
    """Where the next round can read a call and its reply: the saved receipt in the workspace, if there is one."""
    try:
        path = store.tool_history_path(session_id).parent / f"{message_id}.json"
    except (KeyError, ValueError, OSError):
        path = None
    if path is not None and path.is_file():
        return path.relative_to(directory).as_posix() if path.is_relative_to(directory) else path.as_posix()
    return f"session {session_id}, message {message_id}"


def _calls(store, sessions, since: float, directory: Path) -> list[dict]:
    """This round's tool calls in the task's sessions, in that order."""
    rows = []
    for session in sessions:
        messages = store.messages(session["id"])
        calls = {call["id"]: call for message in messages if message.get("role") == "assistant"
                 for call in message.get("tool_calls") or [] if isinstance(call, dict) and call.get("id")}
        for message in messages:
            if message.get("role") != "tool" or (message.get("created") or 0) < since:
                continue
            call = calls.get(message.get("tool_call_id")) or {}
            rows.append({"session": session, "message": message,
                         "name": message.get("name") or call.get("name") or "unknown",
                         "target": _target(call.get("arguments")), "failure": _failure(message),
                         "where": _receipt(store, session["id"], message.get("id", ""), directory)})
    return rows


def _tool_section(rows: list[dict], root: str, limit: int) -> tuple[str, list[Item]]:
    """The tool calls as lines T1, T2, ...: every failure with its output, the others as space allows.

    Calls left out are counted by tool where they were left out; only the calls shown can be cited."""
    lines = []
    for number, row in enumerate(rows, 1):
        head = f"[T{number}] {row['name']}: {_clip(row['target'], LIMITS['target'])} -> {row['failure'] or 'ok'}"
        detail = ""
        if row["failure"]:
            content = str(row["message"].get("content") or "")
            # A command's output ends with its error; a tool's error message starts with it.
            detail = _clip(content, LIMITS["detail"], tail=row["failure"] != "error")
        lines.append((head, detail))
    failed = [index for index, row in enumerate(rows) if row["failure"]]

    def left():  # each gap between shown calls takes a line
        return limit - 120 * (len(failed) + 1) - sum(_bytes(lines[index][0]) + _bytes(lines[index][1]) + 8
                                                    for index in failed)

    room = left()
    if room < 0:  # too many failures: shorter outputs for all of them
        share = max(80, (limit // 2) // len(failed))
        for index in failed:
            head, detail = lines[index]
            lines[index] = (head, _clip(detail, share, tail=rows[index]["failure"] != "error"))
        room = max(0, left())
    shown = set(failed)
    passed = [index for index, row in enumerate(rows) if not row["failure"]]
    low, high = 0, len(passed) - 1
    while low <= high:  # the round's first and last calls first, then inward
        for index in ((passed[low],) if low == high else (passed[low], passed[high])):
            size = _bytes(lines[index][0]) + 1
            if size > room:
                low, high = 1, 0
                break
            room -= size
            shown.add(index)
        else:
            low, high = low + 1, high - 1
    text, items, gap, session = [], [], [], None

    def close_gap():
        if gap:
            counts = Counter(rows[index]["name"] for index in gap)
            text.append(f"(T{gap[0] + 1}–T{gap[-1] + 1}: {len(gap)} calls without failure not shown: "
                        + ", ".join(f"{name} {count}" for name, count in counts.most_common()) + ")")
            gap.clear()

    for index, row in enumerate(rows):
        if row["session"]["id"] != session:
            close_gap()
            session = row["session"]["id"]
            label = "the task's top session" if session == root else \
                f"a subagent session ({_one_line(row['session'].get('title') or row['session'].get('agent') or '')})"
            text.append(f"Session {session}, {label}:")
        if index not in shown:
            gap.append(index)
            continue
        close_gap()
        head, detail = lines[index]
        text.append(head + ("\n    " + detail.replace("\n", "\n    ") if detail else ""))
        items.append(Item(f"T{index + 1}", f"{row['name']} call", row["where"], ""))
    close_gap()
    if not rows:
        text.append("(no tool calls in this round)")
    return "\n".join(text), items


def _ending(round_: int, ended: dict) -> str:
    if ended.get("status") == "paused":
        how = (f"The round is not over: the host paused it because the last {ended.get('stall')} model calls made "
               "no progress the host can see: nothing new saved in the project, no new outside source, no project "
               "file read for the first time (counted from saved times since the last review). The working agent "
               "reads this review before it goes on with the round.")
    elif ended.get("stop_requested"):
        how = (f"The person stopped this round before it ended, saying: {_clip(str(ended['stop_requested']), 600)}. "
               "The work after that point has not been run yet.")
    elif ended.get("stopped_at"):
        how = (f"The person stopped this round at a stage they chose (a new record of kind "
               f"{ended.get('stop_at')!r}, {ended['stopped_at']}); the work after it has not been run yet.")
    elif ended.get("error"):
        how = f"The round ended with an error: {_clip(str(ended['error']), 1200)}"
    elif ended.get("status") == "completed":
        how = "The working agent finished its reply."
    else:
        how = f"The round ended with the dialogue status {ended.get('status')!r}."
    facts = [f"Round {round_} of this task. {how}"]
    if isinstance(ended.get("seconds"), (int, float)):
        facts.append(f"Time: {ended['seconds']:.0f} s.")
    if isinstance(ended.get("model_calls"), int):
        facts.append(f"Model calls by the working agent: {ended['model_calls']}.")
    return " ".join(facts)


def _sources(directory: Path, names) -> list[Item]:
    items, used = [], 0
    names = list(names)
    for number, name in enumerate(names[:MAX_SOURCES], 1):
        try:
            data = (directory / name).read_bytes()
        except OSError:
            continue
        try:
            text = data.decode("utf-8") if len(data) <= LIMITS["source"] else None
        except UnicodeDecodeError:
            text = None
        if len(data) > LIMITS["source"]:
            body = f"({len(data)} bytes; not included: larger than {LIMITS['source']} bytes)"
        elif text is None:
            body = f"({len(data)} bytes; not text, not included)"
        elif used + len(data) > LIMITS["sources"]:
            body = f"({len(data)} bytes; not included: the package's room for sources is used up)"
        else:
            used += len(data)
            body = text
        items.append(Item(f"S{number}", "task source", name, body))
    if len(names) > MAX_SOURCES:
        items.append(Item("S0", "task sources not listed", "the task's sources",
                          f"{len(names) - MAX_SOURCES} more source files are not listed."))
    return items


def lessons_path(root: str) -> Path:
    return task_skills.review_dir(root) / SKILL / LESSONS_FILE


def previous_lessons(root: str) -> dict | None:
    """The current review version's lessons with their evidence, as the last review saved them."""
    try:
        value = json.loads(lessons_path(root).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) and isinstance(value.get("lessons"), list) else None


def _evidence_text(evidence: list[dict]) -> str:
    return "；".join(f"第 {item.get('round')} 輪 {item.get('id')} {item.get('title')} `{item.get('where')}`"
                    for item in evidence)


def package(*, store, root: str, directory: Path, round_: int, commission: str, request: str, ended: dict,
            answer: str, since: float, sources=(), extra=(), core=()) -> tuple[str, list[Item]]:
    """The evidence package as the reviewer reads it, and its citable items.

    extra: (id, title, where, text) items the caller adds, such as the research board."""
    items = [Item("C1", "the commission", "the session's first request", _clip(commission, LIMITS["commission"]))]
    if request.strip() and request.strip() != commission.strip():
        items.append(Item("C2", "this round's request", f"the first request of round {round_}",
                          _clip(request, LIMITS["request"])))
    items.append(Item("R1", "how the round ended", f"the record of round {round_}", _ending(round_, ended)))
    if answer.strip():
        items.append(Item("A1", "the round's last reply", f"the last reply of round {round_}",
                          _clip(answer, LIMITS["answer"])))
    for id_, title, where, text in extra:
        if text.strip():
            items.append(Item(id_, title, where, _clip(text, LIMITS["extra"])))
    previous = previous_lessons(root)
    for number, lesson in enumerate((previous or {}).get("lessons") or [], 1):
        evidence = [item for item in lesson.get("evidence") or [] if isinstance(item, dict)]
        written = (f"the review written when round {previous.get('round')} was paused" if previous.get("paused")
                   else f"the review written after round {previous.get('round')}")
        items.append(Item(f"P{number}", "a lesson of the previous review", written,
                          f"{lesson.get('lesson', '')}\nIts evidence: {_evidence_text(evidence) or 'none recorded'}",
                          tuple(evidence)))
    from opencode.verification import package_items

    items.extend(package_items(root))  # the task's verification plan: V1, V2, ...
    loaded, _ = task_skills.load(directory, root, core)
    methods = [item for item in loaded.values() if item.kind == "method"]
    for number, item in enumerate(methods, 1):
        where = item.skill.location
        where = where.relative_to(directory).as_posix() if where.is_relative_to(directory) else where.as_posix()
        items.append(Item(f"K{number}", f"method skill {item.skill.name!r} (written in round {item.round})", where,
                          f"{item.skill.description}\n{_clip(item.skill.body.strip(), LIMITS['method'])}"))
    items.extend(_sources(directory, sources))
    tools, calls = _tool_section(_calls(store, task_sessions(store, root), since, directory), root, LIMITS["tools"])
    parts = [f"Evidence package for the review after round {round_} of this task. "
             "Each item's id is in brackets; cite those ids."]
    if previous is None:
        parts.append("There is no previous review: this is the task's first.")
    parts += [f"[{item.id}] {item.title} ({item.where})\n{item.text}" for item in items]
    parts.append(f"Tool calls of round {round_}, in order (T ids). Failures come with their output; calls "
                 "without failure are left out where space runs short, and only the calls shown can be cited.\n"
                 + tools)
    return "\n\n".join(parts), items + calls


def _normal(value: str) -> str:
    return re.sub(r"[\s\[\]()（）]", "", str(value)).upper()


def parse(text: str) -> dict:
    """The reviewer's reply, checked for shape (not yet for its citations)."""
    stripped = text.strip()
    fence = re.fullmatch(r"```(?:json)?\s*\n(.*)\n```", stripped, re.S)
    try:
        value = json.loads(fence.group(1) if fence else stripped)
    except json.JSONDecodeError as error:
        raise ValueError(f"Expected one JSON object: {error}") from error
    if not isinstance(value, dict):
        raise ValueError("Expected one JSON object")
    missing = [key for key in SCHEMA["required"] if key not in value]
    if missing:
        raise ValueError(f"Missing {', '.join(missing)}")
    if not isinstance(value["description"], str) or not value["description"].strip():
        raise ValueError("description must be one nonempty sentence")
    for key, fields in FIELDS.items():
        if not isinstance(value[key], list):
            raise ValueError(f"{key} must be a list")
        for number, entry in enumerate(value[key], 1):
            where = f"{key} entry {number}"
            if not isinstance(entry, dict) or any(field not in entry for field in fields):
                raise ValueError(f"{where} must have {', '.join(fields)}")
            if not isinstance(entry["evidence"], list) or not all(isinstance(x, str) for x in entry["evidence"]):
                raise ValueError(f"{where}: evidence must be a list of ids")
            for field in fields:
                if field != "evidence" and (not isinstance(entry[field], str) or not entry[field].strip()):
                    raise ValueError(f"{where}: {field} must be nonempty text")
            if key == "framework_issues" and entry["cause"] not in CAUSES:
                raise ValueError(f"{where}: cause must be one of {', '.join(CAUSES)}")
    return value


def _resolve(ids, by_id: dict[str, Item], round_: int) -> list[dict]:
    found, seen = [], set()
    for id_ in ids:
        item = by_id[id_]
        for entry in item.cites or ({"round": round_, "id": item.id, "title": item.title, "where": item.where},):
            key = (entry.get("round"), entry.get("id"), entry.get("where"))
            if key not in seen:
                seen.add(key)
                found.append(dict(entry))
    return found


def cite(reply: dict, items: list[Item], round_: int) -> tuple[dict, list[dict]]:
    """The entries whose citations the package holds, with their evidence resolved; and the refused ones."""
    by_id = {item.id: item for item in items}
    accepted, refused = {key: [] for key in FIELDS}, []
    for key, fields in FIELDS.items():
        for entry in reply[key]:
            ids = [_normal(value) for value in entry["evidence"] if _normal(value)]
            unknown = [value for value in ids if value not in by_id]
            reason = ("it cites no evidence" if not ids else
                      f"it cites {', '.join(unknown)}, which the evidence package does not hold" if unknown else None)
            text = {field: entry[field].strip() for field in fields if field != "evidence"}
            if reason:
                refused.append({"kind": key, **text, "reason": f"{reason} (skill charter article 4)"})
            else:
                accepted[key].append({**text, "evidence": _resolve(ids, by_id, round_)})
    return accepted, refused


def skill_body(round_: int, lessons: list[dict], *, paused: bool = False) -> str:
    when = f"第 {round_} 輪進行中因工作停滯而暫停，" if paused else f"第 {round_} 輪結束後"
    lines = ["# 本任務前幾輪的檢討", "",
             f"{when}由檢討者整理，取代上一版。這些教訓低於委託，也低於框架的規則、檢查與評分定義，"
             "不改變其中任何一項。每條都附證據所在；證據不成立的教訓，指出來，不要照做。", ""]
    if not lessons:
        lines.append("這一輪檢討後沒有保留的教訓；上一版的教訓都已撤回。")
    for number, lesson in enumerate(lessons, 1):
        lines += [f"{number}. {lesson['lesson']}", f"   證據：{_evidence_text(lesson['evidence'])}"]
    return "\n".join(lines)


def review(complete, *, store, root: str, directory, round_: int, commission: str, request: str, ended: dict,
           answer: str, since: float, sources=(), extra=(), core=()) -> dict:
    """Review the round that just ended and write the task's next review version; return the record.

    complete(system, message, (name, schema)) makes one model call and returns its completion (.text)."""
    directory = Path(directory).resolve()
    rules = task_skills.charter()
    message, items = package(store=store, root=root, directory=directory, round_=round_, commission=commission,
                             request=request, ended=ended, answer=answer, since=since, sources=sources,
                             extra=extra, core=core)
    system = instructions(rules)
    record = {"round": round_, "session": root, "charter": str(rules["version"]),
              "evidence": [{"id": item.id, "title": item.title, "where": item.where} for item in items],
              "replies": []}
    request_text = message
    for attempt in range(2):
        completion = complete(system, request_text, ("round_review", SCHEMA))
        text = completion.text if isinstance(getattr(completion, "text", None), str) else ""
        record["replies"].append(text)
        try:
            reply = parse(text)
            accepted, refused = cite(reply, items, round_)
            description = " ".join(reply["description"].split())
            body = skill_body(round_, accepted["lessons"], paused=ended.get("status") == "paused")
            if len(description) + len(body) > rules["max_chars"]:
                raise ValueError(f"With the evidence locations the framework adds, the review takes "
                                 f"{len(description) + len(body)} characters; the skill charter allows "
                                 f"{rules['max_chars']}. Merge or shorten lessons.")
            break
        except ValueError as error:
            if attempt:
                raise ValueError(f"The round review failed its one repair: {error}") from error
            request_text = "\n\n".join([
                message, "Your reply could not be used. Fix the issue below and return the complete JSON object "
                "again; keep its content otherwise.", "Your reply:", text, "The issue:", str(error)])
    record.update(description=description, lessons=accepted["lessons"], dropped=accepted["dropped"],
                  framework_issues=accepted["framework_issues"], refused=refused)
    if not accepted["lessons"] and not (task_skills.review_dir(root) / SKILL / "SKILL.md").is_file():
        record["status"] = "no lessons"
        return record
    history = task_skills.review_dir(root) / SKILL / "history"
    if lessons_path(root).is_file():  # kept beside the version write_review archives, under the same number
        history.mkdir(exist_ok=True)
        shutil.copy2(lessons_path(root), history / f"lessons.{len(list(history.glob('SKILL.*.md'))) + 1}.json")
    path = task_skills.write_review(root, SKILL, description, body, core)
    paused = {"paused": True} if ended.get("status") == "paused" else {}
    lessons_path(root).write_text(json.dumps({"round": round_, **paused, "lessons": accepted["lessons"]},
                                             ensure_ascii=False, indent=2), encoding="utf-8")
    record.update(status="written", skill=str(path))
    return record


def issues_markdown(record: dict) -> str:
    """The framework issues of one round, and the entries not written, for the people who maintain the framework."""
    lines = [f"# 框架問題清單（第 {record.get('round')} 輪）", "",
             "每輪結束時由檢討者提出，給維護框架的人看，不是給執行者的指引。每條附證據所在，是否成立要由人核對。", ""]
    for cause, title in (("framework", "框架"), ("environment", "環境")):
        entries = [item for item in record.get("framework_issues") or [] if item["cause"] == cause]
        lines += [f"## {title}", ""]
        lines += [f"{number}. {item['issue']}\n   證據：{_evidence_text(item['evidence'])}"
                  for number, item in enumerate(entries, 1)] or ["（無）"]
        lines.append("")
    if record.get("refused"):
        lines += ["## 沒有寫入的項目", ""]
        lines += [f"- {item.get('lesson') or item.get('issue')}：{item['reason']}" for item in record["refused"]]
        lines.append("")
    return "\n".join(lines)
