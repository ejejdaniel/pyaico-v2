"""Deployment settings in one file: config/runtime.json in the installation folder.

These depend on the machine and the services it talks to, not on the science: how many network
queries one task may make, how long to wait for the model server and the private literature
database, how large one model request may be, and how long a calculation may run. Every default
is the value that was fixed in the code before, so a missing file or key changes nothing.
COSCI_RUNTIME_CONFIG names another file. Keys starting with "_" are notes and are skipped.
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEFAULTS = {
    "network": {"max_queries": 20},
    "model_request": {"timeout_s": 600, "connect_timeout_s": 30, "max_bytes": 262144},
    "literature_agent": {"timeout_s": 300, "poll_s": 2},
    "compute": {"simulation_s": 120, "simulation_max_s": 600, "calc_check_s": 60, "inference_s": 30},
}
# Counts must be whole numbers; network.max_queries may also be null, for no limit.
WHOLE = {("network", "max_queries"), ("model_request", "max_bytes")}
_loaded = None


def path() -> Path:
    override = os.environ.get("COSCI_RUNTIME_CONFIG", "").strip()
    return Path(override) if override else ROOT / "config" / "runtime.json"


def _valid(group, key, value):
    if (group, key) == ("network", "max_queries") and value is None:
        return True
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        return False
    return isinstance(value, int) or (group, key) not in WHOLE


def load(source: Path | None = None) -> dict:
    """The defaults with the file's values over them; unknown keys and invalid values are refused."""
    source = source or path()
    values = {group: dict(items) for group, items in DEFAULTS.items()}
    if not source.is_file():
        return values
    try:
        raw = json.loads(source.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as error:
        raise ValueError(f"{source}: not valid JSON ({error})") from None
    if not isinstance(raw, dict):
        raise ValueError(f"{source}: must be a JSON object")
    for group, items in raw.items():
        if group.startswith("_"):
            continue
        if group not in DEFAULTS or not isinstance(items, dict):
            raise ValueError(f"{source}: unknown setting group {group!r}; the groups are {', '.join(DEFAULTS)}")
        for key, value in items.items():
            if key.startswith("_"):
                continue
            if key not in DEFAULTS[group]:
                raise ValueError(f"{source}: unknown setting {group}.{key}; {group} has {', '.join(DEFAULTS[group])}")
            if not _valid(group, key, value):
                kind = "a positive whole number" if (group, key) in WHOLE else "a positive number"
                extra = " or null (no limit)" if (group, key) == ("network", "max_queries") else ""
                raise ValueError(f"{source}: {group}.{key} must be {kind}{extra}, not {value!r}")
            values[group][key] = value
    compute = values["compute"]
    if compute["simulation_s"] > compute["simulation_max_s"]:
        raise ValueError(f"{source}: compute.simulation_s ({compute['simulation_s']}) must not exceed "
                         f"compute.simulation_max_s ({compute['simulation_max_s']})")
    return values


def get(name: str):
    """One setting by its dotted name, for example "model_request.timeout_s"; read once per process."""
    global _loaded
    if _loaded is None:
        _loaded = load()
    group, key = name.split(".", 1)
    return _loaded[group][key]
