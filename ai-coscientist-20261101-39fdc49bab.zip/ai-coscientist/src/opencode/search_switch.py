"""Session switches for the three kinds of search a user may turn off.

A switch that is off is a deny rule for each of its tools in the session's
permission list, so the loop hides those tools from the model at its next step
and subagents created later inherit the rule.
"""
from __future__ import annotations

GROUPS: dict[str, tuple[str, tuple[str, ...]]] = {
    "web": ("網路搜尋", ("websearch", "webfetch", "codesearch")),
    "literature": ("文獻搜尋", ("paper_search", "paper_fetch")),
    "private": ("私人資料庫", ("literature_agent",)),
}
TOOLS = frozenset(tool for _, tools in GROUPS.values() for tool in tools)


def _deny(tool: str) -> dict:
    return {"permission": tool, "pattern": "*", "action": "deny"}


def states(rules: list[dict] | None) -> dict[str, bool]:
    """Which groups are on: a group is off when every one of its tools is denied."""
    rules = rules or []
    return {group: not all(_deny(tool) in rules for tool in tools) for group, (_, tools) in GROUPS.items()}


def apply(rules: list[dict] | None, switches: dict[str, bool]) -> list[dict]:
    """The rules with each group's tools denied when its switch is off, and other rules kept."""
    kept = [dict(rule) for rule in rules or []
            if not (rule.get("permission") in TOOLS and rule.get("pattern") == "*")]
    return kept + [_deny(tool) for group, (_, tools) in GROUPS.items() if not switches.get(group, True)
                   for tool in tools]


def denied(rules: list[dict] | None) -> list[dict]:
    """The deny rules of switches that are off, for a child session to inherit."""
    return apply([], states(rules))
