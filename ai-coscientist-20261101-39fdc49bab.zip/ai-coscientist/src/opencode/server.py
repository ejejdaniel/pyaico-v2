"""HTTP API compatible with the OpenCode session routes, plus a small web UI."""

from __future__ import annotations

import json
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from urllib.parse import parse_qs, urlparse

from opencode import __version__
from opencode.provider import ProviderError


def _html() -> bytes:
    return files("opencode").joinpath("web/index.html").read_bytes()


class Server:
    def __init__(self, app, host: str = "127.0.0.1", port: int = 0, password: str | None = None, cors: list[str] | None = None):
        self.app = app
        self.password = password if password is not None else os.environ.get("OPENCODE_SERVER_PASSWORD")
        self.username = os.environ.get("OPENCODE_SERVER_USERNAME", "opencode")
        self.cors = cors or []
        self.httpd = ThreadingHTTPServer((host, port), self._handler())
        self.thread: threading.Thread | None = None

    @property
    def url(self) -> str:
        host, port = self.httpd.server_address[:2]
        return f"http://{host}:{port}"

    def serve_forever(self) -> None:
        self.httpd.serve_forever()

    def start(self) -> None:
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.httpd.shutdown()
        self.httpd.server_close()

    def _handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt, *args):
                return

            def _authorized(self) -> bool:
                if not server.password:
                    return True
                header = self.headers.get("Authorization") or ""
                match = re.match(r"^Basic\s+(.+)$", header, re.I)
                if not match:
                    return False
                import base64

                try:
                    decoded = base64.b64decode(match[1], validate=True).decode("utf-8")
                except Exception:
                    return False
                username, _, password = decoded.partition(":")
                return username == server.username and password == server.password

            def _cors_headers(self) -> None:
                origin = self.headers.get("Origin")
                if origin and _allowed_origin(origin, server.cors):
                    self.send_header("Access-Control-Allow-Origin", origin)
                    self.send_header("Vary", "Origin")

            def _send(self, status: int, body: bytes, content_type: str = "application/json") -> None:
                if status == 204:
                    body = b""
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self._cors_headers()
                if status == 401:
                    self.send_header("WWW-Authenticate", 'Basic realm="Secure Area"')
                self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
                self.end_headers()
                self.wfile.write(body)

            def _json(self, status: int, payload) -> None:
                self._send(status, json.dumps(payload, default=str).encode("utf-8"))

            def _read_json(self) -> dict:
                length = int(self.headers.get("Content-Length") or 0)
                if length <= 0:
                    return {}
                raw = self.rfile.read(length)
                if not raw:
                    return {}
                data = json.loads(raw.decode("utf-8"))
                return data if isinstance(data, dict) else {}

            def do_OPTIONS(self):
                self._send(204, b"")

            def do_GET(self):
                if not self._authorized():
                    self._json(401, {"error": "unauthorized"})
                    return
                self._route("GET")

            def do_POST(self):
                if not self._authorized():
                    self._json(401, {"error": "unauthorized"})
                    return
                self._route("POST")

            def do_PATCH(self):
                if not self._authorized():
                    self._json(401, {"error": "unauthorized"})
                    return
                self._route("PATCH")

            def do_DELETE(self):
                if not self._authorized():
                    self._json(401, {"error": "unauthorized"})
                    return
                self._route("DELETE")

            def _route(self, method: str) -> None:
                parsed = urlparse(self.path)
                path = parsed.path.rstrip("/") or "/"
                parts = [part for part in path.split("/") if part]
                try:
                    self._dispatch(method, path, parts, parse_qs(parsed.query))
                except KeyError:
                    self._json(404, {"error": "not found"})
                except ProviderError as exc:
                    self._json(400, {"error": str(exc)})
                except json.JSONDecodeError:
                    self._json(400, {"error": "invalid json"})
                except Exception as exc:
                    self._json(500, {"error": str(exc)})

            def _dispatch(self, method: str, path: str, parts: list[str], query: dict) -> None:
                app = server.app
                if method == "GET" and path == "/":
                    self._send(200, _html(), "text/html; charset=utf-8")
                    return
                if method == "GET" and path == "/global/health":
                    self._json(200, {"healthy": True, "version": __version__})
                    return
                if method == "GET" and path == "/path":
                    self._json(200, {"directory": str(app.directory), "worktree": str(app.worktree)})
                    return
                if method == "GET" and path == "/config":
                    self._json(200, app.config)
                    return
                if method == "GET" and path == "/agent":
                    self._json(200, [agent.to_dict() for agent in app.agents.values() if not agent.hidden])
                    return
                if method == "GET" and path == "/provider":
                    self._json(
                        200,
                        [
                            {
                                "id": item.id,
                                "name": item.name,
                                "models": item.models,
                                "default": item.default_model,
                                "configured": bool(app.provider.key_for(item)) or item.id == "ollama",
                            }
                            for item in app.provider.providers.values()
                        ],
                    )
                    return
                if method == "GET" and path == "/mcp":
                    app.ensure_mcp()
                    self._json(200, [item.status() for item in app.mcp.servers.values()])
                    return
                if method == "POST" and len(parts) == 3 and parts[0] == "mcp" and parts[2] == "auth":
                    url = app.mcp.authenticate(parts[1], block=False)
                    self._json(200, {"authorizationUrl": url, "name": parts[1]})
                    return
                if method == "GET" and path == "/event":
                    self._events()
                    return
                if method == "GET" and path == "/permission":
                    self._json(200, app.permissions.list_pending())
                    return
                if method == "GET" and path == "/question":
                    self._json(200, app.pending_questions())
                    return
                if method == "POST" and len(parts) == 3 and parts[0] == "question" and parts[2] == "reply":
                    body = self._read_json()
                    ok = app.reply_question(parts[1], body.get("answers") or [])
                    self._json(200 if ok else 404, {"ok": ok})
                    return
                if method == "GET" and path == "/session":
                    self._json(200, app.store.list_sessions(str(app.directory)))
                    return
                if method == "POST" and path == "/session":
                    body = self._read_json()
                    self._json(
                        200,
                        app.create_session(agent=body.get("agent"), model=body.get("model"), title=body.get("title") or "", **({"permission": body["permission"]} if "permission" in body else {})),
                    )
                    return
                if method == "GET" and path == "/session/status":
                    self._json(200, {"pending": app.permissions.list_pending()})
                    return
                if len(parts) >= 2 and parts[0] == "session":
                    self._session(method, parts)
                    return
                self._json(404, {"error": f"no route {method} {path}"})

            def _session(self, method: str, parts: list[str]) -> None:
                app = server.app
                session_id = parts[1]
                tail = parts[2:]
                if method == "GET" and not tail:
                    self._json(200, app.store.get_session(session_id))
                    return
                if method == "DELETE" and not tail:
                    app.store.delete_session(session_id)
                    self._json(200, {"ok": True})
                    return
                if method == "PATCH" and not tail:
                    self._json(200, app.store.update_session(session_id, **self._read_json()))
                    return
                if method == "GET" and tail == ["message"]:
                    self._json(200, app.store.messages(session_id))
                    return
                if method == "POST" and tail == ["message"]:
                    body = self._read_json()
                    text = _prompt_text(body)
                    result = app.prompt(session_id, text, agent=body.get("agent"), model=_model(body), **({"tools": body["tools"]} if "tools" in body else {}))
                    self._json(200, result)
                    return
                if method == "POST" and tail == ["prompt_async"]:
                    body = self._read_json()
                    text = _prompt_text(body)
                    agent = body.get("agent")
                    model = _model(body)

                    def worker():
                        try:
                            app.prompt(session_id, text, agent=agent, model=model, **({"tools": body["tools"]} if "tools" in body else {}))
                        except Exception as exc:
                            app.store.add_message(session_id, "assistant", {"content": f"Error: {exc}"})
                            app.bus.publish("session.error", {"sessionID": session_id, "error": str(exc)})

                    threading.Thread(target=worker, daemon=True).start()
                    self._json(204, {})
                    return
                if method == "POST" and tail == ["abort"]:
                    app.abort(session_id)
                    self._json(200, {"ok": True})
                    return
                if method == "GET" and tail == ["todo"]:
                    self._json(200, app.store.todos(session_id))
                    return
                if method == "GET" and tail == ["children"]:
                    self._json(200, app.store.children(session_id))
                    return
                if method == "POST" and tail == ["shell"]:
                    body = self._read_json()
                    self._json(200, app.shell(session_id, body.get("command") or ""))
                    return
                if method == "POST" and tail == ["summarize"]:
                    self._json(200, {"summary": app.summarize(session_id)})
                    return
                if method == "POST" and tail == ["revert"]:
                    self._json(200, {"restored": app.store.revert(session_id)})
                    return
                if method == "POST" and len(tail) == 2 and tail[0] == "permissions":
                    body = self._read_json()
                    ok = app.permissions.reply(tail[1], body.get("response") or "reject", body.get("message"))
                    self._json(200 if ok else 404, {"ok": ok})
                    return
                self._json(404, {"error": "unknown session route"})

            def _events(self) -> None:
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self._cors_headers()
                self.end_headers()
                box = server.app.bus.subscribe()
                try:
                    self.wfile.write(b": ok\n\n")
                    self.wfile.flush()
                    while True:
                        try:
                            event = box.get(timeout=15)
                        except Exception:
                            self.wfile.write(b": ping\n\n")
                            self.wfile.flush()
                            continue
                        payload = json.dumps(event, default=str).encode("utf-8")
                        self.wfile.write(b"data: " + payload + b"\n\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
                finally:
                    server.app.bus.unsubscribe(box)

        return Handler


def _allowed_origin(origin: str, cors: list[str]) -> bool:
    return (origin.startswith(("http://localhost:", "http://127.0.0.1:", "oc://renderer"))
            or origin in {"tauri://localhost", "http://tauri.localhost", "https://tauri.localhost"}
            or re.fullmatch(r"https://([a-z0-9-]+\.)*opencode\.ai", origin) is not None
            or origin in cors)


def _prompt_text(body: dict) -> str:
    if body.get("text"):
        return str(body["text"])
    parts = body.get("parts") or []
    chunks = []
    for part in parts:
        if isinstance(part, str):
            chunks.append(part)
        elif isinstance(part, dict):
            chunks.append(part.get("text") or part.get("content") or "")
    return "\n".join(chunk for chunk in chunks if chunk)


def _model(body: dict) -> str | None:
    model = body.get("model")
    if isinstance(model, str):
        return model
    if isinstance(model, dict) and model.get("providerID") and model.get("modelID"):
        return f"{model['providerID']}/{model['modelID']}"
    return None
