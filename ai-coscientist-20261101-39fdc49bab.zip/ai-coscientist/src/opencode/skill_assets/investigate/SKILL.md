---
name: investigate
description: Investigate failures and conflicting accounts from original records and code; trace handoffs, test causal explanations, and revise unsupported prior conclusions.
---

# Investigate from evidence

Work on the user's question with the authorized read, search and programming
tools. This skill does not authorize restarting the subject of an investigation,
changing its records, or performing operations the user prohibited.

## Working method

Distinguish an observation, an explanation of it, and what remains unknown.
For nontrivial work, use the existing todo list to keep unresolved questions
visible. Ordinary working notes may record the evidence locations supporting or
opposing a hypothesis. They are not new evidence or a required publication.

Choose the next action from the missing fact, not from a fixed tool sequence.
Known paths can be read directly. Locate unknown files before opening them.
Inspect unfamiliar fields before writing a small parser for cross-record
comparison. A failed search establishes only what was searched, not global
absence. Read `references/handoffs.md` when investigating a data or control
handoff; simple questions need no extra ceremony.

## Before delivering an explanation

For each principal causal claim in the proposed answer, ask what original
observation establishes the connection, not merely its endpoints. A timestamp,
event name, instruction, or empty field can locate a question without answering
it. The system under investigation may violate its own documented rules.

Inspect the producer, transferred identity, consumer input, or implementation
that could distinguish competing explanations when that information is available
and authorized. Reuse already inspected evidence; do not reread every file to
perform a ritual check. Check version and scope before carrying an observation
forward. Lack of evidence in one view does not prove absence in every view.

An earlier assistant answer or summary is a prior interpretation, even when it
sounds confident. If evidence does not support it, explicitly withdraw or narrow
that claim, identify the source that changed the assessment, and update the
existing work notes or todos. Repeating the earlier answer is not corroboration.
Do not seek confirmation alone: look for observations that would disprove the
candidate explanation.

## Honest completion

Deliver the established facts and their exact original locations, the causal
explanation they support, and any unresolved link. If required evidence is
unavailable, state the missing scope rather than inventing a root cause. Do not
keep investigating an unrelated question to avoid returning a bounded answer.

A host-enabled answer review gives this same agent one verification phase with
its remaining tools and budget. It is not evidence that the host agrees with the
answer, and it does not replenish time or steps. Resolve the important gaps or
report them truthfully; do not request an endless series of reviews.
