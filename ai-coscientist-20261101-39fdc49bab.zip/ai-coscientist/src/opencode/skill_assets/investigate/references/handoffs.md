# Following a handoff

Select a suspect boundary from the question and observations. These are things
to establish where relevant, not a mandatory ordered checklist for every task:

- The producer's actual saved output and its identity/version.
- The reference or payload passed through the intervening operation.
- What the consumer resolved, including filtering and permission scope.
- The consumer's actual input and response, not only a later status message.
- Which transition first differs from the intended contract.

Compare exact references or values with a small program when repetition or
volume makes manual comparison unreliable. Preserve the query and scope so an
absence claim can be inspected. A current source checkout is not automatically
the code that ran in a historical log; establish that relationship before using
it as proof of historical behavior.

Use event sequence and actual payloads together. A timestamp establishes the
recorded event, not every intervening operation. Check the scope of each field
and consider counterexamples before generalizing. Distinguish a documented
contract from evidence that the historical execution followed it.

If the trace stops at a boundary, bound the conclusion there. Identify what
missing observation would distinguish the remaining explanations. Do not fill
unobserved steps with assumptions; pursue them only while useful evidence is
available within the task's constraints.
