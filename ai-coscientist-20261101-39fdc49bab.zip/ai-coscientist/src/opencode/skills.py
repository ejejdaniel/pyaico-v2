"""Discover SKILL.md files under `.opencode/skill(s)` and the user config directory."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from opencode.config import _frontmatter
from opencode.paths import config_dir, home
from opencode.permission import evaluate


@dataclass
class Skill:
    name: str
    description: str
    location: Path
    body: str

    def to_dict(self) -> dict:
        return {"name": self.name, "description": self.description, "location": str(self.location)}


def _scan(root: Path, found: dict[str, Skill]) -> None:
    if not root.is_dir():
        return
    for path in sorted(root.rglob("SKILL.md")):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        meta, body = _frontmatter(text)
        name = meta.get("name")
        if not isinstance(name, str) or not name or not isinstance(meta.get("description", ""), str):
            continue
        found[name] = Skill(
            name=name,
            description=str(meta.get("description") or ""),
            location=path,
            body=body,
        )


def discover(directory: Path, worktree: Path, config: dict) -> dict[str, Skill]:
    found: dict[str, Skill] = {}
    roots = [home() / ".claude" / "skills", home() / ".agents" / "skills"]
    current = directory.resolve()
    stop = worktree.resolve()
    chain: list[Path] = []
    while True:
        chain.append(current)
        if current == stop or current.parent == current:
            break
        if stop not in current.parents:
            break
        current = current.parent
    for folder in reversed(chain):
        roots.extend([folder / ".claude" / "skills", folder / ".agents" / "skills"])
    roots.extend([config_dir() / "skill", config_dir() / "skills"])
    for folder in reversed(chain):
        for name in ("skill", "skills"):
            roots.append(folder / ".opencode" / name)
    skills_cfg = config.get("skills") or {}
    if isinstance(skills_cfg, dict):
        for extra in skills_cfg.get("paths") or []:
            expanded = home() / extra[2:] if extra.startswith("~/") else Path(extra)
            roots.append(expanded if expanded.is_absolute() else directory / expanded)
    for root in roots:
        _scan(root, found)
    return found


def render(skills: dict[str, Skill], agent=None) -> str:
    if agent is not None:
        skills = {name: skill for name, skill in skills.items()
                  if evaluate("skill", name, agent.permission).action != "deny"}
    if not skills:
        return ""
    lines = [
        "Skills provide specialized instructions and workflows for specific tasks.",
        "Use the skill tool to load a skill when a task matches its description.",
        "<available_skills>",
    ]
    for skill in sorted(skills.values(), key=lambda item: item.name):
        lines.append("  <skill>")
        lines.append(f"    <name>{skill.name}</name>")
        lines.append(f"    <description>{skill.description}</description>")
        lines.append(f"    <location>{skill.location}</location>")
        lines.append("  </skill>")
    lines.append("</available_skills>")
    return "\n".join(lines)
