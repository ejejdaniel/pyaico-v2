"""Skills a task writes for itself, under the skill charter (skill_charter.md; docs/design_meta_task_zones_20261030_zh-TW.md §10).

A session is one task and may run for several rounds. Its task skills live as long as it does, in two
kinds:

- method skills: the working agent writes them with the task_skill tool, in the workspace at
  <folder>/.task/<top session>/skills/<name>/SKILL.md, and may change them;
- review skills: the reviewer writes them between rounds (opencode/round_review.py), in the session's
  state at <state>/task/<top session>/review/<name>/SKILL.md, out of the working agent's reach; the
  system prompt carries them in full (standing), and the loop sends them with the round's first message
  and, while the work stalls, a one-line reminder with the newest one (opening).

Every task skill is checked against the charter's machine rules when it is written and when it is
loaded. One that fails is not loaded, and the reason names the article it breaks.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
import shutil

import yaml

from opencode.config import _frontmatter
from opencode.paths import state_dir
from opencode.skills import Skill

CHARTER = Path(__file__).with_name("skill_charter.md")
NAME = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
FIELDS = ("name", "description", "kind", "author", "session", "round", "charter")
# Each kind has one author and one place: method skills in the workspace, review skills in the state.
AUTHOR = {"method": "worker", "review": "reviewer"}


@dataclass(frozen=True)
class TaskSkill:
    skill: Skill
    kind: str
    round: int
    charter: str


def charter() -> dict:
    """The charter's machine rules: its front matter, with its version."""
    rules, _ = _frontmatter(CHARTER.read_text(encoding="utf-8"))
    return rules


def root_session(store, session_id: str) -> str:
    """The top session of a task: subagents work for the same task and share its skills."""
    current, seen = session_id, set()
    while current not in seen:
        seen.add(current)
        try:
            parent = store.get_session(current).get("parentID")
        except Exception:  # a session the store does not hold is a task of its own
            return current
        if not parent:
            return current
        current = parent
    return current


def method_dir(directory, root: str) -> Path:
    return Path(directory) / ".task" / root / "skills"


def state_root() -> Path:
    """Where every task's review skills and round count are kept: the state, out of the working agent's reach."""
    return state_dir() / "task"


def review_dir(root: str) -> Path:
    return state_root() / root / "review"


def _round_file(root: str) -> Path:
    return state_root() / root / "round.json"


def current_round(root: str) -> int:
    """The round this task is in: 1 until a continuation records another (the runner counts them)."""
    try:
        value = json.loads(_round_file(root).read_text(encoding="utf-8")).get("round")
    except (OSError, ValueError, AttributeError):
        return 1
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 1 else 1


def set_round(root: str, value: int) -> None:
    path = _round_file(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"round": value}), encoding="utf-8")


def problems(meta: dict, body: str, *, kind: str, root: str, core, rules: dict | None = None) -> list[str]:
    """What keeps a task skill from loading, each naming the charter article it breaks.

    kind is where the skill was found (method: the workspace; review: the session's state)."""
    rules = rules or charter()
    found = []
    missing = [field for field in FIELDS if meta.get(field) in (None, "")]
    if missing:
        found.append(f"missing {', '.join(missing)} (skill charter article 2)")
    if meta.get("kind") not in rules["kinds"] or meta.get("author") not in rules["authors"]:
        found.append(f"kind must be one of {', '.join(rules['kinds'])} and author one of "
                     f"{', '.join(rules['authors'])} (skill charter article 2)")
    elif meta["kind"] != kind or meta["author"] != AUTHOR[kind]:
        found.append(f"a {kind} skill is written by the {AUTHOR[kind]} and kept where its kind is kept "
                     "(skill charter article 3)")
    round_ = meta.get("round")
    if round_ is not None and (isinstance(round_, bool) or not isinstance(round_, int) or round_ < 1):
        found.append("round must be a whole number from 1 (skill charter article 2)")
    if meta.get("session") not in (None, "") and meta.get("session") != root:
        found.append("it belongs to another session (skill charter article 3)")
    if len(str(meta.get("description") or "")) + len(body) > rules["max_chars"]:
        found.append(f"description and text exceed {rules['max_chars']} characters (skill charter article 3)")
    if meta.get("name") in core:
        found.append(f"{meta['name']!r} is the name of a framework skill (skill charter article 1)")
    return found


def load(directory, root: str, core, kinds=("review", "method")) -> tuple[dict[str, TaskSkill], list[dict]]:
    """This task's skills that pass the charter, and the refused ones as {name, location, reasons}.

    Review skills come first, so a method skill cannot take a review skill's name."""
    rules = charter()
    loaded, refused = {}, []
    for kind in [kind for kind in ("review", "method") if kind in kinds]:
        folder = review_dir(root) if kind == "review" else method_dir(directory, root)
        if not folder.is_dir():
            continue
        for path in sorted(folder.glob("*/SKILL.md")):
            try:
                meta, body = _frontmatter(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeDecodeError, ValueError) as error:
                refused.append({"name": path.parent.name, "location": path, "reasons": [f"unreadable: {error}"]})
                continue
            name = str(meta.get("name") or path.parent.name)
            reasons = problems(meta, body, kind=kind, root=root, core=core, rules=rules)
            if not reasons and name in loaded:
                reasons = [f"a review skill of this task is named {name!r} (skill charter article 1)"]
            if reasons:
                refused.append({"name": name, "location": path, "reasons": reasons})
                continue
            loaded[name] = TaskSkill(Skill(name, str(meta["description"]), path, body), kind, meta["round"],
                                     str(meta["charter"]))
    return loaded, refused


def describe(item: TaskSkill) -> str:
    """The line the skill tool puts before a task skill's text."""
    who = "by the reviewer, with lessons from earlier rounds; it is read-only" if item.kind == "review" \
        else "by the working agent"
    return (f"This is a task {item.kind} skill of this session, from round {item.round} (skill charter "
            f"{item.charter}), written {who}. It applies to this task only and changes no framework rule or check.")


def _reviews(store, session_id: str, core) -> list[TaskSkill]:
    try:
        loaded, _ = load(None, root_session(store, session_id), core, kinds=("review",))
    except (OSError, ValueError, KeyError):
        return []
    return list(loaded.values())


def last_review(store, session_id: str) -> float:
    """When this task's newest review version was written (0.0 when there is none)."""
    folder = review_dir(root_session(store, session_id))
    times = [path.stat().st_mtime for path in folder.glob("*/SKILL.md")] if folder.is_dir() else []
    return max(times, default=0.0)


def standing(store, session_id: str, core, *, repeated: bool = False) -> str:
    """This task's review skills in full, as the system prompt carries them through every later round.

    The reviewer writes them between rounds only, so the prompt stays the same all round (and the
    provider's prefix cache with it). repeated: the loop also sends them with the messages (opening)."""
    again = (" The same text comes once more with this round's first message, in <task-review>, and while the "
             "work stalls its description comes after the newest message, in <task-review-reminder>; they "
             "repeat these lessons and add none.") if repeated else ""
    return "\n\n".join(
        f'<task_review_skill name="{item.skill.name}">\n{describe(item)} Its whole text is here, so the skill '
        f"tool need not load it.{again}\n\n{item.skill.body.strip()}\n</task_review_skill>"
        for item in _reviews(store, session_id, core))


def opening(store, session_id: str, core) -> tuple[str, str]:
    """This task's review skills as the round's first message carries them, and the reminder for every step.

    In the system prompt alone they did not reach the agent: acoustics round 2 (2026-10-31) resumed 315
    messages of round 1's debugging loop and went on with it, against the lessons. So the loop also sends
    the text once with the round's first message, and the descriptions after the newest message while the
    work stalls (opencode/progress.py; always on, the reminder changed nothing in a rerun); neither is
    saved. A compaction summary is written with the text too (compaction.build_prompt)."""
    items = _reviews(store, session_id, core)
    text = "\n\n".join(
        f'<task-review name="{item.skill.name}" round="{item.round}">\n{item.skill.description}\n\n'
        f"{item.skill.body.strip()}\n</task-review>" for item in items)
    reminder = "\n".join(
        f'<task-review-reminder name="{item.skill.name}" round="{item.round}">{item.skill.description}'
        "</task-review-reminder>" for item in items)
    return text, reminder


def _write(folder: Path, name: str, description: str, body: str, *, kind: str, root: str, core) -> Path:
    rules = charter()
    if not NAME.match(name or ""):
        raise ValueError("A task skill's name is lowercase letters, digits and hyphens, up to 64 characters")
    meta = {"name": name, "description": description, "kind": kind, "author": AUTHOR[kind], "session": root,
            "round": current_round(root), "charter": str(rules["version"])}
    reasons = problems(meta, body, kind=kind, root=root, core=core, rules=rules)
    if reasons:
        raise ValueError(f"Task skill {name!r} was not written: " + "; ".join(reasons))
    target = folder / name / "SKILL.md"
    if target.exists():  # every earlier version is kept
        history = target.parent / "history"
        history.mkdir(exist_ok=True)
        shutil.copy2(target, history / f"SKILL.{len(list(history.glob('SKILL.*.md'))) + 1}.md")
    target.parent.mkdir(parents=True, exist_ok=True)
    front = yaml.safe_dump(meta, allow_unicode=True, sort_keys=False)
    target.write_text(f"---\n{front}---\n{body.strip()}\n", encoding="utf-8")
    return target


def write_method(directory, root: str, name: str, description: str, body: str, core) -> Path:
    """A method skill of this task, written by the working agent (through the task_skill tool)."""
    return _write(method_dir(directory, root), name, description, body, kind="method", root=root, core=core)


def write_review(root: str, name: str, description: str, body: str, core) -> Path:
    """A review skill of this task, written by the reviewer between rounds."""
    return _write(review_dir(root), name, description, body, kind="review", root=root, core=core)
