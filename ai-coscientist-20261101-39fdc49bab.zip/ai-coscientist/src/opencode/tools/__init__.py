"""Assemble the tool list for an agent."""

from __future__ import annotations

from dataclasses import replace
import os

from opencode.permission import Rule, disabled, evaluate, merge
from opencode.prompts import load as load_prompt
from opencode.tools.extra import extra_tools
from opencode.tools.files import file_tools
from opencode.tools.shell import shell_tool
from opencode.tools.task_skill import task_skill_tool
from opencode.tools.types import Tool, ToolResult, prop, schema
from opencode.tools.web import web_tools


def lsp_tool() -> Tool:
    def execute(args: dict, ctx) -> ToolResult:
        from opencode.tools.util import _abort_event, ensure_access, session_path

        path = session_path(args.get("filePath") or "", ctx)
        ensure_access(ctx, path, "lsp")
        operation = args.get("operation")
        line = int(args.get("line") or 1)
        character = int(args.get("character") or 1)
        return ctx.app.lsp_operation(operation, path, line, character, args.get("query"),
                                     abort_event=_abort_event(ctx))

    return Tool(
        "lsp",
        load_prompt("lsp.txt"),
        schema(
            {
                "operation": prop(
                    "string",
                    "The LSP operation to perform",
                    enum=[
                        "goToDefinition",
                        "findReferences",
                        "hover",
                        "documentSymbol",
                        "workspaceSymbol",
                        "goToImplementation",
                        "prepareCallHierarchy",
                        "incomingCalls",
                        "outgoingCalls",
                    ],
                ),
                "filePath": prop("string", "The absolute or relative path to the file"),
                "line": prop("integer", "The line number (1-based, as shown in editors)"),
                "character": prop("integer", "The character offset (1-based, as shown in editors)"),
                "query": prop("string", "Search query for workspaceSymbol"),
            },
            ["operation", "filePath", "line", "character"],
        ),
        execute,
    )


def builtin_tools(config: dict | None = None) -> list[Tool]:
    return [*file_tools(), shell_tool(config), *web_tools(), *extra_tools(), task_skill_tool(), lsp_tool()]


def tools_for(agent, mcp_tools: list[Tool] | None = None, *, model_id: str | None = None,
              provider_id: str | None = None,
              permission: list[Rule] | None = None, agents: dict | None = None,
              config: dict | None = None) -> list[Tool]:
    tools = builtin_tools(config) + list(mcp_tools or [])
    names = [tool.name for tool in tools]
    hidden = disabled(names, merge(agent.permission, permission or []))
    use_patch = bool(model_id and "gpt-" in model_id and "oss" not in model_id and "gpt-4" not in model_id)
    websearch_enabled = provider_id == "opencode" or any(
        os.environ.get(name, "").lower() in {"true", "1", "yes", "on"}
        for name in (
            "OPENCODE_EXPERIMENTAL", "OPENCODE_ENABLE_EXA", "OPENCODE_EXPERIMENTAL_EXA",
            "OPENCODE_ENABLE_PARALLEL", "OPENCODE_EXPERIMENTAL_PARALLEL",
        )
    )
    visible = []
    for tool in tools:
        if tool.name in hidden:
            continue
        if tool.name == "websearch" and not websearch_enabled:
            continue
        if tool.name == "apply_patch" and not use_patch:
            continue
        if tool.name in {"edit", "write"} and use_patch:
            continue
        if tool.name == "task" and agents is not None:
            available = sorted((item for item in agents.values() if item.mode != "primary"
                                and evaluate("task", item.name, agent.permission).action != "deny"),
                               key=lambda item: item.name)
            description = "Available agent types and the tools they have access to:\n" + "\n".join(
                f"- {item.name}: {item.description or 'This subagent should only be called manually by the user.'}"
                for item in available)
            tool = replace(tool, description=tool.description + "\n" + description)
        visible.append(tool)
    return visible
