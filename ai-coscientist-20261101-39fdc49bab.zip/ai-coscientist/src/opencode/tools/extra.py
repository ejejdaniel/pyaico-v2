"""todo, question, skill, task, plan, and apply_patch."""

from __future__ import annotations

from pathlib import Path

from opencode import search_switch
from opencode.patch import apply_chunks, parse_patch
from opencode.permission import PermissionRejected
from opencode.prompts import load as load_prompt
from opencode.tools.types import Tool, ToolResult, prop, schema
from opencode.tools.util import _abort_event, ensure_external_directory, mark_read, refuse_protected, relative_path, session_path, snapshot


def _todo(args: dict, ctx) -> ToolResult:
    todos = args.get("todos") or []
    ctx.app.permissions.ask(
        session_id=ctx.session_id,
        permission="todowrite",
        patterns=["*"],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata={},
        abort_event=_abort_event(ctx),
    )
    normalized = []
    for index, todo in enumerate(todos):
        if isinstance(todo, str):
            todo = {"content": todo, "status": "pending"}
        normalized.append(
            {
                "id": str(todo.get("id") or index + 1),
                "content": todo.get("content") or "",
                "status": todo.get("status") or "pending",
                "priority": todo.get("priority") or "medium",
            }
        )
    stored = ctx.app.store.set_todos(ctx.session_id, normalized)
    remaining = len([item for item in stored if item["status"] != "completed"])
    import json

    return ToolResult(title=f"{remaining} todos", output=json.dumps(stored, indent=2), metadata={"todos": stored})


NO_ANSWER = ("No one can answer questions in this run: it has no input. Record each question and the assumption "
             "you continue with in your notes, then go on.")


def _question(args: dict, ctx) -> ToolResult:
    questions = args.get("questions") or []
    try:
        answers = ctx.app.ask_questions(ctx.session_id, questions, abort_event=_abort_event(ctx))
    except EOFError:
        # An unattended run reads no input: v42 asked a test question and got only "EOF when reading a line".
        return ToolResult(title="No one can answer", output=NO_ANSWER, metadata={"answers": []})
    formatted = []
    for index, question in enumerate(questions):
        label = question.get("question") if isinstance(question, dict) else str(question)
        answer = answers[index] if index < len(answers) else []
        formatted.append(f"\"{label}\"=\"{', '.join(answer) if answer else 'Unanswered'}\"")
    return ToolResult(
        title=f"Asked {len(questions)} question{'s' if len(questions) != 1 else ''}",
        output="User has answered your questions: " + ", ".join(formatted) + ". You can now continue with the user's answers in mind.",
        metadata={"answers": answers},
    )


def _skill(args: dict, ctx) -> ToolResult:
    from opencode import task_skills

    name = args.get("name") or ""
    # This task's skills (opencode/task_skills.py) are read afresh, so one written during a run loads
    # without a restart; each is checked against the skill charter.
    root = task_skills.root_session(ctx.app.store, ctx.session_id)
    from opencode.deep import skills as installed_skills

    task, refused = task_skills.load(Path(getattr(ctx, "directory", None) or ctx.app.directory), root,
                                     installed_skills(ctx.app))
    # Deep research's skills while the task has it on (opencode/deep.py): its installed copies come first.
    from opencode.deep import is_on as deep_is_on
    installed = getattr(ctx.app, "deep", None)
    research = installed.skills if installed and deep_is_on(ctx.app, ctx.session_id) else {}
    skill = research.get(name) or ctx.app.skills.get(name) or (task[name].skill if name in task else None)
    if skill is None:
        available = ", ".join(sorted({*ctx.app.skills, *research, *task})) or "none"
        message = f'Skill "{name}" not found. Available skills: {available}'
        if refused:
            message += "." + "".join(f" Task skill {item['name']!r} was not loaded: "
                                     f"{'; '.join(item['reasons'])}." for item in refused)
        raise KeyError(message)
    ctx.app.permissions.ask(
        session_id=ctx.session_id,
        permission="skill",
        patterns=[name],
        ruleset=ctx.agent.permission,
        always=[name],
        metadata={"name": name},
        abort_event=_abort_event(ctx),
    )
    directory = skill.location.parent
    files = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.name != "SKILL.md" and not path.is_symlink():
            files.append(path)
        if len(files) == 10:
            break
    notes = [task_skills.describe(task[name])] if name in task else []
    notes += [f"A task skill at {item['location']} is also named {name!r} and was not loaded: "
              f"{'; '.join(item['reasons'])}." for item in refused if item["name"] == name]
    output = "\n".join([
        f'<skill_content name="{skill.name}">', f"# Skill: {skill.name}", "", *notes, *([""] if notes else []),
        skill.body.strip(), "",
        f"Base directory for this skill: {directory}",
        "Relative paths in this skill (e.g., scripts/, reference/) are relative to this base directory.",
        "Note: file list is sampled.", "", "<skill_files>",
        "\n".join(f"<file>{path.resolve()}</file>" for path in files),
        "</skill_files>", "</skill_content>",
    ])
    return ToolResult(title=f"Loaded skill: {skill.name}", output=output, metadata={"location": str(skill.location)})


def _task(args: dict, ctx) -> ToolResult:
    for name in ("description", "prompt", "subagent_type"):
        if name not in args or not isinstance(args[name], str):
            raise ValueError(f"{name} is required and must be a string")
    description = args["description"]
    prompt = args["prompt"]
    subagent = args["subagent_type"]
    parent = ctx.app.store.get_session(ctx.session_id)
    current = parent
    depth = 0
    while current.get("parentID"):
        depth += 1
        current = ctx.app.store.get_session(current["parentID"])
    limit = ctx.app.config.get("subagent_depth")
    if limit is None:
        limit = 1
    if depth >= limit:
        raise RuntimeError(f'Subagent depth limit reached ({limit}). Increase "subagent_depth" to allow nested subagents.')
    ctx.app.permissions.ask(
        session_id=ctx.session_id,
        permission="task",
        patterns=[subagent],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata={"description": description, "subagent": subagent},
        abort_event=_abort_event(ctx),
    )
    next_agent = ctx.app.agents.get(subagent)
    if next_agent is None:
        raise ValueError(f"Unknown agent type: {subagent} is not a valid agent type")
    parent_model = parent.get("model")
    message_id = getattr(ctx, "message_id", None)
    if message_id is not None:
        message = next((item for item in ctx.app.store.messages(ctx.session_id) if item["id"] == message_id), None)
        if message is None or message.get("role") != "assistant":
            raise ValueError("Not an assistant message")
        parent_model = message.get("model") or parent_model
    model = next_agent.model or parent_model
    child_permission = [dict(rule) for rule in parent.get("permission") or []
                        if rule["permission"] == "external_directory" or rule["action"] == "deny"]
    for permission in ("todowrite", "task"):
        if not any(rule.permission == permission for rule in next_agent.permission):
            deny = {"permission": permission, "pattern": "*", "action": "deny"}
            if deny not in child_permission:
                child_permission.append(deny)
    depth += 1
    background = bool(args.get("background"))
    task_id = args.get("task_id")

    child = None
    if task_id:
        try:
            child = ctx.app.store.get_session(task_id)
        except KeyError:
            pass
    if child is None:
        child = ctx.app.store.create_session(
            directory=str(ctx.directory),
            agent=subagent,
            model=model,
            title=description + f" (@{next_agent.name} subagent)",
            parent_id=ctx.session_id,
            permission=child_permission,
        )
    else:
        # A resumed subagent follows the parent's search switches as they are now.
        switches = search_switch.states(parent.get("permission"))
        if search_switch.states(child.get("permission")) != switches:
            ctx.app.store.update_session(child["id"], permission=search_switch.apply(child.get("permission"), switches))
    session_id = child["id"]
    if child.get("model") != model:
        ctx.app.store.update_session(session_id, model=model)
    with ctx.app._execution_lock:
        control = ctx.app._background.get(session_id)
        active_background = control is not None and not control.is_set()
        if active_background:
            # Check and extend the same live job atomically with cancellation.
            ctx.app.spawn_background(session_id, prompt, subagent, depth, ctx.session_id, model=model,
                                     _abort_event=_abort_event(ctx))
    if background and not active_background:
        ctx.app.spawn_background(session_id, prompt, subagent, depth, ctx.session_id, model=model,
                                 _abort_event=_abort_event(ctx))
    if background or active_background:
        summary = "Background task updated" if active_background else "Background task started"
        background_text = (
            "Additional context sent to the running background task.\n"
            "The task is still working in the background. You will be notified automatically when it finishes."
            if active_background else
            "The task is working in the background. You will be notified automatically when it finishes."
        )
        return ToolResult(
            title=description,
            output=(
                f'<task id="{session_id}" state="running">\n'
                f"<summary>{summary}</summary>\n<task_result>\n{background_text}\n"
                "DO NOT sleep, poll for progress, ask the task for status, or duplicate this task's work — avoid working with the same files or topics it is using.\n"
                + ("Work on non-overlapping tasks, or briefly tell the user what you sent and end your response.\n"
                   if active_background else
                   "Work on non-overlapping tasks, or briefly tell the user what you launched and end your response.\n") +
                "</task_result>\n"
                "</task>"
            ),
            metadata={"sessionID": session_id},
        )
    result = ctx.app.run_prompt(session_id, prompt, agent=subagent, model=model, depth=depth, on_text=None,
                                _parent_id=ctx.session_id, _abort_event=_abort_event(ctx))
    text = result.get("text") or ""
    state = result.get("status", "completed")
    return ToolResult(
        title=description,
        output=f'<task id="{session_id}" state="{state}">\n<summary>{description}</summary>\n<task_result>\n{text}\n</task_result>\n</task>',
        metadata={"sessionID": session_id},
    )


def _plan_file(ctx) -> Path:
    return ctx.worktree / ".opencode" / "plans" / f"{ctx.session_id}.md"


def _plan_exit(args: dict, ctx) -> ToolResult:
    plan = _plan_file(ctx).relative_to(ctx.worktree)
    answers = ctx.app.ask_questions(
        ctx.session_id,
        [
            {
                "question": f"Plan at {plan} is complete. Would you like to switch to the build agent and start implementing?",
                "header": "Build Agent",
                "options": [
                    {"label": "Yes", "description": "Switch to build agent and start implementing the plan"},
                    {"label": "No", "description": "Stay with plan agent to continue refining the plan"},
                ],
            }
        ],
        abort_event=_abort_event(ctx),
    )
    if answers and answers[0] and answers[0][0] == "No":
        raise PermissionRejected("The user dismissed this question")
    last_user = next((message for message in reversed(ctx.app.store.messages(ctx.session_id))
                      if message.get("role") == "user" and message.get("model")), None)
    if last_user is not None:
        model = last_user["model"]
    else:
        provider, model_id = ctx.app.provider.resolve(None)
        model = f"{provider.id}/{model_id}"
    ctx.app.store.add_message(ctx.session_id, "user", {
        "content": f"The plan at {plan} has been approved, you can now edit files. Execute the plan",
        "synthetic": True, "agent": "build", "model": model,
    })
    ctx.app.store.update_session(ctx.session_id, agent="build")
    ctx.switch_agent = "build"
    return ToolResult(
        title="Switching to build agent",
        output="User approved switching to build agent. Wait for further instructions.",
    )


def _plan_enter(args: dict, ctx) -> ToolResult:
    ctx.app.permissions.ask(
        session_id=ctx.session_id,
        permission="plan_enter",
        patterns=["*"],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata={},
        abort_event=_abort_event(ctx),
    )
    answers = ctx.app.ask_questions(
        ctx.session_id,
        [
            {
                "question": "This task looks like it would benefit from a plan. Switch to the plan agent?",
                "header": "Plan",
                "options": [
                    {"label": "Yes", "description": "Switch to plan and design the change before editing"},
                    {"label": "No", "description": "Keep implementing with the build agent"},
                ],
            }
        ],
        abort_event=_abort_event(ctx),
    )
    if answers and answers[0] and answers[0][0] == "No":
        return ToolResult(title="Staying in build", output="User chose to keep the current agent.")
    ctx.app.store.update_session(ctx.session_id, agent="plan")
    ctx.switch_agent = "plan"
    plan = _plan_file(ctx)
    return ToolResult(title="Switching to plan agent", output=f"Switched to plan agent. Write the plan to {plan}.")


def _apply_patch(args: dict, ctx) -> ToolResult:
    text = args.get("patchText") or ""
    if not text.strip():
        raise ValueError("patchText is required")
    hunks = parse_patch(text)
    changes = []
    for hunk in hunks:
        path = session_path(hunk.path, ctx)
        ensure_external_directory(ctx, path)
        destination = session_path(hunk.move_path, ctx) if hunk.move_path else path
        if hunk.type == "add":
            updated = hunk.contents
            if updated and not updated.endswith("\n"):
                updated += "\n"
        else:
            if not path.is_file():
                raise FileNotFoundError(path)
            original = path.read_bytes().decode("utf-8", errors="replace")
            updated = apply_chunks(original, hunk.chunks, str(path)) if hunk.type == "update" else None
            if hunk.move_path:
                ensure_external_directory(ctx, destination)
        changes.append((hunk.type, path, destination, updated))

    # A host's protected paths are refused to this tool, source and destination alike (opencode/integrity.py).
    for _, source, target, _ in changes:
        refuse_protected(ctx, source)
        refuse_protected(ctx, target)
    # Upstream validates every hunk before applying any file change.
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="edit",
                            patterns=[relative_path(ctx, path).replace("\\", "/") for _, path, _, _ in changes],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=_abort_event(ctx))
    changed = []
    summary = []
    for kind, path, destination, updated in changes:
        snapshot(ctx, path)
        if destination != path:
            snapshot(ctx, destination)
        if kind == "delete":
            path.unlink()
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(updated.encode("utf-8"))
            if destination != path:
                path.unlink()
            mark_read(ctx, destination)
        changed.append(str(destination))
        relative = str(destination.relative_to(ctx.worktree)) if destination.is_relative_to(ctx.worktree) else str(destination)
        label = {"add": "A", "delete": "D", "update": "M"}[kind]
        summary.append(f"{label} {relative.replace(chr(92), '/')}")
    output = "Success. Updated the following files:\n" + "\n".join(summary)
    return ToolResult(title=output, output=output, metadata={"files": changed})


def extra_tools() -> list[Tool]:
    todo_item = {
        "type": "object",
        "properties": {
            "id": prop("string", "Todo id"),
            "content": prop("string", "The task description"),
            "status": prop("string", "pending, in_progress, completed, or cancelled", enum=["pending", "in_progress", "completed", "cancelled"]),
            "priority": prop("string", "high, medium, or low", enum=["high", "medium", "low"]),
        },
        "required": ["content", "status"],
    }
    question_item = {
        "type": "object",
        "properties": {
            "question": prop("string", "The question to ask"),
            "header": prop("string", "Short label"),
            "options": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "label": prop("string", "Option label"),
                        "description": prop("string", "Option description"),
                    },
                    "required": ["label"],
                },
            },
            "multiple": prop("boolean", "Allow multiple selections"),
        },
        "required": ["question"],
    }
    return [
        Tool(
            "todowrite",
            load_prompt("todowrite.txt"),
            schema({"todos": {"type": "array", "items": todo_item, "description": "The updated todo list"}}, ["todos"]),
            _todo,
        ),
        Tool(
            "question",
            load_prompt("question.txt"),
            schema({"questions": {"type": "array", "items": question_item, "description": "Questions to ask"}}, ["questions"]),
            _question,
        ),
        Tool(
            "skill",
            load_prompt("skill.txt"),
            schema({"name": prop("string", "The name of the skill from available_skills")}, ["name"]),
            _skill,
        ),
        Tool(
            "task",
            load_prompt("task.txt"),
            schema(
                {
                    "description": prop("string", "A short (3-5 words) description of the task"),
                    "prompt": prop("string", "The task for the agent to perform"),
                    "subagent_type": prop("string", "The type of specialized agent to use for this task"),
                    "task_id": prop("string", "Resume a previous task by its task id"),
                    "command": prop("string", "The command that triggered this task"),
                    "background": prop("boolean", "Run the agent in the background"),
                },
                ["description", "prompt", "subagent_type"],
            ),
            _task,
        ),
        Tool("plan_exit", load_prompt("plan-exit.txt"), schema({}, []), _plan_exit),
        Tool("plan_enter", load_prompt("plan-enter.txt"), schema({}, []), _plan_enter),
        Tool(
            "apply_patch",
            load_prompt("apply_patch.txt"),
            schema({"patchText": prop("string", "The full patch text that describes all changes to be made")}, ["patchText"]),
            _apply_patch,
        ),
    ]
