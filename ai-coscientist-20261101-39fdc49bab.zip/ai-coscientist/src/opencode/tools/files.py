"""read, write, edit, grep, and glob."""

from __future__ import annotations

import os
import json
import platform
import re
import shutil
import subprocess
import tarfile
import tempfile
import zipfile
from pathlib import Path
from threading import Event, Lock, Thread

import httpx

from opencode.hidden import for_context as hidden_for
from opencode.instructions import resolve as resolve_instructions
from opencode.media import attachment_from_bytes, sniff_mime
from opencode.paths import data_dir
from opencode.permission import PermissionRejected
from opencode.prompts import load as load_prompt
from opencode.tools.types import Tool, ToolResult, prop, schema
from opencode import executor
from opencode.tools.util import (
    _abort_event,
    _run_cancellable,
    ask_file_permission,
    ensure_access,
    ensure_external_directory,
    mark_read,
    norm_key,
    refuse_protected,
    session_path,
    snapshot,
)

MAX_READ_BYTES = 50 * 1024
READ_LIMIT = 2000
MAX_LINE_LENGTH = 2000
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
BINARY_EXT = {".zip", ".tar", ".gz", ".exe", ".dll", ".so", ".class", ".jar", ".war", ".7z",
              ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".ods", ".odp", ".bin",
              ".dat", ".obj", ".o", ".a", ".lib", ".wasm", ".pyc", ".pyo"}
_edit_locks: dict[str, Lock] = {}
_edit_locks_guard = Lock()


def _truncate_utf16(text: str, limit: int, suffix: str) -> str:
    # JavaScript string.length and slice/substring count UTF-16 code units.
    encoded = text.encode("utf-16-le", errors="surrogatepass")
    if len(encoded) <= limit * 2:
        return text
    return encoded[:limit * 2].decode("utf-16-le", errors="surrogatepass") + suffix


def _read(args: dict, ctx) -> ToolResult:
    raw = args.get("filePath") or ""
    if not raw:
        raise ValueError("filePath is required")
    path = session_path(raw, ctx)
    ensure_access(ctx, path, "read")
    if not path.exists():
        suggestions = _suggest(path, hidden_for(ctx))
        raise FileNotFoundError(f"{path} does not exist.{suggestions}")
    if path.is_dir():
        return _read_dir(path, args, ctx)
    loaded = resolve_instructions(ctx, path)
    with path.open("rb") as stream:
        sample = stream.read(4096)
    mime = sniff_mime(sample, _mime(path))
    if mime in {"image/jpeg", "image/png", "image/gif", "image/webp", "application/pdf"}:
        return _read_media(path, ctx, loaded)
    if (path.suffix.lower() in BINARY_EXT or b"\0" in sample
            or sample and sum(byte < 9 or 13 < byte < 32 for byte in sample) / len(sample) > 0.3):
        raise ValueError(f"Cannot read binary file: {path}")
    offset = int(args.get("offset") or 1)
    limit = int(args.get("limit", READ_LIMIT))
    if offset < 0 or limit < 0:
        raise ValueError("offset and limit must be nonnegative")
    rendered = []
    count = size = 0
    more = cut = False
    with path.open(encoding="utf-8", errors="replace", newline=None) as stream:
        for line in stream:
            count += 1
            if count < offset:
                continue
            if len(rendered) >= limit:
                more = True
                continue
            line = line.rstrip("\n")
            line = _truncate_utf16(line, MAX_LINE_LENGTH, f"... (line truncated to {MAX_LINE_LENGTH} chars)")
            # Buffer.byteLength counts a split surrogate as U+FFFD in UTF-8.
            encoded_line = line.encode("utf-16-le", errors="surrogatepass").decode("utf-16-le", errors="replace")
            addition = len(encoded_line.encode("utf-8")) + bool(rendered)
            if size + addition > MAX_READ_BYTES:
                more = cut = True
                break
            rendered.append(line)
            size += addition
    if count < offset and not (count == 0 and offset == 1):
        raise ValueError(f"Offset {offset} is out of range for this file ({count} lines)")
    last = offset + len(rendered) - 1
    body = f"<path>{path}</path>\n<type>file</type>\n<content>\n\n"
    body += "\n".join(f"{offset + index}: {line}" for index, line in enumerate(rendered))
    if cut:
        body += f"\n\n(Output capped at 50 KB. Showing lines {offset}-{last}. Use offset={last + 1} to continue.)"
    elif more:
        body += f"\n\n(Showing lines {offset}-{last} of {count}. Use offset={last + 1} to continue.)"
    else:
        body += f"\n\n(End of file - total {count} lines)"
    body += "\n</content>"
    if loaded:
        body += "\n\n<system-reminder>\n" + "\n\n".join(text for _, text in loaded) + "\n</system-reminder>"
    mark_read(ctx, path)
    return ToolResult(title=_title(path, ctx), output=body,
                      metadata={"path": str(path), "loaded": [name for name, _ in loaded], "truncated": more or cut})


def _read_dir(path: Path, args: dict, ctx) -> ToolResult:
    offset = int(args.get("offset") or 1)
    limit = int(args.get("limit", READ_LIMIT))
    if offset < 0 or limit < 0:
        raise ValueError("offset and limit must be nonnegative")
    entries = []
    hidden = hidden_for(ctx)
    for child in sorted(path.iterdir(), key=lambda item: item.name.lower()):
        if hidden is not None and hidden.hides(child):
            continue
        suffix = "/" if child.is_dir() else ""
        entries.append(child.name + suffix)
    selected = entries[offset - 1 : offset - 1 + limit]
    mark_read(ctx, path)
    output = f"<path>{path}</path>\n<type>directory</type>\n<entries>\n" + "\n".join(selected)
    if offset - 1 + len(selected) < len(entries):
        output += f"\n\n(Showing {len(selected)} of {len(entries)} entries. Use 'offset' parameter to read beyond entry {offset + len(selected)})"
    else:
        output += f"\n\n({len(entries)} entries)"
    output += "\n</entries>"
    return ToolResult(title=_title(path, ctx), output=output, metadata={"count": len(entries), "loaded": [],
                                                                     "truncated": offset - 1 + len(selected) < len(entries)})


def _title(path: Path, ctx) -> str:
    try:
        return os.path.relpath(path, ctx.worktree)
    except ValueError:
        return str(path)


def _suggest(path: Path, hidden=None) -> str:
    parent = path.parent
    if not parent.is_dir():
        return ""
    names = [item.name for item in parent.iterdir() if hidden is None or not hidden.hides(item)]
    close = [name for name in names if path.name.lower() in name.lower()][:8]
    if not close:
        return ""
    return " Nearby: " + ", ".join(close)


def _read_media(path: Path, ctx, loaded: list[tuple[str, str]]) -> ToolResult:
    raw = path.read_bytes()
    mime = sniff_mime(raw, _mime(path))
    mark_read(ctx, path)
    attachment = attachment_from_bytes(raw, mime, filename=path.name)
    kind = "PDF" if mime == "application/pdf" else "Image"
    if attachment is None:
        return ToolResult(
            title=path.name,
            output=f"{kind} is {len(raw)} bytes and was not attached.",
            metadata={"path": str(path), "bytes": len(raw), "mime": mime, "loaded": [name for name, _ in loaded], "truncated": False},
        )
    return ToolResult(
        title=path.name,
        output=f"{kind} read successfully",
        metadata={"path": str(path), "bytes": len(raw), "mime": mime, "loaded": [name for name, _ in loaded], "truncated": False},
        attachments=[attachment],
    )


def _mime(path: Path) -> str:
    return {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".pdf": "application/pdf",
    }.get(path.suffix.lower(), "application/octet-stream")


def _write(args: dict, ctx) -> ToolResult:
    raw = args.get("filePath") or ""
    content = args.get("content")
    if not raw:
        raise ValueError("filePath is required")
    if content is None:
        raise ValueError("content is required")
    path = session_path(raw, ctx)
    ensure_external_directory(ctx, path)
    text = content if isinstance(content, str) else str(content)
    bom = path.is_file() and path.read_bytes().startswith(b"\xef\xbb\xbf")
    refuse_protected(ctx, path)
    ask_file_permission(ctx, path, "edit")
    snapshot(ctx, path)
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_text(path, text, bom or text.startswith("\ufeff"))
    mark_read(ctx, path)
    return ToolResult(title=_title(path, ctx), output="Wrote file successfully.", metadata={"path": str(path)})


def _edit(args: dict, ctx) -> ToolResult:
    path = session_path(args.get("filePath") or "", ctx)
    with _edit_locks_guard:
        lock = _edit_locks.setdefault(norm_key(path), Lock())
    with lock:
        return _edit_locked(args, ctx)


def _edit_locked(args: dict, ctx) -> ToolResult:
    raw = args.get("filePath") or ""
    old = args.get("oldString")
    new = args.get("newString")
    if not raw:
        raise ValueError("filePath is required")
    if old is None or new is None:
        raise ValueError("oldString and newString are required")
    if old == new:
        raise ValueError("No changes to apply: oldString and newString are identical.")
    path = session_path(raw, ctx)
    ensure_external_directory(ctx, path)
    if old == "":
        if path.exists():
            raise ValueError("oldString cannot be empty when editing an existing file. Provide the exact text to replace, or use write for an intentional full-file replacement.")
        refuse_protected(ctx, path)
        ask_file_permission(ctx, path, "edit")
        snapshot(ctx, path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _write_text(path, new, new.startswith("\ufeff"))
        mark_read(ctx, path)
        return ToolResult(title=_title(path, ctx), output="Edit applied successfully.", metadata={"path": str(path)})
    if not path.is_file():
        raise FileNotFoundError(path)
    text = path.read_bytes().decode("utf-8", errors="replace")
    bom = text.startswith("\ufeff")
    text = text.removeprefix("\ufeff")
    ending = "\r\n" if "\r\n" in text else "\n"
    old = old.replace("\r\n", "\n").replace("\n", ending)
    new = new.replace("\r\n", "\n").replace("\n", ending)
    replace_all = bool(args.get("replaceAll"))
    updated = _replace(text, old, new, replace_all)
    refuse_protected(ctx, path)
    ask_file_permission(ctx, path, "edit")
    snapshot(ctx, path)
    _write_text(path, updated, bom or updated.startswith("\ufeff"))
    mark_read(ctx, path)
    return ToolResult(
        title=_title(path, ctx),
        output="Edit applied successfully.",
        metadata={"path": str(path)},
    )


def _write_text(path: Path, text: str, bom: bool) -> None:
    path.write_bytes((("\ufeff" if bom else "") + text.removeprefix("\ufeff")).encode("utf-8"))


def _levenshtein(left: str, right: str) -> int:
    row = list(range(len(right) + 1))
    for index, char in enumerate(left, 1):
        current = [index]
        for column, other in enumerate(right, 1):
            current.append(min(row[column] + 1, current[-1] + 1, row[column - 1] + (char != other)))
        row = current
    return row[-1]


def _simple(content, find):
    yield find


def _line_trimmed(content, find):
    original = content.split("\n")
    search = find.split("\n")
    if search[-1] == "":
        search.pop()
    for start in range(len(original) - len(search) + 1):
        if all(original[start + index].strip() == line.strip() for index, line in enumerate(search)):
            yield "\n".join(original[start:start + len(search)])


def _block_anchor(content, find):
    original = content.split("\n")
    search = find.split("\n")
    if len(search) < 3:
        return
    if search[-1] == "":
        search.pop()
    delta = max(1, len(search) // 4)
    candidates = []
    for start, line in enumerate(original):
        if line.strip() != search[0].strip():
            continue
        for end in range(start + 2, len(original)):
            if original[end].strip() != search[-1].strip():
                continue
            if abs(end - start + 1 - len(search)) <= delta:
                candidates.append((start, end))
            break
    best = None
    best_score = -1
    for start, end in candidates:
        count = min(len(search) - 2, end - start - 1)
        score = 0 if count > 0 else 1.0
        for index in range(1, min(len(search) - 1, end - start)):
            left, right = original[start + index].strip(), search[index].strip()
            length = max(len(left), len(right))
            if length:
                score += (1 - _levenshtein(left, right) / length) / count
            if len(candidates) == 1 and score >= 0.65:
                break
        if score > best_score:
            best, best_score = (start, end), score
    if best is not None and best_score >= 0.65:
        yield "\n".join(original[best[0]:best[1] + 1])


def _whitespace_normalized(content, find):
    def normalize(text):
        return re.sub(r"\s+", " ", text).strip()

    normalized = normalize(find)
    lines = content.split("\n")
    for line in lines:
        if normalize(line) == normalized:
            yield line
        elif normalized in normalize(line):
            words = re.split(r"\s+", find.strip())
            match = re.search(r"\s+".join(re.escape(word) for word in words), line)
            if match:
                yield match[0]
    size = len(find.split("\n"))
    if size > 1:
        for start in range(len(lines) - size + 1):
            block = "\n".join(lines[start:start + size])
            if normalize(block) == normalized:
                yield block


def _indentation_flexible(content, find):
    def normalize(text):
        lines = text.split("\n")
        nonempty = [line for line in lines if line.strip()]
        if not nonempty:
            return text
        indent = min(len(re.match(r"\s*", line)[0]) for line in nonempty)
        return "\n".join(line[indent:] if line.strip() else line for line in lines)

    normalized = normalize(find)
    lines, size = content.split("\n"), len(find.split("\n"))
    for start in range(len(lines) - size + 1):
        block = "\n".join(lines[start:start + size])
        if normalize(block) == normalized:
            yield block


def _escape_normalized(content, find):
    def unescape(text):
        return re.sub(r"\\(n|t|r|'|\"|`|\\|\n|\$)",
                      lambda match: {"n": "\n", "t": "\t", "r": "\r"}.get(match[1], match[1]), text)

    unescaped = unescape(find)
    if unescaped in content:
        yield unescaped
    lines, size = content.split("\n"), len(unescaped.split("\n"))
    for start in range(len(lines) - size + 1):
        block = "\n".join(lines[start:start + size])
        if unescape(block) == unescaped:
            yield block


def _trimmed_boundary(content, find):
    trimmed = find.strip()
    if trimmed == find:
        return
    if trimmed in content:
        yield trimmed
    lines, size = content.split("\n"), len(find.split("\n"))
    for start in range(len(lines) - size + 1):
        block = "\n".join(lines[start:start + size])
        if block.strip() == trimmed:
            yield block


def _context_aware(content, find):
    search = find.split("\n")
    if len(search) < 3:
        return
    if search[-1] == "":
        search.pop()
    lines = content.split("\n")
    for start, line in enumerate(lines):
        if line.strip() != search[0].strip():
            continue
        for end in range(start + 2, len(lines)):
            if lines[end].strip() != search[-1].strip():
                continue
            block = lines[start:end + 1]
            if len(block) == len(search):
                pairs = [(left.strip(), right.strip()) for left, right in zip(block[1:-1], search[1:-1])
                         if left.strip() or right.strip()]
                if not pairs or sum(left == right for left, right in pairs) / len(pairs) >= 0.5:
                    yield "\n".join(block)
            break


def _multi_occurrence(content, find):
    start = 0
    while find:
        index = content.find(find, start)
        if index < 0:
            break
        yield find
        start = index + len(find)


def _replace(content, old, new, replace_all=False):
    if old == new:
        raise ValueError("No changes to apply: oldString and newString are identical.")
    if old == "":
        raise ValueError("oldString cannot be empty when editing an existing file. Provide the exact text to replace, or use write for an intentional full-file replacement.")
    not_found = True
    for replacer in (_simple, _line_trimmed, _block_anchor, _whitespace_normalized, _indentation_flexible,
                     _escape_normalized, _trimmed_boundary, _context_aware, _multi_occurrence):
        for search in replacer(content, old):
            index = content.find(search)
            if index < 0:
                continue
            not_found = False
            old_lines, search_lines = len(old.split("\n")), len(search.split("\n"))
            if (search_lines >= max(old_lines + 3, old_lines * 2)
                    or old_lines > 1 and len(search.strip()) > max(len(old.strip()) + 500, len(old.strip()) * 4)):
                raise ValueError("Refusing replacement because the matched span is much larger than oldString. Re-read the file and provide the full exact oldString for the intended replacement.")
            if replace_all:
                return content.replace(search, new)
            if index != content.rfind(search):
                continue
            return content[:index] + new + content[index + len(search):]
    if not_found:
        raise ValueError("Could not find oldString in the file. It must match exactly, including whitespace, indentation, and line endings.")
    raise ValueError("Found multiple matches for oldString. Provide more surrounding context to make the match unique.")


def _grep(args: dict, ctx) -> ToolResult:
    pattern = args.get("pattern") or ""
    if not pattern:
        raise ValueError("pattern is required")
    ctx.app.permissions.ask(abort_event=_abort_event(ctx), session_id=ctx.session_id, permission="grep", patterns=[pattern],
                            ruleset=ctx.agent.permission, always=["*"], metadata={})
    root = session_path(args.get("path") or str(ctx.directory), ctx)
    ensure_external_directory(ctx, root, kind="directory" if root.is_dir() else "file")
    include = args.get("include")
    cwd = root if root.is_dir() else root.parent
    command = ["--no-config", "--json", "--hidden", "--no-messages"]
    if include:
        command.append(f"--glob={include}")
    command.extend(["--glob=!**/.git/**", "--", pattern, "."])
    hidden = hidden_for(ctx)
    parse = _grep_record
    if hidden is not None:
        def parse(line):
            row = _grep_record(line)
            return None if row is not None and hidden.hides(cwd / _rg_relative(row["path"]["text"])) else row
    rows = _ripgrep(cwd, command, parse, pattern=pattern, abort=_search_abort(ctx))
    total = len(rows)
    truncated = total == 100
    metadata = {"matches": total, "truncated": truncated}
    if not rows:
        return ToolResult(title=pattern, output="No files found", metadata=metadata)
    output = [f"Found {total} matches" + (" (more matches available)" if truncated else "")]
    current = None
    for row in rows:
        path = str((cwd / _rg_relative(row["path"]["text"])).resolve())
        if current != path:
            if current is not None:
                output.append("")
            current = path
            output.append(f"{path}:")
        text = _truncate_utf16(row["lines"]["text"], MAX_LINE_LENGTH, "...")
        output.append(f"  Line {row['line_number']}: {text}")
    if truncated:
        output.extend(["", "(Results truncated. Consider using a more specific path or pattern.)"])
    return ToolResult(title=pattern, output="\n".join(output), metadata=metadata)


def _glob(args: dict, ctx) -> ToolResult:
    pattern = args["pattern"]
    ctx.app.permissions.ask(abort_event=_abort_event(ctx), session_id=ctx.session_id, permission="glob", patterns=[pattern],
                            ruleset=ctx.agent.permission, always=["*"], metadata={})
    root = session_path(args.get("path") or str(ctx.directory), ctx)
    if root.is_file():
        raise ValueError(f"glob path must be a directory: {root}")
    ensure_external_directory(ctx, root, kind="directory")
    hidden = hidden_for(ctx)
    parse = _rg_relative
    if hidden is not None:
        def parse(line):
            name = _rg_relative(line)
            return None if hidden.hides(root / name) else name
    matches = _ripgrep(root, ["--no-config", "--files", f"--glob={pattern}", "--glob=!**/.git/**", "."],
                       parse, abort=_search_abort(ctx))
    truncated = len(matches) == 100
    output = [str((root / name).resolve()) for name in matches] or ["No files found"]
    if truncated:
        output.extend(["", "(Results are truncated: showing first 100 results. Consider using a more specific path or pattern.)"])
    return ToolResult(title=_title(root, ctx), output="\n".join(output),
                      metadata={"count": len(matches), "truncated": truncated})


def _rg_relative(value: str) -> str:
    return re.sub(r"^[\\/]+", "", re.sub(r"^(?:\.[\\/])+", "", value)).replace("\\", "/")


def _grep_record(line: str):
    if len(line.encode("utf-8")) > 64 * 1024:
        raise RuntimeError("Ripgrep JSON record exceeded 65536 bytes")
    try:
        record = json.loads(line)
    except ValueError as error:
        raise RuntimeError("Invalid ripgrep JSON output") from error
    if not isinstance(record, dict) or record.get("type") != "match":
        return None
    data = record.get("data")
    try:
        valid = (isinstance(data, dict)
                 and isinstance(data["path"]["text"], str) and isinstance(data["lines"]["text"], str)
                 and type(data["line_number"]) is int and data["line_number"] >= 1
                 and type(data["absolute_offset"]) is int and data["absolute_offset"] >= 0
                 and isinstance(data["submatches"], list)
                 and all(isinstance(item["match"]["text"], str)
                         and type(item["start"]) is int and item["start"] >= 0
                         and type(item["end"]) is int and item["end"] >= 0 for item in data["submatches"]))
    except (KeyError, TypeError):
        valid = False
    if not valid:
        raise RuntimeError("Invalid ripgrep match output")
    return data


def _search_abort(ctx):
    return _abort_event(ctx)


def _ripgrep(cwd: Path, args: list[str], parse, *, pattern: str | None = None, abort=None):
    if abort is not None and abort.is_set():
        raise PermissionRejected("Execution stopped")
    executable = _ripgrep_binary(abort=abort) if abort is not None else _ripgrep_binary()
    if abort is not None and abort.is_set():
        raise PermissionRejected("Execution stopped")
    process = executor.spawn([executable, *args], executor.Launch("agent_search", "ripgrep"),
                             cwd=cwd, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    errors = bytearray()
    done = Event()

    def watch_abort():
        while not done.wait(0.05):
            if abort.is_set():
                try:
                    process.kill()
                except OSError:
                    pass
                return

    watcher = Thread(target=watch_abort, name="opencode-ripgrep-abort", daemon=True) if abort is not None else None
    if watcher is not None:
        watcher.start()

    def read_errors():
        while chunk := process.stderr.read(8192):
            if len(errors) < 8192:
                errors.extend(chunk[:8192 - len(errors)])

    reader = Thread(target=read_errors, daemon=True)
    reader.start()
    rows = []
    try:
        for raw in process.stdout:
            if abort is not None and abort.is_set():
                raise PermissionRejected("Execution stopped")
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if not line:
                continue
            row = parse(line)
            if row is not None:
                rows.append(row)
            if len(rows) > 100:
                return rows[:100]
        code = process.wait()
        reader.join()
        if abort is not None and abort.is_set():
            raise PermissionRejected("Execution stopped")
        error = errors.decode("utf-8", errors="replace").strip()
        if pattern and code == 2 and ("regex parse error" in error or "error parsing regex" in error):
            raise ValueError(error)
        if code not in (0, 1, 2):
            raise RuntimeError(error or f"ripgrep failed with code {code}")
        return [] if code == 1 else rows
    finally:
        done.set()
        if watcher is not None:
            watcher.join()
        if process.poll() is None:
            try:
                process.kill()
            except OSError:
                pass
        process.wait()
        reader.join()
        process.stdout.close()
        process.stderr.close()


_ripgrep_lock = Lock()


def _ripgrep_binary(*, abort=None) -> str:
    executable = "rg.exe" if os.name == "nt" else "rg"
    system = _which(executable)
    if system and Path(system).is_file():
        return system
    target = data_dir() / "bin" / executable
    while not _ripgrep_lock.acquire(timeout=0.05):
        if abort is not None and abort.is_set():
            raise PermissionRejected("Execution stopped")
    try:
        if abort is not None and abort.is_set():
            raise PermissionRejected("Execution stopped")
        if target.is_file():
            return str(target)
        system_name = {"Windows": "win32", "Darwin": "darwin", "Linux": "linux"}.get(platform.system())
        architecture = {"AMD64": "x64", "x86_64": "x64", "arm64": "arm64", "aarch64": "arm64",
                        "x86": "ia32", "i386": "ia32", "i686": "ia32"}.get(platform.machine())
        key = f"{architecture}-{system_name}"
        platforms = {
            "arm64-darwin": ("aarch64-apple-darwin", "tar.gz"),
            "arm64-linux": ("aarch64-unknown-linux-gnu", "tar.gz"),
            "x64-darwin": ("x86_64-apple-darwin", "tar.gz"),
            "x64-linux": ("x86_64-unknown-linux-musl", "tar.gz"),
            "arm64-win32": ("aarch64-pc-windows-msvc", "zip"),
            "ia32-win32": ("i686-pc-windows-msvc", "zip"),
            "x64-win32": ("x86_64-pc-windows-msvc", "zip"),
        }
        if key not in platforms:
            raise RuntimeError(f"unsupported platform for ripgrep: {key}")
        triple, extension = platforms[key]
        filename = f"ripgrep-15.1.0-{triple}.{extension}"
        url = f"https://github.com/BurntSushi/ripgrep/releases/download/15.1.0/{filename}"
        target.parent.mkdir(parents=True, exist_ok=True)
        if abort is None:
            with httpx.Client(follow_redirects=True) as client:
                response = client.get(url)
                response.raise_for_status()
                content = response.content
        else:
            async def request():
                async with httpx.AsyncClient(follow_redirects=True) as client:
                    response = await client.get(url)
                    response.raise_for_status()
                    return response.content

            content = _run_cancellable(request, abort)
        if not content:
            raise RuntimeError(f"failed to download ripgrep from {url}")
        archive = target.parent / filename
        archive.write_bytes(content)
        member = f"ripgrep-15.1.0-{triple}/{executable}"
        with tempfile.TemporaryDirectory(dir=target.parent, prefix="ripgrep-") as folder:
            extracted = Path(folder) / executable
            if extension == "zip":
                with zipfile.ZipFile(archive) as source:
                    try:
                        binary = source.read(member)
                    except KeyError as error:
                        raise RuntimeError(f"ripgrep archive did not contain executable: {member}") from error
            else:
                with tarfile.open(archive, "r:gz") as source:
                    try:
                        stream = source.extractfile(member)
                    except KeyError as error:
                        raise RuntimeError(f"ripgrep archive did not contain executable: {member}") from error
                    if stream is None:
                        raise RuntimeError(f"ripgrep archive did not contain executable: {member}")
                    with stream:
                        binary = stream.read()
            extracted.write_bytes(binary)
            shutil.copyfile(extracted, target)
        if os.name != "nt":
            target.chmod(0o755)
        try:
            archive.unlink()
        except OSError:
            pass
        return str(target)
    finally:
        _ripgrep_lock.release()


def _which(name: str) -> str | None:
    from shutil import which

    return which(name)


def file_tools() -> list[Tool]:
    return [
        Tool(
            "read",
            load_prompt("read.txt"),
            schema(
                {
                    "filePath": prop("string", "The absolute path to the file or directory to read"),
                    "offset": prop("integer", "The line number to start reading from (1-indexed)"),
                    "limit": prop("integer", "The maximum number of lines to read (defaults to 2000)"),
                },
                ["filePath"],
            ),
            _read,
        ),
        Tool(
            "write",
            load_prompt("write.txt"),
            schema(
                {
                    "filePath": prop("string", "The absolute path to the file to write (must be absolute, not relative)"),
                    "content": prop("string", "The content to write to the file"),
                },
                ["filePath", "content"],
            ),
            _write,
        ),
        Tool(
            "edit",
            load_prompt("edit.txt"),
            schema(
                {
                    "filePath": prop("string", "The absolute path to the file to modify"),
                    "oldString": prop("string", "The text to replace"),
                    "newString": prop("string", "The text to replace it with (must be different from oldString)"),
                    "replaceAll": prop("boolean", "Replace all occurrences of oldString (default false)"),
                },
                ["filePath", "oldString", "newString"],
            ),
            _edit,
        ),
        Tool(
            "grep",
            load_prompt("grep.txt"),
            schema(
                {
                    "pattern": prop("string", "The regex pattern to search for in file contents"),
                    "path": prop("string", "The directory to search in. Defaults to the current working directory."),
                    "include": prop("string", 'File pattern to include in the search (e.g. "*.js", "*.{ts,tsx}")'),
                },
                ["pattern"],
            ),
            _grep,
        ),
        Tool(
            "glob",
            load_prompt("glob.txt"),
            schema(
                {
                    "pattern": prop("string", "The glob pattern to match files against"),
                    "path": prop(
                        "string",
                        "The directory to search in. If not specified, the current working directory will be used.",
                    ),
                },
                ["pattern"],
            ),
            _glob,
        ),
    ]
