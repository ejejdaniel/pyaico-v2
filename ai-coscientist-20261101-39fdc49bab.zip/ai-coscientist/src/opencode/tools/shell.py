"""bash tool. The permission key stays `bash` so saved rules keep working."""

from __future__ import annotations

import os
import codecs
import re
import signal
import subprocess
import sys
import time
from collections import deque
from pathlib import Path
from shutil import which
from threading import Thread

from opencode.hidden import for_context as hidden_for
from opencode.paths import tmp_dir, truncation_dir
from opencode.permission import PermissionRejected
from opencode.prompts import load as load_prompt
from opencode.store import new_id
from opencode.tools.shell_ast import path_pattern, resolve_shell_path, scan
from opencode.tools.types import Tool, ToolResult, prop, schema
from opencode.tools.util import _abort_event
from opencode import executor


def description(config: dict | None = None) -> str:
    config = config or {}
    shell = _shell_name(_shell_executable(config))
    template = load_prompt("bash.txt")
    platform = "win32" if os.name == "nt" else sys.platform
    limits = config.get("tool_output") or {}
    timeout = 120_000
    if shell == "powershell":
        chain = "If the commands depend on each other and must run sequentially, avoid '&&' in this shell because Windows PowerShell (5.1) does not support it. Use PowerShell conditionals such as `cmd1; if ($?) { cmd2 }` when later commands must depend on earlier success."
    elif shell == "pwsh":
        chain = 'If the commands depend on each other and must run sequentially, use a single bash tool call with \'&&\' to chain them together (e.g., `git add . && git commit -m "message" && git push`). For instance, if one operation must complete before another starts (like New-Item before Copy-Item, Write before bash for git operations, or git add before git commit), run these operations sequentially instead.'
    elif shell == "cmd":
        chain = "If the commands depend on each other and must run sequentially, use a single bash tool call with `&&` to chain them together (e.g., `mkdir out && dir out`). For instance, if one operation must complete before another starts, run these operations sequentially instead."
    else:
        chain = 'If the commands depend on each other and must run sequentially, use a single Bash call with \'&&\' to chain them together (e.g., `git add . && git commit -m "message" && git push`). For instance, if one operation must complete before another starts (like mkdir before cp, Write before Bash for git operations, or git add before git commit), run these operations sequentially instead.'
    powershell = shell in {"powershell", "pwsh"}
    section = load_prompt("shell-powershell.txt" if powershell else "shell-cmd.txt" if shell == "cmd" else "shell-bash.txt")
    path_sep = "\\" if platform == "win32" else "/"
    section_values = {"chain": chain, "maxLines": str(limits.get("max_lines", 2000)),
                      "maxBytes": str(limits.get("max_bytes", 50 * 1024)), "defaultTimeoutMs": str(timeout),
                      "pathSep": path_sep}
    if powershell:
        section_values["notes"] = load_prompt(f"shell-{shell}-notes.txt")
        section_values["badExample"] = (f'Set-Location -LiteralPath "project{path_sep}subdir"; if ($?) {{ pytest tests }}'
                                        if shell == "powershell" else f'Set-Location -LiteralPath "project{path_sep}subdir" && pytest tests')
    section = re.sub(r"\$\{(\w+)\}", lambda match: section_values[match[1]], section)
    display = {"pwsh": "PowerShell (7+)", "powershell": "Windows PowerShell (5.1)", "cmd": "cmd.exe"}.get(shell, shell)
    values = {
        "intro": (f"Executes a given {display} command with optional timeout, ensuring proper handling and security measures."
                  if powershell or shell == "cmd" else "Executes a given bash command in a persistent shell session with optional timeout, ensuring proper handling and security measures."),
        "os": platform,
        "shell": shell,
        "workdirSection": ("All commands run in the current working directory by default. Use the `workdir` parameter if you need to run a command in a different directory. "
                           + ("AVOID changing directories inside the command - use `workdir` instead." if powershell or shell == "cmd"
                              else "AVOID using `cd <directory> && <command>` patterns - use `workdir` instead.")),
        "tmp": str(tmp_dir()),
        "commandSection": section,
    }
    rendered = template
    for key, value in values.items():
        rendered = rendered.replace("${" + key + "}", value)
    return rendered


def _shell_name(executable: str) -> str:
    return (Path(executable).stem if os.name == "nt" else Path(executable).name).lower()


def _gitbash() -> str | None:
    if os.name != "nt":
        return None
    explicit = os.environ.get("OPENCODE_GIT_BASH_PATH")
    if explicit:
        return explicit
    git = which("git")
    path = Path(git).parent.parent / "bin" / "bash.exe" if git else None
    return str(path) if path and path.is_file() else None


def _shell_executable(config: dict | None = None) -> str:
    requested = (config or {}).get("shell") or os.environ.get("SHELL")
    if requested and _shell_name(requested) not in {"fish", "nu"}:
        candidate = _gitbash() if os.name == "nt" and _shell_name(requested) == "bash" else None
        candidate = candidate or (requested if Path(requested).is_file() else which(requested))
        if candidate:
            return candidate
    if os.name == "nt":
        return which("pwsh") or which("powershell") or _gitbash() or os.environ.get("COMSPEC") or "cmd.exe"
    if sys.platform == "darwin":
        return "/bin/zsh"
    return which("bash") or "/bin/sh"


# Git Bash on Windows silently cuts a `bash -c` argument past about 8192 characters: the rest
# of the command never runs and nothing reports it (v17 lost the end of a heredoc that way).
LONG_COMMAND = 4096
POSIX_SHELLS = {"bash", "sh", "zsh", "dash", "ksh"}


def _command_script(command: str, executable: str) -> Path | None:
    """A temporary script file holding a long command for a POSIX shell on Windows, else None.

    The shell then reads the command from the file instead of its command line, so no length
    limit applies. Short commands, other shells and other systems keep `-c` unchanged.
    """
    if os.name != "nt" or len(command) <= LONG_COMMAND or Path(executable).stem.lower() not in POSIX_SHELLS:
        return None
    folder = tmp_dir()
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"command-{new_id('sh')}.sh"
    with path.open("xb") as stream:
        stream.write(command.encode("utf-8"))
    return path


def _command_line(command: str, executable: str | None = None, script: Path | None = None) -> list[str]:
    executable = executable or _shell_executable()
    if script is not None:
        return [executable, script.as_posix()]
    if Path(executable).stem.lower() in {"powershell", "pwsh"}:
        return [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
    if Path(executable).stem.lower() == "cmd":
        return [executable, "/d", "/s", "/c", command]
    return [executable, "-c", command]


def _ask(ctx, command: str, workdir: Path, executable: str) -> None:
    directories, patterns, always = scan(command, workdir, ctx.worktree, executable, directory=ctx.directory)
    if directories:
        globs = [path_pattern(path) for path in directories]
        ctx.app.permissions.ask(
            abort_event=_abort_event(ctx),
            session_id=ctx.session_id,
            permission="external_directory",
            patterns=globs,
            ruleset=ctx.agent.permission,
            always=globs,
            metadata={"command": command, "directories": [str(path) for path in directories], "patterns": globs},
        )
    if patterns:
        ctx.app.permissions.ask(
            abort_event=_abort_event(ctx),
            session_id=ctx.session_id,
            permission="bash",
            patterns=patterns,
            ruleset=ctx.agent.permission,
            always=always,
            metadata={"command": command},
        )


def _windows_job():
    """Own one Windows command tree without depending on taskkill credentials."""
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.CreateJobObjectW.restype = wintypes.HANDLE
    kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    kernel.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
    kernel.TerminateJobObject.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.CreateJobObjectW(None, None)
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    return kernel, handle


def _terminate_tree(process: subprocess.Popen, *, force: bool = False, job=None) -> None:
    if os.name == "nt":
        import ctypes
        kernel, handle = job
        if not kernel.TerminateJobObject(handle, 1):
            raise ctypes.WinError(ctypes.get_last_error())
        return
    try:
        os.killpg(process.pid, signal.SIGKILL if force else signal.SIGTERM)
    except ProcessLookupError:
        pass


def _resume_windows_process(process: subprocess.Popen, kernel) -> None:
    """Resume the initial thread only after its suspended process joins our job."""
    import ctypes
    from ctypes import wintypes

    class ThreadEntry(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("usage", wintypes.DWORD),
                    ("id", wintypes.DWORD), ("owner", wintypes.DWORD),
                    ("base_priority", wintypes.LONG), ("delta_priority", wintypes.LONG),
                    ("flags", wintypes.DWORD)]

    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Thread32First.argtypes = [wintypes.HANDLE, ctypes.POINTER(ThreadEntry)]
    kernel.Thread32Next.argtypes = [wintypes.HANDLE, ctypes.POINTER(ThreadEntry)]
    kernel.OpenThread.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel.OpenThread.restype = wintypes.HANDLE
    kernel.ResumeThread.argtypes = [wintypes.HANDLE]
    kernel.ResumeThread.restype = wintypes.DWORD
    snapshot = kernel.CreateToolhelp32Snapshot(0x00000004, 0)  # TH32CS_SNAPTHREAD
    if snapshot == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        entry = ThreadEntry()
        entry.size = ctypes.sizeof(entry)
        found = kernel.Thread32First(snapshot, ctypes.byref(entry))
        while found:
            if entry.owner == process.pid:
                thread = kernel.OpenThread(0x0002, False, entry.id)  # THREAD_SUSPEND_RESUME
                if not thread:
                    raise ctypes.WinError(ctypes.get_last_error())
                try:
                    if kernel.ResumeThread(thread) == 0xFFFFFFFF:
                        raise ctypes.WinError(ctypes.get_last_error())
                    return
                finally:
                    kernel.CloseHandle(thread)
            found = kernel.Thread32Next(snapshot, ctypes.byref(entry))
        raise RuntimeError("Cannot find the suspended shell's initial thread")
    finally:
        kernel.CloseHandle(snapshot)


def _run(command: str, workdir: Path, env: dict, timeout: float, abort, *, executable=None, on_chunk=None):
    # CREATE_SUSPENDED prevents any command/descendant from running before job assignment.
    options = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW | 0x00000004} if os.name == "nt" else {"start_new_session": True}
    job = _windows_job() if os.name == "nt" else None
    job_assigned = False
    process = None
    deadline = time.monotonic() + timeout + 0.1
    reason = ""
    chunks = []
    reader = None
    read_errors = []
    executable = executable or _shell_executable()
    script = None
    try:
        script = _command_script(command, executable)
        process = executor.spawn(
            _command_line(command, executable, script), executor.Launch("agent_command"),
            cwd=str(workdir), stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env, **options,
        )
        if job is not None:
            import ctypes
            kernel, handle = job
            if not kernel.AssignProcessToJobObject(handle, int(process._handle)):
                error = ctypes.get_last_error()
                raise ctypes.WinError(error)
            job_assigned = True
            _resume_windows_process(process, kernel)

        def drain():
            decoder = codecs.getincrementaldecoder("utf-8")("replace")
            try:
                while raw := process.stdout.read1(8192):
                    chunk = decoder.decode(raw)
                    if chunk:
                        on_chunk(chunk) if on_chunk else chunks.append(chunk)
                final = decoder.decode(b"", final=True)
                if final:
                    on_chunk(final) if on_chunk else chunks.append(final)
            except BaseException as exc:
                read_errors.append(exc)

        reader = Thread(target=drain, name="opencode-shell-output", daemon=True)
        reader.start()
        while True:
            if read_errors:
                raise read_errors[0]
            if abort is not None and abort.is_set():
                reason = "abort"
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                reason = "timeout"
                break
            try:
                process.wait(timeout=min(remaining, 0.05))
                break
            except subprocess.TimeoutExpired:
                continue
        if reason:
            _terminate_tree(process, job=job)
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                _terminate_tree(process, force=True, job=job)
                process.wait()
        while reader.is_alive():
            reader.join(timeout=0.05)
            if not reader.is_alive():
                break
            if not reason and abort is not None and abort.is_set():
                reason = "abort"
                _terminate_tree(process, job=job)
            if not reason and time.monotonic() >= deadline:
                reason = "timeout"
                _terminate_tree(process, job=job)
        if read_errors:
            raise read_errors[0]
        return "".join(chunks), "", None if reason else process.returncode, reason
    except BaseException as error:
        if process is not None:
            try:
                if job is not None and not job_assigned:
                    # Assignment failed while the initial thread was suspended:
                    # the job owns nothing, so terminate this process directly.
                    process.kill()
                else:
                    _terminate_tree(process, force=True, job=job)
                process.wait(timeout=3)
                if reader:
                    reader.join(timeout=3)
            except Exception as cleanup_error:
                error.add_note(f"Shell cleanup also failed: {cleanup_error}")
        raise
    finally:
        if job is not None:
            job[0].CloseHandle(job[1])
        if process is not None and process.stdout is not None:
            process.stdout.close()
        if process is not None and process.stderr is not None:
            process.stderr.close()
        if script is not None:
            try:
                script.unlink()
            except OSError:
                pass  # a leftover file in the temp folder must not turn a finished command into a failure


def _bash(args: dict, ctx) -> ToolResult:
    command = args.get("command") or ""
    if not command.strip():
        raise ValueError("command is required")
    config = getattr(ctx.app, "config", {})
    executable = _shell_executable(config)
    timeout_ms = int(args["timeout"]) if args.get("timeout") is not None else 120_000
    if timeout_ms < 0:
        raise ValueError(f"Invalid timeout value: {timeout_ms}. Timeout must be a positive number.")
    timeout = timeout_ms / 1000
    workdir = resolve_shell_path(args["workdir"], ctx.directory, executable) if args.get("workdir") else ctx.directory
    hidden = hidden_for(ctx)
    named = None if hidden is None else str(workdir) if hidden.hides(workdir) else hidden.command(command, workdir)
    if named:
        # A command naming a host record is answered as the shell answers a missing file, without running.
        text = f"{named}: No such file or directory"
        return ToolResult(title=command, output=f"{text}\n\n<shell_metadata>\nCommand exited with code 1.\n</shell_metadata>",
                          metadata={"truncated": False, "exit": 1, "output": text})
    _ask(ctx, command, workdir, executable)
    env = os.environ.copy()
    # Output is decoded as UTF-8; make Python children read, write and print UTF-8 too
    # instead of the Windows code page (an explicit user setting still wins).
    env.setdefault("PYTHONUTF8", "1")
    abort = _abort_event(ctx)
    if abort is not None and abort.is_set():
        raise PermissionRejected("Execution stopped")
    limits = config.get("tool_output") or {}
    output = _Output(limits.get("max_lines", 2000), limits.get("max_bytes", 50 * 1024))
    try:
        _, _, returncode, reason = _run(command, workdir, env, timeout, abort,
                                       executable=executable, on_chunk=output.append)
    finally:
        output.close()
    result, metadata = output.finish()
    if hidden is not None:
        # Lines that name a host record are dropped, from the saved full output too.
        result = hidden.clean(result, workdir, command) or "(no output)"
        _clean_saved(metadata.get("outputPath"), hidden, workdir, command)
    notices = []
    if reason == "timeout":
        notices.append(f"shell tool terminated command after exceeding timeout {timeout_ms} ms. If this command is expected to take longer and is not waiting for interactive input, retry with a larger timeout value in milliseconds.")
    if reason == "abort":
        notices.append("User aborted the command")
    if not reason and returncode not in (0, None):
        # Without this the model cannot tell a failed command from a quiet one.
        notices.append(f"Command exited with code {returncode}.")
    if notices:
        result += "\n\n<shell_metadata>\n" + "\n".join(notices) + "\n</shell_metadata>"
    metadata["exit"] = returncode
    metadata["output"] = output.last or _preview(result)
    if hidden is not None:
        metadata["output"] = hidden.clean(metadata["output"], workdir, command)
    return ToolResult(title=command, output=result, metadata=metadata)


def _clean_saved(path, hidden, workdir, command) -> None:
    if not path:
        return
    saved = Path(path)
    text = saved.read_bytes().decode("utf-8", errors="replace")
    cleaned = hidden.clean(text, workdir, command)
    if cleaned != text:
        saved.write_bytes(cleaned.encode("utf-8"))


def _preview(text: str) -> str:
    return text if len(text) <= 30_000 else "...\n\n" + text[-30_000:]


def _tail(text: str, max_lines: int, max_bytes: int) -> tuple[str, bool]:
    lines = text.split("\n")
    if len(lines) <= max_lines and len(text.encode("utf-8")) <= max_bytes:
        return text, False
    kept, used = [], 0
    for line in reversed(lines):
        if len(kept) >= max_lines:
            break
        size = len(line.encode("utf-8")) + bool(kept)
        if used + size > max_bytes:
            if not kept:
                kept.append(line.encode("utf-8")[-max_bytes:].decode("utf-8", "ignore"))
            break
        kept.append(line)
        used += size
    return "\n".join(reversed(kept)), True


class _Output:
    """Keep the upstream bounded tail while streaming complete output to disk."""

    def __init__(self, max_lines, max_bytes):
        self.max_lines, self.max_bytes = max_lines, max_bytes
        self.chunks = deque()
        self.used = 0
        self.full = ""
        self.last = ""
        self.path = None
        self.sink = None
        self.cut = False

    def append(self, text):
        size = len(text.encode("utf-8"))
        self.chunks.append((text, size))
        self.used += size
        while self.used > self.max_bytes * 2 and len(self.chunks) > 1:
            self.used -= self.chunks.popleft()[1]
            self.cut = True
        self.last = _preview(self.last + text)
        if self.sink is not None:
            self.sink.write(text.encode("utf-8"))
        else:
            self.full += text
            if len(self.full.encode("utf-8")) > self.max_bytes:
                self._save(self.full)
                self.cut = True
                self.sink = self.path.open("ab")
                self.full = ""

    def _save(self, text):
        folder = truncation_dir()
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / new_id("tool")
        self.path.write_bytes(text.encode("utf-8"))

    def close(self):
        if self.sink is not None:
            self.sink.close()
            self.sink = None

    def finish(self):
        raw = "".join(text for text, _ in self.chunks)
        output, cut = _tail(raw, self.max_lines, self.max_bytes)
        self.cut = self.cut or cut
        if self.path is None and cut:
            self._save(raw)
        output = output or "(no output)"
        metadata = {"truncated": self.cut}
        if self.cut and self.path is not None:
            output = f"...output truncated...\n\nFull output saved to: {self.path}\n\n" + output
            metadata["outputPath"] = str(self.path)
        return output, metadata


def shell_tool(config: dict | None = None) -> Tool:
    return Tool(
        "bash",
        description(config),
        schema(
            {
                "command": prop("string", "The command to execute"),
                "timeout": prop("integer", "Optional timeout in milliseconds", minimum=1),
                "workdir": prop(
                    "string",
                    "The working directory to run the command in. Defaults to the current directory. Use this instead of 'cd' commands.",
                ),
            },
            ["command"],
        ),
        _bash,
    )
