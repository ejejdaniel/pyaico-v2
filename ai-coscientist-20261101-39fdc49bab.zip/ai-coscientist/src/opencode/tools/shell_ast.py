"""Internal Tree-sitter permission scan, ported from OpenCode 1.18.9 shell.ts.

This is shell syntax bookkeeping, not a sandbox or an interpreter. As upstream,
dynamic paths are not evaluated and only the listed file commands supply paths.
"""

from __future__ import annotations

import os
import re
import subprocess
from functools import lru_cache
from pathlib import Path

from tree_sitter import Language, Parser
import tree_sitter_bash
import tree_sitter_powershell

from opencode.tools.util import inside
from opencode import executor

_CWD = {"cd", "chdir", "popd", "pushd", "push-location", "set-location"}
_FILES = _CWD | {
    "rm", "cp", "mv", "mkdir", "touch", "chmod", "chown", "cat", "get-content",
    "set-content", "add-content", "copy-item", "move-item", "remove-item", "new-item", "rename-item",
}
_CMD_FILES = {"copy", "del", "dir", "erase", "md", "mkdir", "move", "rd", "ren", "rename", "rmdir", "type"}
_FLAGS = {"-destination", "-literalpath", "-path"}
_SWITCHES = {"-confirm", "-debug", "-force", "-nonewline", "-recurse", "-verbose", "-whatif"}

# Exact ARITY entries from packages/opencode/src/permission/arity.ts (1.18.9).
# The explicit arity-one entries equal the unknown-command default.
_ARITY = dict.fromkeys((
    "bazel brew bun cargo cdk cf cmake composer consul crictl deno docker eksctl firebase flyctl git go "
    "gradle helm heroku hugo ip kind kubectl kustomize make mc minikube mongosh mysql mvn ng npm nvm nx "
    "openssl pip pipenv pnpm poetry podman psql pulumi pyenv python rake rbenv redis-cli rustup serverless "
    "skaffold sls sst swift systemctl terraform tmux turbo ufw vault vercel volta wp yarn"
).split(), 2)
_ARITY.update(dict.fromkeys(("aws", "az", "doctl", "gcloud", "gh", "sfdx"), 3))
_ARITY.update(dict.fromkeys((
    "bun run", "bun x", "cargo add", "cargo run", "consul kv", "deno task", "docker builder",
    "docker compose", "docker container", "docker image", "docker network", "docker volume",
    "eksctl create", "git config", "git remote", "git stash", "ip addr", "ip link", "ip netns",
    "ip route", "kind create", "kubectl kustomize", "kubectl rollout", "mc admin", "npm exec",
    "npm init", "npm run", "npm view", "openssl req", "openssl x509", "pnpm dlx", "pnpm exec",
    "pnpm run", "podman container", "podman image", "pulumi stack", "terraform workspace",
    "vault auth", "vault kv", "yarn dlx", "yarn run",
), 3))


def arity_prefix(tokens: list[str]) -> list[str]:
    for length in range(len(tokens), 0, -1):
        count = _ARITY.get(" ".join(tokens[:length]))
        if count is not None:
            return tokens[:count]
    return tokens[:1]


@lru_cache(maxsize=2)
def _language(ps: bool) -> Language:
    return Language((tree_sitter_powershell if ps else tree_sitter_bash).language())


def _parse(command: str, ps: bool):
    # A parser is local to the call: background sessions may scan concurrently.
    tree = Parser(_language(ps)).parse(command.encode("utf-8"))
    if tree is None:
        raise RuntimeError("Failed to parse command")
    # Upstream traverses the recovery tree; it does not reject root.has_error.
    return tree


def _commands(root):
    stack = list(reversed(root.children))
    while stack:
        node = stack.pop()
        if node.type == "command":
            yield node
        stack.extend(reversed(node.children))


def _parts(node) -> list[tuple[str, str]]:
    out = []
    for child in node.children:
        if child.type == "command_elements":
            out.extend((item.type, item.text.decode("utf-8")) for item in child.children
                       if item.type not in {"command_argument_sep", "redirection"})
        elif child.type in {"command_name", "command_name_expr", "word", "string", "raw_string", "concatenation"}:
            out.append((child.type, child.text.decode("utf-8")))
    return out


def _path_args(parts: list[tuple[str, str]], ps: bool, cmd: bool) -> list[str]:
    if not ps:
        return [text for _, text in parts[1:] if not text.startswith("-")
                and not (cmd and text.startswith("/"))
                and not (parts[0][1] == "chmod" and text.startswith("+"))]
    out = []
    want = False
    for kind, text in parts[1:]:
        if want:
            out.append(text)
            want = False
        elif kind == "command_parameter":
            if text.lower() not in _SWITCHES:
                want = text.lower() in _FLAGS
        else:
            out.append(text)
    return out


def _unquote(text: str) -> str:
    return text[1:-1] if len(text) >= 2 and text[0] in "\"'" and text[0] == text[-1] else text


def _home(text: str) -> str:
    if text == "~":
        return str(Path.home())
    if text.startswith(("~/", "~\\")):
        return str(Path.home() / text[2:])
    return text


def _expand(text: str, cwd: Path, shell: str) -> str:
    def env_value(match):
        key = match.group(1)
        if os.name != "nt":
            return os.environ.get(key, "")
        return next((value for name, value in os.environ.items() if name.lower() == key.lower()), "")
    out = re.sub(r"\$\{env:([^}]+)\}", env_value, _unquote(text), flags=re.I)
    out = re.sub(r"\$env:([A-Za-z_][A-Za-z0-9_]*)", env_value, out, flags=re.I)
    automatic = {"HOME": str(Path.home()), "PWD": str(cwd), "PSHOME": str(Path(shell).parent)}
    out = re.sub(r"\$(HOME|PWD|PSHOME)(?=$|[\\/])",
                 lambda match: automatic[match.group(1).upper()], out, flags=re.I)
    return _home(out)


def _windows_path(text: str) -> str:
    for expression in (r"^/([A-Za-z]):(?:[\\/]|$)", r"^/([A-Za-z])(?:/|$)",
                       r"^/cygdrive/([A-Za-z])(?:/|$)", r"^/mnt/([A-Za-z])(?:/|$)"):
        text = re.sub(expression, lambda match: match.group(1).upper() + ":/", text)
    return text


def resolve_shell_path(text: str, cwd: Path, shell: str) -> Path:
    if os.name == "nt":
        normalized = _windows_path(text)
        if (Path(shell).stem.lower() in {"bash", "dash", "ksh", "sh", "zsh"}
                and text.startswith("/") and normalized == text):
            # Pass the path as $1, never interpolate it into shell program text.
            try:
                result = executor.run(
                    [shell, "-lc", 'cygpath -w -- "$1"', "_", text], executor.Launch("framework_helper", "cygpath"),
                    cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace",
                    timeout=5, creationflags=subprocess.CREATE_NO_WINDOW,
                )
                lines = result.stdout.splitlines()
                if result.returncode == 0 and lines and lines[0].strip():
                    normalized = _windows_path(lines[0].strip())
            except (OSError, subprocess.TimeoutExpired):
                # Upstream falls back to native path resolution when cygpath fails.
                pass
        text = normalized
    path = Path(text)
    return (path if path.is_absolute() else cwd / path).resolve()


def path_pattern(path: Path) -> str:
    # resolve uses Windows' native final path/casing for existing directories.
    return str(path.resolve() / "*")


def _arg_path(arg: str, cwd: Path, ps: bool, shell: str) -> Path | None:
    text = _expand(arg, cwd, shell) if ps else _home(_unquote(arg))
    wildcard = re.search(r"[?*\[]", text)
    if wildcard:
        text = text[:wildcard.start()]
    if not text or text.startswith(("(", "@(")) or any(mark in text for mark in ("$(", "${", "`")):
        return None
    if (re.search(r"\$(?!env:)", text, flags=re.I) if ps else "$" in text):
        return None
    if ps:
        provider = re.match(r"^([A-Za-z]+)::(.*)$", text)
        if provider:
            if provider.group(1).lower() != "filesystem":
                return None
            text = provider.group(2)
        drive = re.match(r"^([A-Za-z]+):", text)
        if drive and len(drive.group(1)) != 1:
            return None
    return resolve_shell_path(text, cwd, shell)


def scan(command: str, cwd: Path, worktree: Path, shell: str, *, directory: Path | None = None) -> tuple[list[Path], list[str], list[str]]:
    ps = Path(shell).stem.lower() in {"powershell", "pwsh"}
    cmd = Path(shell).stem.lower() == "cmd"
    tree = _parse(command, ps)
    directories: dict[Path, None] = {}
    patterns: dict[str, None] = {}
    always: dict[str, None] = {}
    for node in _commands(tree.root_node):
        parts = _parts(node)
        tokens = [text for _, text in parts]
        name = (tokens[0].lower() if ps or cmd else tokens[0]) if tokens else None
        if name in _FILES or (cmd and name in _CMD_FILES):
            for arg in _path_args(parts, ps, cmd):
                path = _arg_path(arg, cwd, ps, shell)
                if path is not None and not inside(worktree, path) and not (directory and inside(directory, path)):
                    directories[path if path.is_dir() else path.parent] = None
        if tokens and name not in _CWD:
            source = node.parent if node.parent and node.parent.type == "redirected_statement" else node
            patterns[source.text.decode("utf-8").strip()] = None
            always[" ".join(arity_prefix(tokens)) + " *"] = None
    if not inside(worktree, cwd) and not (directory and inside(directory, cwd)):
        directories[cwd] = None
    return list(directories), list(patterns), list(always)
