"""task_skill: write a method skill for this task, or list this task's skills (opencode/task_skills.py)."""

from __future__ import annotations

from pathlib import Path

from opencode import task_skills as tasks
from opencode.tools.types import Tool, ToolResult, prop, schema
from opencode.tools.util import ask_file_permission

DESCRIPTION = """Write a method skill for the current task, or list this task's skills.

The task is this session, over all its rounds. A method skill records how to do part of this task - a calculation, a check, a procedure you worked out - so that you and later rounds can load it with the skill tool by its name. It applies to this task only and cannot take the name of a skill listed in your system prompt. Writing again with the same name replaces it and keeps the earlier version. The tool records the task, the round and the skill charter version; give only the name, a one-line description and the text.

Review skills, written between rounds with lessons from earlier rounds of this task, appear in the list too; they are read-only.

The skill charter governs task skills: none may relax, replace or reinterpret a framework rule, check, commission or scoring definition."""


def _task_skill(args: dict, ctx) -> ToolResult:
    action = args.get("action")
    directory = Path(getattr(ctx, "directory", None) or ctx.app.directory)
    root = tasks.root_session(ctx.app.store, ctx.session_id)
    from opencode.deep import skills as installed_skills

    core = set(installed_skills(ctx.app))  # a task skill may not take a framework skill's name
    if action == "list":
        loaded, refused = tasks.load(directory, root, core)
        lines = [f"Task skills of this session (round {tasks.current_round(root)}):"]
        lines += [f"- {name}: {item.kind} skill from round {item.round}: {item.skill.description}"
                  for name, item in sorted(loaded.items())] or ["- none yet"]
        lines += [f"Not loaded: {item['name']} ({item['location']}): {'; '.join(item['reasons'])}" for item in refused]
        return ToolResult(title="Task skills", output="\n".join(lines))
    if action != "write":
        raise ValueError("action must be write or list")
    name = args.get("name") or ""
    loaded, _ = tasks.load(directory, root, core)
    if name in loaded and loaded[name].kind == "review":
        raise ValueError(f"Task skill {name!r} was not written: a review skill of this task is named {name!r}, "
                         "and review skills are read-only (skill charter article 1)")
    ask_file_permission(ctx, tasks.method_dir(directory, root) / name / "SKILL.md", "edit")
    path = tasks.write_method(directory, root, name, args.get("description") or "", args.get("body") or "", core)
    return ToolResult(
        title=f"Wrote task skill: {name}",
        output=(f"Wrote method skill {name!r} for this task at {path}. Load it with the skill tool by its name. "
                f"Companion files (scripts, references) can go in {path.parent}."),
        metadata={"location": str(path)})


def task_skill_tool() -> Tool:
    return Tool(
        "task_skill",
        DESCRIPTION,
        schema({
            "action": prop("string", "write a method skill, or list this task's skills", enum=["write", "list"]),
            "name": prop("string", "write: the skill's name, lowercase letters, digits and hyphens"),
            "description": prop("string", "write: one line saying when to use the skill"),
            "body": prop("string", "write: the skill's text"),
        }, ["action"]),
        _task_skill,
    )
