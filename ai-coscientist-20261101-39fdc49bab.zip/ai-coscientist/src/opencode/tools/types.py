"""Shared tool types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable


_external_readers: set[Callable] = set()


def external_source(execute: Callable) -> Callable:
    """Register a producer, not a model-authored claim about its output."""
    _external_readers.add(execute)
    return execute


def external_source_names(tools: list[Tool]) -> set[str]:
    return {tool.name for tool in tools if tool.execute in _external_readers}


@dataclass
class ToolResult:
    output: str
    title: str = ""
    metadata: dict = field(default_factory=dict)
    attachments: list = field(default_factory=list)
    # Filled only on the copy handed to a live presenter (on_tool_result);
    # never saved. Lets a UI name the call without guessing from order.
    tool: str = ""
    input: dict = field(default_factory=dict)


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict
    execute: Callable[..., ToolResult]


def schema(properties: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}


def prop(type_: str, description: str, **extra) -> dict:
    data = {"type": type_, "description": description}
    data.update(extra)
    return data
