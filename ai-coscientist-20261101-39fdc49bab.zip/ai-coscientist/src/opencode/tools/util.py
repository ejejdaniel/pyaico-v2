"""Path, permission, and output limits shared by tools."""

from __future__ import annotations

import json
import os
import hashlib
import io
import atexit
import logging
import re
import stat
import threading
import time
from pathlib import Path

from opencode.hidden import for_context as hidden_for, missing as hidden_missing
from opencode.paths import truncation_dir
from opencode.permission import PermissionDenied, PermissionRejected, permission_key
from opencode.tools.types import ToolResult

IGNORE_DIRS = {
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".next",
    ".turbo",
    "target",
}

_OUTPUT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000


def _output_timestamp(name: str) -> int | None:
    # Store.new_id already encodes decimal milliseconds in this port's tool IDs.
    # Keep that existing filename format; neither mtime nor directory age is TTL.
    match = re.fullmatch(r"tool_(\d{13})[0-9a-f]{8}", name)
    return int(match.group(1)) if match else None


def _file_identity(info) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mtime_ns, info.st_ctime_ns, info.st_size)


def _cleanup_output_files(directory: Path, *, now_ms: int | None = None, stop=None) -> None:
    """Delete only expired generated outputs, never recursively traverse entries."""
    cutoff = (int(time.time() * 1000) if now_ms is None else now_ms) - _OUTPUT_RETENTION_MS
    try:
        entries = list(directory.iterdir())
    except OSError:
        return
    for entry in entries:
        if stop is not None and stop.is_set():
            return
        timestamp = _output_timestamp(entry.name)
        if timestamp is None or timestamp >= cutoff:
            continue
        try:
            original = entry.lstat()
            if not stat.S_ISREG(original.st_mode):
                continue
            # Another cleanup may have removed the file, or a writer may have
            # replaced it while this pass was running. Do not remove that version.
            current = entry.lstat()
            if _file_identity(current) != _file_identity(original):
                continue
            if stop is not None and stop.is_set():
                return
            entry.unlink()
        except OSError:
            continue


class _OutputCleanup:
    """One process-owned worker; each registered data directory keeps its schedule."""

    def __init__(self):
        self._condition = threading.Condition()
        self._stop = threading.Event()
        self._directories: dict[Path, float] = {}
        self._thread = None

    def start(self, directory: Path) -> None:
        with self._condition:
            if self._stop.is_set():
                return
            self._directories.setdefault(directory.resolve(), time.monotonic() + 60)
            if self._thread is None:
                self._thread = threading.Thread(target=self._run, name="opencode-output-cleanup", daemon=True)
                self._thread.start()
            self._condition.notify_all()

    def close(self) -> None:
        self._stop.set()
        with self._condition:
            self._condition.notify_all()
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=1)

    def _run(self) -> None:
        while not self._stop.is_set():
            with self._condition:
                if self._stop.is_set():
                    return
                if not self._directories:
                    self._condition.wait()
                    continue
                directory, due = min(self._directories.items(), key=lambda item: item[1])
                delay = due - time.monotonic()
                if delay > 0:
                    self._condition.wait(delay)
                    continue
            try:
                _cleanup_output_files(directory, stop=self._stop)
            except Exception:
                logging.getLogger(__name__).exception("Truncation cleanup failed")
            with self._condition:
                # Source Schedule.spaced starts the hour after the pass finishes.
                self._directories[directory] = time.monotonic() + 60 * 60


_output_cleanup = _OutputCleanup()
atexit.register(_output_cleanup.close)


def start_output_cleanup() -> None:
    """Start the shared Truncate service's delayed, hourly retention task."""
    _output_cleanup.start(truncation_dir())


def resolve_path(raw: str, directory: Path) -> Path:
    path = Path(raw)
    if not path.is_absolute():
        path = directory / path
    return path.resolve()


def former_directories(store, session_id: str) -> list[Path]:
    """Directories this session used before its operational directory moved."""
    try:
        meta = store.get_session(session_id).get("meta") or {}
    except (KeyError, AttributeError):
        return []
    roots = []
    for item in meta.get("former_directories") or []:
        if not isinstance(item, str) or not item.strip():
            continue
        try:
            path = Path(item).resolve()
        except OSError:
            continue
        if path not in roots:
            roots.append(path)
    return roots


def session_path(raw: str, ctx) -> Path:
    return resolve_path(raw or "", ctx.directory)


def relocate_text(text: str, directory: Path, formers: list[Path]) -> str:
    if not text or not formers:
        return text
    current = directory.resolve()
    for old in sorted(formers, key=lambda item: len(str(item)), reverse=True):
        if old == current:
            continue
        for spelling in _path_spellings(old):
            replacement = _path_spelling(current, spelling, old)
            if spelling and spelling != replacement:
                text = _replace_path_prefix(text, spelling, replacement)
    return text


def relocate_presented(messages: list[dict], directory: Path, formers: list[Path]) -> list[dict]:
    """Copy messages for the model. Stored history keeps its original paths."""
    if not formers:
        return messages
    relocated = []
    for message in messages:
        item = dict(message)
        content = item.get("content")
        if isinstance(content, str):
            item["content"] = relocate_text(content, directory, formers)
        calls = item.get("tool_calls")
        if calls:
            rewritten = []
            for call in calls:
                copied = dict(call)
                arguments = copied.get("arguments")
                if isinstance(arguments, dict):
                    copied["arguments"] = json.loads(relocate_text(json.dumps(arguments, ensure_ascii=False), directory, formers))
                elif isinstance(arguments, str):
                    copied["arguments"] = relocate_text(arguments, directory, formers)
                rewritten.append(copied)
            item["tool_calls"] = rewritten
        relocated.append(item)
    return relocated


def _path_spellings(path: Path) -> list[str]:
    resolved = str(path)
    values = [resolved, path.as_posix()]
    if "\\" in resolved:
        values.append(resolved.replace("\\", "\\\\"))
    return list(dict.fromkeys(value for value in values if value))


def _path_spelling(current: Path, spelling: str, old: Path) -> str:
    if "/" in spelling and "\\" not in spelling:
        return current.as_posix()
    if "\\\\" in spelling:
        return str(current).replace("\\", "\\\\")
    return str(current)


def _replace_path_prefix(text: str, old: str, new: str) -> str:
    parts = []
    cursor = 0
    search = 0
    haystack = text.casefold()
    needle = old.casefold()
    while True:
        index = haystack.find(needle, search)
        if index < 0:
            parts.append(text[cursor:])
            break
        end = index + len(old)
        if end < len(text) and text[end] not in "\\/\"' \t\r\n":
            search = index + 1
            continue
        parts.append(text[cursor:index])
        parts.append(new)
        cursor = end
        search = end
    return "".join(parts)


def inside(root: Path, path: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def norm_key(path: Path) -> str:
    return os.path.normcase(str(path.resolve()))


def relative_path(ctx, path: Path) -> str:
    try:
        relative = os.path.relpath(path, ctx.worktree)
        return "" if relative == "." else relative
    except ValueError:
        # Node's path.relative returns the absolute target for another drive.
        return str(path)


def _abort_event(ctx):
    abort = getattr(ctx, "abort", None)
    if abort is not None:
        return abort
    source = getattr(ctx.app, "abort_event", None)
    return source(ctx.session_id) if source else None


def _run_cancellable(request, abort):
    # The provider owns the shared async-request thread/cleanup primitive.
    # Tools use the same lifetime while retaining their existing stop exception.
    from opencode.provider import ProviderError, _run_cancellable as run

    try:
        return run(request, abort)
    except ProviderError:
        if abort.is_set():
            raise PermissionRejected("Execution stopped") from None
        raise


def ask_file_permission(ctx, path: Path, permission: str) -> None:
    ctx.app.permissions.ask(
        abort_event=_abort_event(ctx),
        session_id=ctx.session_id,
        permission=permission,
        patterns=["*" if permission == "lsp" else relative_path(ctx, path)],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata={},
    )


def refuse_protected(ctx, path: Path) -> None:
    """The agent's own file tools are refused what its host protects (config["protected"]; opencode/integrity.py):
    the meta region, the framework's ledgers and records, everything outside the workspace. Framework tools save
    their records and ledgers through ensure_access, which this does not touch."""
    from opencode.integrity import refuses

    patterns = (getattr(ctx.app, "config", None) or {}).get("protected")
    relative = relative_path(ctx, path).replace("\\", "/")
    if patterns and refuses(patterns, relative):
        raise PermissionDenied("edit", relative)


def ensure_external_directory(ctx, path: Path, *, kind: str = "file") -> None:
    hidden = hidden_for(ctx)
    if hidden is not None and hidden.hides(path):
        # A host record reads as a path that does not exist (see opencode/hidden.py).
        raise hidden_missing(path)
    worktree_contains = str(ctx.worktree).replace("\\", "/") != "/" and inside(ctx.worktree, path)
    if not worktree_contains and not inside(ctx.directory, path):
        directory = path if kind == "directory" else path.parent
        pattern = directory.as_posix().rstrip("/") + "/*"
        ctx.app.permissions.ask(
            abort_event=_abort_event(ctx),
            session_id=ctx.session_id,
            permission="external_directory",
            patterns=[pattern],
            ruleset=ctx.agent.permission,
            always=[pattern],
            metadata={},
        )


def ensure_access(ctx, path: Path, permission: str) -> None:
    ensure_external_directory(ctx, path, kind="directory" if permission == "read" and path.is_dir() else "file")
    ask_file_permission(ctx, path, permission)


def require_read(ctx, path: Path) -> None:
    if norm_key(path) not in ctx.read_files:
        raise PermissionDenied("edit", str(path)) if False else RuntimeError(
            "You must Read this file before editing it."
        )


def mark_read(ctx, path: Path) -> None:
    ctx.read_files.add(norm_key(path))


def snapshot(ctx, path: Path) -> None:
    existed = path.exists() and path.is_file()
    content = path.read_bytes() if existed else None
    ctx.app.store.save_snapshot(ctx.session_id, ctx.turn, str(path), existed, content)


def truncate(text: str, *, max_lines: int = 2000, max_bytes: int = 50 * 1024, label: str = "output",
             saved_path: Path | None = None, direction: str = "head", agent=None) -> str:
    return truncate_output(text, max_lines=max_lines, max_bytes=max_bytes,
                           saved_path=saved_path, direction=direction, agent=agent)[0]


def truncate_output(text: str, *, max_lines: int = 2000, max_bytes: int = 50 * 1024,
                    saved_path: Path | None = None, direction: str = "head", agent=None) -> tuple[str, dict]:
    from opencode.store import new_id
    from opencode.permission import evaluate
    raw = text.encode("utf-8")
    lines = text.split("\n")
    if len(lines) <= max_lines and len(raw) <= max_bytes:
        return text, {"truncated": False}
    kept = []
    size = 0
    hit_bytes = False
    for line in (lines if direction == "head" else reversed(lines)):
        if len(kept) >= max_lines:
            break
        length = len(line.encode("utf-8")) + bool(kept)
        if size + length > max_bytes:
            hit_bytes = True
            break
        kept.append(line)
        size += length
    if direction == "tail":
        kept.reverse()
    folder = truncation_dir()
    folder.mkdir(parents=True, exist_ok=True)
    target = saved_path or folder / new_id("tool")
    if saved_path is None:
        target.write_bytes(raw)
    removed = len(raw) - size if hit_bytes else len(lines) - len(kept)
    unit = "bytes" if hit_bytes else "lines"
    hint = f"The tool call succeeded but the output was truncated. Full output saved to: {target}\n"
    if agent and evaluate("task", "*", agent.permission).action != "deny":
        hint += "Use the Task tool to have explore agent process this file with Grep and Read (with offset/limit). Do NOT read the full file yourself - delegate to save context."
    else:
        hint += "Use Grep to search the full content or Read with offset/limit to view specific sections."
    preview = "\n".join(kept)
    marker = f"...{removed} {unit} truncated..."
    result = (f"{preview}\n\n{marker}\n\n{hint}" if direction == "head"
              else f"{marker}\n\n{hint}\n\n{preview}")
    return result, {"truncated": True, "outputPath": str(target)}


def tool_error(exc: Exception) -> ToolResult:
    if isinstance(exc, PermissionDenied):
        return ToolResult(output=str(exc), title="denied")
    return ToolResult(output=f"Error: {exc}", title="error")


def hidden(agent, name: str) -> bool:
    from opencode.permission import disabled

    return name in disabled([name], agent.permission) or permission_key(name) in disabled(
        [permission_key(name)], agent.permission
    )
