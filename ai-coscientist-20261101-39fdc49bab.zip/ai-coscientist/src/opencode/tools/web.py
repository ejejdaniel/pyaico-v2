"""webfetch and websearch."""

from __future__ import annotations

import json
import os
import re
from datetime import date
from html.parser import HTMLParser
from urllib.parse import quote

import httpx
from bs4 import BeautifulSoup
from markdownify import MarkdownConverter

from opencode import VERSION
from opencode.media import data_url
from opencode.prompts import load as load_prompt
from opencode.tools.types import Tool, ToolResult, external_source, prop, schema
from opencode.tools.util import _abort_event, _run_cancellable

MAX_BYTES = 5 * 1024 * 1024


class _TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if self._skip or tag in {"script", "style", "noscript", "iframe", "object", "embed"}:
            self._skip += 1
            if tag in {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}:
                self._skip -= 1

    def handle_startendtag(self, tag, attrs):
        pass

    def handle_endtag(self, tag):
        if self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if self._skip:
            return
        self.parts.append(data)


def _html_to_text(raw: str) -> str:
    parser = _TextExtractor()
    parser.feed(raw)
    parser.close()
    return "".join(parser.parts).strip()


class _MarkdownConverter(MarkdownConverter):
    def convert_pre(self, el, text, parent_tags):
        code = el.find("code", recursive=False)
        if code is None:
            return "\n\n" + text + "\n\n"
        match = re.search(r"language-(\S+)", " ".join(code.get("class", [])))
        language = match.group(1) if match else ""
        raw = code.get_text().replace("\r\n", "\n").removesuffix("\n")
        fences = re.findall(r"^`{3,}", raw, re.M)
        fence = "`" * max(3, max((len(item) + 1 for item in fences), default=3))
        return f"\n\n{fence}{language}\n{raw}\n{fence}\n\n"


def _html_to_markdown(raw: str) -> str:
    document = BeautifulSoup(raw, "html.parser")
    for element in document.find_all(["script", "style", "meta", "link"]):
        element.decompose()
    return _MarkdownConverter(heading_style="ATX", bullets="-", strong_em_symbol="*",
                              autolinks=False).convert_soup(document)


@external_source
def _webfetch(args: dict, ctx) -> ToolResult:
    url = args["url"]
    if not url.startswith(("http://", "https://")):
        raise ValueError("URL must start with http:// or https://")
    ctx.app.permissions.ask(
        abort_event=_abort_event(ctx),
        session_id=ctx.session_id,
        permission="webfetch",
        patterns=[url],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata={"url": url},
    )
    fmt = args.get("format", "markdown")
    timeout = min(args.get("timeout", 30), 120)
    accept = {
        "markdown": "text/markdown;q=1.0, text/x-markdown;q=0.9, text/plain;q=0.8, text/html;q=0.7, */*;q=0.1",
        "text": "text/plain;q=1.0, text/markdown;q=0.9, text/html;q=0.8, */*;q=0.1",
        "html": "text/html;q=1.0, application/xhtml+xml;q=0.9, text/plain;q=0.8, text/markdown;q=0.7, */*;q=0.1",
    }.get(fmt, "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
               "Accept": accept, "Accept-Language": "en-US,en;q=0.9"}
    abort = _abort_event(ctx)
    try:
        if abort is None:
            raw, content_type = _fetch_sync(url, headers, timeout)
        else:
            raw, content_type = _run_cancellable(lambda: _fetch_async(url, headers, timeout), abort)
    except httpx.TimeoutException as error:
        raise RuntimeError("Request timed out") from error
    mime = content_type.split(";")[0].strip().lower()
    title = f"{url} ({content_type})"
    if mime.startswith("image/") and mime not in {"image/svg+xml", "image/vnd.fastbidsheet"}:
        return ToolResult(title=title, output="Image fetched successfully",
                          attachments=[{"mime": mime, "url": data_url(mime, raw)}])
    body = raw.decode("utf-8-sig", errors="replace")
    if "text/html" in content_type:
        if fmt == "markdown":
            body = _html_to_markdown(body)
        elif fmt == "text":
            body = _html_to_text(body)
    return ToolResult(title=title, output=body)


def _check_fetch_response(response):
    response.raise_for_status()
    length = re.match(r"^[\s]*[+]?([0-9]+)", response.headers.get("content-length", ""))
    if length and int(length.group(1)) > MAX_BYTES:
        raise ValueError("Response too large (exceeds 5MB limit)")


def _fetch_sync(url, headers, timeout):
    with httpx.Client(timeout=timeout, follow_redirects=True) as client:
        for attempt in range(2):
            with client.stream("GET", url, headers=headers) as response:
                if attempt == 0 and response.status_code == 403 and response.headers.get("cf-mitigated") == "challenge":
                    headers["User-Agent"] = "opencode"
                    continue
                _check_fetch_response(response)
                chunks, size = [], 0
                for chunk in response.iter_bytes():
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError("Response too large (exceeds 5MB limit)")
                    chunks.append(chunk)
                return b"".join(chunks), response.headers.get("content-type", "")


async def _fetch_async(url, headers, timeout):
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        for attempt in range(2):
            async with client.stream("GET", url, headers=headers) as response:
                if attempt == 0 and response.status_code == 403 and response.headers.get("cf-mitigated") == "challenge":
                    headers["User-Agent"] = "opencode"
                    continue
                _check_fetch_response(response)
                chunks, size = [], 0
                async for chunk in response.aiter_bytes():
                    size += len(chunk)
                    if size > MAX_BYTES:
                        raise ValueError("Response too large (exceeds 5MB limit)")
                    chunks.append(chunk)
                return b"".join(chunks), response.headers.get("content-type", "")


@external_source
def _websearch(args: dict, ctx) -> ToolResult:
    query = args["query"]
    provider = _search_provider(ctx.session_id)
    metadata = {key: args[key] for key in ("numResults", "livecrawl", "type", "contextMaxCharacters") if key in args}
    metadata.update(query=query, provider=provider)
    ctx.app.permissions.ask(
        abort_event=_abort_event(ctx),
        session_id=ctx.session_id,
        permission="websearch",
        patterns=[query],
        ruleset=ctx.agent.permission,
        always=["*"],
        metadata=metadata,
    )
    headers = {"Accept": "application/json, text/event-stream"}
    if provider == "parallel":
        url, name = "https://search.parallel.ai/mcp", "web_search"
        arguments = {"objective": query, "search_queries": [query], "session_id": ctx.session_id}
        model = _search_model(ctx)
        if model is not None:
            arguments["model_name"] = model
        headers["User-Agent"] = f"opencode/{VERSION}"
        if os.environ.get("PARALLEL_API_KEY"):
            headers["Authorization"] = "Bearer " + os.environ["PARALLEL_API_KEY"]
    else:
        url, name = "https://mcp.exa.ai/mcp", "web_search_exa"
        if os.environ.get("EXA_API_KEY"):
            url += "?exaApiKey=" + quote(os.environ["EXA_API_KEY"], safe="~()*!.'-")
        arguments = {"query": query, "type": args.get("type") or "auto", "numResults": args.get("numResults") or 8,
                     "livecrawl": args.get("livecrawl") or "fallback"}
        if "contextMaxCharacters" in args:
            arguments["contextMaxCharacters"] = args["contextMaxCharacters"]
    payload = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": name, "arguments": arguments}}
    abort = _abort_event(ctx)
    try:
        if abort is None:
            with httpx.Client(timeout=25, follow_redirects=True) as client:
                response = client.post(url, headers=headers, json=payload)
        else:
            async def request():
                async with httpx.AsyncClient(timeout=25, follow_redirects=True) as client:
                    return await client.post(url, headers=headers, json=payload)

            response = _run_cancellable(request, abort)
        response.raise_for_status()
    except httpx.TimeoutException as error:
        raise RuntimeError(f"{name} request timed out") from error
    text = _parse_search_response(response.text)
    label = "Parallel Web Search" if provider == "parallel" else "Exa Web Search"
    return ToolResult(title=f"{label}: {query}", metadata={"provider": provider},
                      output=text if text is not None else "No search results found. Please try a different query.")


def _search_provider(session_id: str) -> str:
    override = os.environ.get("OPENCODE_WEBSEARCH_PROVIDER")
    if override in {"exa", "parallel"}:
        return override
    def enabled(*names):
        return any(os.environ.get(name, "").lower() in {"true", "1", "yes", "on"} for name in names)
    if enabled("OPENCODE_ENABLE_PARALLEL", "OPENCODE_EXPERIMENTAL_PARALLEL"):
        return "parallel"
    if enabled("OPENCODE_EXPERIMENTAL", "OPENCODE_ENABLE_EXA", "OPENCODE_EXPERIMENTAL_EXA"):
        return "exa"
    value = 0x811C9DC5 if session_id else 0
    units = session_id.encode("utf-16-le", errors="surrogatepass")
    for index in range(0, len(units), 2):
        value = ((value ^ int.from_bytes(units[index:index + 2], "little")) * 0x01000193) & 0xFFFFFFFF
    return "exa" if value % 2 == 0 else "parallel"


def _search_model(ctx) -> str | None:
    message_id = getattr(ctx, "message_id", None)
    if message_id is None:
        return None
    message = next((item for item in ctx.app.store.messages(ctx.session_id) if item["id"] == message_id), None)
    if not message or not isinstance(message.get("model"), str):
        return None
    model = message["model"].split("/", 1)[-1]
    return model[:100]


def _parse_search_response(body: str) -> str | None:
    def parse(payload):
        payload = payload.strip()
        if not payload.startswith("{"):
            return None
        data = json.loads(payload)
        if not isinstance(data, dict) or not isinstance(data.get("result"), dict):
            raise ValueError("Invalid search response: result must be an object")
        content = data["result"].get("content")
        if not isinstance(content, list) or any(not isinstance(item, dict) or not isinstance(item.get("type"), str)
                                               or not isinstance(item.get("text"), str) for item in content):
            raise ValueError("Invalid search response: content must contain type and text strings")
        return next((item["text"] for item in content if item["text"]), None)
    direct = parse(body)
    if direct:
        return direct
    for line in body.split("\n"):
        if line.startswith("data: "):
            result = parse(line[6:])
            if result:
                return result
    return None


def web_tools() -> list[Tool]:
    year = str(date.today().year)
    search_description = load_prompt("websearch.txt").replace("{{year}}", year)
    return [
        Tool(
            "webfetch",
            load_prompt("webfetch.txt"),
            schema(
                {
                    "url": prop("string", "The URL to fetch content from"),
                    "format": prop("string", "The format to return the content in (text, markdown, or html). Defaults to markdown.", enum=["text", "markdown", "html"]),
                    "timeout": prop("integer", "Optional timeout in seconds (max 120)"),
                },
                ["url"],
            ),
            _webfetch,
        ),
        Tool(
            "websearch",
            search_description,
            schema(
                {
                    "query": prop("string", "Websearch query"),
                    "numResults": prop("number", "Number of search results to return (default: 8)"),
                    "livecrawl": prop("string", "Live crawl mode - 'fallback': use live crawling as backup if cached content unavailable, 'preferred': prioritize live crawling (default: 'fallback')", enum=["fallback", "preferred"]),
                    "type": prop("string", "Search type - 'auto': balanced search (default), 'fast': quick results, 'deep': comprehensive search", enum=["auto", "fast", "deep"]),
                    "contextMaxCharacters": prop("number", "Maximum characters for context string optimized for LLMs (default: 10000)"),
                },
                ["query"],
            ),
            _websearch,
        ),
    ]
