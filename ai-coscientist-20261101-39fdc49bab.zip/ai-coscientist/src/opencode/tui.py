"""Local full-screen OpenCode frontend; the existing App owns all execution.

Only UI state lives here. No frontend event or presentation is persisted as a
runtime message. Live prose uses on_text; formal results use session.result.
"""

from __future__ import annotations

import asyncio
import json
import queue
import time

from rich.console import Group
from rich.cells import cell_len
from rich.markdown import Markdown
from rich.text import Text
from textual import events, on, work
from textual.app import App as TerminalApp, ComposeResult
from textual.binding import Binding
from textual.css.query import NoMatches
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, OptionList, SelectionList, Static, TextArea
from textual.widgets.option_list import Option

from opencode import __version__, search_switch
from opencode.deep import is_on as deep_is_on, set_on as set_deep
from opencode._tui_presenter import (ToolCard, final_response, message_renderable, saved_history,
                                     tool_primary_argument, with_tool_inputs)


# The home screen's "aha!" picture: the user's reference image shrunk to 61x30 and reduced to a few
# colours, then touched up by hand (background rays cropped, mouth redrawn, the hand replaced by a lit bulb). Each
# character is one pixel; two pixel rows share a terminal row as a half block.
SPRITE = (
    "jqkkklnkkknnmmnkkkiiiikkkkkkmnnkkkkkkkkkkkmmnnmkkkkkkkkkonnkr",
    "jnkkmmokknonnnnkkkkiikklnklinnnnnnkkkkkkknoonkikkknkkkkknnoko",
    "qkklmonklnnmlnkkkkkkkkknnknggggiiimnnllllkmigdddmkonkklklnllm",
    "okknlolkkkkknlkkkkkkkkloolndbcbbddddggigdddcbbbdnnoolknlllnkl",
    "mkQnnoklQlllnlQkkkkllllooongbbbbbbbbbbcbbbbbbbbgnomjllonllnll",
    "lloQolllQlllnQkkkkklllnkooomcbbbbbbbbaaaaaabbbdpmgbdmlonlllnl",
    "QnnmQllllllnQlkkQkklllmdgoooqgccaaaaaaaaaaaaaaabaaabmnoolllnn",
    "nQnolnlOOOOnllkQkkklllibbcdggdcggjgaaaaaaaaadjgdcaabjooolllno",
    "osomnOOBBBBOOlkkkkkkkmjjjjppjjjdddgjcaaaabdgpjjjjjjjqooomlllo",
    "sonnOBBBWWBBBOnkkkistttrrqqqqppqtrjccaabcjrttrqpppprttttrnlln",
    "QQooOBBWWWWBBOnQQlktttpdccbdggdggptpjjjjqtrjggdcbbdgqrttttmln",
    "oooOBBBWWWWBBBOlllltttdgqpptttqcdbjttttttrgcddjpjcajjmrtttmln",
    "sosOBBBBWWBBBBOkkkkrtscpttttttttdagttttttpbcjtttttcaajottjmln",
    "omlOBBBFBBFBBBOllllmtrjttttttgctqagtrggptjbgtttjjttqajotnmlln",
    "ololOBBBFFBBBOkllllntrrtjttttgctjagtpbbjtpdjqttcgttqamrtnllln",
    "oQnmOBBBFFBBBOkQlllnsttpgrrrtrrrcbptjaagtqdctrtqqtqtjnrtnnnno",
    "sknolOBBFFBBOlkkkkknrtqgdrrrrqqmadrtdaadrtdcrrrrrrjtqossnnnno",
    "tkomnnOBFFBOllkkkkknntjgapinooliagtjbaabjtgcjmoomjjjqstonnnno",
    "qknnonZZZZZZmmnkkkiontqcadiiikiddqrgaaaadtqcgilligdjossononnr",
    "rkooonzzzzzznnnkkkkonrtqgddgggddptjaaaacajtpdgiigdinstsnoonor",
    "rmoonlZZZZZZlnkmmmmooostttrrqqrttpcaaaaaacptpjjjjpsttrnossnor",
    "rosookzzzzzznlkooooooorqjpqqqqqpjcaaacccaabgpppppqronosssonrs",
    "tsnnnokzZZzlnlknnnnsssrsqjdbbbbbbcrrrrrrrjdbbbbjprsssssssorrs",
    "soololllllllnlkooonssssssrrgbaaaagrooooorngaaaagsssssssssosrn",
    "ollkollllllnllkkkkosssssstrgbbaabgrookkormcaaaaajsssssssstrsm",
    "nlnoknlllllnllkkknsssssssssgbbaaaggrkkkrggbabbabbgrssssrsrsom",
    "lnoosmlllllollkmmsssssssssjcbbbbbbddrrrgdbbbbbbbccjsssrrrrsmm",
    "nooonnomllknmmnossorsssssmgcbbbbbbccccccccbcbbbbdjrrssrrrsnll",
    "ooonlrttqqqqqrtttsqppqrrnkjdddccccccccccccccccdjrrrrssrrssoln",
    "oooosrqqqqqqqqtqpjppppppppprpggdddddddddddddgprrrrsssssssooon",
)
SPRITE_COLOURS = {
    "B": "#fff6a8",
    "F": "#ffb400",
    "O": "#c98a00",
    "Q": "#ffe14d",
    "W": "#ffffff",
    "Z": "#9aa3ab",
    "a": "#fffef8",
    "b": "#fffde4",
    "c": "#faf2df",
    "d": "#faeec2",
    "g": "#dabf92",
    "i": "#e3925a",
    "j": "#a48a60",
    "k": "#e2663d",
    "l": "#dd583b",
    "m": "#c15c3b",
    "n": "#ba452c",
    "o": "#a62e1c",
    "p": "#74603c",
    "q": "#664828",
    "r": "#642f18",
    "s": "#69180b",
    "t": "#301008",
    "z": "#5f666d",
}


def logo() -> Text:
    """The picture as half blocks, with the name centred under it."""
    text = Text()
    for top, bottom in zip(SPRITE[0::2], SPRITE[1::2]):
        for upper, lower in zip(top, bottom):
            if upper == "." and lower == ".":
                text.append(" ")
            elif lower == "." or upper == lower:
                text.append("▀" if lower == "." else "█", style=SPRITE_COLOURS[upper])
            elif upper == ".":
                text.append("▄", style=SPRITE_COLOURS[lower])
            else:
                text.append("▀", style=f"{SPRITE_COLOURS[upper]} on {SPRITE_COLOURS[lower]}")
        text.append("\n")
    text.append(" " * ((len(SPRITE[0]) - len(BRAND)) // 2))
    text.append(BRAND, style="bold #fab283")
    return text


SPINNER = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
HINTS = "Enter 送出 · Ctrl+J 換行 · /sessions 舊對話 · /models 模型 · Ctrl+P 指令"


def _elapsed(seconds: float) -> str:
    seconds = int(seconds)
    return f"{seconds}s" if seconds < 60 else f"{seconds // 60}m{seconds % 60:02d}s"


def _count(value: int) -> str:
    return f"{value / 1000:.1f}k" if value >= 1000 else str(value)


def token_summary(tokens) -> str:
    """Describe one response's provider-reported usage; empty when none was reported."""
    if not isinstance(tokens, dict) or not tokens:
        return ""
    numbers = {key: value for key, value in tokens.items() if isinstance(value, int)}
    sent = (numbers.get("prompt_tokens") or numbers.get("input_tokens") or 0) + numbers.get("cache_read_input_tokens", 0) \
        + numbers.get("cache_creation_input_tokens", 0)
    received = numbers.get("completion_tokens") or numbers.get("output_tokens") or 0
    if not sent and not received:
        total = numbers.get("total_tokens") or numbers.get("total") or 0
        return f"{_count(total)} tokens" if total else ""
    return f"{_count(sent)} in · {_count(received)} out"


def markdown_split(text: str) -> int:
    """Length of the longest prefix ending in a blank line outside a code fence.

That prefix renders the same whether or not more text follows, so a stream
can freeze it and re-render only the tail.
"""
    split, fenced, position = 0, False, 0
    for line in text.splitlines(keepends=True):
        position += len(line)
        stripped = line.strip()
        if stripped.startswith(("```", "~~~")):
            fenced = not fenced
        elif not stripped and not fenced and line.endswith("\n") and position < len(text):
            split = position
    return split


class LiveText:
    """Streamed prose for one reply; the UI owns it until saved history replaces it."""

    def __init__(self, text: str = ""):
        self.text = text

    def __rich__(self):
        return Markdown(self.text)


class LiveMarkdown(Vertical):
    """Freeze completed Markdown blocks so each chunk re-parses only the tail."""

    DEFAULT_CSS = "LiveMarkdown { height: auto; } LiveMarkdown > Static { height: auto; }"

    def __init__(self, item: LiveText, **kwargs):
        super().__init__(**kwargs)
        self.item = item
        self.frozen = 0
        self.tail = Static()

    def compose(self) -> ComposeResult:
        yield self.tail

    def on_mount(self):
        self.sync()

    def sync(self):
        rest = self.item.text[self.frozen:]
        split = markdown_split(rest)
        if split:
            self.mount(Static(Markdown(rest[:split])), before=self.tail)
            self.frozen += split
            rest = rest[split:]
        self.tail.update(Markdown(rest))


class ToolCardView(Static):
    """A tool card; clicking toggles the full output when it is long."""

    def __init__(self, item: ToolCard, **kwargs):
        super().__init__(item, **kwargs)
        self.item = item

    def on_click(self):
        if self.item.collapsible:
            self.item.expanded = not self.item.expanded
            self.update(self.item)


class QueueBar(Static):
    """Prompts waiting for the current turn; clicking a line cancels it."""

    def on_click(self, event: events.Click):
        self.app.cancel_queued(event.y)


def conversation_widget(item, index):
    options = {"id": f"message-{index}", "classes": "message"}
    if isinstance(item, ToolCard):
        widget = ToolCardView(item, **options)
    elif isinstance(item, LiveText):
        widget = LiveMarkdown(item, **options)
    else:
        widget = Static(item, **options)
        widget.item = item
    return widget


class PromptInput(TextArea):
    BINDINGS = [
        Binding("enter", "send", priority=True, show=False),
        Binding("ctrl+j,shift+enter,ctrl+enter,alt+enter", "newline", priority=True, show=False),
    ]

    class Submitted(Message):
        pass

    def action_send(self):
        self.post_message(self.Submitted())

    def action_newline(self):
        self.insert("\n")

    def on_key(self, event: events.Key):
        if self.app.leader_pending:
            event.stop()
            event.prevent_default()
            self.app.consume_leader(event.key)


class ChoiceDialog(ModalScreen[str | None]):
    BINDINGS = [("escape", "cancel", "Close"), ("down", "next", "Next"), ("up", "previous", "Previous")]

    def __init__(self, title: str, choices: list[tuple[str, str]]):
        super().__init__()
        self.title_text, self.choices = title, choices
        self.filtered = choices

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog"):
            yield Label(self.title_text, classes="dialog-title")
            yield Input(placeholder="搜尋…", id="choice-search")
            yield OptionList(*(Option(Text(label), id=str(index)) for index, (label, _) in enumerate(self.choices)), id="choices")
            yield Static("↑ ↓ 選擇  Enter 確認  Esc 返回", classes="muted")

    def on_mount(self):
        self.query_one(Input).focus()

    @on(Input.Changed)
    def filter_choices(self, event: Input.Changed):
        needle = event.value.casefold()
        self.filtered = [(label, value) for label, value in self.choices if needle in label.casefold()]
        options = self.query_one(OptionList)
        options.clear_options()
        options.add_options(Option(Text(label), id=str(index)) for index, (label, _) in enumerate(self.filtered))
        if self.filtered:
            options.highlighted = 0

    @on(Input.Submitted)
    def submit_search(self):
        index = self.query_one(OptionList).highlighted
        if index is not None and index < len(self.filtered):
            self.dismiss(self.filtered[index][1])

    @on(OptionList.OptionSelected)
    def select_choice(self, event: OptionList.OptionSelected):
        self.dismiss(self.filtered[event.option_index][1])

    def action_next(self):
        self.query_one(OptionList).action_cursor_down()

    def action_previous(self):
        self.query_one(OptionList).action_cursor_up()

    def action_cancel(self):
        self.dismiss(None)


class PermissionDialog(ModalScreen[tuple[str, str | None] | None]):
    BINDINGS = [("escape", "reject", "Reject")]

    def __init__(self, request: dict):
        super().__init__()
        self.request = request
        self.confirm_always = False

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog"):
            yield Label("Permission required", classes="dialog-title")
            yield Static(Text(f"{self.request['permission']} · {self.request['sessionID']}"))
            yield Static(Text("\n".join(self.request.get("patterns") or [])))
            with VerticalScroll(classes="request-details"):
                yield Static(Text(json.dumps(self.request.get("metadata") or {}, ensure_ascii=False, indent=2)))
            yield Static("持續允許只適用於所列規則，直到程式關閉。", id="permission-note", classes="muted")
            yield Input(placeholder="拒絕時可補充修正指示", id="permission-reason")
            with Horizontal(classes="buttons"):
                yield Button("Allow once", id="once", variant="primary")
                yield Button("Always allow", id="always")
                yield Button("Reject", id="reject", variant="error")

    def on_mount(self):
        self.query_one("#once", Button).focus()

    @on(Button.Pressed)
    def choose(self, event: Button.Pressed):
        choice = event.button.id
        if choice == "always" and not self.confirm_always:
            self.confirm_always = True
            patterns = "\n".join(self.request.get("always") or [])
            self.query_one("#permission-note", Static).update(Text("再次選擇以確認持續允許：\n" + patterns))
            event.button.label = "Confirm always"
            return
        self.dismiss((choice, self.query_one(Input).value or None))

    def action_reject(self):
        self.dismiss(("reject", self.query_one(Input).value or None))


class QuestionDialog(ModalScreen[list[list[str]] | None]):
    # No question.reject contract exists. A separate, explicit button aborts
    # the session; Escape only clears an edit, never supplies an empty answer.
    BINDINGS = [("escape", "clear_edit", "Clear edit")]

    def __init__(self, request: dict):
        super().__init__()
        self.request = request
        self.index = 0
        self.answers = [[] for _ in request["questions"]]

    def compose(self) -> ComposeResult:
        with Vertical(classes="dialog"):
            yield Label("Question", id="question-title", classes="dialog-title")
            yield Static(id="question-text")
            yield SelectionList(id="question-options")
            yield Input(placeholder="其他答案", id="question-custom")
            yield Static("選取答案後繼續；若需取消工作，請明確選擇停止對話。", id="question-note", classes="muted")
            with Horizontal(classes="buttons"):
                yield Button("Previous", id="question-back")
                yield Button("Next", id="question-next", variant="primary")
                yield Button("停止對話", id="question-stop", variant="error")

    def on_mount(self):
        self.show_question()

    def show_question(self):
        question = self.request["questions"][self.index]
        self.query_one("#question-title", Label).update(Text(f"{question.get('header') or 'Question'}  {self.index + 1}/{len(self.answers)}"))
        self.query_one("#question-text", Static).update(Text(question["question"]))
        options = self.query_one(SelectionList)
        options.clear_options()
        options.add_options((Text(option["label"] + (" — " + option["description"] if option.get("description") else "")),
                             option["label"], option["label"] in self.answers[self.index])
                            for option in question.get("options") or [])
        options.highlighted = 0 if options.option_count else None
        known = {option["label"] for option in question.get("options") or []}
        custom = self.query_one(Input)
        custom.value = next((value for value in self.answers[self.index] if value not in known), "")
        custom.display = question.get("custom") is not False
        self.query_one("#question-back", Button).disabled = self.index == 0
        self.query_one("#question-next", Button).label = "Submit" if self.index == len(self.answers) - 1 else "Next"
        options.focus() if options.option_count else custom.focus()

    @on(SelectionList.SelectionToggled)
    def single_choice(self, event: SelectionList.SelectionToggled):
        if self.request["questions"][self.index].get("multiple"):
            return
        options = self.query_one(SelectionList)
        value = event.selection.value
        if value in options.selected:
            options.deselect_all()
            options.select(value)

    @on(Button.Pressed)
    def choose(self, event: Button.Pressed):
        if event.button.id == "question-stop":
            self.dismiss(None)
            return
        question = self.request["questions"][self.index]
        values = list(self.query_one(SelectionList).selected)
        custom = self.query_one(Input).value.strip() if question.get("custom") is not False else ""
        if custom:
            values = [*values, custom] if question.get("multiple") else [custom]
        self.answers[self.index] = values
        if event.button.id == "question-back":
            self.index -= 1
        elif not values:
            self.query_one("#question-note", Static).update("請選擇或輸入答案。")
            return
        elif self.index == len(self.answers) - 1:
            self.dismiss(self.answers)
            return
        else:
            self.index += 1
        self.show_question()

    def action_clear_edit(self):
        self.query_one(Input).value = ""


class TextArrived(Message):
    def __init__(self, session_id: str, text: str):
        super().__init__()
        self.session_id, self.text = session_id, text


class ToolArrived(Message):
    def __init__(self, session_id: str, result):
        super().__init__()
        self.session_id, self.result = session_id, result


class TurnEnded(Message):
    def __init__(self, session_id: str, result=None, error: BaseException | None = None, *, compaction=False):
        super().__init__()
        self.session_id, self.result, self.error = session_id, result, error
        self.compaction = compaction


class HistoryRefresh(Message):
    def __init__(self, session_id: str):
        super().__init__()
        self.session_id = session_id


# The name the screen shows; the command and package keep their own names.
BRAND = "Co-Scientist"


class OpenCodeTUI(TerminalApp):
    TITLE = BRAND
    ENABLE_COMMAND_PALETTE = False
    BINDINGS = [
        Binding("ctrl+p", "commands", priority=True, show=False),
        Binding("ctrl+x", "leader", priority=True, show=False),
        Binding("escape", "interrupt", show=False),
        Binding("ctrl+c", "clear_or_exit", priority=True, show=False),
        Binding("ctrl+d", "eof", priority=True, show=False),
        Binding("tab", "next_agent", priority=True, show=False),
        Binding("shift+tab", "previous_agent", priority=True, show=False),
        Binding("pageup", "page_up", priority=True, show=False),
        Binding("pagedown", "page_down", priority=True, show=False),
    ]
    CSS = """
    Screen { background: #0a0a0a; color: #eeeeee; }
    #main { height: 1fr; }
    #left { width: 1fr; height: 100%; padding: 0 2; }
    #conversation { height: 1fr; scrollbar-size: 1 1; }
    #home-logo { height: 16; width: auto; margin: 0 0 1 0; }
    #composer { height: auto; background: #1e1e1e; border-left: thick #fab283; padding: 1 2 0 2; }
    #prompt { height: 3; min-height: 1; padding: 0; border: none; background: #1e1e1e; }
    #prompt:focus { border: none; }
    #model-line { height: 1; margin-top: 1; color: #808080; }
    #hints { height: 1; margin-bottom: 1; color: #808080; }
    #footer { height: 1; color: #808080; padding: 0 2; }
    #queue { height: auto; color: #e5c07b; background: #141414; padding: 0 2; display: none; }
    #sidebar { width: 42; height: 100%; padding: 1 2; background: #141414; }
    #sidebar.overlay { layer: overlay; dock: right; }
    #sidebar-title { text-style: bold; margin-bottom: 1; }
    #sidebar-scroll { height: 1fr; }
    #sidebar-content { height: auto; }
    #sidebar-version { height: 1; color: #808080; }
    .message { height: auto; margin: 1 1 1 0; }
    ToolCardView.message { margin: 0 1 1 0; }
    .home #left { align: center middle; }
    .home #composer, .home #hints { width: 75; max-width: 100%; }
    .home #conversation { display: none; }
    .muted { color: #808080; height: auto; }
    ModalScreen { align: center middle; background: #000000 65%; }
    .dialog { width: 80; max-width: 95%; max-height: 90%; height: auto; background: #141414; padding: 1 2; border: solid #484848; }
    .dialog-title { color: #fab283; text-style: bold; margin-bottom: 1; }
    .dialog Input { margin: 1 0; }
    #choices { height: 15; max-height: 60%; }
    .request-details { height: auto; max-height: 12; }
    #question-options { height: auto; max-height: 14; margin-top: 1; }
    .buttons { height: auto; margin-top: 1; }
    .buttons Button { margin-right: 1; min-width: 12; }
    """

    def __init__(self, runtime, *, agent=None, model=None, session_id=None, deep=False):
        super().__init__()
        self.runtime = runtime
        self.agent = agent or runtime.default_agent
        self.model = model or runtime.config.get("model")
        self._initial_selection = (agent, model)
        self.session_id = session_id
        # Search switches for the next new session; a shown session uses its own.
        self.search = {group: True for group in search_switch.GROUPS}
        # Deep research for the next new session (opencode/deep.py); a shown session uses its own.
        self.deep = bool(deep)
        self.running_session = None
        self.leader_pending = False
        self.sidebar_override = None
        self.views: dict[str, list] = {}
        self.streamed: dict[str, str] = {}
        self.live_index: dict[str, int | None] = {}
        self.statuses: dict[str, str] = {}
        self.activities: dict[str, str] = {}
        # In-memory delivery state lasts only for this TUI subscription. These
        # IDs come from the producer, never from text or message position.
        self.results: dict[str, dict[str, dict]] = {}
        self._result_ids: set[str] = set()
        self._local_items: dict[str, list] = {}
        self._history_dirty: set[str] = set()
        self._refresh_pending: set[str] = set()
        self._live_text: dict[str, str] = {}
        self._view_lock = asyncio.Lock()
        self._waiting_history: set[str] = set()
        self._owned_sessions: set[str] = set()
        self._cancel_requested: set[str] = set()
        self._terminal_width = None
        self._interrupt_at = 0.0
        self._pending_id = None
        self._exit_requested = False
        self._bus = None
        self._old_callbacks = None
        # Footer state, fed by bus events; display only.
        self._started: dict[str, float] = {}
        self._running_tools: dict[str, list[tuple[str, str]]] = {}
        self._tokens: dict[str, str] = {}
        # Prompts submitted while a turn runs; sent in order once it ends.
        self.queued: list[dict] = []
        self._finishing: set[str] = set()
        self._render_cache: dict[str, dict[str, object]] = {}
        self._rendered_session = object()

    def compose(self) -> ComposeResult:
        with Horizontal(id="main"):
            with Vertical(id="left"):
                yield Static(logo(), id="home-logo")
                yield VerticalScroll(id="conversation")
                yield QueueBar(id="queue")
                with Vertical(id="composer"):
                    yield PromptInput(id="prompt", show_line_numbers=False, soft_wrap=True, tab_behavior="focus", placeholder="Ask anything…")
                    yield Static(id="model-line")
                yield Static(HINTS, id="hints")
            with Vertical(id="sidebar"):
                yield Static(id="sidebar-title")
                with VerticalScroll(id="sidebar-scroll"):
                    yield Static(id="sidebar-content")
                yield Static(f"{BRAND} {__version__}", id="sidebar-version")
        yield Static(id="footer")

    async def on_mount(self):
        self._old_callbacks = (self.runtime.permissions.callback, self.runtime.question_callback)
        self.runtime.permissions.callback = None
        self.runtime.question_callback = None
        self._bus = self.runtime.bus.subscribe()
        self.set_interval(0.10, self.poll_runtime)
        self.set_interval(0.10, self.refresh_footer)
        await self.show_session(self.session_id)
        explicit_agent, explicit_model = self._initial_selection
        self.agent = explicit_agent or self.agent
        self.model = explicit_model or self.model
        self.refresh_chrome()
        self.query_one(PromptInput).focus()

    def on_unmount(self):
        for session_id in self._owned_sessions:
            if self.owned_work_active(session_id):
                self.runtime.abort(session_id)
        if self._bus is not None:
            self.runtime.bus.unsubscribe(self._bus)
        if self._old_callbacks is not None:
            self.runtime.permissions.callback, self.runtime.question_callback = self._old_callbacks

    async def show_session(self, session_id):
        async with self._view_lock:
            self.session_id = session_id
            self.query_one("#main").set_class(session_id is None, "home")
            self.query_one("#home-logo").display = session_id is None
            if session_id:
                info = self.runtime.store.get_session(session_id)
                self.agent, self.model = info.get("agent") or self.agent, info.get("model") or self.model
                self.search = search_switch.states(info.get("permission"))
                self.deep = deep_is_on(self.runtime, session_id)
                if not self.load_history(session_id) and session_id not in self.views:
                    self._waiting_history.add(session_id)
            await self.render_conversation()
            self.refresh_chrome()

    def load_history(self, session_id):
        # Runtime ownership and the foreground callback lifetime both matter:
        # its queued text messages must finish before replacing transient UI.
        # Hold the execution lock through the snapshot so a new draft cannot
        # start between the idle check and the history read.
        with self.runtime._execution_lock:
            if (session_id == self.running_session or session_id in self.runtime._running
                    or session_id in self.runtime._background):
                self._history_dirty.add(session_id)
                return False
            messages = saved_history(self.runtime.store, session_id)
        # Reuse renderables for unchanged messages: the conversation then
        # remounts only what changed, and tool cards keep their expanded state.
        previous, cache = self._render_cache.get(session_id, {}), {}
        def cached(key, build):
            cache[key] = previous[key] if key in previous else build()
            return cache[key]
        items = []
        for item in with_tool_inputs(messages):
            if item.get("role") == "assistant" and item.get("tool_calls") and not (item.get("content") or "").strip() \
                    and not item.get("error"):
                continue  # its tool cards already say what it did
            key = json.dumps(item, sort_keys=True, ensure_ascii=False, default=str)
            items.append(cached(key, lambda item=item: message_renderable(item)))
        for result_id, result in self.results.get(session_id, {}).items():
            text = final_response(result, messages)
            if text:
                items.append(cached(json.dumps(["result", result_id, text]),
                                    lambda text=text: Group(Text("Final response", style="#fab283"), Markdown(text))))
        self._render_cache[session_id] = cache
        items.extend(self._local_items.get(session_id, []))
        self.views[session_id] = items
        self.live_index[session_id] = None
        self._waiting_history.discard(session_id)
        self._history_dirty.discard(session_id)
        return True

    async def render_conversation(self):
        # show_session and refresh_history hold the UI lock across Textual's
        # asynchronous removal/mount, so their widgets cannot interleave.
        # Only widgets after the first changed item are replaced, so a refresh
        # neither blanks the screen nor moves a reader who scrolled up.
        session_id = self.session_id
        conversation = self.query_one("#conversation", VerticalScroll)
        items = self.views.get(session_id, [])
        same_session = self._rendered_session == session_id
        at_bottom = conversation.scroll_y >= conversation.max_scroll_y - 1
        mounted = [widget for widget in conversation.children if widget.id != "waiting-note"]
        keep = 0
        if same_session:
            while keep < min(len(mounted), len(items)) and getattr(mounted[keep], "item", None) is items[keep]:
                keep += 1
        with self.batch_update():
            stale = mounted[keep:] + [widget for widget in conversation.children if widget.id == "waiting-note"]
            if stale:
                await conversation.remove_children(stale)
            widgets = [conversation_widget(item, index) for index, item in enumerate(items) if index >= keep]
            if session_id in self._waiting_history:
                widgets.append(Static("此對話正在執行；完成後載入已保存內容。", id="waiting-note", classes="message muted"))
            if widgets:
                await conversation.mount_all(widgets)
        self._rendered_session = session_id
        if not same_session or at_bottom:
            conversation.scroll_end(animate=False)

    @on(HistoryRefresh)
    async def refresh_history(self, event: HistoryRefresh):
        async with self._view_lock:
            self._refresh_pending.discard(event.session_id)
            if self.load_history(event.session_id) and event.session_id == self.session_id:
                await self.render_conversation()

    def refresh_chrome(self):
        off = [label for group, (label, _) in search_switch.GROUPS.items() if not self.search[group]]
        self.query_one("#model-line", Static).update(Text(f"{self.agent}  ·  {self.model or '(default model)'}"
                                                          + ("  ·  深入研究" if self.deep else "")
                                                          + (f"  ·  已關閉：{'、'.join(off)}" if off else "")))
        self.refresh_footer()
        self.refresh_queue()
        sidebar = self.query_one("#sidebar")
        wide = (self._terminal_width if self._terminal_width is not None else self.size.width) > 120
        sidebar.display = self.session_id is not None and (wide if self.sidebar_override is None else self.sidebar_override)
        sidebar.set_class(not wide, "overlay")
        if self.session_id:
            info = self.runtime.store.get_session(self.session_id)
            self.query_one("#sidebar-title", Static).update(Text(info.get("title") or "New session"))
            lines = [f"Agent  {info.get('agent') or self.agent}", f"Model  {info.get('model') or self.model or '(default)'}",
                     "Search  " + " · ".join(f"{label} {'開' if self.search[group] else '關'}"
                                             for group, (label, _) in search_switch.GROUPS.items()),
                     f"深入研究  {'開' if self.deep else '關'}"]
            todos = self.runtime.store.todos(self.session_id)
            if todos:
                lines.extend(["", "Todo", *(f"{item['status']}  {item['content']}" for item in todos)])
            children = self.runtime.store.children(self.session_id)
            if children:
                lines.extend(["", "Subagents", *((item.get("title") or item["id"]) + "  " + self.statuses.get(item["id"], "") for item in children)])
            if self.activities.get(self.session_id):
                lines.extend(["", "最近工具事件", self.activities[self.session_id]])
            lines.extend(["", "Ctrl+X B  sidebar", "Ctrl+X L  sessions", "Ctrl+X M  models"])
            self.query_one("#sidebar-content", Static).update(Text("\n".join(lines)))

    def session_busy(self, session_id) -> bool:
        if session_id is None:
            return False
        with self.runtime._execution_lock:
            return (session_id == self.running_session or session_id in self.runtime._running
                    or session_id in self.runtime._background)

    def refresh_footer(self):
        # A timer can fire during shutdown, after the widgets are gone.
        try:
            footer_widget = self.screen_stack[0].query_one("#footer", Static)
        except (NoMatches, IndexError):
            return
        sid = self.session_id
        busy = self.session_busy(sid)
        parts = []
        if busy:
            started = self._started.setdefault(sid, time.monotonic())
            elapsed = time.monotonic() - started
            parts.append(f"{SPINNER[int(elapsed * 10) % len(SPINNER)]} 執行中 {_elapsed(elapsed)}")
            tools = self._running_tools.get(sid) or []
            if tools:
                labels = [label for _, label in tools[-2:]]
                parts.append(", ".join(labels) + (f" +{len(tools) - 2}" if len(tools) > 2 else ""))
        else:
            self._started.pop(sid, None)
            if self.statuses.get(sid):
                parts.append(self.statuses[sid])
        if self._tokens.get(sid):
            parts.append(self._tokens[sid])
        if busy:
            parts.append("Esc×2 停止")
        footer = Text(f"{self.runtime.directory}   ", style="#808080")
        footer.append("  ·  ".join(parts), style="#eeeeee" if busy else "#808080")
        footer_widget.update(footer)

    def refresh_queue(self):
        try:
            bar = self.screen_stack[0].query_one("#queue", QueueBar)  # dialogs sit on top
        except (NoMatches, IndexError):
            return
        bar.display = bool(self.queued)
        lines = Text()
        for index, item in enumerate(self.queued):
            preview = " ".join(item["text"].split())
            if len(preview) > 60:
                preview = preview[:59] + "…"
            lines.append(f"⏳ 排隊中 {index + 1}  ", style="#e5c07b")
            lines.append(preview + "\n", style="#eeeeee")
        if self.queued:
            lines.append("本輪結束後依序送出 · 點擊一則取消 · Ctrl+X U 取消最後一則", style="#808080")
        bar.update(lines)

    def cancel_queued(self, index=None):
        if not self.queued:
            return False
        if index is None or not 0 <= index < len(self.queued):
            index = len(self.queued) - 1
        removed = self.queued.pop(index)
        self.refresh_queue()
        self.notify("已取消排隊訊息：" + " ".join(removed["text"].split())[:40])
        return True

    def update_tokens(self, session_id):
        # Only the provider-reported usage field is read; never message bodies.
        for message in reversed(self.runtime.store.messages(session_id)):
            if message.get("role") == "assistant" and message.get("tokens"):
                summary = token_summary(message["tokens"])
                if summary:
                    self._tokens[session_id] = summary
                return

    def drain_queue(self):
        if not self.queued or self.running_session or self._finishing or self._exit_requested:
            return
        item = self.queued[0]
        if self.session_busy(item["session_id"]):
            return
        self.queued.pop(0)
        session_id = item["session_id"]
        if session_id is None:
            session_id = self.runtime.create_session(agent=item["agent"], model=item["model"],
                                                     permission=item.get("permission"))["id"]
        self.running_session = session_id  # claimed now so a second drain cannot start
        self.refresh_queue()
        self.run_worker(self.launch(session_id, item["text"], item["agent"], item["model"],
                                    show=item["session_id"] is None), exit_on_error=False)

    def on_resize(self, event: events.Resize):
        self._terminal_width = event.size.width
        if self.is_mounted:
            # The resize event precedes the layout pass that updates App.size.
            self.refresh_chrome()
            self.call_after_refresh(self.resize_input)

    @on(TextArea.Changed)
    def resize_input(self):
        editor = self.query_one(PromptInput)
        width = max(1, editor.size.width)
        rows = sum(max(1, (cell_len(line) + width - 1) // width) for line in editor.text.split("\n"))
        editor.styles.height = min(max(1, rows), max(6, self.size.height // 3))

    async def append(self, session_id, item, *, retain=False):
        async with self._view_lock:
            if retain:
                self._local_items.setdefault(session_id, []).append(item)
            items = self.views.setdefault(session_id, [])
            index = len(items)
            items.append(item)
            if session_id == self.session_id:
                conversation = self.query_one("#conversation", VerticalScroll)
                at_bottom = conversation.scroll_y >= conversation.max_scroll_y - 1
                await conversation.mount(conversation_widget(item, index))
                if at_bottom:
                    conversation.scroll_end(animate=False)
            return index

    @on(PromptInput.Submitted)
    async def submit_prompt(self):
        editor = self.query_one(PromptInput)
        text = editor.text
        if not text.strip():
            return
        if text.startswith("/"):
            if await self.slash(text):
                editor.load_text("")
            return
        if await self.start_prompt(text, self.agent, self.model):
            editor.load_text("")

    async def start_prompt(self, text, agent, model):
        if self.running_session or self.session_busy(self.session_id) or self.queued:
            self.queued.append({"session_id": self.session_id, "text": text, "agent": agent, "model": model,
                                "permission": search_switch.apply([], self.search)})
            self.refresh_queue()
            return True
        if self.session_id is None:
            created = self.runtime.create_session(agent=agent, model=model,
                                                  permission=search_switch.apply([], self.search))
            if self.deep:
                set_deep(self.runtime.store, created["id"], True)
            await self.show_session(created["id"])
        self.running_session = self.session_id
        await self.launch(self.session_id, text, agent, model)
        return True

    async def launch(self, session_id, text, agent, model, *, show=False):
        """Start a turn whose session the caller has already claimed as running_session."""
        if show:
            await self.show_session(session_id)
        self._owned_sessions.add(session_id)
        self._started[session_id] = time.monotonic()
        self._running_tools[session_id] = []
        self._cancel_requested.discard(session_id)
        self.streamed[session_id], self.live_index[session_id] = "", None
        self.statuses[session_id] = "busy"
        await self.append(session_id, message_renderable({"role": "user", "content": text}))
        self.refresh_chrome()
        self.execute_prompt(session_id, text, agent, model)

    @work(thread=True, exit_on_error=False)
    def execute_prompt(self, session_id, text, agent, model):
        if self._exit_requested or session_id in self._cancel_requested:
            self.post_message(TurnEnded(session_id, error=RuntimeError("已取消，未開始執行。")))
            return
        try:
            result = self.runtime.prompt(session_id, text, agent=agent, model=model,
                on_text=lambda piece: self.post_message(TextArrived(session_id, piece)),
                on_tool_result=lambda result: self.post_message(ToolArrived(session_id, result)))
        except BaseException as error:
            self.post_message(TurnEnded(session_id, error=error))
        else:
            self.post_message(TurnEnded(session_id, result=result))

    @on(TextArrived)
    async def receive_text(self, event: TextArrived):
        sid = event.session_id
        self.streamed[sid] = self.streamed.get(sid, "") + event.text
        index = self.live_index.get(sid)
        if index is None:
            # Keep the text source beside the renderable only in this UI object.
            self.live_index[sid] = await self.append(sid, LiveText(event.text))
            self._live_text[sid] = event.text
        else:
            async with self._view_lock:
                self._live_text[sid] += event.text
                self.views[sid][index].text = self._live_text[sid]
                if sid == self.session_id:
                    conversation = self.query_one("#conversation", VerticalScroll)
                    at_bottom = conversation.scroll_y >= conversation.max_scroll_y - 1
                    widget = conversation.query_one(f"#message-{index}")
                    if isinstance(widget, LiveMarkdown):
                        widget.sync()
                    if at_bottom:
                        conversation.scroll_end(animate=False)

    @on(ToolArrived)
    async def receive_tool(self, event: ToolArrived):
        self.live_index[event.session_id] = None
        result = event.result
        await self.append(event.session_id, message_renderable({"role": "tool", "title": result.title,
            "name": getattr(result, "tool", ""), "input": getattr(result, "input", None),
            "content": result.output, "metadata": result.metadata}))
        files = result.metadata.get("files")
        if isinstance(files, list):
            for name in files:
                if isinstance(name, str):
                    path = (self.runtime.directory / name).resolve()
                    if path.is_file():
                        await self.append(event.session_id, Text(f"File  {path}", style="underline #5c9cf5"), retain=True)

    @on(TurnEnded)
    async def finish_turn(self, event: TurnEnded):
        sid = event.session_id
        # Release the turn before rendering its last lines; the queue waits
        # for this handler so a queued prompt cannot land above them.
        self._finishing.add(sid)
        if self.running_session == sid:
            self.running_session = None
        try:
            await self._finish_turn(event)
        finally:
            self._finishing.discard(sid)
        if not (self._exit_requested and not self.owned_work_active()):
            self.drain_queue()

    async def _finish_turn(self, event: TurnEnded):
        sid = event.session_id
        if event.error:
            await self.append(sid, Text(str(event.error), style="#e06c75"), retain=True)
        elif event.compaction:
            # summarize is not an _execute result and has no session.result.
            text = event.result.get("text") or ""
            if text:
                await self.append(sid, Group(Text("Final response", style="#fab283"), Markdown(text)), retain=True)
        self.live_index[sid] = None
        self._running_tools[sid] = []
        self._cancel_requested.discard(sid)
        self._history_dirty.add(sid)
        # Drain results before the final safe snapshot. Foreground completion
        # owns only its busy state; it never renders prompt result.text again.
        self.poll_runtime()
        with self.runtime._execution_lock:
            if sid not in self.runtime._running and sid not in self.runtime._background:
                self.statuses[sid] = "idle"
        self.update_tokens(sid)
        self.refresh_chrome()
        if self._exit_requested and not self.owned_work_active():
            self.exit()

    def poll_runtime(self):
        if not self.is_running:
            return
        # App registers a fresh cancellation Event when a prompt starts. An
        # early stop must also reach that Event if registration raced the key.
        for session_id in self._cancel_requested | (self._owned_sessions if self._exit_requested else set()):
            with self.runtime._execution_lock:
                if self.owned_work_active(session_id) and not self.runtime.abort_event(session_id).is_set():
                    self.runtime.abort(session_id)
        if self._exit_requested and self.running_session is None and not self.owned_work_active():
            self.exit()
            return
        changed = False
        while self._bus is not None:
            try:
                event = self._bus.get_nowait()
            except queue.Empty:
                break
            props = event["properties"]
            sid = props.get("sessionID")
            if event["type"] == "session.status":
                self.statuses[props["sessionID"]] = props["status"]
                if props["status"] == "idle":
                    self._history_dirty.add(sid)
            if event["type"] == "session.result":
                result_id = props["resultID"]
                if result_id not in self._result_ids:
                    self._result_ids.add(result_id)
                    self.results.setdefault(sid, {})[result_id] = dict(props)
                    self._history_dirty.add(sid)
            if event["type"] == "session.error":
                item = Text(str(props["error"]), style="#e06c75")
                self._local_items.setdefault(sid, []).append(item)
                self._history_dirty.add(sid)
                self.notify(f"{sid}: {props['error']}", severity="error")
            if event["type"] in {"message.updated", "task.completed"}:
                self._history_dirty.add(sid)
            if event["type"] in {"tool.running", "tool.completed"}:
                self.activities[props["sessionID"]] = str(props.get("tool") or props.get("title") or "") + (" · 開始" if event["type"] == "tool.running" else " · 完成")
                tools = self._running_tools.setdefault(sid, [])
                name = str(props.get("tool") or "")
                if event["type"] == "tool.running":
                    tool_input = props.get("input") if isinstance(props.get("input"), dict) else {}
                    argument = " ".join(tool_primary_argument(tool_input).split())
                    tools.append((name, name + (" " + argument[:40] if argument else "")))
                else:
                    match = next((entry for entry in tools if entry[0] == name), None)
                    if match:
                        tools.remove(match)
            if event["type"] == "message.updated" and sid == self.session_id:
                self.update_tokens(sid)
            if event["type"] in {"session.status", "session.updated", "todo.updated", "task.completed", "tool.running", "tool.completed"}:
                changed = True
            # message.updated invalidates only; reading its body while running
            # could expose a review draft before its final marker is assigned.
        if changed:
            self.refresh_chrome()
        for session_id in self._history_dirty | self._waiting_history:
            if session_id not in self.views and session_id != self.session_id:
                continue
            with self.runtime._execution_lock:
                active = (session_id == self.running_session or session_id in self.runtime._running
                          or session_id in self.runtime._background)
            if not active and session_id not in self._refresh_pending:
                self._refresh_pending.add(session_id)
                self.post_message(HistoryRefresh(session_id))
        self.drain_queue()
        permissions = self.runtime.permissions.list_pending()
        questions = self.runtime.pending_questions()
        if self._pending_id and self._pending_id not in {item["id"] for item in [*permissions, *questions]}:
            if isinstance(self.screen, (PermissionDialog, QuestionDialog)):
                self.screen.dismiss(None)
            self._pending_id = None
        if self._pending_id is not None or isinstance(self.screen, ModalScreen):
            return
        if permissions:
            request = permissions[0]
            self._pending_id = request["id"]
            def reply(value):
                self._pending_id = None
                if value:
                    self.runtime.permissions.reply(request["id"], value[0], value[1])
            self.push_screen(PermissionDialog(request), reply)
            return
        if questions:
            request = questions[0]
            self._pending_id = request["id"]
            def answer(value):
                self._pending_id = None
                if request["id"] not in {item["id"] for item in self.runtime.pending_questions()}:
                    return
                if value is None:
                    self.runtime.abort(request["sessionID"])
                else:
                    self.runtime.reply_question(request["id"], value)
            self.push_screen(QuestionDialog(request), answer)

    def on_key(self, event: events.Key):
        # The prompt handles its own keys; this covers focus elsewhere, such
        # as the conversation after clicking a tool card.
        if self.leader_pending and not isinstance(self.screen, ModalScreen):
            event.stop()
            event.prevent_default()
            self.consume_leader(event.key)

    def action_leader(self):
        if isinstance(self.screen, ModalScreen):
            return
        self.leader_pending = True
        self.query_one("#hints", Static).update("Ctrl+X …  N new · L sessions · M models · A agents · B sidebar · E 展開工具 · U 取消排隊 · Q exit")
        self.set_timer(2, self.clear_leader)

    def clear_leader(self):
        self.leader_pending = False
        if self.is_running:
            self.query_one("#hints", Static).update(HINTS)

    def consume_leader(self, key):
        self.clear_leader()
        if key == "e":
            self.toggle_tool_cards()
            return
        if key == "u":
            if not self.cancel_queued():
                self.notify("沒有排隊中的訊息。")
            return
        command = {"n": "new", "l": "sessions", "m": "models", "a": "agents", "b": "sidebar", "q": "quit", "c": "compact"}.get(key)
        if command:
            self.run_worker(self.slash("/" + command), exit_on_error=False)

    def toggle_tool_cards(self):
        cards = [view for view in self.query("#conversation ToolCardView").results(ToolCardView)
                 if view.item.collapsible]
        expand = any(not view.item.expanded for view in cards)
        for view in cards:
            view.item.expanded = expand
            view.update(view.item)

    def action_commands(self):
        if isinstance(self.screen, ModalScreen):
            return
        choices = [("New session", "/new"), ("Switch session", "/sessions"), ("Switch model", "/models"),
                   ("Switch agent", "/agents"), ("Search switches", "/search"), ("Deep research on/off", "/deep"),
                   ("Toggle sidebar", "/sidebar"), ("Compact session", "/compact"),
                   ("Undo file changes", "/undo"), ("Export session", "/export"), ("Help", "/help"), ("Exit", "/quit")]
        choices.extend(("/" + name, "/" + name) for name, command in (self.runtime.config.get("command") or {}).items()
                       if isinstance(command, dict))
        self.push_screen(ChoiceDialog("Commands", choices),
                         lambda choice: self.run_worker(self.slash(choice), exit_on_error=False) if choice else None)

    async def slash(self, text):
        name, _, rest = text.partition(" ")
        if name in {"/quit", "/exit"}:
            self.request_exit()
        elif name == "/new":
            if rest.strip():
                created = self.runtime.create_session(agent=self.agent, model=self.model, title=rest.strip(),
                                                      permission=search_switch.apply([], self.search))
                if self.deep:
                    set_deep(self.runtime.store, created["id"], True)
                await self.show_session(created["id"])
            else:
                await self.show_session(None)
        elif name == "/sidebar":
            self.sidebar_override = not self.query_one("#sidebar").display
            self.refresh_chrome()
        elif name in {"/sessions", "/models", "/agents", "/model", "/agent"}:
            await self.choose(name, rest.strip())
        elif name == "/search":
            return self.search_command(rest.split())
        elif name == "/deep":
            return self.deep_command(rest.strip())
        elif name == "/help":
            self.notify("Ctrl+X N 新對話；Ctrl+X L 對話；Ctrl+X M 模型；Ctrl+X B 側欄；/search 搜尋開關；"
                        "/deep 深入研究開關；Esc 兩次停止。", timeout=10)
        elif name == "/compact":
            if not self.session_id or self.running_session:
                self.notify("請先選擇閒置對話。", severity="warning")
            else:
                self.running_session = self.session_id
                self._owned_sessions.add(self.session_id)
                self.compact_session(self.session_id)
        elif name == "/undo":
            if not self.session_id or self.running_session:
                self.notify("請先選擇閒置對話。", severity="warning")
            else:
                restored = self.runtime.store.revert(self.session_id)
                self.notify("\n".join(restored) or "沒有可還原的檔案變更。")
        elif name == "/export" and self.session_id:
            data = {"session": self.runtime.store.get_session(self.session_id), "messages": self.runtime.store.messages(self.session_id)}
            await self.append(self.session_id, Text(json.dumps(data, ensure_ascii=False, indent=2)), retain=True)
        else:
            command = (self.runtime.config.get("command") or {}).get(name.removeprefix("/"))
            if isinstance(command, dict):
                expanded = (command.get("template") or "").replace("$ARGUMENTS", rest).replace("$1", rest)
                return await self.start_prompt(expanded, command.get("agent") or self.agent,
                                               command.get("model") or self.model)
            self.notify(f"尚未支援此介面命令：{name}", severity="warning")
            return False
        return True

    def deep_command(self, word):
        """/deep switches deep research for the shown task, or for the next new one; /deep on|off sets it. It
        takes effect from the next message (opencode/deep.py)."""
        if word not in {"", "on", "off"}:
            self.notify("用法：/deep，或 /deep <on|off>", severity="warning")
            return False
        self.deep = (not self.deep) if not word else word == "on"
        if self.session_id:
            set_deep(self.runtime.store, self.session_id, self.deep)
        self.notify(f"深入研究：{'開' if self.deep else '關'}（從下一則訊息起生效；研究指引與工具、驗證計畫、檢討）",
                    timeout=6)
        self.refresh_chrome()
        return True

    def search_command(self, words):
        """/search opens the switches; /search <web|literature|private|all> <on|off> sets them."""
        if not words:
            self.choose_search()
            return True
        groups = list(search_switch.GROUPS) if words[0] == "all" else [words[0]]
        if len(words) != 2 or words[1] not in {"on", "off"} or any(g not in search_switch.GROUPS for g in groups):
            self.notify("用法：/search，或 /search <web|literature|private|all> <on|off>", severity="warning")
            return False
        for group in groups:
            self.set_search(group, words[1] == "on")
        return True

    def choose_search(self):
        choices = [(f"{label}  {'開' if self.search[group] else '關'}  （{'、'.join(tools)}）", group)
                   for group, (label, tools) in search_switch.GROUPS.items()]
        def selected(group):
            if group:
                self.set_search(group, not self.search[group])
                self.choose_search()
        self.push_screen(ChoiceDialog("搜尋開關（Enter 切換）", choices), selected)

    def set_search(self, group, on):
        self.search[group] = on
        if self.session_id:
            # The loop reads the session's rules at each step, so a running task follows at its next step.
            info = self.runtime.store.get_session(self.session_id)
            self.runtime.store.update_session(self.session_id,
                                              permission=search_switch.apply(info.get("permission"), self.search))
        self.refresh_chrome()

    @work(thread=True, exit_on_error=False)
    def compact_session(self, session_id):
        try:
            result = self.runtime.summarize(session_id)
        except BaseException as error:
            self.post_message(TurnEnded(session_id, error=error))
        else:
            self.post_message(TurnEnded(session_id, result={"text": result}, compaction=True))

    async def choose(self, name, value):
        if name == "/sessions":
            choices = [(f"{item.get('title') or 'New session'} · {item['id']}" + (" · subagent" if item.get("parentID") else ""), item["id"])
                       for item in self.runtime.store.list_sessions(str(self.runtime.directory))]
            self.push_screen(ChoiceDialog("Sessions", choices),
                             lambda sid: self.run_worker(self.show_session(sid), exit_on_error=False) if sid else None)
            return
        model = name in {"/models", "/model"}
        if model:
            choices = [(f"{provider.id}/{item}", f"{provider.id}/{item}")
                       for provider in self.runtime.provider.available()
                       for item in provider.models or [provider.default_model] if item]
        else:
            choices = [(agent.name, agent.name) for agent in self.runtime.agents.values() if not agent.hidden]
        def selected(choice):
            if not choice:
                return
            if model:
                self.model = choice
            else:
                self.agent = choice
            if self.session_id:
                self.runtime.store.update_session(self.session_id, **{"model" if model else "agent": choice})
            self.refresh_chrome()
        if value:
            if model:
                # The existing CLI accepts provider/model ids beyond a provider's
                # advertised menu; resolution remains the provider's job.
                selected(value)
            elif value not in {choice for _, choice in choices}:
                self.notify("找不到這個選項。", severity="warning")
            else:
                selected(value)
        else:
            self.push_screen(ChoiceDialog("Models" if model else "Agents", choices), selected)

    def action_interrupt(self):
        if isinstance(self.screen, ModalScreen):
            return
        target = self.running_session or next((sid for sid in self._owned_sessions if self.owned_work_active(sid)), None)
        if not target:
            return
        now = time.monotonic()
        if now - self._interrupt_at <= 5:
            self._cancel_requested.add(target)
            self.runtime.abort(target)
            self._interrupt_at = 0
        else:
            self._interrupt_at = now
            self.notify("再按一次 Esc 停止目前工作。")

    def action_clear_or_exit(self):
        if isinstance(self.screen, ModalScreen):
            self.request_exit()
            return
        editor = self.query_one(PromptInput)
        if editor.text:
            editor.load_text("")
        else:
            self.request_exit()

    def action_eof(self):
        if isinstance(self.screen, ModalScreen):
            focused = self.focused
            if isinstance(focused, Input) and focused.value:
                focused.action_delete_right()
            else:
                self.request_exit()
            return
        editor = self.query_one(PromptInput)
        if editor.text:
            editor.action_delete_right()
        else:
            self.request_exit()

    def request_exit(self):
        self._exit_requested = True
        for session_id in self._owned_sessions:
            if session_id == self.running_session or self.owned_work_active(session_id):
                self.runtime.abort(session_id)
        if self.running_session or self.owned_work_active():
            self.notify("正在停止工作並保留內容…")
        else:
            self.exit()

    def owned_work_active(self, session_id=None):
        # Background descendants can outlive the foreground prompt callback.
        # Read the existing App ownership map; never cancel unrelated sessions.
        with self.runtime._execution_lock:
            owned = {session_id} if session_id else set(self._owned_sessions)
            while True:
                children = {child for child, parent in self.runtime._task_parents.items() if parent in owned}
                if children <= owned:
                    break
                owned.update(children)
            return bool(owned.intersection(self.runtime._running) or owned.intersection(self.runtime._background))

    def action_next_agent(self):
        self.cycle_agent(1)

    def action_previous_agent(self):
        self.cycle_agent(-1)

    def cycle_agent(self, direction):
        if isinstance(self.screen, ModalScreen):
            self.screen.focus_next() if direction > 0 else self.screen.focus_previous()
            return
        names = [agent.name for agent in self.runtime.agents.values() if not agent.hidden and agent.mode != "subagent"]
        if not names:
            return
        self.agent = names[((names.index(self.agent) if self.agent in names else 0) + direction) % len(names)]
        if self.session_id:
            self.runtime.store.update_session(self.session_id, agent=self.agent)
        self.refresh_chrome()

    def action_page_up(self):
        if not isinstance(self.screen, ModalScreen):
            self.query_one("#conversation", VerticalScroll).scroll_page_up(animate=False)

    def action_page_down(self):
        if not isinstance(self.screen, ModalScreen):
            self.query_one("#conversation", VerticalScroll).scroll_page_down(animate=False)


def run(runtime, args, *, session_id=None):
    OpenCodeTUI(runtime, agent=args.agent, model=args.model, session_id=session_id,
                deep=getattr(args, "deep", False)).run()
