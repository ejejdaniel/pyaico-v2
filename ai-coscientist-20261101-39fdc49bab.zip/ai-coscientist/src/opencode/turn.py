"""Optional, installed turn hooks. No domain policy belongs in this module."""

from typing import Protocol


class TurnExtension(Protocol):
    def context(self) -> str: ...
    def feedback(self) -> str | None: ...
    def present(self, text: str, status: str) -> str: ...


def create_extension(app, session_id: str, user_message_id: str, *, deep: bool = False) -> TurnExtension | None:
    """The turn extension: the folder's own, or, while the task has deep research on, the one deep research
    installs (opencode/deep.py)."""
    factory = app.turn_extension_factory or (getattr(getattr(app, "deep", None), "extension", None) if deep else None)
    if factory is None:
        return None
    extension = factory(app, session_id, user_message_id)
    if not all(callable(getattr(extension, name, None)) for name in ("context", "feedback", "present")):
        raise TypeError("TURN_EXTENSION must return context(), feedback(), and present() methods")
    return extension


def context_text(extension: TurnExtension | None) -> str:
    value = extension.context() if extension else ""
    if not isinstance(value, str):
        raise TypeError("Turn context must be text")
    return value
