"""The task's verification plan, written by the reviewer before the first round (skill charter 0.3).

A task can be solved when three things are clear: what is asked, how a result is checked, and when the work
is done or stops. In acoustics round 1 and the reruns of round 2 (2026-10-31) the working agent built a
checking tool for over a hundred calls without seeing that it was building one, without a known-answer check
of it, and without a point at which to set it aside; the lessons written after each round said so too late.

So before the first round a reviewer reads the commission and the task's sources and writes, with the
framework's verification method (skill_assets/verification/SKILL.md), the task's verification plan: the
truth sources the task has, the checks each layer (input, computation, result) can rely on with their
strength, the evidence the host can see when each is ready, and the stop conditions. It is a review skill
(task_skills): read-only to the working agent, ranked below the commission and the framework's rules, and
every entry cites the ids of the evidence it rests on (machine-checked, charter article 4). The framework,
not the model, turns the ids into locations.

The plan is sized to the task. A question answered by reading its sources needs a check or two, and a
greeting or a confirmation none: the reviewer may judge that a plan would cost more than the work. That
verdict writes no skill and holds for its round only, since the next round's request may need a plan (it is
judged again between the rounds); a written plan holds for the whole task.

It makes one model call through a function its caller supplies; a reply that fails the format gets one
repair call.
"""

from __future__ import annotations

import json
from pathlib import Path
import re

from opencode import task_skills
from opencode.round_review import LIMITS, TEXT_SHARE, Item, _clip, _normal, _sources

SKILL = "verification-plan"
PLAN_FILE = "plan.json"
METHOD = Path(__file__).with_name("skill_assets") / "verification" / "SKILL.md"
LAYERS = ("input", "computation", "result")
STRENGTHS = ("strong", "medium", "weak", "none")
SCOPES = ("task", "work")
_LAYER_TEXT = {"input": "輸入", "computation": "計算", "result": "結果"}
_STRENGTH_TEXT = {"strong": "強", "medium": "中", "weak": "弱", "none": "無"}

_ENTRY = {"type": "object", "additionalProperties": False}
_TEXT = {"type": "string"}
_IDS = {"type": "array", "items": {"type": "string"}}
SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["needed", "reason", "description", "problem", "resources", "checks", "stops"],
    "properties": {
        "needed": {"type": "boolean"},
        "reason": _TEXT,
        "description": _TEXT,
        "problem": {**_ENTRY, "required": ["text", "evidence"], "properties": {"text": _TEXT, "evidence": _IDS}},
        "resources": {"type": "array", "items": {**_ENTRY, "required": ["resource", "what", "evidence"],
                                                 "properties": {"resource": _TEXT, "what": _TEXT, "evidence": _IDS}}},
        "checks": {"type": "array", "items": {
            **_ENTRY, "required": ["layer", "target", "methods", "strength", "ready_when", "evidence"],
            "properties": {"layer": {"type": "string", "enum": list(LAYERS)}, "target": _TEXT, "methods": _TEXT,
                           "strength": {"type": "string", "enum": list(STRENGTHS)}, "ready_when": _TEXT,
                           "evidence": _IDS}}},
        "stops": {"type": "array", "items": {**_ENTRY, "required": ["scope", "condition", "evidence"],
                                             "properties": {"scope": {"type": "string", "enum": list(SCOPES)},
                                                            "condition": _TEXT, "evidence": _IDS}}},
    },
}
_LISTS = {"resources": ("resource", "what"), "checks": ("layer", "target", "methods", "strength", "ready_when"),
          "stops": ("scope", "condition")}
_CHOICES = {"layer": LAYERS, "strength": STRENGTHS, "scope": SCOPES}


def method() -> str:
    """The framework's verification method, without its front matter."""
    text = METHOD.read_text(encoding="utf-8")
    return text.split("---", 2)[2].strip() if text.startswith("---") else text.strip()


def instructions(rules: dict, round_: int = 1) -> str:
    budget = int(rules["max_chars"] * TEXT_SHARE)
    when = ("before its first round. The working agent has not started" if round_ == 1 else
            f"before round {round_}: no plan was needed for the earlier rounds, and this round's request (C2, when "
            "it differs from the commission) may need one")
    return f"""You are the reviewer of one task, {when}. You run no tools and change nothing: you read the commission and the task's sources in the user message, and write the task's verification plan with the framework's verification method below, as one JSON object. The working agent reads the plan throughout the task.

First judge whether the task needs a plan, and size the plan to the task (the method's section 1).
- needed: false when a plan would cost more than the work, such as a greeting, a confirmation, or a question one direct reading answers. Then reason says why, problem says what is asked with its evidence, and resources, checks and stops stay empty; no plan is written, and the framework judges again before the task's next round.
- needed: true otherwise, with reason saying in one sentence what makes checking matter here. A question answered by reading the sources needs one or two checks of the result layer (each claim traced to where it was read), not a computation layer, and such a check is ready when the answer itself cites the file and line or the record each claim comes from: it needs no saved record, script or report; a task that models, computes, designs or predicts needs checks for the layers it uses.

The plan says how results in this task can be checked, not what they should be.
- problem: what is asked and how results are judged, in the commission's own terms (its target, measure and limits).
- resources: the truth sources this task actually has (physical laws and models, measurements and how many, standards, literature, hand-computable cases, the sources' own statements, review), and what it lacks.
- checks: for the input, computation and result layers, what is checked, by which methods, how strong the check is, and what evidence shows the check is ready: for a computation, something the host can see (a mounted task tool whose known-answer tests passed, a saved comparison with the task's measurements, a saved check that can be rerun); for a claim read from the sources, its citation in the answer. A checking tool the work must build is itself a check of the computation layer.
- stops: the task's own completion conditions as the commission states them (scope "task"), and for pieces of work, chiefly building a check, when to stop and record a gap instead (scope "work").

Rules (skill charter {rules['version']}):
- Evidence (article 4): every entry cites at least one id from the package, such as C1 or S2. An entry with no citation, or with an id the package does not hold, is not written.
- Rank (article 1): the plan ranks below the commission and below every rule, check, tool contract and scoring definition of the framework. Never relax, replace or reinterpret them, and never change what the commission asks for or how it is judged.
- No answers: write no result, value or design the work should arrive at, and no fact the sources do not state. Name no skills and no order of work; one check can be met in more than one way.
- Size (article 3): the description and all entries together stay under {budget} characters. A few checks that matter are better than many.
- Language: write in the language and script of the commission (Traditional Chinese when it is written in Traditional Chinese).

Reply with JSON only, in this shape: {{"needed": true, "reason": "one sentence", "description": "one sentence: how results in this task can be checked", "problem": {{"text": "...", "evidence": ["C1"]}}, "resources": [{{"resource": "...", "what": "...", "evidence": ["S1"]}}], "checks": [{{"layer": "computation", "target": "...", "methods": "...", "strength": "medium", "ready_when": "...", "evidence": ["C1", "S1"]}}], "stops": [{{"scope": "task", "condition": "...", "evidence": ["C1"]}}]}}

The framework's verification method:

{method()}"""


def package(*, commission: str, directory: Path, sources=(), request: str = "",
            round_: int = 1) -> tuple[str, list[Item]]:
    """The planner's evidence package, and its citable items. request: this round's request (C2, when it is
    not the commission)."""
    items = [Item("C1", "the commission", "the session's first request", _clip(commission, LIMITS["commission"]))]
    if request.strip() and request.strip() != commission.strip():
        items.append(Item("C2", "this round's request", f"the first request of round {round_}",
                          _clip(request, LIMITS["request"])))
    items += _sources(directory, sources)
    when = "its first round" if round_ == 1 else f"round {round_}"
    parts = [f"Evidence package for the verification plan of this task, before {when}. "
             "Each item's id is in brackets; cite those ids."]
    parts += [f"[{item.id}] {item.title} ({item.where})\n{item.text}" for item in items]
    return "\n\n".join(parts), items


def parse(text: str) -> dict:
    """The planner's reply, checked for shape (not yet for its citations)."""
    stripped = text.strip()
    fence = re.fullmatch(r"```(?:json)?\s*\n(.*)\n```", stripped, re.S)
    try:
        value = json.loads(fence.group(1) if fence else stripped)
    except json.JSONDecodeError as error:
        raise ValueError(f"Expected one JSON object: {error}") from error
    if not isinstance(value, dict):
        raise ValueError("Expected one JSON object")
    missing = [key for key in SCHEMA["required"] if key not in value]
    if missing:
        raise ValueError(f"Missing {', '.join(missing)}")
    if not isinstance(value["needed"], bool):
        raise ValueError("needed must be true or false")
    if not isinstance(value["reason"], str) or (not value["needed"] and not value["reason"].strip()):
        raise ValueError("reason must say why the task does or does not need a plan")
    if not isinstance(value["description"], str) or not value["description"].strip():
        raise ValueError("description must be one nonempty sentence")
    problem = value["problem"]
    if not isinstance(problem, dict) or not isinstance(problem.get("text"), str) or not problem["text"].strip():
        raise ValueError("problem must have nonempty text and evidence")
    if not isinstance(problem.get("evidence"), list):
        raise ValueError("problem: evidence must be a list of ids")
    for key, fields in _LISTS.items():
        if not isinstance(value[key], list):
            raise ValueError(f"{key} must be a list")
        for number, entry in enumerate(value[key], 1):
            where = f"{key} entry {number}"
            if not isinstance(entry, dict) or any(field not in entry for field in (*fields, "evidence")):
                raise ValueError(f"{where} must have {', '.join((*fields, 'evidence'))}")
            if not isinstance(entry["evidence"], list) or not all(isinstance(x, str) for x in entry["evidence"]):
                raise ValueError(f"{where}: evidence must be a list of ids")
            for field in fields:
                if not isinstance(entry[field], str) or not entry[field].strip():
                    raise ValueError(f"{where}: {field} must be nonempty text")
                if field in _CHOICES and entry[field] not in _CHOICES[field]:
                    raise ValueError(f"{where}: {field} must be one of {', '.join(_CHOICES[field])}")
    if not value["needed"] and any(value[key] for key in _LISTS):
        raise ValueError("needed is false, so resources, checks and stops stay empty; if the task needs these "
                         "checks, set needed to true")
    if value["needed"] and not value["checks"]:
        raise ValueError("checks must name at least one check")
    return value


def _evidence(ids, by_id: dict[str, Item]) -> list[dict]:
    return [{"id": id_, "title": by_id[id_].title, "where": by_id[id_].where} for id_ in dict.fromkeys(ids)]


def cite(reply: dict, items: list[Item]) -> tuple[dict, list[dict]]:
    """The entries whose citations the package holds, with their evidence resolved; and the refused ones."""
    by_id = {item.id: item for item in items}

    def check(entry):
        ids = [_normal(value) for value in entry["evidence"] if _normal(value)]
        unknown = [value for value in ids if value not in by_id]
        if not ids:
            return None, "it cites no evidence"
        if unknown:
            return None, f"it cites {', '.join(unknown)}, which the evidence package does not hold"
        return _evidence(ids, by_id), None

    refused = []
    evidence, reason = check(reply["problem"])
    if reason:
        raise ValueError(f"problem: {reason} (skill charter article 4)")
    accepted = {"needed": reply["needed"], "reason": " ".join(reply["reason"].split()),
                "problem": {"text": reply["problem"]["text"].strip(), "evidence": evidence}}
    if not reply["needed"]:
        return {**accepted, **{key: [] for key in _LISTS}}, refused
    for key, fields in _LISTS.items():
        accepted[key] = []
        for entry in reply[key]:
            evidence, reason = check(entry)
            text = {field: entry[field].strip() for field in fields}
            if reason:
                refused.append({"kind": key, **text, "reason": f"{reason} (skill charter article 4)"})
            else:
                accepted[key].append({**text, "evidence": evidence})
    if not accepted["checks"]:
        raise ValueError("no check cites evidence the package holds (skill charter article 4)")
    return accepted, refused


def _cited(evidence: list[dict]) -> str:
    return "；".join(f"{item['id']} {item['title']} `{item['where']}`" for item in evidence)


def skill_body(plan: dict, round_: int = 1) -> str:
    lines = ["# 本任務的驗證計畫", "",
             f"第 {round_} 輪開工前由檢討者依框架的驗證方法整理。它低於委託，也低於框架的規則、檢查與評分定義，不改變其中"
             "任何一項；它只說怎麼驗證、看什麼證據，不說結果應該是多少，也不規定做事的順序。每條都附依據；依據不成立的，"
             "指出來，不要照做。就緒要有框架看得到的證據；沒有證據的檢查就是未就緒，把它做出來並驗過本身就是一段工作。", "",
             "## 題目", "", plan["problem"]["text"], f"依據：{_cited(plan['problem']['evidence'])}", "",
             "## 驗證資源", ""]
    for entry in plan["resources"]:
        lines.append(f"- {entry['resource']}：{entry['what']}（依據：{_cited(entry['evidence'])}）")
    lines += ["", "## 檢查", ""]
    for number, entry in enumerate(plan["checks"], 1):
        lines += [f"V{number}. [{_LAYER_TEXT[entry['layer']]}｜{_STRENGTH_TEXT[entry['strength']]}] {entry['target']}",
                  f"   方法：{entry['methods']}", f"   就緒的證據：{entry['ready_when']}",
                  f"   依據：{_cited(entry['evidence'])}"]
    lines += ["", "## 停止條件", ""]
    for entry in plan["stops"]:
        scope = "任務" if entry["scope"] == "task" else "每段工作"
        lines.append(f"- {scope}：{entry['condition']}（依據：{_cited(entry['evidence'])}）")
    return "\n".join(lines)


def plan_path(root: str) -> Path:
    return task_skills.review_dir(root) / SKILL / PLAN_FILE


def saved_plan(root: str) -> dict | None:
    """The task's verification plan as it was saved, or None when it has none."""
    try:
        value = json.loads(plan_path(root).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) and isinstance(value.get("checks"), list) else None


def planned(root: str, round_: int) -> bool:
    """Whether the task's plan stands for this round: a written plan holds for the whole task, a verdict that
    none is needed for the round it was given in."""
    value = saved_plan(root)
    return value is not None and (value.get("needed") is not False or value.get("round") == round_)


def plan(complete, *, root: str, directory, commission: str, request: str = "", round_: int = 1, sources=(),
         core=()) -> dict:
    """Write the task's verification plan before its first round (or before a later one, when the earlier
    rounds needed none); return the record, whose status is "written" or "not-needed".

    complete(system, message, (name, schema)) makes one model call and returns its completion (.text)."""
    directory = Path(directory).resolve()
    rules = task_skills.charter()
    message, items = package(commission=commission, directory=directory, sources=sources, request=request,
                             round_=round_)
    system = instructions(rules, round_)
    record = {"session": root, "charter": str(rules["version"]), "round": round_,
              "evidence": [{"id": item.id, "title": item.title, "where": item.where} for item in items], "replies": []}
    request_text = message
    for attempt in range(2):
        completion = complete(system, request_text, ("verification_plan", SCHEMA))
        text = completion.text if isinstance(getattr(completion, "text", None), str) else ""
        record["replies"].append(text)
        try:
            reply = parse(text)
            accepted, refused = cite(reply, items)
            description = " ".join(reply["description"].split())
            body = skill_body(accepted, round_) if accepted["needed"] else ""
            if len(description) + len(body) > rules["max_chars"]:
                raise ValueError(f"With the evidence locations the framework adds, the plan takes "
                                 f"{len(description) + len(body)} characters; the skill charter allows "
                                 f"{rules['max_chars']}. Keep the checks that matter and shorten them.")
            break
        except ValueError as error:
            if attempt:
                raise ValueError(f"The verification plan failed its one repair: {error}") from error
            request_text = "\n\n".join([
                message, "Your reply could not be used. Fix the issue below and return the complete JSON object "
                "again; keep its content otherwise.", "Your reply:", text, "The issue:", str(error)])
    saved = {"round": round_, "description": description, **accepted}
    if not accepted["needed"]:
        # No skill: nothing comes to the working agent. The verdict is kept so this round does not ask again.
        plan_path(root).parent.mkdir(parents=True, exist_ok=True)
        plan_path(root).write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n")
        record.update(status="not-needed", description=description, reason=accepted["reason"], plan=accepted,
                      refused=refused)
        return record
    path = task_skills.write_review(root, SKILL, description, body, core)
    plan_path(root).write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n")
    record.update(status="written", skill=str(path), description=description, plan=accepted, refused=refused)
    return record


def package_items(root: str) -> list[Item]:
    """The plan's checks as items a later review can cite (V1, V2, ...), each with the plan's own evidence."""
    value = saved_plan(root) or {}
    items = []
    for number, entry in enumerate(value.get("checks") or [], 1):
        items.append(Item(
            f"V{number}", "a check of the task's verification plan", "the verification plan written before round 1",
            f"[{entry.get('layer')} | {entry.get('strength')}] {entry.get('target')}\nMethods: {entry.get('methods')}\n"
            f"Ready when: {entry.get('ready_when')}"))
    return items
