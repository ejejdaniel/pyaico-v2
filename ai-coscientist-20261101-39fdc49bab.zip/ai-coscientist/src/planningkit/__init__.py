"""Optional, science-neutral planning persistence and projections."""
