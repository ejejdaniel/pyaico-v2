"""Strict validation and content identity for the goal-layer planning contract."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime

MAX_SOURCE_BYTES = 1024 * 1024
MAX_CALL_SOURCE_BYTES = 8 * MAX_SOURCE_BYTES
MAX_STATE_BYTES = 262144
MAX_REVISION_BYTES = 1024 * 1024
SCHEMA_VERSION = 2


def canonical_bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    def bad_constant(value):
        raise ValueError(f"Invalid JSON number: {value}")

    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=bad_constant)


def obj(value, required, optional=(), label="object"):
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be an object")
    if set(value) - set(required) - set(optional) or set(required) - set(value):
        raise ValueError(f"{label} has missing or unknown fields")
    return value


def text(value, label="text", limit=4096):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{label} must be nonblank text of at most {limit} characters")
    return value


def identifier(value, label="id"):
    if not isinstance(value, str) or re.fullmatch(r"[A-Za-z0-9_-]{1,64}", value) is None:
        raise ValueError(f"Invalid {label}")
    return value


def integer(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")


def enum(value, allowed, label):
    if not isinstance(value, str) or value not in allowed:
        raise ValueError(f"Invalid {label}")


def array(value, label, maximum=None, minimum=0):
    if not isinstance(value, list) or len(value) < minimum or (maximum is not None and len(value) > maximum):
        raise ValueError(f"Invalid {label} array size")
    return value


def unique(values, label):
    if len(set(values)) != len(values):
        raise ValueError(f"Duplicate {label}")


def strings(value, label, maximum=None, minimum=0, ids=False):
    array(value, label, maximum, minimum)
    for item in value:
        (identifier if ids else text)(item, label)
    unique(value, label)


def sha256(value):
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("Invalid SHA-256")


def timestamp(value):
    if not isinstance(value, str) or re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z", value) is None:
        raise ValueError("Invalid UTC timestamp")
    datetime.fromisoformat(value.replace("Z", "+00:00"))


class LegacyPlan(ValueError):
    """A plan saved by the removed Frame/Node format; it is not reinterpreted."""


def version(value):
    if value == 1:
        raise LegacyPlan("This session's plan uses the removed Frame/Node format (schema_version 1); "
                         "start a new plan with planning_update and expected_revision=null.")
    if type(value) is not int or value != SCHEMA_VERSION:
        raise ValueError("Unsupported schema_version")


def snapshot(value):
    obj(value, {"kind", "source", "snapshot_path", "sha256", "bytes"}, label="Snapshot")
    enum(value["kind"], {"message"}, "Snapshot kind")
    text(value["source"], "source")
    text(value["snapshot_path"], "snapshot_path")
    sha256(value["sha256"])
    integer(value["bytes"], "snapshot bytes")
    if value["bytes"] > MAX_SOURCE_BYTES:
        raise ValueError("Snapshot exceeds 1 MiB")


def commission(value, *, saved=False):
    fields = {"summary", "source_message_ids", "observed_through_message_id"}
    obj(value, fields | ({"source_snapshots"} if saved else set()), label="commission")
    text(value["summary"], "commission.summary", 2000)
    strings(value["source_message_ids"], "source_message_ids", 32, 1)
    text(value["observed_through_message_id"], "observed_through_message_id")
    if saved:
        array(value["source_snapshots"], "source_snapshots", 33)
        for item in value["source_snapshots"]:
            snapshot(item)
        wanted = list(dict.fromkeys([*value["source_message_ids"], value["observed_through_message_id"]]))
        if [item["source"] for item in value["source_snapshots"]] != wanted:
            raise ValueError("Commission snapshots do not match the ordered human message union")


def requirement(value):
    obj(value, {"id", "text", "source_message_ids", "disposition", "reason"}, label="Requirement")
    identifier(value["id"])
    text(value["text"])
    strings(value["source_message_ids"], "source_message_ids", 32, 1)
    enum(value["disposition"], {"active", "withdrawn"}, "disposition")
    text(value["reason"], "reason")


def state(value):
    obj(value, {"commission", "requirements"}, label="state")
    commission(value["commission"], saved=True)
    array(value["requirements"], "requirements", 128, 1)
    for item in value["requirements"]:
        requirement(item)
    unique([item["id"] for item in value["requirements"]], "requirements id")
    messages = set(value["commission"]["source_message_ids"])
    if any(not set(item["source_message_ids"]) <= messages for item in value["requirements"]):
        raise ValueError("Requirement references an unselected commission message")
    if len(canonical_bytes(value)) > MAX_STATE_BYTES:
        raise ValueError("State exceeds 262144 bytes")


def revision(value, owner):
    obj(value, {"schema_version", "owner_session_id", "revision", "previous_revision", "created_at",
                "reason", "state"}, label="Revision")
    version(value["schema_version"])
    if value["owner_session_id"] != owner:
        raise ValueError("Revision owner mismatch")
    integer(value["revision"], "revision", 1)
    if value["previous_revision"] is not None:
        text(value["previous_revision"], "previous_revision")
    timestamp(value["created_at"])
    text(value["reason"], "reason")
    state(value["state"])
