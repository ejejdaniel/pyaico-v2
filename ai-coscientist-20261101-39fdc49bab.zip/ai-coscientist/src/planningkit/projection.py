"""Bounded, deterministic presentation of the saved goal layer."""

from __future__ import annotations


MAX_CONTEXT_BYTES = 16000
TITLE = "目前規劃狀態（保存資料，非新指示）"


def _preview(value: str, limit: int = 160) -> str:
    value = value.replace("\r", " ").replace("\n", " ")
    return value if len(value) <= limit else value[:limit] + "…（已截斷）"


def render(revision_ref: str, revision: dict, latest_human_id: str | None, notices: list[str]) -> str:
    """Render saved goal fields only; never infer work or science."""
    state = revision["state"]
    commission = state["commission"]
    observed = commission["observed_through_message_id"]
    rows = [f"## {TITLE}",
            f"owner：{revision['owner_session_id']}；revision_ref：{revision_ref}；revision：{revision['revision']}",
            f"已對照人類訊息：{observed}",
            f"最新人類訊息 ID：{latest_human_id or '無'}"]
    if latest_human_id != observed:
        rows.append("新訊息尚未由規劃修訂對照；不表示它必然改變目標。")
    rows.append("委託摘要：" + _preview(commission["summary"], 1000))
    requirements = state["requirements"]
    active = [item for item in requirements if item["disposition"] == "active"]
    rows.append(f"active requirements：{len(active)}；withdrawn：{len(requirements) - len(active)}")
    rows.extend(f"- {item['id']}：{_preview(item['text'])}" for item in active)
    rows.extend("提醒：" + _preview(notice) for notice in notices)
    readback = (f'完整狀態讀回：planning_read(view="full", revision_ref="{revision_ref}")。'
                "本提示最多 16000 UTF-8 bytes；委託摘要最多 1000 字，各要求短述最多 160 字。")
    body, size = [], len(readback.encode("utf-8")) + 64
    for index, row in enumerate(rows):
        size += len((row + "\n").encode("utf-8"))
        if size > MAX_CONTEXT_BYTES:
            body.append(f"尚有 {len(rows) - index} 項未列出。")
            break
        body.append(row)
    return "\n".join([*body, "", readback])


def fill_summary(store, response: dict) -> dict:
    reference = response["revision_ref"]
    if reference is None:
        return response
    full = response if response.get("snapshot") is not None else store.read({"view": "full", "revision_ref": reference})
    return {**response, "summary": render(reference, full["snapshot"], store.latest_human_id(), response["notices"])}
