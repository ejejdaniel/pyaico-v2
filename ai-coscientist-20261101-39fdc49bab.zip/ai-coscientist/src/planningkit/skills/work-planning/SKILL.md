---
name: work-planning
description: Keep a saved, source-bound record of what the human asked for — a commission and requirements traced to exact human messages — so lengthy work stays aligned across compaction and changed requests. Record it when a multi-part commission starts; short questions can be answered directly.
---

# Work planning

Planning here records goals, not steps. It keeps the human's commission and its
requirements, each traced to exact human message IDs, so that after many turns
and compactions you can still check your work against what was actually asked.
The actual human messages remain authoritative.

Choose actions dynamically. Planning never schedules, orders or blocks work.

| Need | Use |
|---|---|
| The next few operations | `todowrite` |
| Design a larger change before acting, or confirm it with the user | plan mode (`plan_enter` / `plan_exit`) |
| What the human asked for, across the whole session | `planning_update` (this skill) |
| Domain reasoning state, when an extension offers one | that extension's tool (for research: `research_graph_update`) |

Read [plan operations](references/operations.md) before creating or revising a
plan. Read [continuation and changes](references/continuation.md) when resuming
or when a new human message arrives. Links are relative to this skill's
directory.

A requirement records an obligation, not proof it was met. Completion is judged
from actual results and applicable reviews, not from the plan.
