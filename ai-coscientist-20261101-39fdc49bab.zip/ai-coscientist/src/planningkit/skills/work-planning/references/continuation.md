# Continuation, changes and recovery

Read the saved plan and actual results before resuming. Compaction is not a
reason to rebuild a plan or repeat a calculation. A new session has its own
plan; nothing is imported from a parent session automatically.

## When a new human message arrives

The summary notes a human message the plan has not reconciled. That notice does
not mean the goal changed. Read the message and decide what it is:

- a question or status request: answer it; optionally update
  `observed_through_message_id` so the notice clears;
- an added constraint or goal: add requirements citing the new message;
- a changed or dropped goal: revise or withdraw the affected requirements with
  a reason, and add the message to the commission sources.

Do not quietly reinterpret old requirements to fit new work, and do not treat a
new, easier requirement as fulfilling an old one.

If a domain extension links its own records to requirement IDs (for research,
decision nodes in the reasoning graph), changing or withdrawing a requirement
marks those linked items for review there. Re-check each one: update it, or
record why it still holds. When the change is large, consider plan mode to lay
out the rework and confirm it with the user before acting.

## Failures

Wait for a successful receipt before issuing a dependent update. Calls in one
model reply may run in parallel. On a revision conflict, read the current plan
and decide what remains appropriate; do not retry blindly. If a reply is lost,
read back the head before resubmitting. A failed call preserves earlier
committed versions; report the failure and continue with useful authorized work.
