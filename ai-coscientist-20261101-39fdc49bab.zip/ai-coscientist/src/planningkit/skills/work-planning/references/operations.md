# Plan operations

## Read and establish scope

`planning_read` defaults to the current summary. Use `view="full"` for the exact
saved revision and `view="history"` for up to 20 revision headers. An explicit
`revision_ref` selects a committed historical revision in this session. Use the
last history entry's `previous_revision` to read an earlier page.

Read the actual human requests from the existing conversation history index
and its linked message JSON files. Entries labelled `human request` expose the
real message IDs. Select actual IDs; never invent IDs or substitute an
assistant summary for the human commission.

## Create or revise

`planning_update` requires `expected_revision` and a nonempty `reason`.
For `expected_revision`, select the exact current `revision_ref`, or its full
lowercase 64-character hash with optional `.json`. Null is valid only for the
first revision, which must also provide:

- `commission`: `summary`, `source_message_ids`, `observed_through_message_id`.
  Select the human commission and amendments; the observed ID must be the latest
  actual human message, including a follow-up that leaves the goal unchanged.
  The host freezes these messages; do not supply `source_snapshots`.
- `requirements`: at least one item with `id`, `text`, `source_message_ids`,
  `disposition` (`active` or `withdrawn`) and `reason`. Each source must be in
  the commission's source IDs. Preserve the full commission, not only the part
  you are working on now.

Later updates may omit `commission`: the saved commission is kept and the
summary notes any newer human message it has not yet reconciled. A supplied
commission is rejected unless it observes the latest actual human message.

`requirements` upsert complete items by ID; omitted items are kept. Never delete
or reuse an ID: set `disposition` to `withdrawn` with a reason instead. Keep and
append commission source IDs.

IDs use 1–64 ASCII letters, digits, underscores or hyphens. General text is at
most 4096 characters; the commission summary is at most 2000. Capacity is 128
requirements. These are storage limits, never targets.

Use planning tools for official changes, not Write/Edit/Bash on plan storage.
A plan saved in the removed Frame/Node format (schema_version 1) is not read;
start a new plan with `expected_revision: null`.
