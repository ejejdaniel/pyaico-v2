"""Owner-scoped immutable goal records (commission and requirements) with locked head commits."""

from __future__ import annotations

import copy
import os
import re
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from opencode.permission import PermissionRejected
from opencode.store import latest_human_message
from opencode.tools.util import _abort_event, ensure_access

from . import contracts as c


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _upsert(existing, changes):
    replacements = {item["id"]: item for item in changes}
    result = [replacements.pop(item["id"], item) for item in existing]
    return result + list(replacements.values())


class PlanningStore:
    def __init__(self, ctx, *, check_access=None):
        self.ctx = ctx
        self.root = Path(ctx.directory).resolve()
        self.owner = c.identifier(ctx.session_id, "owner session id")
        self.prefix = f".opencode/planning/{self.owner}"
        self.folder = self.root / self.prefix
        self.head = self.folder / "head.json"
        self.check_access = check_access or (lambda path, permission: ensure_access(ctx, path, permission))

    def _abort(self):
        event = _abort_event(self.ctx)
        if event is not None and event.is_set():
            raise PermissionRejected("Execution stopped")

    def _access(self, path, permission):
        self._abort()
        self.check_access(path, permission)
        self._abort()

    def _inside_root(self, path):
        resolved = path.resolve()
        if not resolved.is_relative_to(self.root):
            raise ValueError("Planning path escapes the current workspace")
        return resolved

    def _managed(self, ref, category=None):
        c.text(ref, "planning reference")
        path = self.root / ref
        resolved = self._inside_root(path)
        if not resolved.is_relative_to(self.folder) or resolved.as_posix() != path.as_posix():
            raise ValueError("Planning reference is not a canonical path for this owner")
        if ref != resolved.relative_to(self.root).as_posix():
            raise ValueError("Planning reference must be an exact workspace-relative path")
        if category:
            suffix = ".json" if category == "revisions" else ""
            if path.parent != self.folder / category or (suffix and path.suffix != suffix):
                raise ValueError("Invalid planning reference category")
            c.sha256(path.name[:-len(suffix)] if suffix else path.name)
        return resolved

    def _expected_revision(self, value, *, field, allow_none=False) -> str | None:
        """Resolve only an explicitly selected complete revision identity."""
        if allow_none and (value is None or (isinstance(value, str) and value.strip().lower() in ("null", "none"))):
            # The text 'null' can be no path or hash; runs (2026-10-31, 2026-11-01) sent it for the first plan.
            return None
        ref = value
        if isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}(?:\.json)?", value):
            ref = f"{self.prefix}/revisions/{value.removesuffix('.json')}.json"
        try:
            self._managed(ref, "revisions")
        except ValueError as exc:
            # LIT 2026-10-31 sent the text 'null' for the first plan; told only of paths and hashes, it spent
            # a dozen calls guessing hashes of the head file.
            first = (" If planning_read shows revision_ref null, no plan has been saved yet: pass JSON null "
                     "itself (not the text 'null', a path or a hash) to save the first one.") if allow_none else ""
            # No file path in the advice: a run (2026-11-01) passed the head file's path, given here "to read".
            raise ValueError(
                f"{field} received {value!r}: {exc}. Expected this owner's canonical revision path, "
                "a complete 64-character lowercase SHA-256, or that hash followed by .json." + first +
                " planning_read(view=\"full\") shows the current revision_ref; pass that."
            ) from exc
        return ref

    def _expect_head(self, original, resolved, head, *, field) -> None:
        """Compare an explicit identity with an already authorized head read."""
        if resolved != head and head is None:
            raise ValueError(
                f"{field} does not match the head: received {original!r}, but no plan has been saved yet, so there "
                f"is no revision to expect. Pass {field} as JSON null itself (not a text, a path or a hash) to save "
                "the first revision."
            )
        if resolved != head:
            raise ValueError(
                f"{field} does not match the head: received {original!r}, resolved to {resolved!r}, current head {head!r}. "
                "planning_read(view=\"full\") shows the current revision_ref; pass that."
            )

    def _messages(self):
        # Message sources use the existing session-scoped store interface, not
        # file access to the whole Common database (which may be outside cwd).
        self._abort()
        return self.ctx.app.store.messages(self.owner)

    def latest_human_id(self):
        message = latest_human_message(self._messages())
        return message["id"] if message is not None else None

    def _message(self, message_id, *, human=False):
        message = next((item for item in self._messages() if item.get("id") == message_id), None)
        if message is None or message.get("sessionID") != self.owner:
            index = self.ctx.app.store._receipt_index_path(self.owner, "history", "conversation")
            raise ValueError(
                "Source message does not belong to this owner session. A session ID is not a message ID.\n"
                f"Owner conversation index: {index.as_posix()}\n"
                "Use the ordinary read tool to inspect this index. For commission sources, read entries "
                "labelled 'human request' and their linked original message JSON before explicitly selecting "
                "message IDs. Other message sources may include actual tool observations from this owner's "
                "tool/source history.")
        if human and latest_human_message([message]) is None:
            raise ValueError("Commission sources must be nonsynthetic human messages")
        return message

    def _read_bytes(self, path, maximum):
        self._access(path, "read")
        with path.open("rb") as stream:
            raw = stream.read(maximum + 1)
        if len(raw) > maximum:
            raise ValueError("Planning content exceeds its byte capacity")
        self._abort()
        return raw

    def _read_json(self, ref, category, maximum):
        path = self._managed(ref, category)
        raw = self._read_bytes(path, maximum)
        expected = path.stem if category != "blobs" else path.name
        if c.digest(raw) != expected:
            raise ValueError(f"Planning content hash mismatch: {ref}")
        value = c.strict_json(raw)
        if c.canonical_bytes(value) != raw:
            raise ValueError("Planning JSON is not in its canonical encoding")
        return value

    def _head_ref(self):
        path = self._managed(f"{self.prefix}/head.json")
        self._access(path, "read")
        if not path.exists():
            return None
        raw = self._read_bytes(path, c.MAX_REVISION_BYTES)
        value = c.obj(c.strict_json(raw), {"schema_version", "revision_ref"}, label="head")
        c.version(value["schema_version"])
        self._managed(value["revision_ref"], "revisions")
        if c.canonical_bytes(value) != raw:
            raise ValueError("Head JSON is not in its canonical encoding")
        return value["revision_ref"]

    def _check_snapshot(self, item, *, human=False, checked=None):
        c.snapshot(item)
        key = (item["kind"], item["source"], item["sha256"], human)
        if checked is not None and key in checked:
            if checked[key] != item:
                raise ValueError("Conflicting Snapshot metadata")
            return
        path = self._managed(item["snapshot_path"], "blobs")
        if path.name != item["sha256"]:
            raise ValueError("Snapshot path and hash disagree")
        raw = self._read_bytes(path, c.MAX_SOURCE_BYTES)
        if len(raw) != item["bytes"] or c.digest(raw) != item["sha256"]:
            raise ValueError("Snapshot bytes/hash mismatch")
        message = c.strict_json(raw)
        if (not isinstance(message, dict) or message.get("id") != item["source"]
                or message.get("sessionID") != self.owner or c.canonical_bytes(message) != raw):
            raise ValueError("Message snapshot provenance is invalid")
        if human and latest_human_message([message]) is None:
            raise ValueError("Commission snapshot is not a nonsynthetic human message")
        if checked is not None:
            checked[key] = item

    def _transition(self, previous, current):
        if current["revision"] != previous["revision"] + 1:
            raise ValueError("Revision sequence is broken")
        old, new = previous["state"], current["state"]
        old_sources = old["commission"]["source_message_ids"]
        if new["commission"]["source_message_ids"][:len(old_sources)] != old_sources:
            raise ValueError("Commission source history was removed or reordered")
        old_snapshots = {item["source"]: item for item in old["commission"]["source_snapshots"]}
        for item in new["commission"]["source_snapshots"]:
            if item["source"] in old_snapshots and item != old_snapshots[item["source"]]:
                raise ValueError("Frozen commission provenance was rewritten")
        if not {item["id"] for item in old["requirements"]} <= {item["id"] for item in new["requirements"]}:
            raise ValueError("Existing requirement identities were removed; withdraw them instead")
        if new == old:
            raise ValueError("An update revision must contain a state change")

    def _load(self):
        head = self._head_ref()
        result = {"head": head, "order": [], "revisions": {}}
        ref = head
        while ref is not None:
            if ref in result["revisions"]:
                raise ValueError("Revision history contains a cycle")
            revision = self._read_json(ref, "revisions", c.MAX_REVISION_BYTES)
            c.revision(revision, self.owner)
            result["revisions"][ref] = revision
            result["order"].append(ref)
            ref = revision["previous_revision"]
        checked = {}
        for index, ref in enumerate(reversed(result["order"])):
            revision = result["revisions"][ref]
            if index == 0:
                if revision["revision"] != 1:
                    raise ValueError("Initial revision is invalid")
            else:
                self._transition(result["revisions"][revision["previous_revision"]], revision)
            for item in revision["state"]["commission"]["source_snapshots"]:
                self._check_snapshot(item, human=True, checked=checked)
        return result

    @contextmanager
    def _locked(self):
        folder = self._managed(self.prefix)
        lock_path = self._managed(f"{self.prefix}/.lock")
        self._access(folder, "edit")
        self._access(lock_path, "edit")
        self._access(lock_path, "read")
        folder.mkdir(parents=True, exist_ok=True)
        try:
            stream = lock_path.open("x+b")
        except FileExistsError:
            stream = lock_path.open("r+b")
        acquired = False
        try:
            if os.name == "nt":
                import msvcrt
                try:
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError as exc:
                    raise RuntimeError("Planning owner is already being modified") from exc
            else:
                import fcntl
                try:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError as exc:
                    raise RuntimeError("Planning owner is already being modified") from exc
            acquired = True
            stream.seek(0)
            raw = stream.read(2)
            if raw == b"":
                stream.seek(0)
                stream.write(b"\0")
                stream.flush()
                os.fsync(stream.fileno())
            elif raw != b"\0":
                raise ValueError("Planning lock must contain one zero byte")
            self._abort()
            yield
        finally:
            if acquired:
                if os.name == "nt":
                    import msvcrt
                    stream.seek(0)
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            stream.close()

    def _freeze_message(self, message_id, pending, new_sources):
        raw = c.canonical_bytes(self._message(message_id, human=True))
        if len(raw) > c.MAX_SOURCE_BYTES:
            raise ValueError("Message source exceeds 1 MiB")
        digest = c.digest(raw)
        item = {"kind": "message", "source": message_id, "snapshot_path": f"{self.prefix}/blobs/{digest}",
                "sha256": digest, "bytes": len(raw)}
        new_sources[message_id] = len(raw)
        if sum(new_sources.values()) > c.MAX_CALL_SOURCE_BYTES:
            raise ValueError("New source snapshots exceed 8 MiB for this call")
        pending[item["snapshot_path"]] = raw
        return item

    def _freeze_commission(self, value, history, pending, new_sources):
        c.commission(value)
        existing = {}
        if history["head"]:
            existing = {item["source"]: item for item in
                        history["revisions"][history["head"]]["state"]["commission"]["source_snapshots"]}
        result = copy.deepcopy(value)
        result["source_snapshots"] = []
        for message_id in dict.fromkeys([*value["source_message_ids"], value["observed_through_message_id"]]):
            # Previously frozen human provenance is immutable even if conversation metadata changes.
            if message_id in existing:
                item = existing[message_id]
            else:
                item = self._freeze_message(message_id, pending, new_sources)
            result["source_snapshots"].append(item)
        c.commission(result, saved=True)
        return result

    def _immutable(self, ref, raw, maximum):
        if len(raw) > maximum:
            raise ValueError("Planning record exceeds byte capacity")
        path = self._managed(ref)
        self._access(path.parent, "edit")
        self._access(path, "edit")
        self._access(path, "read")
        path.parent.mkdir(parents=True, exist_ok=True)
        self._abort()
        try:
            with path.open("xb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
        except FileExistsError:
            pass
        restored = self._read_bytes(path, maximum)
        if restored != raw or c.digest(restored) != path.stem:
            raise ValueError("Immutable planning content collision or incomplete write")

    def _commit(self, revision, history, pending, *, expected_revision, field, require_latest=False):
        c.revision(revision, self.owner)
        raw = c.canonical_bytes(revision)
        if len(raw) > c.MAX_REVISION_BYTES:
            raise ValueError("Revision exceeds 1 MiB")
        ref = f"{self.prefix}/revisions/{c.digest(raw)}.json"
        for blob_ref, content in pending.items():
            self._immutable(blob_ref, content, c.MAX_SOURCE_BYTES)
        self._immutable(ref, raw, c.MAX_REVISION_BYTES)
        restored = self._read_json(ref, "revisions", c.MAX_REVISION_BYTES)
        c.revision(restored, self.owner)
        if history["head"]:
            self._transition(history["revisions"][history["head"]], restored)
        self._access(self.head, "edit")
        # A same-directory temporary file makes the final head replacement atomic.
        temporary = self.folder / (".head-" + os.urandom(12).hex() + ".tmp")
        self._access(temporary, "edit")
        try:
            with temporary.open("xb") as stream:
                stream.write(c.canonical_bytes({"schema_version": c.SCHEMA_VERSION, "revision_ref": ref}))
                stream.flush()
                os.fsync(stream.fileno())
            self._expect_head(expected_revision, history["head"], self._head_ref(), field=field)
            if require_latest:
                self._require_latest(revision["state"])
            self._abort()
            os.replace(temporary, self.head)
        finally:
            if temporary.exists():
                temporary.unlink()
        return ref

    def _require_latest(self, state):
        # Only a commission supplied in this call claims a new reconciliation,
        # so only that claim must name the latest actual human message. Updates
        # that omit commission keep the earlier claim and receive a notice.
        observed, latest = state["commission"]["observed_through_message_id"], self.latest_human_id()
        if observed != latest:
            raise ValueError(
                "A supplied commission must observe the latest human message. "
                f"commission.observed_through_message_id is {observed}; the latest actual human message is {latest}. "
                "Read that message, then resubmit commission with observed_through_message_id set to it "
                "(adding it to source_message_ids if it governs the work), or omit commission to keep the "
                "previous reconciliation; the receipt will then note the unreconciled message.")

    def _notices(self, state):
        if self.latest_human_id() != state["commission"]["observed_through_message_id"]:
            return ["新訊息尚未由規劃修訂對照；不表示它必然改變目標。"]
        return []

    def _response(self, history, ref, *, view="full"):
        result = {"revision_ref": ref, "snapshot": None, "history": [], "summary": "", "notices": []}
        if ref is None:
            return result
        revision = history["revisions"][ref]
        result["notices"] = self._notices(revision["state"])
        if view == "full":
            result["snapshot"] = revision
        elif view == "history":
            current = ref
            while current is not None and len(result["history"]) < 20:
                item = history["revisions"][current]
                result["history"].append({"revision_ref": current, **{key: item[key] for key in
                                           ("revision", "previous_revision", "created_at", "reason")}})
                current = item["previous_revision"]
        return copy.deepcopy(result)

    def read(self, args):
        c.obj(args, set(), {"view", "revision_ref"}, label="planning_read")
        view = args.get("view", "summary")
        c.enum(view, {"summary", "full", "history"}, "view")
        if "revision_ref" in args:
            self._managed(args["revision_ref"], "revisions")
        history = self._load()
        ref = args.get("revision_ref", history["head"])
        if ref is None:
            return self._response(history, None)
        if ref not in history["revisions"]:
            raise ValueError("Selected revision is not in this owner's committed history")
        return self._response(history, ref, view=view)

    def update(self, args):
        optional = {"commission", "requirements"}
        c.obj(args, {"expected_revision", "reason"}, optional, label="planning_update")
        c.text(args["reason"], "reason")
        if not optional.intersection(args):
            raise ValueError("planning_update requires commission or requirements")
        field = "planning_update.expected_revision"
        expected = self._expected_revision(args["expected_revision"], field=field, allow_none=True)
        if "commission" in args:
            c.commission(args["commission"])
        if "requirements" in args:
            c.array(args["requirements"], "requirements", 128)
            for item in args["requirements"]:
                c.requirement(item)
            c.unique([item["id"] for item in args["requirements"]], "requirements id")
        with self._locked():
            history = self._load()
            self._expect_head(args["expected_revision"], expected, history["head"], field=field)
            previous = history["revisions"].get(history["head"])
            if previous is None and ("commission" not in args or not args.get("requirements")):
                raise ValueError("Initial update requires commission and nonempty requirements")
            state = copy.deepcopy(previous["state"] if previous else {"commission": {}, "requirements": []})
            pending, new_sources = {}, {}
            if "commission" in args:
                state["commission"] = self._freeze_commission(args["commission"], history, pending, new_sources)
            state["requirements"] = _upsert(state["requirements"], copy.deepcopy(args.get("requirements", [])))
            c.state(state)
            supplied = "commission" in args
            if supplied:
                self._require_latest(state)
            if previous and state == previous["state"]:
                response = self._response(history, history["head"])
                response["notices"].append("no-change：狀態未變更，保留原版本；不代表新增進展。")
                return response
            revision = {"schema_version": c.SCHEMA_VERSION, "owner_session_id": self.owner,
                        "revision": previous["revision"] + 1 if previous else 1,
                        "previous_revision": history["head"], "created_at": _now(),
                        "reason": args["reason"], "state": state}
            if previous:
                self._transition(previous, revision)
            ref = self._commit(revision, history, pending, expected_revision=args["expected_revision"],
                               field=field, require_latest=supplied)
            return self._response(self._load(), ref)
