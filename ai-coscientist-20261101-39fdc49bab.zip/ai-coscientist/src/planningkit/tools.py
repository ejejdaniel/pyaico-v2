"""Optional goal-layer planning tools; authorization stays in Common's Broker."""

from __future__ import annotations

import json

from opencode.tools.types import Tool, ToolResult, schema
from opencode.tools.util import _abort_event
from planningkit.projection import fill_summary
from planningkit.storage import PlanningStore
from planningkit.turn import TURN_EXTENSION


def _text(maximum=4096):
    return {"type": "string", "minLength": 1, "maxLength": maximum, "pattern": r"\S"}


ID = {"type": "string", "pattern": "^[A-Za-z0-9_-]{1,64}$"}
TEXT = _text()
REFERENCE = _text()


def _array(items, maximum, minimum=0, unique=False):
    value = {"type": "array", "items": items, "minItems": minimum, "maxItems": maximum}
    if unique:
        value["uniqueItems"] = True
    return value


COMMISSION = schema({"summary": _text(2000), "source_message_ids": _array(REFERENCE, 32, 1, True),
                     "observed_through_message_id": REFERENCE},
                    ["summary", "source_message_ids", "observed_through_message_id"])
REQUIREMENT = schema({"id": ID, "text": TEXT, "source_message_ids": _array(REFERENCE, 32, 1, True),
                      "disposition": {"enum": ["active", "withdrawn"]}, "reason": TEXT},
                     ["id", "text", "source_message_ids", "disposition", "reason"])

READ_SCHEMA = schema({"view": {"type": "string", "enum": ["summary", "full", "history"], "default": "summary"},
                      "revision_ref": REFERENCE}, [])
UPDATE_SCHEMA = schema({"expected_revision": {"anyOf": [REFERENCE, {"type": "null"}],
                                             "description": "Exact current revision: this owner's canonical workspace-relative revision path, "
                                             "a complete 64-character lowercase SHA-256, or that hash followed by .json. "
                                             "null is accepted only when creating the first revision."}, "reason": TEXT,
                        "commission": COMMISSION, "requirements": _array(REQUIREMENT, 128)},
                       ["expected_revision", "reason"])
UPDATE_SCHEMA["anyOf"] = [{"required": [key]} for key in ("commission", "requirements")]


def _execute(operation, args, ctx):
    name = "planning_" + operation
    ctx.app.permissions.ask(session_id=ctx.session_id, permission=name, patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={},
                            abort_event=_abort_event(ctx))
    store = PlanningStore(ctx)
    response = fill_summary(store, getattr(store, operation)(args))
    # Common performs receipt truncation and retains the complete readable output.
    return ToolResult(title=name, output=json.dumps(response, ensure_ascii=False, indent=2, allow_nan=False))


def _read(args, ctx):
    return _execute("read", args, ctx)


def _update(args, ctx):
    return _execute("update", args, ctx)


TOOLS = [
    Tool("planning_read", "Read this session's exact saved goal revision (commission and requirements) or its history. "
         "No plan is required for ordinary work. summary is a bounded preview; full preserves all fields. "
         "Select real human message IDs from the existing conversation history index when first planning.", READ_SCHEMA, _read),
    Tool("planning_update", "Save an explicit revision of what the human asked for: a commission summary bound to "
         "exact human message IDs, and requirements each traced to those messages. Withdraw a requirement instead "
         "of deleting it. Use it when a multi-part commission starts, so the goal survives long work and "
         "compaction, and again when a new human message changes, adds or withdraws a goal; omit commission to "
         "edit requirements only. Use the exact expected_revision receipt. This records goals; it does not schedule "
         "or restrict actions.", UPDATE_SCHEMA, _update),
]
