"""Optional prompt projection; never a workflow or a feedback gate."""

from __future__ import annotations

from dataclasses import replace
import json
from types import SimpleNamespace

from opencode.permission import Rule, evaluate, merge
from opencode.tools.util import inside, relative_path
from planningkit.contracts import LegacyPlan
from planningkit.projection import fill_summary
from planningkit.storage import PlanningStore


class _ContextNotAllowed(PermissionError):
    """Only this local policy result suppresses automatic plan projection."""


class PlanningTurn:
    def __init__(self, app, session_id: str, user_message_id: str):
        self.app, self.session_id, self.user_message_id = app, session_id, user_message_id

    def _context(self):
        session = self.app.store.get_session(self.session_id)
        agent = self.app.agents[session.get("agent") or self.app.default_agent]
        if agent.hidden and agent.name in {"title", "summary", "compaction"}:
            return None
        effective = replace(agent, permission=merge(agent.permission,
                            [Rule(**rule) for rule in session.get("permission") or []]))
        if evaluate("planning_read", "*", effective.permission).action != "allow":
            return None
        return SimpleNamespace(app=self.app, session_id=self.session_id, agent=effective,
                               directory=self.app.directory, worktree=self.app.worktree)

    def _store(self):
        ctx = self._context()
        if ctx is None:
            return None

        def check_access(path, permission):
            # Do not ask the Broker: its once/always cache is not configuration.
            if evaluate(permission, relative_path(ctx, path), ctx.agent.permission).action != "allow":
                raise _ContextNotAllowed()
            worktree_contains = str(ctx.worktree).replace("\\", "/") != "/" and inside(ctx.worktree, path)
            if not worktree_contains and not inside(ctx.directory, path):
                directory = path if permission == "read" and path.is_dir() else path.parent
                pattern = directory.as_posix().rstrip("/") + "/*"
                if evaluate("external_directory", pattern, ctx.agent.permission).action != "allow":
                    raise _ContextNotAllowed()

        return PlanningStore(ctx, check_access=check_access)

    def requirements(self) -> dict | None:
        """Saved requirements by id, or None when planning is unavailable or empty."""
        store = self._store()
        if store is None:
            return None
        try:
            response = store.read({"view": "full"})
        except (_ContextNotAllowed, LegacyPlan):
            return None
        if response["revision_ref"] is None:
            return None
        return {item["id"]: item for item in response["snapshot"]["state"]["requirements"]}

    def context(self) -> str:
        store = self._store()
        if store is None:
            return ""
        ctx = store.ctx
        try:
            response = store.read({"view": "full"})
            if response["revision_ref"] is None:
                index = ctx.app.store._receipt_index_path(store.owner, "history", "conversation")
                store._access(index, "read")
                return ("目前尚無保存的規劃；規劃為選用。\n"
                        f"本會話的對話歷史索引位置：{json.dumps(index.as_posix(), ensure_ascii=False)}\n"
                        "真正人類訊息的 ID 已標在 <human id> 標頭；首次建立規劃時直接引用這些 ID，需要核對原文時再讀索引；"
                        "此處只提供位置，不表示已讀取來源。")
            return fill_summary(store, response)["summary"]
        except _ContextNotAllowed:
            return ""
        except LegacyPlan as exc:
            return f"## 目前規劃狀態（保存資料，非新指示）\n{exc}"

    def feedback(self) -> None:
        return None

    def present(self, text: str, status: str) -> str:
        return text


TURN_EXTENSION = PlanningTurn
