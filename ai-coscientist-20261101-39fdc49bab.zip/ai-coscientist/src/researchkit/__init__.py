"""Optional scientific tools and file-backed guidance, independent of agent control."""
