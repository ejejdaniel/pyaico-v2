"""Scale check and declared anchoring for proxies that predict a measured quantity.

A proxy declared `direction: target` ranks by distance to the target value, which only
means something when its predictions sit on the measured scale. The host compares the
proxy's predictions for historical samples with their measurements (offset, residuals,
order agreement). When the formula declares an anchor, the host shifts candidate
predictions by the estimated offset and ranks baselines by their measurements.

Anchoring trusts the predicted differences and corrects only the absolute level. It
cannot repair a wrong slope, which shows as spread or sign changes in the residuals,
and it is never validation.
"""

from __future__ import annotations

import itertools
import statistics

ANCHOR_MODES = ("none", "mean_offset", "reference_sample")


def anchor_mode(anchor) -> tuple[str, str | None]:
    """('none'|'mean_offset'|'reference_sample', reference id or None) from a declaration."""
    if anchor in (None, "none"):
        return "none", None
    if anchor == "mean_offset":
        return "mean_offset", None
    if isinstance(anchor, dict) and set(anchor) == {"reference_sample"} and isinstance(anchor["reference_sample"], str):
        return "reference_sample", anchor["reference_sample"]
    raise ValueError('anchor must be "none", "mean_offset" or {"reference_sample": "<baseline id>"}')


def apply(raw: dict, measured: dict, baseline_ids: list, candidate_ids: list, anchor=None):
    """(values used for ranking, scale check) for one sheet."""
    mode, reference = anchor_mode(anchor)
    compared = [b for b in baseline_ids if b in measured]
    check = {"anchor": mode if mode != "reference_sample" else {"reference_sample": reference},
             "compared_baselines": compared, "anchored": False}
    if not compared:
        check["status"] = "no measured values for the baselines; the scale cannot be checked"
        return dict(raw), check
    residuals = {b: raw[b] - measured[b] for b in compared}
    check["measured"] = {b: measured[b] for b in compared}
    check["predicted"] = {b: raw[b] for b in compared}
    check["residuals"] = residuals
    check["mean_offset"] = statistics.fmean(residuals.values())
    check["residual_spread"] = max(residuals.values()) - min(residuals.values())
    pairs = list(itertools.combinations(compared, 2))
    disagreements = [[a, b] for a, b in pairs
                     if (raw[a] - raw[b]) * (measured[a] - measured[b]) < 0]
    check["order_agreement"] = f"{len(pairs) - len(disagreements)}/{len(pairs)}" if pairs else "n/a"
    if disagreements:
        check["order_disagreements"] = disagreements
    if mode == "none":
        return dict(raw), check
    if mode == "mean_offset" and len(compared) < 2:
        check["status"] = ("anchoring refused: mean_offset needs at least two measured baselines "
                           "(one cannot show whether the error is a constant offset); use reference_sample")
        return dict(raw), check
    if mode == "reference_sample" and reference not in compared:
        check["status"] = f"anchoring refused: reference sample {reference!r} has no measured value"
        return dict(raw), check
    offset = check["mean_offset"] if mode == "mean_offset" else residuals[reference]
    used = {}
    for sample in [*baseline_ids, *candidate_ids]:
        # Baselines rank by what was measured; others by the shifted prediction.
        used[sample] = measured[sample] if sample in compared else raw[sample] - offset
    check.update(anchored=True, offset_applied=offset,
                 residuals_after={b: raw[b] - offset - measured[b] for b in compared},
                 note="Baselines ranked by their measured values; candidates by prediction minus the offset. "
                      "Anchoring corrects the level only; residual spread and order disagreements show slope "
                      "error it cannot fix. This is not validation.")
    return used, check


def shifted(raw: dict, check: dict) -> dict:
    """The formula's own predictions on the scale its candidates are ranked on.

    The order on the historical samples is checked on these. Ranking puts anchored baselines at
    their measured values, which would make any order agree; the raw values may sit far from a
    target. v41's P1 was about 48 below its target of 40 before its anchor and 9 to 12 above it
    after: the raw values reversed the history, the anchored ones agreed with it.
    """
    if not check.get("anchored"):
        return dict(raw)
    return {sample: value - check["offset_applied"] for sample, value in raw.items()}
