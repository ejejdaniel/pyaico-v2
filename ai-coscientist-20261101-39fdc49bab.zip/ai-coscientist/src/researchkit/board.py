"""Read-only research board derived from saved records and human messages.

Everything here is recomputed from immutable records on every call. It lists
saved facts and mechanical consistency notices; it never judges scientific
support, picks a winner or edits a record.
"""

from __future__ import annotations

from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re

from researchkit import graph, records
from researchkit.knowledge import tables
from researchkit.report_evidence import resolve
from researchkit.scoring import DIRECTIONS, MECHANISM, check_direction, orient


TITLE = "## 研究看板（宿主由已保存紀錄現算，不是新指示）"
MAX_CONTEXT_BYTES = 6000
HYPOTHESES_FILE = "hypotheses.json"
PROXY_FILE = "proxy_formula.json"
CALIBRATION_FILE = "calibration.json"
EVOLUTION_FILE = "evolution.json"
SMALL_SAMPLE = 2
# Active hypotheses (neither deferred nor not computable) beyond this each cost a full
# formula -> implementation -> leaderboard -> review path; research.hypothesis_budget overrides it.
HYPOTHESIS_BUDGET = 3
SURPASS = ("robust_surpass", "surpass_one_sheet", "tradeoff_surpass")
EVIDENCE_LABEL = {"history": "有歷史差異", "history_reversed": "與歷史 KPI 順序相反", "mechanism_only": "歷史同分，僅機制",
                  "llm_judge": "LLM 評審"}
SMALL_MARGIN = 0.1  # a surpass smaller than this share of the primary sheet's pool range
EFFECTS = {"supports", "contradicts", "uninformative"}
# A target with an optimum (|x - a|, min/max, squares) is not monotone in its input.
NON_MONOTONE = re.compile(r"\babs\s*\(|\bmin\s*\(|\bmax\s*\(|\*\*\s*2|\^\s*2|\|")
# A score written as minus a distance: larger is closer to the target, so its direction is higher.
NEGATED_DISTANCE = re.compile(r"[-−]\s*abs\s*\(")


class Notices(list):
    """Mechanical notices with a level, an optional merge group and a stable id.

    "action" notices point at something likely wrong or unverifiable; "info"
    notices state a caveat or the current state of the work. Plain append()
    keeps the action level, so existing call sites stay correct by default.
    """

    def __init__(self):
        super().__init__()
        self.items = []
        self._subject = None

    @contextmanager
    def about(self, record_path):
        """Notices added inside are about this record: they go when a later version replaces it."""
        previous, self._subject = self._subject, record_path
        try:
            yield
        finally:
            self._subject = previous

    def add(self, text, *, level="action", group=None, ref=None, key=None):
        """key names what the notice is about when its wording can change as work is added."""
        self.items.append({"text": text, "level": level, "group": group, "ref": ref, "key": key or text,
                           "subject": self._subject})
        super().append(text)

    def append(self, text):
        self.add(text)

    def finalize(self, replies=None, replaced=()):
        """Merge repeats, give each notice an id, and attach the author's replies.

        A notice about a record that a later version replaces is dropped: a saved record cannot
        change, so only the newer version can answer it, and that version gets its own notices.
        """
        replies = replies or {}
        merged, seen = [], set()
        groups = {}
        for item in self.items:
            if item["subject"] is not None and item["subject"] in replaced:
                continue
            if item["group"]:
                groups.setdefault(item["group"], []).append(item)
                continue
            if item["key"] not in seen:
                seen.add(item["key"])
                merged.append({key: value for key, value in item.items() if key != "subject"})
        for group, items in groups.items():
            if group == "small_sample":
                refs = list(dict.fromkeys(_short(i["ref"]) for i in items))
                text = (f"calibration {'、'.join(refs)} 只有 {SMALL_SAMPLE} 筆樣本：任何方向正確的公式都會得到 ±1，"
                        "排列檢定的 p 值最小也是 1（雙尾），這些分數無法區分公式好壞。")
            else:
                text = items[0]["text"]
            merged.append({"text": text, "level": items[0]["level"], "group": group, "ref": None,
                           "key": f"group:{group}"})
        for item in merged:
            # The id follows the subject, not the wording, so a reply survives later detail changes.
            item["id"] = "N" + hashlib.sha256(item.pop("key").encode("utf-8")).hexdigest()[:6]
            item["reply"] = replies.get(item["id"])
        order = {"action": 0, "info": 1}
        merged.sort(key=lambda item: (item["reply"] is not None, order[item["level"]]))
        return merged


def open_actions(board):
    """Action notices the author has not answered."""
    return [item for item in board.get("notice_items", []) if item["level"] == "action" and not item["reply"]]


def _preview(value, limit=160):
    text = " ".join(str(value).split())
    return text if len(text) <= limit else text[:limit] + "…（已截斷）"


def _short(ref):
    # .research/records/<64 hex>/record.json -> first 8 hex, enough to tell rows apart.
    parts = ref.split("/")
    return parts[2][:8] if len(parts) == 4 else ref


def _human_messages(history):
    rows = []
    for message in history or []:
        if message.get("role") != "user" or message.get("synthetic") or message.get("compaction_through"):
            continue
        content = message.get("content")
        rows.append({"id": message.get("id"),
                     "text": content if isinstance(content, str) else json.dumps(content, ensure_ascii=False)})
    return rows


def _read_json(root, record, name, check_read, notices):
    """Exact frozen bytes of one named template file, or None when absent."""
    matches = [item for item in record["files"] if Path(item["source_path"]).name == name]
    if not matches:
        return None
    if len(matches) > 1:
        notices.append(f"{record['kind']} {_short(record['record_path'])} 含多個 {name}，看板未採用。")
        return None
    try:
        frozen, = resolve(root, [{"record_ref": record["record_path"], "source_path": matches[0]["source_path"]}],
                          check_read=check_read)
        return json.loads(frozen["text"])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        notices.append(f"{record['kind']} {_short(record['record_path'])} 的 {name} 無法讀成 JSON：{_preview(exc)}")
        return None


HYPOTHESES_SHAPE = '{"hypotheses": [{"id": "H1", "statement": "...", ...}]}'


EVOLUTION_SHAPE = ('{"ranking_rule": "...", "rounds": [{"round": 1, "candidate_ids": [...], "leaderboard_ref": '
                   '"<record.json>", "strategy": "explore|exploit", "levers": [...], "reason": "..."}], '
                   '"stop_reason": "...", "claims_surpass": true|false}')


def comparison_sets(value):
    """(host_compared, better): the host's comparison and leaderboard records, and those of them in which a
    candidate is ahead of the best baseline."""
    better = {row["ref"] for row in value["comparisons"] if row["comparison"] == "better"}
    better |= {row["ref"] for row in value["leaderboards"]
               if any(c["verdict"] in (*SURPASS, "conditional_surpass") for c in row["candidates"])}
    host_compared = {row["ref"] for row in value["comparisons"]} | {row["ref"] for row in value["leaderboards"]}
    return host_compared, better


def _ahead(value, ref, candidates):
    """Whether the host comparison ref shows one of these candidates ahead of the best baseline."""
    for row in value["leaderboards"]:
        if row["ref"] == ref and any(c.get("id") in candidates and c.get("verdict") in (*SURPASS, "conditional_surpass")
                                     for c in row["candidates"] or []):
            return True
    for row in value["comparisons"]:
        best = row["best_candidate"]
        ids = best.get("ids") if isinstance(best, dict) else [best]
        if row["ref"] == ref and row["comparison"] == "better" and set(ids or []) & set(candidates):
            return True
    return False


def evolution_problems(declaration, value):
    """Everything an evolution declaration lacks for the host to check its rounds and its surpass claim.

    A run (2026-11-01) declared its evolution with fields of its own, no surpass claim and no stop reason,
    and stopped after one round on a surpass that its leaderboard did not show; the board's check of the
    claim never ran, because there was no claim to check. `value` is the built board.
    """
    if not isinstance(declaration, dict):
        return [f"evolution.json must be an object: {EVOLUTION_SHAPE}"]
    host_compared, _ = comparison_sets(value)
    text = lambda item, key: isinstance(item.get(key), str) and item[key].strip()
    problems, cited, candidates = [], [], set()
    rounds = declaration.get("rounds")
    if not isinstance(rounds, list) or not rounds:
        problems.append("rounds must list each round actually run, in order")
        rounds = []
    for number, item in enumerate(rounds, 1):
        if not isinstance(item, dict):
            problems.append(f"rounds[{number}] is not an object")
            continue
        if item.get("round") != number:
            problems.append(f"rounds[{number}] has round {item.get('round')!r}: number the rounds 1, 2, ... in the "
                            "order they ran")
        ids = item.get("candidate_ids")
        if isinstance(ids, list) and ids and all(isinstance(c, str) and c.strip() for c in ids):
            candidates |= set(ids)
        else:
            problems.append(f"round {number} needs candidate_ids: the candidates it generated and scored")
        refs = [item[key] for key in ("leaderboard_ref", "comparison_ref") if text(item, key)]
        if not refs:
            problems.append(f"round {number} needs leaderboard_ref (research_leaderboard) or comparison_ref "
                            "(research_compare_candidates): the host comparison that ranked it")
        for ref in refs:
            if ref in host_compared:
                cited.append(ref)
            else:
                problems.append(f"round {number} cites {ref}, which is not a host comparison: give the record.json "
                                "path research_leaderboard or research_compare_candidates returned")
        if item.get("strategy") not in ("explore", "exploit"):
            problems.append(f"round {number} needs strategy explore or exploit")
        if not text(item, "reason"):
            problems.append(f"round {number} needs reason: what it tried and, after the first round, which earlier "
                            "result it used")
    for key, what in (("ranking_rule", "the rule that orders candidates against the baselines"),
                      ("stop_reason", "why the evolution stopped where it did")):
        if not text(declaration, key):
            problems.append(f"{key} is missing: {what}")
    claims = declaration.get("claims_surpass")
    if not isinstance(claims, bool):
        problems.append("claims_surpass must be true or false: whether a candidate is ahead of the best baseline")
    elif claims and cited and not any(_ahead(value, ref, candidates) for ref in cited):
        problems.append("claims_surpass is true, but no comparison the rounds cite shows one of their candidates "
                        "ahead of the best baseline. Cite the round whose leaderboard or comparison shows it; if none "
                        "does, set claims_surpass false, and the evolution goes on within the round limit the "
                        "commission sets")
    return problems


def hypothesis_problems(value):
    """What keeps a hypotheses.json from being read, naming the keys an item has instead of id or statement.

    v23 wrote hypothesis_id for id; the board said only that an id was missing, and the revision check
    that every earlier id (H1, H2, H3) was missing, so the set was saved four more times.
    """
    items = value.get("hypotheses") if isinstance(value, dict) else None
    if not isinstance(items, list) or not items:
        return [f"hypotheses.json must be {HYPOTHESES_SHAPE}"]
    problems, seen = [], set()
    for number, item in enumerate(items, 1):
        if not isinstance(item, dict):
            problems.append(f"item {number} is not an object")
            continue
        keys = ", ".join(sorted(item)) or "none"
        if not isinstance(item.get("id"), str) or not item["id"].strip():
            near = sorted((key for key in item if key != "id" and key.lower().endswith("id")
                           and isinstance(item[key], str)), key=lambda key: "hyp" not in key.lower())
            problems.append(f"item {number} has no id" + (f" (it has {near[0]}; the key must be id)" if near
                                                            else f"; its keys are {keys}"))
        elif item["id"] in seen:
            problems.append(f"id {item['id']} appears more than once")
        else:
            seen.add(item["id"])
        if not isinstance(item.get("statement"), str) or not item["statement"].strip():
            problems.append(f"item {number} has no statement text; its keys are {keys}")
    return problems


def _hypothesis_items(value, record, notices):
    problems = hypothesis_problems(value)
    if problems:
        notices.append(f"hypothesis {_short(record['record_path'])} 的 {HYPOTHESES_FILE} 看板未採用："
                       + "; ".join(problems[:4]) + f"。格式：{HYPOTHESES_SHAPE}")
        return None
    rows = []
    for item in value["hypotheses"]:
        status = item.get("proxy_status") if isinstance(item.get("proxy_status"), dict) else {}
        kind = status.get("status")
        # The status counts even without a reason; a missing reason is shown, not mistaken for "active".
        reason = status["reason"].strip() if isinstance(status.get("reason"), str) and status["reason"].strip() \
            else "（未寫理由）"
        tried = status.get("tried") if isinstance(status.get("tried"), list) else []
        missing = status.get("missing") if isinstance(status.get("missing"), str) and status["missing"].strip() else None
        levers = item.get("levers") if isinstance(item.get("levers"), list) else []
        rows.append({"id": item["id"], "statement": item["statement"],
                     "not_computable": reason if kind == "not_computable" else None,
                     "deferred": reason if kind == "deferred" else None,
                     "deferred_basis": status.get("basis") if kind == "deferred" else None,
                     "tried": [t for t in tried if isinstance(t, dict) and isinstance(t.get("proxy"), str)
                               and t["proxy"].strip() and isinstance(t.get("why_not"), str) and t["why_not"].strip()],
                     "missing": missing,
                     "merged": (status.get("into") if isinstance(status.get("into"), str) else "（未指明）")
                               if kind == "merged" else None,
                     "levers": [lever for lever in levers if isinstance(lever, str) and lever.strip()]})
    return rows


def _flatten(row, prefix=""):
    flat = {}
    for key, value in row.items():
        name = f"{prefix}{key}"
        if isinstance(value, dict):
            flat.update(_flatten(value, name + "."))
        else:
            flat[name] = value
    return flat


def _comparable(value):
    number = tables.number(value) if isinstance(value, str) else (
        float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None)
    return f"{number:.12g}" if number is not None else json.dumps(value, sort_keys=True, ensure_ascii=False)


def _lever_table(root, value, record, check_read, notices):
    """{column: 'varies'|'constant'} over the rows of the hypotheses' declared lever_table.

    The table holds the historical records (CSV/TSV with a header, or JSON rows keyed by
    sample; nested objects become dotted names). A lever that is constant there cannot be
    calibrated on history; it can still separate new candidates.
    """
    table = value.get("lever_table") if isinstance(value, dict) else None
    if table is None:
        return None
    label = f"hypothesis {_short(record['record_path'])} 的 lever_table"
    if not (isinstance(table, dict) and isinstance(table.get("record_ref"), str)
            and isinstance(table.get("source_path"), str)):
        notices.append(f"{label} 需為 {{\"record_ref\": ..., \"source_path\": ...}}，看板未採用。")
        return None
    try:
        frozen, = resolve(root, [{"record_ref": table["record_ref"], "source_path": table["source_path"]}],
                          check_read=check_read)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        notices.append(f"{label} 無法讀取：{_preview(exc)}")
        return None
    columns = {}
    parsed = tables.read_table({"source_path": table["source_path"], "text": frozen["text"]})
    if parsed:
        header, body = parsed
        for index, name in enumerate(header):
            columns[name] = [_comparable(row[index].strip()) for row in body]
    else:
        try:
            data = json.loads(frozen["text"])
        except ValueError:
            data = None
        rows = list(data.values()) if isinstance(data, dict) else data if isinstance(data, list) else []
        if len(rows) >= 2 and all(isinstance(row, dict) for row in rows):
            flat = [_flatten(row) for row in rows]
            for name in sorted({key for row in flat for key in row}):
                columns[name] = [_comparable(row.get(name)) for row in flat]
    if not columns:
        notices.append(f"{label} 不是至少兩列的 CSV／TSV 或 JSON 列表，看板未採用。")
        return None
    return {name: ("varies" if len(set(values)) > 1 else "constant") for name, values in columns.items()}


def _proxy_template(value, record, notices):
    if (not isinstance(value, dict) or not isinstance(value.get("expression"), str)
            or not isinstance(value.get("hypothesis_ids"), list)
            or not all(isinstance(item, str) and item.strip() for item in value["hypothesis_ids"])):
        notices.append(f"proxy_formula {_short(record['record_path'])} 的 {PROXY_FILE} 需含 expression 與 "
                       "hypothesis_ids 字串陣列，看板未採用。")
        return None
    direction, target_value = value.get("direction"), value.get("target_value")
    if direction is not None:
        try:
            check_direction(direction, target_value)
        except ValueError:
            notices.append(f"proxy_formula {_short(record['record_path'])} 的 {PROXY_FILE} direction 應為 higher、lower，"
                           "或 target 並附數值 target_value，看板未採用此欄位。")
            direction = target_value = None
    target = value.get("target_transform")
    return {"formula_id": value.get("formula_id") if isinstance(value.get("formula_id"), str) else None,
            "expression": value["expression"], "hypothesis_ids": list(dict.fromkeys(value["hypothesis_ids"])),
            "direction": direction, "target_value": target_value if direction == "target" else None,
            "target_transform": target if isinstance(target, str) and target.strip() else None,
            "measured": isinstance(value.get("measured"), dict), "kpi": isinstance(value.get("kpi"), dict),
            "anchor": value.get("anchor") if isinstance(value.get("anchor"), (str, dict)) else None,
            "mechanism_predicts": value.get("mechanism_predicts") if value.get("mechanism_predicts") in MECHANISM
            else None,
            "terms": bool(value.get("terms")) and isinstance(value.get("terms"), list),
            "kpi_better": value["kpi"].get("better") if isinstance(value.get("kpi"), dict) else None}


MECHANISM_TEXT = {"kpi_rises": "機制：公式值升高、KPI 升高", "kpi_falls": "機制：公式值升高、KPI 下降"}


def _calibration_template(value, record, notices):
    """calibration.json: the author's link to a formula and per-hypothesis judgments."""
    if not isinstance(value, dict) or not isinstance(value.get("judgments", []), list):
        notices.append(f"calibration {_short(record['record_path'])} 的 {CALIBRATION_FILE} 需為物件，"
                       "judgments 為陣列，看板未採用。")
        return None
    judgments = []
    for item in value.get("judgments", []):
        if (not isinstance(item, dict) or not isinstance(item.get("hypothesis_id"), str)
                or item.get("effect") not in EFFECTS or not isinstance(item.get("reason"), str)):
            notices.append(f"calibration {_short(record['record_path'])} 的 {CALIBRATION_FILE} judgments 每項需含 "
                           "hypothesis_id、effect（supports／contradicts／uninformative）、reason，看板未採用。")
            return None
        judgments.append({"hypothesis_id": item["hypothesis_id"], "effect": item["effect"], "reason": item["reason"]})
    ref = value.get("proxy_formula_ref")
    return {"proxy_formula_ref": ref if isinstance(ref, str) else None, "judgments": judgments}


def _evolution_template(value, record, notices, source=EVOLUTION_FILE):
    """evolution.json: the scoring basis, ranking rule, rounds and stop reason of one evolution."""
    rounds = value.get("rounds") if isinstance(value, dict) else None
    if not isinstance(value, dict) or not isinstance(rounds, list) or not all(
            isinstance(item, dict) and isinstance(item.get("round"), int) for item in rounds):
        notices.append(f"{record['kind']} {_short(record['record_path'])} 的宣告檔 {source} 需含 rounds 陣列"
                       f"（每項有整數 round），看板未採用。{EVOLUTION_HOW}")
        return None
    text = lambda key: value.get(key) if isinstance(value.get(key), str) and value[key].strip() else None
    return {"proxy_formula_ref": text("proxy_formula_ref"), "ranking_rule": text("ranking_rule"),
            "direction": value.get("direction") if value.get("direction") in DIRECTIONS else None,
            "target_transform": text("target_transform"), "stop_reason": text("stop_reason"),
            "tie_break": text("tie_break"), "claims_surpass": value.get("claims_surpass") is True,
            "primary_formula_ref": text("primary_formula_ref") or text("proxy_formula_ref"),
            "rounds": [_round(item) for item in rounds]}


EVOLUTION_HOW = ("宣告檔就是這筆紀錄中名為 evolution.json 的檔：用 research_record 的 template 傳入宣告內容即可；"
                 "自己的結果檔請取別的名字，不要叫 evolution.json。")


def _evolution_row(root, board, item, formulas, ancestors, host_compared, better, check_read, notices, by_ref=None):
    """One evolution record's declaration on the board, and what in it the host cannot check."""
    ref = item["record_path"]
    label = f"{item['kind']} {_short(ref)}"
    value = _read_json(root, item, EVOLUTION_FILE, check_read, notices)
    if value is None:
        if not any(Path(f["source_path"]).name == EVOLUTION_FILE for f in item["files"]):
            notices.append(f"{label} 未附 {EVOLUTION_FILE}：宿主無法核對它的計分依據、排名規則與超越宣稱。{EVOLUTION_HOW}")
        return
    source = next(f["source_path"] for f in item["files"] if Path(f["source_path"]).name == EVOLUTION_FILE)
    template = _evolution_template(value, item, notices, source)
    if template is None:
        return
    board["evolutions"].append({"ref": ref, "kind": item["kind"], "title": item["title"], **template})
    basis = template["primary_formula_ref"]
    formula = formulas.get(basis)
    scored_by_leaderboard = any(r["leaderboard_ref"] for r in template["rounds"])
    if basis is None and not scored_by_leaderboard:
        notices.append(f"{label} 的宣告檔 {source} 沒有 proxy_formula_ref（或 primary_formula_ref），各輪也沒有 "
                       f"leaderboard_ref：看不出演化用哪條公式計分。{EVOLUTION_HOW}")
    elif basis is not None and basis not in ancestors(ref):
        notices.append(f"{label} 的宣告檔 {source} 寫 proxy_formula_ref {_short(basis)}，但這筆紀錄沒有依賴它："
                       "請在 depends_on 列出計分用的公式紀錄。")
    rule = (formula or {}).get("template") or {}
    basis_label = rule.get("formula_id") or (_short(basis) if basis else "未宣告公式")
    board["decisions"].append({"id": f"{_short(ref)}:evolution", "source": ref, "kind": "evolution_rule",
                               "text": f"演化以 {basis_label} 計分；排名規則 {template['ranking_rule'] or '未宣告'}；"
                                       f"停止理由 {template['stop_reason'] or '未宣告'}"})
    for key, name in (("direction", "方向"), ("target_transform", "目標轉換")):
        if rule.get(key) and template[key] and rule[key] != template[key]:
            notices.append(f"{label} 的{name} {template[key]} 與公式宣告的 {rule[key]} 不同："
                           "規則在結果之後改變了。若是有意修訂，請寫成新的決策並說明理由。")
    compared = [c for r in template["rounds"] for c in (r["comparison_ref"], r["leaderboard_ref"]) if c]
    unknown = [c for c in compared if c not in host_compared]
    if unknown:
        notices.append(f"{label} 引用的 comparison_ref／leaderboard_ref 不是宿主比較紀錄："
                       + "、".join(_short(c) for c in unknown))
    if template["claims_surpass"] and not any(c in better for c in compared):
        notices.append(f"{label} 宣稱超越，但沒有任何一輪指向顯示超越的宿主比較紀錄"
                       "（research_compare_candidates 或 research_leaderboard）；超越未經宿主核對。")
    if by_ref:
        _round_order_notices(root, label, template["rounds"], by_ref, notices)


def _round_order_notices(root, label, rounds, by_ref, notices):
    """Say when a round's candidates were computed before the previous round was ranked.

    v30 declared three rounds; the values of rounds 2 and 3 were saved half a minute apart and five
    minutes before the first leaderboard, so no round could use what the one before it found.
    A round's newest values decide it: v41's rounds 2 and 3 also ranked the history values saved
    before round 1, and the oldest of their values made both look computed in advance.
    """
    def saved_at(ref):
        try:
            return (Path(root) / ref).stat().st_mtime_ns
        except OSError:
            return None

    scored = [(r["round"], r["leaderboard_ref"] or r["comparison_ref"]) for r in sorted(rounds, key=lambda r: r["round"])
              if (r["leaderboard_ref"] or r["comparison_ref"]) in by_ref]
    early = []
    for (_, previous), (number, ref) in zip(scored, scored[1:]):
        ranked = saved_at(previous)
        values = [d for d in by_ref[ref]["depends_on"] if d in by_ref and by_ref[d]["kind"] == "implementation"]
        times = [t for t in (saved_at(d) for d in values) if t is not None]
        if ranked is not None and times and max(times) < ranked:
            early.append(f"第 {number} 輪（數值 {'、'.join(_short(d) for d in values)} 早於第 {number - 1} 輪的排名 "
                         f"{_short(previous)}）")
    if early:
        notices.add(f"{label}：" + "；".join(early) + "。這幾輪的候選在上一輪排名之前就算好了，沒有用到上一輪的結果，"
                    "和上一輪是同一批，不是接續的演化。請在 evolution.json 照實寫成一輪；要接續演化，就在看過上一輪的"
                    "排行榜後，依它的結果設計下一輪候選，並在 reason 寫明用了哪個結果。",
                    key=f"evolution_round_order:{label}")


def _round(item):
    pick = lambda key: item.get(key) if isinstance(item.get(key), str) and item[key].strip() else None
    levers = item.get("levers")
    return {"round": item["round"], "comparison_ref": pick("comparison_ref"),
            "leaderboard_ref": pick("leaderboard_ref"),
            "strategy": item.get("strategy") if item.get("strategy") in ("explore", "exploit") else None,
            "levers": sorted(x for x in levers if isinstance(x, str)) if isinstance(levers, list) else None,
            "reason": pick("reason")}


def _calibration(value):
    keys = ("kendall_tau_b", "spearman_rho", "sample_count", "direction")
    if isinstance(value, dict) and all(key in value for key in keys):
        row = {key: value[key] for key in keys}
        adjusted = value.get("direction_adjusted_kendall_tau_b")
        row["adjusted_tau"] = adjusted if isinstance(adjusted, (int, float)) else None
        permutation = value.get("permutation_p")
        p = permutation.get("two_sided") if isinstance(permutation, dict) else None
        row["p_two_sided"] = p if isinstance(p, (int, float)) else None
        return row
    return None


def _calc_row(root, record, check_read, notices):
    """Conclusions of calc results saved in a kind=calc record."""
    found = []
    for item in record["files"]:
        if not item["source_path"].endswith(".json"):
            continue
        try:
            frozen, = resolve(root, [{"record_ref": record["record_path"], "source_path": item["source_path"]}],
                              check_read=check_read)
            value = json.loads(frozen["text"])
        except (OSError, ValueError, KeyError, TypeError):
            continue
        header = value.get("calc") if isinstance(value, dict) else None
        result = value.get("result") if isinstance(value, dict) else None
        if isinstance(header, dict) and isinstance(result, dict) and isinstance(result.get("conclusion"), str):
            found.append({"kind": header.get("kind"), "conclusion": result["conclusion"]})
    if not found:
        notices.add(f"calc {_short(record['record_path'])} 沒有可讀的 calc 結果檔（.research/calc/*.json）。",
                    key=f"calc_empty:{record['record_path']}")
    return {"ref": record["record_path"], "title": record["title"], "results": found}


def _simulation_row(root, record, check_read, notices):
    """Route, status, scalar values and warnings of a kind=simulation record."""
    value = _read_json(root, record, "result.json", check_read, notices)
    ref = record["record_path"]
    if not isinstance(value, dict):
        notices.add(f"simulation {_short(ref)} 沒有可讀的 result.json。", key=f"simulation_empty:{ref}")
        return {"ref": ref, "route": None, "status": None, "reason": None, "values": {}, "warnings": []}
    route = (value.get("route") or {}).get("id")
    values = {name: item for name, item in (value.get("values") or {}).items()
              if isinstance(item, dict) and isinstance(item.get("value"), (int, float))
              and not isinstance(item.get("value"), bool)}
    row = {"ref": ref, "route": route, "status": value.get("status"), "reason": value.get("reason"),
           "values": values, "warnings": [str(w) for w in value.get("warnings") or []]}
    if row["status"] != "completed":
        notices.add(f"simulation {_short(ref)}（{route}）狀態 {row['status']}：{_preview(row['reason'], 200)}。"
                    "它沒有產生結果；報告列出所用模擬時也要列出這一筆。", level="info", key=f"simulation_status:{ref}")
    return row


def _simulation_text(row):
    shown = "，".join(f"{name}={item['value']:.4g} {item.get('unit', '')}".rstrip()
                     for name, item in list(row["values"].items())[:3])
    warned = f"；警告 {len(row['warnings'])} 條" if row["warnings"] else ""
    return f"simulation {_short(row['ref'])}（{row['route']}）{row['status']}：{shown or '無數值'}{warned}"


def build(root: Path, *, history=None, check_read=None, requirements=None, hypothesis_budget=None) -> dict:
    root = Path(root).resolve()
    notices = Notices()
    if not isinstance(hypothesis_budget, int) or isinstance(hypothesis_budget, bool) or hypothesis_budget < 1:
        hypothesis_budget = HYPOTHESIS_BUDGET
    saved = records.inventory(root, check_read=check_read) if (root / ".research" / "records").is_dir() else []
    by_ref = {item["record_path"]: item for item in saved}
    ancestry = {}

    def ancestors(ref):
        if ref not in ancestry:
            found, pending = set(), list(by_ref[ref]["depends_on"])
            while pending:
                current = pending.pop()
                if current not in found and current in by_ref:
                    found.add(current)
                    pending.extend(by_ref[current]["depends_on"])
            ancestry[ref] = found
        return ancestry[ref]

    def of_kind(kind):
        return [item for item in saved if item["kind"] == kind]

    dependents = records.direct_dependents(saved)
    board = {"humans": _human_messages(history), "tasks": [], "hypotheses": [], "proxy_formulas": [],
             "comparisons": [], "other_kinds": {}, "mindmaps": [], "open_checkpoints": [], "reviews": [],
             "graph": _graph(root, check_read, requirements, notices), "notices": notices}
    for item in of_kind("task"):
        board["tasks"].append({"ref": item["record_path"], "title": item["title"]})

    for item in of_kind("hypothesis"):
        with notices.about(item["record_path"]):
            value = _read_json(root, item, HYPOTHESES_FILE, check_read, notices)
            items = _hypothesis_items(value, item, notices) if value is not None else None
            levers = _lever_table(root, value, item, check_read, notices) if items else None
        for h in items or []:
            h["lever_facts"] = ({lever: levers.get(lever, "missing") for lever in h["levers"]}
                                if levers is not None else None)
        board["hypotheses"].append({"ref": item["record_path"], "title": item["title"], "items": items})
    hypothesis_items = {row["ref"]: row["items"] for row in board["hypotheses"]}

    calibrations, calibration_templates = [], {}
    for item in of_kind("calibration"):
        for source in item["files"]:
            name = Path(source["source_path"]).name
            if not name.endswith(".json") or name == CALIBRATION_FILE:
                continue
            value = _read_json(root, item, name, check_read, notices)
            score = _calibration(value)
            if score is not None:
                calibrations.append({"ref": item["record_path"], **score})
        template = _read_json(root, item, CALIBRATION_FILE, check_read, notices)
        if template is not None:
            template = _calibration_template(template, item, notices)
        if template is not None:
            calibration_templates[item["record_path"]] = template
            if template["proxy_formula_ref"] and template["proxy_formula_ref"] not in ancestors(item["record_path"]):
                notices.append(f"calibration {_short(item['record_path'])} 的 proxy_formula_ref 不在它的依賴中；"
                               "請讓計分紀錄依賴它所計分的公式。")
    board["decisions"], board["questions"], board["evolutions"] = [], [], []

    covered_ids = {}
    negated = []  # formulas returning -abs(...) but declared lower
    formula_templates = {}
    for item in of_kind("proxy_formula"):
        with notices.about(item["record_path"]):
            template = _read_json(root, item, PROXY_FILE, check_read, notices)
            formula_templates[item["record_path"]] = (_proxy_template(template, item, notices)
                                                      if template is not None else None)
    replaced = _superseded(by_ref, ancestors, formula_templates, hypothesis_items)
    for item in of_kind("proxy_formula"):
        with notices.about(item["record_path"]):
            ref = item["record_path"]
            linked = sorted(a for a in ancestors(ref) if by_ref[a]["kind"] == "hypothesis")
            template = formula_templates[ref]
            scores = [row for row in calibrations if ref in ancestors(row["ref"])]
            revisions = sorted(d["record_path"] for d in dependents.get(ref, []) if d["kind"] == "proxy_formula")
            current = ref not in replaced
            board["proxy_formulas"].append({"ref": ref, "title": item["title"], "hypothesis_refs": linked,
                                            "template": template, "calibrations": scores,
                                            "later_proxy_formulas": revisions,
                                            "superseded_by": replaced.get(ref, [])})
            if not linked:
                notices.append(f"proxy_formula {_short(ref)} 沒有依賴任何 hypothesis 紀錄；看不出它在檢驗哪個假說。")
            if template is not None and linked:
                known = {}
                for h_ref in linked:
                    for h in hypothesis_items.get(h_ref) or []:
                        known.setdefault(h["id"], []).append(h_ref)
                missing = [h for h in template["hypothesis_ids"] if h not in known]
                if missing:
                    notices.append(f"proxy_formula {_short(ref)} 宣告的 hypothesis_ids 在其依賴的假說模板中找不到："
                                   + "、".join(missing))
                for h in template["hypothesis_ids"]:
                    for h_ref in known.get(h, []):
                        covered_ids.setdefault((h_ref, h), []).append(ref)
            elif linked:
                notices.add(f"proxy_formula {_short(ref)} 未附 {PROXY_FILE}，只能對應到整份假說紀錄，"
                            "看不出對應哪一條假說。", level="info")
            unscored = [c["record_path"] for c in of_kind("calibration") if ref in ancestors(c["record_path"])
                        and not any(row["ref"] == c["record_path"] for row in scores)]
            if unscored:
                notices.add(f"proxy_formula {_short(ref)} 有 calibration 紀錄 " + "、".join(_short(r) for r in unscored)
                            + "，但未附 research_compare 產生的結果 JSON；分數無法由宿主核對。",
                            key=f"unscored:{ref}")
            elif not scores and current:
                notices.add(f"proxy_formula {_short(ref)} 尚無依賴它的 calibration 計分紀錄。", level="info")
            for row in scores:
                if row.get("adjusted_tau") is not None and row["adjusted_tau"] < 0:
                    notices.append(f"calibration {_short(row['ref'])}：proxy_formula {_short(ref)} 依宣告方向的排序與歷史資料"
                                   f"相反（τ_b={row['adjusted_tau']}）；請檢查方向或公式，leaderboard 仍保留這張 sheet。")
                if isinstance(row["sample_count"], int) and row["sample_count"] <= SMALL_SAMPLE:
                    notices.add(f"calibration {_short(row['ref'])} 只有 {row['sample_count']} 筆樣本："
                                "任何方向正確的公式都會得到 ±1，此分數無法區分公式好壞。",
                                level="info", group="small_sample", ref=row["ref"])
            if template is None:
                continue
            label = template["formula_id"] or _short(ref)
            if current and not template["measured"] and not template["kpi"]:
                notices.add(f"proxy_formula {label}（{_short(ref)}）沒有宣告它排序的 KPI（kpi）或它預測的量測值（measured）："
                            "宿主無法檢查它在歷史樣本上的方向是否和實測一致，排行榜也會把它當成未經檢查。請另存修訂版公式"
                            "（revises 指向這筆），加上 \"kpi\": {\"record_ref\", \"source_path\", \"column\", \"better\": "
                            "\"lower|higher|target\", \"target_value\"}：KPI 的實測欄位，以及哪個方向對委託較好。",
                            key=f"kpi_missing:{ref}")
            if len(template["hypothesis_ids"]) >= 2 and current and not template["terms"]:
                notices.add(f"proxy_formula {label}（{_short(ref)}）同時代表 {len(template['hypothesis_ids'])} 個假說"
                            f"（{'、'.join(template['hypothesis_ids'])}）：每個假說應有自己的一條公式，各成一張 sheet。"
                            "若它們其實是同一個機制，請把它們合併成一個假說。", key=f"one_to_one:{ref}")
            # A saved record cannot change; once a revision depends on it, the revision carries the declaration.
            if template["direction"] == "target" and not template["measured"] and not revisions:
                notices.add(f"proxy_formula {label}（{_short(ref)}）宣告 direction target，但沒有指明 measured（它預測的量測值）。"
                            "依與目標的距離排名，前提是預測值和量測值在同一把尺上；指明 measured 後，research_leaderboard "
                            "會比對歷史預測與量測，列出偏差與殘差。已保存的紀錄不能修改：請另存一筆修訂版 proxy_formula，"
                            "revises 指向這筆紀錄，template 加上 \"measured\": {\"record_ref\", \"source_path\", \"column\"}；"
                            "有了依賴它的修訂版，這則提醒就不再出現。", key=f"target_unmeasured:{ref}")
            if (template["direction"] or template["target_transform"]) and current:
                board["decisions"].append({"id": f"{_short(ref)}:rule", "source": ref, "kind": "scoring_rule",
                                           "text": f"{label} 方向 {template['direction'] or '未宣告'}"
                                                   + (f"（目標值 {template['target_value']:g}）" if template["target_value"] is not None else "")
                                                   + f"；目標轉換 "
                                                   f"{template['target_transform'] or '未宣告'}"})
            if template["direction"] == "lower" and NEGATED_DISTANCE.search(template["expression"]) and current:
                negated.append(f"{label}（{_short(ref)}）")
            for row in scores:
                if template["direction"] and row["direction"] != template["direction"]:
                    notices.append(f"calibration {_short(row['ref'])} 以方向 {row['direction']} 計分，但 {label} 宣告 "
                                   f"{template['direction']}：規則在公式之後改變了。若是有意修訂，請以新公式紀錄"
                                   "或新決策寫明理由。")
            direction = template["direction"] or next((row["direction"] for row in scores), None)
            if (template["target_transform"] and direction and direction != "target"
                    and NON_MONOTONE.search(template["target_transform"])):
                notices.append(f"{label} 的目標 {template['target_transform']} 有最佳點，但公式方向固定為 {direction}："
                               "持續朝同一方向最佳化，可能把候選推過最佳點。較穩的做法是讓公式預測該量本身，"
                               "宣告 direction target 與 target_value，由排名計算與目標的距離。排名前請用目前的資料估算候選在目標上的位置，"
                               "並寫明估算方法的限制；若無法估算，寫明原因。估算的範圍可用 calc kind=interval，例如 "
                               '{"expr": "<候選在目標量上的估計式>", "ranges": {"<不確定的參數>": [<低>, <高>]}}。')
            for cal_ref, cal in calibration_templates.items():
                if ref not in ancestors(cal_ref):
                    continue
                for judgment in cal["judgments"]:
                    for h_ref in linked:
                        for h in hypothesis_items.get(h_ref) or []:
                            entry = {"calibration": cal_ref, **judgment}
                            if h["id"] == judgment["hypothesis_id"] and entry not in h.get("judgments", []):
                                h.setdefault("judgments", []).append(entry)

    if negated:
        notices.add(f"公式 {'、'.join(negated)} 回傳 -abs(...)：數值越大代表越接近目標，但方向宣告為 lower。direction 指"
                    "實作回傳的數字是越高越好還是越低越好，不是偏差的大小。若越大越好，請以新版公式紀錄改成 higher"
                    "（research_record 的 revises 指向舊版），再重算 research_leaderboard；leaderboard 依宣告方向排名，現在的判定會是反的。",
                    key="negated_distance")
    _target_model_notice(board, notices)
    formulas_by_ref = {f["ref"]: f for f in board["proxy_formulas"]}
    for row in board["hypotheses"]:
        formulas = [f["ref"] for f in board["proxy_formulas"] if row["ref"] in f["hypothesis_refs"]]
        row["proxy_formula_refs"] = formulas
        row["superseded_by"] = replaced.get(row["ref"], [])
        older = sorted(a for a in ancestors(row["ref"]) if by_ref[a]["kind"] == "hypothesis")
        for h in row["items"] or []:
            # A revision that keeps a hypothesis's id keeps the formulas built for it, also when it rewords the
            # statement: v23 added a comma to H3, lost its formula and saved the set five more times.
            carried, reworded = [], []
            for a in older:
                for prev in hypothesis_items.get(a) or []:
                    found = covered_ids.get((a, h["id"]), []) if prev["id"] == h["id"] else []
                    carried += found
                    if found and prev["statement"].strip() != h["statement"].strip():
                        reworded += found
            own = covered_ids.get((row["ref"], h["id"]), [])
            h["proxy_formula_refs"] = list(dict.fromkeys(own + carried))
            h["reworded_from"] = [] if own else list(dict.fromkeys(reworded))
        if row["superseded_by"]:
            continue  # the newer hypothesis record carries the current judgments and notices
        for h in row["items"] or []:
            if h["reworded_from"]:
                labels = "、".join(dict.fromkeys(
                    (formulas_by_ref.get(f, {}).get("template") or {}).get("formula_id") or _short(f)
                    for f in h["reworded_from"]))
                notices.add(f"hypothesis {_short(row['ref'])} 改寫了 {h['id']} 的敘述，沿用為舊版敘述建立的公式 {labels}。"
                            "公式仍對應新敘述就不必處理；不再對應時，另存修訂版公式（revises 指向舊公式）。",
                            level="info", key=f"reworded:{row['ref']}:{h['id']}")
        if not formulas and not any(h["proxy_formula_refs"] for h in row["items"] or []):
            notices.add(f"hypothesis {_short(row['ref'])} 尚無任何 proxy_formula 依賴它。", level="info")
        uncovered = [h["id"] for h in row["items"] or [] if not h["proxy_formula_refs"] and not h["not_computable"]
                     and not h["deferred"] and not h["merged"]]
        deferred = [h for h in row["items"] or [] if h["deferred"]]
        queued = [h for h in deferred if h["deferred_basis"] == "budget"]
        if queued:
            notices.add(f"hypothesis {_short(row['ref'])} 因預算排隊的假說：" + "；".join(
                f"{h['id']}（{_preview(h['deferred'], 120)}）" for h in queued)
                + "。第一次交付後依排序啟用；仍在排隊的，報告列為尚未評估，不是無法檢驗。", level="info",
                key=f"deferred:{row['ref']}")
        held_back = [h for h in deferred if h["deferred_basis"] != "budget"]
        if held_back:
            notices.add(f"hypothesis {_short(row['ref'])} 延後的 " + "、".join(h["id"] for h in held_back)
                        + " 沒有標示 \"basis\": \"budget\"：延後只能是預算排隊。連方向都缺量測或工具時，改寫 "
                        "not_computable 並在 missing 寫缺什麼；否則它仍是進行中的假說。",
                        key=f"deferred_basis:{row['ref']}")
        for h in row["items"] or []:
            ids = {other["id"] for other in row["items"] if other["id"] != h["id"]}
            if h["merged"] and h["merged"] not in ids:
                notices.add(f"hypothesis {_short(row['ref'])} 的 {h['id']} 標為 merged，但 into（{h['merged']}）"
                            "不是同一份紀錄中的另一個假說 id。", key=f"merged_into:{row['ref']}:{h['id']}")
        active = [h for h in row["items"] or [] if not h["deferred"] and not h["not_computable"] and not h["merged"]]
        if len(active) > hypothesis_budget:
            notices.add(f"hypothesis {_short(row['ref'])} 有 {len(active)} 個主動假說，超過預算 {hypothesis_budget}"
                        "（research.hypothesis_budget，是上限不是配額）：其餘標為 deferred，寫 \"basis\": \"budget\" "
                        "與排序，先完成一次完整交付。",
                        level="info", key=f"hypothesis_budget:{row['ref']}")
        declared = [h for h in row["items"] or [] if not h["proxy_formula_refs"] and h["not_computable"]]
        # v24 regenerated its set and lost H4-H6's deferred status; asking for their formulas made it build three.
        lost = [hid for hid in uncovered if any(prev["id"] == hid and prev["deferred"]
                                                for a in older for prev in hypothesis_items.get(a) or [])]
        if lost:
            notices.add(f"hypothesis {_short(row['ref'])} 的 {'、'.join(lost)} 在前一版標為預算排隊（deferred），這一版"
                        "沒有 proxy_status，看板因此把它們算成進行中的假說。仍要延後的話，另存一版並保留原本的 "
                        "proxy_status；只有決定現在啟用時才需要為它們建立公式。", key=f"lost_deferred:{row['ref']}")
            uncovered = [hid for hid in uncovered if hid not in lost]
        if row["items"] and uncovered:
            # v23 saved a second set with the same ids that did not build on the first, which its formulas use.
            elsewhere = sorted({other for other in hypothesis_items if other != row["ref"]
                                and other not in ancestors(row["ref"])
                                for hid in uncovered if covered_ids.get((other, hid))})
            hint = (f"這些 id 的公式依賴的是另一份假說紀錄 {'、'.join(_short(o) for o in elsewhere)}：若這份是它的新版，"
                    "請另存並以 revises 指向它，公式就會沿用，不要另起一份平行的假說集。") if elsewhere else ""
            notices.add(f"hypothesis {_short(row['ref'])} 中沒有對應公式的假說：{'、'.join(uncovered)}。" + hint
                        + "請為它寫公式（槓桿是設計能設定的量，大小不確定就寫成範圍）；連方向都缺量測或工具時，"
                        "在 proxy_status 寫 not_computable 並在 missing 寫缺什麼；預算排隊的標 deferred。",
                        key=f"uncovered:{row['ref']}")
        unexplained = [h["id"] for h in row["items"] or [] if h["not_computable"] and not h["missing"] and not h["tried"]]
        if unexplained:
            notices.add(f"hypothesis {_short(row['ref'])} 宣告無法計算的 {'、'.join(unexplained)} 沒有寫 missing："
                        "連方向都要靠哪個量測或工具才能判斷。報告要寫出它，作為下一步。",
                        key=f"not_computable_tried:{row['ref']}")
        if declared:
            notices.add(f"hypothesis {_short(row['ref'])} 宣告無法計算：" + "；".join(
                f"{h['id']}（{_preview(h['not_computable'], 120)}）" for h in declared)
                + "。這些假說沒有自己的 sheet，候選不會沿著它們的方向產生。", level="info",
                key=f"not_computable:{row['ref']}")
        for h in row["items"] or []:
            ids = {formulas_by_ref[f]["template"]["formula_id"] for f in h["proxy_formula_refs"]
                   if f in formulas_by_ref and formulas_by_ref[f]["template"]
                   and formulas_by_ref[f]["template"]["formula_id"]}
            if len(ids) > 1:
                notices.add(f"假說 {h['id']} 有 {len(ids)} 條不同的公式（{'、'.join(sorted(ids))}）：一對一時請保留一條；"
                            "修訂請沿用同一個 formula_id，並以 research_record 的 revises 指向舊版。", level="info",
                            key=f"many_formulas:{row['ref']}:{h['id']}")

    for item in saved:
        names = [f for f in item["files"] if Path(f["source_path"]).name == "comparison.json"]
        if item["kind"] != "implementation" or len(names) != 1:
            continue
        value = _read_json(root, item, "comparison.json", check_read, notices)
        if isinstance(value, dict) and {"method_ref", "best_baseline", "best_candidate", "comparison"} <= set(value):
            board["comparisons"].append({"ref": item["record_path"], "method_ref": value["method_ref"],
                                         "direction": value.get("direction"),
                                         "best_baseline": value["best_baseline"],
                                         "best_candidate": value["best_candidate"],
                                         "comparison": value["comparison"]})
    _history_checks(root, board, saved, of_kind, ancestors, check_read, notices)
    board["leaderboards"] = []
    for item in of_kind("leaderboard"):
        value = _read_json(root, item, "leaderboard.json", check_read, notices)
        if not isinstance(value, dict) or not {"sheets", "candidates", "pareto_front"} <= set(value):
            continue
        row = {"ref": item["record_path"], **{k: value.get(k) for k in (
            "primary_formula_ref", "baseline_ids", "candidate_ids", "sheets", "candidates", "pareto_front",
            "front_ratio", "front_too_large", "sheet_agreement", "all_sheets_agree", "most_disputed")}}
        board["leaderboards"].append(row)
        with notices.about(item["record_path"]):
            label = f"leaderboard {_short(item['record_path'])}"
            if len(row["sheets"]) == 1:
                notices.add(f"{label} 只有一張 sheet：候選只從一個假說的角度評估，判定不會是「穩健超越」。"
                            "其他假說應各有一條公式，各成一張 sheet。", level="info")
            if row["all_sheets_agree"]:
                notices.add(f"{label} 各 sheet 的排名完全一致：這些公式對候選的預測沒有差別，等於只有一張 sheet。",
                            level="info")
            for sheet in row["sheets"] or []:
                if sheet.get("evidence") == "history_reversed":
                    order = sheet.get("history_order") or {}
                    notices.add(f"{label} 的 sheet {_sheet_label(sheet)} 對歷史樣本的偏好與實測 KPI 相反（實測較好的是 "
                                f"{order.get('better_by_kpi')}），靠它得到的超越只是條件式。" + _reversed_reading(sheet),
                                key=f"history_reversed:{item['record_path']}:{sheet.get('formula_ref')}")
                if sheet.get("evidence") == "history_fitted":
                    why = ("是量化模型，係數由歷史樣本與各機制的正負號求得" if sheet.get("model") else
                           "是在歷史檢查判定同一假說與歷史相反之後才存的（"
                           + "、".join(_short(r["history_check"]) for r in sheet["revised_after"]) + "）"
                           if sheet.get("revised_after") else
                           f"的常數取自 {'、'.join(sheet.get('fitted_on') or [])}（fitted_on）")
                    notices.add(f"{label} 的 sheet {_sheet_label(sheet)} {why}，與這些歷史樣本一致是擬合的結果，不算歷史證據；"
                                "靠它得到的超越只是條件式。報告要寫明哪些地方是看過歷史資料後才定的。", level="info",
                                key=f"history_fitted:{item['record_path']}:{sheet.get('formula_ref')}")
                for text, key in _scale_notices(sheet):
                    notices.add(f"{label}：{text}", key=f"{key}:{item['record_path']}:{sheet.get('formula_ref')}")
            if row["front_too_large"]:
                notices.add(f"{label} 的 Pareto 前緣占全部樣本的 {round(row['front_ratio'] * 100)}%：沒有候選能壓過其他候選，"
                            "選哪個取決於哪個假說成立。要挑實測對象，可用 calc kind=design 的 predictions 模式，"
                            "找出最能分辨假說的候選。", level="info")
    formulas = {row["ref"]: row for row in board["proxy_formulas"]}
    # A candidate comparison ranks by its own direction; research_leaderboard ranks by the formula's.
    # A comparison whose method is a formula ranks that formula only: a shared values table depends
    # on every formula, and its other columns are not what this comparison ranked.
    clashes = {}
    for comparison in board["comparisons"]:
        used = ({comparison["method_ref"]} if comparison["method_ref"] in formulas
                else ancestors(comparison["ref"]) | {comparison["method_ref"]})
        for ref, row in formulas.items():
            declared = (row["template"] or {}).get("direction")
            if ref in used and declared and comparison["direction"] and declared != comparison["direction"]:
                clashes.setdefault(comparison["ref"], []).append(
                    f"{row['template']['formula_id'] or _short(ref)}（{declared}）")
    if clashes:
        listed = "；".join(f"比較 {_short(c)} 用 {next(r for r in board['comparisons'] if r['ref'] == c)['direction']}，"
                          f"公式宣告 {'、'.join(names)}" for c, names in clashes.items())
        notices.add(f"候選比較與公式的方向不一致：{listed}。research_leaderboard 依公式宣告的方向排名，兩邊的判定會"
                    "相反。請確認實作回傳的數字哪個方向較好，修正錯的一邊（公式以新版紀錄修訂，revises 指向舊版），"
                    "再重算比較與 leaderboard。", key="comparison_direction")
    host_compared, better = comparison_sets(board)
    # Only an evolution record declares an evolution. An implementation's own data file that happens to be
    # called evolution.json is data: v22 saved its results as data/evolution.json, the board read that as the
    # declaration, and the notices it raised could not be answered by saving anything else.
    for item in (item for item in saved if "evolution" in item["kind"]):
        with notices.about(item["record_path"]):
            _evolution_row(root, board, item, formulas, ancestors, host_compared, better, check_read, notices,
                           by_ref)
    known_kinds = {"task", "hypothesis", "proxy_formula", "calibration", "implementation", "mindmap",
                   "mindmap_checkpoint", "review", "report", "final_lca", "user_report", "leaderboard", "calc", "judgment",
                   "simulation", "history_check"}
    for item in saved:
        if item["kind"] not in known_kinds:
            board["other_kinds"].setdefault(item["kind"], []).append(
                {"ref": item["record_path"], "title": item["title"]})

    board["calcs"] = [_calc_row(root, item, check_read, notices) for item in of_kind("calc")]
    board["simulations"] = [_simulation_row(root, item, check_read, notices) for item in of_kind("simulation")]
    unfinished = {row["ref"]: row for row in board["simulations"] if row["status"] != "completed"}
    for item in saved:
        if item["kind"] in DELIVERY_KINDS:
            for ref in sorted(set(unfinished) & ancestors(item["record_path"])):
                row = unfinished[ref]
                notices.add(f"{item['kind']} {_short(item['record_path'])} 依賴狀態為 {row['status']} 的 simulation "
                            f"{_short(ref)}（{row['route']}）：它沒有產生結果，不能當作證據。",
                            key=f"delivery_unfinished_simulation:{item['record_path']}:{ref}")
    board["judgments"] = []
    for item in of_kind("judgment"):
        value = _read_json(root, item, "judgment.json", check_read, notices)
        if not isinstance(value, dict):
            continue
        row = {"ref": item["record_path"], **{k: value.get(k) for k in (
            "hypothesis_id", "formula_id", "repeats_used", "agreement_kendall_tau_b", "low_agreement",
            "unsourced_samples", "unfetched_citations")}}
        board["judgments"].append(row)
        label = f"LLM 評審 {_short(item['record_path'])}（{row['hypothesis_id']}）"
        if row["unfetched_citations"]:
            notices.add(f"{label} 引用了 {len(row['unfetched_citations'])} 個評審從未讀取的網址："
                        + "、".join(_preview(u, 80) for u in row["unfetched_citations"][:3])
                        + "；這些出處可能是編造的，不能當作證據。", key=f"judge_unfetched:{item['record_path']}")
        if row["low_agreement"]:
            notices.add(f"{label} 各次評分的一致度低（τ_b={row['agreement_kendall_tau_b']}）：這張 sheet 的排名"
                        "不穩定，報告須寫明。", level="info", key=f"judge_agreement:{item['record_path']}")
        if row["unsourced_samples"]:
            notices.add(f"{label} 對 {'、'.join(row['unsourced_samples'][:6])} 沒有任何出處，只有機制推估。",
                        level="info", key=f"judge_unsourced:{item['record_path']}")
    for item in of_kind("mindmap"):
        board["mindmaps"].append({"ref": item["record_path"], "title": item["title"]})
        value = _read_json(root, item, "mindmap.json", check_read, notices)
        gaps = value.get("unresolved_gaps") if isinstance(value, dict) else None
        for index, gap in enumerate(gaps if isinstance(gaps, list) else [], 1):
            if isinstance(gap, str) and gap.strip():
                board["questions"].append({"id": f"{_short(item['record_path'])}:G{index}", "text": gap,
                                           "source": item["record_path"]})
    for item in of_kind("mindmap_checkpoint"):
        if not dependents.get(item["record_path"]):
            board["open_checkpoints"].append(item["record_path"])

    for item in of_kind("review"):
        value = _read_json(root, item, "review.json", check_read, notices)
        reviewed = value.get("reviewed_refs") if isinstance(value, dict) else None
        board["reviews"].append({"ref": item["record_path"], "title": item["title"],
                                 "reviewed_refs": reviewed if isinstance(reviewed, list) else None})
    _review_coverage_notices(root, board, saved, by_ref, dependents, notices, ancestors, check_read)
    _version_notices(board, saved, ancestors, notices)
    _evolution_progress_notices(board, notices)
    board["deliveries"] = {kind: [item["record_path"] for item in _by_save_time(root, of_kind(kind))]
                           for kind in sorted(DELIVERY_KINDS)}
    delivered = _by_save_time(root, [item for item in saved if item["kind"] in ("report", "user_report")])
    if delivered and of_kind("leaderboard") and not any("evolution" in item["kind"] for item in saved):
        notices.add("已有 research_leaderboard 排名候選、也已存 report，但沒有 sample_evolution 紀錄：research_deliver "
                    "會拒絕交付。請用 research_record（kind sample_evolution，template 存成 evolution.json，見 sample 技能）"
                    "照實寫下實際跑過的每一輪（candidate_ids、leaderboard_ref、strategy、levers、reason）與 stop_reason；"
                    "一次算好的候選就是一輪。報告描述的輪次要與它一致。", key="evolution_missing")
    if delivered and not of_kind("final_lca"):
        notices.add(f"已保存 {len(delivered)} 筆 report／user_report（最新 {_short(delivered[-1]['record_path'])}），"
                    "但沒有 kind=final_lca 紀錄。委託的正式收尾需要一筆 Final-LCA 判定（released、bounded-reject、"
                    "hard-block 都是有效結果）：它依賴所交付的 report，以及一筆 review.json 的 reviewed_refs 涵蓋該 report "
                    "的審查；user_report 再直接依賴這份 report 與 final_lca。research_deliver 一次寫好 Final-LCA 與 user_report（見 final-lca/SKILL.md）。這不是要求重做"
                    "研究，已完成的審查與計算可直接引用。", key="final_lca_missing")
    # Unbound-review notices stay at publication time: records carry no time, so
    # here a record saved before the review would be indistinguishable from one after.
    replies = (board["graph"] or {}).get("notice_replies") or {}
    # A later evolution record built on an earlier one replaces it, as revisions do for formulas and hypotheses.
    stale = set(replaced) | {older for item in saved if "evolution" in item["kind"]
                             for older in ancestors(item["record_path"]) if "evolution" in by_ref[older]["kind"]}
    stale |= _stale_leaderboards(root, board, replaced, by_ref)
    board["notice_items"] = notices.finalize(replies, stale)
    board["notices"] = [item["text"] for item in board["notice_items"]]
    return board


def _target_model_notice(board, notices):
    """Ask for a quantitative model when the KPI's best value is a target.

    A run's KPI had a target band, its samples were all on one side of it, and its formulas ranked by
    "lower is better": nothing said how far a candidate moved, so nothing could tell one that stops at
    the target from one that overshoots.
    """
    current = [row for row in board["proxy_formulas"] if not row["superseded_by"] and row["template"]]
    targeted = [row for row in current if row["template"].get("kpi_better") == "target"]
    if not targeted or any(row["template"].get("terms") for row in current):
        return
    notices.add("KPI 以目標值為佳（kpi.better target），但還沒有量化模型：只靠各機制的排名，看不出候選會落在目標的哪一側、"
                "會不會衝過頭。請另存一條量化模型公式：direction target 與目標值（有容許範圍就填 tolerance）、measured 指向"
                "實測 KPI，hypothesis_ids 列出它涵蓋的 active 假說，terms 為每個假說一項 {hypothesis_id, lever, quantity"
                "（數值表裡這一項物理量的欄位）, mechanism_predicts（依機制）}。不要寫係數：歷史檢查依歷史量測與各機制的正負號"
                "求出所有相容的係數，排行榜在所有相容係數下比較候選。它是排行榜上額外的一張表，不取代各假說自己的表；見 "
                "final-kpi-proxy-discovery。", key="target_model_missing")


def _stale_leaderboards(root, board, replaced, by_ref):
    """Leaderboards whose notices a newer one answers.

    v30 kept two "order reversed" action notices on each of three leaderboards that later ones had
    replaced. A leaderboard is replaced when it ranks a formula version a revision replaced, or when
    a later leaderboard ranks the same formulas again.
    """
    rows = {row["ref"]: row for row in board["leaderboards"]}
    stale, seen = set(), set()
    for item in reversed(_by_save_time(root, [by_ref[ref] for ref in rows if ref in by_ref])):
        ref = item["record_path"]
        formulas = frozenset(s.get("formula_ref") for s in rows[ref]["sheets"] or [] if isinstance(s, dict))
        if formulas & set(replaced) or formulas in seen:
            stale.add(ref)
        seen.add(formulas)
    return stale


DELIVERY_KINDS = {"report", "final_lca", "user_report"}
VERSIONED_KINDS = {"hypothesis", "proxy_formula"}


def _superseded(by_ref, ancestors, formula_templates, hypothesis_items):
    """{older ref: [newer refs]} for hypothesis and proxy_formula records a later version replaces.

    A newer version depends on the older one (research_record's revises adds that
    dependency). Formulas replace each other only when they share a formula_id, or
    when one of them declares none and the newer depends on the older directly. A
    hypotheses set replaces an older one only when it keeps every older id; a record
    that only adds new hypotheses leaves the older set current.
    """
    def formula_id(ref):
        template = formula_templates.get(ref)
        return template["formula_id"] if template else None

    replaced = {}
    for ref, item in by_ref.items():
        if item["kind"] not in VERSIONED_KINDS:
            continue
        for older in sorted(ancestors(ref)):
            if by_ref[older]["kind"] != item["kind"]:
                continue
            if item["kind"] == "proxy_formula":
                mine, theirs = formula_id(ref), formula_id(older)
                if not (mine == theirs if mine and theirs else older in item["depends_on"]):
                    continue
            elif not {h["id"] for h in hypothesis_items.get(older) or []} <= {
                    h["id"] for h in hypothesis_items.get(ref) or []}:
                continue
            replaced.setdefault(older, []).append(ref)
    return replaced


HISTORY_FLAGS = {
    "off_scale": lambda s: (f"預測平均偏離量測 {s['scale_check']['mean_offset']:+g}（殘差差距 "
                           f"{s['scale_check']['residual_spread']:g}）：依與目標距離的排名不可信。請另存修訂版公式（revises "
                           "指向這筆）修正；若誤差主要是固定偏移，可宣告 anchor。"),
    "order_reversed": lambda s: ("公式對歷史樣本的偏好與實測 KPI 相反（" + "、".join(
        f"{a}／{b}" for a, b in (s.get("history_order") or {}).get("disagreements")
        or s["scale_check"].get("order_disagreements", [])) + "；實測較好的是 "
        + str((s.get("history_order") or {}).get("better_by_kpi") or "量測值較高者") + "）。" + _reversed_reading(s)),
    "equal_on_history": lambda s: "公式對每筆歷史樣本的預測都相同：歷史資料無法檢驗它，排行榜上會是「僅機制」的 sheet。",
    "spread_mismatch": lambda s: (f"預測的樣本間差距是量測差距的 {s['spread_ratio']:.2g} 倍：候選與目標的距離會被"
                                 + ("壓縮。" if s["spread_ratio"] < 1 else "放大。")),
    "coefficients_infeasible": lambda s: (
        "量化模型找不到任何一組符合各機制正負號、又能重現歷史量測的係數（至少要容許 "
        f"{s['model']['min_noise']:.3g} 的誤差才行）。" + CHECK_MODEL),
    "coefficient_pinned_zero": lambda s: ("歷史資料讓量化模型的某些係數只能是 0：機制說 KPI 會隨那一項變，這些樣本說不會。"
                                          + CHECK_MODEL),
    "coefficients_undetermined": lambda s: ("這些歷史樣本定不出量化模型的部分係數；排行榜會在所有相容的係數下比較候選，"
                                            "分不出的標 undecided，並列出量哪個候選就能定出係數（next_measurements）。"),
    "fitted_history": lambda s: ("量化模型的係數由歷史檢查依這些樣本與各機制的正負號求得：與它們一致是擬合出來的，"
                                 "排行榜上這張 sheet 是 history_fitted，不算歷史證據。") if s.get("model") else (
        ("這條公式是在歷史檢查判定同一假說與歷史相反之後才存的（" + "、".join(
        _short(item["history_check"]) for item in s["revised_after"]) + "）：現在與這些樣本一致是看過結果後修出來的，"
        "不是檢驗；排行榜上這張 sheet 是 history_fitted，不算歷史證據。"
        + (f"它宣告了修正（{s['correction'].get('error')}：{_preview(str(s['correction'].get('what')), 80)}），"
           "報告請寫明修正內容與依據。" if isinstance(s.get("correction"), dict) else
           "報告請寫明之後改了什麼、為什麼改。"))
        if s.get("revised_after") else
        ("公式的常數取自它所比較的歷史樣本（fitted_on）：與這些樣本一致是擬合出來的，不是檢驗；"
         "排行榜上這張 sheet 是 history_fitted，不算歷史證據，靠它得到的超越只是條件式。")),
}
HISTORY_ACTION_FLAGS = ("off_scale", "order_reversed", "coefficients_infeasible", "coefficient_pinned_zero")
CHECK_MODEL = ("請先檢查每一項：程式算的量是否符合題目定義的角色與意義、正負號是否和機制一致、程式是否算出所寫的量（calc kind "
               "properties）、每個輸入值是否來自題目、引用來源或 calc 結果（自行假設的值要指明）。找到錯誤就另存修訂版並在 correction 寫明；不要為了湊合資料而改機制給的正負號。若量測本來就有"
               "這麼大的誤差，就宣告 noise {sd, source}；否則照實報告模型與歷史矛盾。")
CHECK_PHYSICS = ("請先檢查公式的機制：(1) 用到的每個成分或輸入是否符合題目定義的角色與意義（題目以化學結構定義角色時用 calc kind roles）；(2) 公式內每一項的正負號是否和理由一致；"
                 "(3) 程式是否算出所寫的公式（calc kind properties）；(4) 每個輸入值是否來自題目、引用來源或 calc 結果："
                 "自行假設的值（常數、刻度或排序）要指明，順序相反可能就出在它。找到錯誤就另存修訂版，在 correction 寫明錯在哪裡與依據；"
                 "不要為了和歷史一致而改機制給的正負號。")


def _reversed_reading(sheet):
    """What a reversed order means on the board: v31 called three confounded reversals refutations."""
    others = sheet.get("confounded_with") or []
    tail = "它在排行榜上是 history_reversed，不算歷史證據；這之後才存的同一假說公式（包括宣告的修正）在排行榜上只算 history_fitted。"
    if others:
        return (f"這些樣本在 {'、'.join(others)} 上也不同：實測差異是幾個變化的淨效果，這個順序本身不能反駁也不能支持這個假說。"
                + CHECK_PHYSICS + "都沒有錯，就在報告寫明這些樣本分不開這幾個機制，以及哪個量測能分開（calc kind design）。" + tail)
    return ("這些樣本分得開這條公式與其他公式：不是歷史反駁了這個假說，就是公式寫錯了機制。" + CHECK_PHYSICS
            + "都沒有錯，就照實報告歷史與假說相反。" + tail)
UNCHECKED_ORDER = {"undeclared": "（未宣告 kpi 或 measured）", "no_overlap": "（KPI 檔的樣本 ID 與預測對不上）",
                   "one_sample": "（只比到一筆歷史樣本）", "kpi_ties": "（KPI 在歷史樣本上相同）"}


def _measured_kpi(board) -> bool:
    """Whether a current formula ranks measured values. A task with no measurements has no history to check
    against, so a formula without a history check is not missing one."""
    return any(row["template"] and (row["template"]["kpi"] or row["template"]["measured"])
               for row in board["proxy_formulas"] if not row.get("superseded_by"))


def _history_checks(root, board, saved, of_kind, ancestors, check_read, notices):
    """The newest history check of each formula, its findings as notices, and formulas not yet checked."""
    board["history_checks"], latest = [], {}
    for item in _by_save_time(root, of_kind("history_check")):
        value = _read_json(root, item, "history_check.json", check_read, notices)
        sheets = value.get("sheets") if isinstance(value, dict) else None
        rows = [s for s in sheets if isinstance(s, dict) and isinstance(s.get("formula_ref"), str)
                and isinstance(s.get("flags"), list)] if isinstance(sheets, list) else []
        board["history_checks"].append({"ref": item["record_path"], "sheets": rows})
        for sheet in rows:
            latest[sheet["formula_ref"]] = (item["record_path"], sheet)
    for row in board["proxy_formulas"]:
        check_ref, sheet = latest.get(row["ref"], (None, None))
        row["history_check"] = ({"ref": check_ref, "flags": sheet["flags"], "order_checked": sheet.get("order_checked") is True,
                                 "order_reason": sheet.get("order_unchecked_reason")}
                                if check_ref else None)
        if row["superseded_by"] or not row["template"]:
            continue
        label = f"proxy_formula {row['template']['formula_id'] or ''}（{_short(row['ref'])}）"
        if check_ref:
            for flag in sheet["flags"]:
                if flag in HISTORY_FLAGS:
                    try:
                        text = HISTORY_FLAGS[flag](sheet)
                    except (KeyError, TypeError, ValueError):
                        text = f"旗標 {flag}"
                    notices.add(f"{label} 的歷史檢查 {_short(check_ref)}：{text}",
                                level="action" if flag in HISTORY_ACTION_FLAGS else "info",
                                key=f"history_{flag}:{row['ref']}")
            continue
        users = {item["kind"] for item in saved if row["ref"] in ancestors(item["record_path"])}
        if "implementation" in users and not users & {"leaderboard", "sample_evolution"} and _measured_kpi(board):
            notices.add(f"{label} 已有依賴它的實作，但還沒有歷史檢查：產生候選前，請把它對歷史樣本的預測交給 "
                        "research_history_check（尺度、順序、是否同值）。這些問題在排行榜之後才發現，要重算整輪候選。",
                        key=f"history_missing:{row['ref']}")


def _by_save_time(root, items):
    """Records in the order they were saved (record.json is written once, when the record is made)."""
    def saved_at(item):
        try:
            return (Path(root) / item["record_path"]).stat().st_mtime_ns
        except OSError:
            return 0
    return sorted(items, key=lambda item: (saved_at(item), item["record_path"]))


def _review_coverage_notices(root, board, saved, by_ref, dependents, notices, ancestors, check_read=None):
    """Say, when a report or Final-LCA is saved, whether its exact version has been reviewed.

    The delivery check at the end of a turn finds the same gap, after the Final-LCA and the
    delivery are written; these notices appear in the receipt of the record being saved. A report
    built on a reviewed version (the reviewed draft, then the rendered or revised report) needs no
    second review: research_deliver asks for an answer to each check the review did not support.
    """
    reviewed = {}
    for review in board["reviews"]:
        for ref in review["reviewed_refs"] or []:
            reviewed.setdefault(ref, []).append(review["ref"])
    reports = _by_save_time(root, [item for item in saved if item["kind"] == "report"])
    if reports and reports[-1]["record_path"] not in reviewed:
        newest = reports[-1]["record_path"]
        built_on = [ref for ref in ancestors(newest) if ref in reviewed]
        earlier = [item["record_path"] for item in reports[:-1] if item["record_path"] in reviewed]
        if built_on:
            notices.add(f"report {_short(newest)} 建立在審查過的版本 {'、'.join(_short(r) for r in built_on)} 上："
                        "不必重審；用 research_deliver 交付時，逐條回應審查中未判為 supported 的項目（已修改或列為"
                        "限制時引用報告原文）。", level="info", key=f"report_built_on_review:{newest}")
        elif earlier:
            notices.add(f"report {_short(newest)} 是最新的報告，但還沒有審查：現有審查涵蓋的是 "
                        f"{'、'.join(_short(r) for r in earlier)}，而這份報告沒有依賴它們。交付的報告要依賴審查過的"
                        f"版本（depends_on 放它），或先用 research_review 審查 {_short(newest)}。",
                        key=f"report_unreviewed:{newest}")
    for item in saved:
        if item["kind"] != "final_lca" or any(d["kind"] == "final_lca" for d in dependents.get(item["record_path"], [])):
            continue  # a revised Final-LCA carries the current judgment
        own_reviews = {ref for ref in item["depends_on"] if by_ref.get(ref, {}).get("kind") == "review"}
        covered = {ref for review in board["reviews"] if review["ref"] in own_reviews
                   for ref in review["reviewed_refs"] or []}
        embedded = any(Path(f["source_path"]).name == "review.json" for f in item["files"])
        answers = records._final_lca_answers(root, item["record_path"], item)
        for report in item["depends_on"]:
            if by_ref.get(report, {}).get("kind") == "report" and report not in covered:
                if answers is not None and covered & (ancestors(report) | {report}) and _answers_all(
                        root, answers, own_reviews, by_ref, check_read):
                    continue  # research_deliver answered the review of an earlier version
                scope = "、".join(_short(r) for r in sorted(covered)) or "無"
                notices.add(f"final_lca {_short(item['record_path'])} 判定的報告 {_short(report)} 不在它依賴的審查範圍內"
                            f"（它依賴的 kind=review 紀錄涵蓋：{scope}）：Final-LCA 必須判定審查過的那一版。請先審查 "
                            f"{_short(report)}，再另存 Final-LCA（revises 指向這筆），並讓它依賴新的審查紀錄。"
                            + ("Final-LCA 自己的檔案裡有 review.json，但那不算審查：審查要另存成 kind=review 的紀錄"
                               "（files 放 review.json，depends_on 放被審的報告），Final-LCA 再依賴這筆審查紀錄。"
                               if embedded else ""),
                            key=f"lca_unreviewed:{item['record_path']}:{report}")


def _answers_all(root, answers, review_refs, by_ref, check_read):
    """Whether a final_lca.json answers every check its reviews did not support."""
    from researchkit.delivery import answers_cover, review_checks
    try:
        return all(answers_cover(answers, ref, review_checks(root, {**by_ref[ref], "record_path": ref}, check_read)[1])
                   for ref in review_refs)
    except (OSError, ValueError, KeyError):
        return False


def _version_notices(board, saved, ancestors, notices):
    """Formula versions: ambiguous revisions, and deliveries built on an older version."""
    rows = {row["ref"]: row for row in board["proxy_formulas"]}
    by_id = {}
    for row in board["proxy_formulas"]:
        if row["template"] and row["template"]["formula_id"]:
            by_id.setdefault(row["template"]["formula_id"], []).append(row["ref"])
    newer = {}
    for formula_id, refs in by_id.items():
        for older in refs:
            for later in refs:
                if later != older and older in ancestors(later):
                    newer.setdefault(older, []).append(later)
        unlinked = [ref for ref in refs if not any(ref in ancestors(other) or other in ancestors(ref)
                                                   for other in refs if other != ref)]
        if len(refs) > 1 and unlinked:
            which = ("彼此沒有依賴關係" if len(unlinked) == len(refs) else
                     f"其中 {'、'.join(_short(r) for r in unlinked)} 與其他版本沒有依賴關係")
            notices.add(f"proxy_formula {formula_id} 有多份紀錄（{'、'.join(_short(r) for r in refs)}），{which}："
                        "看不出哪一份是現行版本。修訂時請以 research_record 的 revises 指向舊版，或改用不同的 formula_id。",
                        key=f"formula_versions:{formula_id}")
        current = [ref for ref in refs if not rows[ref]["superseded_by"]]
        if len(current) > 1 and not unlinked:
            notices.add(f"proxy_formula {formula_id} 有 {len(current)} 份現行版本（{'、'.join(_short(r) for r in current)}）："
                        "它們都修訂自較舊的版本，但彼此沒有修訂關係，看板都列為現行。若是不同變體（例如有無錨定），"
                        "請改用不同的 formula_id；若其中一份已作廢，下次修訂時讓新版同時依賴兩份（revises 指向一份，"
                        "depends_on 放另一份）。", level="info", key=f"formula_forks:{formula_id}")
    for row in board["proxy_formulas"]:
        newer.setdefault(row["ref"], []).extend(row["later_proxy_formulas"])
    for item in saved:
        if item["kind"] not in DELIVERY_KINDS:
            continue
        used = ancestors(item["record_path"])
        for older, laters in newer.items():
            # A delivery that already uses one newer version is current, even if another revision of the
            # same formula (an abandoned copy, say) is unused; only a delivery that uses none is flagged.
            missing = [later for later in dict.fromkeys(laters) if later not in used]
            if older in used and missing and len(missing) == len(set(laters)):
                notices.add(f"{item['kind']} {_short(item['record_path'])} 依賴 proxy_formula {_short(older)}，"
                            f"但它已有修訂版 {'、'.join(_short(r) for r in missing)}；請確認交付內容是否仍以舊版為準。",
                            key=f"stale:{item['record_path']}:{older}")


def delivery_digest(root, board, record_path, *, check_read=None):
    """What a delivery relies on, stated from saved records for the author to cross-check."""
    saved = {item["record_path"]: item for item in records.inventory(Path(root).resolve(), check_read=check_read)}
    used, pending = set(), list(saved.get(record_path, {}).get("depends_on", []))
    while pending:
        ref = pending.pop()
        if ref not in used and ref in saved:
            used.add(ref)
            pending.extend(saved[ref]["depends_on"])
    lines = []
    for row in board["proxy_formulas"]:
        if row["ref"] in used and row["template"]:
            t = row["template"]
            lines.append(f"proxy_formula {t['formula_id'] or ''}（{_short(row['ref'])}）宣告 "
                         f"{'、'.join(t['hypothesis_ids']) or '無'}；方向 {t['direction'] or '未宣告'}"
                         + (f"（{MECHANISM_TEXT[t['mechanism_predicts']]}）" if t.get("mechanism_predicts") else "")
                         + f"；目標 {t['target_transform'] or '未宣告'}")
    for row in board["hypotheses"]:
        for h in row["items"] or []:
            judged = [j for j in h.get("judgments", []) if j["calibration"] in used]
            if judged:
                lines.append(f"{h['id']} 的作者判斷：" + "、".join(
                    f"{j['effect']}（calibration {_short(j['calibration'])}）" for j in judged))
    for row in board.get("leaderboards", []):
        if row["ref"] in used:
            lines += [line.strip("- ").strip() for line in _leaderboard_rows(row)]
    for row in board.get("simulations", []):
        if row["ref"] in used:
            lines.append(_simulation_text(row) + ("：" + "；".join(_preview(w, 120) for w in row["warnings"][:3])
                                                  if row["warnings"] else ""))
    for evolution in board["evolutions"]:
        if evolution["ref"] in used:
            signals = evolution.get("signals") or {}
            lines.append(f"演化 {_short(evolution['ref'])}：{len(evolution['rounds'])} 輪，各輪最佳分數 "
                         f"{signals.get('best_by_round') or '無宿主比較'}；宣稱超越：{'是' if evolution['claims_surpass'] else '否'}；"
                         f"破同分規則：{evolution.get('tie_break') or '未宣告'}")
            if signals:
                lines.append("探索／收斂訊號：" + _signal_text(signals))
    return lines


def _round_result(round_, comparisons, leaderboards):
    """Best primary-sheet result of one round, from a host comparison or leaderboard."""
    board_row = leaderboards.get(round_["leaderboard_ref"])
    if board_row:
        sheet = next((s for s in board_row["sheets"] if s.get("primary")), None) or next(
            (s for s in board_row["sheets"] if s.get("evidence", "history") == "history"), board_row["sheets"][0])
        if "model" in sheet:
            # A quantitative model's sheet has no single value per candidate to track across rounds.
            return {"value": None, "oriented": None, "tied": [], "outside": sheet["outside_baseline_range"],
                    "disputed": board_row["most_disputed"],
                    "verdicts": {c["id"]: c["verdict"] for c in board_row["candidates"]}, "margins": {},
                    "sheet": sheet, "baselines": board_row["baseline_ids"],
                    "surpass": any(c["verdict"] in SURPASS for c in board_row["candidates"])}
        score = lambda v: orient(v, sheet["direction"], sheet.get("target_value"))
        value = max((sheet["values"][c] for c in board_row["candidate_ids"]), key=score)
        return {"value": value, "oriented": score(value), "tied": sheet["tied_best_candidates"],
                "outside": sheet["outside_baseline_range"], "disputed": board_row["most_disputed"],
                "verdicts": {c["id"]: c["verdict"] for c in board_row["candidates"]},
                "margins": {c["id"]: (c.get("margins") or {}).get(sheet["formula_id"] or sheet["formula_ref"])
                            for c in board_row["candidates"]},
                "sheet": sheet, "baselines": board_row["baseline_ids"],
                "surpass": any(c["verdict"] in SURPASS for c in board_row["candidates"])}
    row = comparisons.get(round_["comparison_ref"])
    if row:
        sign = 1 if row.get("direction") != "lower" else -1
        value = row["best_candidate"]["value"]
        tied = row["best_candidate"]["ids"] if len(row["best_candidate"]["ids"]) > 1 else []
        return {"value": value, "oriented": sign * value if isinstance(value, (int, float)) else None,
                "tied": tied, "outside": None, "disputed": [], "verdicts": {}, "margins": {},
                "surpass": row["comparison"] == "better"}
    return None


def _margin_notice(label, ref, winners, last, notices):
    """A surpass smaller than SMALL_MARGIN of the pool range, with a ready calc input to check it."""
    small = [c for c in winners if isinstance((last["margins"].get(c) or {}).get("of_pool_range"), (int, float))
             and last["margins"][c]["of_pool_range"] < SMALL_MARGIN]
    if not small:
        return
    sheet = last["sheet"]
    best = sheet["best_baselines"]
    name = sheet["formula_id"] or _short(sheet["formula_ref"])
    example = {"sheets": {name: {"values": {s: sheet["values"][s] for s in [*best, *small]},
                                 "direction": sheet["direction"], "sd": "<量測或模型誤差>"}},
               "baseline_ids": best, "candidate_ids": small}
    gaps = "、".join(f"{c} 領先 {last['margins'][c]['better_by']:.3g}（池內範圍的 "
                    f"{last['margins'][c]['of_pool_range']:.0%}）" for c in small)
    notices.add(f"{label} 的超越幅度很小：主 sheet {name} 上 {gaps}。若量測或模型誤差可能有這麼大，超越未必成立；"
                "可用 calc kind=sensitivity 檢查，例如 input " + json.dumps(example, ensure_ascii=False),
                level="info", key=f"margin:{ref}")


def _evolution_progress_notices(board, notices):
    """Ties, stagnation and the exploration / exploitation signals of each evolution."""
    comparisons = {row["ref"]: row for row in board["comparisons"]}
    leaderboards = {row["ref"]: row for row in board.get("leaderboards", [])}
    for row in board["comparisons"]:
        if len(row["best_candidate"]["ids"]) > 1:
            notices.append(f"候選比較 {_short(row['ref'])} 的最佳候選同分（{'、'.join(row['best_candidate']['ids'])}"
                           f"={row['best_candidate']['value']}）：請用事先宣告的破同分規則排名，或在報告中寫明同分。")
    for evolution in board["evolutions"]:
        label = f"{evolution['kind']} {_short(evolution['ref'])}"
        results = [_round_result(r, comparisons, leaderboards) for r in evolution["rounds"]]
        scored = [(r, res) for r, res in zip(evolution["rounds"], results) if res and res["oriented"] is not None]
        oriented = [res["oriented"] for _, res in scored]
        last = scored[-1][1] if scored else None
        stalled = [scored[i][0]["round"] for i in range(1, len(scored)) if oriented[i] <= oriented[i - 1]]
        formula = next((f for f in board["proxy_formulas"] if f["ref"] == evolution["primary_formula_ref"]), None)
        evidence = [f"n={c['sample_count']}" for c in (formula or {}).get("calibrations", [])]
        evolution["signals"] = {
            "rounds_scored": len(scored), "rounds_declared": len(evolution["rounds"]),
            "best_by_round": [res["value"] for _, res in scored], "stalled_rounds": stalled,
            "tied_best": last["tied"] if last else [], "outside_history": (last or {}).get("outside") or [],
            "most_disputed": last["disputed"] if last else [], "goal_met": any(res["surpass"] for _, res in scored),
            "levers": [r["levers"] for r in evolution["rounds"]],
            "strategies": [r["strategy"] for r in evolution["rounds"]], "calibration": evidence,
        }
        values = [res["value"] for _, res in scored]
        if len(values) >= 2:
            if len(set(values)) == 1:
                text = f"{label} 各輪最佳候選分數都是 {values[0]}：後續輪次沒有提高分數，候選之間同分。"
                if evolution.get("tie_break"):
                    notices.add(text + f"已宣告破同分規則：{_preview(evolution['tie_break'], 120)}", level="info")
                else:
                    notices.append(text + "請在 evolution.json 的 tie_break 寫明事先決定的破同分規則，"
                                   "或在報告中寫明同分與其意義。")
            elif max(oriented[1:]) <= oriented[0]:
                notices.add(f"{label} 第 1 輪之後的輪次沒有提高最佳分數（{values}）。", level="info")
        rounds = evolution["rounds"]
        for i in range(1, len(rounds) - 1):
            if (rounds[i]["round"] in stalled and rounds[i + 1]["strategy"] == "exploit"
                    and rounds[i + 1]["levers"] and rounds[i + 1]["levers"] == rounds[i]["levers"]):
                notices.add(f"{label} 第 {rounds[i]['round']} 輪停滯後，第 {rounds[i + 1]['round']} 輪仍宣告 exploit，"
                            f"且沿用同一槓桿（{'、'.join(rounds[i]['levers'])}）。", level="info")
        if evolution["claims_surpass"] and last and last["verdicts"]:
            winners = [c for c, v in last["verdicts"].items() if v in SURPASS]
            conditional = [c for c, v in last["verdicts"].items() if v == "conditional_surpass"]
            if winners and all(last["verdicts"][c] == "surpass_one_sheet" for c in winners):
                notices.add(f"{label} 宣稱超越，但只有一張有歷史差異的 sheet 能比較（{'、'.join(winners)}）："
                            "這是單張 sheet 的超越，不能稱為穩健。", level="info")
            elif winners and not any(last["verdicts"][c] == "robust_surpass" for c in winners):
                notices.add(f"{label} 宣稱超越，但最後一輪的超越候選（{'、'.join(winners)}）都有 sheet 落後：超越並不穩健。",
                            level="info")
            if not winners and conditional:
                notices.add(f"{label} 宣稱超越，但最後一輪只有條件式超越（{'、'.join(conditional)}）：只在歷史同分或"
                            "LLM 評審的 sheet 上領先，報告須寫成「若該假說成立」。", level="info")
            _margin_notice(label, evolution["ref"], winners, last, notices)
            if winners and last["outside"] and set(winners) <= set(last["outside"]):
                notices.add(f"{label} 宣稱超越的候選（{'、'.join(winners)}）在主 sheet 上都超出歷史樣本範圍：屬於外推。",
                            level="info")
        missing = [r["round"] for r in rounds if not r["strategy"]]
        if missing and any(r["leaderboard_ref"] for r in rounds):
            notices.add(f"{label} 第 {'、'.join(str(m) for m in missing)} 輪未宣告 strategy（explore／exploit）。",
                        level="info")


def _graph(root, check_read, requirements, notices):
    try:
        ref, revision = graph.GraphStore(root, check_read=check_read).read()
    except (OSError, ValueError) as exc:
        notices.append(f"推理圖無法讀取：{_preview(exc)}")
        return None
    if revision is None:
        return None
    state = revision["state"]
    direct, indirect = graph.flags(state, requirements=requirements)
    return {"revision_ref": ref, "revision": revision["revision"], "nodes": state["nodes"],
            "needs_review": direct, "indirectly_affected": indirect,
            "notice_replies": state.get("notice_replies") or {}}


def _sheet_label(sheet):
    return f"{sheet['formula_id'] or _short(sheet['formula_ref'])}（{'、'.join(sheet['hypothesis_ids']) or '未宣告'}）"


def _scale_notices(sheet):
    """Notices from the host's scale check of a sheet whose formula predicts a measured quantity."""
    check, label = sheet.get("scale_check"), sheet.get("formula_id") or _short(sheet.get("formula_ref") or "")
    if not isinstance(check, dict):
        return []
    found = []
    if check.get("status"):
        found.append((f"{label} 的尺度檢查：{check['status']}", "scale_status"))
    offset, spread = check.get("mean_offset"), check.get("residual_spread")
    target = sheet.get("target_value")
    if isinstance(offset, (int, float)) and not check.get("anchored"):
        tolerance = abs(target) * 0.05 if isinstance(target, (int, float)) and target else 0
        if abs(offset) > max(tolerance, spread or 0):
            residuals = "、".join(f"{s} 預測 {check['predicted'][s]:g}／量測 {check['measured'][s]:g}"
                                  for s in check.get("compared_baselines", []))
            found.append((f"{label} 對歷史樣本的預測偏離量測（{residuals}；平均偏差 {offset:+g}）。預測不在量測尺度上，"
                          "「與目標的距離」排名不可信。若誤差主要是固定偏移，可在 proxy_formula.json 宣告 anchor "
                          '（"mean_offset" 或 {"reference_sample": "<歷史樣本>"}）由宿主校準；若斜率也錯，校準修不好。',
                          "scale_offset"))
    if check.get("order_disagreements"):
        pairs = "、".join(f"{a}／{b}" for a, b in check["order_disagreements"])
        found.append((f"{label} 對歷史樣本的高低順序與量測相反（{pairs}）：這是斜率或方向問題，偏移校準無法修正。",
                      "scale_order"))
    return found


def _leaderboard_rows(row):
    sheets = "、".join(_sheet_label(s) + ("★主" if s.get("primary") else "")
                      + (f"〔{EVIDENCE_LABEL.get(s['evidence'], s['evidence'])}〕" if s.get("evidence") else "")
                      for s in row["sheets"])
    rows = [f"- leaderboard {_short(row['ref'])}：sheets {sheets}；前緣 {'、'.join(row['pareto_front'])}"
            f"（{round(row['front_ratio'] * 100)}%）"]
    for verdict, name in (("robust_surpass", "穩健超越"), ("surpass_one_sheet", "單張 sheet 的超越"),
                          ("tradeoff_surpass", "有取捨的超越")):
        found = [c for c in row["candidates"] if c["verdict"] == verdict]
        if found:
            rows.append(f"  {name}：" + "；".join(
                c["id"] + (f"（落後於 {'、'.join(c['worse_on'])}）" if c["worse_on"] else "") for c in found))
    found = [c for c in row["candidates"] if c["verdict"] == "conditional_surpass"]
    if found:
        rows.append("  條件式超越：" + "；".join(
            c["id"] + "（若 " + "、".join("/".join(x["hypothesis_ids"]) or x["sheet"] for x in c["conditional_on"])
            + " 成立）" for c in found))
    taus = "；".join(f"{'/'.join(a['sheets'])} τ={a['kendall_tau_b']:.2f}" if a["kendall_tau_b"] is not None
                     else f"{'/'.join(a['sheets'])} τ=無法計算" for a in row["sheet_agreement"])
    if taus:
        rows.append("  sheet 一致度：" + taus)
    if row["most_disputed"]:
        rows.append("  各 sheet 分歧最大（最能分辨假說，建議優先實測）：" + "、".join(row["most_disputed"]))
    return rows


def _signal_text(signals):
    parts = [f"各輪主 sheet 最佳 {signals['best_by_round'] or '無'}"]
    if signals["stalled_rounds"]:
        parts.append(f"停滯於第 {'、'.join(map(str, signals['stalled_rounds']))} 輪")
    if signals["tied_best"]:
        parts.append(f"同分 {'、'.join(signals['tied_best'])}")
    if signals["outside_history"]:
        parts.append(f"外推 {'、'.join(signals['outside_history'])}")
    if signals["most_disputed"]:
        parts.append(f"分歧 {'、'.join(signals['most_disputed'])}")
    parts.append(f"計分 {'、'.join(signals['calibration']) or '無'}")
    levers = [("、".join(l) if l else "未宣告") for l in signals["levers"]]
    parts.append(f"槓桿 {' → '.join(levers) or '無'}")
    parts.append(f"已計分 {signals['rounds_scored']}/{signals['rounds_declared']} 輪；"
                 f"主 sheet 超越：{'已達成' if signals['goal_met'] else '未達成'}")
    return "；".join(parts)


def _derived_rows(board):
    """Graph nodes the host derives from saved records and templates."""
    rows = [f"由紀錄推導：決策 {len(board['decisions'])}、疑問 {len(board['questions'])}（心智圖缺口）、"
            f"演化 {len(board['evolutions'])}"]
    rows += [f"- 決策 {item['id']}：{_preview(item['text'], 200)}" for item in board["decisions"]]
    questions = board["questions"]
    rows += [f"- 疑問 {item['id']}：{_preview(item['text'], 100)}" for item in questions[:5]]
    if len(questions) > 5:
        rows.append(f"- 另有 {len(questions) - 5} 條心智圖缺口未列出。")
    return rows


def _graph_rows(value):
    if value is None:
        return ["- 尚無手動記錄的節點（選用；只有推導不出的疑問、決策或狀態變更才需要 research_graph_update）。"]
    nodes = value["nodes"]
    live = [n for n in nodes.values() if not n.get("superseded_by")]
    rows = [f"revision {value['revision']}：`{value['revision_ref']}`；節點 {len(live)}（另有 "
            f"{len(nodes) - len(live)} 個已被取代）"]
    for identifier, reasons in sorted(value["needs_review"].items()):
        node = nodes[identifier]
        rows.append(f"- 需要重看 {node['type']} {identifier}：{_preview(node['text'], 100)}；原因：" + "；".join(reasons))
    if value["indirectly_affected"]:
        rows.append("- 間接受影響（待上游處理後再看）：" + "、".join(value["indirectly_affected"]))
    from researchkit.host_source import DOC_GAP
    gaps = [n for n in live if n["type"] == "question" and n["text"].startswith(DOC_GAP)]
    if gaps:
        rows.append("- 文件缺口（給框架維護者，不是科學問題）：" + "；".join(
            f"{n['id']} {_preview(n['text'][len(DOC_GAP):], 100)}" for n in gaps))
    order = {"decision": 0, "conjecture": 1, "question": 2, "observation": 3}
    for node in sorted(live, key=lambda n: (order[n["type"]], n["id"])):
        if node in gaps:
            continue
        if node["type"] == "question" and node["status"] != "open":
            continue
        if node["type"] == "observation" and node["status"] == "valid":
            continue
        evidence = ""
        if node["type"] == "conjecture":
            sup = [o["id"] for o in nodes.values() if not o.get("superseded_by") and o["status"] == "valid"
                   and any(e["to"] == node["id"] and e["type"] == "supports" for e in o["edges"])]
            con = [o["id"] for o in nodes.values() if not o.get("superseded_by") and o["status"] == "valid"
                   and any(e["to"] == node["id"] and e["type"] == "contradicts" for e in o["edges"])]
            evidence = f"；支持 {'、'.join(sup) or '無'}；反駁 {'、'.join(con) or '無'}"
        rows.append(f"- {node['type']} {node['id']}（{node['status']}）：{_preview(node['text'], 120)}{evidence}")
    valid = [n["id"] for n in live if n["type"] == "observation" and n["status"] == "valid"]
    if valid:
        rows.append(f"- 有效 observation {len(valid)} 個：" + "、".join(valid[-12:]))
    return rows


CURRENT_FORMULA_ROWS = 8


def _current_rows(board):
    """The current version of each hypothesis set and formula, and the newest deliveries.

    Short on purpose: it comes first, so it survives the size limit and a compacted conversation.
    """
    rows = []
    hypotheses = [row for row in board["hypotheses"] if not row.get("superseded_by")]
    for row in hypotheses:
        items = row["items"]
        merged = sum(1 for h in items or [] if h.get("merged"))
        counts = (f"主動 {sum(1 for h in items if not h['deferred'] and not h['not_computable'] and not h.get('merged'))}、"
                  f"排隊 {sum(1 for h in items if h['deferred'])}、"
                  f"無法計算 {sum(1 for h in items if h['not_computable'])}"
                  + (f"、合併 {merged}" if merged else "")) if items else "未附可用的假說模板"
        rows.append(f"- 假說紀錄 {_short(row['ref'])}：{counts}")
    formulas = [row for row in board["proxy_formulas"] if not row.get("superseded_by")]
    for row in formulas[:CURRENT_FORMULA_ROWS]:
        t = row["template"]
        if t:
            direction = t["direction"] or "未宣告"
            if t["direction"] == "target":
                direction += f"（目標 {t['target_value']:g}" + ("，已指明 measured）" if t["measured"] else "，未指明 measured）")
            if t.get("mechanism_predicts"):
                direction += f"（{MECHANISM_TEXT[t['mechanism_predicts']]}）"
            text = f"{t['formula_id'] or '未命名'}（{'、'.join(t['hypothesis_ids']) or '無假說'}），方向 {direction}"
            if t.get("anchor"):
                anchor = t["anchor"]
                text += "，錨定 " + (anchor if isinstance(anchor, str) else _preview(json.dumps(anchor, ensure_ascii=False), 60))
        else:
            text = _preview(row["title"], 80)
        check = row.get("history_check")
        flags = [flag for flag in (check or {}).get("flags", []) if flag != "order_unchecked"]
        if not check:
            history = "尚未做歷史檢查" if _measured_kpi(board) else "沒有量測可檢查，只有機制依據"
        elif not check["order_checked"]:
            # v22's board said "kpi not declared" for a formula that declared it but was checked on one sample.
            declared = bool(t and (t["kpi"] or t["measured"]))
            reason = UNCHECKED_ORDER.get(check.get("order_reason") or ("" if declared else "undeclared"), "")
            history = f"歷史檢查：順序未檢查{reason}" + (f"；{'、'.join(flags)}" if flags else "")
        else:
            history = "歷史檢查 " + ("、".join(flags) if flags else "順序與實測一致")
        rows.append(f"- 公式 {_short(row['ref'])}：{text}；計分 {len(row['calibrations'])} 筆；{history}")
    if len(formulas) > CURRENT_FORMULA_ROWS:
        rows.append(f"- 另有 {len(formulas) - CURRENT_FORMULA_ROWS} 條現行公式，見「假說與代理公式」。")
    old_hypotheses = len(board["hypotheses"]) - len(hypotheses)
    old_formulas = len(board["proxy_formulas"]) - len(formulas)
    if old_hypotheses or old_formulas:
        rows.append(f"- 已被修訂取代、看板不再列出的舊版：假說紀錄 {old_hypotheses}、公式 {old_formulas}"
                    "（research_board 與 research_list 仍回傳全部）")
    deliveries = board.get("deliveries") or {}
    parts = []
    for kind in ("report", "final_lca", "user_report"):
        refs = deliveries.get(kind) or []
        parts.append(f"{kind} " + ((_short(refs[-1]) + (f"（共 {len(refs)} 份）" if len(refs) > 1 else ""))
                                  if refs else "無"))
    rows.append("- 最新交付（依保存時間）：" + "；".join(parts))
    return rows


def _replaced(row):
    return f"；已被 {'、'.join(_short(r) for r in row['superseded_by'])} 取代" if row.get("superseded_by") else ""


def _sections(board, full=False):
    humans = board["humans"]
    human_rows = [f"真正人類訊息共 {len(humans)} 則（原文保存在會話，看板只列短述）："]
    human_rows += [f"- {row['id']}：{_preview(row['text'], 300)}" for row in humans[-5:]]
    if len(humans) > 5:
        human_rows.append(f"- 較早的 {len(humans) - 5} 則未列出。")
    human_rows += [f"- task {_short(t['ref'])}：{_preview(t['title'])}" for t in board["tasks"]] or ["- task 紀錄：無"]

    hypothesis_rows = []
    for row in board["hypotheses"]:
        if row.get("superseded_by") and not full:
            continue
        hypothesis_rows.append(f"- hypothesis {_short(row['ref'])}：{_preview(row['title'])}；"
                               f"依賴它的 proxy_formula：{len(row['proxy_formula_refs'])}{_replaced(row)}")
        if row["items"] is None:
            hypothesis_rows.append(f"  未附可用的 {HYPOTHESES_FILE}，無法逐條對應。")
        for h in row["items"] or []:
            linked = "、".join(_short(r) for r in h["proxy_formula_refs"]) or "無"
            judged = "；".join(f"{j['effect']}（calibration {_short(j['calibration'])}，作者判斷）"
                              for j in h.get("judgments", []))
            facts = h.get("lever_facts") or {}
            lever_text = "、".join(f"{name}" + {"varies": "（歷史有變化）", "constant": "（歷史相同）",
                                                  "missing": "（表中沒有）"}[state] for name, state in facts.items())
            hypothesis_rows.append(f"  {h['id']}：{_preview(h['statement'], 120)}；"
                                   + ("排隊（預算）" if h.get("deferred") else f"併入 {h['merged']}" if h.get("merged")
                                      else f"對應公式：{linked}")
                                   + (f"；槓桿 {lever_text}" if lever_text else "")
                                   + (f"；{judged}" if judged else ""))
    for row in board["proxy_formulas"]:
        if row.get("superseded_by") and not full:
            continue
        template = row["template"]
        label = (f"{template['formula_id'] or ''} {_preview(template['expression'], 120)}；"
                 f"hypothesis_ids：{'、'.join(template['hypothesis_ids']) or '無'}") if template else _preview(row["title"])
        scores = "；".join(f"τ_b={c['kendall_tau_b']} ρ={c['spearman_rho']} n={c['sample_count']}"
                           + (f" p={c['p_two_sided']:.3g}" if c.get("p_two_sided") is not None else "")
                           for c in row["calibrations"]) or "尚無計分"
        later = (f"；已有後續 proxy_formula 依賴它：{len(row['later_proxy_formulas'])}"
                 if row["later_proxy_formulas"] else "")
        hypothesis_rows.append(f"- proxy_formula {_short(row['ref'])}：{label}；{scores}{later}{_replaced(row)}")
    if not hypothesis_rows:
        hypothesis_rows = ["- 尚無 hypothesis 或 proxy_formula 紀錄。"]

    comparison_rows = [
        f"- method {_short(c['method_ref'])}（{c['direction']}）：最佳候選 {'、'.join(c['best_candidate']['ids'])}"
        f"={c['best_candidate']['value']}，最佳基準 {'、'.join(c['best_baseline']['ids'])}"
        f"={c['best_baseline']['value']}，結果 {c['comparison']}；{_short(c['ref'])}"
        for c in board["comparisons"]]
    for row in board.get("leaderboards", []):
        comparison_rows += _leaderboard_rows(row)
    for row in board.get("judgments", []):
        agreement = row["agreement_kendall_tau_b"]
        comparison_rows.append(f"- LLM 評審 {_short(row['ref'])}：假說 {row['hypothesis_id']}，{row['repeats_used']} 次盲測，"
                               f"一致度 τ_b={'無法計算' if agreement is None else f'{agreement:.2f}'}；"
                               f"未讀取的引用 {len(row['unfetched_citations'] or [])} 個")
    for row in board.get("calcs", []):
        comparison_rows += [f"- calc {_short(row['ref'])}（{r['kind']}）：{_preview(r['conclusion'], 240)}"
                            for r in row["results"]]
    simulations = board.get("simulations", [])
    if len(simulations) > 5 and not full:
        comparison_rows.append(f"- simulation 共 {len(simulations)} 筆，以下列最後 5 筆；全部見 research_board。")
    comparison_rows += [f"- {_simulation_text(row)}" for row in (simulations if full else simulations[-5:])]
    for evolution in board["evolutions"]:
        compared = sum(1 for r in evolution["rounds"] if r["comparison_ref"] or r["leaderboard_ref"])
        comparison_rows.append(f"- 演化 {_short(evolution['ref'])}：{len(evolution['rounds'])} 輪，其中 {compared} 輪有宿主比較；"
                               f"宣稱超越：{'是' if evolution['claims_surpass'] else '否'}")
        if evolution.get("signals"):
            comparison_rows.append("  探索／收斂訊號：" + _signal_text(evolution["signals"]))
    for kind, rows in sorted(board["other_kinds"].items()):
        comparison_rows.append(f"- 其他 kind {kind}：{len(rows)} 筆，宿主未核對其中數值；"
                               + "、".join(f"{_short(r['ref'])} {_preview(r['title'], 80)}" for r in rows[-3:]))
    if not comparison_rows:
        comparison_rows = ["- 尚無候選比較紀錄。"]

    other_rows = [f"- mindmap {_short(m['ref'])}：{_preview(m['title'])}" for m in board["mindmaps"]]
    if board["open_checkpoints"]:
        other_rows.append(f"- 尚未被後續紀錄使用的 mindmap_checkpoint：{len(board['open_checkpoints'])}")
    for review in board["reviews"]:
        scope = ("、".join(_short(r) for r in review["reviewed_refs"]) if review["reviewed_refs"] is not None
                 else "未讀到 reviewed_refs")
        other_rows.append(f"- review {_short(review['ref'])}：審查範圍 {scope}")
    if not other_rows:
        other_rows = ["- 尚無心智圖或審查紀錄。"]
    items = board.get("notice_items", [])
    action_rows = [f"- [{item['id']}] {_preview(item['text'], 300)}" for item in items
                   if item["level"] == "action" and not item["reply"]] or ["- 無"]
    action_rows.append("處理後或判斷不適用時，可用 research_graph_update 的 notice_replies 寫明理由。")
    info_rows = [f"- [{item['id']}] 已回覆：{_preview(item['text'], 160)}；理由：{_preview(item['reply'], 160)}"
                 for item in items if item["reply"]]
    info_rows += [f"- {_preview(item['text'], 300)}" for item in items
                  if item["level"] == "info" and not item["reply"]]
    return [("現行版本（舊版不列）", _current_rows(board)),
            ("委託與任務", human_rows),
            ("需要處理的提醒（機械比對，不是科學判斷）", action_rows),
            ("推理圖（需要重看的節點優先）", _graph_rows(board["graph"]) + _derived_rows(board)),
            ("假說與代理公式", hypothesis_rows),
            ("候選與樣本比較", comparison_rows), ("心智圖與審查", other_rows),
            ("資訊性提醒與已回覆", info_rows or ["- 無"])]


def render(board, *, limit=MAX_CONTEXT_BYTES, full=False) -> str:
    """Bounded summary. Rows that do not fit are counted, never silently dropped.

    full: the research_board view, with no size limit and replaced versions listed and marked.
    """
    if full:
        limit = float("inf")
        prefix = [TITLE, "完整看板（含已被修訂取代的舊版）。紀錄以 record 雜湊前 8 碼標示，可直接當作紀錄參照；"
                         "原文以精確 record.json 為準。"]
    else:
        prefix = [TITLE, "紀錄以 record 雜湊前 8 碼標示；完整內容用 research_board 讀取，原文以精確 record.json 為準。"]
    sections = _sections(board, full)
    omission_bound = "\n".join(f"{label}：尚有 {len(rows)} 項未列出。" for label, rows in sections)
    remaining = limit - len(("\n".join(prefix) + "\n" + omission_bound + "\n").encode("utf-8"))
    body, omitted, full = [], [], False
    for label, rows in sections:
        heading = f"\n{label}："
        if full or len((heading + "\n" + rows[0] + "\n").encode("utf-8")) > remaining:
            omitted.append(f"{label}：尚有 {len(rows)} 項未列出。")
            full = True
            continue
        body.append(heading)
        remaining -= len((heading + "\n").encode("utf-8"))
        for index, row in enumerate(rows):
            size = len((row + "\n").encode("utf-8"))
            if size > remaining:
                omitted.append(f"{label}：尚有 {len(rows) - index} 項未列出。")
                full = True
                break
            body.append(row)
            remaining -= size
    return "\n".join([*prefix, *body, *([""] + omitted if omitted else [])])


def configured_budget(config):
    """research.hypothesis_budget from the app configuration, or None for the default."""
    research = config.get("research") if isinstance(config, dict) else None
    return research.get("hypothesis_budget") if isinstance(research, dict) else None


def context(root: Path, history, *, check_read=None, requirements=None, hypothesis_budget=None) -> str:
    board = build(root, history=history, check_read=check_read, requirements=requirements,
                  hypothesis_budget=hypothesis_budget)
    if not any(board[key] for key in ("tasks", "hypotheses", "proxy_formulas", "comparisons",
                                      "other_kinds", "mindmaps", "reviews", "graph", "simulations")):
        return ""
    return render(board)
