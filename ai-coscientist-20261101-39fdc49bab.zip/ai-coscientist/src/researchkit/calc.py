"""calc: quick, deterministic calculations that are easy to get wrong by reasoning alone.

One call returns a one-line conclusion first, then details. Every call saves its
exact input and result under .research/calc/ as a draft; a draft becomes
citable evidence only when that file is saved with research_record (kind="calc").

Scripts use the same calculations: `from researchkit import calc`, then for example
`r = calc.stats(x=[...], y=[...]); print(r); r.save(".research/calc/my_stats.json")`.
"""

from __future__ import annotations

import hashlib
import heapq
import itertools
import json
import math

import numpy as np

from researchkit import calc_expr as ex
from researchkit import scoring
from researchkit.calc_expr import ExprError


VERSION = 1
CALC_DIR = ".research/calc"
MAX_DRAWS = 20000
EXACT_SPLITS = 100000
BOX_BUDGET = 4000
EXAMPLES = {
    "stats": {"x": [2.1, 3.0, 3.4, 4.8], "y": [10, 12, 11, 15]},
    "sensitivity": {"sheets": {"P1": {"values": {"h1": 2.0, "h2": 3.5, "s1": 3.7}, "direction": "higher",
                                      "sd": 0.3}},
                    "baseline_ids": ["h1", "h2"], "candidate_ids": ["s1"]},
    "interval": {"expr": "12 - k*(x - 2)", "ranges": {"k": [0.5, 1.5], "x": [2, 3]}},
    "logic": {"premises": ["y = 12 - k*(x - 2)", "0.5 <= k <= 1.5"], "goal": "x <= 3 -> y >= 10"},
    "properties": {"module": "work/model.py", "function": "score", "output": "0",
                   "checks": [{"finite": ["A", "B"]},
                              {"greater": [["A", "B"]], "why": "the mechanism ranks A above B"}]},
    "causal": {"rows": {"r1": {"catalyst": "X", "T": 300}, "r2": {"catalyst": "Y", "T": 320}},
               "factors": ["catalyst", "T"], "target": "catalyst"},
    "constant": {"names": ["R", "F"]},
    "units": {"expr": "Ea/(R*T)", "units": {"Ea": "kJ/mol", "R": "J/(mol*K)", "T": "K"}},
    "design": {"existing": {"r1": {"catalyst": "X", "T": 300}, "r2": {"catalyst": "Y", "T": 320}},
               "candidates": {"c1": {"catalyst": "X", "T": 320}, "c2": {"catalyst": "Y", "T": 300}}, "pick": 1},
    "roles": {"structures": {"L1": "c1ccncc1", "A1": "CC(=O)[O-]", "M1": "[Na+]"},
              "components": {"L1": ["L1"], "salt": ["M1", "A1"]},
              "features": {"pyridine": "n1ccccc1", "carboxylate": "[O-]C=O"},
              "roles": {"ligand": {"requires": ["pyridine"], "source": "the ligand is a pyridine"},
                        "base": {"requires": ["carboxylate"], "source": "the base is a carboxylate"}},
              "assigned": {"L1": "ligand", "salt": "base"}},
}
KINDS = tuple(EXAMPLES)


class CalcError(ValueError):
    pass


def _fail(kind, message):
    raise CalcError(f"calc {kind}: {message}\nExample input: {json.dumps(EXAMPLES[kind], ensure_ascii=False)}")


def _seed(kind, data):
    blob = json.dumps({"kind": kind, "input": data}, sort_keys=True, ensure_ascii=False, default=str)
    return int(hashlib.sha256(blob.encode("utf-8")).hexdigest()[:12], 16)


def _number(value, label, kind):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        _fail(kind, f"{label} must be a finite number, got {value!r}")
    return float(value)


def _numbers(value, label, kind, minimum=1):
    if not isinstance(value, list) or len(value) < minimum:
        _fail(kind, f"{label} must be a list of at least {minimum} numbers")
    return [_number(v, f"{label}[{i}]", kind) for i, v in enumerate(value)]


def _range(value, label, kind):
    if not isinstance(value, list) or len(value) != 2:
        _fail(kind, f"{label} must be [low, high]")
    low, high = (_number(v, label, kind) for v in value)
    if low > high:
        _fail(kind, f"{label}: low {low} is above high {high}")
    return low, high


def _draws(data, kind, default=2000):
    draws = data.get("draws", default)
    if isinstance(draws, bool) or not isinstance(draws, int) or not 100 <= draws <= MAX_DRAWS:
        _fail(kind, f"draws must be an integer from 100 to {MAX_DRAWS}")
    return draws


def _fmt(value):
    if value is None:
        return "undefined"
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return f"{value:.4g}"


def _expr(text, label, kind):
    try:
        node = ex.parse(text, label)
        sorts = {}
        ex.infer(node, "bool" if ex.is_condition(node) else "num", sorts, label)
    except ExprError as exc:
        _fail(kind, str(exc))
    return node, sorts


# ---- stats ----

def _stats(data, seed):
    kind = "stats"
    if "x" in data or "y" in data:
        x, y = _numbers(data.get("x"), "x", kind, 2), _numbers(data.get("y"), "y", kind, 2)
        if len(x) != len(y):
            _fail(kind, "x and y must have the same length (paired samples)")
        tau = scoring.tau_b(x, y)
        ranks_x, ranks_y = scoring._ranks(x), scoring._ranks(y)
        rho = _pearson(ranks_x, ranks_y)
        permutation = scoring.permutation_tau(x, y, sign=-1 if (tau or 0) < 0 else 1, seed=seed)
        result = {"n": len(x), "kendall_tau_b": tau, "spearman_rho": rho, "permutation_p": permutation}
        if permutation is None:
            result["conclusion"] = "Rank correlation is undefined: x or y is constant."
            return result
        text = (f"Kendall tau-b = {_fmt(tau)}, Spearman rho = {_fmt(rho)} (n = {len(x)}); "
                f"permutation p two-sided = {_fmt(permutation['two_sided'])}, "
                f"one-sided in the observed direction = {_fmt(permutation['one_sided'])}.")
        smallest = permutation["smallest_possible_two_sided"]
        if smallest is not None and smallest >= 0.05:
            text += (f" With n = {len(x)} no ordering can reach two-sided p < 0.05 "
                     f"(smallest possible p = {_fmt(smallest)}): this data cannot distinguish the relation from chance.")
        result["conclusion"] = text
        return result
    if "groups" in data:
        groups = data["groups"]
        if not isinstance(groups, dict) or len(groups) != 2:
            _fail(kind, "groups must name exactly two groups, e.g. {\"A\": [..], \"B\": [..]}")
        (name_a, a), (name_b, b) = [(k, _numbers(v, f"groups.{k}", kind)) for k, v in groups.items()]
        return _groups(name_a, a, name_b, b, seed)
    if "values" in data:
        values = _numbers(data["values"], "values", kind)
        array = np.array(values)
        result = {"n": len(values), "mean": float(array.mean()), "min": float(array.min()), "max": float(array.max()),
                  "sd": float(array.std(ddof=1)) if len(values) > 1 else None}
        if len(values) >= 3:
            rng = np.random.default_rng(seed)
            means = rng.choice(array, size=(5000, len(values))).mean(axis=1)
            result["bootstrap_95"] = [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]
        result["conclusion"] = (f"n = {len(values)}, mean = {_fmt(result['mean'])}, sd = {_fmt(result['sd'])}"
                                + (f", bootstrap 95% interval of the mean [{_fmt(result['bootstrap_95'][0])}, "
                                   f"{_fmt(result['bootstrap_95'][1])}]" if "bootstrap_95" in result else
                                   "; too few values for an interval") + ".")
        return result
    _fail(kind, "give x and y (paired), groups (two groups) or values (one sample)")


def _pearson(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if a.std() == 0 or b.std() == 0:
        return None
    return float(np.corrcoef(a, b)[0, 1])


def _groups(name_a, a, name_b, b, seed):
    pooled = np.array(a + b)
    observed = float(np.mean(b) - np.mean(a))
    n, k = len(pooled), len(a)
    total_splits = math.comb(n, k)
    eps = 1e-12 * max(1.0, abs(observed))
    if total_splits <= EXACT_SPLITS:
        diffs = []
        for chosen in itertools.combinations(range(n), k):
            mask = np.zeros(n, bool)
            mask[list(chosen)] = True
            diffs.append(pooled[~mask].mean() - pooled[mask].mean())
        diffs = np.abs(np.array(diffs))
        p = float(np.mean(diffs >= abs(observed) - eps))
        smallest = float(np.mean(diffs >= diffs.max() - eps))
        exact = True
    else:
        rng = np.random.default_rng(seed)
        count = 0
        for _ in range(MAX_DRAWS):
            shuffled = rng.permutation(pooled)
            count += abs(shuffled[k:].mean() - shuffled[:k].mean()) >= abs(observed) - eps
        p, smallest, exact = (count + 1) / (MAX_DRAWS + 1), None, False
    result = {"groups": {name_a: len(a), name_b: len(b)}, "difference": observed,
              "difference_means": f"mean({name_b}) - mean({name_a})",
              "permutation_p_two_sided": p, "smallest_possible_p": smallest, "exact": exact}
    if len(a) >= 2 and len(b) >= 2:
        rng = np.random.default_rng(seed + 1)
        boot = (rng.choice(np.array(b), (5000, len(b))).mean(axis=1)
                - rng.choice(np.array(a), (5000, len(a))).mean(axis=1))
        result["bootstrap_95"] = [float(np.percentile(boot, 2.5)), float(np.percentile(boot, 97.5))]
    text = (f"mean({name_b}) - mean({name_a}) = {_fmt(observed)}; permutation p two-sided = {_fmt(p)}"
            + (f"; bootstrap 95% interval [{_fmt(result['bootstrap_95'][0])}, {_fmt(result['bootstrap_95'][1])}]"
               if "bootstrap_95" in result else "") + ".")
    if smallest is not None and smallest >= 0.05:
        text += (f" With {len(a)} and {len(b)} values no split can reach p < 0.05 "
                 f"(smallest possible p = {_fmt(smallest)}).")
    if min(len(a), len(b)) < 4 and "bootstrap_95" in result:
        text += " The bootstrap interval is rough with fewer than 4 values per group."
    result["conclusion"] = text
    return result


# ---- sensitivity ----

def _sensitivity(data, seed):
    if "sheets" in data:
        return _noise(data, seed)
    if "expr" in data:
        return _weights(data, seed)
    _fail("sensitivity", "give sheets (values with declared noise) or expr with ranges (weights or parameters)")


def _ids(data, key, kind, required=True):
    value = data.get(key)
    if value is None and not required:
        return []
    if not isinstance(value, list) or not value or not all(isinstance(v, str) for v in value):
        _fail(kind, f"{key} must be a nonempty list of sample ids")
    return value


def _noise(data, seed):
    from researchkit import leaderboard

    kind = "sensitivity"
    sheets = data["sheets"]
    if not isinstance(sheets, dict) or not sheets:
        _fail(kind, "sheets must map a sheet name to {values, direction, sd}")
    baselines, candidates = _ids(data, "baseline_ids", kind), _ids(data, "candidate_ids", kind)
    if set(baselines) & set(candidates):
        _fail(kind, "baseline_ids and candidate_ids overlap")
    primary = data.get("primary", next(iter(sheets)))
    if primary not in sheets:
        _fail(kind, f"primary {primary!r} is not a sheet name")
    samples = baselines + candidates
    # Every sheet's problems at once (calc_roles.all_problems): LIT (2026-10-31) was refused twice, first for a
    # direction, then for an sd.
    from researchkit.calc_roles import all_problems

    problems = []
    for name, sheet in sheets.items():
        if not isinstance(sheet, dict) or not isinstance(sheet.get("values"), dict):
            problems.append(f"sheet {name}: needs values, direction and sd")
            continue
        missing = [s for s in samples if s not in sheet["values"]]
        if missing:
            problems.append(f"sheet {name}: no value for {', '.join(missing)}")
        if sheet.get("direction") not in ("higher", "lower"):
            problems.append(f"sheet {name}: direction must be higher or lower")
        if "sd" not in sheet and "sd_relative" not in sheet:
            problems.append(f"sheet {name}: declare sd (absolute) or sd_relative (fraction of each value)")
    if problems:
        _fail(kind, all_problems(problems))
    parsed = {}
    for name, sheet in sheets.items():
        values = np.array([_number(sheet["values"][s], f"{name}.{s}", kind) for s in samples])
        if "sd" in sheet:
            sd = np.full(len(samples), _number(sheet["sd"], f"{name}.sd", kind))
        else:
            sd = np.abs(values) * _number(sheet["sd_relative"], f"{name}.sd_relative", kind)
        if np.any(sd < 0):
            _fail(kind, f"sheet {name}: sd must not be negative")
        parsed[name] = (values, sd, 1 if sheet["direction"] == "higher" else -1, sheet["direction"])
    draws = _draws(data, kind)
    rng = np.random.default_rng(seed)
    noisy = {name: (values + rng.normal(size=(draws, len(samples))) * sd) * sign
             for name, (values, sd, sign, _) in parsed.items()}
    nb = len(baselines)
    oriented = noisy[primary]
    best_base = oriented[:, :nb].max(axis=1)
    cand = oriented[:, nb:]
    beats = (cand > best_base[:, None]).mean(axis=0)
    top = (cand == cand.max(axis=1)[:, None]).mean(axis=0)
    rows = {c: {"beats_best_baseline_on_primary": float(beats[i]), "top_candidate_on_primary": float(top[i])}
            for i, c in enumerate(candidates)}

    def compute(values_by_sheet):
        return leaderboard.compute(
            [{"formula_ref": name, "formula_id": name, "hypothesis_ids": [], "direction": parsed[name][3],
              "values": dict(zip(samples, values_by_sheet[name]))} for name in parsed],
            baselines, candidates, primary)

    nominal = compute({name: parsed[name][0].tolist() for name in parsed})
    nominal_verdicts = {row["id"]: row["verdict"] for row in nominal["candidates"]}
    if len(parsed) > 1:
        counts = {c: {} for c in candidates}
        for d in range(draws):
            board = compute({name: (noisy[name][d] * parsed[name][2]).tolist() for name in parsed})
            for row in board["candidates"]:
                counts[row["id"]][row["verdict"]] = counts[row["id"]].get(row["verdict"], 0) + 1
        for c in candidates:
            rows[c]["verdicts"] = {v: n / draws for v, n in sorted(counts[c].items())}
    for c in candidates:
        rows[c]["verdict_without_noise"] = nominal_verdicts[c]
    leader = max(candidates, key=lambda c: (rows[c]["beats_best_baseline_on_primary"], -candidates.index(c)))
    text = (f"Under the declared noise, {leader} beats the best historical sample on {primary} in "
            f"{rows[leader]['beats_best_baseline_on_primary']:.0%} of {draws} draws "
            f"(without noise: {nominal_verdicts[leader]})")
    if len(parsed) > 1:
        robust = rows[leader]["verdicts"].get("robust_surpass", 0.0)
        text += f"; it is a robust surpass on every sheet in {robust:.0%}"
    others = [c for c in candidates if c != leader and rows[c]["top_candidate_on_primary"] >= 0.2]
    if others:
        text += f". Also often the top candidate: {', '.join(others)}"
    return {"draws": draws, "primary": primary, "candidates": rows, "conclusion": text + ".",
            "note": "The noise is the author's declared error; the result is only as good as that declaration."}


def _weights(data, seed):
    kind = "sensitivity"
    node, sorts = _expr(data["expr"], "expr", kind)
    if ex.is_condition(node):
        _fail(kind, "expr must be a score formula, not a condition")
    rows = data.get("rows")
    if not isinstance(rows, dict) or len(rows) < 2:
        _fail(kind, "rows must map at least two sample ids to their variable values")
    ranges = data.get("ranges")
    if not isinstance(ranges, dict) or not ranges:
        _fail(kind, "ranges must give [low, high] for each weight or parameter that is uncertain")
    bounds = {name: _range(value, f"ranges.{name}", kind) for name, value in ranges.items()}
    direction = data.get("direction")
    if direction not in ("higher", "lower"):
        _fail(kind, "direction must be higher or lower (which score is better)")
    draws = _draws(data, kind)
    rng = np.random.default_rng(seed)
    names = list(bounds)
    corners = list(itertools.product(*[bounds[n] for n in names])) if len(names) <= 10 else []
    samples = {n: np.concatenate([np.array([c[i] for c in corners]), rng.uniform(*bounds[n], size=draws)])
               for i, n in enumerate(names)}
    midpoint = {n: (bounds[n][0] + bounds[n][1]) / 2 for n in names}
    ids = list(rows)
    needed = ex.names(node) - set(names)
    scores, nominal = [], []
    with np.errstate(all="ignore"):
        for sample_id in ids:
            row = rows[sample_id]
            if not isinstance(row, dict):
                _fail(kind, f"rows.{sample_id} must map variable names to numbers")
            missing = needed - set(row)
            if missing:
                _fail(kind, f"rows.{sample_id}: no value for {', '.join(sorted(missing))}")
            env = {k: _number(v, f"rows.{sample_id}.{k}", kind) for k, v in row.items()}
            scores.append(np.broadcast_to(ex.evaluate(node, {**env, **samples}), (len(samples[names[0]]),)))
            nominal.append(float(ex.evaluate(node, {**env, **midpoint})))
    sign = 1 if direction == "higher" else -1
    matrix = np.array(scores).T * sign
    if not np.all(np.isfinite(matrix)):
        _fail(kind, "the score is not finite somewhere in the ranges (division by zero or log of zero?)")
    ranks = (-matrix).argsort(axis=1).argsort(axis=1) + 1
    nominal_order = sorted(ids, key=lambda i: -sign * nominal[ids.index(i)])
    first = (ranks == 1).mean(axis=0)
    result_rows = {i: {"nominal_score": nominal[j], "rank_range": [int(ranks[:, j].min()), int(ranks[:, j].max())],
                       "ranked_first": float(first[j])} for j, i in enumerate(ids)}
    leader = nominal_order[0]
    j = ids.index(leader)
    flips = np.nonzero(ranks[:, j] != 1)[0]
    result = {"draws": int(matrix.shape[0]), "nominal_order": nominal_order, "rows": result_rows}
    text = (f"At the midpoint of the ranges the order is {', '.join(nominal_order)}; "
            f"{leader} ranks first in {first[j]:.0%} of the parameter draws")
    if len(flips):
        example = {n: float(samples[n][flips[0]]) for n in names}
        result["counterexample"] = {"parameters": example,
                                    "first": ids[int(np.argmin(ranks[flips[0]]))]}
        text += f"; for example at {json.dumps(example)} {result['counterexample']['first']} ranks first instead"
    else:
        text += "; the top position never changes within these ranges"
    baselines, candidates = _ids(data, "baseline_ids", kind, False), _ids(data, "candidate_ids", kind, False)
    if baselines and candidates:
        unknown = [i for i in baselines + candidates if i not in ids]
        if unknown:
            _fail(kind, f"no row for {', '.join(unknown)}")
        b = matrix[:, [ids.index(i) for i in baselines]].max(axis=1)
        c = matrix[:, [ids.index(i) for i in candidates]].max(axis=1)
        result["best_candidate_beats_best_baseline"] = float((c > b).mean())
        text += (f". The best candidate beats the best baseline in "
                 f"{result['best_candidate_beats_best_baseline']:.0%} of draws")
    result["conclusion"] = text + "."
    return result


# ---- interval ----

def _interval(data, seed):
    kind = "interval"
    node, sorts = _expr(data.get("expr"), "expr", kind)
    for key in ("values", "ranges", "normal", "uniform"):
        if not isinstance(data.get(key, {}), dict):
            _fail(kind, f"{key} must map names to numbers or [a, b] pairs")
    fixed = {k: _number(v, f"values.{k}", kind) for k, v in data.get("values", {}).items()}
    ranges = {k: _range(v, f"ranges.{k}", kind) for k, v in data.get("ranges", {}).items()}
    normal = dict(data.get("normal", {}))
    uniform = {k: _range(v, f"uniform.{k}", kind) for k, v in data.get("uniform", {}).items()}
    given = [*fixed, *ranges, *normal, *uniform]
    duplicate = {n for n in given if given.count(n) > 1}
    if duplicate:
        _fail(kind, f"{', '.join(sorted(duplicate))} given more than once")
    missing = ex.names(node) - set(given)
    if missing:
        _fail(kind, f"no value, range or distribution for {', '.join(sorted(missing))}")
    unused = sorted(set(given) - ex.names(node))
    if ranges and (normal or uniform):
        _fail(kind, "use ranges for guaranteed bounds, or normal/uniform for a distribution, not both")
    if normal or uniform:
        result = _distribution(node, fixed, normal, uniform, data, seed)
    else:
        if ex.is_condition(node):
            _fail(kind, "for a condition over ranges use kind=logic; interval gives bounds of a number")
        result = _bounds(node, fixed, ranges)
    if unused:
        result["unused"] = unused
    return result


def _bounds(node, fixed, ranges):
    kind = "interval"
    names = list(ranges)
    full = {**{k: (v, v) for k, v in fixed.items()}, **ranges}

    def box_bounds(box):
        return ex.interval(node, {**full, **box})

    def point(values):
        with np.errstate(all="ignore"):
            value = ex.evaluate(node, {**fixed, **values})
        value = float(value)
        return value if math.isfinite(value) else None

    try:
        whole = box_bounds({})
    except ExprError as exc:
        _fail(kind, str(exc))
    if not names:
        value = point({})
        return {"value": value, "conclusion": f"Value = {_fmt(value)}."}
    # Inner bounds from corners and seeded samples; outer bounds by splitting boxes.
    rng = np.random.default_rng(0)
    trial = {n: rng.uniform(*ranges[n], size=2000) for n in names}
    if len(names) <= 10:
        corners = list(itertools.product(*[ranges[n] for n in names]))
        for i, n in enumerate(names):
            trial[n] = np.concatenate([np.array([c[i] for c in corners]), trial[n]])
    with np.errstate(all="ignore"):
        values = np.broadcast_to(ex.evaluate(node, {**fixed, **trial}), trial[names[0]].shape)
    finite = np.isfinite(values)
    if not finite.any():
        _fail(kind, "the expression is not finite anywhere in the ranges")
    result = {}
    for label, sign in (("lower", 1), ("upper", -1)):
        index = int(np.argmin(np.where(finite, sign * values, np.inf)))
        best = sign * float(values[index])
        best_at = {n: float(trial[n][index]) for n in names}
        heap, counter, used = [], 0, 0

        def low(box):
            try:
                lo, hi = box_bounds(box)
            except ExprError:  # undefined on this whole box (e.g. log of a negative range)
                return math.inf
            return lo if sign == 1 else -hi

        start = dict(ranges)
        heap.append((low(start), counter, start))
        while heap and used < BOX_BUDGET:
            bound, _, box = heapq.heappop(heap)
            if bound >= best - 1e-9 * max(1.0, abs(best)):
                heapq.heappush(heap, (bound, counter, box))
                break
            widest = max(names, key=lambda n: box[n][1] - box[n][0])
            lo, hi = box[widest]
            if hi - lo <= 1e-12 * max(1.0, abs(lo), abs(hi)):
                heapq.heappush(heap, (bound, counter, box))
                break
            mid = (lo + hi) / 2
            for part in ((lo, mid), (mid, hi)):
                child = {**box, widest: part}
                centre = {n: (child[n][0] + child[n][1]) / 2 for n in names}
                value = point(centre)
                if value is not None and sign * value < best:
                    best, best_at = sign * value, centre
                counter += 1
                used += 1
                heapq.heappush(heap, (low(child), counter, child))
        outer = min([heap[0][0], best]) if heap else best
        result[label] = {"guaranteed": sign * outer, "attained": sign * best, "at": best_at}
    exact = all(abs(r["guaranteed"] - r["attained"]) <= 1e-6 * max(1.0, abs(r["attained"]))
                for r in (result["lower"], result["upper"]))
    result["exact"] = exact
    lo, hi = result["lower"], result["upper"]
    if exact:
        text = (f"Over the given ranges the value lies in [{_fmt(lo['attained'])}, {_fmt(hi['attained'])}]; "
                f"minimum at {json.dumps(lo['at'])}, maximum at {json.dumps(hi['at'])}.")
    else:
        text = (f"Over the given ranges the value lies within [{_fmt(lo['guaranteed'])}, {_fmt(hi['guaranteed'])}] "
                f"(guaranteed) and reaches at least [{_fmt(lo['attained'])}, {_fmt(hi['attained'])}] "
                f"(attained at {json.dumps(lo['at'])} and {json.dumps(hi['at'])}).")
    result["conclusion"] = text
    result["note"] = "Guaranteed bounds come from interval arithmetic with box splitting, up to floating-point rounding."
    return result


def _distribution(node, fixed, normal, uniform, data, seed):
    kind = "interval"
    draws = _draws(data, kind, MAX_DRAWS)
    rng = np.random.default_rng(seed)
    env = dict(fixed)
    for name, spec in normal.items():
        if not isinstance(spec, list) or len(spec) != 2:
            _fail(kind, f"normal.{name} must be [mean, sd]")
        mean, sd = (_number(v, f"normal.{name}", kind) for v in spec)
        if sd < 0:
            _fail(kind, f"normal.{name}: sd must not be negative")
        env[name] = rng.normal(mean, sd, draws)
    for name, (low, high) in uniform.items():
        env[name] = rng.uniform(low, high, draws)
    with np.errstate(all="ignore"):
        values = np.broadcast_to(ex.evaluate(node, env), (draws,))
    if ex.is_condition(node):
        share = float(np.mean(values))
        return {"draws": draws, "probability_true": share,
                "conclusion": f"The condition holds in {share:.1%} of {draws} draws from the declared distributions."}
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        _fail(kind, "the expression is never finite under the declared distributions")
    q = {p: float(np.percentile(finite, p)) for p in (2.5, 5, 50, 95, 97.5)}
    result = {"draws": draws, "mean": float(finite.mean()), "sd": float(finite.std()), "percentiles": q,
              "non_finite_draws": int(draws - len(finite))}
    result["conclusion"] = (f"Median {_fmt(q[50])}, 95% of draws in [{_fmt(q[2.5])}, {_fmt(q[97.5])}], "
                            f"mean {_fmt(result['mean'])}, sd {_fmt(result['sd'])} ({draws} draws).")
    if result["non_finite_draws"]:
        result["conclusion"] += f" {result['non_finite_draws']} draws were not finite and are excluded."
    return result


# ---- logic ----

def _logic(data, seed):
    import z3

    kind = "logic"
    premises = data.get("premises", [])
    if not isinstance(premises, list):
        _fail(kind, "premises must be a list of expressions")
    goal, find = data.get("goal"), data.get("find")
    if goal is not None and find is not None:
        _fail(kind, "give goal (is it guaranteed?) or find (is there an example?), not both")
    timeout = data.get("timeout_s", 10)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 1 <= timeout <= 60:
        _fail(kind, "timeout_s must be between 1 and 60")
    # Every expression's problems at once: a run (2026-11-01) was refused four times in a row, each refusal
    # naming the next unreadable part (ln, a quantifier, pow, a fractional power).
    parsed, sorts, labels, problems = [], {}, set(), []
    for index, item in enumerate(premises, 1):
        label, text = (item.get("id"), item.get("expr")) if isinstance(item, dict) else (f"P{index}", item)
        if not isinstance(label, str) or not label or label in ("goal", "find", "not_goal"):
            _fail(kind, f"premises[{index - 1}].id must be a nonempty string other than goal/find/not_goal")
        if label in labels:
            _fail(kind, f"premise id {label} is used twice")
        labels.add(label)
        node = _condition(text, label, sorts, problems)
        if node is not None:
            parsed.append((label, node))
    target = None
    if goal is not None or find is not None:
        target = _condition(goal if goal is not None else find, "goal" if goal is not None else "find", sorts,
                            problems)
    if problems:
        _fail(kind, _expression_problems(problems))
    context = z3.Context()
    symbols = {n: (z3.Real(n, context) if s == "num" else z3.Bool(n, context)) for n, s in sorts.items()}
    terms, target_term = [], None
    for label, node in [*parsed, *([("goal", target)] if target is not None else [])]:
        try:
            term = ex.to_z3(node, symbols, z3, context, label)
        except ExprError as exc:
            problems.append(str(exc))
            continue
        if label == "goal" and node is target:
            target_term = term
        else:
            terms.append((label, term))
    if problems:
        _fail(kind, _expression_problems(problems))

    def solver(extra=()):
        s = z3.Solver(ctx=context)
        s.set("timeout", int(timeout * 1000))
        for label, term in [*terms, *extra]:
            s.assert_and_track(term, z3.Bool(f"__{label}", context))
        return s

    def model(s):
        m = s.model()
        return {n: _value(m.eval(symbols[n], model_completion=True), z3) for n in sorted(symbols)}

    def core(s):
        return sorted(str(item)[2:] for item in s.unsat_core())

    base = solver()
    state = base.check()
    result = {"premises": [label for label, _ in parsed]}
    if state == z3.unsat:
        result.update(verdict="premises_inconsistent", conflicting=core(base),
                      conclusion=f"The premises contradict each other ({', '.join(core(base))}); "
                                 "anything follows from them, so fix them first.")
        return result
    if state == z3.unknown:
        return {**result, "verdict": "unknown", "reason": base.reason_unknown(),
                "conclusion": f"The solver could not decide whether the premises are consistent "
                              f"({base.reason_unknown()})."}
    if target is None:
        return {**result, "verdict": "consistent", "example": model(base),
                "conclusion": f"The premises are consistent; one example: {json.dumps(model(base))}."}
    if find is not None:
        s = solver([("find", target_term)])
        state = s.check()
        if state == z3.sat:
            return {**result, "verdict": "found", "example": model(s),
                    "conclusion": f"Found an example: {json.dumps(model(s))}."}
        if state == z3.unsat:
            return {**result, "verdict": "impossible", "conflicting": core(s),
                    "conclusion": "No values satisfy the premises and the condition together "
                                  f"(conflict among {', '.join(core(s))})."}
        return {**result, "verdict": "unknown", "reason": s.reason_unknown(),
                "conclusion": f"The solver could not decide within {timeout} s ({s.reason_unknown()})."}
    negated = solver([("not_goal", z3.Not(target_term))])
    state = negated.check()
    if state == z3.unsat:
        used = [c for c in core(negated) if c != "not_goal"]
        return {**result, "verdict": "proved", "premises_used": used,
                "conclusion": f"Proved: the goal follows from the premises (it needs {', '.join(used) or 'none of them'})."}
    if state == z3.unknown:
        return {**result, "verdict": "unknown", "reason": negated.reason_unknown(),
                "conclusion": f"The solver could not decide within {timeout} s ({negated.reason_unknown()})."}
    counterexample = model(negated)
    possible = solver([("goal", target_term)]).check()
    result.update(verdict="not_proved", counterexample=counterexample,
                  goal_possible=None if possible == z3.unknown else possible == z3.sat)
    text = f"Not guaranteed: counterexample {json.dumps(counterexample)} satisfies the premises but not the goal"
    if possible == z3.unsat:
        text += "; in fact the goal never holds under these premises"
    elif possible == z3.sat:
        text += "; the goal can hold, but only for some values"
    result["conclusion"] = text + "."
    return result


def _condition(text, label, sorts, problems=None):
    """The parsed condition; on a problem, refuse, or with problems given, add it there and return None."""
    try:
        node = ex.parse(text, label)
        ex.infer(node, "bool", sorts, label)
    except ExprError as exc:
        if problems is None:
            _fail("logic", str(exc))
        problems.append(str(exc))
        return None
    return node


def _expression_problems(problems):
    """One problem as it is; several listed, with the syntax help said once instead of after each."""
    if len(problems) == 1:
        return problems[0]
    from researchkit.calc_roles import all_problems
    helped = any(ex.HELP in problem for problem in problems)
    listed = all_problems([problem.replace(" " + ex.HELP, "").replace(ex.HELP, "").strip() for problem in problems])
    return listed + (f"\n{ex.HELP}" if helped else "")


def _value(value, z3):
    if z3.is_true(value):
        return True
    if z3.is_false(value):
        return False
    if z3.is_rational_value(value):
        return float(value.as_fraction())
    if z3.is_algebraic_value(value):
        return float(value.as_decimal(12).rstrip("?"))
    return str(value)


def _properties(data, seed, root=".", **_):
    from researchkit import calc_checks

    def fail(message):
        _fail("properties", message)

    module, function, call, plans, calls = calc_checks.plan_properties(data, fail)
    try:
        outputs = calc_checks.execute(root, module, function, call, data.get("output"), calls)
    except calc_checks.CheckError as exc:
        fail(str(exc))
    return {"module": module, "function": function, **calc_checks.judge_properties(plans, outputs)}


def _causal(data, seed, **_):
    from researchkit import calc_checks

    def fail(message):
        _fail("causal", message)

    if "rows" in data:
        return calc_checks.design(data, fail)
    if "edges" in data:
        return calc_checks.graph(data, fail)
    fail("give rows (sample values per factor) to see what the data can separate, "
         "or edges with treatment and outcome to check a causal graph")


def _constant(data, seed, fetch=None, **_):
    from researchkit import calc_constants

    def fail(message):
        _fail("constant", message)

    return calc_constants.constant(data, fail, fetch)


def _units(data, seed):
    from researchkit import calc_units

    def fail(message):
        _fail("units", message)

    return calc_units.units(data, fail)


def _design(data, seed):
    from researchkit import calc_design

    def fail(message):
        _fail("design", message)

    return calc_design.design(data, fail)


def _roles(data, seed):
    from researchkit import calc_roles

    def fail(message):
        _fail("roles", message)

    return calc_roles.roles(data, fail)


RUNNERS = {"stats": _stats, "sensitivity": _sensitivity, "interval": _interval, "logic": _logic,
           "properties": _properties, "causal": _causal, "constant": _constant, "units": _units,
           "design": _design, "roles": _roles}
NEEDS_CONTEXT = {"properties", "causal", "constant"}


def run(kind, data, *, root=".", fetch=None):
    """Calculate one thing; the result's first field to read is conclusion.

    root is the workspace whose module kind=properties imports; fetch(url, form) -> (status, text)
    performs a network request for kind=constant lookups in PubChem.
    """
    if kind not in RUNNERS:
        raise CalcError(f"calc: kind must be one of {', '.join(KINDS)}")
    if not isinstance(data, dict):
        _fail(kind, "input must be an object")
    runner = RUNNERS[kind]
    raw = runner(data, _seed(kind, data), root=root, fetch=fetch) if kind in NEEDS_CONTEXT else \
        runner(data, _seed(kind, data))
    result = _plain(raw)
    return {"conclusion": result.pop("conclusion"), **result}


def _plain(value):
    """JSON-safe copy: numpy numbers become floats, infinities and NaN become strings."""
    if isinstance(value, dict):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(v) for v in value]
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (int, np.integer)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        value = float(value)
        return value if math.isfinite(value) else str(value)
    return value


def document(kind, data, result):
    """The saved form; the board recognises it by the calc header."""
    return {"calc": {"kind": kind, "version": VERSION}, "input": data, "result": result}


# ---- script use: calc.stats(x=[..], y=[..]).save("work/stats.json") ----

class Result(dict):
    """A calc result; print() shows the conclusion, save() writes the same file the calc tool writes."""

    def __init__(self, kind, data, value):
        super().__init__(value)
        self.kind, self.input = kind, data

    def __str__(self):
        return self["conclusion"]

    def save(self, path):
        from pathlib import Path
        from researchkit import records
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(records.encoded(document(self.kind, self.input, dict(self))))
        return target


def http_fetch(url, form=None):
    """Network access for constant lookups in PubChem from a script."""
    import httpx
    with httpx.Client(timeout=30, follow_redirects=True) as client:
        response = client.post(url, data=form) if form else client.get(url)
    return response.status_code, response.text


def _api(kind):
    def call(data=None, /, *, root=".", fetch=None, **fields):
        merged = {**(data or {}), **fields}
        return Result(kind, merged, run(kind, merged, root=root,
                                        fetch=http_fetch if fetch is None and kind == "constant" else fetch))
    call.__name__ = kind
    call.__doc__ = f"calc kind={kind}; fields as in the calc tool. Example: {json.dumps(EXAMPLES[kind])}"
    return call


stats = _api("stats")
sensitivity = _api("sensitivity")
interval = _api("interval")
logic = _api("logic")
properties = _api("properties")
causal = _api("causal")
constant = _api("constant")
units = _api("units")
design = _api("design")
roles = _api("roles")
