"""calc kinds that check the author's own work: properties (code) and causal (design and graph)."""

from __future__ import annotations

import itertools
import json
import math
from pathlib import Path
import subprocess
import sys

import numpy as np

from researchkit import calc_expr as ex
from researchkit.calc_expr import ExprError
from opencode import executor, runtime_settings


TIMEOUT_S = runtime_settings.get("compute.calc_check_s")  # config/runtime.json, compute
MAX_CALLS = 2000
MAX_GRAPH_SUBSET = 6


class CheckError(ValueError):
    pass


# ---- properties: does the implementation do what its author says it does? ----

CHECKS = ("finite", "greater", "less", "equal", "value", "formula", "increasing", "decreasing")


def _key(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False)


# What one input looks like under each call: a run (2026-11-01) spent a dozen calls finding the pair format, and
# read equal as "f(a) equals b", replacing a known-answer check with one that always holds.
INPUT = {"single": ("a value", "41.0", "45.0"), "kwargs": ("an object of named arguments", '{"x": 41.0}', '{"x": 45.0}'),
         "args": ("a list of positional arguments", "[41.0, 2]", "[45.0, 2]")}


def _pairs(check, name, fail, call="single"):
    pairs = check[name]
    if not isinstance(pairs, list) or not pairs or not all(isinstance(p, list) and len(p) == 2 for p in pairs):
        what, a, b = INPUT.get(call, INPUT["single"])
        if name == "value":
            fail(f"value must be a list of [input, known output] pairs; with call {call} an input is {what}: "
                 f"[[{a}, 0.0]] checks f({a}) = 0.0")
        fail(f"{name} must be a list of [a, b] pairs of inputs whose outputs it compares; with call {call} an input "
             f"is {what}: [[{a}, {b}]] checks f({a}) {dict(greater='>', less='<', equal='=')[name]} f({b})."
             + (" To check one output against a known number, use value" if name == "equal" else ""))
    return pairs


def _sweep(check, name, call, fail):
    arg = check[name]
    if call != "kwargs" or not isinstance(arg, str):
        fail(f"{name} needs call=\"kwargs\" and the name of the argument to vary")
    base = check.get("base")
    span = check.get("range")
    steps = check.get("steps", 21)
    if not isinstance(base, dict) or not isinstance(span, list) or len(span) != 2:
        fail(f"{name} needs base (the other arguments) and range [low, high]")
    if isinstance(steps, bool) or not isinstance(steps, int) or not 3 <= steps <= 201:
        fail(f"{name}: steps must be an integer from 3 to 201")
    return [{**base, arg: float(x)} for x in np.linspace(float(span[0]), float(span[1]), steps)]


def plan_properties(data, fail):
    """Validate the request and list every distinct call the checks need."""
    module, function = data.get("module"), data.get("function")
    if not isinstance(module, str) or not module.endswith(".py") or not isinstance(function, str):
        fail("give module (a .py file in the workspace) and function (its name)")
    call = data.get("call", "single")
    if call not in ("single", "kwargs", "args"):
        fail(f"call must be single, kwargs or args, not {call!r}: it says what each input is. single: the function's "
             "one argument (\"greater\": [[41.0, 45.0]]); kwargs: an object of named arguments "
             "([[{\"x\": 41.0}, {\"x\": 45.0}]]); args: a list of positional arguments ([[[41.0, 2], [45.0, 2]]])")
    checks = data.get("checks")
    if not isinstance(checks, list) or not checks:
        fail(f"checks must be a nonempty list; each check is one of {', '.join(CHECKS)}")
    calls = {}

    def need(value):
        calls.setdefault(_key(value), value)

    plans = []
    for index, check in enumerate(checks):
        names = [n for n in CHECKS if isinstance(check, dict) and n in check]
        if len(names) != 1:
            fail(f"checks[{index}] must name exactly one of {', '.join(CHECKS)}")
        name = names[0]
        inputs = []
        if name == "finite":
            if not isinstance(check[name], list) or not check[name]:
                fail("finite must list the inputs that must give a number")
            inputs = list(check[name])
        elif name in ("greater", "less", "equal"):
            inputs = [x for pair in _pairs(check, name, fail, call) for x in pair]
        elif name == "value":
            inputs = [pair[0] for pair in _pairs(check, name, fail, call)]
        elif name == "formula":
            if call != "kwargs" or not isinstance(check.get("inputs"), list) or not check["inputs"]:
                fail("formula needs call=\"kwargs\" and inputs: a list of argument objects")
            try:
                node = ex.parse(check["formula"], f"checks[{index}].formula")
                ex.infer(node, "num", {}, "formula")
            except ExprError as exc:
                fail(str(exc))
            check = {**check, "_node": node}
            inputs = list(check["inputs"])
        else:
            inputs = _sweep(check, name, call, fail)
        if call == "kwargs" and not all(isinstance(i, dict) for i in inputs):
            fail(f"checks[{index}]: with call=\"kwargs\" every input must be an object of named arguments")
        for value in inputs:
            need(value)
        plans.append((name, check, inputs))
    if len(calls) > MAX_CALLS:
        fail(f"the checks need {len(calls)} calls; at most {MAX_CALLS}")
    return module, function, call, plans, calls


def execute(root, module, function, call, output, calls):
    """Call the author's function in a separate Python process; returns {key: {value|error}}."""
    path = (Path(root) / module).resolve()
    if not path.is_file():
        raise CheckError(f"module {module} does not exist in the workspace")
    from researchkit import calc_runner
    request = {"module": str(path), "function": function, "output": output, "call": call,
               "calls": list(calls.values())}
    try:
        done = executor.run([sys.executable, "-I", calc_runner.__file__],
                            executor.Launch("agent_code", "calc properties"), input=json.dumps(request),
                              capture_output=True, text=True, encoding="utf-8", cwd=str(root), timeout=TIMEOUT_S)
    except subprocess.TimeoutExpired:
        raise CheckError(f"the function did not finish within {TIMEOUT_S} s") from None
    line = next((l for l in done.stdout.splitlines() if l.startswith(calc_runner.MARKER)), None)
    if line is None:
        raise CheckError(f"the check process ended without a result (exit {done.returncode}): {done.stderr[-800:]}")
    reply = json.loads(line[len(calc_runner.MARKER):])
    if "load_error" in reply:
        raise CheckError(f"could not load {function} from {module}: {reply['load_error']}")
    return dict(zip(calls, reply["results"]))


def _show(value):
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return text if len(text) <= 60 else text[:57] + "..."


def judge_properties(plans, outputs, tolerance_default=1e-9):
    def got(value):
        return outputs[_key(value)]

    def describe(value):
        result = got(value)
        return f"f({_show(value)}) = {result['value']:.6g}" if "value" in result else \
            f"f({_show(value)}) {result['error']}"

    rows = []
    for name, check, inputs in plans:
        failures = []
        tolerance = check.get("tolerance", tolerance_default)
        if name == "finite":
            failures = [describe(v) for v in inputs if "value" not in got(v)]
        elif name in ("greater", "less", "equal"):
            for a, b in check[name]:
                ra, rb = got(a), got(b)
                if "value" not in ra or "value" not in rb:
                    failures.append(f"{describe(a)}; {describe(b)}")
                    continue
                x, y = ra["value"], rb["value"]
                ok = x > y if name == "greater" else x < y if name == "less" else abs(x - y) <= tolerance
                if not ok:
                    sign = {"greater": ">", "less": "<", "equal": "="}[name]
                    failures.append(f"expected {describe(a)} {sign} {describe(b)}"
                                    + (" (equal compares the outputs of two inputs; a known output is checked with "
                                       "value: [[input, expected]])" if name == "equal" else ""))
        elif name == "value":
            for a, expected in check[name]:
                r = got(a)
                if "value" not in r or abs(r["value"] - float(expected)) > tolerance * max(1.0, abs(float(expected))):
                    failures.append(f"expected {expected}, {describe(a)}")
        elif name == "formula":
            for item in inputs:
                r = got(item)
                try:
                    expected = float(ex.evaluate(check["_node"], {k: float(v) for k, v in item.items()
                                                                   if isinstance(v, (int, float))}))
                except (ExprError, TypeError, ValueError) as exc:
                    failures.append(f"formula cannot be evaluated at {_show(item)}: {exc}")
                    continue
                if "value" not in r or abs(r["value"] - expected) > tolerance * max(1.0, abs(expected)):
                    failures.append(f"formula gives {expected:.6g}, {describe(item)}")
        else:
            values = [got(v) for v in inputs]
            bad = [describe(v) for v, r in zip(inputs, values) if "value" not in r]
            if bad:
                failures = bad
            else:
                sign = 1 if name == "increasing" else -1
                for (a, ra), (b, rb) in zip(zip(inputs, values), list(zip(inputs, values))[1:]):
                    if sign * (rb["value"] - ra["value"]) < -tolerance * max(1.0, abs(ra["value"])):
                        failures.append(f"{describe(a)} then {describe(b)}")
                        break
        row = {"check": name, "passed": not failures, "failures": failures[:5],
               "failure_count": len(failures)}
        if isinstance(check.get("why"), str):
            row["why"] = check["why"]
        rows.append(row)
    failed = [r for r in rows if not r["passed"]]
    if not failed:
        conclusion = f"All {len(rows)} checks pass ({len(outputs)} calls)."
    else:
        first = failed[0]
        conclusion = (f"{len(failed)} of {len(rows)} checks fail. First: {first['check']} — "
                      f"{first['failures'][0]}"
                      + (f" (and {first['failure_count'] - 1} more)" if first["failure_count"] > 1 else "") + ".")
    return {"checks": rows, "calls": len(outputs), "conclusion": conclusion,
            "note": "Checks only the cases listed; passing them does not prove the code right elsewhere."}


# ---- causal: can the data or the design separate an effect? ----

def _columns(rows, factors, fail):
    """Design columns: numeric factors centred, categorical factors one-hot minus their first level."""
    ids = list(rows)
    columns, owner = [], []
    for factor in factors:
        values = [rows[i].get(factor) for i in ids]
        if any(v is None for v in values):
            fail(f"factor {factor}: missing for {', '.join(i for i, v in zip(ids, values) if v is None)}")
        if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
            column = np.array(values, float)
            columns.append(column - column.mean())
            owner.append((factor, None))
        else:
            levels = list(dict.fromkeys(str(v) for v in values))
            for level in levels[1:]:
                column = np.array([1.0 if str(v) == level else 0.0 for v in values])
                columns.append(column - column.mean())
                owner.append((factor, level))
    return ids, (np.array(columns).T if columns else np.zeros((len(ids), 0))), owner


def _rank(matrix):
    return int(np.linalg.matrix_rank(matrix, tol=1e-9)) if matrix.size else 0


def design(data, fail):
    rows, factors = data.get("rows"), data.get("factors")
    if not isinstance(rows, dict) or len(rows) < 2 or not all(isinstance(r, dict) for r in rows.values()):
        fail("rows must map at least two sample ids to their factor values")
    if factors is None:
        factors = list(dict.fromkeys(k for r in rows.values() for k in r))
    if not isinstance(factors, list) or not factors or not all(isinstance(f, str) for f in factors):
        fail("factors must list the factor names to separate")
    ids, matrix, owner = _columns(rows, factors, fail)
    varying = sorted({f for (f, _), col in zip(owner, matrix.T) if np.any(np.abs(col) > 1e-12)})
    constant = [f for f in factors if f not in varying]
    rank = _rank(matrix)
    separable, entangled = [], {}
    for factor in varying:
        mine = [j for j, (f, _) in enumerate(owner) if f == factor]
        others = [j for j, (f, _) in enumerate(owner) if f != factor]
        lost = rank - _rank(matrix[:, others])
        if lost == len(mine):
            separable.append(factor)
        else:
            partners = []
            for other in varying:
                if other == factor:
                    continue
                pair = [j for j, (f, _) in enumerate(owner) if f in (factor, other)]
                without = [j for j, (f, _) in enumerate(owner) if f != other]
                rest = [j for j in without if owner[j][0] != factor]
                collinear = _rank(matrix[:, pair]) < len(pair)
                frees = _rank(matrix[:, without]) - _rank(matrix[:, rest]) == len(mine)
                if collinear or frees:
                    partners.append(other)
            entangled[factor] = partners
    result = {"samples": len(ids), "varying_factors": varying, "constant_factors": constant,
              "estimable_effects": rank, "effects_needed": int(matrix.shape[1]),
              "separable": separable, "entangled": entangled}
    if not varying:
        result["conclusion"] = "No factor varies across these samples; no effect can be estimated."
        return result
    if not entangled:
        text = f"Each varying factor ({', '.join(varying)}) can be separated in these {len(ids)} samples"
        if len(ids) - 1 - rank <= 0:
            text += ", but no samples are left over to estimate error, so any difference is untested"
        result["conclusion"] = text + "."
        return result
    parts = [f"{f} (moves together with {', '.join(p) or 'a combination of the others'})"
             for f, p in entangled.items()]
    target = data.get("target")
    text = (f"These {len(ids)} samples can estimate at most {rank} effect(s) but {matrix.shape[1]} vary; "
            f"cannot be separated: {'; '.join(parts)}.")
    if isinstance(target, str) and target in entangled:
        held = [p for p in entangled[target]] or [f for f in varying if f != target]
        text += (f" To separate {target}, add a sample that changes {target} while keeping "
                 f"{', '.join(held)} as in an existing sample.")
    result["conclusion"] = text
    return result


def _parse_edges(edges, fail):
    parents, latent = {}, 0
    for text in edges:
        if not isinstance(text, str):
            fail("edges must be strings like \"A -> B -> C\" or \"A <-> B\"")
        if "<->" in text:
            nodes = [n.strip() for n in text.split("<->")]
            if len(nodes) != 2 or not all(nodes):
                fail(f"{text!r}: write a hidden common cause as \"A <-> B\"")
            latent += 1
            hidden = f"U{latent}({nodes[0]},{nodes[1]})"
            for node in nodes:
                parents.setdefault(node, set()).add(hidden)
            parents.setdefault(hidden, set())
            continue
        nodes = [n.strip() for n in text.split("->")]
        if len(nodes) < 2 or not all(nodes):
            fail(f"{text!r}: write edges as \"A -> B\" (chains allowed)")
        for a, b in zip(nodes, nodes[1:]):
            parents.setdefault(a, set())
            parents.setdefault(b, set()).add(a)
    return parents


def _ancestors(parents, nodes):
    found, stack = set(nodes), list(nodes)
    while stack:
        for p in parents.get(stack.pop(), ()):
            if p not in found:
                found.add(p)
                stack.append(p)
    return found


def _descendants(parents, node):
    children = {}
    for child, ps in parents.items():
        for p in ps:
            children.setdefault(p, set()).add(child)
    found, stack = set(), [node]
    while stack:
        for c in children.get(stack.pop(), ()):
            if c not in found:
                found.add(c)
                stack.append(c)
    return found


def _separated(parents, x, y, given):
    """d-separation via the moralised ancestral graph."""
    keep = _ancestors(parents, {x, y, *given})
    links = {n: set() for n in keep}
    for child in keep:
        ps = [p for p in parents.get(child, ()) if p in keep]
        for p in ps:
            links[child].add(p)
            links[p].add(child)
        for a, b in itertools.combinations(ps, 2):
            links[a].add(b)
            links[b].add(a)
    seen, stack = {x}, [x]
    while stack:
        for n in links[stack.pop()]:
            if n == y:
                return False
            if n not in seen and n not in given:
                seen.add(n)
                stack.append(n)
    return True


def graph(data, fail):
    edges, treatment, outcome = data.get("edges"), data.get("treatment"), data.get("outcome")
    if not isinstance(edges, list) or not edges or not isinstance(treatment, str) or not isinstance(outcome, str):
        fail("give edges, treatment and outcome")
    parents = _parse_edges(edges, fail)
    for node in (treatment, outcome):
        if node not in parents:
            fail(f"{node} does not appear in the edges")
    if treatment in _descendants(parents, treatment):
        fail("the graph has a cycle through the treatment")
    hidden = {n for n in parents if n.startswith("U") and "(" in n}
    observed = data.get("observed")
    if observed is None:
        observed = [n for n in parents if n not in hidden]
    if not isinstance(observed, list) or not all(isinstance(n, str) for n in observed):
        fail("observed must list the variables you have data for")
    descendants = _descendants(parents, treatment)
    # Back-door: cut the treatment's outgoing edges, then block every path into it.
    cut = {child: {p for p in ps if p != treatment} for child, ps in parents.items()}
    candidates = sorted(n for n in observed if n not in descendants and n not in (treatment, outcome))
    adjustment = None
    for size in range(0, min(len(candidates), MAX_GRAPH_SUBSET) + 1):
        for subset in itertools.combinations(candidates, size):
            if _separated(cut, treatment, outcome, set(subset)):
                adjustment = list(subset)
                break
        if adjustment is not None:
            break
    mediators = sorted(n for n in descendants if outcome in _descendants(parents, n) or n == outcome)
    mediators = [m for m in mediators if m != outcome]
    result = {"treatment": treatment, "outcome": outcome, "observed": sorted(observed),
              "hidden_common_causes": sorted(hidden), "mediators": mediators,
              "has_effect_path": outcome in descendants}
    if not result["has_effect_path"]:
        result["conclusion"] = f"In this graph {treatment} has no path to {outcome}: its effect is zero by assumption."
        return result
    if adjustment is None:
        confounders = sorted(n for n in _ancestors(parents, {treatment}) & _ancestors(parents, {outcome})
                             if n not in (treatment, outcome) and n not in descendants and n not in observed)
        result.update(identifiable=False, unobserved_confounders=confounders)
        result["conclusion"] = (f"The effect of {treatment} on {outcome} cannot be separated by adjustment with the "
                                f"observed variables; unmeasured common causes: {', '.join(confounders) or 'none listed'}. "
                                f"Measure one of them, or vary {treatment} deliberately while holding the others fixed.")
        return result
    result.update(identifiable=True, adjustment_set=adjustment)
    result["conclusion"] = (f"The effect of {treatment} on {outcome} is identifiable by adjusting for "
                            f"{', '.join(adjustment) if adjustment else 'nothing'}"
                            + (f"; do not adjust for the mediators {', '.join(mediators)}" if mediators else "")
                            + ". This holds only if the graph is right.")
    return result
