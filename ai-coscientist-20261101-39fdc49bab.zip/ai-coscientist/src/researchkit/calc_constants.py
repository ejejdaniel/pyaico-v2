"""calc kind=constant: values with a stated source instead of numbers recalled from memory.

Three sources, each labelled in the result:
- defined: SI defining constants (exact since 2019) and constants derived from them;
- CODATA 2018 recommended values for a few measured constants;
- computed: molar mass and descriptors from a formula or SMILES with RDKit;
- pubchem: PubChem records fetched over the network (computed properties, or the
  experimental-property sections with their cited sources).
Nothing is filled in from memory: an unknown name or a missing record is reported as not found.
"""

from __future__ import annotations

import json
import re
from urllib.parse import quote


CODATA = "CODATA 2018 / SI 2019 (NIST SP 961)"
CONSTANTS = {
    # name: (value, unit, status, aliases)
    "speed_of_light": (299792458.0, "m s^-1", "exact", ("c",)),
    "planck": (6.62607015e-34, "J s", "exact", ("h",)),
    "elementary_charge": (1.602176634e-19, "C", "exact", ("e",)),
    "boltzmann": (1.380649e-23, "J K^-1", "exact", ("kB", "k_B")),
    "avogadro": (6.02214076e23, "mol^-1", "exact", ("NA", "N_A")),
    "gas_constant": (6.02214076e23 * 1.380649e-23, "J mol^-1 K^-1", "exact (NA * kB)", ("R",)),
    "faraday": (6.02214076e23 * 1.602176634e-19, "C mol^-1", "exact (NA * e)", ("F",)),
    "vacuum_permittivity": (8.8541878128e-12, "F m^-1", "measured, rel. unc. 1.5e-10", ("epsilon0", "eps0")),
    "electron_mass": (9.1093837015e-31, "kg", "measured, rel. unc. 3.0e-10", ("me", "m_e")),
    "atomic_mass_constant": (1.66053906660e-27, "kg", "measured, rel. unc. 3.0e-10", ("u", "amu", "Da")),
    "gravitational": (6.67430e-11, "m^3 kg^-1 s^-2", "measured, rel. unc. 2.2e-5", ("G",)),
}
ALIASES = {alias: name for name, (*_, aliases) in CONSTANTS.items() for alias in aliases}
PUBCHEM = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"
PUBCHEM_VIEW = "https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound"
PUBCHEM_PROPERTIES = ("MolecularFormula", "MolecularWeight", "ExactMass", "XLogP", "TPSA",
                      "HBondDonorCount", "HBondAcceptorCount", "RotatableBondCount", "IUPACName",
                      "CanonicalSMILES")


def _named(names, fail):
    rows, missing = {}, []
    for name in names:
        key = ALIASES.get(name, name)
        if key in CONSTANTS:
            value, unit, status, _ = CONSTANTS[key]
            rows[name] = {"value": value, "unit": unit, "status": status, "source": CODATA, "name": key}
        else:
            missing.append(name)
    return rows, missing


def _formula_counts(formula, fail):
    """Element counts of a formula such as C10H12O2, (CH3)3COH or CuSO4·5H2O."""
    total = {}
    for part in re.split(r"[·.*]", re.sub(r"\s", "", formula)):
        lead = re.match(r"\d+", part)
        factor = int(lead.group()) if lead else 1
        part = part[lead.end():] if lead else part
        tokens = re.findall(r"[A-Z][a-z]?|\(|\)|\d+", part)
        if not part or "".join(tokens) != part:
            fail(f"cannot read formula {formula!r}")
        stack = [{}]
        for i, token in enumerate(tokens):
            n = int(tokens[i + 1]) if i + 1 < len(tokens) and tokens[i + 1].isdigit() else 1
            if token == "(":
                stack.append({})
            elif token == ")":
                if len(stack) == 1:
                    fail(f"unbalanced parentheses in {formula!r}")
                group = stack.pop()
                for element, count in group.items():
                    stack[-1][element] = stack[-1].get(element, 0) + count * n
            elif not token.isdigit():
                stack[-1][token] = stack[-1].get(token, 0) + n
            elif i == 0 or tokens[i - 1] == "(":
                fail(f"misplaced number in {formula!r}")
        if len(stack) != 1:
            fail(f"unbalanced parentheses in {formula!r}")
        for element, count in stack[0].items():
            total[element] = total.get(element, 0) + count * factor
    return total


def _rdkit(fail):
    try:
        import rdkit
        from rdkit import Chem
        from rdkit.Chem import Crippen, Descriptors, rdMolDescriptors
    except ImportError:
        fail("RDKit is not installed, so formulas and SMILES cannot be computed here")
    return rdkit, Chem, Crippen, Descriptors, rdMolDescriptors


def _formula(formula, fail):
    rdkit, Chem, *_ = _rdkit(fail)
    table = Chem.GetPeriodicTable()
    counts = _formula_counts(formula, fail)
    mass = 0.0
    for element, count in counts.items():
        try:
            number = table.GetAtomicNumber(element)
        except RuntimeError:
            number = 0
        if number <= 0:
            fail(f"unknown element {element!r} in {formula!r}")
        mass += table.GetAtomicWeight(element) * count
    return {"formula": formula, "elements": counts, "molar_mass": mass, "unit": "g mol^-1",
            "status": "computed from standard atomic weights",
            "source": f"RDKit {rdkit.__version__} periodic table"}


def _smiles(smiles, fail):
    rdkit, Chem, Crippen, Descriptors, rdMolDescriptors = _rdkit(fail)
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        fail(f"RDKit cannot read SMILES {smiles!r}")
    return {"smiles": smiles, "canonical_smiles": Chem.MolToSmiles(molecule),
            "formula": rdMolDescriptors.CalcMolFormula(molecule),
            "molar_mass": Descriptors.MolWt(molecule), "exact_mass": Descriptors.ExactMolWt(molecule),
            "logp_crippen": Crippen.MolLogP(molecule), "tpsa": rdMolDescriptors.CalcTPSA(molecule),
            "hbond_donors": rdMolDescriptors.CalcNumHBD(molecule),
            "hbond_acceptors": rdMolDescriptors.CalcNumHBA(molecule),
            "rotatable_bonds": rdMolDescriptors.CalcNumRotatableBonds(molecule),
            "status": "computed estimates (logP and TPSA are model values, not measurements)",
            "source": f"RDKit {rdkit.__version__}"}


def _texts(node, references, found):
    """Collect Information entries (value strings with their reference) from a PUG View section tree."""
    if isinstance(node, dict):
        for info in node.get("Information", []) or []:
            value = info.get("Value", {})
            strings = [s.get("String", "") for s in value.get("StringWithMarkup", []) or []]
            numbers = value.get("Number")
            text = "; ".join(s for s in strings if s) or (
                " ".join(str(n) for n in numbers) + (" " + value.get("Unit", "") if value.get("Unit") else "")
                if numbers else "")
            if text:
                ref = references.get(info.get("ReferenceNumber"), {})
                found.append({"value": text, "source": ref.get("SourceName"), "source_detail": ref.get("Name"),
                              "url": ref.get("URL")})
        for child in node.get("Section", []) or []:
            _texts(child, references, found)
    return found


def _pubchem(data, fetch, fail):
    if fetch is None:
        fail("a PubChem lookup needs the network; use it through the calc tool")
    if isinstance(data.get("smiles"), str):
        url = f"{PUBCHEM}/compound/smiles/property/{','.join(PUBCHEM_PROPERTIES)}/JSON"
        status, text = fetch(url, {"smiles": data["smiles"]})
        query = data["smiles"]
    elif isinstance(data.get("compound"), str):
        url = f"{PUBCHEM}/compound/name/{quote(data['compound'], safe='')}/property/{','.join(PUBCHEM_PROPERTIES)}/JSON"
        status, text = fetch(url, None)
        query = data["compound"]
    else:
        fail("pubchem needs compound (a name) or smiles")
    if status == 404:
        return {"found": False, "query": query, "url": url,
                "conclusion": f"PubChem has no compound matching {query!r}; no value is given."}
    if status != 200:
        fail(f"PubChem answered HTTP {status}: {text[:200]}")
    rows = json.loads(text).get("PropertyTable", {}).get("Properties", [])
    if not rows:
        return {"found": False, "query": query, "url": url,
                "conclusion": f"PubChem returned no properties for {query!r}; no value is given."}
    record = rows[0]
    cid = record.get("CID")
    result = {"found": True, "query": query, "cid": cid, "properties": record,
              "matches": len(rows), "url": f"https://pubchem.ncbi.nlm.nih.gov/compound/{cid}",
              "status": "PubChem computed properties (XLogP and TPSA are model values)"}
    heading = data.get("experimental")
    if heading is not None:
        if not isinstance(heading, str) or not heading.strip():
            fail("experimental must name a PubChem heading, e.g. \"Boiling Point\", \"pKa\" or \"Glass Transition Temperature\"")
        view_url = f"{PUBCHEM_VIEW}/{cid}/JSON?heading={quote(heading)}"
        status, text = fetch(view_url, None)
        if status == 404:
            result["experimental"] = {"heading": heading, "values": [], "url": view_url}
        elif status != 200:
            fail(f"PubChem answered HTTP {status} for {heading}: {text[:200]}")
        else:
            record_view = json.loads(text).get("Record", {})
            references = {r.get("ReferenceNumber"): r for r in record_view.get("Reference", []) or []}
            values = _texts(record_view, references, [])
            result["experimental"] = {"heading": heading, "values": values[:15], "count": len(values),
                                      "url": view_url}
    parts = [f"PubChem CID {cid} ({record.get('IUPACName') or query}): formula {record.get('MolecularFormula')}, "
             f"molecular weight {record.get('MolecularWeight')}"]
    if record.get("XLogP") is not None:
        parts.append(f"XLogP {record['XLogP']} (computed)")
    if len(rows) > 1:
        parts.append(f"{len(rows)} records matched; the first is shown")
    experimental = result.get("experimental")
    if experimental is not None:
        if experimental["values"]:
            first = experimental["values"][0]
            parts.append(f"{heading}: {len(experimental.get('values'))} reported value(s), e.g. {first['value']!r} "
                         f"({first['source'] or 'source not named'})")
        else:
            parts.append(f"no {heading} section in PubChem; no value is given")
    result["conclusion"] = "; ".join(parts) + "."
    return result


def constant(data, fail, fetch=None):
    if data.get("source") == "pubchem" or "compound" in data or "experimental" in data:
        return _pubchem(data, fetch, fail)
    if isinstance(data.get("names"), list) or isinstance(data.get("name"), str):
        names = data["names"] if isinstance(data.get("names"), list) else [data["name"]]
        rows, missing = _named(names, fail)
        text = "; ".join(f"{n} = {r['value']:.10g} {r['unit']} ({r['status']})" for n, r in rows.items())
        if missing:
            text += ("; " if text else "") + (f"not in the built-in table: {', '.join(missing)} (known: "
                                              f"{', '.join(sorted(CONSTANTS))}); no value is given")
        return {"constants": rows, "not_found": missing, "conclusion": text + ".", "source": CODATA}
    if isinstance(data.get("formula"), str):
        result = _formula(data["formula"], fail)
        result["conclusion"] = (f"{data['formula']}: molar mass {result['molar_mass']:.4f} g/mol "
                                f"(standard atomic weights, {result['source']}).")
        return result
    if isinstance(data.get("smiles"), str):
        result = _smiles(data["smiles"], fail)
        result["conclusion"] = (f"{result['canonical_smiles']}: {result['formula']}, molar mass "
                                f"{result['molar_mass']:.3f} g/mol, Crippen logP {result['logp_crippen']:.2f} "
                                f"(computed by {result['source']}).")
        return result
    fail("give name/names (physical constants), formula, smiles (computed with RDKit), or compound/smiles "
         "with source=\"pubchem\" (optionally experimental: a PubChem heading)")
