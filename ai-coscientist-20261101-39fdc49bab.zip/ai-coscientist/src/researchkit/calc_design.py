"""calc kind=design: which experiment to run next.

augment: pick candidates that make the most factor effects estimable (greedy D-optimal).
discriminate: pick candidates whose measurement best tells competing hypotheses apart.
"""

from __future__ import annotations

import itertools
import math

import numpy as np


MAX_CANDIDATES = 500
MAX_PICK = 20


def _encode(rows, factors, fail):
    """Design matrix with an intercept: numeric factors standardised, categorical ones one-hot."""
    ids = list(rows)
    columns, owners = [np.ones(len(ids))], [None]
    for factor in factors:
        values = [rows[i].get(factor) for i in ids]
        missing = [i for i, v in zip(ids, values) if v is None]
        if missing:
            fail(f"factor {factor}: no value for {', '.join(missing[:5])}")
        if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
            column = np.array(values, float)
            spread = column.std()
            columns.append((column - column.mean()) / spread if spread else column * 0)
            owners.append(factor)
        else:
            levels = list(dict.fromkeys(str(v) for v in values))
            for level in levels[1:]:
                columns.append(np.array([1.0 if str(v) == level else 0.0 for v in values]))
                owners.append(factor)
    return ids, np.array(columns).T, owners


def _separable(matrix, owners):
    """How many factors vary in these rows and can be told apart from all the others."""
    total = _rank(matrix)
    count = 0
    for factor in dict.fromkeys(o for o in owners if o):
        mine = [j for j, o in enumerate(owners) if o == factor]
        if not np.any(np.abs(matrix[:, mine] - matrix[:1, mine]) > 1e-12):
            continue
        rest = [j for j, o in enumerate(owners) if o != factor]
        if total - _rank(matrix[:, rest]) == len(mine):
            count += 1
    return count


def _rank(matrix):
    return int(np.linalg.matrix_rank(matrix, tol=1e-9)) if len(matrix) else 0


def _logdet(matrix):
    sign, value = np.linalg.slogdet(matrix.T @ matrix + 1e-6 * np.eye(matrix.shape[1]))
    return value


def augment(data, fail):
    from researchkit import calc_checks

    existing, candidates = data.get("existing", {}), data.get("candidates")
    if not isinstance(existing, dict) or not isinstance(candidates, dict) or not candidates:
        fail("give candidates (id -> factor values) and optionally existing samples in the same form")
    if len(candidates) > MAX_CANDIDATES:
        fail(f"at most {MAX_CANDIDATES} candidates")
    overlap = set(existing) & set(candidates)
    if overlap:
        fail(f"ids used in both existing and candidates: {', '.join(sorted(overlap))}")
    pick = data.get("pick", 1)
    if isinstance(pick, bool) or not isinstance(pick, int) or not 1 <= pick <= min(MAX_PICK, len(candidates)):
        fail(f"pick must be an integer from 1 to {min(MAX_PICK, len(candidates))}")
    rows = {**existing, **candidates}
    factors = data.get("factors") or list(dict.fromkeys(k for r in rows.values() for k in r))
    ids, matrix, owners = _encode(rows, factors, fail)
    index = {i: n for n, i in enumerate(ids)}
    chosen = [index[i] for i in existing]
    before = max(_rank(matrix[chosen]) - 1, 0) if chosen else 0
    picks = []
    remaining = [index[c] for c in candidates]
    for _ in range(pick):
        def score(n):
            trial = matrix[chosen + [n]]
            return (_separable(trial, owners), _rank(trial), _logdet(trial), -n)
        best = max(remaining, key=score)
        gain = _rank(matrix[chosen + [best]]) - (_rank(matrix[chosen]) if chosen else 0)
        chosen.append(best)
        remaining.remove(best)
        picks.append({"id": ids[best], "adds_estimable_effect": gain > 0})
    after = _rank(matrix[chosen]) - 1
    possible = _rank(matrix) - 1
    final_rows = {ids[n]: rows[ids[n]] for n in chosen}

    def quiet(message):
        raise ValueError(message)

    try:
        separation = calc_checks.design({"rows": final_rows, "factors": factors}, quiet)
    except ValueError:
        separation = None
    names = ", ".join(p["id"] for p in picks)
    text = (f"Measure {names}: estimable effects go from {before} to {after} "
            f"(at most {possible} with every candidate)")
    if separation and separation.get("entangled"):
        text += f"; still entangled: {', '.join(separation['entangled'])}"
    elif separation:
        text += "; every varying factor is then separable"
    idle = [p["id"] for p in picks if not p["adds_estimable_effect"]]
    if idle:
        text += f". {', '.join(idle)} {'adds' if len(idle) == 1 else 'add'} no new effect, only precision"
    return {"mode": "augment", "picks": picks, "estimable_before": before, "estimable_after": after,
            "estimable_with_all": possible, "separation": separation, "conclusion": text + ".",
            "note": "Effects are main effects only (no interactions); a factor's levels come from all listed rows."}


def _phi(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def discriminate(data, fail):
    predictions, sd = data.get("predictions"), data.get("sd")
    if not isinstance(predictions, dict) or len(predictions) < 2:
        fail("predictions must map at least two hypotheses to {candidate id: predicted measured value}")
    if isinstance(sd, bool) or not isinstance(sd, (int, float)) or not sd > 0:
        fail("sd must be the expected measurement error (a positive number, same unit as the predictions)")
    hypotheses = list(predictions)
    candidates = list(dict.fromkeys(c for p in predictions.values() if isinstance(p, dict) for c in p))
    if not candidates:
        fail("no candidate predictions given")
    for h, p in predictions.items():
        if not isinstance(p, dict) or not all(isinstance(v, (int, float)) and not isinstance(v, bool)
                                              for v in p.values()):
            fail(f"predictions.{h} must map candidate ids to numbers")
    pick = data.get("pick", 1)
    if isinstance(pick, bool) or not isinstance(pick, int) or not 1 <= pick <= len(candidates):
        fail(f"pick must be an integer from 1 to {len(candidates)}")
    rows = {}
    for c in candidates:
        pairs = []
        for a, b in itertools.combinations(hypotheses, 2):
            if c in predictions[a] and c in predictions[b]:
                gap = abs(predictions[a][c] - predictions[b][c])
                pairs.append({"pair": [a, b], "gap": gap, "tell_apart": _phi(gap / (2 * sd))})
        if not pairs:
            continue
        rows[c] = {"mean_tell_apart": sum(p["tell_apart"] for p in pairs) / len(pairs),
                   "weakest_pair": min(pairs, key=lambda p: p["tell_apart"]),
                   "pairs_compared": len(pairs)}
    if not rows:
        fail("no candidate has predictions from two or more hypotheses")
    ranked = sorted(rows, key=lambda c: (-rows[c]["mean_tell_apart"], candidates.index(c)))
    picks = ranked[:pick]
    best = rows[picks[0]]
    text = (f"Measure {', '.join(picks)}: a measurement of {picks[0]} points to the right hypothesis with "
            f"probability {best['mean_tell_apart']:.0%} on average over hypothesis pairs "
            f"(weakest pair {'/'.join(best['weakest_pair']['pair'])}: {best['weakest_pair']['tell_apart']:.0%})")
    if best["mean_tell_apart"] < 0.6:
        text += ". No candidate separates the hypotheses well at this measurement error"
    return {"mode": "discriminate", "picks": picks, "candidates": {c: rows[c] for c in ranked},
            "conclusion": text + ".",
            "note": "Assumes each hypothesis's prediction is exact and the measurement error is normal with sd; "
                    "50% means the measurement cannot tell the pair apart."}


def design(data, fail):
    if "predictions" in data:
        return discriminate(data, fail)
    if "candidates" in data:
        return augment(data, fail)
    fail("give candidates (and existing samples) to choose what makes effects separable, or predictions "
         "(per hypothesis) with sd to choose what tells hypotheses apart")
