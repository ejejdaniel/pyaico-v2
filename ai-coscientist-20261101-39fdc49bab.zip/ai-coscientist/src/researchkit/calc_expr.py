"""Plain infix expressions for calc: one parser, three evaluators.

Expressions are written the way they appear on paper:
`y = 12 - k*(x - 2)`, `0.5 <= k <= 1.5`, `x <= 3 -> y >= 10`, `x^2`,
`exp(-Ea/(R*T))`. The same parsed form is evaluated on numbers (numpy arrays),
on intervals (guaranteed bounds) and as Z3 terms (logic).
"""

from __future__ import annotations

import ast
import functools
import math
import re
from fractions import Fraction

import numpy as np


MAX_CHARS = 4000
MAX_DEPTH = 100
FUNCTIONS = {"exp": 1, "log": 1, "sqrt": 1, "abs": 1, "min": None, "max": None, "implies": 2}
_REPLACE = (("≤", "<="), ("≥", ">="), ("≠", "!="), ("−", "-"), ("×", "*"), ("^", "**"))
HELP = ("Write numbers, names, + - * / ^, exp log sqrt abs min max, comparisons (5 <= k <= 7 is fine), "
        "= or ==, and/or/not, and A -> B for implication.")


class ExprError(ValueError):
    """An expression the calculator cannot read or evaluate."""


def _split_implication(text):
    depth = 0
    for i in range(len(text) - 1):
        char = text[i]
        if char in "([":
            depth += 1
        elif char in ")]":
            depth -= 1
        elif depth == 0 and text[i:i + 2] in ("->", "=>") and (i == 0 or text[i - 1] not in "<>=!"):
            return text[:i], text[i + 2:]
    return None


def parse(text, label="expression"):
    if not isinstance(text, str) or not text.strip():
        raise ExprError(f"{label}: expected a nonempty expression string. {HELP}")
    if len(text) > MAX_CHARS:
        raise ExprError(f"{label}: longer than {MAX_CHARS} characters")
    for old, new in _REPLACE:
        text = text.replace(old, new)
    parts = _split_implication(text)
    if parts:
        return ("implies", parse(parts[0], label), parse(parts[1], label))
    source = re.sub(r"(?<![<>=!])=(?!=)", "==", text.strip())
    try:
        tree = ast.parse(source, mode="eval")
    except SyntaxError as exc:
        raise ExprError(f"{label}: cannot read {text.strip()!r} ({exc.msg}). {HELP}") from None
    return _convert(tree.body, source, label, 0)


_BINARY = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.Pow: "**"}
_COMPARE = {ast.Lt: "<", ast.LtE: "<=", ast.Gt: ">", ast.GtE: ">=", ast.Eq: "==", ast.NotEq: "!="}


def _convert(node, source, label, depth):
    if depth > MAX_DEPTH:
        raise ExprError(f"{label}: nested more than {MAX_DEPTH} levels")

    def child(item):
        return _convert(item, source, label, depth + 1)

    if isinstance(node, ast.Constant):
        if isinstance(node.value, bool):
            return ("bool", node.value)
        if isinstance(node.value, (int, float)):
            literal = (ast.get_source_segment(source, node) or repr(node.value)).replace("_", "")
            try:
                return ("num", Fraction(literal))
            except (ValueError, ZeroDivisionError):
                return ("num", Fraction(node.value))
    elif isinstance(node, ast.Name):
        if node.id == "pi":
            return ("num", Fraction(math.pi))
        if node.id in FUNCTIONS:
            raise ExprError(f"{label}: {node.id} is a function; write {node.id}(...)")
        return ("var", node.id)
    elif isinstance(node, ast.UnaryOp):
        if isinstance(node.op, ast.USub):
            return ("neg", child(node.operand))
        if isinstance(node.op, ast.UAdd):
            return child(node.operand)
        if isinstance(node.op, ast.Not):
            return ("not", child(node.operand))
    elif isinstance(node, ast.BinOp) and type(node.op) in _BINARY:
        return ("bin", _BINARY[type(node.op)], child(node.left), child(node.right))
    elif isinstance(node, ast.BoolOp):
        return ("and" if isinstance(node.op, ast.And) else "or", tuple(child(v) for v in node.values))
    elif isinstance(node, ast.Compare) and all(type(op) in _COMPARE for op in node.ops):
        return ("cmp", tuple(_COMPARE[type(op)] for op in node.ops),
                tuple(child(item) for item in [node.left, *node.comparators]))
    elif (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCTIONS
          and not node.keywords):
        name, args = node.func.id, tuple(child(a) for a in node.args)
        arity = FUNCTIONS[name]
        if (arity is None and len(args) < 2) or (arity is not None and len(args) != arity):
            raise ExprError(f"{label}: {name} takes {'two or more' if arity is None else arity} argument(s)")
        return ("implies", *args) if name == "implies" else ("call", name, args)
    part = ast.get_source_segment(source, node) or type(node).__name__
    called = node.func.id if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) else None
    instead = f" (write {ALIASES[called]})" if called in ALIASES else ""
    raise ExprError(f"{label}: unsupported part {part!r}{instead}. {HELP}")


# Names models reach for that the calculator spells otherwise.
ALIASES = {"ln": "log, the natural logarithm", "log10": "log(x)/log(10)", "log2": "log(x)/log(2)",
           "pow": "a^b", "power": "a^b", "fabs": "abs"}


# ---- types: every name is a number unless it is used as a condition ----

def infer(node, expected, sorts, label="expression"):
    """Record each name's sort ("num" or "bool") in sorts; reject mixed use."""
    kind = node[0]
    actual = "bool" if kind in ("bool", "cmp", "and", "or", "not", "implies") else "num"
    if kind == "var":
        previous = sorts.setdefault(node[1], expected)
        if previous != expected:
            raise ExprError(f"{label}: {node[1]} is used both as a number and as a condition")
        return
    if actual != expected:
        raise ExprError(f"{label}: expected a {'condition' if expected == 'bool' else 'number'} "
                        f"but found a {'condition' if actual == 'bool' else 'number'}")
    if kind in ("neg", "not"):
        infer(node[1], actual, sorts, label)
    elif kind == "bin":
        infer(node[2], "num", sorts, label)
        infer(node[3], "num", sorts, label)
    elif kind in ("call", "cmp"):
        for item in node[2]:
            infer(item, "num", sorts, label)
    elif kind in ("and", "or"):
        for item in node[1]:
            infer(item, "bool", sorts, label)
    elif kind == "implies":
        infer(node[1], "bool", sorts, label)
        infer(node[2], "bool", sorts, label)


def is_condition(node):
    return node[0] in ("bool", "cmp", "and", "or", "not", "implies")


def names(node, found=None):
    found = set() if found is None else found
    if node[0] == "var":
        found.add(node[1])
    for item in node[1:]:
        if isinstance(item, tuple) and item and isinstance(item[0], str):
            names(item, found)
        elif isinstance(item, tuple):
            for sub in item:
                if isinstance(sub, tuple) and sub and isinstance(sub[0], str):
                    names(sub, found)
    return found


def constant(node):
    """Exact value of an expression without names, or None."""
    kind = node[0]
    if kind == "num":
        return node[1]
    if kind == "neg":
        value = constant(node[1])
        return None if value is None else -value
    if kind == "bin":
        left, right = constant(node[2]), constant(node[3])
        if left is None or right is None:
            return None
        if node[1] == "/":
            return None if right == 0 else left / right
        if node[1] == "**":
            if right.denominator != 1 or abs(right) > 64 or (left == 0 and right < 0):
                return None
            return left ** int(right)
        return {"+": left + right, "-": left - right, "*": left * right}[node[1]]
    return None


# ---- numbers (numpy arrays broadcast over draws) ----

def evaluate(node, env):
    kind = node[0]
    if kind == "num":
        return float(node[1])
    if kind == "bool":
        return node[1]
    if kind == "var":
        if node[1] not in env:
            raise ExprError(f"no value given for {node[1]}")
        return env[node[1]]
    if kind == "neg":
        return -evaluate(node[1], env)
    if kind == "bin":
        left, right = evaluate(node[2], env), evaluate(node[3], env)
        op = node[1]
        return (left + right if op == "+" else left - right if op == "-" else left * right if op == "*"
                else np.divide(left, right) if op == "/" else np.power(np.asarray(left, float), right))
    if kind == "call":
        args = [evaluate(item, env) for item in node[2]]
        name = node[1]
        if name == "min":
            return functools.reduce(np.minimum, args)
        if name == "max":
            return functools.reduce(np.maximum, args)
        return {"exp": np.exp, "log": np.log, "sqrt": np.sqrt, "abs": np.abs}[name](args[0])
    if kind == "cmp":
        values = [evaluate(item, env) for item in node[2]]
        result = True
        for op, left, right in zip(node[1], values, values[1:]):
            step = {"<": np.less, "<=": np.less_equal, ">": np.greater, ">=": np.greater_equal,
                    "==": np.equal, "!=": np.not_equal}[op](left, right)
            result = np.logical_and(result, step)
        return result
    if kind == "and":
        return functools.reduce(np.logical_and, [evaluate(item, env) for item in node[1]])
    if kind == "or":
        return functools.reduce(np.logical_or, [evaluate(item, env) for item in node[1]])
    if kind == "not":
        return np.logical_not(evaluate(node[1], env))
    if kind == "implies":
        return np.logical_or(np.logical_not(evaluate(node[1], env)), evaluate(node[2], env))
    raise ExprError(f"cannot evaluate {kind}")


# ---- intervals: outer bounds (up to floating-point rounding) ----

INF = math.inf


def _safe(function, value):
    try:
        return function(value)
    except OverflowError:
        return INF


def _mul(a, b):
    products = [0.0 if (x == 0 and math.isinf(y)) or (y == 0 and math.isinf(x)) else x * y
                for x in a for y in b]
    return min(products), max(products)


def _div(a, b, label):
    if b[0] <= 0 <= b[1]:
        if b[0] == b[1] == 0:
            raise ExprError(f"{label}: division by zero")
        return -INF, INF
    return _mul(a, (1 / b[1], 1 / b[0]))


def _pow(a, exponent, label):
    lo, hi = a
    if exponent.denominator == 1:
        n = int(exponent)
        if n == 0:
            return 1.0, 1.0
        if n < 0:
            return _div((1.0, 1.0), _pow(a, -exponent, label), label)
        ends = (_safe(lambda v: v ** n, lo), _safe(lambda v: v ** n, hi))
        if n % 2 == 0:
            ends = tuple(abs(e) for e in ends)
            return (0.0 if lo <= 0 <= hi else min(ends)), max(ends)
        return (-INF if lo == -INF else ends[0]), ends[1]
    if hi < 0:
        raise ExprError(f"{label}: non-integer power of a negative range")
    lo = max(lo, 0.0)
    p = float(exponent)
    if p > 0:
        return lo ** p, _safe(lambda v: v ** p, hi)
    return (_safe(lambda v: v ** p, hi), INF if lo == 0 else lo ** p)


def interval(node, box, label="expression"):
    kind = node[0]
    if kind == "num":
        return float(node[1]), float(node[1])
    if kind == "var":
        return box[node[1]]
    if kind == "neg":
        lo, hi = interval(node[1], box, label)
        return -hi, -lo
    if kind == "bin":
        op = node[1]
        left = interval(node[2], box, label)
        if op == "**":
            exponent = constant(node[3])
            if exponent is not None:
                return _pow(left, exponent, label)
            if left[0] <= 0:
                raise ExprError(f"{label}: a variable power needs a positive base range")
            log = (math.log(left[0]), _safe(math.log, left[1]))
            product = _mul(interval(node[3], box, label), log)
            return _safe(math.exp, product[0]), _safe(math.exp, product[1])
        right = interval(node[3], box, label)
        if op == "+":
            return left[0] + right[0], left[1] + right[1]
        if op == "-":
            return left[0] - right[1], left[1] - right[0]
        if op == "*":
            return _mul(left, right)
        return _div(left, right, label)
    if kind == "call":
        args = [interval(item, box, label) for item in node[2]]
        name = node[1]
        (lo, hi) = args[0]
        if name == "exp":
            return _safe(math.exp, lo), _safe(math.exp, hi)
        if name == "log":
            if hi <= 0:
                raise ExprError(f"{label}: log of a range that is never positive")
            return (-INF if lo <= 0 else math.log(lo)), _safe(math.log, hi)
        if name == "sqrt":
            if hi < 0:
                raise ExprError(f"{label}: sqrt of a negative range")
            return math.sqrt(max(lo, 0.0)), _safe(math.sqrt, hi)
        if name == "abs":
            if lo >= 0:
                return lo, hi
            if hi <= 0:
                return -hi, -lo
            return 0.0, max(-lo, hi)
        if name == "min":
            return min(a[0] for a in args), min(a[1] for a in args)
        if name == "max":
            return max(a[0] for a in args), max(a[1] for a in args)
    raise ExprError(f"{label}: bounds need a numeric expression, not a condition")


# ---- Z3 terms ----

def to_z3(node, symbols, z3, context, label="expression"):
    def term(item):
        return to_z3(item, symbols, z3, context, label)

    kind = node[0]
    if kind == "num":
        return z3.RealVal(f"{node[1].numerator}/{node[1].denominator}", ctx=context)
    if kind == "bool":
        return z3.BoolVal(node[1], ctx=context)
    if kind == "var":
        return symbols[node[1]]
    if kind == "neg":
        return -term(node[1])
    if kind == "bin":
        op = node[1]
        if op == "**":
            exponent = constant(node[3])
            if exponent is None or exponent.denominator != 1 or abs(exponent) > 16:
                raise ExprError(f"{label}: logic handles whole-number powers up to 16; "
                                "check other powers with kind=interval")
            base = term(node[2])
            n = int(exponent)
            if n == 0:
                return z3.RealVal(1, ctx=context)
            result = base
            for _ in range(abs(n) - 1):
                result = result * base
            return result if n > 0 else 1 / result
        left, right = term(node[2]), term(node[3])
        return left + right if op == "+" else left - right if op == "-" else left * right if op == "*" else left / right
    if kind == "call":
        name = node[1]
        if name in ("exp", "log", "sqrt"):
            raise ExprError(f"{label}: logic cannot reason about {name}; write the relation as a polynomial, "
                            "or check bounds with kind=interval")
        args = [term(item) for item in node[2]]
        if name == "abs":
            return z3.If(args[0] >= 0, args[0], -args[0])
        result = args[0]
        for item in args[1:]:
            result = z3.If(item < result, item, result) if name == "min" else z3.If(item > result, item, result)
        return result
    if kind == "cmp":
        values = [term(item) for item in node[2]]
        steps = []
        for op, left, right in zip(node[1], values, values[1:]):
            steps.append({"<": lambda a, b: a < b, "<=": lambda a, b: a <= b, ">": lambda a, b: a > b,
                          ">=": lambda a, b: a >= b, "==": lambda a, b: a == b,
                          "!=": lambda a, b: a != b}[op](left, right))
        return steps[0] if len(steps) == 1 else z3.And(*steps)
    if kind == "and":
        return z3.And(*[term(item) for item in node[1]])
    if kind == "or":
        return z3.Or(*[term(item) for item in node[1]])
    if kind == "not":
        return z3.Not(term(node[1]))
    if kind == "implies":
        return z3.Implies(term(node[1]), term(node[2]))
    raise ExprError(f"{label}: cannot translate {kind}")
