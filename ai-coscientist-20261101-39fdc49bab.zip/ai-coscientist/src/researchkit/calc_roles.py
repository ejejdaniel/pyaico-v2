"""calc kind=roles: which component can take which role, by the structural features a role requires.

A task may define roles by structure ("the catalyst carries group X", "the inhibitor has motif Y").
Runs assigned a salt to a role because its cation looked like that role's, although only another
component carried the group the task requires of it. This checks every supplied structure against
the features the author quotes from the task, by RDKit substructure match, and says which roles each
component can take and whether an assignment holds. It also gives the acid strength of each ion,
since a salt's acid-base behaviour comes from its anion, and tells an ester from an acid or base site.
"""

from __future__ import annotations


def _names(items):
    return ", ".join(items) if items else "none"


# Acid-base sites, first match wins for an atom. The site atom comes first in each pattern, which
# matches the acid and its anion alike. Reference values are measured pKa in water from the PubChem
# record of the reference compound (the source PubChem cites); they order acid strength, they are not
# the pKa of these exact structures or of the acid in a film or another solvent.
# (class, SMARTS, reference compound, pKa, bound, source)
ACID_SITES = (
    ("fluoroalkanesulfonic acid", "[OX1-,OX2H1]S(=O)(=O)[CX4](F)", "methanesulfonic acid", -1.86, "<",
     "HSDB via PubChem CID 6395; fluorine next to the acid group lowers pKa, as in trifluoroacetic acid 0.3 "
     "(HSDB, CID 6422) against acetic acid 4.756 (ChEMBL, CID 176)"),
    ("sulfonic acid", "[OX1-,OX2H1]S(=O)(=O)[#6]", "methanesulfonic acid", -1.86, "≈", "HSDB via PubChem CID 6395"),
    ("fluoroalkanoic acid", "[OX1-,OX2H1]C(=O)[CX4](F)", "trifluoroacetic acid", 0.3, "≈", "HSDB via PubChem CID 6422"),
    ("phosphoric or phosphonic acid", "[OX1-,OX2H1]P(=O)", "phosphoric acid (first)", 2.15, "≈",
     "HSDB via PubChem CID 1004"),
    ("aromatic carboxylic acid", "[OX1-,OX2H1]C(=O)c", "benzoic acid", 4.207, "≈",
     "ChEMBL via PubChem CID 243; ring substituents shift it"),
    ("aliphatic carboxylic acid", "[OX1-,OX2H1]C(=O)[#6]", "acetic acid", 4.756, "≈", "ChEMBL via PubChem CID 176"),
    ("phenol", "[OX1-,OX2H1]c", "phenol", 9.99, "≈", "DrugBank via PubChem CID 996"),
    ("protonated amine", "[NX4+;!H0]", "trimethylammonium", 9.8, "≈", "ChEMBL via PubChem CID 1146"),
    ("amine", "[NX3;H0,H1,H2;!$(N[a]);!$(N[#6]=[O,S,N]);!$(NS(=O)=O)]", "trimethylammonium", 9.8, "≈",
     "ChEMBL via PubChem CID 1146"),
)
NO_PROTON_CATION = "[+;H0;!$(*~[-])]"
ESTER = "[#6][CX3](=O)[OX2][#6]"


def _strength(site):
    if site["bound"] == "<":
        return f"pKa < {site['pKa']:g} (below {site['reference']})"
    return f"pKa ≈ {site['pKa']:g} ({site['reference']})"


def _acid_base(molecules, Chem):
    """Per structure: each acid or base site, the class of acid it is or gives, and cations with no proton."""
    patterns = [(cls, Chem.MolFromSmarts(smarts), ref, pka, bound, source)
                for cls, smarts, ref, pka, bound, source in ACID_SITES]
    cation = Chem.MolFromSmarts(NO_PROTON_CATION)
    found = {}
    for name, molecule in molecules.items():
        sites, claimed = [], set()
        for cls, pattern, ref, pka, bound, source in patterns:
            for match in molecule.GetSubstructMatches(pattern):
                atom = match[0]
                if atom in claimed:
                    continue
                claimed.add(atom)
                charge = molecule.GetAtomWithIdx(atom).GetFormalCharge()
                form = "anion" if charge < 0 else "base" if cls == "amine" else "acid"
                sites.append({"site": form, "acid": cls, "reference": ref, "pKa": pka, "bound": bound,
                              "source": source, "atom": atom})
        for (atom,) in molecule.GetSubstructMatches(cation):
            sites.append({"site": "cation with no proton", "atom": atom,
                          "element": molecule.GetAtomWithIdx(atom).GetSymbol()})
        for atom in molecule.GetAtoms():
            if atom.GetFormalCharge() < 0 and atom.GetIdx() not in claimed and not any(
                    n.GetFormalCharge() > 0 for n in atom.GetNeighbors()):
                sites.append({"site": "anion", "acid": "not in the reference table", "atom": atom.GetIdx()})
        found[name] = sites
    return found


def _acid_base_text(components, sites):
    anions = [(component, part, site) for component, parts in components.items() for part in parts
              for site in sites[part] if site["site"] == "anion" and "pKa" in site]
    if len({site["acid"] for _, _, site in anions}) < 2:
        return ""
    order = sorted(anions, key=lambda item: item[2]["pKa"] - (1 if item[2]["bound"] == "<" else 0))
    text = (" Acid each anion gives on taking a proton, strongest first: " + "; ".join(
        f"{part} in {component}: {site['acid']}, {_strength(site)}" for component, part, site in order) + ".")
    strong, weak = order[0], order[-1]
    gap = weak[2]["pKa"] - strong[2]["pKa"]
    if strong[0] != weak[0]:
        if gap >= 2:
            text += (f" An anion takes the proton of a clearly stronger acid: {weak[1]} ({weak[0]}) is a base toward "
                     f"the acid of {strong[1]} ({strong[0]}).")
        else:
            text += (f" {weak[1]} and {strong[1]} give acids within 2 pKa units: a proton passes between them "
                     "only in part.")
    holders = sorted({component for component, _, _ in anions})
    bare = sorted({part for component in holders for part in components[component]
                   if any(s["site"] == "cation with no proton" for s in sites[part])})
    if bare:
        text += (f" The cations {_names(bare)} carry no proton: each salt's acid-base behaviour comes from its "
                 "anion.")
    return text


def all_problems(problems: list[str]) -> str:
    """One message with every problem found in an input, so that one revision can fix them all. LIT (2026-10-31)
    sent this input three times, and each refusal named a different problem."""
    return problems[0] if len(problems) == 1 else (
        f"{len(problems)} problems, all of them listed so one revision fixes them:\n"
        + "\n".join(f"- {problem}" for problem in problems))


def _named(value) -> bool:
    return isinstance(value, str) and bool(value.strip())


def roles(data, fail):
    problems = []
    structures = data.get("structures")
    if not isinstance(structures, dict) or not structures:
        problems.append("structures must map each supplied structure name to its SMILES")
        structures = {}
    else:
        bad = [str(name) for name, smiles in structures.items() if not (_named(name) and _named(smiles))]
        if bad:
            problems.append(f"structures must map each supplied structure name to its SMILES; these have none: "
                            f"{', '.join(bad)} (a structure the task does not give stays out, and its role is a gap)")
    components = data.get("components") or {name: [name] for name in structures}
    if not isinstance(components, dict) or not all(
            isinstance(parts, list) and parts and all(isinstance(p, str) for p in parts) for parts in components.values()):
        problems.append("components must map each component to the list of structure names it consists of "
                        "(a salt or composite term lists every fragment)")
        components = {}
    unknown = sorted({p for parts in components.values() for p in parts} - set(structures))
    if unknown and structures:
        problems.append(f"components name structures that are not in structures: {', '.join(unknown)}")
    features = data.get("features")
    if not isinstance(features, dict) or not features:
        problems.append("features must map each structural feature the task names to a SMARTS pattern (quote the "
                        "task's own structure where it gives one)")
        features = {}
    else:
        bad = [str(name) for name, smarts in features.items() if not (_named(name) and _named(smarts))]
        if bad:
            problems.append(f"features must map each structural feature to a SMARTS pattern; these have none: "
                            f"{', '.join(bad)}")
    required = {}
    roles_given = data.get("roles") if isinstance(data.get("roles"), dict) else {}
    for role, spec in roles_given.items():
        needs = spec.get("requires") if isinstance(spec, dict) else spec
        if not isinstance(needs, list) or not needs or not all(isinstance(f, str) for f in needs):
            problems.append(f"roles.{role} must give requires: the features the task says that role carries")
            continue
        missing = [f for f in needs if f not in features]
        if missing:
            problems.append(f"roles.{role} requires features not defined in features: {', '.join(missing)}")
        required[role] = needs
    if not roles_given:
        problems.append("roles must map each role the task defines to {\"requires\": [features], "
                        "\"source\": \"<the task's words>\"}")
    assigned = data.get("assigned") or {}
    if not isinstance(assigned, dict) or not all(c in components and r in required for c, r in assigned.items()):
        problems.append("assigned, when given, maps components to roles, both named above")
    if problems:
        fail(all_problems(problems))

    from rdkit import Chem, RDLogger
    RDLogger.DisableLog("rdApp.*")
    molecules = {}
    for name, smiles in structures.items():
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            fail(f"structures.{name}: RDKit cannot read the SMILES {smiles!r}")
        molecules[name] = molecule
    patterns = {}
    for name, smarts in features.items():
        pattern = Chem.MolFromSmarts(smarts)
        if pattern is None:
            fail(f"features.{name}: RDKit cannot read the SMARTS {smarts!r}")
        patterns[name] = pattern

    carriers = {component: {feature: [part for part in parts if molecules[part].HasSubstructMatch(pattern)]
                            for feature, pattern in patterns.items()}
                for component, parts in components.items()}
    admissible = {component: [role for role, needs in required.items() if all(found[f] for f in needs)]
                  for component, found in carriers.items()}
    candidates = {role: [c for c in components if role in admissible[c]] for role in required}
    checks = []
    for component, role in assigned.items():
        lacking = [f for f in required[role] if not carriers[component][f]]
        checks.append({"component": component, "role": role, "holds": not lacking, "lacks": lacking})
    wrong = [c for c in checks if not c["holds"]]
    unfilled = [role for role, names in candidates.items() if not names]
    # A feature no supplied structure has is more often a pattern that does not say what the task says
    # than a missing component (v34 put the ring of a benzoate on the oxygen; a polymer repeat unit has
    # lost the double bond its monomer's motif names).
    unmatched = [f for f in features if not any(carriers[c][f] for c in components)]
    if wrong:
        conclusion = "; ".join(
            f"{c['component']} cannot be {c['role']}: none of its parts ({_names(components[c['component']])}) "
            f"carries {_names(c['lacks'])}" for c in wrong) + "."
    elif checks:
        conclusion = "Every assignment has the features its role requires: " + "; ".join(
            f"{c['component']} as {c['role']}" for c in checks) + "."
    else:
        conclusion = "; ".join(f"{c} can be {_names(r)}" for c, r in admissible.items()) + "."
    if unmatched:
        conclusion += (f" No structure matches {_names(unmatched)}: check the SMARTS against the task's own fragment "
                       "(the same atoms and bonds, a charged or neutral form, a polymer repeat unit instead of its "
                       "monomer) before treating it as missing.")
    if unfilled:
        conclusion += f" No component carries what {_names(unfilled)} requires: a data gap, not a guess."

    # The same feature can match an ion in one component and a neutral group in another (a benzoate
    # anion and an aryl ester both contain O-C(=O)-aryl); only the first can take or give a proton.
    sites = _acid_base(molecules, Chem)
    site_atoms = {part: {s["atom"] for s in found if s["site"] != "cation with no proton"}
                  for part, found in sites.items()}
    ester = Chem.MolFromSmarts(ESTER)
    without_site = {}
    for feature in dict.fromkeys(f for needs in required.values() for f in needs):
        on, off = [], []
        for component, found in carriers.items():
            for part in found[feature]:
                matches = molecules[part].GetSubstructMatches(patterns[feature])
                if any(set(m) & site_atoms[part] for m in matches):
                    on.append(f"{part} ({component})")
                else:
                    esters = {a for m in molecules[part].GetSubstructMatches(ester) for a in m}
                    what = "an ester" if all(set(m) & esters for m in matches) else "a neutral group"
                    off.append({"component": component, "part": part, "is": what})
        if on and off:
            without_site[feature] = off
            conclusion += " " + "; ".join(
                f"The {feature} match in {o['part']} ({o['component']}) is {o['is']} with no acid or base site"
                for o in off) + f", unlike {_names(on)}."
    conclusion += _acid_base_text(components, sites)
    acid_base = {component: [{"part": part, **{k: v for k, v in site.items() if k != "atom"}}
                             for part in parts for site in sites[part]]
                 for component, parts in components.items()}
    return {"conclusion": conclusion,
            "acid_base": {c: found for c, found in acid_base.items() if found},
            "feature_matches_without_acid_base_site": without_site,
            "features_found": {c: {f: parts for f, parts in found.items() if parts} for c, found in carriers.items()},
            "admissible_roles": admissible, "candidates_by_role": candidates, "assignment": checks,
            "unfilled_roles": unfilled, "unmatched_features": unmatched,
            "note": "Substructure matches of the features you gave; a match is necessary for a role, not proof of "
                    "it. A component that lacks a feature its role requires cannot take that role, whatever its "
                    "other parts resemble."}
