"""Subprocess side of calc kind=properties: import the author's module and call one function.

Reads {"module", "function", "output", "call", "calls"} as JSON on stdin and
prints MARKER followed by {"results": [...]} on stdout. Anything the author's
code prints goes to stderr so it cannot be mistaken for a result. Standalone:
it imports nothing from researchkit.
"""

import contextlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import traceback

MARKER = "@@CALC_RESULT@@"


def _pick(value, path):
    for part in [p for p in str(path).split(".") if p] if path not in (None, "") else []:
        if isinstance(value, (list, tuple)) and part.lstrip("-").isdigit():
            value = value[int(part)]
        elif isinstance(value, dict) and part in value:
            value = value[part]
        else:
            raise KeyError(f"output path {path!r}: cannot take {part!r} from {type(value).__name__}")
    return value


def _number(value):
    if value is None:
        return {"error": "returned None"}
    if isinstance(value, bool):
        return {"error": f"returned a bool ({value}), not a number"}
    if isinstance(value, (list, tuple, dict)):
        # v34 rewrote its functions eight times around a list it could have indexed with "output".
        return {"error": f"returned a {type(value).__name__} of {len(value)}, not a number: name the number to check "
                         "with \"output\" (an index such as \"0\", a key, or a path such as \"P1.0\")"}
    try:
        number = float(value)
    except (TypeError, ValueError):
        return {"error": f"returned {type(value).__name__} {str(value)[:80]!r}, not a number"}
    if not math.isfinite(number):
        return {"error": f"returned {number}"}
    return {"value": number}


def main():
    request = json.loads(sys.stdin.read())
    module_path = Path(request["module"]).resolve()
    sys.path.insert(0, str(module_path.parent))
    results = []
    with contextlib.redirect_stdout(sys.stderr):
        try:
            spec = importlib.util.spec_from_file_location(module_path.stem, module_path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_path.stem] = module
            spec.loader.exec_module(module)
            function = getattr(module, request["function"])
        except Exception as exc:  # the author's module failed to load
            print(MARKER + json.dumps({"load_error": f"{type(exc).__name__}: {exc}",
                                       "trace": traceback.format_exc()[-1500:]}), file=sys.__stdout__)
            return
        for arguments in request["calls"]:
            try:
                if request["call"] == "kwargs":
                    raw = function(**arguments)
                elif request["call"] == "args":
                    raw = function(*arguments)
                else:
                    raw = function(arguments)
                results.append(_number(_pick(raw, request.get("output"))))
            except Exception as exc:
                text = f"{type(exc).__name__}: {str(exc)[:200]}"
                if isinstance(exc, TypeError) and "argument" in str(exc):
                    text += (" (call=" + request["call"] + " passes each input as " + {
                        "single": "the one argument", "kwargs": "named arguments", "args": "positional arguments"}.get(
                        request["call"], "given") + "; a function of several named inputs takes \"call\": \"kwargs\" "
                        "with an object per input, one of several positional inputs \"call\": \"args\" with a list)")
                results.append({"error": text})
    print(MARKER + json.dumps({"results": results}), file=sys.__stdout__)


if __name__ == "__main__":
    main()
