"""calc kind=units: dimensions of a formula and unit conversion, without external packages.

A unit string is a product of units with optional powers: "J/(mol*K)", "kJ/mol",
"g mol^-1", "m s^-1". Each unit is a scale to SI and a vector of base dimensions.
"""

from __future__ import annotations

from fractions import Fraction
import math
import re

from researchkit import calc_expr as ex
from researchkit.calc_expr import ExprError


BASE = ("m", "kg", "s", "A", "K", "mol", "cd")
PREFIXES = {"Y": 1e24, "Z": 1e21, "E": 1e18, "P": 1e15, "T": 1e12, "G": 1e9, "M": 1e6, "k": 1e3, "h": 1e2,
            "da": 1e1, "d": 1e-1, "c": 1e-2, "m": 1e-3, "u": 1e-6, "µ": 1e-6, "μ": 1e-6, "n": 1e-9,
            "p": 1e-12, "f": 1e-15, "a": 1e-18}


def _d(**powers):
    return tuple(Fraction(powers.get(name, 0)) for name in BASE)


NONE = _d()
# name: (scale to SI, dimensions, accepts SI prefixes)
UNITS = {
    "m": (1.0, _d(m=1), True), "g": (1e-3, _d(kg=1), True), "s": (1.0, _d(s=1), True),
    "A": (1.0, _d(A=1), True), "K": (1.0, _d(K=1), True), "mol": (1.0, _d(mol=1), True),
    "cd": (1.0, _d(cd=1), False),
    "N": (1.0, _d(kg=1, m=1, s=-2), True), "J": (1.0, _d(kg=1, m=2, s=-2), True),
    "W": (1.0, _d(kg=1, m=2, s=-3), True), "Pa": (1.0, _d(kg=1, m=-1, s=-2), True),
    "C": (1.0, _d(A=1, s=1), True), "V": (1.0, _d(kg=1, m=2, s=-3, A=-1), True),
    "Hz": (1.0, _d(s=-1), True), "Ohm": (1.0, _d(kg=1, m=2, s=-3, A=-2), True),
    "F": (1.0, _d(kg=-1, m=-2, s=4, A=2), True), "S": (1.0, _d(kg=-1, m=-2, s=3, A=2), True),
    "L": (1e-3, _d(m=3), True), "l": (1e-3, _d(m=3), True),
    "M": (1e3, _d(mol=1, m=-3), False),  # mol/L; prefixed forms mM, uM, nM below
    "mM": (1.0, _d(mol=1, m=-3), False), "uM": (1e-3, _d(mol=1, m=-3), False),
    "nM": (1e-6, _d(mol=1, m=-3), False),
    "min": (60.0, _d(s=1), False), "h": (3600.0, _d(s=1), False), "hr": (3600.0, _d(s=1), False),
    "day": (86400.0, _d(s=1), False),
    "bar": (1e5, _d(kg=1, m=-1, s=-2), True), "atm": (101325.0, _d(kg=1, m=-1, s=-2), False),
    "Torr": (101325.0 / 760, _d(kg=1, m=-1, s=-2), False),
    "eV": (1.602176634e-19, _d(kg=1, m=2, s=-2), True), "cal": (4.184, _d(kg=1, m=2, s=-2), True),
    "Da": (1.66053906660e-27, _d(kg=1), True), "u": (1.66053906660e-27, _d(kg=1), False),
    "angstrom": (1e-10, _d(m=1), False), "Å": (1e-10, _d(m=1), False),
    "degC": (1.0, _d(K=1), False), "°C": (1.0, _d(K=1), False),
    "percent": (1e-2, NONE, False), "%": (1e-2, NONE, False), "wt%": (1e-2, NONE, False),
    "mol%": (1e-2, NONE, False), "ppm": (1e-6, NONE, False), "rad": (1.0, NONE, False),
    "1": (1.0, NONE, False),
}
AFFINE = {"degC", "°C"}


class UnitError(ValueError):
    pass


def _lookup(token):
    if token in UNITS:
        scale, dims, _ = UNITS[token]
        return scale, dims
    for prefix in sorted(PREFIXES, key=len, reverse=True):
        if token.startswith(prefix) and token[len(prefix):] in UNITS and UNITS[token[len(prefix):]][2]:
            scale, dims, _ = UNITS[token[len(prefix):]]
            return PREFIXES[prefix] * scale, dims
    known = ", ".join(sorted(k for k in UNITS if k != "1"))
    raise UnitError(f"unknown unit {token!r}; known units (SI prefixes allowed on most): {known}")


def parse_unit(text):
    """(scale to SI, dimensions) of a unit string."""
    if not isinstance(text, str):
        raise UnitError(f"a unit must be a string, got {text!r}")
    source = text.strip().replace("·", "*").replace("⋅", "*").replace("**", "^")
    if source in ("", "1", "-", "dimensionless"):
        return 1.0, NONE
    tokens = re.findall(r"[A-Za-zµμÅ°%]+|\^|[*/()]|-?\d+(?:/\d+)?|\s+", source)
    if "".join(tokens) != source:
        raise UnitError(f"cannot read unit {text!r}")
    number = re.compile(r"-?\d+(?:/\d+)?")
    position = 0

    def peek():
        return tokens[position] if position < len(tokens) else None

    def skip_space():
        nonlocal position
        while peek() is not None and peek().isspace():
            position += 1

    def factor():
        nonlocal position
        skip_space()
        token = peek()
        if token == "(":
            position += 1
            value = product()
            skip_space()
            if peek() != ")":
                raise UnitError(f"unbalanced parentheses in {text!r}")
            position += 1
        elif token is None or token in ")*/^":
            raise UnitError(f"cannot read unit {text!r}")
        elif number.fullmatch(token):
            position += 1
            if token != "1":
                raise UnitError(f"{text!r}: a bare number {token} is not a unit")
            value = (1.0, NONE)
        else:
            position += 1
            value = _lookup(token)
        if peek() == "^":
            position += 1
            power = peek()
            if power is None or not number.fullmatch(power):
                raise UnitError(f"{text!r}: ^ needs a number")
            position += 1
            value = _power(value, Fraction(power))
        elif peek() is not None and number.fullmatch(peek()):  # cm2, s-1
            value = _power(value, Fraction(peek()))
            position += 1
        return value

    def product():
        nonlocal position
        value = factor()
        while True:
            skip_space()
            token = peek()
            if token is None or token == ")":
                return value
            if token == "/":
                position += 1
                right = factor()
                value = (value[0] / right[0], tuple(a - b for a, b in zip(value[1], right[1])))
                continue
            if token == "*":
                position += 1
            right = factor()
            value = (value[0] * right[0], tuple(a + b for a, b in zip(value[1], right[1])))

    result = product()
    skip_space()
    if position != len(tokens):
        raise UnitError(f"cannot read unit {text!r}")
    return result


def _power(value, power):
    return value[0] ** float(power), tuple(d * power for d in value[1])


def show(dims):
    parts = []
    for name, power in zip(BASE, dims):
        if power == 1:
            parts.append(name)
        elif power:
            parts.append(f"{name}^{power}")
    return " ".join(parts) or "dimensionless"


def _same(a, b):
    return a == b


def _dims(node, units, notes):
    """Dimensions and SI scale of an expression whose names carry the given units."""
    kind = node[0]
    if kind == "num":
        return NONE, 1.0, True  # bare number: dimensionless, may be read as "same unit" in + - and comparisons
    if kind == "var":
        if node[1] not in units:
            raise UnitError(f"no unit given for {node[1]} (use \"1\" for a dimensionless quantity)")
        scale, dims = units[node[1]]
        return dims, scale, False
    if kind == "neg":
        return _dims(node[1], units, notes)
    if kind == "bin":
        op = node[1]
        left, right = _dims(node[2], units, notes), _dims(node[3], units, notes)
        if op in "+-":
            return _additive(left, right, op, node, notes)
        if op == "*":
            return tuple(a + b for a, b in zip(left[0], right[0])), left[1] * right[1], left[2] and right[2]
        if op == "/":
            return tuple(a - b for a, b in zip(left[0], right[0])), left[1] / right[1], left[2] and right[2]
        exponent = ex.constant(node[3])
        if right[0] != NONE:
            raise UnitError(f"an exponent must be dimensionless, got {show(right[0])}")
        if exponent is None:
            if left[0] != NONE:
                raise UnitError("a quantity with units raised to a variable power has no fixed unit")
            return NONE, 1.0, left[2]
        return tuple(d * exponent for d in left[0]), left[1] ** float(exponent), left[2]
    if kind == "call":
        name = node[1]
        args = [_dims(item, units, notes) for item in node[2]]
        if name in ("exp", "log"):
            if args[0][0] != NONE:
                raise UnitError(f"{name}() of a quantity with units ({show(args[0][0])}): divide by a reference "
                                "value first, e.g. log(c/c0)")
            if args[0][1] != 1.0 and not args[0][2]:
                notes.append(f"{name}() argument is dimensionless but its units carry a scale factor "
                             f"{args[0][1]:.6g} (e.g. mm/m); the value depends on the units used")
            return NONE, 1.0, False
        if name == "sqrt":
            return tuple(d / 2 for d in args[0][0]), math.sqrt(args[0][1]), args[0][2]
        if name == "abs":
            return args[0]
        result = args[0]
        for item in args[1:]:
            result = _additive(result, item, name, node, notes)
        return result
    if kind == "cmp":
        values = [_dims(item, units, notes) for item in node[2]]
        for left, right in zip(values, values[1:]):
            _additive(left, right, "compare", node, notes)
        return NONE, 1.0, False
    if kind in ("and", "or"):
        for item in node[1]:
            _dims(item, units, notes)
        return NONE, 1.0, False
    if kind == "not":
        _dims(node[1], units, notes)
        return NONE, 1.0, False
    if kind == "implies":
        _dims(node[1], units, notes)
        _dims(node[2], units, notes)
        return NONE, 1.0, False
    raise UnitError(f"cannot check units of {kind}")


def _additive(left, right, op, node, notes):
    (ld, ls, lbare), (rd, rs, rbare) = left, right
    if lbare and not rbare:
        notes.append(f"a bare number is combined with a quantity in {show(rd)} ({op}); it is read as that unit")
        return rd, rs, False
    if rbare and not lbare:
        notes.append(f"a bare number is combined with a quantity in {show(ld)} ({op}); it is read as that unit")
        return ld, ls, False
    if ld != rd:
        raise UnitError(f"cannot {'compare' if op == 'compare' else 'combine'} {show(ld)} with {show(rd)} ({op})")
    if not math.isclose(ls, rs, rel_tol=1e-12) and not (lbare and rbare):
        notes.append(f"terms in {show(ld)} use different unit scales ({ls:.6g} vs {rs:.6g} in SI); "
                     "convert them before adding or comparing")
    return ld, ls, lbare and rbare


def _molar_masses(data, names, fail):
    """g/mol of each name: given, the sum of a composite's parts, or RDKit from SMILES. Never guessed."""
    structures, given = data.get("structures") or {}, data.get("molar_mass") or {}
    components = data.get("components") or {}
    if not isinstance(structures, dict) or not all(isinstance(v, str) and v.strip() for v in structures.values()):
        fail("structures must map names to SMILES")
    if not isinstance(given, dict) or not all(
            isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0 for v in given.values()):
        fail("molar_mass must map names to positive g/mol values")
    if not isinstance(components, dict) or not all(
            isinstance(v, list) and v and all(isinstance(p, str) for p in v) for v in components.values()):
        fail("components must map a salt or composite to the list of its parts")
    masses, notes = {}, []
    if structures:
        from rdkit import Chem, RDLogger
        from rdkit.Chem.Descriptors import MolWt
        RDLogger.DisableLog("rdApp.*")

    def mass(name, trail=()):
        if name in given:
            return float(given[name])
        if name in components:
            if name in trail:
                fail(f"components.{name} contains itself")
            return sum(mass(part, (*trail, name)) for part in components[name])
        if name in structures:
            molecule = Chem.MolFromSmiles(structures[name])
            if molecule is None:
                fail(f"structures.{name}: RDKit cannot read the SMILES {structures[name]!r}")
            if any(atom.GetAtomicNum() == 0 for atom in molecule.GetAtoms()):
                notes.append(f"{name} has open bonds (*), which add no mass: its molar mass is that of the unit "
                             "as drawn")
            return MolWt(molecule)
        fail(f"{name} has no structure, components entry or molar_mass; a molar mass is not guessed")

    for name in names:
        masses[name] = mass(name)
    return masses, notes


def amounts(data, fail):
    """Moles of each named substance in each record of a recipe, and mole ratios between them.

    A record is a set of groups; a group has its mass in grams ("g") and the shares of its members by
    mole ("mol") or by mass ("wt"). Where the basis of a percentage is unclear, readings holds each
    candidate reading of the same records, and the answer says which conclusions hold under all of them.
    """
    readings = data.get("readings")
    if readings is None:
        readings = {"as given": data.get("records")}
    if not isinstance(readings, dict) or not readings:
        fail("readings must map each reading to its records")
    names = []
    for reading, records in readings.items():
        if not isinstance(records, dict) or not records:
            fail(f"{reading}: records must map each record to its groups, e.g. "
                 "{\"A\": {\"resin\": {\"g\": 100, \"mol\": {\"X\": 35, \"Y\": 65}}}}")
        for record, groups in records.items():
            if not isinstance(groups, dict) or not groups:
                fail(f"{reading}.{record} must map groups to {{\"g\": mass, \"mol\" or \"wt\": shares}}")
            for group, spec in groups.items():
                where = f"{reading}.{record}.{group}"
                if not isinstance(spec, dict):
                    fail(f"{where} must be {{\"g\": mass, \"mol\" or \"wt\": shares}}")
                g = spec.get("g")
                if not isinstance(g, (int, float)) or isinstance(g, bool) or g <= 0:
                    fail(f"{where}.g must be the group's positive mass in grams")
                bases = [b for b in ("mol", "wt") if b in spec]
                if len(bases) != 1:
                    fail(f"{where} must give its members' shares by \"mol\" or by \"wt\" (one of them)")
                shares = spec[bases[0]]
                if not isinstance(shares, dict) or not shares or not all(
                        isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 for v in shares.values()) \
                        or not sum(shares.values()) > 0:
                    fail(f"{where}.{bases[0]} must map members to non-negative shares with a positive sum")
                names.extend(shares)
    names = list(dict.fromkeys(names))
    pairs = data.get("ratios") or ([data["ratio"]] if "ratio" in data else [])
    if not isinstance(pairs, list) or not all(
            isinstance(p, list) and len(p) == 2 and all(isinstance(n, str) for n in p) for p in pairs):
        fail("ratio must be [numerator, denominator], or ratios a list of such pairs")
    masses, notes = _molar_masses(data, names, fail)

    computed = {}
    for reading, records in readings.items():
        computed[reading] = {}
        for record, groups in records.items():
            moles, total = {}, 0.0
            for group, spec in groups.items():
                basis = "mol" if "mol" in spec else "wt"
                shares, g = spec[basis], float(spec["g"])
                whole = sum(shares.values())
                if basis == "mol":
                    per_mole = sum(share * masses[n] for n, share in shares.items()) / whole
                    for n, share in shares.items():
                        moles[n] = moles.get(n, 0.0) + g / per_mole * share / whole
                else:
                    for n, share in shares.items():
                        moles[n] = moles.get(n, 0.0) + g * share / whole / masses[n]
                total += g
            ratios = {}
            for a, b in pairs:
                missing = [n for n in (a, b) if n not in moles]
                if missing:
                    fail(f"{reading}.{record} has no {_join(missing)} for the ratio {a}:{b}")
                if moles[b] == 0:
                    fail(f"{reading}.{record}: {b} has no moles, so {a}:{b} is undefined")
                ratios[f"{a}:{b}"] = moles[a] / moles[b]
            computed[reading][record] = {
                "mmol": {n: v * 1000 for n, v in moles.items()}, "g_total": total,
                "mmol_per_g": {n: v * 1000 / total for n, v in moles.items()}, "ratios": ratios}

    lines = []
    for a, b in pairs:
        key = f"{a}:{b}"
        each = {reading: [(record, values["ratios"][key]) for record, values in records.items()]
                for reading, records in computed.items()}
        if len(each) == 1:
            (series,) = each.values()
            lines.append(f"Mole ratio {key}: " + ", ".join(f"{r} {v:.3g}" for r, v in series) + _changes(series))
            continue
        lines.append(f"Mole ratio {key} by reading: " + "; ".join(
            f"{reading}: " + ", ".join(f"{r} {v:.3g}" for r, v in series) for reading, series in each.items()))
        records = [r for r, _ in next(iter(each.values()))]
        if all([r for r, _ in series] == records for series in each.values()):
            values = [v for series in each.values() for _, v in series]
            for i in range(1, len(records)):
                steps = [series[i][1] / series[i - 1][1] - 1 for series in each.values()]
                span = f"{min(steps):+.0%} to {max(steps):+.0%}"
                if all(s > 0 for s in steps):
                    lines.append(f"From {records[i - 1]} to {records[i]} it rises under every reading ({span})")
                elif all(s < 0 for s in steps):
                    lines.append(f"From {records[i - 1]} to {records[i]} it falls under every reading ({span})")
                else:
                    lines.append(f"From {records[i - 1]} to {records[i]} its direction depends on the reading "
                                 f"({span}): settle the basis before using the direction")
            lines.append(f"Its size depends on the reading ({min(values):.3g} to {max(values):.3g})")
    if not pairs:
        lines.append("Moles per gram of all listed material: " + "; ".join(
            f"{record}: " + ", ".join(f"{n} {v:.3g} mmol/g" for n, v in values["mmol_per_g"].items())
            for records in computed.values() for record, values in records.items()))
    result = {"conclusion": ". ".join(lines) + ".", "molar_mass_g_per_mol": masses, "readings": computed}
    if notes:
        result["notes"] = list(dict.fromkeys(notes))
    return result


def _join(items):
    return ", ".join(items)


def _changes(series):
    if len(series) < 2:
        return ""
    return " (" + "; ".join(f"{series[i - 1][0]} to {series[i][0]} {series[i][1] / series[i - 1][1] - 1:+.0%}"
                            for i in range(1, len(series))) + ")"


def units(data, fail):
    if "records" in data or "readings" in data:
        return amounts(data, fail)
    if "convert" in data:
        text, target = data.get("convert"), data.get("to")
        if not isinstance(text, str) or not isinstance(target, str):
            fail("convert needs a value with its unit, e.g. \"2.5 kcal/mol\", and to, e.g. \"kJ/mol\"")
        match = re.match(r"\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)\s*(.*)$", text)
        if not match:
            fail(f"cannot read a number at the start of {text!r}")
        value, unit = float(match.group(1)), match.group(2)
        try:
            source, goal = parse_unit(unit), parse_unit(target)
        except UnitError as exc:
            fail(str(exc))
        if source[1] != goal[1]:
            fail(f"{unit} ({show(source[1])}) cannot be converted to {target} ({show(goal[1])})")
        result = value * source[0] / goal[0]
        note = []
        if unit.strip() in AFFINE and target.strip() == "K":
            result, note = value + 273.15, ["absolute temperature"]
        elif unit.strip() == "K" and target.strip() in AFFINE:
            result, note = value - 273.15, ["absolute temperature"]
        elif unit.strip() in AFFINE and target.strip() in AFFINE:
            note = []
        elif any(a in unit or a in target for a in AFFINE):
            note.append("degC inside a compound unit is treated as a temperature difference (1 degC = 1 K)")
        return {"value": result, "unit": target, "factor": source[0] / goal[0], "notes": note,
                "conclusion": f"{text.strip()} = {result:.6g} {target}" + (f" ({note[0]})" if note else "") + "."}
    expression, given = data.get("expr"), data.get("units")
    if not isinstance(given, dict) or not given:
        fail("give expr with units (a unit per name), or convert with to")
    try:
        node = ex.parse(expression, "expr")
        parsed = {name: parse_unit(unit) for name, unit in given.items()}
    except (ExprError, UnitError) as exc:
        fail(str(exc))
    notes = []
    try:
        dims, scale, _ = _dims(node, parsed, notes)
    except UnitError as exc:
        return {"consistent": False, "problem": str(exc), "conclusion": f"Units do not work out: {exc}."}
    if any(u in AFFINE for u in given.values()):
        notes.append("degC is treated as a temperature difference; use K inside products, ratios and exponentials")
    result = {"consistent": True, "dimensions": show(dims), "si_factor": scale, "notes": notes}
    text = f"Units are consistent; the result has dimensions {show(dims)}"
    if not math.isclose(scale, 1.0, rel_tol=1e-12) and not ex.is_condition(node):
        if dims == NONE:
            result["mixed_scale"] = True
            text += (f", but the units carry a factor of {scale:.6g}: computed with numbers in the given units, "
                     f"this dimensionless value is off by that factor (convert to consistent units first)")
        else:
            text += (f"; a value computed with numbers in the given units must be multiplied by {scale:.6g} "
                     "to be in SI")
    expect = data.get("expect")
    if expect is not None:
        try:
            goal = parse_unit(expect)
        except UnitError as exc:
            fail(str(exc))
        result["matches_expect"] = goal[1] == dims
        if goal[1] != dims:
            result["consistent"] = False
            text = (f"Units do not match the expected {expect}: the formula gives {show(dims)}, "
                    f"{expect} is {show(goal[1])}")
        else:
            result["multiply_by_to_get_expect"] = scale / goal[0]
            text += (f"; to express it in {expect}, multiply the value computed in the given units by "
                     f"{scale / goal[0]:.6g}")
    if notes:
        text += ". Notes: " + "; ".join(dict.fromkeys(notes))
    result["conclusion"] = text + "."
    return result
