"""Compare explicit groups from one frozen method-bound values file.

The values file is the same one research_leaderboard reads (a flat map, or one column of a values
table). When method_ref is a proxy_formula record, its declared direction, target and anchoring
rank the samples, exactly as on the leaderboard, so the two never rank the same file differently.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
import uuid

from jsonschema import Draft202012Validator

from opencode.permission import PermissionRejected
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records, values_table
from researchkit.scoring import check_direction, orient
from researchkit.report_evidence import _reference, resolve
from researchkit.values_table import MAX_BYTES, numeric_values as _numeric_values  # noqa: F401


_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}
_SELECTION = values_table.SELECTION
_IDS = {"type": "array", "minItems": 1, "uniqueItems": True, "items": dict(_TEXT)}
INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "method_ref": dict(_TEXT), "values": _SELECTION,
        "baseline_ids": _IDS, "candidate_ids": _IDS,
        "direction": {"type": "string", "enum": ["higher", "lower", "target"]},
        "target_value": {"type": "number"},
    },
    "required": ["method_ref", "values", "baseline_ids", "candidate_ids"],
    "additionalProperties": False,
}


def validate_input(args):
    Draft202012Validator(INPUT_SCHEMA).validate(args)
    _reference(args["method_ref"])
    _reference(args["values"]["record_ref"])
    if set(args["baseline_ids"]) & set(args["candidate_ids"]):
        raise ValueError("baseline_ids and candidate_ids must not overlap")
    if "direction" in args:
        check_direction(args["direction"], args.get("target_value"))
    elif "target_value" in args:
        raise ValueError("target_value goes with direction target")
    return args


def _basis(args, declared):
    """(direction, target_value) to rank by: the formula's declaration, or the call's own."""
    if declared is None:
        if "direction" not in args:
            raise ValueError("direction is required: method_ref is not a proxy_formula record that declares one")
        return args["direction"], args.get("target_value")
    given = {key: args[key] for key in ("direction", "target_value") if key in args}
    wanted = {key: declared[key] for key in ("direction", "target_value") if key in declared}
    if given and given != wanted:
        raise ValueError(f"method_ref declares {wanted}; this call gives {given}. The comparison ranks by the "
                         "formula's declaration, as research_leaderboard does: leave direction out or match it.")
    return declared["direction"], declared.get("target_value")


def _check_abort(abort):
    if abort is not None and abort.is_set():
        raise PermissionRejected("Execution stopped during candidate comparison")


def run(args, root: Path, folder: Path, *, check_read=None, abort=None):
    """Validate sources, calculate exact float differences, and freeze one result."""
    args = validate_input(args)
    root = root.resolve()
    folder = records.local_path(root, str(folder))

    def read(path):
        _check_abort(abort)
        if check_read:
            check_read(path)
        _check_abort(abort)

    _check_abort(abort)
    values_ref = args["values"]["record_ref"]
    closure = records._read_dependencies(root, [values_ref], check_read=read)
    if closure[values_ref]["kind"] not in values_table.VALUE_KINDS:
        raise ValueError(f"values.record_ref must select a kind=implementation or kind=simulation record; "
                         f"{values_ref} is kind={closure[values_ref]['kind']}. " + values_table.SAVE_ORDER)
    # Only actual depends_on edges count. Merely selecting the values record as
    # method_ref does not turn it into its own declared dependency.
    ancestors = {records.local_path(root, ref).relative_to(root).as_posix()
                 for record in closure.values() for ref in record["depends_on"]}
    if args["method_ref"] not in ancestors:
        raise values_table.dependency_error(root, args["method_ref"], values_ref, read,
                                            f"The values record {values_ref} (method_ref's values)")
    from researchkit import leaderboard  # imports this module
    declared = leaderboard.declaration(root, args["method_ref"], read)
    from researchkit import term_model
    if declared is not None and term_model.is_model(declared):
        raise ValueError("method_ref is a model with terms: research_leaderboard compares samples under every set of "
                         "coefficients its history allows; research_compare_candidates ranks one formula's values")
    direction, target_value = _basis(args, declared)
    values, sha256 = values_table.read(root, args["values"], read)
    missing = [sample_id for sample_id in [*args["baseline_ids"], *args["candidate_ids"]]
               if sample_id not in values]
    if missing:
        raise ValueError(f"Selected IDs are missing from the values file: {missing}")
    details, extra = {}, []
    if declared is not None:
        values, details, extra = leaderboard.apply_declaration(root, declared, values, args["baseline_ids"],
                                                               args["candidate_ids"], read)
    baselines = [{"id": sample_id, "value": values[sample_id]} for sample_id in args["baseline_ids"]]
    candidates = [{"id": sample_id, "value": values[sample_id]} for sample_id in args["candidate_ids"]]
    def score(value):
        return orient(value, direction, target_value)

    def best(rows):
        top = max(score(row["value"]) for row in rows)
        ids = [row["id"] for row in rows if score(row["value"]) == top]
        return {"ids": ids, "value": next(row["value"] for row in rows if row["id"] == ids[0])}

    baseline, candidate = best(baselines), best(candidates)
    # Positive delta means better for every direction, including distance to a target value.
    delta = score(candidate["value"]) - score(baseline["value"])
    if not math.isfinite(delta):
        raise ValueError("Candidate comparison delta must be finite; float subtraction overflowed")
    outcome = {
        "method_ref": args["method_ref"],
        "values": {**values_table.selection(args["values"]), "sha256": sha256},
        "direction": direction,
        **({"target_value": target_value} if direction == "target" else {}),
        "basis": "declared by method_ref, as on research_leaderboard" if declared is not None else "this call",
        **{key: details[key] for key in ("scale_check", "raw_values", "history_order") if key in details},
        "baselines": baselines, "candidates": candidates,
        "best_baseline": baseline, "best_candidate": candidate,
        "delta": delta, "comparison": "better" if delta > 0 else "worse" if delta < 0 else "tie",
    }
    raw = records.encoded(outcome)
    _check_abort(abort)
    folder.mkdir(parents=True, exist_ok=False)
    destination = folder / "comparison.json"
    with destination.open("xb") as stream:
        stream.write(raw)
    _check_abort(abort)
    source_path = destination.relative_to(root).as_posix()
    dependencies = list(dict.fromkeys([args["method_ref"], values_ref, *extra]))
    saved = records.publish(root, kind="implementation", title="Explicit same-method candidate comparison",
                            files=[source_path], depends_on=dependencies, check_read=read)
    frozen, = resolve(root, [{"record_ref": saved["record_path"], "source_path": source_path}], check_read=read)
    if frozen["sha256"] != records.digest(raw) or frozen["text"].encode("utf-8") != raw:
        raise RuntimeError("Published comparison bytes differ from the computed result")
    _check_abort(abort)
    return {"result": json.loads(frozen["text"]), "record": records.present(root, saved)}


def execute(args, ctx):
    root = ctx.directory.resolve()
    abort = _abort_event(ctx)
    _check_abort(abort)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_compare_candidates", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=abort)
    folder = records.local_path(root, f".research/method_comparisons/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    ensure_access(ctx, folder, "read")
    receipt = run(args, root, folder, check_read=lambda path: ensure_access(ctx, path, "read"), abort=abort)
    _check_abort(abort)
    return ToolResult(title="research_compare_candidates", output=json.dumps(
        receipt, ensure_ascii=False, indent=2, allow_nan=False))
