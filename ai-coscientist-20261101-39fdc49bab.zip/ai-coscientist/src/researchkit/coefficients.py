"""Coefficients of a quantitative model, set by the measurements and the signs the mechanisms give.

The author decides which physical quantities enter a model and how each is computed: its code
writes, for every sample, one number per term. The mechanism of each term's hypothesis fixes the
sign of its coefficient. The sizes are not a judgment call: every set of coefficients that
reproduces the historical measurements, within the declared measurement error, with those signs,
is equally consistent with what is known. This module describes that set with linear programs and
answers questions about all of it at once: whether it is empty, the bounds of each coefficient,
the range of each sample's prediction, and which sample is better than which under every set.

    prediction(sample) = offset + sum_k c_k * q_k(sample)        (the offset is optional)

A mechanism that says the KPI rises with a quantity says its coefficient is positive, not zero:
comparisons hold for every set in which every coefficient has its sign strictly. When the history
leaves a coefficient no room but zero, that is reported, and the comparisons fall back to the
closed set. A term whose mechanism gives no sign (0) has a coefficient of either sign: the history
alone bounds it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math

import numpy as np
from scipy.optimize import linprog


TOL = 1e-6  # in scaled units: quantities divided by their largest magnitude, the KPI by its own


class ModelError(ValueError):
    pass


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


@dataclass
class Fit:
    """The coefficient sets consistent with a history, in scaled units (see module docstring)."""

    terms: list
    signs: list
    offset: bool
    noise: float
    scale_q: np.ndarray
    scale_y: float
    rows: np.ndarray            # scaled history features, with a leading 1 when there is an offset
    targets: np.ndarray         # scaled measurements
    feasible: bool = False
    strict: bool = False
    pinned: list = field(default_factory=list)
    min_noise: float | None = None

    @property
    def width(self):
        return len(self.terms) + (1 if self.offset else 0)

    def x(self, quantities):
        """Scaled feature row of one sample: [1?, q_1/s_1, ...]."""
        row = [quantities[name] / scale for name, scale in zip(self.terms, self.scale_q)]
        return np.array(([1.0] if self.offset else []) + row)

    def _bounds(self):
        first = [(None, None)] if self.offset else []
        return first + [((0, None) if sign > 0 else (None, 0) if sign < 0 else (None, None)) for sign in self.signs]

    def _data(self):
        """Constraints of the history: |rows @ z - targets| <= noise (equalities without noise)."""
        if self.noise > 0:
            band = self.noise / self.scale_y
            return (np.vstack([self.rows, -self.rows]),
                    np.concatenate([self.targets + band, -self.targets + band]), None, None)
        return None, None, self.rows, self.targets

    def _sign_rows(self):
        """-sign_k * c_k <= 0 written as rows over z (used with an extra variable t)."""
        rows = []
        for k, sign in enumerate(self.signs):
            if not sign:
                continue
            row = np.zeros(self.width)
            row[k + (1 if self.offset else 0)] = -sign
            rows.append(row)
        return rows

    def minimum(self, g, h=0.0):
        """min over the closed set of g.z + h; -inf when unbounded, None when the set is empty."""
        A_ub, b_ub, A_eq, b_eq = self._data()
        result = linprog(np.asarray(g, float), A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                         bounds=self._bounds(), method="highs")
        if result.status == 0:
            return float(result.fun) + h
        if result.status == 3:
            return -math.inf
        if result.status == 2:
            return None
        raise RuntimeError(f"linear program failed: {result.message}")

    def maximum(self, g, h=0.0):
        low = self.minimum(-np.asarray(g, float), -h)
        return None if low is None else -low

    def interior(self, g=None, h=0.0):
        """Largest t <= 1 with every coefficient at least t in its sign's direction (and g.z + h = 0)."""
        A_ub, b_ub, A_eq, b_eq = self._data()
        width = self.width
        signs = self._sign_rows()
        rows_ub = [np.append(row, 1.0) for row in signs]
        values_ub = [0.0] * len(signs)
        if A_ub is not None:
            rows_ub += [np.append(row, 0.0) for row in A_ub]
            values_ub += list(b_ub)
        rows_eq, values_eq = [], []
        if A_eq is not None:
            rows_eq += [np.append(row, 0.0) for row in A_eq]
            values_eq += list(b_eq)
        if g is not None:
            rows_eq.append(np.append(np.asarray(g, float), 0.0))
            values_eq.append(-h)
        objective = np.zeros(width + 1)
        objective[-1] = -1.0
        result = linprog(objective, A_ub=np.array(rows_ub) if rows_ub else None,
                         b_ub=np.array(values_ub) if rows_ub else None,
                         A_eq=np.array(rows_eq) if rows_eq else None, b_eq=np.array(values_eq) if rows_eq else None,
                         bounds=[(None, None)] * width + [(None, 1.0)], method="highs")
        if result.status == 0:
            return -float(result.fun)
        if result.status == 2:
            return None
        raise RuntimeError(f"linear program failed: {result.message}")

    def sign_on(self, g, h=0.0):
        """Sign of g.z + h over every coefficient set: 1, -1, 0 (identically zero) or None (it varies)."""
        low, high = self.minimum(g, h), self.maximum(g, h)
        if low is None:
            return None
        if low > TOL:
            return 1
        if high < -TOL:
            return -1
        if low >= -TOL and high <= TOL:
            return 0
        if low < -TOL and high > TOL:
            return None
        # One side touches zero: reached with every coefficient strictly signed, or only where one is zero.
        if not self.strict:
            return None
        touches = self.interior(g, h)
        if touches is not None and touches > TOL:
            return None
        return 1 if high > TOL else -1


def fit(terms, signs, history, measured, *, offset=True, noise=0.0, samples=None):
    """Fit over the coefficient sets consistent with the history.

    terms: [name]; signs: {name: 1, -1 or 0 (no sign)}; history: {sample: {name: quantity}};
    measured: {sample: value}; samples: further {sample: {name: quantity}} used only for scaling.
    """
    if not terms or len(set(terms)) != len(terms):
        raise ModelError("terms must name each quantity once")
    if any(signs.get(name) not in (1, -1, 0) for name in terms):
        raise ModelError("every term needs a sign: 1 (the KPI rises with it), -1 (falls) or 0 (none given)")
    if not _finite(noise) or noise < 0:
        raise ModelError("noise must be a non-negative number")
    if not history:
        raise ModelError("the history has no samples")
    everything = {**(samples or {}), **history}
    for sample, quantities in everything.items():
        for name in terms:
            if not _finite((quantities or {}).get(name)):
                raise ModelError(f"{sample} has no number for {name}")
    for sample in history:
        if not _finite(measured.get(sample)):
            raise ModelError(f"{sample} has no measured value")
    scale_q = np.array([max(abs(everything[s][name]) for s in everything) or 1.0 for name in terms])
    scale_y = max(abs(measured[s]) for s in history) or 1.0
    model = Fit(list(terms), [signs[name] for name in terms], bool(offset), float(noise), scale_q, scale_y,
                rows=np.zeros((0, 0)), targets=np.zeros(0))
    model.rows = np.array([model.x(history[s]) for s in history])
    model.targets = np.array([measured[s] / scale_y for s in history])
    model.feasible = model.minimum(np.zeros(model.width)) is not None
    if not model.feasible:
        model.min_noise = _min_noise(model) * scale_y
        return model
    width_inner = model.interior()
    model.strict = width_inner is not None and width_inner > TOL
    if not model.strict:
        model.pinned = [name for k, name in enumerate(terms)
                        if model.signs[k] and model.maximum(_unit(model, k) * model.signs[k]) <= TOL]
    return model


def _unit(model, k):
    g = np.zeros(model.width)
    g[k + (1 if model.offset else 0)] = 1.0
    return g


def _min_noise(model):
    """Smallest error with which the signs fit the history (scaled units)."""
    width = model.width
    rows = []
    values = []
    for row, target in zip(model.rows, model.targets):
        rows.append(np.append(row, -1.0))
        values.append(target)
        rows.append(np.append(-row, -1.0))
        values.append(-target)
    objective = np.zeros(width + 1)
    objective[-1] = 1.0
    result = linprog(objective, A_ub=np.array(rows), b_ub=np.array(values),
                     bounds=model._bounds() + [(0, None)], method="highs")
    if result.status != 0:
        raise RuntimeError(f"linear program failed: {result.message}")
    return float(result.fun)


def coefficients(model):
    """{name: {"low", "high", "determined"}} in the KPI's units per unit of each quantity, plus "offset".

    low and high are -inf or inf where the history and the signs leave a coefficient unbounded.
    """
    found = {}
    names = (["offset"] if model.offset else []) + model.terms
    for index, name in enumerate(names):
        g = np.zeros(model.width)
        g[index] = 1.0
        low, high = model.minimum(g), model.maximum(g)
        scale = model.scale_y / (1.0 if name == "offset" else model.scale_q[index - (1 if model.offset else 0)])
        found[name] = {"low": low * scale, "high": high * scale,
                       "determined": math.isfinite(low) and math.isfinite(high) and high - low <= TOL}
    return found


def prediction(model, quantities):
    """(low, high) of one sample's prediction over every coefficient set."""
    g = model.x(quantities)
    return model.minimum(g) * model.scale_y, model.maximum(g) * model.scale_y


def relation(model, a, b, direction, target=None):
    """How sample a compares with b on a sheet: better, worse, tie or undecided (under every coefficient set)."""
    xa, xb = model.x(a), model.x(b)
    difference = xa - xb
    if np.all(np.abs(difference) <= TOL):
        return "tie"
    if direction in ("higher", "lower"):
        sign = model.sign_on(difference)
        if sign == 0:
            return "tie"
        if sign is None:
            return "undecided"
        return "better" if (sign > 0) == (direction == "higher") else "worse"
    # Distance to the target: |fa - t| < |fb - t|  <=>  (fa - fb)(fa + fb - 2t) < 0.
    total = xa + xb
    v_sign = model.sign_on(total, -2 * target / model.scale_y)
    if v_sign == 0:
        return "tie"
    u_sign = model.sign_on(difference)
    if u_sign == 0:
        return "tie"
    if u_sign is None or v_sign is None:
        return "undecided"
    return "better" if u_sign * v_sign < 0 else "worse"


def band(low, high, target, tolerance):
    """Where a prediction range lies against target +/- tolerance."""
    edge = 1e-9 * max(1.0, abs(target), abs(tolerance))
    if low >= target - tolerance - edge and high <= target + tolerance + edge:
        return "surely_in"
    if low > target + tolerance + edge:
        return "surely_above"
    if high < target - tolerance - edge:
        return "surely_below"
    return "possibly_in"


def setting_measurements(model, history, candidates, bounds):
    """{term: [candidates]} whose measurement would set an undetermined coefficient.

    A candidate that differs from a historical sample only in one undetermined term (and in terms
    whose coefficients are already set) isolates that coefficient: its measured difference from
    that sample, divided by the change in the quantity, is the coefficient.
    """
    undetermined = [k for k, name in enumerate(model.terms) if not bounds[name]["determined"]]
    found = {}
    for candidate, quantities in candidates.items():
        xc = model.x(quantities)
        for sample, past in history.items():
            difference = xc - model.x(past)
            if model.offset:
                difference = difference[1:]
            moved = [k for k in range(len(model.terms)) if abs(difference[k]) > TOL]
            open_ = [k for k in moved if k in undetermined]
            if len(open_) == 1:
                name = model.terms[open_[0]]
                if candidate not in found.setdefault(name, []):
                    found[name].append(candidate)
                break
    return found
