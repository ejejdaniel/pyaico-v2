"""research_deliver: the Final-LCA and the user_report of one report, written by the host in one call.

LIT runs spent 34-45 minutes between saving a report and delivering it (v16, v21, v23): render,
review, revise, render again, review the revision again, then write review.json, a Final-LCA and
a user_report by hand. Here the author answers each review check that is not supported, and each
host check of the report (report_checks), in one call:

- revised: the report now says something else; quote the delivered text that shows it;
- limitation: the report states the limit; quote where;
- disputed: the author disagrees; say why.

A quotation must be in the delivered report Markdown. A review of an earlier version of the report
(a report record the delivered one depends on, such as the reviewed draft) covers the delivery
once every check it did not support is answered; a revision then needs no second review. The host
writes final_lca.json and a readable final_lca.md, saves the kind=final_lca record (depending on
the report and the reviews) and the kind=user_report record (depending on the report and the
Final-LCA). It does not judge whether an answer is scientifically adequate.
"""

from __future__ import annotations

import json
from pathlib import Path
import re
import uuid

from opencode.provider import _check_abort
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records, report_checks
from researchkit.report_evidence import resolve

DECISIONS = ("released", "bounded-reject", "hard-block")
ACTIONS = ("revised", "limitation", "disputed")
_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}
CHECK_NUMBER = ("1-based: check 1 is the first entry of the review's checks list; research_review's result lists "
                "the checks to answer with these numbers")
# LIT (2026-11-01) counted review.json's checks from 0 in a script, so every answer named the check before the
# one it was written for; answers that landed on other unsupported checks were accepted and delivered.
NUMBERING = ("Checks are numbered from 1 in the order of the review's checks list, as research_review's result "
             "lists them; counting review.json's checks from 0 makes every number one lower than the check meant")
INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "report_ref": dict(_TEXT),
        "markdown": dict(_TEXT),
        "review_refs": {"type": "array", "minItems": 1, "uniqueItems": True, "items": dict(_TEXT)},
        "decision": {"type": "string", "enum": list(DECISIONS)},
        "scope": dict(_TEXT),
        "answers": {"type": "array", "items": {
            "type": "object",
            # No minimum here: deliver() refuses check 0 together with every other problem, and says why.
            "properties": {"review_ref": dict(_TEXT), "check": {"type": "integer", "description": CHECK_NUMBER},
                           "host": {"type": "integer", "minimum": 1},
                           "action": {"type": "string", "enum": list(ACTIONS)},
                           "note": dict(_TEXT), "quote": dict(_TEXT)},
            "required": ["action", "note"], "additionalProperties": False}},
    },
    "required": ["report_ref", "review_refs", "decision", "scope"],
    "additionalProperties": False,
}
FILE = "final_lca.json"


def _flat(text):
    return " ".join(text.split())


def _record(root, ref, read):
    """A saved record with its exact relative path."""
    exact = records.local_path(root, ref).relative_to(Path(root).resolve()).as_posix()
    return {**records.read_record(root, exact, check_read=read), "record_path": exact}


def _snapshot(root, record, source_path, check_read):
    frozen, = resolve(root, [{"record_ref": record["record_path"], "source_path": source_path}], check_read=check_read)
    return frozen["text"]


def report_markdown(root, report, name=None, check_read=None):
    """(source_path, text) of the delivered report's Markdown."""
    sources = [item["source_path"] for item in report["files"] if item["source_path"].lower().endswith(".md")]
    if name is not None:
        if name not in sources:
            raise ValueError(f"markdown {name!r} is not a file of report {report['record_path']}; its Markdown "
                             f"files: {', '.join(sources) or 'none'}")
        return name, _snapshot(root, report, name, check_read)
    # v38's report record also held its literature notes; one file named report*.md is the report text.
    named = [path for path in sources if Path(path).name.lower().startswith("report")]
    if len(sources) > 1 and len(named) == 1:
        sources = named
    if len(sources) != 1:
        raise ValueError(f"report {report['record_path']} holds {len(sources)} Markdown files "
                         f"({', '.join(sources) or 'none'}); name the report text in markdown")
    return sources[0], _snapshot(root, report, sources[0], check_read)


def review_checks(root, review, check_read=None):
    """(reviewed_refs, checks) of a saved kind=review record."""
    files = [item for item in review["files"] if Path(item["source_path"]).name == "review.json"]
    if review["kind"] != "review" or len(files) != 1:
        raise ValueError(f"{review['record_path']} is not a kind=review record with one review.json")
    value = json.loads(_snapshot(root, review, files[0]["source_path"], check_read))
    return list(value.get("reviewed_refs") or []), list(value.get("checks") or [])


def _kind(root, ref, check_read=None):
    try:
        return records.read_record(root, ref, check_read=check_read)["kind"]
    except (OSError, ValueError, KeyError):
        return "unreadable"


def report_versions(root, report_ref, check_read=None):
    """The delivered report and the earlier report records it builds on (a reviewed draft, say)."""
    closure = records._read_dependencies(root, [report_ref], check_read=check_read)
    return {ref for ref, record in closure.items() if record["kind"] == "report"}


def unanswered(checks, answered):
    """1-based numbers of checks that are not supported and have no answer."""
    return [number for number, check in enumerate(checks, 1)
            if check.get("decision") != "supported" and number not in answered]


def answers_cover(lca_value, review_ref, checks):
    """Whether a final_lca.json answers every check of this review that is not supported."""
    answered = {item.get("check") for item in (lca_value or {}).get("items", [])
                if item.get("review_ref") == review_ref and item.get("action") in ACTIONS}
    return not unanswered(checks, answered)


def _preview(text, limit=160):
    text = _flat(str(text))
    return text if len(text) <= limit else text[:limit] + "…"


def _subject(check):
    subject = check.get("subject")
    if isinstance(subject, dict):
        return subject.get("quote") or ""
    return ""


def evolution_gap(root, check_read=None):
    """Why a delivery that ranks candidates is missing its evolution record, or None.

    v30 ranked three rounds of candidates on five leaderboards and delivered without a
    sample_evolution record, so nothing the host checks about rounds (what each used, whether
    scores improved, the stop reason) applied to the evolution its report described.
    """
    saved = records.inventory(root, check_read=check_read)
    if not any(item["kind"] == "leaderboard" for item in saved):
        return None
    if any("evolution" in item["kind"] and any(Path(f["source_path"]).name == "evolution.json" for f in item["files"])
           for item in saved):
        return None
    return ("research_leaderboard ranked candidates here, but no sample_evolution record declares the rounds that "
            "produced them. Save one with research_record (kind sample_evolution, template stored as "
            "evolution.json; see the sample skill): each round actually run with its candidate_ids, leaderboard_ref, "
            "strategy, levers and reason, plus stop_reason and claims_surpass. Candidates computed as one batch are "
            "one round. The delivered report describes the same rounds")


def deliver(args, root, folder, *, check_read=None, abort=None, annotate=None):
    """annotate(markdown, folder, avoid) makes the plain-spoken reading copy (report_notes.write) once the
    delivery holds, kept off the passages in avoid; what it returns goes into the receipt, and the copy's HTML
    and PDF into the user_report."""
    root = Path(root).resolve()
    read = check_read
    gap = evolution_gap(root, read)
    if gap:
        raise ValueError(f"Not delivered; nothing was saved. {gap}.")
    report = _record(root, args["report_ref"], read)
    if report["kind"] != "report":
        raise ValueError(f"report_ref {args['report_ref']} is a {report['kind']} record; deliver a kind=report record")
    report_ref = report["record_path"]
    markdown_path, markdown = report_markdown(root, report, args.get("markdown"), read)
    versions = report_versions(root, report_ref, read)
    flat = _flat(markdown)

    reviews, problems = [], []
    for review_ref in args["review_refs"]:
        review = _record(root, review_ref, read)
        reviewed, checks = review_checks(root, review, read)
        covered = [ref for ref in reviewed if ref in versions]
        kinds = {ref: _kind(root, ref, read) for ref in reviewed} if not covered else {}
        if not covered and "report" not in kinds.values():
            # A run (2026-11-01) reviewed its records before writing the report, was told to make the report
            # depend on "the reviewed version", and saved it depending on those records, twice.
            problems.append(f"review {review_ref} reviewed no report: it reviewed "
                            + ", ".join(f"{kind} {ref.split('/')[2][:8]}" for ref, kind in kinds.items())
                            + f". A review covers a delivery when it reviewed report {report_ref} or an earlier "
                            "version of it; run research_review on this report (its Markdown can be reviewed "
                            "before rendering) and deliver with that review.")
        elif not covered:
            problems.append(f"review {review_ref} reviewed {', '.join(reviewed)}, which is neither report {report_ref} "
                            "nor an earlier report record it depends on. Review this report (its Markdown can be "
                            "reviewed before rendering), or save the delivered report so that it depends on the "
                            "reviewed version.")
        reviews.append({"ref": review["record_path"], "reviewed": covered, "checks": checks})
    host = report_checks.check(root, markdown, read)

    answers, items, seen, misnumbered = args.get("answers", []), [], set(), False
    by_ref = {review["ref"]: review for review in reviews}
    for answer in answers:
        if ("host" in answer) == ("review_ref" in answer or "check" in answer):
            problems.append(f"each answer is about one review check (review_ref and check) or one host check (host): "
                            f"{json.dumps(answer, ensure_ascii=False)[:200]}")
            continue
        if "host" in answer:
            key = ("host", answer["host"])
            if answer["host"] > len(host):
                problems.append(f"host check {answer['host']} does not exist; there are {len(host)}")
                continue
            about = host[answer["host"] - 1]
            item = {"host": answer["host"], "finding": about["text"]}
        else:
            if "review_ref" not in answer or "check" not in answer:
                problems.append("a review answer needs both review_ref and check")
                continue
            # Tool arguments arrive with record references made exact (records.resolve_references).
            review = by_ref.get(answer["review_ref"])
            if review is None:
                problems.append(f"answer names review {answer['review_ref']}, which is not in review_refs")
                continue
            if not 1 <= answer["check"] <= len(review["checks"]):
                problems.append(f"review {review['ref']} has checks 1 to {len(review['checks'])}, not {answer['check']}")
                misnumbered = misnumbered or answer["check"] < 1
                continue
            key = (review["ref"], answer["check"])
            check = review["checks"][answer["check"] - 1]
            if check.get("decision") == "supported":
                # An answer to a supported check is meant for another one, usually the next.
                problems.append(f"review {review['ref']} check {answer['check']} is supported and needs no answer; "
                                f"it is about: {_preview(_subject(check), 160)}")
                misnumbered = True
                continue
            item = {"review_ref": review["ref"], "check": answer["check"], "decision": check.get("decision"),
                    "subject": _preview(_subject(check), 300), "reason": _preview(check.get("reason", ""), 400)}
        if key in seen:
            problems.append(f"{key[0]} {key[1]} is answered twice")
            continue
        seen.add(key)
        if answer["action"] in ("revised", "limitation"):
            # What the check is about, so the passage can be found without opening the review (LIT, 2026-10-31,
            # had to look it up and send the whole delivery again).
            about = _preview(item.get("subject") or item.get("finding") or "", 160)
            if "quote" not in answer:
                problems.append(f"{answer['action']} answer to {key[0]} {key[1]} needs quote: the delivered report's "
                                f"text that shows it (the check is about: {about})")
                continue
            if _flat(answer["quote"]) not in flat:
                problems.append(f"the quote answering {key[0]} {key[1]} is not in {markdown_path} of the delivered "
                                f"report: {_preview(answer['quote'], 120)} (copy one passage as the Markdown has it, "
                                f"emphasis and list markers included; the check is about: {about})")
                continue
        items.append({**item, "action": answer["action"], "note": answer["note"],
                      **({"quote": answer["quote"]} if "quote" in answer else {})})
    for review in reviews:
        missing = unanswered(review["checks"], {number for ref, number in seen if ref == review["ref"]})
        for number in missing:
            check = review["checks"][number - 1]
            problems.append(f"review {review['ref']} check {number} ({check.get('decision')}) is unanswered: "
                            f"{_preview(_subject(check), 120)} — {_preview(check.get('reason', ''), 200)}")
    for finding in host:
        number = int(finding["id"].split("#")[1])
        if ("host", number) not in seen:
            problems.append(f"host check {number} is unanswered: {finding['text']}")
    if problems:
        raise ValueError("Not delivered; nothing was saved. Answer each check that is not supported (revised or "
                         "limitation with a quote of the delivered report, or disputed with the reason):\n- "
                         + "\n- ".join(problems) + (f"\n{NUMBERING}." if misnumbered else ""))

    supported = sum(1 for review in reviews for check in review["checks"] if check.get("decision") == "supported")
    value = {"report_ref": report_ref, "markdown": markdown_path, "decision": args["decision"], "scope": args["scope"],
             "reviews": [{"review_ref": review["ref"], "reviewed_report": review["reviewed"][0],
                          "checks": len(review["checks"])} for review in reviews],
             "report_revised_after_review": any(report_ref not in review["reviewed"] for review in reviews),
             "supported_checks": supported, "items": items, "host_checks": host}
    _check_abort(abort)
    folder.mkdir(parents=True, exist_ok=False)
    (folder / FILE).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (folder / "final_lca.md").write_text(_lca_text(value), encoding="utf-8")
    relative = lambda name: (folder / name).relative_to(root).as_posix()
    lca = records.publish(root, kind="final_lca", title=f"Final-LCA: {args['decision']} for report {report_ref.split('/')[2][:8]}",
                          files=[relative(FILE), relative("final_lca.md")],
                          depends_on=[report_ref, *[review["ref"] for review in reviews]], check_read=read)
    # Passages the review found contradicted or unsupported that the delivered report still has: no plain note.
    avoid = [check["subject"]["quote"] for review in reviews for check in review["checks"]
             if check.get("decision") in ("contradicted", "unsupported") and isinstance(check.get("subject"), dict)
             and isinstance(check["subject"].get("quote"), str) and _flat(check["subject"]["quote"]) in flat]
    notes = annotate(markdown, folder, avoid) if annotate is not None else None
    _check_abort(abort)
    copy = []
    for key in ("html_path", "pdf_path"):
        if notes and key in notes:
            notes[key] = Path(notes[key]).resolve().relative_to(root).as_posix()
            copy.append(notes[key])
    (folder / "delivery.md").write_text(_delivery_text(value, report, lca["record_path"], notes), encoding="utf-8")
    user = records.publish(root, kind="user_report", title=f"Delivered report {report_ref.split('/')[2][:8]} "
                           f"({args['decision']})", files=[relative("delivery.md"), *copy],
                           depends_on=[report_ref, lca["record_path"]], check_read=read)
    issues = records.delivery_issues(root, user["record_path"], check_read=read)
    receipt = {"final_lca": {"record_path": lca["record_path"], "kind": "final_lca"},
               "user_report": {"record_path": user["record_path"], "kind": "user_report"},
               "decision": args["decision"], "answered": len(items), "supported_checks": supported,
               "report_revised_after_review": value["report_revised_after_review"], "delivery_issues": issues}
    if notes is not None:
        receipt["plain_notes"] = notes
    if not issues:
        # v38 spent eight minutes after a clean delivery re-reading records and editing its reasoning graph.
        receipt["next"] = ("The delivery is complete. Close any open todo items with todowrite, then reply with a "
                           "short summary of the result and stop; the delivered records need no further edits.")
    return receipt


def _lca_text(value):
    lines = [f"# Final-LCA：{value['decision']}", "", f"交付報告：`{value['report_ref']}`（{value['markdown']}）", "",
             "## 放行範圍", "", value["scope"], "", "## 依據的審查", ""]
    for review in value["reviews"]:
        same = review["reviewed_report"] == value["report_ref"]
        lines.append(f"- `{review['review_ref']}`：{review['checks']} 項檢查，審查的是"
                     + ("這一版報告" if same else f"較早的版本 `{review['reviewed_report']}`（之後的修改逐條回應如下）"))
    lines += ["", f"審查判為 supported 的檢查：{value['supported_checks']} 項。", "", "## 未通過檢查與宿主檢查的回應", ""]
    names = {"revised": "已修改", "limitation": "列為限制", "disputed": "不同意"}
    for item in value["items"]:
        head = (f"審查 `{item['review_ref'].split('/')[2][:8]}` 第 {item['check']} 項（{item['decision']}）"
                if "review_ref" in item else f"宿主檢查 {item['host']}")
        lines.append(f"### {head}：{names[item['action']]}")
        if "review_ref" in item:
            lines += [f"- 主張：{item['subject']}", f"- 審查理由：{item['reason']}"]
        else:
            lines.append(f"- 發現：{item['finding']}")
        lines.append(f"- 回應：{item['note']}")
        if "quote" in item:
            lines.append(f"- 交付報告原文：「{_preview(item['quote'], 400)}」")
        lines.append("")
    if not value["items"]:
        lines.append("（審查各項皆為 supported，宿主檢查沒有發現。）")
    return "\n".join(lines).rstrip() + "\n"


def _delivery_text(value, report, lca_ref, notes=None):
    files = [item["source_path"] for item in report["files"]
             if item["source_path"].lower().endswith((".md", ".html", ".pdf"))]
    lines = [f"# 交付：{value['decision']}", "",
             f"- 報告紀錄：`{value['report_ref']}`",
             "- 報告檔案：" + "、".join(f"`{name}`" for name in files),
             f"- Final-LCA：`{lca_ref}`"]
    if notes and "html_path" in notes:
        lines.append(f"- 白話註記版：`{notes['html_path']}`、`{notes['pdf_path']}`（{notes['placed']} 則註記；"
                     "閱讀輔助，不屬於審查過的報告）")
    elif notes is not None:
        lines.append("- 白話註記版：未產生（" + (notes.get("error") or "沒有能放進報告的註記") + "）")
    return "\n".join([*lines, "", "## 放行範圍", "", value["scope"], ""])


def execute(args, ctx):
    from jsonschema import Draft202012Validator

    Draft202012Validator(INPUT_SCHEMA).validate(args)
    root = ctx.directory.resolve()
    abort = _abort_event(ctx)
    _check_abort(abort)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_deliver", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=abort)
    folder = records.local_path(root, f".research/deliveries/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    def annotate(markdown, destination, avoid):
        from researchkit import report_notes
        try:
            return report_notes.write(ctx, markdown, destination, avoid)
        except Exception as exc:  # a reading aid: the delivery stands without it
            return {"error": f"{type(exc).__name__}: {exc}"}

    receipt = deliver(args, root, folder, check_read=lambda path: ensure_access(ctx, path, "read"), abort=abort,
                      annotate=annotate)
    return ToolResult(title="research_deliver", output=json.dumps(receipt, ensure_ascii=False, indent=2))


DESCRIPTION = (
    "Deliver one saved report: the host writes its Final-LCA and the user_report in one call. Give report_ref "
    "(the kind=report record with the rendered HTML/PDF), markdown when that record holds more than one .md, the "
    "review records (research_review saves each one), decision (released, bounded-reject or hard-block) and "
    "scope (what the delivery may be used for and its limits). answers: one per review check that is not "
    "supported (a supported check takes none) and per host check of the report — {review_ref, check (numbered from "
    "1, as research_review's result lists them), action, note, quote} or "
    "{host, action, note, quote}; action revised (quote the delivered text that changed) or limitation (quote "
    "where the report states it) needs quote, which must be in the delivered Markdown; disputed needs the reason "
    "in note. A review of an earlier report version the delivered report depends on (the reviewed draft) covers "
    "it once its checks are answered, so a revision needs no second review. Host checks compare the report's "
    "candidate verdicts and table numbers with the newest leaderboards and saved noise checks; a refused call "
    "lists every unanswered check and saves nothing. When leaderboards ranked candidates, a sample_evolution record "
    "declaring the rounds must exist first."
)
