"""Optional research reasoning graph: questions, conjectures, observations, decisions.

The agent writes nodes and edges; the host validates them, keeps every revision,
and computes which nodes need another look after something upstream changed.
Nothing here schedules work, blocks a tool or judges scientific support.
"""

from __future__ import annotations

from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re

from researchkit import records


SCHEMA_VERSION = 1
FOLDER = ".research/graph"
MAX_REVISION_BYTES = 1024 * 1024
STATUSES = {
    "question": {"open", "answered", "dropped"},
    "conjecture": {"proposed", "supported", "weakened", "refuted"},
    "observation": {"valid", "overturned"},
    "decision": {"active", "withdrawn"},
}
EDGE_TYPES = {"based_on", "supports", "contradicts"}
_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,63}")
NODE_FIELDS = {"id", "type", "text", "status", "reason"}
NODE_OPTIONAL = {"records", "edges", "supersedes", "requirement_ids"}


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _text(value, label, limit=4000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{label} must be nonblank text of at most {limit} characters")


def _identifier(value, label):
    if not isinstance(value, str) or not _ID.fullmatch(value):
        raise ValueError(f"{label} must match {_ID.pattern}")


def requirement_fingerprint(requirement: dict) -> str:
    return records.digest(_canonical(requirement))


def _validate_input_node(node):
    if not isinstance(node, dict):
        raise ValueError("Each node must be an object")
    missing, unknown = NODE_FIELDS - set(node), set(node) - NODE_FIELDS - NODE_OPTIONAL
    if missing or unknown:
        raise ValueError(f"Node fields missing {sorted(missing)} or unknown {sorted(unknown)}")
    _identifier(node["id"], "node id")
    if node["type"] not in STATUSES:
        raise ValueError(f"Node {node['id']}: type must be one of {sorted(STATUSES)}")
    if node["status"] not in STATUSES[node["type"]]:
        raise ValueError(f"Node {node['id']}: {node['type']} status must be one of {sorted(STATUSES[node['type']])}")
    _text(node["text"], f"Node {node['id']} text")
    _text(node["reason"], f"Node {node['id']} reason")
    for key in ("records", "requirement_ids"):
        value = node.get(key, [])
        if not isinstance(value, list) or len(value) != len(set(value)) or len(value) > 32:
            raise ValueError(f"Node {node['id']}: {key} must be a list of at most 32 unique items")
    for item in node.get("requirement_ids", []):
        _identifier(item, f"Node {node['id']} requirement id")
    edges = node.get("edges", [])
    if not isinstance(edges, list) or len(edges) > 64:
        raise ValueError(f"Node {node['id']}: edges must be a list of at most 64 items")
    seen = set()
    for edge in edges:
        if not isinstance(edge, dict) or set(edge) != {"type", "to"} or edge["type"] not in EDGE_TYPES:
            raise ValueError(f"Node {node['id']}: each edge is {{type: based_on|supports|contradicts, to: node id}}")
        _identifier(edge["to"], f"Node {node['id']} edge target")
        if edge["to"] == node["id"] or (edge["type"], edge["to"]) in seen:
            raise ValueError(f"Node {node['id']}: self or duplicate edge to {edge['to']}")
        seen.add((edge["type"], edge["to"]))
    if node.get("supersedes") is not None:
        _identifier(node["supersedes"], f"Node {node['id']} supersedes")


def _check_state(root, state, *, check_read=None):
    nodes = state["nodes"]
    for node in nodes.values():
        for edge in node["edges"]:
            target = nodes.get(edge["to"])
            if target is None:
                raise ValueError(f"Node {node['id']}: edge target {edge['to']} does not exist")
            if edge["type"] in {"supports", "contradicts"} and (
                    node["type"] != "observation" or target["type"] != "conjecture"):
                raise ValueError(f"Node {node['id']}: {edge['type']} goes from an observation to a conjecture")
        old = node.get("supersedes")
        if old is not None:
            if old not in nodes or nodes[old]["type"] != node["type"] or old == node["id"]:
                raise ValueError(f"Node {node['id']}: supersedes must name another existing {node['type']} node")
            others = [n["id"] for n in nodes.values() if n.get("supersedes") == old and n["id"] != node["id"]]
            if others:
                raise ValueError(f"Node {old} is already superseded by {others[0]}")
        if node["type"] == "observation" and not node["records"]:
            raise ValueError(f"Observation {node['id']} must cite at least one saved record")
        for ref in node["records"]:
            try:
                records.read_record(root, ref, check_read=check_read)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                raise ValueError(f"Node {node['id']}: record {ref!r} cannot be read as a saved record: {exc}") from exc
        if node["type"] == "conjecture" and node["status"] != "proposed":
            evidence = [o for o in nodes.values() if o["type"] == "observation" and o["status"] == "valid"
                        and any(e["to"] == node["id"] and e["type"] in {"supports", "contradicts"}
                                for e in o["edges"])]
            if not evidence:
                raise ValueError(f"Conjecture {node['id']} is {node['status']}: add a valid observation with a "
                                 "supports or contradicts edge to it, or keep status proposed")
    # Propagation follows based_on; a cycle would make "upstream" meaningless.
    visiting, done = set(), set()

    def visit(identifier):
        if identifier in done:
            return
        if identifier in visiting:
            raise ValueError(f"based_on edges form a cycle through {identifier}")
        visiting.add(identifier)
        for edge in nodes[identifier]["edges"]:
            if edge["type"] == "based_on":
                visit(edge["to"])
        visiting.discard(identifier)
        done.add(identifier)

    for identifier in nodes:
        visit(identifier)


def _upstream(node, nodes):
    """Direct upstream ids whose change can invalidate this node."""
    ups = [e["to"] for e in node["edges"] if e["type"] == "based_on"]
    if node["type"] == "conjecture":
        ups += [o["id"] for o in nodes.values()
                if any(e["to"] == node["id"] and e["type"] in {"supports", "contradicts"} for e in o["edges"])]
    return list(dict.fromkeys(ups))


def apply(state, args, *, requirements=None):
    """Return the next state. requirements maps id -> saved requirement (optional planning)."""
    state = copy.deepcopy(state)
    nodes = state["nodes"]
    changed = set()
    submitted = args.get("nodes", [])
    if not isinstance(submitted, list) or len({n.get("id") for n in submitted if isinstance(n, dict)}) != len(submitted):
        raise ValueError("nodes must be a list with unique ids")
    for node in submitted:
        _validate_input_node(node)
        clean = {"id": node["id"], "type": node["type"], "text": node["text"], "status": node["status"],
                 "reason": node["reason"], "records": list(node.get("records", [])),
                 "edges": [dict(e) for e in node.get("edges", [])], "supersedes": node.get("supersedes"),
                 "requirement_ids": list(node.get("requirement_ids", []))}
        previous = nodes.get(node["id"])
        if previous is not None and previous["type"] != clean["type"]:
            raise ValueError(f"Node {node['id']} cannot change type; add a new node that supersedes it")
        content = {k: v for k, v in clean.items() if k != "reason"}
        if previous is None or {k: previous[k] for k in content} != content:
            clean["version"] = (previous["version"] + 1) if previous else 1
            changed.add(node["id"])
        else:
            clean["version"] = previous["version"]
        clean["seen"] = previous["seen"] if previous else {}
        clean["seen_requirements"] = previous["seen_requirements"] if previous else {}
        for kept in ("superseded_by", "last_review"):
            if previous is not None and previous.get(kept) is not None:
                clean[kept] = previous[kept]
        nodes[node["id"]] = clean
    # Being superseded is a change of the old node, so its dependents are flagged.
    for identifier in list(changed):
        old = nodes[identifier]["supersedes"]
        if old is not None and nodes[old].get("superseded_by") != identifier:
            nodes[old]["superseded_by"] = identifier
            nodes[old]["version"] += 1
            changed.add(old)
    reviewed = set()
    for item in args.get("reviews", []):
        if not isinstance(item, dict) or set(item) != {"node_id", "reason"}:
            raise ValueError("Each review is {node_id, reason}")
        if item["node_id"] not in nodes:
            raise ValueError(f"Reviewed node {item['node_id']} does not exist")
        _text(item["reason"], f"Review reason for {item['node_id']}")
        nodes[item["node_id"]]["last_review"] = item["reason"]
        reviewed.add(item["node_id"])
    replies = state.setdefault("notice_replies", {})
    for item in args.get("notice_replies", []):
        if (not isinstance(item, dict) or set(item) != {"notice_id", "reason"}
                or not isinstance(item["notice_id"], str) or not re.fullmatch(r"N[0-9a-f]{6}", item["notice_id"])):
            raise ValueError("Each notice reply is {notice_id: the [N......] id shown on the board, reason}")
        _text(item["reason"], f"Reply reason for {item['notice_id']}")
        replies[item["notice_id"]] = item["reason"]
    if not replies:
        state.pop("notice_replies")
    # A node written or reviewed now has seen its current upstream versions.
    for identifier in changed | reviewed:
        node = nodes[identifier]
        node["seen"] = {up: nodes[up]["version"] for up in _upstream(node, nodes) if up in nodes}
        if requirements is not None:
            node["seen_requirements"] = {r: requirement_fingerprint(requirements[r])
                                         for r in node["requirement_ids"] if r in requirements}
    return state, changed, reviewed


def flags(state, *, requirements=None):
    """Nodes whose upstream changed after they were last written or reviewed."""
    nodes = state["nodes"]
    direct = {}
    for node in nodes.values():
        if node.get("superseded_by"):
            continue
        reasons = []
        for up in _upstream(node, nodes):
            if up in nodes and node["seen"].get(up) != nodes[up]["version"]:
                upstream = nodes[up]
                why = "是新連入的依據或證據" if up not in node["seen"] else (
                    "已被 " + upstream["superseded_by"] + " 取代") if upstream.get("superseded_by") else (
                    f"狀態為 {upstream['status']}" if upstream["status"] in {"overturned", "withdrawn", "refuted", "dropped"}
                    else "內容已更新")
                reasons.append(f"上游 {up} {why}")
        if requirements is not None:
            for req in node["requirement_ids"]:
                current = requirements.get(req)
                if current is None:
                    reasons.append(f"要求 {req} 不在目前規劃中")
                elif node["seen_requirements"].get(req) != requirement_fingerprint(current):
                    reasons.append(f"要求 {req} 已" + ("撤回" if current["disposition"] == "withdrawn" else "修改"))
        if reasons:
            direct[node["id"]] = reasons
    # Downstream of a flagged node may also be affected, but only after it is resolved.
    children = {}
    for node in nodes.values():
        for up in _upstream(node, nodes):
            children.setdefault(up, []).append(node["id"])
    indirect, pending = set(), list(direct)
    while pending:
        for child in children.get(pending.pop(), []):
            if child not in direct and child not in indirect and not nodes[child].get("superseded_by"):
                indirect.add(child)
                pending.append(child)
    return direct, sorted(indirect)


def empty_state():
    return {"nodes": {}}


def planning_requirements(app, session_id):
    """Saved planning requirements when the optional planning extension has a plan."""
    try:
        from planningkit.turn import PlanningTurn
    except ImportError:
        return None
    try:
        return PlanningTurn(app, session_id, None).requirements()
    except (OSError, ValueError, RuntimeError, KeyError):
        return None


class GraphStore:
    def __init__(self, root: Path, *, check_read=None, check_edit=None):
        self.root = Path(root).resolve()
        self.folder = records.local_path(self.root, FOLDER)
        self.check_read = check_read or (lambda path: None)
        self.check_edit = check_edit or (lambda path: None)

    def _ref(self, digest):
        return f"{FOLDER}/revisions/{digest}.json"

    def head(self):
        path = self.folder / "head.json"
        self.check_read(path)
        if not path.exists():
            return None
        value = json.loads(path.read_bytes())
        if not isinstance(value, dict) or set(value) != {"schema_version", "revision_ref"} \
                or value["schema_version"] != SCHEMA_VERSION:
            raise ValueError("Invalid reasoning graph head")
        return value["revision_ref"]

    def read(self, ref=None):
        ref = ref if ref is not None else self.head()
        if ref is None:
            return None, None
        path = records.local_path(self.root, ref)
        if path.parent != self.folder / "revisions":
            raise ValueError("Graph revision must be under .research/graph/revisions")
        self.check_read(path)
        raw = path.read_bytes()
        if len(raw) > MAX_REVISION_BYTES or records.digest(raw) != path.stem:
            raise ValueError(f"Graph revision content does not match its name: {ref}")
        revision = json.loads(raw)
        if revision.get("schema_version") != SCHEMA_VERSION:
            raise ValueError("Unsupported reasoning graph schema_version")
        return ref, revision

    @contextmanager
    def _locked(self):
        self.check_edit(self.folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        lock = self.folder / ".lock"
        self.check_edit(lock)
        try:
            descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise RuntimeError("The reasoning graph is already being updated; retry after that update") from exc
        try:
            os.close(descriptor)
            yield
        finally:
            lock.unlink(missing_ok=True)

    def update(self, args, *, requirements=None):
        allowed = {"expected_revision", "reason", "nodes", "reviews", "notice_replies"}
        if not isinstance(args, dict) or set(args) - allowed or not {"expected_revision", "reason"} <= set(args):
            raise ValueError("research_graph_update takes expected_revision, reason, nodes, reviews "
                             "and/or notice_replies")
        _text(args["reason"], "reason")
        if not args.get("nodes") and not args.get("reviews") and not args.get("notice_replies"):
            raise ValueError("Provide nodes to add or change, reviews of flagged nodes, or notice_replies")
        with self._locked():
            head, previous = self.read()
            if args["expected_revision"] != head:
                raise ValueError(f"expected_revision {args['expected_revision']!r} is not the current graph head "
                                 f"{head!r}; read the board or research_board, then retry with the current head")
            state = previous["state"] if previous else empty_state()
            nxt, changed, reviewed = apply(state, args, requirements=requirements)
            _check_state(self.root, nxt, check_read=self.check_read)
            if nxt == state:
                return {"revision_ref": head, "changed": [], "reviewed": [], "notice": "no-change：圖未變更。"}
            revision = {"schema_version": SCHEMA_VERSION, "revision": previous["revision"] + 1 if previous else 1,
                        "previous_revision": head, "created_at": _now(), "reason": args["reason"], "state": nxt}
            raw = _canonical(revision)
            if len(raw) > MAX_REVISION_BYTES:
                raise ValueError("Graph revision exceeds 1 MiB")
            ref = self._ref(records.digest(raw))
            path = records.local_path(self.root, ref)
            self.check_edit(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(raw)
            head_path = self.folder / "head.json"
            self.check_edit(head_path)
            temporary = self.folder / (".head-" + os.urandom(8).hex() + ".tmp")
            temporary.write_bytes(_canonical({"schema_version": SCHEMA_VERSION, "revision_ref": ref}))
            os.replace(temporary, head_path)
            direct, indirect = flags(nxt, requirements=requirements)
            return {"revision_ref": ref, "revision": revision["revision"], "changed": sorted(changed),
                    "reviewed": sorted(reviewed), "needs_review": direct, "indirectly_affected": indirect}
