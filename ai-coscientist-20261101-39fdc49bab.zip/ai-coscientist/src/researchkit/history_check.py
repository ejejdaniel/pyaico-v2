"""Check proxy formulas on the historical records before candidates are generated.

For each formula the host reads its predictions for the historical samples. When the
formula declares the measured quantity it predicts, the host compares them with the
measurements: mean offset, residual spread, order agreement and the ratio of the
predicted spread to the measured spread. Predictions that are equal on every
historical sample are reported as well: the history cannot check such a formula.
Nothing is corrected; the findings are facts for the author to act on. A quantitative model
(terms) gets instead the coefficients its history and its mechanisms' signs allow (term_model).
"""

from __future__ import annotations

from pathlib import Path
import uuid

from jsonschema import Draft202012Validator

from opencode.provider import _check_abort
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import anchoring, records, scoring, term_model, values_table
from researchkit.leaderboard import _IDS, _SELECTION, _TEXT, _lines, _selected_numbers, fitted_samples, sheet_inputs
from researchkit.report_evidence import _reference

INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "baseline_ids": _IDS,
        "sheets": {"type": "array", "minItems": 1, "maxItems": 12, "items": {
            "type": "object", "properties": {"formula_ref": dict(_TEXT), "values": _SELECTION},
            "required": ["formula_ref", "values"], "additionalProperties": False}},
    },
    "required": ["baseline_ids", "sheets"],
    "additionalProperties": False,
}
FILE = "history_check.json"
OFF_SCALE_SHARE = 0.05  # the board's leaderboard scale notice uses the same tolerance around a target
SPREAD_RANGE = (0.5, 2.0)
# wrong rankings follow; the others are information
ACTION_FLAGS = ("off_scale", "order_reversed", "coefficients_infeasible", "coefficient_pinned_zero")
# order_unchecked: nothing to order the history against; order_unchecked_reason says why (undeclared: no kpi
# or measured; one_sample: only one historical sample has a value; kpi_ties: the KPI is equal on them).
# fitted_history: the constants were set from the compared samples (fitted_on); agreement is not a check.
NOTE = ("Facts about the historical records only; nothing is corrected. off_scale: the predictions sit "
        "away from the measured values by more than their residual spread, so distance-to-target ranking is wrong "
        "until the formula is revised or a constant offset is anchored. order_reversed: the formula orders the "
        "historical samples opposite to their measurements; when they also differ on other formulas "
        "(confounded_with) the measured difference is the net of several changes and does not test one of them. "
        "Either way, its finding lists what to check first. A formula that declares an anchor is ordered by its "
        "anchored predictions, the values its candidates are ranked by. "
        "order_unchecked: nothing tells whether the formula ranks the history the right way round; "
        "order_unchecked_reason and the finding say why: the formula declares no kpi or measured, only one "
        "historical sample has a value, or the KPI is equal on them. fitted_history: the formula declares in "
        "fitted_on that its constants were set from the samples compared, or it was saved after a history check "
        "found a formula of its hypothesis ordering them against the KPI (revised_after), so agreeing is how it was "
        "made, not a check; its leaderboard sheet is history_fitted, not history evidence. equal_on_history: "
        "the historical records cannot check this formula; its leaderboard sheet will be "
        "mechanism-only. spread_mismatch: predicted differences between samples are much smaller or larger than "
        "the measured ones, so candidates' distances to the target are compressed or stretched. Scale findings "
        "(off_scale, spread_mismatch) are fixed before generating candidates, with a revised formula (revises), "
        "or explained in the report. A quantitative model (terms) is not checked this way: its coefficients are "
        "every set that reproduces these measurements with the signs its mechanisms give (model.coefficients). "
        "coefficients_infeasible: there is none, so check the terms (never flip a sign to make it fit); "
        "coefficient_pinned_zero: the history leaves a term no room but zero; coefficients_undetermined: these "
        "samples do not set some coefficients, and the leaderboard compares samples under every set.")


# A formula that predicts the KPI with constants fitted to these samples picked one of the sets they allow.
TERMS_INSTEAD = (" As a model with terms (one per hypothesis: its quantity and its mechanism's sign), its coefficients "
                 "would be every set these samples allow rather than one fit (final-kpi-proxy-discovery).")


CHECK_PHYSICS = (
    "Check the formula's mechanism first: (1) each component or input it uses has the role and meaning the task "
    "defines for it (calc kind roles when the task defines roles by chemical structure); (2) every "
    "term inside the formula has the sign its rationale gives; (3) the implementation computes the stated formula "
    "(calc kind properties); (4) each input value comes from the task, a cited source or a calc result: name each "
    "one you assumed (a constant, a scale or an ordering), since the order may come from it. Correct an error found "
    "there in a revised formula that declares it in correction; never change a sign the mechanism gives to make "
    "the order agree.")


def reversed_finding(basis, pairs, better, confounded_with):
    """What an order against the KPI means, and what to do about it.

    v30 read "a direction or mechanism error" as an instruction and flipped P3 three times. v31 was
    told the history contradicted its three hypotheses, although its two samples differed on all
    three at once; two of the reversals came from a component read in the wrong role and a term with
    the wrong sign, and the agent explained them away instead of finding them.
    """
    head = f"The formula prefers the historical samples in the opposite order to {basis} ({pairs}; the KPI prefers {better})"
    tail = (" Its leaderboard sheet is history_reversed, not history evidence. A formula for this hypothesis saved "
            "after this check is made knowing these samples' order, so its agreement with them counts as fitted "
            "(history_fitted), a declared correction included; the report states what was corrected and why.")
    if confounded_with:
        return (f"{head}. These samples also differ on {', '.join(confounded_with)}: the measured difference is the net "
                "of several changes, so this order alone neither refutes nor supports the hypothesis. "
                + CHECK_PHYSICS + " If nothing is wrong there, report that these samples do not separate the "
                "mechanisms, and which measurement would (calc kind design)." + tail)
    return (f"{head}, and these samples separate it from the other formulas checked here: either the history "
            "contradicts the hypothesis as stated or the formula misstates its mechanism. " + CHECK_PHYSICS
            + " If nothing is wrong there, report the contradiction." + tail)


def confounding(sheets, baseline_ids):
    """{formula label: [other formulas the historical samples cannot separate from it]}.

    sheets: [(label, hypothesis ids, {sample: value})]. n samples give at most n - 1 independent
    differences; when more formulas than that vary on them, each one's order is the net of all of
    them (v31: two samples, three formulas). With more samples, only a formula that orders them
    exactly as another does, or exactly reversed, cannot be told apart from it; any other reversed
    order is evidence against the hypothesis, as it should be in a field with many samples.
    """
    samples = [s for s in baseline_ids if all(s in values for _, _, values in sheets)]
    varying = [(label, set(ids), [values[s] for s in samples]) for label, ids, values in sheets
               if len({values[s] for s in samples}) > 1]
    too_few = len(samples) - 1 < len(varying)
    found = {}
    for label, ids, _ in sheets:
        mine = next((row for row in varying if row[0] == label), None)
        found[label] = [] if mine is None else [
            other for other, theirs, values in varying
            if other != label and theirs != set(ids)
            and (too_few or abs(scoring.tau_b(mine[2], values) or 0) == 1)]
    return found


def check_sheet(template, values, baseline_ids, measured, kpi_values=None, confounded_with=()):
    """Flags, plain findings and the numbers behind them for one formula.

    measured: the values the formula predicts on their own scale, or None.
    kpi_values: the measured KPI named by the formula's kpi declaration, or None.
    confounded_with: the other formulas whose predictions also differ on these samples.
    """
    predicted = {sample: values[sample] for sample in baseline_ids}
    row = {"predicted": predicted, "flags": [], "findings": []}
    equal = len(predicted) > 1 and max(predicted.values()) == min(predicted.values())
    if equal:
        row["flags"].append("equal_on_history")
        row["findings"].append(f"Predictions are equal on every historical sample ({next(iter(predicted.values())):g}): "
                               "the history cannot check this formula.")
    check = (anchoring.apply(predicted, measured, list(baseline_ids), [], template.get("anchor"))[1]
             if measured is not None else None)
    ordered = anchoring.shifted(predicted, check) if check else predicted
    kpi = template.get("kpi")
    if kpi is not None and kpi_values is not None:
        order = scoring.kpi_order(ordered, kpi_values, template["direction"], template.get("target_value"),
                                  kpi["better"], kpi.get("target_value"))
        basis = (f"the measured KPI {kpi.get('column') or kpi['source_path']} (better: {kpi['better']}"
                 + (f" {kpi['target_value']:g}" if kpi["better"] == "target" else "") + ")")
    elif measured is not None:
        order, basis = scoring.kpi_order(ordered, measured, "higher", None, "higher"), "the measured values it predicts"
    else:
        order, basis = None, None
    row["order_checked"] = bool(order and order["pairs"])
    if order is None:
        row["flags"].append("order_unchecked")
        row["order_unchecked_reason"] = "undeclared"
        row["findings"].append("proxy_formula.json declares neither kpi (the measured KPI the formula ranks and which "
                               "of its values are better) nor measured, so the order on the historical samples was "
                               "not checked. Save a revised formula (revises) that adds kpi.")
    else:
        row["history_order"] = order
        compared = order["compared_samples"]
        unvalued = [sample for sample in predicted if sample not in compared]
        if confounded_with:
            row["confounded_with"] = list(confounded_with)
        if order["reversed"]:
            row["flags"].append("order_reversed")
            pairs = ", ".join(f"{a}/{b}" for a, b in order["disagreements"])
            row["findings"].append(reversed_finding(basis, pairs, order["better_by_kpi"], confounded_with))
        elif not order["pairs"]:
            # Three different causes, each with its own remedy; v22 was told the KPI did not separate the
            # samples when its KPI file used other sample IDs.
            row["flags"].append("order_unchecked")
            if not compared:
                row["order_unchecked_reason"] = "no_overlap"
                row["findings"].append(f"None of the historical samples ({', '.join(predicted)}) has a value in "
                                       f"{basis}, so their order was not checked: its sample IDs must be the ones "
                                       "the predictions use.")
            elif len(compared) == 1:
                row["order_unchecked_reason"] = "one_sample"
                row["findings"].append(
                    f"Only one historical sample ({compared[0]}) was checked, so there is no pair to order: pass "
                    "every historical sample in baseline_ids." if not unvalued else
                    f"Only {compared[0]} of the historical samples has a value in {basis} ({', '.join(unvalued)} "
                    "has none), so there is no pair to order.")
            else:
                row["order_unchecked_reason"] = "kpi_ties"
                row["findings"].append(f"{basis[0].upper()}{basis[1:]} is the same for {', '.join(compared)}, so it "
                                       "does not order these historical samples.")
        if unvalued and order["pairs"]:
            row["findings"].append(f"{basis[0].upper()}{basis[1:]} has no value for {', '.join(unvalued)}; the order "
                                   f"was checked on {', '.join(compared)} only.")
        declared = set(template.get("fitted_on") or [])
        fitted = fitted_samples(template)
        revised = template.get("revised_after") or []
        if revised:
            row["revised_after"] = revised
        # Only an agreeing order is "how it was made"; v25's fitted formulas still ranked the history backwards.
        if fitted and order["pairs"] and set(compared) <= fitted and not order["reversed"]:
            row["flags"].append("fitted_history")
            if declared and set(compared) <= declared:
                row["findings"].append(f"The formula's constants were set from {', '.join(sorted(declared))} "
                                       "(fitted_on), the samples it is compared on here: agreeing with them is how it "
                                       "was made, not a check. Its leaderboard sheet counts as history_fitted, not as "
                                       "history evidence." + (TERMS_INSTEAD if template.get("direction") == "target"
                                                              else ""))
            else:
                earlier = "; ".join(f"{item['formula_id'] or item['formula_ref']} in {item['history_check']}"
                                    for item in revised)
                correction = template.get("correction")
                row["findings"].append(
                    f"This formula was saved after a history check found a formula of its hypothesis ordering these "
                    f"samples against the KPI ({earlier}): agreeing with them now is how it was revised, not a check. "
                    + (f"It declares a correction ({correction['error']}: {correction['what']}; basis: "
                       f"{correction['basis']}); state it and its basis in the report. " if correction else
                       "Report what was changed after that check and why. ")
                    + "Its leaderboard sheet counts as history_fitted, not as history evidence.")
    confounded = (f" These samples also differ on {', '.join(confounded_with)}, so the agreement is the net of "
                  "several changes, not specific to this mechanism." if confounded_with else "")
    if measured is None:
        if not row["flags"]:
            row["findings"].append("No finding: the formula orders the historical samples as the KPI does. With few "
                                   "samples this is consistency, not validation." + confounded)
        return row
    compared = check["compared_baselines"]
    row["scale_check"] = {key: value for key, value in check.items() if key != "predicted"}
    if not compared:
        row["findings"].append("The measured selection has no values for these samples; scale was not checked.")
        return row
    offset, spread = check["mean_offset"], check["residual_spread"]
    target = template.get("target_value")
    tolerance = abs(target) * OFF_SCALE_SHARE if isinstance(target, (int, float)) and target else 0
    if not check["anchored"] and abs(offset) > max(tolerance, spread):
        row["flags"].append("off_scale")
        row["findings"].append(f"Predictions are {offset:+g} from the measured values on average (residual spread "
                               f"{spread:g}): distance-to-target ranking is wrong until the formula is revised, or a "
                               "constant offset is anchored.")
    if check["anchored"]:
        row["findings"].append(f"The declared anchor shifts predictions by {-check['offset_applied']:+g}; residuals "
                               f"after it: {', '.join(f'{s} {r:+g}' for s, r in check['residuals_after'].items())}.")
    measured_spread = max(measured[s] for s in compared) - min(measured[s] for s in compared)
    predicted_spread = max(predicted[s] for s in compared) - min(predicted[s] for s in compared)
    row["spread_ratio"] = predicted_spread / measured_spread if measured_spread and len(compared) > 1 else None
    ratio = row["spread_ratio"]
    fitted = fitted_samples(template)
    exact = [s for s in compared
             if s not in fitted and abs(predicted[s] - measured[s]) <= 1e-9 * max(1, abs(measured[s]))]
    hint = None
    if check["anchored"]:
        pass
    elif exact:
        # v28's combined formula listed one of the two samples its constants came from; an exact hit is the trace.
        hint = ("The prediction equals the measured value exactly for "
                + ", ".join(f"{s} ({measured[s]:g})" for s in exact)
                + ", which fitted_on does not list. If any constant of the formula was set from "
                + ("that sample" if len(exact) == 1 else "these samples")
                + ", list it in fitted_on in a revised formula (revises): agreement with the samples a formula was "
                "fitted to is not a check of it.")
    elif ratio is not None and abs(ratio - 1) < 1e-9 and len(compared) > 1 and not fitted:
        # v23 took P2's and P3's slopes from the two measured rows; nothing in the formula said so.
        hint = ("The predictions reproduce the measured differences between these samples exactly. If any constant "
                "was set from them, list them in fitted_on: agreement with the samples a formula was fitted to is not "
                "a check of it.")
    if hint:
        row["findings"].append(hint + (TERMS_INSTEAD if template.get("direction") == "target" else ""))
    if ratio is not None and not equal and not SPREAD_RANGE[0] <= ratio <= SPREAD_RANGE[1]:
        row["flags"].append("spread_mismatch")
        row["findings"].append(f"Predicted differences are {ratio:.2g} times the measured differences across these "
                               "samples, so candidates' distances to the target are "
                               + ("compressed." if ratio < 1 else "stretched."))
    if not row["flags"] and not hint:
        row["findings"].append("No finding: on these samples the predictions are on the measured scale and in the "
                               "measured order. With few samples this is consistency, not validation." + confounded)
    return row


def run(args, root: Path, folder: Path, *, check_read=None, abort=None):
    Draft202012Validator(INPUT_SCHEMA).validate(args)
    refs = [sheet["formula_ref"] for sheet in args["sheets"]]
    if len(set(refs)) != len(refs):
        raise ValueError("Each formula_ref may appear in only one sheet")
    root = root.resolve()
    folder = records.local_path(root, str(folder))
    baseline_ids = args["baseline_ids"]

    def read(path):
        _check_abort(abort)
        if check_read:
            check_read(path)

    sheets, dependencies, inputs = [], [], []
    for sheet in args["sheets"]:
        template, values, _ = sheet_inputs(root, sheet, read, baseline_ids)
        missing = [sample for sample in baseline_ids if sample not in values]
        if missing:
            raise ValueError(f"Values for {sheet['formula_ref']} have no prediction for: {missing}")
        inputs.append((sheet, template, values))
    labels = [template["formula_id"] or sheet["formula_ref"] for sheet, template, _ in inputs]
    others = confounding([(label, template["hypothesis_ids"], values)
                          for label, (_, template, values) in zip(labels, inputs)
                          if not term_model.is_model(template)], baseline_ids)
    for label, (sheet, template, values) in zip(labels, inputs):
        if term_model.is_model(template):
            measured = term_model.read_measured(root, template, baseline_ids, read, label)
            sheets.append({"formula_ref": sheet["formula_ref"], "formula_id": template["formula_id"],
                           "hypothesis_ids": template["hypothesis_ids"], "direction": template["direction"],
                           **({"target_value": template["target_value"]} if "target_value" in template else {}),
                           **({"correction": template["correction"]} if template.get("correction") else {}),
                           **term_model.history_row(template, values, measured, baseline_ids)})
            dependencies += [template["measured"]["record_ref"], sheet["formula_ref"], sheet["values"]["record_ref"]]
            continue
        measured_selection, measured = template.get("measured"), None
        if measured_selection is not None:
            _reference(measured_selection["record_ref"])
            measured = values_table.require_samples(_selected_numbers(root, measured_selection, read, "measured"),
                                                    baseline_ids, measured_selection, "measured", label)
            dependencies.append(measured_selection["record_ref"])
        kpi, kpi_values = template.get("kpi"), None
        if kpi is not None:
            _reference(kpi["record_ref"])
            kpi_values = values_table.require_samples(
                _selected_numbers(root, {key: kpi[key] for key in ("record_ref", "source_path", "column")
                                         if key in kpi}, read, "kpi"), baseline_ids, kpi, "kpi", label)
            dependencies.append(kpi["record_ref"])
        sheets.append({"formula_ref": sheet["formula_ref"], "formula_id": template["formula_id"],
                       "hypothesis_ids": template["hypothesis_ids"],
                       **({"mechanism_predicts": template["mechanism_predicts"]}
                          if "mechanism_predicts" in template else {}),
                       "direction": template["direction"],
                       **({"target_value": template["target_value"]} if "target_value" in template else {}),
                       **({"correction": template["correction"]} if template.get("correction") else {}),
                       **check_sheet(template, values, baseline_ids, measured, kpi_values, others.get(label, []))})
        dependencies += [sheet["formula_ref"], sheet["values"]["record_ref"]]
    outcome = {"baseline_ids": list(baseline_ids), "sheets": sheets, "note": NOTE}
    raw = records.encoded(outcome)
    _check_abort(abort)
    folder.mkdir(parents=True, exist_ok=False)
    destination = folder / FILE
    with destination.open("xb") as stream:
        stream.write(raw)
    saved = records.publish(root, kind="history_check", title="History check of proxy formulas",
                            files=[destination.relative_to(root).as_posix()],
                            depends_on=list(dict.fromkeys(dependencies)), check_read=read)
    return {"result": outcome, "record": records.present(root, saved)}


def execute(args, ctx):
    root = ctx.directory.resolve()
    abort = _abort_event(ctx)
    _check_abort(abort)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_history_check", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=abort)
    folder = records.local_path(root, f".research/history-checks/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    receipt = run(args, root, folder, check_read=lambda path: ensure_access(ctx, path, "read"), abort=abort)
    return ToolResult(title="research_history_check",
                      output=_lines({"record_path": receipt["record"]["record_path"], **receipt["result"]}))
