"""Notice when the agent reads the host's own implementation instead of doing the research.

v8 spent 81 of 119 tool calls printing researchkit source with inspect.getsource to
learn formats. The host does not block this (Bash stays flexible); it counts such
calls in the saved history and says, in the host facts, where formats are documented.
"""

from __future__ import annotations

import json
from pathlib import Path
import re

import opencode
import researchkit


NOTICE_AFTER = 2
_INTROSPECTION = re.compile(r"inspect\.(getsource|getsourcefile|getsourcelines|getfile)|\.__file__|\bdir\(|\bhelp\(|"
                            r"importlib\.resources|pkgutil\.get_data")
_HOST_NAMES = re.compile(r"\b(researchkit|opencode|planningkit)\b")


def _host_dirs():
    return [Path(module.__file__).resolve().parent for module in (researchkit, opencode)]


def _normal(text):
    return text.replace("\\", "/").lower()


def _arguments(call):
    arguments = call.get("arguments")
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except ValueError:
            return {"command": arguments}
    return arguments if isinstance(arguments, dict) else {}


def is_host_read(call, dirs=None) -> bool:
    """A tool call that reads host source: introspection of host modules, or a path inside them."""
    dirs = [_normal(str(d)) for d in (dirs or _host_dirs())]
    arguments = _arguments(call)
    text = _normal(" ".join(str(v) for v in arguments.values() if isinstance(v, str)))
    for d in dirs:
        start = text.find(d)
        while start >= 0:
            rest = text[start + len(d):]
            # The packaged skills are documentation (the same text as the installed skills).
            if not rest.startswith("/skills/") and (rest[:1] in ("", "/", "\"", "'", " ")):
                return True
            start = text.find(d, start + 1)
    return call.get("name") == "bash" and bool(_INTROSPECTION.search(text)) and bool(_HOST_NAMES.search(text))


DOC_GAP = "文件缺口："


def notice(history, *, self_improvement: bool = False) -> str:
    """Host-facts text once the session has read host source NOTICE_AFTER times; empty otherwise.

    self_improvement comes from the workspace configuration ("research": {"self_improvement":
    true}), set by a person before the session starts: then the host is the task material and
    no notice is given. Reading the host because a document was unclear is a documentation gap;
    the notice asks for it as a reasoning-graph question starting with DOC_GAP.
    """
    if self_improvement:
        return ""
    dirs = _host_dirs()
    count = sum(1 for message in history if message.get("role") == "assistant"
                for call in message.get("tool_calls") or [] if is_host_read(call, dirs))
    if count < NOTICE_AFTER:
        return ""
    return ("宿主實作提醒：本工作階段已有 " + str(count) + " 次工具呼叫在讀宿主程式（researchkit／opencode 的原始碼）。"
            "這次的委託是研究，宿主程式不是研究材料，也不是格式說明：工具的參數與回傳寫在工具說明裡，紀錄、模板與"
            "報告版型寫在技能文件裡（例如 research-practice、final-kpi-proxy-discovery、sample、scientific-report-writer "
            "的 report-delivery）。格式不清楚時，直接呼叫工具，錯誤訊息會說明缺什麼。如果是因為文件沒寫清楚才去讀原始碼，"
            f"請用 research_graph_update 新增一個 question 節點，text 以「{DOC_GAP}」開頭，寫明哪一份文件沒說清楚什麼，"
            "然後回到研究。腳本只需要 from researchkit import calc。")
