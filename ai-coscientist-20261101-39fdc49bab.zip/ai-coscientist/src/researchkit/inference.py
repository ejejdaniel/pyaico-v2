"""Source-bound formal inference evidence, without scientific interpretation."""

from __future__ import annotations

from copy import deepcopy
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

from jsonschema import Draft202012Validator

from opencode import runtime_settings
from opencode.permission import PermissionRejected
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records
from researchkit.report_evidence import resolve
from opencode import executor


MAX_BYTES = 262144
COMPUTE_SECONDS = float(runtime_settings.get("compute.inference_s"))  # config/runtime.json, compute
QUERY_NAMES = ("base_consistency", "base_counterexample", "full_consistency", "full_counterexample")
_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}


def _object(properties):
    return {"type": "object", "properties": properties, "required": list(properties),
            "additionalProperties": False}


_CITATION = _object({
    "record_ref": dict(_TEXT), "source_path": dict(_TEXT),
    "start_line": {"type": "integer", "minimum": 1},
    "end_line": {"type": "integer", "minimum": 1}, "quote": dict(_TEXT),
})
_CITATION["required"] = ["record_ref", "source_path", "quote"]
_CITATION["dependentRequired"] = {"start_line": ["end_line"], "end_line": ["start_line"]}
INPUT_SCHEMA = _object({
    "scope": dict(_TEXT),
    "goal": _object({"source": _CITATION, "expr": dict(_TEXT), "interpretation": dict(_TEXT)}),
    "variables": {"type": "array", "maxItems": 32, "items": _object({
        "name": dict(_TEXT), "sort": {"type": "string", "enum": ["Bool", "Real"]},
        "meaning": dict(_TEXT), "unit": {"type": ["string", "null"]},
    })},
    "premises": {"type": "array", "maxItems": 64, "items": _object({
        "id": dict(_TEXT), "origin": {"type": "string", "enum": ["source", "assumption"]},
        "expr": dict(_TEXT), "sources": {"type": "array", "items": _CITATION},
        "interpretation": dict(_TEXT),
    })},
})


def _unique_keys(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"Duplicate JSON key: {key}")
        value[key] = item
    return value


def _invalid_constant(value):
    raise ValueError(f"Invalid JSON constant: {value}")


def parse_json(raw):
    """Use strict decoding wherever this extension owns the raw JSON bytes."""
    return json.loads(raw, object_pairs_hook=_unique_keys, parse_constant=_invalid_constant)


def validate_input(value):
    if isinstance(value, (str, bytes)):
        raw = value.encode("utf-8") if isinstance(value, str) else value
        if len(raw) > MAX_BYTES:
            raise ValueError("Inference input exceeds 262144 UTF-8 bytes")
        value = parse_json(raw.decode("utf-8"))
    # Common already supplies a parsed object. Do not reinterpret scientific text.
    Draft202012Validator(INPUT_SCHEMA).validate(value)
    value = deepcopy(value)
    for variable in value["variables"]:
        if variable["sort"] == "Real":
            if not isinstance(variable["unit"], str) or not variable["unit"].strip():
                raise ValueError("Real variable unit must be nonblank (use '1' for dimensionless)")
        elif variable["unit"] is not None:
            raise ValueError("Bool variable unit must be null")
    for premise in value["premises"]:
        if premise["origin"] == "source" and not premise["sources"]:
            raise ValueError("Source premise needs at least one exact citation")
    raw = records.encoded(value)
    if len(raw) > MAX_BYTES:
        raise ValueError("Inference input exceeds 262144 UTF-8 bytes")
    from researchkit.inference_expr import validate_expressions
    validate_expressions(value)
    return value


def _citations(problem):
    return [problem["goal"]["source"],
            *(citation for premise in problem["premises"] for citation in premise["sources"])]


def _newlines(value):
    return value.replace("\r\n", "\n").replace("\r", "\n")


def validate_sources(root, problem, *, check_read=None):
    """Verify frozen sources and fill omitted positions in the validated copy."""
    citations = _citations(problem)
    choices = list({(item["record_ref"], item["source_path"]):
                    {"record_ref": item["record_ref"], "source_path": item["source_path"]}
                    for item in citations}.values())
    sources = {(item["record_ref"], item["source_path"]): item["text"]
               for item in resolve(root, choices, check_read=check_read)}
    for citation in citations:
        lines = _newlines(sources[citation["record_ref"], citation["source_path"]]).split("\n")
        if lines[-1] == "":
            lines.pop()
        quote = _newlines(citation["quote"])
        if ("start_line" in citation) != ("end_line" in citation):
            raise ValueError("Citation start_line and end_line must be provided together")
        if "start_line" not in citation:
            # Search precisely the text accepted by the explicit-range path,
            # including overlapping matches and preserving the original quote.
            text = "\n".join(lines)
            offset = text.find(quote)
            if offset < 0:
                raise ValueError("Citation quote has no exact location in the selected source")
            if text.find(quote, offset + 1) >= 0:
                raise ValueError("Citation quote has multiple exact locations in the selected source; "
                                 "provide an unambiguous quote or explicit line range")
            citation["start_line"] = text.count("\n", 0, offset) + 1
            citation["end_line"] = text.count("\n", 0, offset + len(quote)) + 1
        start, end = citation["start_line"], citation["end_line"]
        if type(start) is not int or type(end) is not int or not 1 <= start <= end <= len(lines):
            raise ValueError("Citation line range is outside the exact selected source")
        if quote not in "\n".join(lines[start - 1:end]):
            raise ValueError("Citation quote is not contiguous literal text within the selected line range")
    if len(records.encoded(problem)) > MAX_BYTES:
        raise ValueError("Inference input exceeds 262144 UTF-8 bytes after citation location")
    return list(dict.fromkeys(item["record_ref"] for item in citations))


def _query(name, status="not_run", reason="Not executed", elapsed_ms=0):
    return {"name": name, "status": status, "reason": reason, "elapsed_ms": elapsed_ms,
            "values": None, "core_ids": None}


def _read_query(path, name, problem):
    item = parse_json(path.read_text(encoding="utf-8"))
    if not isinstance(item, dict) or set(item) != set(_query(name)) or item["name"] != name:
        raise ValueError(f"Invalid saved query object: {name}")
    status = item["status"]
    if status not in {"sat", "unsat", "unknown", "timeout", "cancelled", "error", "not_run"}:
        raise ValueError(f"Invalid saved query status: {name}")
    if type(item["elapsed_ms"]) is not int or item["elapsed_ms"] < 0:
        raise ValueError(f"Invalid saved query elapsed time: {name}")
    if status in {"sat", "unsat"}:
        if item["reason"] is not None:
            raise ValueError(f"Normal solver result must have null reason: {name}")
    elif not isinstance(item["reason"], str) or not item["reason"].strip():
        raise ValueError(f"Incomplete solver result needs reason: {name}")
    if status == "sat":
        values = item["values"]
        if (not isinstance(values, dict) or set(values) != {v["name"] for v in problem["variables"]}
                or any(not isinstance(v, str) or not v.strip() for v in values.values())):
            raise ValueError(f"Missing exact variable values: {name}")
    elif item["values"] is not None:
        raise ValueError(f"Only sat may contain variable values: {name}")
    core = item["core_ids"]
    if status != "unsat" and core is not None:
        raise ValueError(f"Only unsat may contain a core: {name}")
    if core is not None:
        allowed = {p["id"] for p in problem["premises"]} | {"__negated_goal"}
        if not isinstance(core, list) or any(not isinstance(v, str) or v not in allowed for v in core):
            raise ValueError(f"Invalid core IDs: {name}")
    if status in {"sat", "unsat", "unknown"}:
        for suffix in (".smt2", ".txt"):
            if not path.with_suffix(suffix).is_file():
                raise ValueError(f"Missing raw query evidence: {name}{suffix}")
    return item


def _stop(process):
    if process.poll() is None:
        process.kill()
    process.wait()


def _compute(problem, folder, abort=None):
    """Bound the whole worker lifetime, including native solver/model extraction."""
    started = time.monotonic()
    deadline = started + COMPUTE_SECONDS
    termination = None
    process = None
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(Path(__file__).resolve().parents[1])
    command = [sys.executable, "-m", "researchkit.inference_worker",
               str(folder / "input.json"), str(folder), repr(deadline)]
    try:
        with (folder / "stdout.txt").open("wb") as stdout, (folder / "stderr.txt").open("wb") as stderr:
            if abort is not None and abort.is_set():
                termination = ("cancelled", "Parent cancellation before solver launch")
            else:
                process = executor.spawn(command, executor.Launch("framework_compute", "inference solver"),
                                         cwd=folder, env=environment, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr,
                                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                while process.poll() is None:
                    if abort is not None and abort.is_set():
                        termination = ("cancelled", "Parent cancellation stopped the solver worker")
                        _stop(process)
                        break
                    if time.monotonic() >= deadline:
                        termination = ("timeout", "Shared 30-second computation deadline expired")
                        _stop(process)
                        break
                    time.sleep(min(0.02, max(0, deadline - time.monotonic())))
                if termination is None and process.returncode != 0:
                    termination = ("error", f"Solver worker exited {process.returncode}; inspect stderr.txt")
                if termination is None and abort is not None and abort.is_set():
                    termination = ("cancelled", "Parent cancellation observed when the solver worker exited")
                if termination is None and time.monotonic() >= deadline:
                    termination = ("timeout", "Shared 30-second computation deadline expired before worker completion")
    except Exception as exc:
        termination = ("error", f"Solver worker failure: {type(exc).__name__}: {exc}")
    finally:
        if process is not None and process.poll() is None:
            _stop(process)
    elapsed = max(0, int((time.monotonic() - started) * 1000))
    stdout_text = (folder / "stdout.txt").read_text(encoding="utf-8", errors="replace")
    version_line = stdout_text.splitlines()
    version = version_line[0].strip() if version_line and version_line[0].strip() else None
    queries = []
    for name in QUERY_NAMES:
        path = folder / f"{name}.json"
        if path.exists():
            try:
                queries.append(_read_query(path, name, problem))
            except (ValueError, OSError) as exc:
                queries.append(_query(name, "error", str(exc)))
        else:
            queries.append(_query(name))
    if termination is None and any(q["status"] == "not_run" and q["reason"] == "Not executed" for q in queries):
        termination = ("error", "Solver worker ended without a complete query ledger; inspect saved files")
    if termination is not None:
        # A committed answer remains intact. Attribute interruption to the first
        # unfinished query; subsequent queries are explicitly not executed.
        pending = next((i for i, q in enumerate(queries) if q["status"] == "not_run"
                        and not (folder / f"{q['name']}.json").exists()), None)
        if pending is not None:
            queries[pending] = _query(QUERY_NAMES[pending], *termination, elapsed_ms=elapsed)
        elif not any(q["status"] in {"error", "timeout", "cancelled"} for q in queries):
            # Do not hide a failed worker behind complete-looking results.
            raise RuntimeError(f"{termination[1]}; completed query files remain at {folder}")
        for i, item in enumerate(queries):
            if item["status"] == "not_run" and item["reason"] == "Not executed":
                queries[i] = _query(item["name"], reason=f"Not executed after {termination[0]}")
    for item in queries:
        destination = folder / f"{item['name']}.json"
        if not destination.exists():
            temporary = destination.with_suffix(".json.tmp")
            temporary.write_bytes(records.encoded(item))
            temporary.replace(destination)
    return {"input_sha256": records.digest((folder / "input.json").read_bytes()),
            "solver_version": version, "elapsed_ms": elapsed, "queries": queries}


def run(problem, root: Path, folder: Path, *, check_read=None, abort=None,
        extra_dependencies=(), expected_input: bytes | None = None):
    """Execute one validated request and freeze its evidence in an existing record."""
    root = root.resolve()
    folder = records.local_path(root, str(folder))
    problem = validate_input(problem)
    dependencies = validate_sources(root, problem, check_read=check_read)
    raw = records.encoded(problem)
    if expected_input is not None and raw != expected_input:
        raise ValueError("Inference input differs from the expected frozen bytes")
    dependencies = list(dict.fromkeys([*dependencies, *extra_dependencies]))
    # Preflight publication dependencies before spending computation; no hidden
    # source inference or selection occurs during this integrity traversal.
    records._read_dependencies(root, dependencies, check_read=check_read)
    if abort is not None and abort.is_set():
        raise PermissionRejected("Execution stopped before inference")
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "input.json").write_bytes(raw)
    if (folder / "input.json").read_bytes() != raw:
        raise RuntimeError(f"Inference input readback failed: {folder}")
    try:
        outcome = _compute(problem, folder, abort)
        if (folder / "input.json").read_bytes() != raw:
            raise RuntimeError("Inference input changed during execution; saved files are not a validated result")
        (folder / "result.json").write_bytes(records.encoded(outcome))
        if parse_json((folder / "result.json").read_text(encoding="utf-8")) != outcome:
            raise RuntimeError("Inference result readback failed")
        if abort is not None and abort.is_set():
            raise PermissionRejected(f"Execution stopped; inference evidence remains at {folder}")
        captured = {path.relative_to(root).as_posix(): path.read_bytes()
                    for path in sorted(folder.iterdir()) if path.is_file() and not path.name.endswith(".tmp")}
        relative = folder.relative_to(root).as_posix()
        if captured[f"{relative}/input.json"] != raw or captured[f"{relative}/result.json"] != records.encoded(outcome):
            raise RuntimeError("Inference input/result changed before publication")
        for query in outcome["queries"]:
            if parse_json(captured[f"{relative}/{query['name']}.json"].decode("utf-8")) != query:
                raise RuntimeError("Inference query changed before publication")
        saved = records.publish(root, kind="implementation", title="Formal inference: " + problem["scope"],
                                files=list(captured), depends_on=dependencies, check_read=check_read)
        # publish reads files again: compare its frozen bytes with the computation
        # handoff, not merely with hashes calculated from that later read.
        if {item["source_path"] for item in saved["files"]} != set(captured):
            raise RuntimeError(f"Published inference file selection changed: {saved['record_path']}")
        saved_folder = records.local_path(root, saved["record_path"]).parent
        for item in saved["files"]:
            frozen = records.local_path(saved_folder, item["snapshot"])
            if check_read:
                check_read(frozen)
            if frozen.read_bytes() != captured[item["source_path"]]:
                raise RuntimeError(f"Published inference bytes differ from computed evidence: {saved['record_path']}")
        failed = next((q for q in outcome["queries"] if q["status"] in {"error", "timeout", "cancelled"}), None)
        if failed is not None:
            raise RuntimeError(f"{failed['name']}: {failed['status']}: {failed['reason']}; "
                               f"preserved implementation record: {saved['record_path']}")
        return records.present(root, saved)
    except PermissionRejected:
        raise
    except Exception as exc:
        raise RuntimeError(f"Inference did not complete: {exc}. Saved evidence remains at {folder}") from exc


def execute(args, ctx):
    root = ctx.directory.resolve()
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="check_inference", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=_abort_event(ctx))
    folder = records.local_path(root, f".research/inference-runs/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    # Grant/check readback paths before launching; cancellation must not require a
    # fresh permission to preserve already-produced local evidence.
    ensure_access(ctx, folder, "read")
    saved = run(args, root, folder, check_read=lambda path: ensure_access(ctx, path, "read"),
                abort=_abort_event(ctx))
    # Return the committed result itself to the calling agent. Working files and
    # the record receipt alone do not establish which values it actually saw.
    result_source = (folder / "result.json").relative_to(root).as_posix()
    selected = resolve(root, [{"record_ref": saved["record_path"], "source_path": result_source}],
                       check_read=lambda path: ensure_access(ctx, path, "read"))[0]
    outcome = parse_json(selected["text"])
    abort = _abort_event(ctx)
    if abort is not None and abort.is_set():
        raise PermissionRejected(f"Execution stopped; inference evidence remains at {saved['record_path']}")
    return ToolResult(title="check_inference", output=json.dumps(
        {**saved, "result": outcome}, ensure_ascii=False, indent=2, allow_nan=False))
