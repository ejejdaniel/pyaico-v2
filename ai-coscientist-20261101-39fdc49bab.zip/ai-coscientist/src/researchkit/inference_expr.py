"""A deliberately small, typed expression language for formal inference.

This module checks syntax and declared types only. It does not interpret the
scientific meaning, adequacy, or provenance of any statement.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any


MAX_VARIABLES = 32
MAX_PREMISES = 64
MAX_EXPRESSION_BYTES = 8192
MAX_EXPRESSION_DEPTH = 64
RESERVED_NAMES = frozenset({
    "Bool", "Real", "Int", "true", "false", "and", "or", "not", "xor",
    "distinct", "ite", "let", "forall", "exists", "lambda", "as", "match",
    "par", "to_real", "to_int", "is_int", "div", "mod", "abs",
})
_IDENTIFIER = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,63}\Z", re.ASCII)
_INTEGER = re.compile(r"(?:0|[1-9][0-9]*)\Z", re.ASCII)
AST = tuple[Any, ...]


class InferenceExpressionError(ValueError):
    """An expression or declaration is outside the approved formal language."""


def _identifier(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _IDENTIFIER.fullmatch(value):
        raise InferenceExpressionError(f"{label}: expected an ASCII identifier of at most 64 characters")
    if value in RESERVED_NAMES:
        raise InferenceExpressionError(f"{label}: reserved identifier {value!r}")
    return value


def _signed_integer(node: AST) -> str | None:
    """Recognize integer literals and unary signs without evaluating an expression."""
    if node[0] == "num":
        return node[1]
    if node[0] == "call" and node[1] == "-" and len(node[2]) == 1:
        value = _signed_integer(node[2][0])
        if value is not None:
            return value[1:] if value.startswith("-") else "-" + value
    return None


class _Parser:
    def __init__(self, expression: Any, variables: Mapping[str, str], label: str):
        self.label = label
        if not isinstance(expression, str):
            self.fail("expression must be a string")
        try:
            size = len(expression.encode("utf-8"))
        except UnicodeEncodeError as exc:
            raise InferenceExpressionError(f"{label}: invalid Unicode expression") from exc
        if size > MAX_EXPRESSION_BYTES:
            self.fail(f"expression exceeds {MAX_EXPRESSION_BYTES} UTF-8 bytes")
        self.tokens = re.findall(r"\(|\)|[^\s()]+", expression)
        self.position = 0
        self.variables = variables

    def fail(self, message: str) -> None:
        raise InferenceExpressionError(f"{self.label}: {message}")

    def parse(self) -> AST:
        node, sort = self.expression(1)
        if self.position != len(self.tokens):
            self.fail("expected exactly one expression")
        if sort != "Bool":
            self.fail("goal and premises must have Bool type")
        return node

    def expression(self, depth: int) -> tuple[AST, str]:
        if depth > MAX_EXPRESSION_DEPTH:
            self.fail(f"expression exceeds depth {MAX_EXPRESSION_DEPTH}")
        if self.position >= len(self.tokens):
            self.fail("unexpected end of expression")
        token = self.tokens[self.position]
        self.position += 1
        if token != "(":
            if token in {"true", "false"}:
                return ("bool", token == "true"), "Bool"
            if _INTEGER.fullmatch(token):
                return ("num", token), "Real"
            if token in self.variables:
                return ("var", token), self.variables[token]
            self.fail(f"undeclared identifier or unsupported token {token!r}")
        if self.position >= len(self.tokens):
            self.fail("missing operator")
        operator = self.tokens[self.position]
        self.position += 1
        allowed = {"+", "-", "*", "/", "=", "<", "<=", ">", ">=", "and", "or", "not", "=>"}
        if operator not in allowed:
            self.fail(f"unsupported operator {operator!r}")
        arguments: list[AST] = []
        sorts: list[str] = []
        while self.position < len(self.tokens) and self.tokens[self.position] != ")":
            node, sort = self.expression(depth + 1)
            arguments.append(node)
            sorts.append(sort)
        if self.position >= len(self.tokens):
            self.fail("unclosed parenthesis")
        self.position += 1
        count = len(arguments)
        if operator in {"not", "/"}:
            expected = 1 if operator == "not" else 2
            if count != expected:
                self.fail(f"{operator!r} requires exactly {expected} operand(s)")
        elif count < (1 if operator == "-" else 2):
            self.fail(f"{operator!r} has too few operands")
        if operator in {"+", "-", "*", "/", "<", "<=", ">", ">="}:
            if any(sort != "Real" for sort in sorts):
                self.fail(f"{operator!r} requires Real operands")
        elif operator == "=":
            if len(set(sorts)) != 1:
                self.fail("equality requires operands of the same type")
        elif any(sort != "Bool" for sort in sorts):
            self.fail(f"{operator!r} requires Bool operands")
        if operator == "/":
            numerator, denominator = map(_signed_integer, arguments)
            if numerator is None or denominator is None:
                self.fail("division requires two constant integer literals, optionally unary-negated")
            if denominator.lstrip("-") == "0":
                self.fail("division denominator must be nonzero")
        result_sort = "Real" if operator in {"+", "-", "*", "/"} else "Bool"
        return ("call", operator, tuple(arguments)), result_sort


def _contains_goal_conjunct(node: AST, goal: AST) -> bool:
    if node == goal:
        return True
    return bool(
        node[0] == "call" and node[1] == "and"
        and any(_contains_goal_conjunct(child, goal) for child in node[2])
    )


def validate_expressions(problem: Mapping[str, Any]) -> tuple[dict[str, str], AST, dict[str, AST]]:
    """Return typed syntax trees, rejecting direct syntactic use of the goal.

    Full request shape, citation validation, and scientific interpretation are
    owned by the caller. This also checks declarations needed to parse safely.
    """
    if not isinstance(problem, Mapping):
        raise InferenceExpressionError("problem must be an object")
    declarations = problem.get("variables")
    premises = problem.get("premises")
    if not isinstance(declarations, list) or len(declarations) > MAX_VARIABLES:
        raise InferenceExpressionError(f"variables must be a list of at most {MAX_VARIABLES} entries")
    if not isinstance(premises, list) or len(premises) > MAX_PREMISES:
        raise InferenceExpressionError(f"premises must be a list of at most {MAX_PREMISES} entries")
    variables: dict[str, str] = {}
    names: set[str] = set()
    for index, declaration in enumerate(declarations):
        if not isinstance(declaration, Mapping):
            raise InferenceExpressionError(f"variables[{index}] must be an object")
        name = _identifier(declaration.get("name"), f"variables[{index}].name")
        if name in names:
            raise InferenceExpressionError(f"duplicate identifier {name!r}")
        sort = declaration.get("sort")
        if sort not in ("Bool", "Real"):
            raise InferenceExpressionError(f"{name}: sort must be Bool or Real")
        names.add(name)
        variables[name] = sort
    goal_record = problem.get("goal")
    if not isinstance(goal_record, Mapping):
        raise InferenceExpressionError("goal must be an object")
    goal = _Parser(goal_record.get("expr"), variables, "goal.expr").parse()
    parsed_premises: dict[str, AST] = {}
    for index, premise in enumerate(premises):
        if not isinstance(premise, Mapping):
            raise InferenceExpressionError(f"premises[{index}] must be an object")
        identifier = _identifier(premise.get("id"), f"premises[{index}].id")
        if identifier in names:
            raise InferenceExpressionError(f"duplicate identifier {identifier!r}")
        names.add(identifier)
        if premise.get("origin") not in ("source", "assumption"):
            raise InferenceExpressionError(f"{identifier}: origin must be source or assumption")
        node = _Parser(premise.get("expr"), variables, f"premise {identifier}").parse()
        if _contains_goal_conjunct(node, goal):
            raise InferenceExpressionError(f"premise {identifier}: goal is used directly as a premise or top-level and conjunct")
        parsed_premises[identifier] = node
    return variables, goal, parsed_premises
