"""Isolated local Z3 worker; its results concern only the supplied formal model."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
import sys
import time
from typing import Any

from researchkit.inference_expr import AST, validate_expressions


QUERY_NAMES = (
    "base_consistency", "base_counterexample", "full_consistency", "full_counterexample",
)


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _unique_object_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key!r}")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"Nonstandard JSON constant: {value}")


def _translate(node: AST, variables: dict[str, Any], z3: Any, context: Any) -> Any:
    if node[0] == "bool":
        return z3.BoolVal(node[1], ctx=context)
    if node[0] == "num":
        return z3.RealVal(node[1], ctx=context)
    if node[0] == "var":
        return variables[node[1]]
    operator = node[1]
    arguments = [_translate(child, variables, z3, context) for child in node[2]]
    if operator == "and":
        return z3.And(*arguments)
    if operator == "or":
        return z3.Or(*arguments)
    if operator == "not":
        return z3.Not(arguments[0])
    if operator == "=>":
        result = arguments[-1]
        for argument in reversed(arguments[:-1]):
            result = z3.Implies(argument, result)
        return result
    if operator in {"=", "<", "<=", ">", ">="}:
        comparisons = []
        for left, right in zip(arguments, arguments[1:]):
            if operator == "=":
                comparisons.append(left == right)
            elif operator == "<":
                comparisons.append(left < right)
            elif operator == "<=":
                comparisons.append(left <= right)
            elif operator == ">":
                comparisons.append(left > right)
            else:
                comparisons.append(left >= right)
        return comparisons[0] if len(comparisons) == 1 else z3.And(*comparisons)
    if operator == "-" and len(arguments) == 1:
        return -arguments[0]
    result = arguments[0]
    for argument in arguments[1:]:
        if operator == "+":
            result = result + argument
        elif operator == "-":
            result = result - argument
        elif operator == "*":
            result = result * argument
        elif operator == "/":
            result = result / argument
        else:
            raise ValueError(f"unexpected validated operator {operator!r}")
    return result


def _query_record(name: str, status: str, reason: str | None, elapsed_ms: int = 0,
                  values: dict[str, str] | None = None, core_ids: list[str] | None = None) -> dict[str, Any]:
    return {"name": name, "status": status, "reason": reason, "elapsed_ms": elapsed_ms,
            "values": values, "core_ids": core_ids}


def _query(name: str, constraints: list[tuple[str, Any]], negated_goal: Any | None,
           variables: dict[str, Any], folder: Path, deadline: float, z3: Any, context: Any) -> dict[str, Any]:
    started = time.monotonic()
    if started >= deadline:
        record = _query_record(name, "timeout", "Shared inference deadline expired before query")
        _atomic_json(folder / f"{name}.json", record)
        return record
    raw_parts: list[str] = []
    status = "error"
    reason: str | None = "Query did not complete"
    values: dict[str, str] | None = None
    core_ids: list[str] | None = None
    try:
        solver = z3.Solver(ctx=context)
        labels = []
        for identifier, expression in constraints:
            label = z3.Bool(identifier, ctx=context)
            solver.assert_and_track(expression, label)
            labels.append(label)
        if negated_goal is not None:
            label = z3.Bool("__negated_goal", ctx=context)
            solver.assert_and_track(negated_goal, label)
            labels.append(label)
        # assert_and_track emits implications in to_smt2(). Replaying those with
        # plain check-sat would leave the tracking labels false and lose premises.
        script, marker, suffix = solver.to_smt2().rpartition("(check-sat)")
        if not marker:
            raise RuntimeError("Z3 did not emit the expected check-sat command")
        assumptions = " ".join(label.sexpr() for label in labels)
        script = "(set-option :produce-models true)\n(set-option :produce-unsat-cores true)\n" + script
        script += f"(check-sat-assuming ({assumptions}))" + suffix
        (folder / f"{name}.smt2").write_text(script, encoding="utf-8")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            status, reason = "timeout", "Shared inference deadline expired before solver call"
            raw_parts.append(reason)
        else:
            solver.set(timeout=max(1, math.floor(remaining * 1000)))
            outcome = solver.check()
            raw_parts.append(str(outcome))
            if outcome == z3.sat:
                model = solver.model()
                values = {key: model.eval(value, model_completion=True).sexpr() for key, value in variables.items()}
                raw_parts.append(model.sexpr())
                status, reason = "sat", None
            elif outcome == z3.unsat:
                try:
                    core_ids = [str(label) for label in solver.unsat_core()]
                    raw_parts.append("(" + " ".join(core_ids) + ")")
                except z3.Z3Exception as exc:
                    # A missing explanatory core does not erase a completed
                    # unsat result; the approved contract represents it as null.
                    core_ids = None
                    raw_parts.append(f"Unsat core unavailable: {exc}")
                status, reason = "unsat", None
            else:
                reason = solver.reason_unknown() or "Z3 returned unknown without a reason"
                raw_parts.append(reason)
                normalized_reason = reason.lower()
                status = "timeout" if "timeout" in normalized_reason or time.monotonic() >= deadline else "unknown"
    except Exception as exc:
        status, reason = "error", f"{type(exc).__name__}: {exc}"
        values, core_ids = None, None
        raw_parts.append(reason)
    finished = time.monotonic()
    if finished >= deadline:
        status, reason = "timeout", "Shared inference deadline expired before query output extraction completed"
        values, core_ids = None, None
        raw_parts.append(reason)
    elapsed_ms = max(0, int((finished - started) * 1000))
    record = _query_record(name, status, reason, elapsed_ms, values, core_ids)
    (folder / f"{name}.txt").write_text("\n".join(raw_parts) + "\n", encoding="utf-8")
    _atomic_json(folder / f"{name}.json", record)
    return record


def run_worker(problem: dict[str, Any], folder: Path, deadline: float, z3: Any) -> list[dict[str, Any]]:
    """Execute the fixed, bounded solver checks. Source validity is external."""
    variable_sorts, goal_ast, premise_asts = validate_expressions(problem)
    if not math.isfinite(deadline):
        raise ValueError("deadline must be a finite monotonic timestamp")
    folder.mkdir(parents=True, exist_ok=True)
    context = z3.Context()
    variables = {
        name: (z3.Bool(name, ctx=context) if sort == "Bool" else z3.Real(name, ctx=context))
        for name, sort in variable_sorts.items()
    }
    goal = _translate(goal_ast, variables, z3, context)
    base = []
    assumptions = []
    for premise in problem["premises"]:
        pair = (premise["id"], _translate(premise_asts[premise["id"]], variables, z3, context))
        (base if premise["origin"] == "source" else assumptions).append(pair)
    results: dict[str, dict[str, Any]] = {}

    def execute(name: str, constraints: list[tuple[str, Any]], counterexample: bool = False) -> str:
        record = _query(name, constraints, z3.Not(goal) if counterexample else None,
                        variables, folder, deadline, z3, context)
        results[name] = record
        return record["status"]

    def skip(name: str, reason: str) -> None:
        record = _query_record(name, "not_run", reason)
        results[name] = record
        _atomic_json(folder / f"{name}.json", record)

    stopped = {"error", "timeout", "cancelled"}
    base_status = execute("base_consistency", base)
    if base_status == "sat":
        next_status = execute("base_counterexample", base, True)
    else:
        skip("base_counterexample", f"Base consistency was {base_status}; counterexample check requires sat")
        next_status = base_status
    if base_status == "unsat":
        skip_reason = "Source premises are inconsistent; later queries were skipped"
    elif next_status in stopped:
        skip_reason = f"Previous query ended with {next_status}; remaining queries were stopped"
    elif not assumptions:
        skip_reason = "No added assumptions; full queries would duplicate base queries"
    else:
        skip_reason = None
    if skip_reason is not None:
        skip("full_consistency", skip_reason)
        skip("full_counterexample", skip_reason)
    else:
        full_status = execute("full_consistency", base + assumptions)
        if full_status == "sat":
            execute("full_counterexample", base + assumptions, True)
        else:
            skip("full_counterexample", f"Full consistency was {full_status}; counterexample check requires sat")
    return [results[name] for name in QUERY_NAMES]


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    if len(arguments) != 3:
        print("usage: python -m researchkit.inference_worker INPUT_JSON RUN_FOLDER DEADLINE_MONOTONIC", file=sys.stderr)
        return 2
    try:
        import z3
    except ImportError:
        print("check_inference requires the local z3-solver dependency; it is not installed", file=sys.stderr)
        return 2
    print(z3.get_version_string(), flush=True)
    try:
        problem = json.loads(Path(arguments[0]).read_text(encoding="utf-8"),
                             object_pairs_hook=_unique_object_pairs, parse_constant=_reject_json_constant)
        run_worker(problem, Path(arguments[1]), float(arguments[2]), z3)
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
