"""research_judge: blinded, repeated LLM scoring for a hypothesis that no formula can compute.

The host hides which samples are historical and which are candidates: every
repeat sees all samples under fresh codes in a fresh order, in its own sub-session
whose only tools fetch web pages (no workspace reads, no research board). Each
score must cite sources; the host checks the cited URLs against what that
sub-session actually fetched. The mean scores become a values map that
research_leaderboard uses as an llm_judge sheet, which can support only a
conditional surpass.
"""

from __future__ import annotations

import json
from pathlib import Path
import random
import re
import uuid

from jsonschema import Draft202012Validator

from opencode import search_switch
from opencode.agent import Agent
from opencode.permission import from_config
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records, scoring
from researchkit.report_evidence import _reference, resolve


AGENT = "research-judge"
SYSTEM_PATH = Path(__file__).parent / "skills/research-judge/references/judge-system.md"
MAX_SAMPLES = 40
MAX_STEPS = 16
LOW_AGREEMENT = 0.5
# Words that would tell the judge which samples are history and which are new designs.
REVEALING = re.compile(r"histor|baseline|candidate|measured|experiment(al)? result|歷史|候選|實測|量測|基準|既有樣本",
                       re.IGNORECASE)
_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}
INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "formula_ref": dict(_TEXT),
        "criterion": dict(_TEXT),
        "samples": {"type": "object", "minProperties": 2, "maxProperties": MAX_SAMPLES,
                    "additionalProperties": dict(_TEXT)},
        "repeats": {"type": "integer", "minimum": 2, "maximum": 4},
    },
    "required": ["formula_ref", "criterion", "samples"],
    "additionalProperties": False,
}
CHILD_PERMISSION = [
    {"permission": "*", "pattern": "*", "action": "deny"},
    {"permission": "webfetch", "pattern": "*", "action": "allow"},
    {"permission": "websearch", "pattern": "*", "action": "allow"},
]


def _formula(root, ref, read):
    """The llm_judge formula record and the statement of the one hypothesis it stands for."""
    record = records.read_record(root, ref, check_read=read)
    if record["kind"] != "proxy_formula":
        from researchkit.leaderboard import not_a_formula
        raise ValueError(not_a_formula(ref, record["kind"]))
    files = [f for f in record["files"] if Path(f["source_path"]).name == "proxy_formula.json"]
    if len(files) != 1:
        raise ValueError(f"{ref} must contain exactly one proxy_formula.json")
    frozen, = resolve(root, [{"record_ref": ref, "source_path": files[0]["source_path"]}], check_read=read)
    value = json.loads(frozen["text"])
    if not isinstance(value, dict) or value.get("method") != "llm_judge":
        raise ValueError(f"{ref}: proxy_formula.json must declare \"method\": \"llm_judge\"")
    if value.get("direction") != "higher":
        raise ValueError(f"{ref}: an llm_judge formula must declare direction higher (a higher score is better)")
    ids = value.get("hypothesis_ids")
    if not isinstance(ids, list) or len(ids) != 1 or not isinstance(ids[0], str):
        raise ValueError(f"{ref}: an llm_judge formula stands for exactly one hypothesis (hypothesis_ids: [one id])")
    hypothesis_id = ids[0]
    for parent in record["depends_on"]:
        try:
            upstream = records.read_record(root, parent, check_read=read)
        except (OSError, ValueError, KeyError):
            continue
        for item in upstream["files"]:
            if Path(item["source_path"]).name != "hypotheses.json":
                continue
            text, = resolve(root, [{"record_ref": parent, "source_path": item["source_path"]}], check_read=read)
            for row in (json.loads(text["text"]).get("hypotheses") or []):
                if isinstance(row, dict) and row.get("id") == hypothesis_id and isinstance(row.get("statement"), str):
                    return value, hypothesis_id, row["statement"]
    raise ValueError(f"{ref}: depend on the hypothesis record whose hypotheses.json states {hypothesis_id}")


def _prompt(statement, criterion, coded):
    lines = "\n".join(f"{code}: {text}" for code, text in coded)
    codes = ", ".join(code for code, _ in coded)
    return (f"Hypothesis under test:\n{statement}\n\nCriterion to score:\n{criterion}\n\n"
            f"Samples (codes are arbitrary and their order is random):\n{lines}\n\n"
            "Score every sample from 0 to 10 on the criterion, higher meaning the hypothesis predicts a better result. "
            "Look up evidence before scoring and cite the exact URLs you fetched. Reply with only this JSON object:\n"
            '{"scores": {"' + coded[0][0] + '": {"score": 0-10, "reason": "...", "sources": ["https://..."]}, ...}}\n'
            f"Include every code: {codes}.")


def _parse(text, codes):
    body = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", text or "")
    start, end = body.find("{"), body.rfind("}")
    if start < 0 or end < start:
        raise ValueError("the reply has no JSON object")
    value = json.loads(body[start:end + 1])
    scores = value.get("scores") if isinstance(value, dict) else None
    if not isinstance(scores, dict):
        raise ValueError("the reply has no scores object")
    missing = [c for c in codes if c not in scores]
    if missing:
        raise ValueError(f"the reply is missing {', '.join(missing)}")
    parsed = {}
    for code in codes:
        row = scores[code]
        score = row.get("score") if isinstance(row, dict) else None
        if isinstance(score, bool) or not isinstance(score, (int, float)) or not 0 <= score <= 10:
            raise ValueError(f"{code}: score must be a number from 0 to 10")
        sources = row.get("sources") if isinstance(row.get("sources"), list) else []
        parsed[code] = {"score": float(score), "reason": str(row.get("reason") or ""),
                        "sources": [s for s in sources if isinstance(s, str)]}
    return parsed


def _fetched(app, session_id):
    """URLs the sub-session actually fetched (webfetch arguments)."""
    urls = set()
    for message in app.store.messages(session_id):
        for call in message.get("tool_calls") or []:
            name = call.get("name") or (call.get("function") or {}).get("name")
            arguments = call.get("arguments") or (call.get("function") or {}).get("arguments") or {}
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except ValueError:
                    arguments = {}
            if name == "webfetch" and isinstance(arguments.get("url"), str):
                urls.add(arguments["url"].rstrip("/"))
    return urls


def _ensure_agent(app):
    if AGENT not in app.agents:
        app.agents[AGENT] = Agent(
            name=AGENT, description="Blinded scorer used by research_judge.", mode="subagent", hidden=True,
            prompt=SYSTEM_PATH.read_text(encoding="utf-8"), steps=MAX_STEPS,
            permission=from_config({"*": "deny", "webfetch": "allow", "websearch": "allow"}))


def judge(ctx, args, *, ask=None):
    Draft202012Validator(INPUT_SCHEMA).validate(args)
    _reference(args["formula_ref"])
    root = ctx.directory.resolve()

    def read(path):
        ensure_access(ctx, path, "read")

    formula, hypothesis_id, statement = _formula(root, args["formula_ref"], read)
    revealing = {sid: REVEALING.search(text).group(0) for sid, text in args["samples"].items()
                 if REVEALING.search(text)}
    if revealing:
        raise ValueError("Sample descriptions must not say which samples are historical or new, or give measured "
                         "results; remove: " + "; ".join(f"{s} ({w!r})" for s, w in revealing.items()))
    _ensure_agent(ctx.app)
    parent = ctx.app.store.get_session(ctx.session_id)
    model = parent.get("model")
    # The scorers may search the web only while the user's web-search switch is on.
    permission = CHILD_PERMISSION + search_switch.denied(parent.get("permission"))
    repeats = args.get("repeats", 2)
    ids = list(args["samples"])
    runs = []
    for repeat in range(repeats):
        order = ids[:]
        random.Random(f"{args['formula_ref']}:{repeat}").shuffle(order)
        coded = [(f"S{n:02d}", sid) for n, sid in enumerate(order, 1)]
        code_of = dict(coded)
        prompt = _prompt(statement, args["criterion"], [(c, args["samples"][sid]) for c, sid in coded])
        child = ctx.app.store.create_session(directory=str(ctx.directory), agent=AGENT, model=model,
                                             title=f"research_judge {hypothesis_id} repeat {repeat + 1}",
                                             parent_id=ctx.session_id, permission=permission)
        result = ctx.app.run_prompt(child["id"], prompt, agent=AGENT, model=model, depth=1,
                                    _parent_id=ctx.session_id, _abort_event=_abort_event(ctx))
        run = {"repeat": repeat + 1, "session_id": child["id"], "codes": code_of, "status": result.get("status")}
        try:
            parsed = _parse(result.get("text") or "", [c for c, _ in coded])
        except (ValueError, json.JSONDecodeError) as exc:
            run["error"] = str(exc)
            run["reply"] = (result.get("text") or "")[:4000]
            runs.append(run)
            continue
        fetched = _fetched(ctx.app, child["id"])
        run["scores"] = {}
        for code, row in parsed.items():
            cited = [u for u in row["sources"]]
            run["scores"][code_of[code]] = {**row, "unfetched_sources": [u for u in cited
                                                                         if u.rstrip("/") not in fetched]}
        run["fetched_urls"] = sorted(fetched)
        runs.append(run)
    good = [r for r in runs if "scores" in r]
    if len(good) < 2:
        raise ValueError("research_judge needs at least two usable repeats; failures: "
                         + "; ".join(r.get("error", "") for r in runs if "error" in r))
    values = {sid: sum(r["scores"][sid]["score"] for r in good) / len(good) for sid in ids}
    spread = {sid: max(r["scores"][sid]["score"] for r in good) - min(r["scores"][sid]["score"] for r in good)
              for sid in ids}
    taus = []
    for a in range(len(good)):
        for b in range(a + 1, len(good)):
            tau = scoring.tau_b([good[a]["scores"][s]["score"] for s in ids],
                                [good[b]["scores"][s]["score"] for s in ids])
            taus.append(tau)
    defined = [t for t in taus if t is not None]
    agreement = sum(defined) / len(defined) if defined else None
    unsourced = sorted({sid for r in good for sid in ids if not r["scores"][sid]["sources"]})
    unfetched = sorted({u for r in good for sid in ids for u in r["scores"][sid]["unfetched_sources"]})
    summary = {"hypothesis_id": hypothesis_id, "formula_id": formula.get("formula_id"),
               "repeats_requested": repeats, "repeats_used": len(good), "agreement_kendall_tau_b": agreement,
               "low_agreement": agreement is None or agreement < LOW_AGREEMENT,
               "unsourced_samples": unsourced, "unfetched_citations": unfetched, "score_spread": spread}
    text = (f"LLM judge for {hypothesis_id}: {len(good)} blinded repeats, agreement between repeats "
            f"tau_b = {'undefined' if agreement is None else f'{agreement:.2f}'}")
    if summary["low_agreement"]:
        text += " (low: the scores are not stable)"
    if unsourced:
        text += f"; no source for {', '.join(unsourced)}"
    if unfetched:
        text += f"; {len(unfetched)} cited URL(s) were never fetched by the judge"
    summary["conclusion"] = text + ". Use values.json as an llm_judge sheet in research_leaderboard."
    folder = records.local_path(root, f".research/judgments/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    folder.mkdir(parents=True)
    judgment_path, values_path = folder / "judgment.json", folder / "values.json"
    judgment_path.write_bytes(records.encoded({**summary, "criterion": args["criterion"],
                                               "statement": statement, "samples": args["samples"], "runs": runs}))
    values_path.write_bytes(records.encoded(values))
    files = [p.relative_to(root).as_posix() for p in (judgment_path, values_path)]
    saved = records.publish(root, kind="judgment", title=f"LLM judge for {hypothesis_id}", files=files,
                            depends_on=[args["formula_ref"]], check_read=read)
    return {"summary": summary, "values": values,
            "values_selection": {"record_ref": saved["record_path"], "source_path": files[1]},
            "record": records.present(root, saved)}


def execute(args, ctx):
    abort = _abort_event(ctx)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_judge", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=abort)
    receipt = judge(ctx, args)
    return ToolResult(title="research_judge", output=json.dumps(receipt, ensure_ascii=False, indent=2,
                                                                allow_nan=False))
