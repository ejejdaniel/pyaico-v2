"""Computational knowledge for tool-less model calls.

Sub-calls such as mind-map stages and reviews cannot run tools, and a model asked to
remember to check something often does not. Providers here compute plain facts from
the selected sources automatically: what a written structure is, what a table holds,
where prose and a table disagree. Redundant facts are acceptable; wrong ones are not,
so each provider reports only what it can determine unambiguously.

A provider takes the selected sources (dicts with `source_path` and `text`) and
returns lines. The block is capped in length so it never crowds out the sources.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from researchkit.knowledge import chemistry, numbers, tables

DEFAULT_CAP = 12000


@dataclass(frozen=True)
class Provider:
    name: str
    heading: str
    run: Callable[[list[dict]], list[str]]


PROVIDERS = (
    Provider("chemistry", "Structures written as SMILES (RDKit): what each given structure is, not its "
             "properties or reactivity", chemistry.facts),
    Provider("tables", "Selected tables (CSV/TSV): size, columns, per-row values and what varies between rows",
             tables.facts),
    Provider("numbers", "Numbers in prose that nearly but not exactly match a table value in the same column "
             "(possible source inconsistencies; decide which source is authoritative)", numbers.facts),
)


def facts_block(sources, *, cap=DEFAULT_CAP, providers=PROVIDERS) -> str:
    """Facts from every provider that finds something, as one block of at most `cap` characters."""
    sections, used, omitted = [], 0, 0
    for provider in providers:
        try:
            lines = provider.run(list(sources))
        except Exception as error:  # A provider failure must not stop the model call.
            lines = [f"(provider failed and reported nothing: {type(error).__name__})"]
        if not lines:
            continue
        heading = f"[{provider.name}] {provider.heading}:"
        kept = []
        for line in lines:
            if used + len(heading) + len(line) + 2 > cap:
                omitted += 1
                continue
            kept.append(line)
            used += len(line) + 1
        if kept:
            used += len(heading) + 1
            sections.append("\n".join([heading, *kept]))
    if not sections:
        return ""
    note = (f"\n({omitted} further fact lines omitted by the {cap}-character cap.)" if omitted else "")
    return ("Host-computed facts (calculated by the host from the selected sources, not a selected file and "
            "not citable source lines). Where your description differs from these facts, the facts win:\n"
            + "\n\n".join(sections) + note)
