"""Facts the host can compute from structures written in the selected sources.

Mind-map stages have no tools, so they describe structures from memory and can get
them wrong (ring sizes, which carbon an ester is attached to). When the sources give
SMILES, RDKit states the plain facts of each structure: formula, element counts,
rings, functional groups and the ester alkyl side. These are facts about the given
structures only, not properties, reactivities or mechanisms.
"""

from __future__ import annotations

import re

_CANDIDATE = re.compile(r"[A-Za-z0-9@+\-\[\]()=#$/\\%.*:]{5,}")
_STRUCTURE_HINT = re.compile(r"[()=\[\]#]|[a-z]\d|\d[a-zA-Z]")
_LABEL = re.compile(r"([A-Za-z][A-Za-z0-9_\-]{0,30})\s*[:：=|]\s*`?\s*$")
MAX_STRUCTURES = 40

# Functional groups named in plain chemical terms; counts are of matches in the given structure.
_GROUPS = (
    ("ester", "[CX3](=O)[OX2][#6]"),
    ("carboxylate or carboxylic acid", "[CX3](=O)[OX1-,OX2H1]"),
    ("sulfonate", "[SX4](=O)(=O)[OX1-,OX2]"),
    ("sulfonium", "[SX3+]"),
    ("iodonium", "[IX2+]"),
    ("phenol", "c[OX2H1]"),
    ("acrylate or methacrylate unit", "[CX4,CX3]~[CX4,CX3]([CH3,H])C(=O)O"),
    ("CF2 or CF3", "[CX4](F)(F)"),
    ("ether", "[OD2]([#6;!$(C=O);!$(S=O)])[#6;!$(C=O);!$(S=O)]"),
    ("amine", "[NX3;!$(N-C=O);!$(N-S=O)]"),
    ("amide", "C(=O)N"),
)


def _rdkit():
    try:
        from rdkit import Chem, RDLogger
        from rdkit.Chem import rdMolDescriptors
    except ImportError:
        return None
    RDLogger.DisableLog("rdApp.*")
    return Chem, rdMolDescriptors


def find_structures(texts):
    """[(label, smiles)] for SMILES-like tokens that RDKit parses, first occurrence of each structure."""
    kit = _rdkit()
    if kit is None:
        return []
    Chem, _ = kit
    found, seen = [], set()
    for text in texts:
        for line in text.splitlines():
            for match in _CANDIDATE.finditer(line):
                token = match.group().strip("`.,;:")
                if len(token) < 5 or not _STRUCTURE_HINT.search(token) or not re.search(r"[CNOcnos]", token):
                    continue
                mol = Chem.MolFromSmiles(token)
                if mol is None or mol.GetNumHeavyAtoms() < 3:
                    continue
                key = Chem.MolToSmiles(mol)
                if key in seen:
                    continue
                seen.add(key)
                label = _LABEL.search(line[:match.start()])
                found.append((label.group(1) if label else "", token))
                if len(found) >= MAX_STRUCTURES:
                    return found
    return found


def _ester_sides(mol):
    """Describe the carbon on the alkoxy side of each ester: degree, ring size, benzylic."""
    from rdkit import Chem

    pattern = Chem.MolFromSmarts("[CX3](=O)[OX2][CX4]")
    aryl = Chem.MolFromSmarts("[CX3](=O)[OX2]c")
    sides = ["aryl ester (oxygen bonded to an aromatic ring)"] * len(mol.GetSubstructMatches(aryl))
    ring_info = mol.GetRingInfo()
    for _, _, _, carbon_index in mol.GetSubstructMatches(pattern):
        carbon = mol.GetAtomWithIdx(carbon_index)
        carbons = sum(1 for n in carbon.GetNeighbors() if n.GetSymbol() == "C")
        degree = {1: "primary", 2: "secondary", 3: "tertiary"}.get(carbons, "methyl" if carbons == 0 else "quaternary")
        rings = [len(ring) for ring in ring_info.AtomRings() if carbon_index in ring]
        benzylic = any(n.GetIsAromatic() for n in carbon.GetNeighbors())
        text = f"{degree} carbon"
        if rings:
            text += f" in a {min(rings)}-membered ring"
        if benzylic:
            text += ", benzylic (bonded to an aromatic ring)"
        sides.append(text)
    return sides


def describe(smiles):
    kit = _rdkit()
    if kit is None:
        return None
    Chem, descriptors = kit
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    elements = {}
    for atom in mol.GetAtoms():
        if atom.GetSymbol() != "*":
            elements[atom.GetSymbol()] = elements.get(atom.GetSymbol(), 0) + 1
    rings = []
    for ring in mol.GetRingInfo().AtomRings():
        aromatic = all(mol.GetAtomWithIdx(index).GetIsAromatic() for index in ring)
        rings.append(f"{len(ring)}-membered {'aromatic' if aromatic else 'aliphatic'}")
    groups = []
    for name, smarts in _GROUPS:
        count = len(mol.GetSubstructMatches(Chem.MolFromSmarts(smarts)))
        if count:
            groups.append(f"{name} ×{count}")
    attachment = sum(1 for atom in mol.GetAtoms() if atom.GetSymbol() == "*")
    parts = [f"formula {descriptors.CalcMolFormula(mol)}" + (f" (+{attachment} attachment points *)" if attachment else ""),
             "elements " + ", ".join(f"{symbol} {count}" for symbol, count in sorted(elements.items())),
             "rings " + (", ".join(rings) if rings else "none"),
             "groups " + (", ".join(groups) if groups else "none listed")]
    sides = _ester_sides(mol)
    if sides:
        parts.append("ester alkoxy side: " + "; ".join(sides))
    return "; ".join(parts)


def facts(sources):
    """One line per distinct structure written as SMILES in the sources (empty without RDKit)."""
    lines = []
    for label, smiles in find_structures([source["text"] for source in sources]):
        description = describe(smiles)
        if description:
            lines.append(f"- {label + ': ' if label else ''}`{smiles}` → {description}")
    return lines
