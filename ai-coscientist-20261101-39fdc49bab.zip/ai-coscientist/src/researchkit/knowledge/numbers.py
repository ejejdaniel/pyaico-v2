"""Numbers in prose that nearly, but not exactly, match a value in the same column of a selected table.

A different source stating 12.4 where the table has 12.1 for the same quantity is easy for
a reader to miss and matters when deciding which source is authoritative. Specifications
written with a comparison (`< 5`, `20 ± 2`) are requirements, not measurements, and are
skipped. Exact matches and far-off numbers are not reported.
"""

from __future__ import annotations

import re

from researchkit.knowledge.tables import number, read_table

NEAR = 0.10  # Relative difference counted as "nearly the same".
_NUMBER = re.compile(r"[-+]?\d+(?:\.\d+)?")
_COMPARISON = re.compile(r"[<>≤≥±]|\+-|-\+|target|目標|範圍|要求")


def _key(name):
    """Column name reduced to its leading word, e.g. 'yield_pct' -> 'yield'."""
    match = re.match(r"[A-Za-z][A-Za-z0-9]*", name.strip())
    return match.group().lower() if match and len(match.group()) >= 2 else None


def facts(sources):
    columns = {}  # key -> [(table path, column name, row label, value)]
    for source in sources:
        table = read_table(source)
        if table is None:
            continue
        header, body = table
        for index, name in enumerate(header[1:], start=1):
            key = _key(name)
            values = [(row[0].strip(), number(row[index])) for row in body]
            if key and all(value is not None for _, value in values):
                columns.setdefault(key, []).extend(
                    (source["source_path"], name, label, value) for label, value in values)
    if not columns:
        return []
    pattern = re.compile(r"\b(" + "|".join(re.escape(key) for key in columns) + r")\b", re.IGNORECASE)
    lines, seen = [], set()
    for source in sources:
        if read_table(source) is not None:
            continue
        for line_number, line in enumerate(source["text"].splitlines(), start=1):
            for match in pattern.finditer(line):
                after = line[match.end():match.end() + 24]
                found = _NUMBER.search(after)
                if not found or _COMPARISON.search(after[:found.start()]) or _COMPARISON.search(after[found.end():found.end() + 4]):
                    continue
                stated = float(found.group())
                entries = columns[match.group(1).lower()]
                if any(stated == value for *_, value in entries):
                    continue
                if not any(value and abs(stated - value) / abs(value) <= NEAR for *_, value in entries):
                    continue
                key = (source["source_path"], line_number, stated)
                if key in seen:
                    continue
                seen.add(key)
                # List the column's values rather than guessing which row the prose meant.
                path, name = entries[0][0], entries[0][1]
                values = "; ".join(f"{value:g} (row {label!r})" for _, _, label, value in entries[:8])
                lines.append(f"- {source['source_path']} line {line_number} states {match.group(1)} "
                             f"{found.group()}; no table value matches it exactly. {path} column {name}: {values}")
    return lines
