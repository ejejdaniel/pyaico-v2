"""Plain facts about selected CSV/TSV tables: size, columns, rows, and what varies between rows."""

from __future__ import annotations

import csv
import io
import math

MAX_ROWS_LISTED = 20


def read_table(source):
    """(header, rows) for a CSV or TSV source, or None when it is not one."""
    path = source["source_path"].lower()
    if not path.endswith((".csv", ".tsv")):
        return None
    text = source["text"].lstrip("﻿")
    rows = [row for row in csv.reader(io.StringIO(text), delimiter="\t" if path.endswith(".tsv") else ",")
            if any(cell.strip() for cell in row)]
    if len(rows) < 2:
        return None
    header, body = [cell.strip() for cell in rows[0]], rows[1:]
    if any(len(row) != len(header) for row in body):
        return None  # Ragged rows: do not guess a structure.
    return header, body


def number(cell):
    try:
        value = float(cell.strip())
    except ValueError:
        return None
    return value if math.isfinite(value) else None


def _numeric(column):
    values = [number(cell) for cell in column]
    return values if all(value is not None for value in values) else None


def facts(sources):
    lines = []
    for source in sources:
        table = read_table(source)
        if table is None:
            continue
        header, body = table
        path = source["source_path"]
        columns = list(zip(*body))
        lines.append(f"- {path}: {len(body)} rows × {len(header)} columns ({', '.join(header)})")
        labels = [row[0].strip() for row in body]
        duplicates = sorted({label for label in labels if labels.count(label) > 1})
        if duplicates:
            lines.append(f"  - repeated first-column labels (separate rows, not merged): {', '.join(duplicates)}")
        constant, varying = [], []
        for name, column in zip(header, columns):
            (constant if len({cell.strip() for cell in column}) == 1 else varying).append(name)
        if len(body) > 1:
            lines.append(f"  - columns that differ between rows: {', '.join(varying) or 'none'}")
            if constant:
                lines.append(f"  - columns identical in every row: "
                             + ", ".join(f"{name} = {columns[header.index(name)][0].strip()}" for name in constant))
        for name, column in zip(header, columns):
            values = _numeric(column)
            if values and len(body) > 1 and len(set(values)) > 1:
                lines.append(f"  - {name}: min {min(values):g}, max {max(values):g}, range {max(values) - min(values):g}")
        if len(body) <= MAX_ROWS_LISTED:
            for row in body:
                cells = "; ".join(f"{name} {cell.strip()}" for name, cell in zip(header[1:], row[1:]))
                lines.append(f"  - row {row[0].strip()!r}: {cells}")
    return lines
