"""Score one shared sample pool on several proxy formulas (sheets) and freeze the result.

Only ranks are compared, never raw values across sheets, and nothing is summed
or weighted into a total. Each sheet gets an evidence level the host derives:
history (the historical samples differ on it, so its order can be checked against
their measured KPI), mechanism_only (they all tie: the sheet ranks new designs by
mechanism alone) or llm_judge (values from a blinded research_judge record).
A surpass is robust only across two or more history sheets; a surpass that rests
on mechanism_only or llm_judge sheets is conditional on those hypotheses.
The host computes; the author judges what the result means scientifically.
"""

from __future__ import annotations

import itertools
import json
from pathlib import Path
import uuid

from jsonschema import Draft202012Validator

from opencode.provider import _check_abort
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records, term_model, values_table
from researchkit.report_evidence import _reference, resolve
from researchkit import anchoring
from researchkit import scoring
from researchkit.scoring import check_direction, orient


_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}
_SELECTION = values_table.SELECTION
_IDS = {"type": "array", "minItems": 1, "uniqueItems": True, "items": dict(_TEXT)}
INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "baseline_ids": _IDS,
        "candidate_ids": _IDS,
        "primary_formula_ref": dict(_TEXT),
        "sheets": {"type": "array", "minItems": 1, "maxItems": 12, "items": {
            "type": "object", "properties": {"formula_ref": dict(_TEXT), "values": _SELECTION},
            "required": ["formula_ref", "values"], "additionalProperties": False}},
    },
    "required": ["baseline_ids", "candidate_ids", "sheets"],
    "additionalProperties": False,
}
FRONT_TOO_LARGE = 0.8
SURPASS = ("robust_surpass", "surpass_one_sheet", "tradeoff_surpass")
EVIDENCE = ("history", "history_fitted", "history_reversed", "mechanism_only", "llm_judge")


def _rank(oriented: dict) -> dict:
    """1 is best; tied values share their average rank."""
    ordered = sorted(oriented, key=lambda sample: -oriented[sample])
    ranks, index = {}, 0
    while index < len(ordered):
        end = index
        while end + 1 < len(ordered) and oriented[ordered[end + 1]] == oriented[ordered[index]]:
            end += 1
        for sample in ordered[index:end + 1]:
            ranks[sample] = (index + end) / 2 + 1
        index = end + 1
    return ranks


def _tau_b(left: dict, right: dict) -> float | None:
    concordant = discordant = left_ties = right_ties = 0
    for a, b in itertools.combinations(sorted(left), 2):
        x, y = left[a] - left[b], right[a] - right[b]
        if x == 0 and y == 0:
            continue
        if x == 0:
            left_ties += 1
        elif y == 0:
            right_ties += 1
        elif (x > 0) == (y > 0):
            concordant += 1
        else:
            discordant += 1
    denominator = ((concordant + discordant + left_ties) * (concordant + discordant + right_ties)) ** 0.5
    return None if denominator == 0 else (concordant - discordant) / denominator


def fitted_samples(template):
    """Historical samples a formula was made to agree with: fitted_on, and the samples on which the history
    contradicted its hypotheses before it was saved (see revised_after_reversal)."""
    return set(template.get("fitted_on") or []) | {
        sample for item in template.get("revised_after") or [] for sample in item["samples"]}


def fitted_history(sheet, baseline_ids):
    """Whether every historical sample the sheet's history agreement rests on was used to make the formula."""
    fitted = fitted_samples(sheet)
    compared = (sheet.get("history_order") or {}).get("compared_samples") or list(baseline_ids)
    return bool(fitted) and set(compared) <= fitted


def _saved_at(root, ref):
    try:
        return (Path(root) / ref).stat().st_mtime_ns
    except OSError:
        return None


def revised_after_reversal(root, formula_ref, template, read):
    """Earlier history checks that found the history contradicting this formula's hypotheses.

    v30 flipped P3's and P4's directions after research_history_check found them reversed on its
    two samples; the next check agreed, and the leaderboard counted the flip as history evidence.
    A formula saved after such a check (a later version of the formula, or another formula for
    the same hypotheses) was written knowing how those samples came out, so agreeing with them is
    fitted, not tested. [{"history_check", "formula_ref", "formula_id", "samples"}], oldest first.
    """
    mine = _saved_at(root, formula_ref)
    folder = Path(root) / ".research" / "records"
    if mine is None or not folder.is_dir():
        return []
    own, name = set(template["hypothesis_ids"]), template["formula_id"]
    checks = []
    for path in folder.glob("*/record.json"):
        when, ref = path.stat().st_mtime_ns, path.relative_to(root).as_posix()
        if when < mine and not path.parent.name.startswith(".staging-"):
            checks.append((when, ref))
    found = []
    for _, ref in sorted(checks):
        record = records.read_record(root, ref, check_read=read)
        files = [item["source_path"] for item in record["files"] if Path(item["source_path"]).name == "history_check.json"]
        if record["kind"] != "history_check" or len(files) != 1:
            continue
        frozen, = resolve(root, [{"record_ref": ref, "source_path": files[0]}], check_read=read)
        try:
            sheets = json.loads(frozen["text"]).get("sheets") or []
        except (ValueError, AttributeError):
            continue
        for sheet in sheets:
            if not isinstance(sheet, dict) or sheet.get("formula_ref") == formula_ref \
                    or "order_reversed" not in (sheet.get("flags") or []):
                continue
            theirs = set(sheet.get("hypothesis_ids") or [])
            if (name and sheet.get("formula_id") == name) or (theirs and theirs <= own):
                found.append({"history_check": ref, "formula_ref": sheet["formula_ref"],
                              "formula_id": sheet.get("formula_id"),
                              "samples": list((sheet.get("history_order") or {}).get("compared_samples") or [])})
    return found


def _model_result(sheet, baseline_ids, candidate_ids, primary):
    """A quantitative model's sheet: relations that hold under every coefficient set the history allows."""
    model, samples = sheet["model"], [*baseline_ids, *candidate_ids]

    def relation(a, b):
        return term_model.relation(model, a, b)

    beaten = {s: [o for o in samples if o != s and relation(o, s) == "better"] for s in samples}
    best_baselines = [b for b in baseline_ids if not any(o in baseline_ids for o in beaten[b])]
    status = {}
    for c in candidate_ids:
        if any(o in baseline_ids for o in beaten[c]):
            status[c] = "worse"
        elif all(relation(c, b) == "better" for b in best_baselines):
            status[c] = "better"
        elif all(relation(c, b) == "tie" for b in best_baselines):
            status[c] = "tie"
        else:
            status[c] = "undecided"
    return {
        "formula_ref": sheet["formula_ref"], "formula_id": sheet["formula_id"],
        "hypothesis_ids": sheet["hypothesis_ids"], "direction": sheet["direction"],
        **({"target_value": sheet["target_value"]} if sheet["direction"] == "target" else {}),
        **({"tolerance": sheet["tolerance"]} if sheet.get("tolerance") is not None else {}),
        "evidence": "history_fitted", "primary": sheet["formula_ref"] == primary,
        "ranks": {s: 1 + len(beaten[s]) for s in samples}, "best_baselines": best_baselines,
        "candidate_status": status, "tied_best_candidates": [],
        "possibly_best": [s for s in samples if not beaten[s]],
        "outside_baseline_range": model["extrapolated"],
        "model": {key: model[key] for key in ("coefficients", "coefficient_text", "pinned_zero", "ranges", "band",
                                                "band_tolerance", "next_measurements", "beats", "ties")
                  if key in model},
        **{key: sheet[key] for key in ("fitted_on", "revised_after", "mechanism_predicts", "correction", "terms")
           if sheet.get(key)},
    }


def compute(sheets: list[dict], baseline_ids: list[str], candidate_ids: list[str], primary: str | None = None) -> dict:
    """sheets: [{formula_ref, formula_id, hypothesis_ids, direction, values: {id: float}, evidence?}], or a
    quantitative model's sheet with "model" (term_model.sheet) in place of values."""
    samples = [*baseline_ids, *candidate_ids]
    oriented = {sheet["formula_ref"]: {s: orient(sheet["values"][s], sheet["direction"], sheet.get("target_value"))
                                       for s in samples} for sheet in sheets if "model" not in sheet}

    def relation(sheet, a, b):
        if "model" in sheet:
            return term_model.relation(sheet["model"], a, b)
        values = oriented[sheet["formula_ref"]]
        return "better" if values[a] > values[b] else "worse" if values[a] < values[b] else "tie"

    results = []
    for sheet in sheets:
        if "model" in sheet:
            results.append(_model_result(sheet, baseline_ids, candidate_ids, primary))
            continue
        values = oriented[sheet["formula_ref"]]
        ranks = _rank(values)
        best_value = max(values[s] for s in baseline_ids)
        best_baselines = [s for s in baseline_ids if values[s] == best_value]
        status = {s: "better" if values[s] > best_value else "tie" if values[s] == best_value else "worse"
                  for s in candidate_ids}
        low, high = min(values[s] for s in baseline_ids), max(values[s] for s in baseline_ids)
        top = max(values[s] for s in candidate_ids)
        # A sheet that orders the historical samples against the measured KPI is not history evidence, and
        # neither is one whose constants were set from those samples (v23 took two slopes from its two rows).
        reversed_history = bool((sheet.get("history_order") or {}).get("reversed"))
        evidence = sheet.get("evidence") if sheet.get("evidence") == "llm_judge" else (
            "mechanism_only" if not high > low else "history_reversed" if reversed_history
            else "history_fitted" if fitted_history(sheet, baseline_ids) else "history")
        results.append({
            "formula_ref": sheet["formula_ref"], "formula_id": sheet["formula_id"],
            "hypothesis_ids": sheet["hypothesis_ids"], "direction": sheet["direction"],
            **({"target_value": sheet["target_value"]} if sheet["direction"] == "target" else {}),
            "evidence": evidence, "primary": sheet["formula_ref"] == primary,
            "values": {s: sheet["values"][s] for s in samples}, "ranks": ranks,
            "best_baselines": best_baselines, "candidate_status": status,
            "tied_best_candidates": [s for s in candidate_ids if values[s] == top] if
            sum(1 for s in candidate_ids if values[s] == top) > 1 else [],
            "outside_baseline_range": [s for s in candidate_ids if not low <= values[s] <= high],
            **{key: sheet[key] for key in ("scale_check", "raw_values", "history_order") if key in sheet},
            **{key: sheet[key] for key in ("fitted_on", "revised_after", "mechanism_predicts", "confounded_with",
                                           "correction", "terms") if sheet.get(key)},
        })
    dominated_by = {s: [] for s in samples}
    for a, b in itertools.permutations(samples, 2):
        found = [relation(sheet, a, b) for sheet in sheets]
        if all(r in ("better", "tie") for r in found) and "better" in found:
            dominated_by[b].append(a)
    front = [s for s in samples if not dominated_by[s]]
    history = [r for r in results if r["evidence"] == "history"]
    margins = {}
    for r in results:
        if "model" in r:
            for s in candidate_ids:
                margins.setdefault(s, {})[r["formula_id"] or r["formula_ref"]] = {"better_by": None,
                                                                                 "of_pool_range": None}
            continue
        values = oriented[r["formula_ref"]]
        best, spread = max(values[b] for b in baseline_ids), max(values.values()) - min(values.values())
        for s in candidate_ids:
            gap = values[s] - best
            margins.setdefault(s, {})[r["formula_id"] or r["formula_ref"]] = {
                "better_by": gap, "of_pool_range": gap / spread if spread else None}
    candidates = []
    for s in candidate_ids:
        statuses = {r["formula_ref"]: r["candidate_status"][s] for r in results}
        worse = [r["formula_id"] or r["formula_ref"] for r in results if r["candidate_status"][s] == "worse"]
        better_history = [r for r in history if r["candidate_status"][s] == "better"]
        # A sure loss on a quantitative model's sheet holds under every coefficient set the history allows, so
        # it weighs against a surpass as a history sheet does (v38's C2 overshot 40 by far, yet ranked a surpass
        # on a lower-is-better index).
        worse_history = [r for r in results if (r["evidence"] == "history" or "model" in r)
                         and r["candidate_status"][s] == "worse"]
        conditional = [{"sheet": r["formula_id"] or r["formula_ref"], "hypothesis_ids": r["hypothesis_ids"],
                        "evidence": r["evidence"]}
                       for r in results if r["evidence"] != "history" and r["candidate_status"][s] == "better"]
        beaten = [d for d in dominated_by[s] if d in baseline_ids]
        if better_history and worse_history:
            verdict = "tradeoff_surpass"
        elif better_history and len(history) >= 2 and not beaten:
            verdict = "robust_surpass"
        elif better_history and not beaten:
            verdict = "surpass_one_sheet"
        elif better_history:
            verdict = "tradeoff_surpass"
        elif conditional:
            verdict = "conditional_surpass"
        else:
            verdict = "no_surpass"
        ranks = [r["ranks"][s] for r in results]
        candidates.append({"id": s, "verdict": verdict, "statuses": statuses, "worse_on": worse,
                           "better_on_history": [r["formula_id"] or r["formula_ref"] for r in better_history],
                           "conditional_on": conditional,
                           "on_front": s in front, "dominated_by": dominated_by[s],
                           "dominated_by_history": [d for d in dominated_by[s] if d in baseline_ids],
                           "mean_rank": sum(ranks) / len(ranks), "rank_spread": max(ranks) - min(ranks),
                           "margins": margins[s]})
    candidates.sort(key=lambda row: (row["mean_rank"], row["id"]))
    agreement = [{"sheets": [a["formula_id"] or a["formula_ref"], b["formula_id"] or b["formula_ref"]],
                  "kendall_tau_b": _tau_b(oriented[a["formula_ref"]], oriented[b["formula_ref"]])
                  if a["formula_ref"] in oriented and b["formula_ref"] in oriented else None}
                 for a, b in itertools.combinations(results, 2)]
    return {
        "primary_formula_ref": primary, "baseline_ids": list(baseline_ids), "candidate_ids": list(candidate_ids),
        "history_sheets": [r["formula_id"] or r["formula_ref"] for r in history],
        "sheets": results, "candidates": candidates,
        "pareto_front": front, "front_ratio": len(front) / len(samples),
        "front_too_large": len(sheets) > 1 and len(front) / len(samples) >= FRONT_TOO_LARGE,
        "sheet_agreement": agreement,
        "all_sheets_agree": len(sheets) > 1 and all(row["kendall_tau_b"] == 1 for row in agreement),
        "most_disputed": [row["id"] for row in sorted(candidates, key=lambda r: -r["rank_spread"])
                          if row["rank_spread"] > 0][:3],
        "note": "Ranks only; mean_rank orders the display with equal sheet weights and is not a score. "
                "verdict: robust_surpass = better than the best historical sample on at least one of two or more "
                "history sheets and worse on none; surpass_one_sheet = only one history sheet can judge it; "
                "tradeoff_surpass = better on one history sheet, worse on another or surely worse on a quantitative "
                "model's sheet (or beaten by a historical sample overall); conditional_surpass = better only on mechanism_only, history_fitted, "
                "history_reversed or llm_judge sheets, so it "
                "holds only if those hypotheses do (see conditional_on). history_reversed: the formula prefers "
                "the historical samples in the opposite order to the measured KPI it ranks (see history_order), "
                "so its sheet is not history evidence. history_fitted: the formula's constants were set from the "
                "historical samples it is compared on (fitted_on), or it was saved after a history check found the "
                "history ordered against the KPI by a formula of its hypothesis (revised_after), so agreeing with them is not evidence either. "
                "A large Pareto front means the choice "
                "depends on which hypothesis is right: pick what to measure with calc kind=design. "
                "margins: how far each candidate is ahead of (positive) or behind the best historical sample on "
                "each sheet, also as a fraction of that sheet's range over the pool; check a small margin against "
                "your error with calc kind=sensitivity. "
                "A quantitative model's sheet (terms) has no values: its coefficients are every set that "
                "reproduces the history with the signs its mechanisms give, so better and worse hold under all of "
                "them, and a pair they disagree on is undecided (candidate_status undecided). possibly_best lists "
                "the samples no other sample surely beats; model.band says whether each prediction is surely or "
                "possibly within the target's tolerance (model.band_tolerance; 0 when none is declared, so the band "
                "is the target value itself); model.next_measurements names candidates whose "
                "measurement would set an undetermined coefficient. Its evidence is history_fitted.",
    }


def not_a_formula(ref, kind):
    """A run (2026-11-01) passed its implementation record as a formula and was told only what it was not."""
    return (f"{ref} is a kind={kind} record, not a kind=proxy_formula record: a formula_ref names the record "
            "research_record saved for one formula (kind proxy_formula, its template stored as proxy_formula.json). "
            "Save each formula that way first; its implementation and values are records of their own")


def _template(root, ref, read):
    record = records.read_record(root, ref, check_read=read)
    if record["kind"] != "proxy_formula":
        raise ValueError(not_a_formula(ref, record["kind"]))
    files = [item for item in record["files"] if Path(item["source_path"]).name == "proxy_formula.json"]
    if len(files) != 1:
        raise ValueError(f"{ref} must contain exactly one proxy_formula.json declaring its direction")
    frozen, = resolve(root, [{"record_ref": ref, "source_path": files[0]["source_path"]}], check_read=read)
    value = json.loads(frozen["text"])
    if not isinstance(value, dict):
        raise ValueError(f"{ref}: proxy_formula.json must be an object declaring its direction")
    try:
        check_direction(value.get("direction"), value.get("target_value"))
    except ValueError as error:
        raise ValueError(f"{ref}: proxy_formula.json: {error}") from None
    ids = value.get("hypothesis_ids") if isinstance(value.get("hypothesis_ids"), list) else []
    measured = value.get("measured")
    if measured is not None:
        try:
            Draft202012Validator(_SELECTION).validate(measured)
        except Exception:
            raise ValueError(f"{ref}: proxy_formula.json measured must be {{record_ref, source_path, column?}} "
                             "selecting the measured values this formula predicts") from None
    try:
        mode, _ = anchoring.anchor_mode(value.get("anchor"))
    except ValueError as error:
        raise ValueError(f"{ref}: proxy_formula.json: {error}") from None
    if mode != "none" and (value["direction"] != "target" or measured is None):
        raise ValueError(f"{ref}: proxy_formula.json: anchor needs direction target and a measured selection")
    kpi = value.get("kpi")
    if kpi is not None and scoring.check_kpi(kpi):
        raise ValueError(f"{ref}: proxy_formula.json: " + "; ".join(scoring.check_kpi(kpi)))
    return {"formula_id": value.get("formula_id") if isinstance(value.get("formula_id"), str) else None,
            "hypothesis_ids": [item for item in ids if isinstance(item, str)], "direction": value["direction"],
            **({"target_value": value["target_value"]} if value["direction"] == "target" else {}),
            "measured": measured, "anchor": value.get("anchor"), "kpi": kpi,
            "fitted_on": [item for item in value.get("fitted_on") or [] if isinstance(item, str)],
            **({"mechanism_predicts": value["mechanism_predicts"]}
               if value.get("mechanism_predicts") in scoring.MECHANISM else {}),
            **{key: value[key] for key in ("correction", "terms", "noise", "tolerance") if value.get(key)},
            **({"offset": value["offset"]} if isinstance(value.get("offset"), bool) else {})}


def _selected_numbers(root, selection, read, label):
    """Numeric {sample: value} map from one frozen file, optionally one column of a values table."""
    return values_table.read(root, selection, read, label)[0]


def declaration(root, ref, read):
    """The proxy_formula.json declaration of a formula record, or None when the record has none."""
    record = records.read_record(root, ref, check_read=read)
    if record["kind"] != "proxy_formula" or not any(
            Path(item["source_path"]).name == "proxy_formula.json" for item in record["files"]):
        return None
    return _template(root, ref, read)


def apply_declaration(root, template, raw, baseline_ids, candidate_ids, read):
    """(ranking values, details, extra dependencies) for one formula's raw values.

    A formula that declares the measured quantity it predicts gets its scale checked, and is
    anchored when it declares an anchor; its order on the historical samples is checked against
    the measured KPI, on the anchored predictions when it is anchored (anchoring.shifted).
    research_leaderboard and research_compare_candidates both rank through this, so the same file
    ranks the same way in both.
    """
    details, dependencies = {}, []
    values, ordered, measured_values = raw, raw, None
    measured = template.get("measured")
    if measured is not None:
        _reference(measured["record_ref"])
        measured_values = values_table.require_samples(_selected_numbers(root, measured, read, "measured"),
                                                       baseline_ids, measured, "measured", template.get("formula_id"))
        values, check = anchoring.apply(raw, measured_values, baseline_ids, candidate_ids, template.get("anchor"))
        details["scale_check"] = check
        if check["anchored"]:
            details["raw_values"] = {s: raw[s] for s in [*baseline_ids, *candidate_ids]}
            ordered = anchoring.shifted(raw, check)
        dependencies.append(measured["record_ref"])
    order, kpi_ref = history_order(root, template, ordered, baseline_ids, read, measured_values)
    if order is not None:
        details["history_order"] = order
    if kpi_ref:
        dependencies.append(kpi_ref)
    return values, details, dependencies


def history_order(root, template, predicted, baseline_ids, read, measured_values=None):
    """(order of the formula on the historical samples against the measured KPI, kpi record or None).

    A declared kpi names the KPI and which of its values are better; a formula that predicts a
    measured quantity is compared with that quantity directly. (None, None) when neither is declared.
    """
    history = {sample: predicted[sample] for sample in baseline_ids if sample in predicted}
    kpi = template.get("kpi")
    if kpi is not None:
        _reference(kpi["record_ref"])
        selection = {key: kpi[key] for key in ("record_ref", "source_path", "column") if key in kpi}
        values = values_table.require_samples(_selected_numbers(root, selection, read, "kpi"), baseline_ids,
                                              selection, "kpi", template.get("formula_id"))
        return (scoring.kpi_order(history, values, template["direction"], template.get("target_value"),
                                  kpi["better"], kpi.get("target_value")), kpi["record_ref"])
    if measured_values is not None:
        return scoring.kpi_order(history, measured_values, "higher", None, "higher"), None
    return None, None


def sheet_inputs(root, sheet, read, samples=()):
    """(formula template, values, kind of the values record) for one sheet, checked.

    values is {sample: value}, or {sample: {quantity: value}} for a model with terms (term_model),
    read for the given samples.
    """
    _reference(sheet["formula_ref"])
    _reference(sheet["values"]["record_ref"])
    template = _template(root, sheet["formula_ref"], read)
    values_ref = sheet["values"]["record_ref"]
    closure = records._read_dependencies(root, [values_ref], check_read=read)
    values_kind = closure[values_ref]["kind"]
    if values_kind not in (*values_table.VALUE_KINDS, "judgment"):
        raise ValueError(f"Each values.record_ref must select a kind=implementation or kind=simulation record, or "
                         f"the kind=judgment record research_judge saved; {values_ref} is kind={values_kind}. "
                         + values_table.SAVE_ORDER)
    ancestors = {records.local_path(root, ref).relative_to(root).as_posix()
                 for record in closure.values() for ref in record["depends_on"]}
    if sheet["formula_ref"] not in ancestors:
        raise values_table.dependency_error(root, sheet["formula_ref"], values_ref, read,
                                            f"The values record {values_ref}")
    revised = revised_after_reversal(root, sheet["formula_ref"], template, read)
    if revised:
        template = {**template, "revised_after": revised}
    if term_model.is_model(template):
        owner = template["formula_id"] or sheet["formula_ref"]
        return (template, term_model.read_quantities(root, template, sheet["values"], samples, read, owner),
                values_kind)
    return template, _selected_numbers(root, sheet["values"], read, "values"), values_kind


def _check_coverage(root, refs, read):
    """Refuse sheets that leave out an active hypothesis (see one_to_one)."""
    from researchkit import board, one_to_one
    if not (root / ".research" / "records").is_dir():
        return
    one_to_one.check_leaderboard(board.build(root, check_read=read), refs)


def run(args, root: Path, folder: Path, *, check_read=None, abort=None):
    Draft202012Validator(INPUT_SCHEMA).validate(args)
    # Every sheet's problems at once: a run (2026-11-01) was refused fourteen times, each refusal naming one
    # problem (a missing hypothesis sheet, a formula on two sheets, a missing column, a stale dependency).
    problems = []
    if set(args["baseline_ids"]) & set(args["candidate_ids"]):
        problems.append("baseline_ids and candidate_ids must not overlap")
    refs = [sheet["formula_ref"] for sheet in args["sheets"]]
    if len(set(refs)) != len(refs):
        problems.append("Each formula_ref may appear in only one sheet. Each sheet is one hypothesis's formula: "
                        "save every formula as its own kind=proxy_formula record with its own proxy_formula.json "
                        "(formula_id, hypothesis_ids, direction). One implementation record may depend on several "
                        "formula records, and one values file may hold a column per formula (select it with "
                        "values.column).")
    primary = args.get("primary_formula_ref")
    if primary is not None and primary not in refs:
        problems.append("primary_formula_ref, when given, must be one of the sheets")
    root = root.resolve()
    folder = records.local_path(root, str(folder))

    def read(path):
        _check_abort(abort)
        if check_read:
            check_read(path)

    def check(fn, *values):
        try:
            return True, fn(*values)
        except ValueError as error:
            problems.append(str(error))
            return False, None

    if all([check(_reference, ref)[0] for ref in dict.fromkeys(refs)]):
        check(_check_coverage, root, refs, read)
    sheets, dependencies, labeled, plain = [], [], [], []
    samples = [*args["baseline_ids"], *args["candidate_ids"]]
    for sheet in args["sheets"]:
        loaded, inputs = check(sheet_inputs, root, sheet, read, samples)
        if not loaded:
            continue
        template, values, values_kind = inputs
        values_ref = sheet["values"]["record_ref"]
        public = {key: value for key, value in template.items() if key not in ("measured", "anchor", "kpi")}
        if term_model.is_model(template):
            owner = template["formula_id"] or sheet["formula_ref"]
            loaded, measured = check(term_model.read_measured, root, template, args["baseline_ids"], read, owner)
            if not loaded:
                continue
            loaded, model = check(term_model.sheet, template, values, measured, args["baseline_ids"],
                                  args["candidate_ids"], owner)
            if loaded:
                sheets.append({"formula_ref": sheet["formula_ref"], **public, "model": model})
                dependencies += [sheet["formula_ref"], values_ref, template["measured"]["record_ref"]]
            continue
        missing = [s for s in [*args["baseline_ids"], *args["candidate_ids"]] if s not in values]
        if missing:
            history = [s for s in missing if s in args["baseline_ids"]]
            problems.append(f"Sheet {sheet['formula_ref']} has no values for: {missing}. Each sheet's values must "
                            "cover every baseline_id and candidate_id"
                            + (": the historical samples belong in the same values table as the candidates, one "
                               "row per sample with a column per formula" if history else ""))
            continue
        labeled.append((f"{template['formula_id'] or 'sheet'} {sheet['formula_ref']}", values))
        raw = values
        loaded, declared = check(apply_declaration, root, template, values, args["baseline_ids"],
                                 args["candidate_ids"], read)
        if not loaded:
            continue
        values, details, extra = declared
        dependencies += extra
        sheets.append({"formula_ref": sheet["formula_ref"], **public, **details, "values": values,
                       **({"evidence": "llm_judge"} if values_kind == "judgment" else {})})
        plain.append((sheets[-1], raw))
        dependencies += [sheet["formula_ref"], values_ref]
    from researchkit import one_to_one
    from researchkit.history_check import confounding
    check(one_to_one.check_distinct, labeled, samples)
    if problems:
        from researchkit.calc_roles import all_problems
        raise ValueError(all_problems(problems))
    labels = [sheet["formula_id"] or sheet["formula_ref"] for sheet, _ in plain]
    others = confounding([(label, sheet["hypothesis_ids"], values)
                          for label, (sheet, values) in zip(labels, plain)], args["baseline_ids"])
    for label, (sheet, _) in zip(labels, plain):
        if others[label]:
            sheet["confounded_with"] = others[label]
    outcome = compute(sheets, args["baseline_ids"], args["candidate_ids"], primary)
    raw = records.encoded(outcome)
    _check_abort(abort)
    folder.mkdir(parents=True, exist_ok=False)
    destination = folder / "leaderboard.json"
    with destination.open("xb") as stream:
        stream.write(raw)
    source_path = destination.relative_to(root).as_posix()
    saved = records.publish(root, kind="leaderboard", title="Multi-sheet leaderboard", files=[source_path],
                            depends_on=list(dict.fromkeys(dependencies)), check_read=read)
    frozen, = resolve(root, [{"record_ref": saved["record_path"], "source_path": source_path}], check_read=read)
    if frozen["text"].encode("utf-8") != raw:
        raise RuntimeError("Published leaderboard bytes differ from the computed result")
    return {"result": json.loads(frozen["text"]), "record": records.present(root, saved)}


def execute(args, ctx):
    root = ctx.directory.resolve()
    abort = _abort_event(ctx)
    _check_abort(abort)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_leaderboard", patterns=["*"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={}, abort_event=abort)
    folder = records.local_path(root, f".research/leaderboards/{uuid.uuid4().hex}")
    ensure_access(ctx, folder, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    receipt = run(args, root, folder, check_read=lambda path: ensure_access(ctx, path, "read"), abort=abort)
    return ToolResult(title="research_leaderboard", output=_lines(summary(receipt)))


def _lines(value):
    """JSON with one field per line and one sheet or candidate per line: a third of the indented size."""
    def dumped(item):
        return json.dumps(item, ensure_ascii=False, allow_nan=False)
    parts = []
    for key, item in value.items():
        if isinstance(item, list) and item and all(isinstance(entry, dict) for entry in item):
            body = "[\n" + ",\n".join("  " + dumped(entry) for entry in item) + "\n]"
        else:
            body = dumped(item)
        parts.append(f"{dumped(key)}: {body}")
    return "{\n" + ",\n".join(parts) + "\n}"


CANDIDATE_ROWS = 30
SHEET_FIELDS = ("formula_ref", "formula_id", "hypothesis_ids", "mechanism_predicts", "direction", "target_value",
                "tolerance", "evidence", "fitted_on", "revised_after", "correction", "confounded_with",
                "primary", "best_baselines", "tied_best_candidates", "possibly_best", "outside_baseline_range",
                "scale_check", "history_order")
CANDIDATE_FIELDS = ("id", "verdict", "mean_rank", "rank_spread", "on_front", "worse_on", "better_on_history",
                    "conditional_on", "dominated_by_history")


def _model_summary(model):
    """What a quantitative model's sheet says, without its per-sample ranges and relations."""
    found = {"coefficients": model["coefficient_text"]}
    if model.get("band"):
        grouped = {}
        for sample, place in model["band"].items():
            grouped.setdefault(place, []).append(sample)
        found["band"] = grouped
        found["band_tolerance"] = model.get("band_tolerance")
    for key in ("next_measurements", "pinned_zero"):
        if model.get(key):
            found[key] = model[key]
    return found


def summary(receipt):
    """The verdicts the author reads now; per-sample values, ranks and margins stay in the saved file."""
    result, record = receipt["result"], receipt["record"]
    candidates = result["candidates"]
    value = {"record_path": record["record_path"], "leaderboard_json": record["files"][0]["snapshot"],
             "sheets": [{**{key: sheet[key] for key in SHEET_FIELDS if key in sheet},
                         **({"model": _model_summary(sheet["model"])} if "model" in sheet else {})}
                        for sheet in result["sheets"]],
             "candidates": [{key: row[key] for key in CANDIDATE_FIELDS} for row in candidates[:CANDIDATE_ROWS]]}
    if len(candidates) > CANDIDATE_ROWS:
        value["candidates_total"] = len(candidates)
    value.update({key: result[key] for key in ("pareto_front", "front_ratio", "front_too_large",
                                               "sheet_agreement", "all_sheets_agree", "most_disputed", "note")})
    value["detail"] = ("Per-sample values, ranks, statuses and margins are in leaderboard_json, the saved record "
                       "file (candidates are ordered by mean_rank); read or grep it, or load it in Python, when "
                       "you need them.")
    return value
