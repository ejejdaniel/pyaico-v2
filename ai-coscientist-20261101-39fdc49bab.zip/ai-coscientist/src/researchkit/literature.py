"""Public scholarly APIs. Search metadata is not a claim of reading full text."""

from __future__ import annotations

import html
import json
import os
import xml.etree.ElementTree as ET
import httpx


def search(query: str, provider: str, limit: int = 5) -> dict:
    if not isinstance(query, str) or not query.strip():
        raise ValueError("query must be nonblank")
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 10:
        raise ValueError("limit must be between 1 and 10")
    with httpx.Client(timeout=45, follow_redirects=True, headers={"User-Agent": "researchkit/0.1 (scholarly metadata research)"}) as client:
        if provider == "crossref":
            response = client.get("https://api.crossref.org/works", params={"query": query, "rows": limit})
            response.raise_for_status()
            raw = response.json()
            items = []
            for item in raw.get("message", {}).get("items", []):
                authors = [" ".join(filter(None, [a.get("given"), a.get("family")])) for a in item.get("author", [])]
                items.append({"title": (item.get("title") or [""])[0], "authors": authors,
                              "doi": item.get("DOI"), "url": item.get("URL"),
                              "published": item.get("published"), "abstract": item.get("abstract"),
                              "venue": item.get("container-title"), "publisher": item.get("publisher"),
                              "scope": "provider_metadata"})
        elif provider == "arxiv":
            response = client.get("https://export.arxiv.org/api/query", params={"search_query": query, "max_results": limit})
            response.raise_for_status()
            raw = response.text
            ns = {"a": "http://www.w3.org/2005/Atom"}
            root = ET.fromstring(raw)
            items = [{"title": e.findtext("a:title", "", ns).strip(), "url": e.findtext("a:id", "", ns),
                      "authors": [a.findtext("a:name", "", ns) for a in e.findall("a:author", ns)],
                      "published": e.findtext("a:published", "", ns),
                      "abstract": e.findtext("a:summary", "", ns).strip(), "scope": "abstract"}
                     for e in root.findall("a:entry", ns)]
        elif provider == "pubmed":
            base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
            response = client.get(base + "esearch.fcgi", params={"db": "pubmed", "term": query, "retmax": limit, "retmode": "json"})
            response.raise_for_status()
            raw = response.json()
            ids = raw.get("esearchresult", {}).get("idlist", [])
            items = []
            if ids:
                response = client.get(base + "efetch.fcgi", params={"db": "pubmed", "id": ",".join(ids), "retmode": "xml"})
                response.raise_for_status()
                raw = {"search": raw, "fetch": response.text}
                for article in ET.fromstring(response.text).findall(".//PubmedArticle"):
                    pmid = article.findtext(".//PMID", "")
                    title = article.find(".//ArticleTitle")
                    abstract = article.findall(".//AbstractText")
                    authors = [a.findtext("CollectiveName") or " ".join(filter(None, [
                        a.findtext("ForeName"), a.findtext("LastName")]))
                        for a in article.findall(".//AuthorList/Author")]
                    date = article.find(".//JournalIssue/PubDate")
                    items.append({"title": "".join(title.itertext()) if title is not None else "",
                                  "url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                                  "authors": authors,
                                  "published": " ".join(date.itertext()).strip() if date is not None else None,
                                  "venue": article.findtext(".//Journal/Title"),
                                  "doi": article.findtext(".//ArticleId[@IdType='doi']"),
                                  "abstract": "\n".join("".join(a.itertext()) for a in abstract), "scope": "abstract"})
        elif provider == "openalex":
            raw = _openalex(client, query, limit)
            items = [_openalex_item(work) for work in raw.get("results", [])]
        else:
            raise ValueError("provider must be crossref, arxiv, pubmed, or openalex")
    return {"query": query, "provider": provider, "items": items, "raw_response": raw}


OPENALEX_FIELDS = ("id,doi,display_name,publication_date,type,cited_by_count,authorships,primary_location,"
                   "open_access,best_oa_location,abstract_inverted_index")


def _openalex(client, query, limit):
    params = {"search": query, "per-page": limit, "select": OPENALEX_FIELDS}
    if os.environ.get("OPENALEX_API_KEY"):
        params["api_key"] = os.environ["OPENALEX_API_KEY"]
    if os.environ.get("OPENALEX_MAILTO"):
        params["mailto"] = os.environ["OPENALEX_MAILTO"]
    response = client.get("https://api.openalex.org/works", params=params)
    response.raise_for_status()
    raw = response.json()
    meta = raw.get("meta")
    if isinstance(meta, dict) and "notice" in meta:
        # The service's usage notice addresses AI agents with account instructions; it is not literature
        # and must not reach the model as content. The budget fields stay.
        raw = {**raw, "meta": {**{k: v for k, v in meta.items() if k != "notice"}, "notice_removed": True}}
    return raw


def _openalex_abstract(index):
    """OpenAlex stores abstracts as {word: [positions]}; rebuild the text."""
    if not isinstance(index, dict) or not index:
        return None
    words = {}
    for word, positions in index.items():
        for position in positions if isinstance(positions, list) else []:
            if isinstance(position, int):
                words[position] = word
    return " ".join(words[n] for n in sorted(words)) or None


def _openalex_item(work):
    location = work.get("primary_location") or {}
    best = work.get("best_oa_location") or {}
    access = work.get("open_access") or {}
    doi = work.get("doi")
    abstract = _openalex_abstract(work.get("abstract_inverted_index"))
    return {"title": work.get("display_name") or "",
            "authors": [((a.get("author") or {}).get("display_name")) for a in work.get("authorships") or []
                        if (a.get("author") or {}).get("display_name")],
            "doi": doi.removeprefix("https://doi.org/") if isinstance(doi, str) else None,
            "url": doi or work.get("id"), "openalex_id": work.get("id"),
            "published": work.get("publication_date"),
            "venue": (location.get("source") or {}).get("display_name"),
            "type": work.get("type"), "cited_by_count": work.get("cited_by_count"),
            "open_access": access.get("oa_status"),
            "oa_pdf": best.get("pdf_url"), "oa_landing_page": best.get("landing_page_url"),
            "abstract": abstract, "scope": "abstract" if abstract else "provider_metadata"}


def summary(result: dict, *, abstract_limit: int | None = None, authors_limit: int | None = None) -> str:
    lines = [f"Query: {result['query']}", f"Provider: {result['provider']}"]
    # Present all source identities before potentially long abstracts.
    lines.append("Bibliographic metadata from this provider; missing fields are unknown, not an invitation to guess.")
    for index, item in enumerate(result["items"], 1):
        lines.append(f"\n{index}. {item['title']}\n{item.get('url', '')}\nScope: {item['scope']}")
        for key in ("authors", "published", "doi", "venue", "publisher"):
            value = item.get(key)
            if key == "authors" and authors_limit and isinstance(value, list) and len(value) > authors_limit:
                value = [*value[:authors_limit], f"et al. ({len(value)} authors)"]
            lines.append(f"{key}: " + (json.dumps(value, ensure_ascii=False) if value else "not supplied"))
        # Fields only some providers give (OpenAlex): shown when present.
        for key in ("type", "cited_by_count", "open_access", "oa_pdf", "oa_landing_page"):
            if item.get(key) is not None:
                lines.append(f"{key}: {item[key]}")
        if item.get("oa_pdf") or item.get("oa_landing_page"):
            lines.append("A free legal copy is listed; read it with paper_fetch before citing its details.")
    for index, item in enumerate(result["items"], 1):
        if item.get("abstract"):
            text = html.unescape(item["abstract"])
            if abstract_limit is not None and len(text) > abstract_limit:
                text = text[:abstract_limit] + f"…（摘要共 {len(text)} 字，此處截斷；完整內容在保存的回應檔）"
            lines.append(f"\nAbstract for result {index}:\n" + text)
    if not result["items"]:
        lines.append("This query returned no entries; this does not establish that no literature exists.")
    return "\n".join(lines)
