"""Client for an external literature agent spoken to over A2A (Agent2Agent).

Transport: JSON-RPC 2.0 over HTTP (A2A 0.3): the agent card at
/.well-known/agent-card.json, then message/send, tasks/get and tasks/cancel.
The remote agent decomposes a natural-language question, searches its own
(possibly internal) literature and returns a synthesis with references.

Its answer is another agent's synthesis, not literature this session has read:
references are leads, and internal ones may not be fetchable here. The reply's
exact shape is not yet specified by the real agent, so parsing is lenient: text
parts form the synthesis; data parts may carry "references" and "sub_questions".
Align _parse_artifacts with the real agent card and examples when they exist.

Configuration: RESEARCH_LITERATURE_AGENT_URL (base URL) and optionally
RESEARCH_LITERATURE_AGENT_TOKEN (sent as a bearer token, never saved).
"""

from __future__ import annotations

import os
import time
import uuid

import httpx

from opencode import runtime_settings


CARD_PATHS = ("/.well-known/agent-card.json", "/.well-known/agent.json")
TERMINAL = {"completed", "failed", "canceled", "rejected"}
PAUSED = {"input-required", "auth-required"}
# How long one query may wait, and how often to ask about it: config/runtime.json, literature_agent.
DEFAULT_TIMEOUT_S = runtime_settings.get("literature_agent.timeout_s")
POLL_S = runtime_settings.get("literature_agent.poll_s")


class AgentError(RuntimeError):
    pass


def configured_url() -> str | None:
    url = os.environ.get("RESEARCH_LITERATURE_AGENT_URL", "").strip()
    return url.rstrip("/") or None


def _headers():
    token = os.environ.get("RESEARCH_LITERATURE_AGENT_TOKEN")
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return headers


class Client:
    def __init__(self, base_url: str, *, http: httpx.Client | None = None, poll_s: float | None = None):
        self.base_url = base_url.rstrip("/")
        self.http = http or httpx.Client(timeout=60, follow_redirects=True)
        self.poll_s = POLL_S if poll_s is None else poll_s
        self.exchanges = []  # every JSON-RPC request and response, for the saved record
        self._card = None

    def card(self) -> dict:
        if self._card is None:
            for path in CARD_PATHS:
                response = self.http.get(self.base_url + path, headers=_headers())
                if response.status_code == 200:
                    self._card = response.json()
                    break
            else:
                raise AgentError(f"No A2A agent card at {self.base_url} ({', '.join(CARD_PATHS)})")
        return self._card

    def _endpoint(self):
        return (self.card().get("url") or self.base_url).rstrip("/")

    def call(self, method: str, params: dict) -> dict:
        request = {"jsonrpc": "2.0", "id": uuid.uuid4().hex, "method": method, "params": params}
        response = self.http.post(self._endpoint(), json=request, headers=_headers())
        try:
            body = response.json()
        except ValueError:
            body = {"http_status": response.status_code, "text": response.text[:2000]}
        self.exchanges.append({"request": request, "response": body})
        if response.status_code >= 400 and "error" not in body:
            raise AgentError(f"{method}: HTTP {response.status_code}")
        if "error" in body:
            error = body["error"] or {}
            raise AgentError(f"{method}: A2A error {error.get('code')}: {error.get('message')}")
        return body.get("result") or {}

    def ask(self, query: str, *, context_id=None, task_id=None, timeout_s=DEFAULT_TIMEOUT_S) -> dict:
        message = {"kind": "message", "role": "user", "messageId": uuid.uuid4().hex,
                   "parts": [{"kind": "text", "text": query}]}
        if context_id:
            message["contextId"] = context_id
        if task_id:
            message["taskId"] = task_id
        result = self.call("message/send", {"message": message, "configuration": {
            "acceptedOutputModes": ["text/plain", "application/json"], "blocking": False}})
        if result.get("kind") == "message":  # answered directly, without a task
            return {"state": "completed", "task_id": None, "context_id": result.get("contextId"),
                    **_parse_parts(result.get("parts") or [])}
        deadline = time.monotonic() + timeout_s
        while _state(result) not in TERMINAL | PAUSED:
            if time.monotonic() > deadline:
                try:
                    self.call("tasks/cancel", {"id": result.get("id")})
                except AgentError:
                    pass
                raise AgentError(f"The literature agent did not finish within {timeout_s} s; the task was canceled")
            time.sleep(self.poll_s)
            result = self.call("tasks/get", {"id": result.get("id")})
        return _parse_task(result)


def _state(task):
    return ((task or {}).get("status") or {}).get("state")


def _status_text(task):
    message = ((task or {}).get("status") or {}).get("message") or {}
    return "\n".join(p.get("text", "") for p in message.get("parts") or [] if p.get("kind") == "text").strip()


def _parse_parts(parts):
    texts, references, sub_questions = [], [], []
    for part in parts:
        if part.get("kind") == "text" and part.get("text"):
            texts.append(part["text"])
        elif part.get("kind") == "data" and isinstance(part.get("data"), dict):
            data = part["data"]
            if isinstance(data.get("references"), list):
                references.extend(r for r in data["references"] if isinstance(r, dict))
            if isinstance(data.get("sub_questions"), list):
                sub_questions.extend(str(q) for q in data["sub_questions"])
            if isinstance(data.get("summary"), str):
                texts.append(data["summary"])
    return {"summary": "\n\n".join(texts).strip(), "references": references, "sub_questions": sub_questions}


def _parse_task(task):
    parts = [p for artifact in task.get("artifacts") or [] for p in artifact.get("parts") or []]
    parsed = _parse_parts(parts)
    return {"state": _state(task), "task_id": task.get("id"), "context_id": task.get("contextId"),
            "agent_message": _status_text(task), **parsed}


def render(result: dict, card: dict, saved_path: str) -> str:
    name = card.get("name") or "literature agent"
    lines = [f"Answer from {name} (version {card.get('version', 'unknown')}), task {result.get('task_id')}, "
             f"state {result['state']}.",
             "This is another agent's synthesis, not literature read in this session: check the claims that "
             "matter against the references (paper_fetch for public ones). Internal references may not be "
             "readable here; cite them as the agent reported them."]
    if result["state"] in PAUSED:
        lines.append(f"The agent needs more input: {result.get('agent_message') or '(no question given)'}\n"
                     f"Answer with literature_agent, passing context_id={result.get('context_id')} and "
                     f"task_id={result.get('task_id')}.")
    elif result["state"] != "completed":
        lines.append(f"The task ended as {result['state']}: {result.get('agent_message') or 'no reason given'}")
    if result.get("sub_questions"):
        lines.append("Sub-questions the agent used:\n" + "\n".join(f"- {q}" for q in result["sub_questions"]))
    if result.get("summary"):
        lines.append("Synthesis:\n" + result["summary"])
    if result.get("references"):
        lines.append("References as reported:")
        for number, ref in enumerate(result["references"], 1):
            fields = [ref.get("id"), ref.get("title"), ", ".join(ref.get("authors") or []) or None,
                      str(ref.get("year")) if ref.get("year") else None, ref.get("source"),
                      ref.get("doi") or ref.get("url")]
            lines.append(f"{number}. " + " | ".join(f for f in fields if f))
    elif result["state"] == "completed":
        lines.append("No references were returned; the synthesis cannot be checked against sources.")
    lines.append(f"Complete exchange and agent card: {saved_path}")
    return "\n".join(lines)
