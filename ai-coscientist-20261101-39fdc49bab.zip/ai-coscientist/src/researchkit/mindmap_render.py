"""Deterministic projection of the approved mind-map content.

The causal-map layout and full method cards are ported from the former
scripts/render_mindmap_artifact.py. No scientific relations are inferred.
"""
from __future__ import annotations

import base64
import html
import math
import re
import unicodedata
from typing import Any, Mapping, Sequence
from xml.etree import ElementTree

from researchkit.mindmap_schema import RELATIONSHIP_PATTERN as _RELATION_PATTERN
from researchkit.mindmap_schema import (
    effect_line, effect_short, observable_line, observables_by_id, side_effect_line, term_coverage, term_line,
)

_PALETTE = (
    ("#4f7d88", "#e7f0f1"), ("#77628b", "#eee9f1"),
    ("#917043", "#f3ece1"), ("#587865", "#e8efe9"),
    ("#8a5d5c", "#f2e8e6"), ("#5f7088", "#e9edf2"),
)
_INK, _MUTED, _DANGER = "#252b2f", "#667075", "#9a5d59"
_NAMESPACE = re.compile(r"[A-Za-z][A-Za-z0-9_.-]*\Z")

# Scope the presentation to this section: a mind map cannot restyle the report.
SECTION_CSS = """
.mindmap-section { margin: 2rem 0; color: #252b2f; background: #fffefb; padding: 1rem; }
.mindmap-section h2, .mindmap-section h3 { color: #252b2f; border-color: #cacbc5; }
.mindmap-section code { color: #252b2f; background: #f7f6f1; }
.mindmap-section .mindmap-source { font-size: .78rem; color: #667075; overflow-wrap: anywhere; }
.mindmap-section .mindmap-summary, .mindmap-section .mindmap-boundary { white-space: pre-wrap; }
.mindmap-section .map-shell { overflow-x: auto; border: 1px solid #cacbc5; border-radius: 6px; background: #fffefb; }
.mindmap-section .map-shell svg { display: block; width: max(100%, 1180px); height: auto; }
.mindmap-section .family-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 360px), 1fr)); gap: 15px; align-items: start; }
.mindmap-section .family { min-width: 0; border: 1px solid #cacbc5; border-top: 4px solid #4f7d88; border-radius: 5px; background: #fffefb; }
.mindmap-section .family-head { padding: 17px 18px 15px; background: #e7f0f1; }
.mindmap-section .family-index { margin: 0 0 3px; font-size: 10px; font-weight: 800; color: #4f7d88; }
.mindmap-section .family-head h3 { margin: 0; font-size: 18px; }
.mindmap-section .family-id { display: block; margin-top: 7px; font-size: 11px; overflow-wrap: anywhere; }
.mindmap-section .mechanism { padding: 16px 18px; border-bottom: 1px solid #cacbc5; }
.mindmap-section .mechanism-label, .mindmap-section .field-label { display: block; margin-bottom: 5px; font-weight: 700; font-size: 12px; color: #4f7d88; }
.mindmap-section .mechanism p, .mindmap-section .field p { margin: 0; font-size: 13px; white-space: pre-wrap; overflow-wrap: anywhere; }
.mindmap-section .mechanism-chain { display: grid; grid-template-columns: minmax(0,1fr) 20px minmax(0,1fr) 20px minmax(0,1fr); gap: 6px; margin-bottom: 15px; }
.mindmap-section .chain-stage { min-width: 0; padding: 8px; border: 1px solid #4f7d88; background: #e7f0f1; font-size: 11px; overflow-wrap: anywhere; }
.mindmap-section .chain-stage ul { padding-left: 15px; margin: 4px 0; }
.mindmap-section .chain-arrow { align-self: center; text-align: center; color: #4f7d88; }
.mindmap-section .field { padding: 13px 18px; border-bottom: 1px solid #cacbc5; }
.mindmap-section .field:last-child { border-bottom: 0; }
.mindmap-section .route-steps, .mindmap-section .target-effects, .mindmap-section .side-effects { padding-left: 18px; margin: 4px 0 10px; font-size: 12px; overflow-wrap: anywhere; }
.mindmap-section .target-model { border: 1px solid #4f7d88; background: #f6f9f9; padding: 8px 14px; margin: 12px 0; overflow-wrap: anywhere; }
.mindmap-section .relations { display: grid; gap: 9px; }
.mindmap-section .relation { padding: 10px 12px; border: 1px solid #cacbc5; background: #f7f6f1; overflow-wrap: anywhere; }
.mindmap-section .relation-id { font-family: monospace; font-size: 12px; }
.mindmap-section .relation-arrow { padding: 0 10px; color: #587865; }
.mindmap-section .relation-text { display: block; font-size: 13px; white-space: pre-wrap; margin-top: 5px; }
.mindmap-section .mindmap-boundary { border-left: 3px solid #9a5d59; padding: 12px 16px; background: #f5e9e6; }
@media (max-width: 650px) {
  .mindmap-section .mechanism-chain { display: block; }
  .mindmap-section .chain-arrow { display: block; transform: rotate(90deg); }
}
@media print {
  .mindmap-section { padding: 0; background: #fff; }
  .mindmap-section .map-shell { overflow: visible; }
  .mindmap-section .map-shell svg { width: 100%; min-width: 0; }
  .mindmap-section .family-grid { display: block; }
  .mindmap-section .family { margin-bottom: 1rem; }
}
"""
for _color_index, (_accent, _soft) in enumerate(_PALETTE):
    SECTION_CSS += (
        f'.mindmap-section .family[data-color="{_color_index}"]'
        f' {{ border-top-color: {_accent}; }}\n'
        f'.mindmap-section .family[data-color="{_color_index}"] .family-head'
        f' {{ background: {_soft}; }}\n'
    )


def _validate(content: Any) -> dict:
    from researchkit.mindmap_schema import validate_map

    return validate_map(content)


def _svg_presentation(svg: str, namespace: str) -> str:
    """Resolve the old CSS into SVG attributes for a standalone, portable graph."""
    root = ElementTree.fromstring(svg)
    root.set("xmlns", "http://www.w3.org/2000/svg")
    _, _, width, height = root.attrib["viewBox"].split()
    root.set("width", width)
    root.set("height", height)
    root.set("font-family", "sans-serif")

    def visit(node: ElementTree.Element, lane: tuple[str, str]) -> None:
        classes = node.get("class", "").split()
        for value in classes:
            if value.startswith("map-lane-"):
                lane = _PALETTE[int(value.rsplit("-", 1)[1])]
        accent, soft = lane
        styles = {
            "map-grid-line": {"stroke": "#e4e2dc", "stroke-width": "1"},
            "map-node": {"fill": "#fffefb", "stroke": "#cacbc5", "stroke-width": "1.3"},
            "map-node-soft": {"fill": "#f7f6f1"},
            "map-node-target": {"fill": "#e8efe9", "stroke": "#587865"},
            "map-family-node": {"fill": soft, "stroke": accent},
            "map-stage-node": {"fill": "#fffefb", "stroke": accent},
            "map-stage-target": {"fill": soft, "stroke": accent},
            "map-risk-node": {"fill": "#f5e9e6", "stroke": _DANGER},
            "map-edge": {"fill": "none", "stroke": _MUTED, "stroke-width": "1.6",
                         "marker-end": "url(#arrow)"},
            "map-edge-lane": {"stroke": accent, "stroke-width": "2"},
            "map-edge-shared": {"stroke": "#587865", "stroke-width": "2"},
            "map-edge-risk": {"fill": "none", "stroke": _DANGER, "stroke-width": "1.4",
                              "stroke-dasharray": "5 4", "marker-end": "url(#arrow-relation)"},
            "map-edge-relation": {"fill": "none", "stroke": _DANGER, "stroke-width": "1.4",
                                  "stroke-dasharray": "6 5", "marker-end": "url(#arrow-relation)"},
            "map-relation-label-box": {"fill": "#fffefb", "stroke": _DANGER, "stroke-width": "1"},
            "map-relation-label": {"fill": _INK, "font-size": "9.5", "font-weight": "600"},
            "map-label": {"fill": _MUTED, "font-size": "12", "font-weight": "700"},
            "map-title": {"fill": _INK, "font-size": "15", "font-weight": "700"},
            "map-small": {"fill": _MUTED, "font-size": "11"},
            "map-tiny": {"fill": "#8e9799", "font-size": "10"},
            "map-family-label": {"fill": accent, "font-size": "11", "font-weight": "800"},
            "map-risk-label": {"fill": _DANGER, "font-size": "10", "font-weight": "800"},
        }
        for name in classes:
            node.attrib.update(styles.get(name, {}))
        if node.get("style") == "marker-end:none":
            node.set("marker-end", "none")
            del node.attrib["style"]
        for key, value in list(node.attrib.items()):
            value = value.replace("var(--muted)", _MUTED).replace("var(--danger)", _DANGER)
            if key == "id":
                value = f"{namespace}-{value}"
            for name in ("map-grid", "arrow-relation", "arrow"):
                value = value.replace(f"url(#{name})", f"url(#{namespace}-{name})")
            node.set(key, value)
        for child in node:
            visit(child, lane)

    visit(root, _PALETTE[0])
    _expand_svg_resources(root)
    return ElementTree.tostring(root, encoding="unicode")


def _expand_svg_resources(root: ElementTree.Element) -> None:
    """Expand the existing SVG pattern/markers, unsupported by MuPDF.

    This is a geometric translation of the original graph's SVG resources.
    Both the browser and PDF receive this identical expanded SVG; scientific
    strings and relations are not inputs to the translation.
    """
    width, height = float(root.get("width")), float(root.get("height"))
    background = next(node for node in root if node.tag == "rect")
    background.set("fill", "#fffefb")
    grid = ElementTree.Element("path", {
        "d": " ".join(
            [f"M{x} 0V{height:g}" for x in range(0, int(width), 36)]
            + [f"M0 {y}H{width:g}" for y in range(0, int(height), 36)]
        ), "stroke": "#e4e2dc", "stroke-width": "1", "fill": "none",
        "class": "map-grid-line",
    })
    root.insert(list(root).index(background) + 1, grid)
    for parent in list(root.iter()):
        for node in list(parent):
            if node.tag != "path":
                continue
            markers = {key: node.attrib.pop(key) for key in ("marker-start", "marker-end")
                       if key in node.attrib}
            if not any(value != "none" for value in markers.values()):
                continue
            # The former renderer emits only absolute M/H/V/Q geometry.
            commands = re.findall(r"([MHVQ])([^MHVQ]*)", node.attrib["d"])
            points = []
            current = (0.0, 0.0)
            for command, coordinates in commands:
                numbers = [float(item) for item in re.findall(r"-?\d+(?:\.\d+)?", coordinates)]
                if command == "M":
                    current = tuple(numbers)
                elif command == "H":
                    current = (numbers[0], current[1])
                elif command == "V":
                    current = (current[0], numbers[0])
                else:
                    points.append(tuple(numbers[:2]))
                    current = tuple(numbers[2:])
                points.append(current)
            if len(points) < 2:
                raise ValueError("mindmap SVG marker path has no segment")
            stroke = float(node.get("stroke-width", "1"))
            for position, resource in markers.items():
                if resource == "none":
                    continue
                start = position == "marker-start"
                endpoint, adjacent = (points[0], points[1]) if start else (points[-1], points[-2])
                dx, dy = endpoint[0] - adjacent[0], endpoint[1] - adjacent[1]
                norm = math.hypot(dx, dy)
                if not norm:
                    raise ValueError("mindmap SVG marker has zero-length tangent")
                ux, uy = dx / norm, dy / norm
                # Original marker: path M0,0 L8,4 L0,8, ref=(7,4),
                # markerUnits=strokeWidth, orient=auto[-start-reverse].
                triangle = [
                    (endpoint[0] + (x - 7) * stroke * ux - (y - 4) * stroke * uy,
                     endpoint[1] + (x - 7) * stroke * uy + (y - 4) * stroke * ux)
                    for x, y in ((0, 0), (8, 4), (0, 8))
                ]
                arrow = ElementTree.Element("polygon", {
                    "points": " ".join(f"{x:.3f},{y:.3f}" for x, y in triangle),
                    "fill": _DANGER if "arrow-relation" in resource else _MUTED,
                    "class": "map-arrowhead", "data-arrow-position": "start" if start else "end",
                })
                parent.insert(list(parent).index(node) + 1, arrow)


def render_svg(content: Mapping[str, Any], *, namespace: str = "mindmap") -> str:
    """Render the exact validated formal content; no envelope guessing."""
    value = _validate(content)
    if not _NAMESPACE.fullmatch(namespace):
        raise ValueError("mindmap namespace must be a nonempty safe HTML identifier")
    return _svg_presentation(_render_causal_map_svg(
        value["families"], title=value["title"],
        evidence_summary=value["evidence_boundary_summary"],
        relationships=value["supported_relationships"],
        target_observables=[observable_line(item) for item in value["target_model"]["observables"]],
        names=observables_by_id(value),
    ), namespace)


def _pdf_graph(svg: str) -> str:
    """Rasterize this same SVG using the already-required PDF engine."""
    import pymupdf

    with pymupdf.open(stream=svg.encode("utf-8"), filetype="svg") as document:
        page = document[0]
        scale = min(2.0, 6000 / max(page.rect.width, page.rect.height))
        pixels = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), alpha=False)
        encoded = base64.b64encode(pixels.tobytes("png")).decode("ascii")
        ratio = min(510 / page.rect.width, 660 / page.rect.height)
        width, height = page.rect.width * ratio, page.rect.height * ratio
    return (f'<img src="data:image/png;base64,{encoded}" '
            f'width="{width:.2f}" height="{height:.2f}" alt="作用路線因果圖" />')


def _pdf_text(value: str) -> str:
    # Story does not support CSS overflow-wrap on long identifiers. These are
    # layout opportunities only; the browser projection retains original text.
    pieces, run = [], 0
    for character in value:
        if character.isspace():
            run = 0
        elif run == 40:
            pieces.append("&#8203;")
            run = 0
        pieces.append(html.escape(character))
        if not character.isspace():
            run += 1
    return "".join(pieces)


def render_section(
    content: Mapping[str, Any], provenance: dict, *, namespace: str, pdf: bool = False,
) -> str:
    """Embed a graph and every formal field from one explicitly selected map.

    ``provenance`` contains the report's already-resolved record_ref, source_path,
    sha256, title, and kind. It is internal rendering input, not a saved schema.
    """
    value = _validate(content)
    svg = render_svg(value, namespace=namespace)
    escape = _pdf_text if pdf else html.escape
    source = "".join(
        f"{label}：{escape(provenance[key])}<br />"
        for key, label in (
            ("title", "保存標題"), ("kind", "類型"), ("record_ref", "紀錄"),
            ("source_path", "原路徑"), ("sha256", "SHA-256"),
        )
    )
    names = observables_by_id(value)
    cards = "".join(_render_family(item, index=index, names=names)
                    for index, item in enumerate(value["families"]))
    relationships = _render_relationships(
        value["supported_relationships"],
        family_ids={item["family_id"] for item in value["families"]},
    )
    gaps = _render_list(value["unresolved_gaps"], empty_text="目前沒有列出的未解缺口。",
                        css_class="gap-list")
    if pdf:
        # Keep each label with its field and make relation explanations block
        # paragraphs. The scientific values remain identical to the HTML view.
        root = ElementTree.fromstring(
            "<div>" + cards + "<h3>族群關係</h3>" + relationships
            + "<h3>未解研究缺口</h3>" + gaps + "</div>"
        )
        for node in root.iter():
            if node.get("class") == "field":
                # Story does not reliably honor keep-with-next CSS. Put the
                # field label on the same first line as its existing value.
                label, paragraph = list(node)
                node.remove(label)
                paragraph.text = label.text + "：" + (paragraph.text or "")
            if node.get("class") == "relation-text":
                node.tag = "p"
            if node.get("class") == "tension":
                node.tail = " "
            for key in ("text", "tail"):
                text = getattr(node, key)
                if text:
                    setattr(node, key, html.unescape(_pdf_text(text)))
        # Story can lose later blocks when an anonymous inline run crosses a
        # page boundary. Give every such run an explicit paragraph, retaining
        # the existing elements, their text/tails, and their original order.
        for parent in list(root.iter()):
            if parent.tag not in ("div", "header", "article", "section"):
                continue
            paragraph = None
            for child in list(parent):
                if child.tag in ("code", "span", "strong", "em"):
                    if paragraph is None:
                        paragraph = ElementTree.Element("p")
                        parent.insert(list(parent).index(child), paragraph)
                    parent.remove(child)
                    paragraph.append(child)
                else:
                    paragraph = None
        details = ElementTree.tostring(root, encoding="unicode", method="html")
        graph = _pdf_graph(svg)
        styling = ""
    else:
        details = f'<div class="family-grid">{cards}</div><h3>族群關係</h3><div class="relations">{relationships}</div><h3>未解研究缺口</h3>{gaps}'
        graph = svg
        styling = f"<style>{SECTION_CSS}</style>"
    return (
        styling + f'<section class="mindmap-section" id="{namespace}">'
        f'<h2>{escape(value["title"])}</h2><div class="mindmap-source">{source}</div>'
        f'<p>{len(value["families"])} 條作用路線；{len(value["supported_relationships"])} 條明示關係。</p>'
        f'<p class="mindmap-summary">{escape(value["landscape_summary"])}</p>'
        + _render_target_model(value, escape) +
        f'<div class="map-shell">{graph}</div><h3>作用路線完整定義</h3>{details}'
        f'<h3>證據邊界</h3><p class="mindmap-boundary">{escape(value["evidence_boundary_summary"])}</p>'
        '</section>'
    )


def render_html(
    content: Mapping[str, Any], provenance: dict, *, namespace: str = "mindmap",
) -> str:
    """Standalone HTML shares the exact graph and full content projection."""
    value = _validate(content)
    section = render_section(value, provenance, namespace=namespace)
    return ('<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{html.escape(value["title"])}</title>'
            '<style>body{font:16px/1.7 system-ui,sans-serif;margin:1rem auto;max-width:1440px;'
            'background:#f1f0eb}h2,h3{line-height:1.4}</style></head><body>'
            + section + '</body></html>')

_FAMILY_FIELDS = (
    ("principle", "作用原理"),
    ("acts_on_terms", "作用於的主導項"),
    ("prerequisites", "成立前提與禁忌"),
    ("early_check", "早期檢查"),
    ("main_bottleneck", "主要瓶頸"),
    ("expected_failure_mode", "可能失效方式"),
    ("viability_band", "目前可研究性"),
)
SCOPE_LABELS = {"in_task": "任務範圍內", "outside_task": "超出任務範圍（列出供參考，不進入後續假說）"}

def _render_causal_map_svg(
    families: Sequence[Mapping[str, Any]],
    *,
    title: str,
    evidence_summary: str,
    relationships: Sequence[str],
    target_observables: Sequence[str],
    names: Mapping[str, str],
) -> str:
    lane_width = 250
    lane_gap = 24
    margin = 52
    content_width = (
        len(families) * lane_width + max(0, len(families) - 1) * lane_gap
    )
    map_width = max(1180, content_width + margin * 2)
    lane_start = (map_width - content_width) / 2

    index_by_id = {
        str(family["family_id"]): index for index, family in enumerate(families)
    }
    drawable_relationships: list[tuple[str, str, str, str]] = []
    for relationship in relationships:
        match = _RELATION_PATTERN.fullmatch(relationship)
        if match is None:
            raise ValueError("validated mindmap relationship has invalid syntax")
        source_id, operator, target_id, explanation = match.groups()
        if source_id not in index_by_id or target_id not in index_by_id:
            raise ValueError("validated mindmap relationship has unknown endpoint")
        drawable_relationships.append(
            (source_id, operator, target_id, explanation)
        )

    stage_specs = (
        ("levers", "可調整的槓桿"),
        ("steps", "逐步機轉"),
        ("target_effect", "對目標的作用"),
    )
    family_stages = [_mechanism_stage_values(family, names) for family in families]
    family_risk_lines = [
        _wrap_svg_lines(
            family["expected_failure_mode"],
            width=29,
            max_lines=3,
        )
        for family in families
    ]
    stage_line_counts: list[int] = []
    for stage_index in range(len(stage_specs)):
        stage_line_counts.append(
            max(
                len(_svg_bullet_lines(stages[stage_index], width=31))
                for stages in family_stages
            )
        )
    stage_heights = [max(102, 43 + line_count * 16) for line_count in stage_line_counts]

    top_y = 28
    top_height = 106
    branch_y = top_y + top_height + 26
    relation_row_spacing = 40
    family_y = max(
        190,
        branch_y + 36 + len(drawable_relationships) * relation_row_spacing,
    )
    family_height = 102
    stage_gap = 30
    stage_ys: list[float] = []
    cursor_y = family_y + family_height + stage_gap
    for stage_height in stage_heights:
        stage_ys.append(cursor_y)
        cursor_y += stage_height + stage_gap

    risk_y = cursor_y
    risk_height = max(
        62,
        37 + max(len(lines) for lines in family_risk_lines) * 14,
    )
    merge_y = risk_y + risk_height + 28
    common_lines = _svg_bullet_lines(list(target_observables), width=78)
    target_height = max(86, 42 + len(common_lines) * 16)
    target_y = merge_y + 30
    map_height = target_y + target_height + 34

    top_gap = 20
    top_width = (map_width - margin * 2 - top_gap * 2) / 3
    top_nodes = (
        ("研究題目", _wrap_svg_lines(title, width=48, max_lines=3)),
        (
            "共同研究資產",
            _wrap_svg_lines(evidence_summary, width=62, max_lines=3),
        ),
        (
            "研究產出方向",
            ["可反駁的作用路線", "由假說、代理公式與驗證工作承接"],
        ),
    )

    parts = [
        f'<svg class="causal-map" viewBox="0 0 {map_width:.0f} {map_height:.0f}" '
        'role="img" aria-label="作用路線因果圖">',
        "<defs>",
        '<pattern id="map-grid" width="36" height="36" patternUnits="userSpaceOnUse">',
        '<path d="M36 0H0V36" class="map-grid-line" fill="none"/>',
        "</pattern>",
        '<marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">',
        '<path d="M0,0 L8,4 L0,8 Z" fill="var(--muted)"/>',
        "</marker>",
        '<marker id="arrow-relation" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto-start-reverse">',
        '<path d="M0,0 L8,4 L0,8 Z" fill="var(--danger)"/>',
        "</marker>",
        "</defs>",
        f'<rect width="{map_width:.0f}" height="{map_height:.0f}" fill="url(#map-grid)"/>',
    ]

    for index, (label, lines) in enumerate(top_nodes):
        x = margin + index * (top_width + top_gap)
        node_class = "map-node map-node-target" if index == 2 else "map-node map-node-soft"
        parts.append(
            f'<rect x="{x:.1f}" y="{top_y}" width="{top_width:.1f}" '
            f'height="{top_height}" rx="8" class="{node_class}"/>'
        )
        parts.append(
            _svg_text([label], x=x + 18, y=top_y + 25, css_class="map-label")
        )
        parts.append(
            _svg_text(
                lines,
                x=x + 18,
                y=top_y + 51,
                css_class="map-small",
                line_height=16,
            )
        )
        if index < 2:
            parts.append(
                f'<path d="M{x + top_width:.1f} {top_y + top_height / 2:.1f} '
                f'H{x + top_width + top_gap:.1f}" class="map-edge"/>'
            )

    shared_center = margin + top_width + top_gap + top_width / 2
    first_center = lane_start + lane_width / 2
    last_center = lane_start + (len(families) - 1) * (lane_width + lane_gap) + lane_width / 2
    parts.extend(
        [
            f'<path d="M{shared_center:.1f} {top_y + top_height:.1f} V{branch_y:.1f}" '
            'class="map-edge map-edge-shared"/>',
            f'<path d="M{first_center:.1f} {branch_y:.1f} H{last_center:.1f}" '
            'class="map-edge map-edge-shared" style="marker-end:none"/>',
        ]
    )

    for index, (family, stages, risk_lines) in enumerate(
        zip(families, family_stages, family_risk_lines)
    ):
        x = lane_start + index * (lane_width + lane_gap)
        center_x = x + lane_width / 2
        lane_class = f"map-lane-{index % 6}"
        family_id = str(family["family_id"])
        family_title = family["title"]
        title_lines = _wrap_svg_lines(family_title, width=28, max_lines=2)
        id_lines = _wrap_svg_lines(family_id, width=34, max_lines=2)
        parts.extend(
            [
                f'<path d="M{center_x:.1f} {branch_y:.1f} V{family_y:.1f}" '
                'class="map-edge map-edge-shared"/>',
                f'<g class="{lane_class}" data-map-family-id="{html.escape(family_id, quote=True)}">',
                f'<rect x="{x:.1f}" y="{family_y}" width="{lane_width}" '
                f'height="{family_height}" rx="8" class="map-node map-family-node"/>',
                _svg_text(
                    [f"ROUTE {index + 1:02d}" + ("（任務範圍外）" if family["scope_status"] == "outside_task" else "")],
                    x=x + 15,
                    y=family_y + 22,
                    css_class="map-family-label",
                ),
                _svg_text(
                    title_lines,
                    x=x + 15,
                    y=family_y + 44,
                    css_class="map-title",
                    line_height=17,
                ),
                _svg_text(
                    id_lines,
                    x=x + 15,
                    y=family_y + 82,
                    css_class="map-tiny",
                    line_height=13,
                ),
            ]
        )

        previous_bottom = family_y + family_height
        for stage_index, ((_, label), items) in enumerate(zip(stage_specs, stages)):
            stage_y = stage_ys[stage_index]
            stage_height = stage_heights[stage_index]
            node_class = (
                "map-node map-stage-target" if stage_index == 2 else "map-node map-stage-node"
            )
            parts.extend(
                [
                    f'<path d="M{center_x:.1f} {previous_bottom:.1f} V{stage_y:.1f}" '
                    'class="map-edge map-edge-lane"/>',
                    f'<rect x="{x:.1f}" y="{stage_y:.1f}" width="{lane_width}" '
                    f'height="{stage_height:.1f}" rx="8" class="{node_class}"/>',
                    _svg_text(
                        [label],
                        x=x + 14,
                        y=stage_y + 23,
                        css_class="map-family-label",
                    ),
                    _svg_text(
                        _svg_bullet_lines(items, width=31),
                        x=x + 14,
                        y=stage_y + 47,
                        css_class="map-small",
                        line_height=16,
                    ),
                ]
            )
            previous_bottom = stage_y + stage_height
        main_route_x = x + lane_width - 4
        main_elbow_y = previous_bottom + 12
        parts.extend(
            [
                f'<path d="M{center_x:.1f} {previous_bottom:.1f} '
                f'V{main_elbow_y:.1f} H{main_route_x:.1f} V{merge_y:.1f}" '
                'class="map-edge map-edge-lane" style="marker-end:none"/>',
                f'<path d="M{center_x:.1f} {previous_bottom:.1f} V{risk_y:.1f}" '
                'class="map-edge-risk"/>',
                f'<rect x="{x + 10:.1f}" y="{risk_y:.1f}" '
                f'width="{lane_width - 20}" height="{risk_height:.1f}" rx="7" '
                'class="map-node map-risk-node" '
                f'data-map-risk-family-id="{html.escape(family_id, quote=True)}"/>',
                _svg_text(
                    ["主要風險／預期失效"],
                    x=x + 22,
                    y=risk_y + 19,
                    css_class="map-risk-label",
                ),
                _svg_text(
                    risk_lines,
                    x=x + 22,
                    y=risk_y + 40,
                    css_class="map-small",
                    line_height=14,
                ),
                "</g>",
            ]
        )

    # Every lane's existing bypass route joins this horizontal collector.
    # The old endpoint at last_center left the final lane's route detached.
    merge_end_x = lane_start + (len(families) - 1) * (lane_width + lane_gap) + lane_width - 4
    parts.extend(
        [
            f'<path d="M{first_center:.1f} {merge_y:.1f} H{merge_end_x:.1f}" '
            'class="map-edge map-edge-shared" style="marker-end:none"/>',
            f'<path d="M{map_width / 2:.1f} {merge_y:.1f} V{target_y:.1f}" '
            'class="map-edge map-edge-shared"/>',
        ]
    )

    target_width = min(760, map_width - margin * 2)
    target_x = (map_width - target_width) / 2
    parts.extend(
        [
            f'<rect x="{target_x:.1f}" y="{target_y:.1f}" width="{target_width:.1f}" '
            f'height="{target_height:.1f}" rx="9" class="map-node map-node-target"/>',
            _svg_text(
                ["目標觀測量與需要的變化"],
                x=target_x + 18,
                y=target_y + 25,
                css_class="map-label",
            ),
            _svg_text(
                common_lines,
                x=target_x + 18,
                y=target_y + 50,
                css_class="map-small",
                line_height=16,
            ),
        ]
    )

    for relation_index, (
        source_id,
        operator,
        target_id,
        explanation,
    ) in enumerate(drawable_relationships):
        source_x = lane_start + index_by_id[source_id] * (lane_width + lane_gap) + lane_width / 2
        target_x_rel = lane_start + index_by_id[target_id] * (lane_width + lane_gap) + lane_width / 2
        arc_y = family_y - 24 - relation_index * relation_row_spacing
        midpoint_x = (source_x + target_x_rel) / 2
        label_width = 196
        label_height = 34
        label_x = min(
            max(midpoint_x - label_width / 2, margin),
            map_width - margin - label_width,
        )
        label_y = arc_y - label_height / 2
        label_lines = _wrap_svg_lines(
            f"R{relation_index + 1} {explanation}",
            width=31,
            max_lines=2,
        )
        marker_start = (
            ' marker-start="url(#arrow-relation)"'
            if operator == "<->"
            else ""
        )
        parts.extend(
            [
            '<g class="map-relation-annotation">',
            f"<title>{html.escape(relationships[relation_index])}</title>",
            f'<path d="M{source_x:.1f} {family_y:.1f} Q{(source_x + target_x_rel) / 2:.1f} '
            f'{arc_y:.1f} {target_x_rel:.1f} {family_y:.1f}" class="map-edge-relation" '
            f'data-map-source-id="{html.escape(source_id, quote=True)}" '
            f'data-map-target-id="{html.escape(target_id, quote=True)}"'
            f'{marker_start}/>',
            f'<rect x="{label_x:.1f}" y="{label_y:.1f}" width="{label_width}" '
            f'height="{label_height}" rx="6" class="map-relation-label-box"/>',
            _svg_text(
                label_lines,
                x=label_x + 9,
                y=label_y + 13,
                css_class="map-relation-label",
                line_height=12,
            ),
            "</g>",
            ]
        )

    parts.append("</svg>")
    return "".join(parts)


def _mechanism_stage_values(
    family: Mapping[str, Any], names: Mapping[str, str],
) -> tuple[list[str], list[str], list[str]]:
    return (
        list(family["levers"]),
        [f"{step['change']} → {step['quantity']}" for step in family["steps"]],
        [effect_short(item, names) for item in family["target_effect"]],
    )


def _wrap_svg_lines(
    value: str,
    *,
    width: int,
    max_lines: int | None = None,
) -> list[str]:
    normalized = " ".join(value.split())
    lines: list[str] = []
    remaining = normalized
    break_chars = " ,.;:，。；：、/／-"
    while remaining:
        if _display_width(remaining) <= width:
            lines.append(remaining)
            break
        used = 0
        cut = 0
        preferred_cut = 0
        for index, character in enumerate(remaining):
            character_width = _character_display_width(character)
            if cut and used + character_width > width:
                break
            used += character_width
            cut = index + 1
            if character in break_chars:
                preferred_cut = cut
        if cut == 0:
            cut = 1
        if preferred_cut >= max(1, cut // 2):
            cut = preferred_cut
        line = remaining[:cut].rstrip()
        if not line:
            line = remaining[:cut]
        lines.append(line)
        remaining = remaining[cut:].lstrip()
    if not lines:
        lines = [""]
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
        final_line = lines[-1].rstrip(" .")
        while final_line and _display_width(final_line + "…") > width:
            final_line = final_line[:-1].rstrip()
        lines[-1] = final_line + "…"
    return lines


def _character_display_width(character: str) -> int:
    if unicodedata.combining(character):
        return 0
    return 2 if unicodedata.east_asian_width(character) in {"W", "F", "A"} else 1


def _display_width(value: str) -> int:
    return sum(_character_display_width(character) for character in value)


def _svg_bullet_lines(values: Sequence[str], *, width: int) -> list[str]:
    rendered: list[str] = []
    for value in values:
        wrapped = _wrap_svg_lines(value, width=max(8, width - 2))
        rendered.append("• " + wrapped[0])
        rendered.extend("  " + line for line in wrapped[1:])
    return rendered


def _svg_text(
    lines: Sequence[str],
    *,
    x: float,
    y: float,
    css_class: str,
    line_height: int = 16,
) -> str:
    spans = "".join(
        f'<tspan x="{x:.1f}" dy="{0 if index == 0 else line_height}">'
        f"{html.escape(line)}</tspan>"
        for index, line in enumerate(lines)
    )
    return f'<text x="{x:.1f}" y="{y:.1f}" class="{css_class}">{spans}</text>'


def _ordered_unique(values: Sequence[str] | Any) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _render_family(family: Mapping[str, Any], *, index: int, names: Mapping[str, str]) -> str:
    family_id = str(family["family_id"])
    title = family["title"]
    fields: list[str] = []
    for key, label in _FAMILY_FIELDS:
        value = family[key]
        text = ("、".join(value) or "未列出") if isinstance(value, list) else value
        fields.append(
            '<div class="field">'
            f'<span class="field-label">{html.escape(label)}</span>'
            f"<p>{html.escape(text)}</p>"
            "</div>"
        )
    steps = "".join(
        f"<li><strong>{html.escape(step['change'])}</strong> → {html.escape(step['quantity'])}："
        f"{html.escape(step['effect'])}（證據：{html.escape(step['evidence'])}）</li>"
        for step in family["steps"]
    )
    effects = "".join(f"<li>{html.escape(effect_line(item, names))}</li>" for item in family["target_effect"])
    side_effects = _render_list(
        [side_effect_line(item, names) for item in family["side_effects"]],
        empty_text="未列出副作用。", css_class="side-effects",
    )
    return f"""<article class="family" data-family-id="{html.escape(family_id, quote=True)}" data-color="{index % 6}">
  <header class="family-head">
    <p class="family-index">ROUTE {index + 1:02d}</p>
    <h3>{html.escape(title)}</h3>
    <code class="family-id">{html.escape(family_id)}</code>
  </header>
  <div class="mechanism">
    {_render_route_chain(family, names)}
    <span class="mechanism-label">範圍</span>
    <p>{html.escape(SCOPE_LABELS[family["scope_status"]])}（{html.escape(family["scope_status"])}）</p>
    <span class="mechanism-label">摘要</span>
    <p>{html.escape(family["summary"])}</p>
    <span class="mechanism-label">逐步機轉</span>
    <ol class="route-steps">{steps}</ol>
    <span class="mechanism-label">對目標的作用</span>
    <ul class="target-effects">{effects}</ul>
    <span class="mechanism-label">副作用</span>
    {side_effects}
  </div>
  <div class="field-grid">
    {''.join(fields)}
  </div>
</article>"""


def _render_route_chain(family: Mapping[str, Any], names: Mapping[str, str]) -> str:
    labels = ("可調整的槓桿", "逐步機轉", "對目標的作用")
    rendered_stages = [
        '<div class="chain-stage">'
        f"<strong>{html.escape(label)}</strong>"
        "<ul>" + "".join(f"<li>{html.escape(item)}</li>" for item in items) + "</ul></div>"
        for label, items in zip(labels, _mechanism_stage_values(family, names))
    ]
    return '<div class="mechanism-chain">' + '<span class="chain-arrow">→</span>'.join(rendered_stages) + "</div>"


def _render_target_model(value: Mapping[str, Any], escape) -> str:
    model, coverage = value["target_model"], term_coverage(value)
    observables = "".join(f"<li>{escape(observable_line(item))}</li>" for item in model["observables"])
    terms = "".join(f"<li>{escape(term_line(term, coverage[term['id']]))}</li>" for term in model["governing_terms"])
    couplings = "".join(f"<li>{escape(item)}</li>" for item in model["couplings"]) or "<li>未列出耦合。</li>"
    return (f'<div class="target-model"><h3>目標模型（各作用路線的共同基準）</h3>'
            f'<ul class="target-observables">{observables}</ul>'
            f'<p><strong>主導關係</strong>：{escape(model["governing_relation"])}</p>'
            f'<p><strong>主導項與作用路線</strong></p><ul class="target-terms">{terms}</ul>'
            f'<p><strong>觀測量之間的耦合</strong></p><ul class="target-couplings">{couplings}</ul></div>')


def _render_relationships(
    relationships: Sequence[str],
    *,
    family_ids: set[str],
) -> str:
    if not relationships:
        return '<div class="relation unparsed">目前沒有列出的族群關係。</div>'
    rendered: list[str] = []
    for relationship in relationships:
        match = _RELATION_PATTERN.fullmatch(relationship)
        if match is None:
            raise ValueError("validated mindmap relationship has invalid syntax")
        source_id, operator, target_id, explanation = match.groups()
        if source_id not in family_ids or target_id not in family_ids:
            raise ValueError("validated mindmap relationship has unknown endpoint")
        arrow = "↔" if operator == "<->" else "→"
        rendered.append(
            '<div class="relation"'
            f' data-source-id="{html.escape(source_id, quote=True)}"'
            f' data-target-id="{html.escape(target_id, quote=True)}">'
            f'<span class="relation-id">{html.escape(source_id)}</span>'
            f'<span class="relation-arrow">{arrow}</span>'
            f'<span class="relation-id">{html.escape(target_id)}</span>'
            f'<span class="relation-text">{html.escape(explanation)}</span>'
            "</div>"
        )
    return "\n".join(rendered)


def _render_list(
    values: Sequence[str],
    *,
    empty_text: str,
    css_class: str,
) -> str:
    items = list(values) if values else [empty_text]
    return (
        f'<ul class="{html.escape(css_class, quote=True)}">'
        + "".join(f"<li>{html.escape(item)}</li>" for item in items)
        + "</ul>"
    )


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        raise ValueError("validated mindmap field must be a list")
    return list(value)


