"""The approved scientific content contract for the mind-map skill."""

from __future__ import annotations

from copy import deepcopy
import json
import re

from jsonschema import Draft202012Validator


def _object(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


def _text(maximum):
    return {"type": "string", "minLength": 1, "maxLength": maximum}


def _array(items, minimum, maximum):
    return {"type": "array", "items": items, "minItems": minimum, "maxItems": maximum}


_SHORT = _text(1600)
OBSERVATION_SCHEMA = _object({
    "source_observations": _array(_SHORT, 1, 16),
    "variation_patterns": _array(_SHORT, 1, 16),
    "explicit_scientific_meanings": _array(_SHORT, 1, 16),
    "evidence_gaps": _array(_SHORT, 0, 16),
})
_NAME = _text(200)
_OBSERVABLE_ID = {"type": "string", "minLength": 1, "maxLength": 40, "pattern": r"^[A-Za-z0-9_.-]+$"}
# Kind of target: larger-the-better, smaller-the-better, or nominal-the-best (a set value).
KINDS = {"larger_better": "望大", "smaller_better": "望小", "nominal": "望目"}
# Computed by the host from the numbers, never authored by the model.
NEEDED_DIRECTIONS = {"increase": "需提高", "decrease": "需降低", "keep": "已在容許範圍內",
                     "per_sample": "依樣本而定（有的高於、有的低於目標）",
                     "unknown": "沒有量測值，無法依數值計算"}
# The model states the sign the route's mechanism predicts for the measured quantity (a hypothesis),
# and separately whether the available data support it.
PREDICTED_SIGNS = {"increases": "預測使其升高", "decreases": "預測使其降低", "mixed": "預測有升有降",
                   "unknown": "機制無法預測方向"}
# Judged against this task's own measurements only; literature support belongs in the basis.
EVIDENCE_STATUSES = {"supported": "本題資料支持", "contradicted": "本題資料矛盾", "untested": "本題資料尚未檢驗"}
RELATIONS = {"toward": "朝向目標", "away": "遠離目標", "per_sample": "依樣本而定",
             "may_leave_band": "可能移出容許範圍", "unknown": "無法判定"}
_VALUE_SCHEMA = _object({"label": _text(100), "value": {"type": "number"}})
# The shared yardstick: where each measured target quantity stands and what governs it.
# It is not a taxonomy; families are routes that move these quantities.
_OBSERVABLE_SCHEMA = _object({
    "id": _OBSERVABLE_ID,
    "name": _NAME,
    # How the task scores or ranks this quantity, when it does (for example a distance to a set
    # value). The score lives here; every other field describes the measured quantity itself.
    "ranking_score": _SHORT,
    "unit": _text(40),
    "kind": {"type": "string", "enum": list(KINDS)},
    "target_value": {"type": "number"},
    "tolerance": {"type": "number", "minimum": 0},
    # Measured values only: empty when the sources hold no measurement of this target (a design that
    # does not exist yet). An estimate is not a measurement.
    "current_values": _array(_VALUE_SCHEMA, 0, 12),
    "needed_change": _SHORT,
})
# Each quantity in the governing relation that could move a target. Every term needs a route
# acting on it, or a reason (empty when a route covers it) why none can in this task.
_TERM_SCHEMA = _object({
    "id": _OBSERVABLE_ID,
    "quantity": _SHORT,
    "effect_on_targets": _SHORT,
    "uncovered_reason": {"type": "string", "maxLength": 1600},
})
TARGET_MODEL_SCHEMA = _object({
    "observables": _array(_OBSERVABLE_SCHEMA, 1, 12),
    "governing_relation": _text(2400),
    "governing_terms": _array(_TERM_SCHEMA, 1, 16),
    "couplings": _array(_SHORT, 0, 12),
})
# One ordered step of a route's mechanism, from what is changed toward a target observable.
_STEP_SCHEMA = _object({
    "change": _SHORT,
    "quantity": _text(300),
    "effect": _SHORT,
    "evidence": _SHORT,
})
# The explanation comes before the choice, so the route is reasoned before it is judged.
_TARGET_EFFECT_SCHEMA = _object({
    "observable_id": _OBSERVABLE_ID,
    "direction": _SHORT,
    "predicted_sign": {"type": "string", "enum": list(PREDICTED_SIGNS)},
    "evidence_status": {"type": "string", "enum": list(EVIDENCE_STATUSES)},
    "magnitude": _SHORT,
    "basis": _SHORT,
})
_SIDE_EFFECT_SCHEMA = _object({
    "observable_id": _OBSERVABLE_ID,
    "effect": _SHORT,
})
SCOPE_STATUSES = ("in_task", "outside_task")
# A family is one route of action: a mechanism that moves the target.
_FAMILY_SCHEMA = _object({
    "family_id": _text(100),
    "title": _text(240),
    "summary": _text(1200),
    "principle": _SHORT,
    "scope_status": {"type": "string", "enum": list(SCOPE_STATUSES)},
    "levers": _array(_SHORT, 1, 8),
    "acts_on_terms": _array(_OBSERVABLE_ID, 0, 8),
    "steps": _array(_STEP_SCHEMA, 2, 10),
    "target_effect": _array(_TARGET_EFFECT_SCHEMA, 1, 12),
    "side_effects": _array(_SIDE_EFFECT_SCHEMA, 0, 12),
    "prerequisites": _SHORT,
    "early_check": _SHORT,
    "main_bottleneck": _SHORT,
    "expected_failure_mode": _SHORT,
    "viability_band": _SHORT,
})
MAP_SCHEMA = _object({
    "title": _text(240),
    "landscape_summary": _text(2600),
    "target_model": TARGET_MODEL_SCHEMA,
    "families": _array(_FAMILY_SCHEMA, 1, 10),
    "supported_relationships": _array(_SHORT, 0, 16),
    "unresolved_gaps": _array(_SHORT, 0, 16),
    "evidence_boundary_summary": _SHORT,
})


def _partial(schema, keep=()):
    """The object schema with its fields optional, except those in keep."""
    return {**schema, "required": [name for name in schema["required"] if name in keep]}


# The audit stage returns its corrections; the host applies them to the draft. v43's audit wrote
# the whole map again, 24,000 characters in eleven to thirteen minutes at the server's speed, and
# most of what it changed was rewording ("沒有" to "無", "/" to "／").
EDITS_SCHEMA = _object({
    "map_fields": _partial({**MAP_SCHEMA, "properties": {
        **{name: value for name, value in MAP_SCHEMA["properties"].items() if name != "families"},
        "target_model": _partial(TARGET_MODEL_SCHEMA)}}),
    "family_fields": _array(_partial(_FAMILY_SCHEMA, keep=("family_id",)), 0, 10),
    "added_families": _array(_FAMILY_SCHEMA, 0, 10),
    "removed_families": _array(_text(100), 0, 10),
})

# This parses the author's explicit endpoints and direction, not scientific words. The explanation may
# follow a full-width colon: v32 wrote all eight lines that way in Chinese and the whole map was refused.
RELATIONSHIP_PATTERN = re.compile(
    r"^\s*([A-Za-z0-9_.:-]+)\s*(<->|->)\s*"
    r"([A-Za-z0-9_.:-]+)\s*[:：]\s*(.+?)\s*$", re.DOTALL,
)


def _validate(value, schema, label):
    error = next(Draft202012Validator(schema).iter_errors(value), None)
    if error is not None:
        path = ".".join(str(part) for part in error.absolute_path)
        raise ValueError(f"{label}{'.' + path if path else ''}: {error.message}")
    return value


def validate_observation(value) -> dict:
    return _validate(value, OBSERVATION_SCHEMA, "observation")


def needed_direction(observable) -> str:
    """Where the measured quantity must go, from its kind, target and current values.

    A set target with no measured value has no computable direction."""
    if observable["kind"] == "larger_better":
        return "increase"
    if observable["kind"] == "smaller_better":
        return "decrease"
    low = observable["target_value"] - observable["tolerance"]
    high = observable["target_value"] + observable["tolerance"]
    values = [item["value"] for item in observable["current_values"]]
    if not values:
        return "unknown"
    if all(value > high for value in values):
        return "decrease"
    if all(value < low for value in values):
        return "increase"
    if all(low <= value <= high for value in values):
        return "keep"
    return "per_sample"


def relation(predicted_sign, needed) -> str:
    """Whether a physical effect moves the quantity toward its target."""
    if predicted_sign not in ("increases", "decreases") or needed == "unknown":
        return "unknown"
    if needed == "keep":
        return "may_leave_band"
    if needed == "per_sample":
        return "per_sample"
    return "toward" if (predicted_sign == "increases") == (needed == "increase") else "away"


def observables_by_id(value) -> dict:
    return {item["id"]: item for item in value["target_model"]["observables"]}


def _number(value) -> str:
    return f"{value:g}"


def observable_line(item) -> str:
    """One measured target in words, with its host-computed needed direction and gaps."""
    unit = item["unit"]
    values = "、".join(f"{entry['label']} {_number(entry['value'])} {unit}"
                      for entry in item["current_values"]) or "無量測值"
    target = (f"{_number(item['target_value'])} ± {_number(item['tolerance'])} {unit}" if item["kind"] == "nominal"
              else f"{_number(item['target_value'])} {unit}")
    needed = needed_direction(item)
    line = (f"{item['name']}（{item['id']}，{KINDS[item['kind']]} {item['kind']}）：目前 {values}；目標 {target}；"
            f"需要的方向（依數值計算）：{NEEDED_DIRECTIONS[needed]}")
    if item["kind"] == "nominal" and item["current_values"]:
        gaps = "、".join(f"{entry['label']} {entry['value'] - item['target_value']:+g} {unit}"
                         for entry in item["current_values"])
        line += f"；與目標的差距：{gaps}"
    return line + f"；任務評分：{item['ranking_score']}。{item['needed_change']}"


def effect_line(item, observables) -> str:
    observable = observables[item["observable_id"]]
    sign = item["predicted_sign"]
    computed = relation(sign, needed_direction(observable))
    evidence = item["evidence_status"]
    return (f"{observable['name']}（{item['observable_id']}）：{PREDICTED_SIGNS[sign]}（{sign}）→ "
            f"{RELATIONS[computed]}（依數值計算）；{EVIDENCE_STATUSES[evidence]}（{evidence}）。"
            f"{item['direction']}；幅度：{item['magnitude']}；依據：{item['basis']}")


def effect_short(item, observables) -> str:
    observable = observables[item["observable_id"]]
    computed = relation(item["predicted_sign"], needed_direction(observable))
    return (f"{observable['name']}：{PREDICTED_SIGNS[item['predicted_sign']]}，{RELATIONS[computed]}，"
            f"{EVIDENCE_STATUSES[item['evidence_status']]}")


def side_effect_line(item, observables) -> str:
    return f"{observables[item['observable_id']]['name']}（{item['observable_id']}）：{item['effect']}"


def computed_directions(value) -> str:
    """Host arithmetic shown to the deepening stage: needed directions and each route's relation."""
    observables = observables_by_id(value)
    lines = ["Target observables:"]
    lines.extend("- " + observable_line(item) for item in observables.values())
    lines.append("Each route's stated predicted_sign compared with those needed directions:")
    for family in value["families"]:
        for item in family["target_effect"]:
            computed = relation(item["predicted_sign"], needed_direction(observables[item["observable_id"]]))
            lines.append(f"- {family['family_id']} on {item['observable_id']}: {item['predicted_sign']} -> {computed}")
    if value["target_model"].get("governing_terms"):
        lines.append("Governing terms and the in-task routes acting on each:")
        coverage = term_coverage(value)
        lines.extend(f"- {term['id']} ({term['quantity']}): {', '.join(coverage[term['id']]) or 'no route'}"
                     for term in value["target_model"]["governing_terms"])
    return "\n".join(lines)


def _route_problems(family, observables):
    """Structural links only: effects use known observable IDs and an in-scope route accounts
    for every observable once. Whether a direction is right stays with the model.

    Returns every problem, so one repair can fix them all.
    """
    label = f"mindmap.families[{family['family_id']}]"
    ids = [item["id"] for item in observables]
    listed = ", ".join(ids)
    problems, seen = [], {}
    for field in ("target_effect", "side_effects"):
        for item in family[field]:
            identifier = item["observable_id"]
            if identifier not in ids:
                problems.append(f"{label}.{field}: observable_id {identifier!r} is not one of "
                                f"target_model.observables ids ({listed})")
            elif identifier in seen:
                problems.append(f"{label}.{field}: observable_id {identifier!r} already appears in "
                                f"{seen[identifier]}; list each observable once, as a target effect "
                                "or as a side effect")
            else:
                seen[identifier] = field
    if family["scope_status"] == "in_task":
        missing = [identifier for identifier in ids if identifier not in seen]
        if missing:
            problems.append(f"{label}: an in_task route accounts for every target observable in "
                            f"target_effect or side_effects (write that no effect is known when so); "
                            f"missing {missing}")
    return problems


def validate_map(value) -> dict:
    _validate(value, MAP_SCHEMA, "mindmap")
    identifiers = [family["family_id"] for family in value["families"]]
    if any(not identifier.strip() for identifier in identifiers):
        raise ValueError("mindmap.families: family_id must not be blank")
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("mindmap.families: family_id must be unique")
    observables = value["target_model"]["observables"]
    if any(not item["name"].strip() for item in observables):
        raise ValueError("mindmap.target_model.observables: name must not be blank")
    if len({item["id"] for item in observables}) != len(observables):
        raise ValueError("mindmap.target_model.observables: id must be unique")
    problems = [problem for item in observables for problem in _score_problems(item)]
    problems += _term_problems(value)
    problems += [problem for family in value["families"] for problem in _route_problems(family, observables)]
    problems += _relationship_problems(value["supported_relationships"], set(identifiers))
    if problems:
        raise ValueError(f"{len(problems)} structural problem(s):\n" + "\n".join(problems))
    return value


def _term_problems(value):
    """Every governing term is acted on by an in-task route, or says why it cannot be."""
    terms = value["target_model"]["governing_terms"]
    ids = [term["id"] for term in terms]
    problems = []
    if len(set(ids)) != len(ids):
        problems.append("mindmap.target_model.governing_terms: id must be unique")
    covered = set()
    for family in value["families"]:
        for term_id in family["acts_on_terms"]:
            if term_id not in ids:
                problems.append(f"mindmap.families[{family['family_id']}].acts_on_terms: {term_id!r} is not one of "
                                f"target_model.governing_terms ids ({', '.join(ids)})")
            elif family["scope_status"] == "in_task":
                covered.add(term_id)
    for term in terms:
        if term["id"] not in covered and not term["uncovered_reason"].strip():
            problems.append(f"mindmap.target_model.governing_terms[{term['id']}]: no in_task route acts on "
                            f"{term['quantity']!r}. Add a route that changes it, or write in uncovered_reason why "
                            "it cannot be changed within this task.")
    return problems


def term_line(term, covered_by) -> str:
    routes = "、".join(covered_by) if covered_by else "無"
    line = f"{term['id']} {term['quantity']}：{term['effect_on_targets']}；作用於此項的路線：{routes}"
    return line + (f"；未覆蓋原因：{term['uncovered_reason']}" if term["uncovered_reason"].strip() else "")


def term_coverage(value) -> dict:
    """term id -> ids of in-task routes acting on it."""
    coverage = {term["id"]: [] for term in value["target_model"]["governing_terms"]}
    for family in value["families"]:
        if family["scope_status"] == "in_task":
            for term_id in family["acts_on_terms"]:
                coverage.setdefault(term_id, []).append(family["family_id"])
    return coverage


def _score_problems(item):
    """A distance score (best value 0, every value at or below 0) listed in place of the measured quantity."""
    values = [entry["value"] for entry in item["current_values"]]
    if item["kind"] == "larger_better" and item["target_value"] == 0 and values and all(value <= 0 for value in values):
        return [f"mindmap.target_model.observables[{item['id']}]: this looks like a distance score (target 0, "
                "every value at or below 0), not a measured quantity. List the measured quantity itself with its "
                "unit, kind (nominal when its best value is a set target), target value, tolerance and measured "
                "values, and put the score in ranking_score."]
    return []


def _relationship_problems(relationships, known):
    problems = []
    for index, relationship in enumerate(relationships):
        label = f"mindmap.supported_relationships[{index}]"
        match = RELATIONSHIP_PATTERN.fullmatch(relationship)
        if match is None:
            problems.append(f"{label}: expected source_id -> target_id: explanation "
                            "or source_id <-> target_id: explanation")
            continue
        source, _, target, explanation = match.groups()
        if source not in known or target not in known:
            problems.append(f"{label}: unknown route endpoint {source!r} or {target!r}; relationships connect two "
                            "family_id values only, and a route's effect on an observable belongs in its "
                            "target_effect or side_effects")
        elif source == target:
            problems.append(f"{label}: self relationships are not allowed")
        elif not explanation.strip():
            problems.append(f"{label}: explanation must not be blank")
    return problems


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _reject_constant(value):
    raise ValueError(f"Non-finite JSON constant is not allowed: {value}")


def _parse(text):
    if not isinstance(text, str):
        raise ValueError("Expected JSON text")
    try:
        return json.loads(text, object_pairs_hook=_unique_keys, parse_constant=_reject_constant)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Expected exactly one JSON object: {exc.msg} "
                         f"at line {exc.lineno}, column {exc.colno}") from exc


def parse_map(text: str) -> dict:
    """Parse the exact formal JSON; never infer a map from Markdown or wrappers."""
    return validate_map(_parse(text))


def apply_edits(draft: dict, edits: dict) -> dict:
    """The audited map: the draft with the audit's corrections, checked as a whole.

    A field given replaces the draft's (a list too, not appended to); target_model may give
    only the parts it changes. Routes keep the draft's order; added ones follow.
    """
    _validate(edits, EDITS_SCHEMA, "mindmap edits")
    result = deepcopy(draft)
    for name, value in edits["map_fields"].items():
        result[name] = {**result[name], **value} if name == "target_model" else value
    families = {family["family_id"]: family for family in result["families"]}
    for identifier in edits["removed_families"]:
        if identifier not in families:
            raise ValueError(f"mindmap edits.removed_families: {identifier} is not a route of the draft")
        del families[identifier]
    for number, item in enumerate(edits["family_fields"], 1):
        if item["family_id"] not in families:
            raise ValueError(f"mindmap edits.family_fields[{number}]: {item['family_id']} is not a route of the "
                             "draft; a new route goes in added_families with every field")
        families[item["family_id"]] = {**families[item["family_id"]], **item}
    for family in edits["added_families"]:
        if family["family_id"] in families:
            raise ValueError(f"mindmap edits.added_families: {family['family_id']} is already a route; change its "
                             "fields in family_fields")
        families[family["family_id"]] = family
    result["families"] = list(families.values())
    return validate_map(result)


def edits_between(draft: dict, final: dict) -> dict:
    """The edits that turn draft into final, for replaying an audit saved as a whole map."""
    old = {family["family_id"]: family for family in draft["families"]}
    new = {family["family_id"]: family for family in final["families"]}
    fields = {name: value for name, value in final.items()
              if name not in ("families", "target_model") and draft.get(name) != value}
    model = {name: value for name, value in final["target_model"].items() if draft["target_model"].get(name) != value}
    return {"map_fields": {**fields, **({"target_model": model} if model else {})},
            "family_fields": [{"family_id": identifier, **{key: value for key, value in family.items()
                                                           if old[identifier].get(key) != value}}
                              for identifier, family in new.items() if identifier in old and family != old[identifier]],
            "added_families": [family for identifier, family in new.items() if identifier not in old],
            "removed_families": [identifier for identifier in old if identifier not in new]}


def parse_audit(text: str, draft: dict) -> dict:
    """The audited map from the deepening reply: corrections to the draft, or the whole map."""
    value = _parse(text)
    if isinstance(value, dict) and "families" in value:
        return validate_map(value)
    return apply_edits(draft, value)


def parse_observation(text: str) -> dict:
    return validate_observation(_parse(text))
