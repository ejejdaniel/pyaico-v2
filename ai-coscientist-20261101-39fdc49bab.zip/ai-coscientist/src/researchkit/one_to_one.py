"""One formula per hypothesis, held by the host where an agent's label is not enough.

LIT v28 combined three hypotheses into one formula PC, was told each hypothesis needs its own
formula, and relabeled PC as H2's formula; its leaderboard then ranked candidates on PC alone.
Three checks: a formula names a lever of the hypothesis it is declared for (other terms are free),
a leaderboard has a sheet of its own for every active hypothesis, and no two sheets of a leaderboard
are the same numbers under different labels.
"""

from __future__ import annotations

import re

TEXT_FIELDS = ("expression", "equation")
LIST_FIELDS = ("inputs", "levers", "variables", "terms")


def current_rows(board, hypothesis_refs):
    """The newest versions of the hypothesis records among hypothesis_refs, as board rows."""
    rows = {row["ref"]: row for row in board["hypotheses"]}
    newest = []
    for ref in hypothesis_refs:
        row = rows.get(ref)
        if row is None:
            continue
        later = [r for r in row.get("superseded_by") or [] if r in rows and not rows[r].get("superseded_by")]
        for found in later or [ref]:
            if found not in newest:
                newest.append(found)
    return [rows[ref] for ref in newest if rows[ref].get("items")]


def _strings(value):
    """Every string in a value, at any depth: v30 wrote inputs as one sentence, others as lists or objects."""
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [part for key, item in value.items() for part in [str(key), *_strings(item)]]
    if isinstance(value, list):
        return [part for item in value for part in _strings(item)]
    return []


def _text(template):
    parts = [template[key] for key in TEXT_FIELDS if isinstance(template.get(key), str)]
    for key in LIST_FIELDS:
        parts += _strings(template.get(key))
    return "\n".join(parts)


def _uses(text, lever):
    return re.search(r"(?<![A-Za-z0-9_])" + re.escape(lever) + r"(?![A-Za-z0-9_])", text, re.IGNORECASE)


def missing_levers(template, rows):
    """{hypothesis id: its levers} for each declared hypothesis whose levers the formula never names.

    The formula's text is its expression, equation, and the names in inputs, levers or variables.
    A hypothesis that declares no levers is not checked.
    """
    own = [item for item in template.get("hypothesis_ids") or [] if isinstance(item, str)]
    text = _text(template)
    missing = {}
    for h in (h for row in rows for h in row["items"] or []):
        if h["id"] in own and h["levers"] and not any(_uses(text, lever) for lever in h["levers"]):
            missing.setdefault(h["id"], h["levers"])
    return missing


def check_formula(template, rows, label):
    """Refuse a formula that names none of the levers of a hypothesis it is declared for."""
    missing = missing_levers(template, rows)
    if not missing:
        return
    names = "; ".join(f"{hid}: {', '.join(levers)}" for hid, levers in missing.items())
    raise ValueError(
        f"proxy_formula template: {label} is declared for {', '.join(missing)} but its expression, equation and "
        f"inputs name none of the levers the hypothesis set gives {'it' if len(missing) == 1 else 'them'} ({names}). "
        "A hypothesis's formula computes how its own lever moves the KPI; terms for other levers may be added. When "
        "the equation writes the lever under another symbol, add the lever's name exactly as listed above to the "
        "template's inputs (for example \"inputs\": [\"<lever name>: <the symbol it is in the equation>\"]) and "
        "save again; the hypothesis set needs no new version for this. If the formula tests another hypothesis, "
        "declare that one in hypothesis_ids. Nothing was saved")


def _active(h):
    return not (h.get("deferred") or h.get("not_computable") or h.get("merged"))


def _label(formula):
    template = formula.get("template") or {}
    return f"{template.get('formula_id') or 'formula'} {formula['ref']}"


def check_leaderboard(board, formula_refs):
    """Refuse a leaderboard that leaves out an active hypothesis of the sheets' hypothesis sets.

    A sheet stands for a hypothesis when its formula's hypothesis_ids name that hypothesis alone.
    """
    formulas = {f["ref"]: f for f in board["proxy_formulas"]}
    lineage = list(dict.fromkeys(ref for formula_ref in formula_refs
                                 for ref in (formulas.get(formula_ref) or {}).get("hypothesis_refs", [])))
    rows = current_rows(board, lineage)
    if not rows:
        return
    covered, shared = set(), []
    for ref in formula_refs:
        template = (formulas.get(ref) or {}).get("template") or {}
        ids = template.get("hypothesis_ids") or []
        if len(ids) == 1:
            covered.add(ids[0])
        elif len(ids) > 1:
            shared.append(f"{template.get('formula_id') or ref} names {', '.join(ids)} together")
    missing = []
    for row in rows:
        for h in row["items"]:
            if not _active(h) or h["id"] in covered or any(h["id"] == m[0] for m in missing):
                continue
            existing = [formulas[ref] for ref in h.get("proxy_formula_refs") or []
                        if ref in formulas and not formulas[ref].get("superseded_by")
                        and ((formulas[ref].get("template") or {}).get("hypothesis_ids") or []) == [h["id"]]]
            missing.append((h["id"], existing))
    if not missing:
        return
    parts = [f"{hid} (" + ("its formula " + "; ".join(_label(f) for f in existing) + " has no sheet here"
                           if existing else "no formula of its own yet") + ")"
             for hid, existing in missing]
    raise ValueError(
        "research_leaderboard needs a sheet for every active hypothesis, each from a formula whose hypothesis_ids "
        "name that hypothesis alone, so that a candidate's standing can be read hypothesis by hypothesis. Missing: "
        + "; ".join(parts) + "."
        + (f" ({'; '.join(shared)}: such a sheet may stay as an extra sheet, but it stands for none of them.)"
           if shared else "")
        + " Add the missing sheets (values for every baseline and candidate). A hypothesis without a formula needs "
        "one first; one that truly cannot be computed, is queued by the budget, or is one mechanism with another is "
        "marked so in a new version of the hypothesis set (proxy_status not_computable with missing, deferred with "
        "basis budget, or merged with into). Nothing was saved")


def _same(left, right, samples):
    return all(abs(left[s] - right[s]) <= 1e-12 * max(1.0, abs(left[s]), abs(right[s])) for s in samples)


def check_distinct(sheets, samples):
    """Refuse two sheets that give every sample the same value: one formula under two labels.

    sheets: [(label, {sample: value})]. Copies would count as sheets that agree, and robust_surpass
    rests on agreement between sheets.
    """
    pairs = [(a[0], b[0]) for i, a in enumerate(sheets) for b in sheets[i + 1:] if _same(a[1], b[1], samples)]
    if not pairs:
        return
    raise ValueError(
        "research_leaderboard: " + "; ".join(f"{a} and {b}" for a, b in pairs) + " give the same value for every "
        "baseline and candidate, so they are one formula under two labels; copies would count as sheets that agree "
        "and make a surpass look robust. Keep one sheet per formula. Each hypothesis's sheet needs a formula of its "
        "own mechanism and quantity. If two hypotheses rest on one quantity, they are one mechanism here: merge them "
        "(proxy_status merged, into) or defer one with the reason, in a new version of the hypothesis set. Do not add "
        "a term only to make the numbers differ; every term needs its mechanism's rationale. Nothing was saved")
