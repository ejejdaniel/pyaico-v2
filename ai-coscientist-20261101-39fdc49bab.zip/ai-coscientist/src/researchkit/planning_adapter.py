"""Compose the two opt-in extensions without changing research delivery."""

from planningkit.tools import TOOLS as PLANNING_TOOLS
from planningkit.turn import PlanningTurn
from researchkit.tools import TOOLS as RESEARCH_TOOLS
from researchkit.turn import ResearchTurn


class ResearchPlanningTurn:
    def __init__(self, app, session_id: str, user_message_id: str):
        self.app = app
        self.session_id = session_id
        self.research = ResearchTurn(app, session_id, user_message_id)
        self.planning = PlanningTurn(app, session_id, user_message_id)

    def context(self) -> str:
        return "\n\n".join(filter(None, [self.research.context(), self.planning.context()]))

    def feedback(self) -> str | None:
        return self.research.feedback()

    def present(self, text: str, status: str) -> str:
        return self.research.present(text, status)

    def delivery_state(self) -> str | None:
        # Without it the loop took v38's clean delivery for none and told the agent to keep working.
        return self.research.delivery_state()


TOOLS = [*RESEARCH_TOOLS, *PLANNING_TOOLS]
TURN_EXTENSION = ResearchPlanningTurn
