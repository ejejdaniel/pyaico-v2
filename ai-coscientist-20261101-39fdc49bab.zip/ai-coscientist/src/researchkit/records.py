"""Content-addressed copies of research files; not a scientific approval system."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import shutil
import time
from html.parser import HTMLParser


def _rename_staging(staging: Path, target: Path) -> None:
    # Windows scanners briefly hold handles on freshly written files, so the
    # directory rename can fail with access denied. Retry only that case.
    for attempt in range(6):
        try:
            staging.rename(target)
            return
        except PermissionError:
            if target.exists() or attempt == 5:
                raise
            time.sleep(0.05 * 2 ** attempt)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8")


def local_path(root: Path, name: str) -> Path:
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f"Path is outside this research workspace: {name}")
    return path


MIN_PREFIX = 8
_REF_PATH = re.compile(r"^\.research/records/([^/]+)/record\.json$")
_REF_ANYWHERE = re.compile(r"\.research[\\/]+records[\\/]+([0-9a-fA-F]{%d,})" % MIN_PREFIX)
_HEX = re.compile(r"^[0-9a-f]{%d,}$" % MIN_PREFIX)


def _ref_field(key) -> bool:
    return isinstance(key, str) and (key.endswith("_ref") or key.endswith("_refs")
                                     or key in ("depends_on", "revises"))


def resolve_references(value, root: Path):
    """(value with record references the host can identify made exact, notes on each change).

    The board names records by the first 8 hex characters; models copy those but
    cannot reliably copy the remaining 56. A reference whose record does not exist
    is resolved when its leading hex characters (at least 8) match exactly one saved
    record better than any other; the result is the exact relative record.json
    path, so the record's content is still verified by its hash. Anything else is
    left unchanged for the tool to reject as before.
    """
    folder = Path(root) / ".research" / "records"
    names = None
    notes = []

    def saved():
        nonlocal names
        if names is None:
            names = sorted(p.name for p in folder.iterdir()
                           if p.is_dir() and not p.name.startswith(".staging-")) if folder.is_dir() else []
        return names

    def resolve(text, token):
        lead = re.match(r"[0-9a-f]*", token.lower()).group(0)
        if len(lead) < MIN_PREFIX:
            return text
        best, length = [], 0
        for name in saved():
            shared = len(os.path.commonprefix([lead, name]))
            if shared > length:
                best, length = [name], shared
            elif shared == length and shared:
                best.append(name)
        if length < MIN_PREFIX or len(best) != 1:
            return text
        exact = f".research/records/{best[0]}/record.json"
        if exact != text:
            notes.append(f"{text} -> {exact}")
        return exact

    def fix(text, key):
        match = _REF_PATH.match(text)
        if match:
            return text if (folder / match.group(1) / "record.json").is_file() else resolve(text, match.group(1))
        if not _ref_field(key):
            return text
        match = _REF_ANYWHERE.search(text)
        if match:
            return resolve(text, match.group(1))
        return resolve(text, text) if _HEX.match(text.lower()) else text

    def walk(item, key=None):
        if isinstance(item, str):
            return fix(item, key)
        if isinstance(item, list):
            return [walk(entry, key) for entry in item]
        if isinstance(item, dict):
            return {name: walk(entry, name) for name, entry in item.items()}
        return item

    return walk(value), notes


def read_record(root: Path, ref: str, *, check_read=None) -> dict:
    path = local_path(root, ref)
    records = (root / ".research" / "records").resolve()
    if path.name != "record.json" or path.parent.parent != records:
        raise ValueError("Expected an exact .research/records/<hash>/record.json path")
    return _read_record(path, path.parent.name, check_read=check_read)


def _read_record(path: Path, expected_hash: str, *, check_read=None) -> dict:
    if check_read:
        check_read(path)
    raw = path.read_bytes()
    if digest(raw) != expected_hash:
        raise ValueError(f"Record content has changed: {path}")
    result = json.loads(raw)
    for item in result["files"]:
        saved = local_path(path.parent, item["snapshot"])
        if check_read:
            check_read(saved)
        data = saved.read_bytes()
        if digest(data) != item["sha256"]:
            raise ValueError(f"Recorded file content has changed: {saved}")
        if len(data) != item["bytes"]:
            raise ValueError(f"Recorded file byte count does not match: {saved}")
    return result


def _read_dependencies(root: Path, refs: list[str], *, check_read=None) -> dict:
    # The cache belongs to one validation pass; never reuse it after a write.
    verified = {}
    pending = list(reversed(refs))
    while pending:
        ref = local_path(root, pending.pop()).relative_to(root.resolve()).as_posix()
        if ref in verified:
            continue
        record = read_record(root, ref, check_read=check_read)
        verified[ref] = record
        pending.extend(reversed(record["depends_on"]))
    return verified


class _InlineReferences(HTMLParser):
    def __init__(self):
        super().__init__()
        self.inline_code = []
        self._pre = 0
        self._code = None

    def handle_starttag(self, tag, attrs):
        if tag == "pre":
            self._pre += 1
        if tag == "code" and not self._pre:
            self._code = []

    def handle_data(self, data):
        if self._code is not None:
            self._code.append(data)

    def handle_endtag(self, tag):
        if tag == "code" and self._code is not None:
            self.inline_code.append("".join(self._code))
            self._code = None
        if tag == "pre":
            self._pre = max(0, self._pre - 1)


def _markdown_references(path: Path, data: bytes):
    parser = _InlineReferences()
    if path.suffix.lower() not in {".md", ".markdown"}:
        return parser
    from markdown import markdown
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return parser  # Preserve opaque bytes; do not invent references from replacement text.
    parser.feed(markdown(text, extensions=["fenced_code"]))
    return parser


def publish(root: Path, *, kind: str, title: str, files: list[str], depends_on: list[str],
            check_read=None, resolve_source=None, resolve_path=None) -> dict:
    if not isinstance(kind, str) or not kind.strip() or not isinstance(title, str) or not title.strip():
        raise ValueError("kind and title must be nonblank text")
    if not files or not all(isinstance(p, str) and p.strip() for p in files):
        raise ValueError("Provide the actual research files to preserve")
    contents = {}
    source_contents = {}
    seen = set()
    pending = [local_path(root, name) for name in files]
    if len(set(pending)) != len(pending):
        raise ValueError("Duplicate file in explicit files")
    review_files = [path for path in pending if path.name == "review.json"]
    if kind == "review" and len(review_files) != 1:
        raise ValueError("review.files: explicitly select exactly one review.json; see final-lca/references/review.md")

    def add_sources(items, reference):
        for name, source_data in items:
            source = local_path(root, str(name))
            if check_read:
                check_read(source)
            if source in source_contents and source_contents[source] != source_data:
                raise ValueError(f"Conflicting source receipt: {reference}")
            source_contents[source] = source_data
            if source in contents:
                contents[source] = source_data
            pending.append(source)

    for path in pending:
        relative = path.relative_to(root.resolve()).as_posix()
        if relative in seen:
            continue
        seen.add(relative)
        if check_read:
            check_read(path)
        if resolve_path and path not in source_contents:
            native = resolve_path(path)
            if native is not None:
                add_sources(native, str(path))
                if path not in source_contents:
                    raise ValueError(f"Native resolver did not preserve selected path: {path}")
        data = source_contents[path] if path in source_contents else path.read_bytes()
        contents[path] = data
        if resolve_source:
            references = _markdown_references(path, data)
            for reference in references.inline_code:
                # Exact receipts come from the session store, not editable projections.
                add_sources(resolve_source(reference), reference)
    inputs = [{"source_path": path.relative_to(root.resolve()).as_posix(),
               "snapshot": "files/" + path.relative_to(root.resolve()).as_posix(),
               "sha256": digest(data), "bytes": len(data)} for path, data in contents.items()]
    dependencies = []
    for ref in depends_on:
        relative = local_path(root, ref).relative_to(root.resolve()).as_posix()
        if relative in dependencies:
            raise ValueError("Duplicate dependency")
        dependencies.append(relative)
    verified = _read_dependencies(root, dependencies, check_read=check_read)
    if kind == "review":
        from .review import validate
        try:
            validate(root, contents[review_files[0]], dependencies, verified, check_read=check_read)
        except ValueError as exc:
            candidate = review_files[0]
            raise ValueError(f"{exc}\nReview was not published. The candidate was not modified: {candidate}\n"
                             f"Validated candidate sha256: {digest(contents[candidate])}. "
                             "Read the cited frozen sources and use edit to correct the affected locations; "
                             "keep unaffected checks and saved research work.") from exc
    body = {"kind": kind, "title": title, "files": inputs, "depends_on": dependencies}
    raw = encoded(body)
    parent = local_path(root, ".research/records")
    parent.mkdir(parents=True, exist_ok=True)
    target = parent / digest(raw)
    ref = (target / "record.json").relative_to(root).as_posix()
    if not target.exists():
        staging = Path(tempfile.mkdtemp(prefix=".staging-", dir=parent))
        try:
            for item, data in zip(inputs, contents.values()):
                destination = staging / item["snapshot"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
            (staging / "record.json").write_bytes(raw)
            _read_record(staging / "record.json", target.name)
            try:
                _rename_staging(staging, target)
            except OSError:
                if not target.exists():
                    raise
        finally:
            if staging.exists():
                shutil.rmtree(staging)
    # Success describes the committed bytes, including every selected ancestor.
    # If this fails after rename, preserve the record and report the failure.
    stored = _read_dependencies(root, [ref], check_read=check_read)
    return {"record_path": ref, **stored[ref]}


def present(root: Path, record: dict) -> dict:
    """Resolve existing snapshot fields for tool output, leaving stored manifests portable."""
    folder = local_path(root, record["record_path"]).parent
    return {**record, "files": [{**item, "snapshot": str(local_path(folder, item["snapshot"]))}
                                for item in record["files"]]}


def inventory(root: Path, *, check_read=None) -> list[dict]:
    return [{"record_path": p.relative_to(root).as_posix(),
             **read_record(root, p.relative_to(root).as_posix(), check_read=check_read)}
            for p in sorted((root / ".research" / "records").glob("*/record.json"))
            if not p.parent.name.startswith(".staging-")]


def unbound_reviews(root: Path, record: dict, *, check_read=None) -> list[dict]:
    """Saved reviews of a new record's direct inputs that the record does not depend on.

    Called right after publication, so every listed review already existed when
    the record was saved. This is mechanical provenance only: it never decides
    whether the record responds to the review or whether the review is right.
    """
    if record["kind"] == "review":
        return []
    saved = {item["record_path"]: item for item in inventory(root, check_read=check_read)}
    upstream, pending = set(), list(record["depends_on"])
    while pending:
        ref = pending.pop()
        if ref not in upstream and ref in saved:
            upstream.add(ref)
            pending.extend(saved[ref]["depends_on"])
    direct = set(record["depends_on"])
    found = []
    for ref, review in saved.items():
        if review["kind"] != "review" or ref in upstream or ref == record["record_path"]:
            continue
        shared = sorted(direct.intersection(review["depends_on"]))
        if shared:
            found.append({"review": ref, "shared_inputs": shared})
    return found


def unbound_review_notice(record_ref: str, found: list[dict]) -> str:
    lines = [
        "宿主依賴檢查（機械比對，不是科學判斷）：此紀錄直接使用的輸入已有既存審查，但此紀錄沒有依賴該審查。",
        "若此紀錄是對審查結果的處置、修訂或沿用其判斷，請另存新紀錄並把該審查列入 depends_on；",
        "已保存紀錄不可改寫。若此紀錄與該審查無關，說明即可，不必重做。",
    ]
    for item in found:
        lines.append(f"- {record_ref} 未依賴 review {item['review']}；共同輸入：" + _edge_list(item["shared_inputs"]))
    return "\n".join(lines)


_DELIVERY_KINDS = {"final_lca", "report", "review", "user_report"}


def delivery_note(root: Path) -> str:
    """Host listing of stored delivery edges. It does not judge review applicability."""
    folder = root / ".research" / "records"
    if not folder.is_dir():
        return ""
    header = (
        "## 宿主依賴表\n\n"
        f"工作目錄：`{root}`\n\n"
        "以下依這個工作目錄的 record.json 現算，只列出 kind 為 review、final_lca、report、user_report 的成果。"
        "宿主沒有判斷舊審查是否仍適用，也沒有指定哪一筆是目前版本。"
    )
    try:
        saved = inventory(root)
    except Exception as exc:
        return header + f"\n\n未能讀取已保存成果：{exc}"
    rows = [record for record in saved if record.get("kind") in _DELIVERY_KINDS]
    if not rows:
        return ""
    reverse = direct_dependents(saved)
    lines = [header, ""]
    for record in sorted(rows, key=lambda item: item["record_path"]):
        incoming = reverse.get(record["record_path"], [])
        lines.append(f"- `{record['kind']}` `{record['record_path']}`")
        lines.append("  - depends_on: " + _edge_list(record.get("depends_on") or []))
        lines.append("  - depended_on_by: " + _edge_list(
            [f"{item['kind']} {item['record_path']}" for item in incoming]))
    return "\n".join(lines)


def _published_receipts(history: list[dict]) -> list[dict]:
    """Only matched successful tool returns, not attempts or prose mentions."""
    calls = {}
    published = []
    for message in history:
        if message.get("role") == "assistant":
            for call in message.get("tool_calls") or []:
                if call.get("name") == "research_record":
                    calls[call["id"]] = call.get("arguments") or {}
        elif message.get("role") == "tool" and message.get("name") == "research_record":
            arguments = calls.get(message.get("tool_call_id"), {})
            if not isinstance(arguments, dict) or not isinstance(arguments.get("kind"), str):
                continue
            try:
                receipt = json.loads(message.get("content") or "")
            except (TypeError, ValueError):
                continue
            if (isinstance(receipt, dict) and receipt.get("kind") == arguments["kind"]
                    and isinstance(receipt.get("record_path"), str) and receipt["record_path"].strip()):
                published.append(receipt)
        elif message.get("role") == "tool" and message.get("name") == "research_deliver":
            # research_deliver saves the final_lca and the user_report in one call.
            try:
                value = json.loads((message.get("content") or "").partition("\n\nHost note: ")[0])
            except (TypeError, ValueError):
                continue
            for kind in ("final_lca", "user_report"):
                receipt = value.get(kind) if isinstance(value, dict) else None
                if (isinstance(receipt, dict) and receipt.get("kind") == kind
                        and isinstance(receipt.get("record_path"), str) and receipt["record_path"].strip()):
                    published.append(receipt)
    return published


def selected_delivery(history: list[dict]) -> str | None:
    """The last successful user_report selection; never infer it from filenames."""
    return next((r["record_path"] for r in reversed(_published_receipts(history))
                 if r["kind"] == "user_report"), None)


def delivery_progress(root: Path, history: list[dict], *, check_read=None) -> str:
    """Rebuild a small factual view from this session's receipts and frozen records."""
    receipts = _published_receipts(history)
    selected = next((r["record_path"] for r in reversed(receipts) if r["kind"] == "user_report"), None)
    if not selected:
        return ""
    selection_index = max(i for i, receipt in enumerate(receipts)
                          if receipt["record_path"] == selected and receipt["kind"] == "user_report")
    saved = {}

    def read(ref):
        if ref not in saved:
            saved[ref] = read_record(root, ref, check_read=check_read)
        return saved[ref]

    try:
        selected_record = read(selected)
        reports = {ref for ref in selected_record["depends_on"] if read(ref)["kind"] == "report"}
        bound = list(selected_record["depends_on"])
        for ref in selected_record["depends_on"]:
            if read(ref)["kind"] == "final_lca":
                bound.extend(read(ref)["depends_on"])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return f"宿主已保存交付定位：`{selected}`；目前無法讀回：{exc}"
    lines = [
        "## 已保存的交付工作（宿主讀回，不是新的研究要求）",
        f"本工作階段目前選定的 user_report：`{selected}`。",
        "該交付直接選入的 report：" + _edge_list(sorted(reports)),
        "以下來自本工作階段的成功發布回條及其明確依賴，只列保存事實與宣告審查範圍，不代表科學上適用或整份委託完成。",
        "report 不會更新交付選擇；只有成功發布 user_report 才會更新。完整原文請讀精確 record.json 的 files[].snapshot。",
    ]
    recent = {r["record_path"] for r in receipts[selection_index:]}
    refs = dict.fromkeys([r["record_path"] for r in reversed(receipts) if r["kind"] in _DELIVERY_KINDS] + bound)
    omitted = 0
    for ref in refs:
        try:
            record = read(ref)
            if record["kind"] not in _DELIVERY_KINDS:
                continue
            if ref not in recent and ref not in bound and not reports.intersection(record["depends_on"]):
                continue
            row = [f"- {record['kind']} `{ref}`", "  depends_on: " + _edge_list(record["depends_on"])]
            if record["kind"] == "review":
                files = [f for f in record["files"] if Path(f["source_path"]).name == "review.json"]
                if len(files) == 1:
                    path = local_path(local_path(root, ref).parent, files[0]["snapshot"])
                    review = json.loads(path.read_bytes().decode("utf-8-sig"))
                    row.append("  review.json.reviewed_refs（作者宣告）: " + _edge_list(review["reviewed_refs"]))
                else:
                    row.append("  未保存 review.json 的精確審查範圍。")
            text = "\n".join(row)
            if len(text) > 4000:
                text = f"- {record['kind']} `{ref}`；依賴及範圍過長，未在此展開，請讀此精確紀錄與其 review.json。"
        except (OSError, ValueError, KeyError, TypeError) as exc:
            text = f"- `{ref}` 已由成功回條或其依賴選入，但目前無法讀回，不作為可沿用的證明：{exc}"
        # Bound only this derived index, never the stored receipt or its exact refs.
        if sum(len(line) for line in lines) + len(text) > 12000:
            omitted += 1
            continue
        lines.append(text)
    if omitted:
        lines.append(f"另有 {omitted} 筆紀錄未展開；完整成功回條仍在本工作階段的工具歷史，可依原引用重讀。")
    return "\n".join(lines)


def delivery_issues(root: Path, ref: str, *, check_read=None) -> list[str]:
    """Check the selected delivery's review bindings, never scientific support.

    Historical ancestors can remain. Only the report and Final LCA selected
    directly by this user_report, and their actual review scope, are checked.
    """
    from .review import validate

    try:
        verified = _read_dependencies(root, [ref], check_read=check_read)
        ref = local_path(root, ref).relative_to(root.resolve()).as_posix()
        selected = verified[ref]
        if selected["kind"] != "user_report":
            return [f"Selected delivery is not a user_report: {ref}"]
        reports = [r for r in selected["depends_on"] if verified[r]["kind"] == "report"]
        lcas = [r for r in selected["depends_on"] if verified[r]["kind"] == "final_lca"]
        issues = []
        if not reports:
            issues.append("user_report must directly select the report being delivered.")
        if not lcas:
            issues.append("user_report must directly select its saved final_lca judgment.")
        covered = set()
        for lca_ref in lcas:
            lca = verified[lca_ref]
            answers = _final_lca_answers(root, lca_ref, lca)
            bound = [r for r in lca["depends_on"] if verified[r]["kind"] == "report"]
            for missing in sorted(set(bound) - set(reports)):
                issues.append(f"final_lca {lca_ref} selects report {missing}, outside this delivery's reports.")
            current = set(bound) & set(reports)
            if not current:
                issues.append(f"final_lca {lca_ref} does not directly select any report in this delivery.")
            reviewed = set()
            for review_ref in lca["depends_on"]:
                review = verified[review_ref]
                if review["kind"] != "review":
                    continue
                files = [f for f in review["files"] if Path(f["source_path"]).name == "review.json"]
                if len(files) != 1:
                    # Old prose reviews remain evidence, not a fabricated exact scope.
                    continue
                data = local_path(local_path(root, review_ref).parent, files[0]["snapshot"]).read_bytes()
                own_dependencies = _read_dependencies(root, review["depends_on"], check_read=check_read)
                validate(root, data, review["depends_on"], own_dependencies, check_read=check_read)
                review_value = json.loads(data.decode("utf-8-sig"))
                reviewed.update(review_value["reviewed_refs"])
                if answers is not None:
                    # A review of an earlier version of the report (the reviewed draft) covers it once the
                    # Final-LCA answers every check that review did not support (research_deliver).
                    from .delivery import answers_cover, report_versions
                    for report_ref in current - reviewed:
                        if (set(review_value["reviewed_refs"]) & report_versions(root, report_ref, check_read=check_read)
                                and answers_cover(answers, review_ref, review_value.get("checks") or [])):
                            reviewed.add(report_ref)
            for missing in sorted(current - reviewed):
                issues.append(f"final_lca {lca_ref} lacks a saved review whose review.json.reviewed_refs includes {missing}.")
            covered.update(current & reviewed)
        for missing in sorted(set(reports) - covered):
            issues.append(f"Delivery report {missing} has no matching final_lca -> review -> reviewed_refs chain.")
        return issues
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return [f"Cannot verify selected delivery {ref}: {exc}"]


def _final_lca_answers(root: Path, lca_ref: str, lca: dict):
    """The final_lca.json research_deliver wrote into a final_lca record, or None."""
    files = [f for f in lca["files"] if Path(f["source_path"]).name == "final_lca.json"]
    if len(files) != 1:
        return None
    try:
        value = json.loads(local_path(local_path(root, lca_ref).parent, files[0]["snapshot"]).read_bytes())
    except (OSError, ValueError):
        return None
    return value if isinstance(value, dict) else None


def delivery_repair_packet(ref: str, issues: list[str]) -> str:
    return "\n".join([
        "宿主交付檢查：這是目前研究委託的未完成交接，不是新的人類委託。",
        f"依本工作階段成功發布回條，代理選定的 user_report 是 `{ref}`。",
        "尚未接妥的正式成果：", *[f"- {issue}" for issue in issues], "",
        "繼續完成原委託，只處理實際缺口。目前提示的『已保存的交付工作』列出成功回條及其依賴；",
        "先核對其內容及適用範圍，可沿用者直接引用，不因交付接錯就重建審查或重跑計算。",
        "只有確實缺少審查時，才依 final-lca/SKILL.md 與 references/review.md 完成補審。",
        "檔名或口頭完成宣稱不會選定交付；需以 kind=user_report 成功發布正確依賴。",
        "真正無法完成時，說明具體阻礙及未完成部分；不能以口頭完成宣稱代替缺少的成果。",
    ])


def _edge_list(items: list[str]) -> str:
    if not items:
        return "（無）"
    return "、".join(f"`{item}`" for item in items)


def direct_dependents(records: list[dict]) -> dict[str, list[dict]]:
    """Reverse the stored depends_on edges. This does not choose a current version."""
    grouped: dict[str, list[dict]] = {}
    seen: dict[str, set[str]] = {}
    for record in records:
        dependent = {"record_path": record["record_path"], "kind": record["kind"]}
        for ref in record.get("depends_on") or []:
            if ref in seen.setdefault(record["record_path"], set()):
                continue
            seen[record["record_path"]].add(ref)
            grouped.setdefault(ref, []).append(dependent)
    for refs in grouped.values():
        refs.sort(key=lambda item: item["record_path"])
    return grouped


def workspace_differences(root: Path, refs: list[str], *, check_read=None,
                          paths: list[str] | None = None) -> list[dict]:
    """Compare selected snapshots with working files, without judging validity."""
    pending = [(ref, [], i) for i, ref in reversed(list(enumerate(refs)))]
    visited = set()
    differences = []
    cached = {}
    while pending:
        ref, ancestry, origin = pending.pop()
        path = local_path(root, ref)
        relative = path.relative_to(root.resolve()).as_posix()
        visit = (origin, relative) if paths is not None else relative
        if visit in visited:
            continue
        visited.add(visit)
        if relative not in cached:
            record = read_record(root, relative, check_read=check_read)
            changed = []
            for item in record["files"]:
                working = local_path(root, item["source_path"])
                if check_read:
                    check_read(working)
                try:
                    current_hash = digest(working.read_bytes())
                except FileNotFoundError:
                    current_hash = None
                if current_hash != item["sha256"]:
                    changed.append({
                        "record_path": relative,
                        "source_path": item["source_path"],
                        "snapshot_path": (path.parent / item["snapshot"]).relative_to(root.resolve()).as_posix(),
                        "recorded_sha256": item["sha256"],
                        "working_sha256": current_hash,
                        "status": "missing" if current_hash is None else "changed",
                    })
            cached[relative] = (record, changed)
            differences.extend(changed)
        record, changed = cached[relative]
        # Records are named by their first 8 hash characters, which the tools accept as references.
        chain = [*ancestry, f"{record['kind']} {path.parent.name[:8]}"]
        pending.extend((child, chain, origin) for child in reversed(record["depends_on"]))
        if paths is not None:
            # One concrete witness per selected root/ancestor, not all DAG paths.
            paths.extend(" -> ".join([*chain, f"{item['source_path']} ({item['status']})"]) for item in changed)
    return differences
