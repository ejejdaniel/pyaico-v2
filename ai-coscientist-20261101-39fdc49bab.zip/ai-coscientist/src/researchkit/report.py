"""Render authored research reports, printing the same HTML for PDF delivery."""

from __future__ import annotations

from pathlib import Path

from researchkit import report_citations
from researchkit.report_html import EVIDENCE_FILE, build_evidence_html, build_html, layout_status
from researchkit.report_pdf import export_pdf
from researchkit.report_style import style_report


def render(markdown_path: Path, destination: Path, *, evidence: list[dict] | None = None,
           mindmaps: list[dict] | None = None, saved_literature: set[str] | None = None) -> dict:
    """saved_literature: identifiers of the literature the research saved (see
    report_citations.saved_identifiers); when given, bibliography entries are checked against it."""
    markdown_path, destination = Path(markdown_path), Path(destination)
    authored = markdown_path.read_text(encoding="utf-8-sig")
    if not authored.strip():
        raise ValueError("Report Markdown is empty")
    document = build_html(markdown_path, destination, evidence=evidence or [], mindmaps=mindmaps or [])
    destination.mkdir(parents=True, exist_ok=False)
    html_path, pdf_path = destination / "report.html", destination / "report.pdf"
    html_path.write_text(document, encoding="utf-8", newline="")
    printed = export_pdf(html_path, pdf_path)
    originals = {}
    if evidence:
        # The complete saved originals are a separate file, so the report stays readable.
        evidence_html, evidence_pdf = destination / EVIDENCE_FILE, destination / "evidence.pdf"
        evidence_html.write_text(build_evidence_html(evidence, markdown_path.stem), encoding="utf-8", newline="")
        evidence_printed = export_pdf(evidence_html, evidence_pdf)
        originals = {"evidence_html_path": str(evidence_html), "evidence_pdf_path": str(evidence_pdf),
                     "evidence_pages": evidence_printed["pages"]}
    layout = layout_status(markdown_path)
    if layout["layout"] == "reader":
        layout_note = ("Reader layout: the answer and the mechanism come first; notes, mind maps and evidence "
                       "files follow as appendices.")
    elif layout["layout"] == "full":
        layout_note = ("Older full layout (mind maps in section 2, evidence in section 8). A report for people "
                       "reads better in the reader layout: see reader_layout_headings.")
    else:
        diff = layout["first_difference"]
        layout_note = (f"Generic layout (mind maps and evidence appended at the end). The reader layout needs the "
                       f"level-two headings listed in reader_layout_headings, in order (each may add a subtitle "
                       f"after a colon); heading {diff['position']} should be {diff['expected']!r}, found "
                       f"{diff['found']!r}. Keep the generic layout if the commission needs different sections.")
    return {
        "html_path": str(html_path),
        "pdf_path": str(pdf_path),
        "pages": printed["pages"],
        **originals,
        "layout": layout,
        "layout_note": layout_note,
        "style": style_report(authored),
        "citations": report_citations.check(authored, saved_literature),
        "renderer": f"Chromium ({Path(printed['browser']).name})",
        "note": (
            "Printed the same saved HTML, including all explicitly selected mindmaps; explicitly selected "
            "frozen evidence is indexed in the report and printed in full to evidence.html and evidence.pdf. "
            f"HTML SHA-256: {printed['html_sha256']}. "
            "Inspect layout before claiming delivery verified."
        ),
    }
