"""Host checks of a report's candidate verdicts and table numbers against the saved records.

A reviewer spends minutes reading what the host can compare at once. In LIT v23 the review's
decisive finding was that the report called E3 a robust surpass although the saved noise check
gave that verdict a 0% chance; v21's report described orders that its own saved checks did not
show. These checks read the report Markdown and report, line by line:

- a candidate named with a leaderboard verdict different from the newest leaderboard's verdict
  for it;
- a candidate called a robust surpass when a saved noise check (calc kind=sensitivity) gives that
  verdict less than half of the draws;
- a number with two or more decimals in a Markdown table row about a candidate that matches none
  of its values, margins or ranks in the newest leaderboard holding it, at the precision shown;
- a rank the prose gives the one candidate a line names (平均名次 9.375) that is none of its ranks;
- a reader-layout mechanism chapter that writes no equation at all.

They are facts for the author to answer, not judgments: a report may quote a verdict to reject it.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from researchkit import records
from researchkit.report_evidence import resolve

VERDICTS = {
    "robust_surpass": ("robust_surpass", "robust surpass", "穩健超越"),
    "tradeoff_surpass": ("tradeoff_surpass", "tradeoff surpass", "取捨式超越", "取捨超越"),
    "conditional_surpass": ("conditional_surpass", "conditional surpass", "條件式超越", "條件超越"),
    "surpass_one_sheet": ("surpass_one_sheet", "單表超越"),
    "no_surpass": ("no_surpass", "未超越"),
}
ROBUST_SHARE = 0.5
# Two or more decimals: computed values. Measured inputs (one decimal, as 12.5) and counts are left alone.
_NUMBER = re.compile(r"(?<![\w.])[-−+]?\d+\.\d{2,}(?![\w.])")
MAX_FINDINGS = 30


def _json_files(root, record, check_read):
    for item in record["files"]:
        if not item["source_path"].endswith(".json"):
            continue
        try:
            frozen, = resolve(root, [{"record_ref": record["record_path"], "source_path": item["source_path"]}],
                              check_read=check_read)
            yield item["source_path"], json.loads(frozen["text"])
        except (OSError, ValueError, KeyError, TypeError):
            continue


def _saved_at(root, record):
    try:
        return (Path(root) / record["record_path"]).stat().st_mtime_ns
    except OSError:
        return 0


def facts(root, check_read=None):
    """{sample: {"verdict", "leaderboard", "values"}} from the newest leaderboard holding each sample, and
    {candidate: {"robust", "calc"}} from saved noise checks."""
    root = Path(root)
    saved = records.inventory(root, check_read=check_read) if (root / ".research" / "records").is_dir() else []
    samples, noise = {}, {}
    for record in sorted(saved, key=lambda item: _saved_at(root, item)):
        if record["kind"] == "leaderboard":
            for _, value in _json_files(root, record, check_read):
                if not isinstance(value, dict) or not isinstance(value.get("sheets"), list):
                    continue
                values = {}
                for sheet in value["sheets"]:
                    for key in ("values", "raw_values"):
                        for sample, number in (sheet.get(key) or {}).items():
                            if isinstance(number, (int, float)) and not isinstance(number, bool):
                                values.setdefault(sample, []).append(float(number))
                    # A quantitative model's sheet gives each sample a predicted range instead.
                    for sample, pair in ((sheet.get("model") or {}).get("ranges") or {}).items():
                        for number in pair if isinstance(pair, list) else []:
                            if isinstance(number, (int, float)) and not isinstance(number, bool):
                                values.setdefault(sample, []).append(float(number))
                verdicts, ranks = {}, {}
                for row in value.get("candidates") or []:
                    if not isinstance(row, dict):
                        continue
                    verdicts[row.get("id")] = row.get("verdict")
                    if _is_number(row.get("mean_rank")):
                        ranks.setdefault(row.get("id"), []).append(float(row["mean_rank"]))
                    # A report may also quote a candidate's margin over the best historical sample.
                    for margin in (row.get("margins") or {}).values():
                        gap = margin.get("better_by") if isinstance(margin, dict) else None
                        if isinstance(gap, (int, float)) and not isinstance(gap, bool):
                            values.setdefault(row.get("id"), []).extend([float(gap), -float(gap)])
                # A candidate's ranks: its mean rank and its rank on each sheet (baselines rank on every board).
                for sheet in value["sheets"]:
                    for sample, rank in (sheet.get("ranks") or {}).items():
                        if sample in ranks and _is_number(rank):
                            ranks[sample].append(float(rank))
                for sample, numbers in values.items():
                    samples[sample] = {"verdict": verdicts.get(sample), "leaderboard": record["record_path"],
                                       "values": numbers + ranks.get(sample, []), "ranks": ranks.get(sample, [])}
        elif record["kind"] == "calc":
            for _, value in _json_files(root, record, check_read):
                header = value.get("calc") if isinstance(value, dict) else None
                result = value.get("result") if isinstance(value, dict) else None
                if not (isinstance(header, dict) and header.get("kind") == "sensitivity" and isinstance(result, dict)):
                    continue
                for candidate, row in (result.get("candidates") or {}).items():
                    shares = row.get("verdicts") if isinstance(row, dict) else None
                    if isinstance(shares, dict):
                        noise[candidate] = {"robust": float(shares.get("robust_surpass", 0.0)),
                                            "calc": record["record_path"], "shares": shares}
    return samples, noise


def _is_number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


# A rank the prose gives a candidate: 平均名次 9.375, 名次為 3, mean rank 14.875.
RANK = re.compile(r"(?:平均名次|名次|mean[_ ]rank|rank)\s*(?:[:：=]|為|是)?\s*([-−]?\d+(?:\.\d+)?)", re.I)
# The reader layout's mechanism chapter (the report skill's outline) and an equation drawn by the renderer.
MECHANISM = re.compile(r"^##\s*2\.\s*機制")
EQUATION = re.compile(r"\$\$.+?\$\$|(?<!\$)\$[^$\n]+?\$(?!\$)", re.S)


def _matches(value, text):
    """Whether a value rounds to the number as written (an integer as written too)."""
    decimals = len(text.split(".", 1)[1]) if "." in text else 0
    return round(value, decimals) == round(float(text.replace("−", "-")), decimals)


def _mechanism_without_relations(markdown):
    """The line of a reader-layout mechanism chapter heading whose chapter writes no equation, or None.

    A run (2026-11-01) wrote its mechanism chapter in words only, about half the usual length, while the
    report skill, which asks for each step's governing relation, was in its context."""
    lines = markdown.splitlines()
    start = next((i for i, line in enumerate(lines) if MECHANISM.match(line)), None)
    if start is None:
        return None
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("## ")), len(lines))
    return None if EQUATION.search("\n".join(lines[start + 1:end])) else start + 1


def _named(line, sample):
    return re.search(r"(?<![\w-])" + re.escape(sample) + r"(?![\w-])", line) is not None


def _verdicts_in(line):
    lowered = line.lower()
    return [verdict for verdict, words in VERDICTS.items() if any(word.lower() in lowered for word in words)]


def _short(ref):
    parts = ref.split("/")
    return parts[2][:8] if len(parts) == 4 else ref


def _shown(number, text):
    """Whether a value rounds to the number as written."""
    decimals = len(text.split(".", 1)[1])
    return round(number, decimals) == round(float(text.replace("−", "-")), decimals)


def check(root, markdown, check_read=None, known=None):
    """Findings about one report Markdown text: [{"id": "host#n", "line": n, "text": ...}]."""
    samples, noise = known if known is not None else facts(root, check_read)
    found = []
    ids = sorted(samples, key=len, reverse=True)
    for number, line in enumerate(markdown.splitlines(), 1):
        named = [sample for sample in ids if _named(line, sample)]
        if not named:
            continue
        said = _verdicts_in(line)
        # A line about one candidate: its verdict words are about that candidate.
        candidates = [sample for sample in named if samples[sample]["verdict"]]
        if said and len(candidates) == 1:
            sample = candidates[0]
            actual = samples[sample]["verdict"]
            other = [verdict for verdict in said if verdict != actual]
            if other and actual not in said:
                found.append((number, f"第 {number} 行把 {sample} 寫成 {other[0]}，排行榜 "
                                      f"{_short(samples[sample]['leaderboard'])} 的判定是 {actual}。"))
            if "robust_surpass" in said and sample in noise and noise[sample]["robust"] < ROBUST_SHARE:
                shares = "、".join(f"{verdict} {share:.0%}" for verdict, share in
                                   sorted(noise[sample]["shares"].items(), key=lambda item: -item[1])[:2])
                found.append((number, f"第 {number} 行把 {sample} 寫成 robust_surpass，但噪聲檢查 "
                                      f"{_short(noise[sample]['calc'])} 在宣告噪聲下只有 "
                                      f"{noise[sample]['robust']:.0%} 的抽樣是 robust_surpass（{shares}）。"))
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")] if line.lstrip().startswith("|") else []
        # Prose about one candidate: the ranks it gives must be the leaderboard's (a reviewer without the
        # leaderboard files called these unassessed, and a run reviewed five more times to cover them).
        if not cells and len(named) == 1 and samples[named[0]].get("ranks"):
            sample = named[0]
            wrong = [text for text in RANK.findall(line)
                     if not any(_matches(value, text) for value in samples[sample]["ranks"])]
            if wrong:
                found.append((number, f"第 {number} 行把 {sample} 的名次寫成 {'、'.join(wrong)}，排行榜 "
                                      f"{_short(samples[sample]['leaderboard'])} 中 {sample} 的平均名次是 "
                                      f"{samples[sample]['ranks'][0]:g}。"))
        if cells and cells[0] in samples and samples[cells[0]]["verdict"]:
            sample = cells[0]
            numbers = [text for cell in cells[1:] for text in _NUMBER.findall(cell)]
            stray = [text for text in numbers if not any(_shown(value, text) for value in samples[sample]["values"])]
            if stray:
                found.append((number, f"第 {number} 行 {sample} 的 {'、'.join(stray)} 不是排行榜 "
                                      f"{_short(samples[sample]['leaderboard'])} 中 {sample} 的任何值。"))
    heading = _mechanism_without_relations(markdown)
    if heading is not None:
        found.insert(0, (heading, f"第 {heading} 行起的機制章沒有任何關係式：每一步寫出支配它的關係（$…$），"
                                  "再用白話說明；確實沒有已知定量關係的步驟，照實寫出並說明原因。"))
    return [{"id": f"host#{index}", "line": line, "text": text}
            for index, (line, text) in enumerate(found[:MAX_FINDINGS], 1)]
