"""External literature citations: `[@key]` in the text, `[@key]: entry` anywhere in the Markdown.

The author writes each bibliography entry and decides which claim it supports. The renderer
numbers the entries in order of first citation, draws the markers and the reference list, and
reports keys cited without an entry, entries never cited, and entries whose DOI or URL matches
no literature this research saved. The report never blocks rendering.
"""

from __future__ import annotations

import json
from pathlib import Path
import re
from urllib.parse import urlsplit

KEY = r"\w[^\s\[\]{};,@]*"
DEFINITION = re.compile(rf"^[ ]{{0,3}}\[@({KEY})\]:[ \t]*(.*)$")
# Not followed by "(" (an ordinary link) or ":" (a definition left in place).
CITE = re.compile(rf"\[@{KEY}(?:\s*[;,]\s*@{KEY})*\](?![(:])")
_FENCE = re.compile(r"^[ ]{0,3}(`{3,}|~{3,})")
_DOI = re.compile(r"\b10\.\d{4,9}/[^\s\"<>]+", re.I)
_URL = re.compile(r"https?://[^\s\"<>]+", re.I)
_ARXIV = re.compile(r"arxiv(?:\.org/(?:abs|pdf)/|:)\s*(\d{4}\.\d{4,5})", re.I)
_PMID = re.compile(r"(?:PMID:?\s*|pubmed\.ncbi\.nlm\.nih\.gov/)(\d{4,9})", re.I)
_TRAILING = ".,;:)]}'"


def keys(citation: str) -> list[str]:
    return re.findall(rf"@({KEY})", citation)


def split(text: str) -> tuple[str, dict[str, str], list[str]]:
    """(the Markdown without definitions, {key: entry} in definition order, keys defined twice).

    A definition may continue on lines indented by four spaces or a tab. Fenced code is left alone.
    """
    kept, entries, duplicates = [], {}, []
    fence, current = None, None
    for line in text.splitlines(keepends=True):
        bare = line.rstrip("\r\n")
        marker = _FENCE.match(bare)
        if fence:
            kept.append(line)
            if marker and marker.group(1)[0] == fence[0] and len(marker.group(1)) >= len(fence):
                fence = None
            continue
        if marker:
            fence, current = marker.group(1), None
            kept.append(line)
            continue
        match = DEFINITION.match(bare)
        if match:
            key, entry = match.group(1), match.group(2).strip()
            if key in entries:
                duplicates.append(key)
                current = None
            else:
                entries[key], current = entry, key
            kept.append("\n")  # a blank line, so text around it does not run together
            continue
        if current and bare.startswith(("    ", "\t")) and bare.strip():
            entries[current] = f"{entries[current]} {bare.strip()}".strip()
            kept.append("\n")
            continue
        current = None
        kept.append(line)
    return "".join(kept), entries, duplicates


def cited_keys(text: str) -> list[str]:
    """Cited keys in order of first citation, ignoring fenced and inline code."""
    prose, fence = [], None
    for line in text.splitlines():
        marker = _FENCE.match(line)
        if fence:
            if marker and marker.group(1)[0] == fence[0] and len(marker.group(1)) >= len(fence):
                fence = None
            continue
        if marker:
            fence = marker.group(1)
            continue
        prose.append(line)
    plain = re.sub(r"`[^`\n]*`", "", "\n".join(prose))
    order = []
    for match in CITE.finditer(plain):
        for key in keys(match.group(0)):
            if key not in order:
                order.append(key)
    return order


def numbering(order: list[str], entries: dict[str, str]) -> dict[str, int]:
    """Cited entries first, in order of first citation; uncited entries after them."""
    ranked = [key for key in order if key in entries] + [key for key in entries if key not in order]
    return {key: number for number, key in enumerate(ranked, 1)}


def runs(numbers) -> list[tuple[int, int]]:
    """[1, 2, 3, 5] -> [(1, 3), (5, 5)]."""
    result = []
    for number in sorted(set(numbers)):
        if result and number == result[-1][1] + 1:
            result[-1] = (result[-1][0], number)
        else:
            result.append((number, number))
    return result


def _url(url: str) -> str:
    parts = urlsplit(url)
    host = parts.netloc.lower().removeprefix("www.")
    if host in {"doi.org", "dx.doi.org"}:
        return "doi:" + parts.path.lstrip("/").lower()
    query = f"?{parts.query}" if parts.query else ""
    return f"url:{host}{parts.path.rstrip('/')}{query}"


def identifiers(text: str) -> set[str]:
    """Normalised DOIs, URLs, arXiv IDs and PubMed IDs found in a text."""
    found = {"doi:" + doi.rstrip(_TRAILING).lower() for doi in _DOI.findall(text)}
    found |= {_url(url.rstrip(_TRAILING)) for url in _URL.findall(text)}
    found |= {"arxiv:" + number for number in _ARXIV.findall(text)}
    found |= {"pmid:" + number for number in _PMID.findall(text)}
    return found


def _load(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def saved_identifiers(research: Path) -> set[str]:
    """DOIs, URLs and IDs of the literature saved under a workspace's .research folder.

    Search results (every identifier field of every item), fetched documents (their URLs and
    the DOIs printed in the first 4000 characters of the extracted text, where a paper prints
    its own DOI) and literature-agent answers. A match shows the source was retrieved, not
    that it supports the claim.
    """
    found = set()
    for path in sorted((research / "searches").glob("*.json")):
        data = _load(path)
        for item in (data or {}).get("items") or []:
            if isinstance(item, dict):
                for field, value in item.items():
                    if field not in {"abstract", "title"} and isinstance(value, str):
                        found |= identifiers(value)
                        if field == "doi" and value.strip():
                            found.add("doi:" + value.strip().lower())
    for path in sorted((research / "documents").glob("*/source.json")):
        data = _load(path) or {}
        for field in ("requested_url", "final_url"):
            if isinstance(data.get(field), str):
                found |= identifiers(data[field])
        try:
            with open(path.parent / "text.txt", encoding="utf-8", errors="replace") as handle:
                head = handle.read(4000)
        except OSError:
            head = ""
        found |= {"doi:" + doi.rstrip(_TRAILING).lower() for doi in _DOI.findall(head)}
    for path in sorted((research / "agent-literature").glob("*.json")):
        data = _load(path)
        if isinstance(data, dict) and data.get("result") is not None:
            found |= identifiers(json.dumps(data["result"], ensure_ascii=False))
    return found


def check(text: str, saved: set[str] | None = None) -> dict:
    """Counts and advice for the literature citations in authored Markdown."""
    body, entries, duplicates = split(text)
    order = cited_keys(body)
    undefined = [key for key in order if key not in entries]
    uncited = [key for key in entries if key not in order]
    bare = [key for key, entry in entries.items() if not identifiers(entry)]
    result = {"references": len(entries), "cited": len([key for key in order if key in entries]),
              "undefined": undefined, "uncited": uncited, "duplicates": duplicates,
              "without_identifier": bare}
    advice = []
    if undefined:
        advice.append(f"引用了沒有條目的文獻鍵 {'、'.join(undefined)}：在 Markdown 任一處寫上 "
                      "`[@鍵]: 作者, 標題, 期刊 卷(期), 頁碼 (年份). DOI`，或刪掉這個引用。")
    if uncited:
        advice.append(f"條目 {'、'.join(uncited)} 沒有在正文引用：在它支持的論述處加上 [@鍵]，或刪掉條目。")
    if duplicates:
        advice.append(f"鍵 {'、'.join(dict.fromkeys(duplicates))} 定義了不只一次，只採用第一個定義。")
    if bare:
        advice.append(f"條目 {'、'.join(bare)} 沒有 DOI 或網址：寫上保存紀錄中的 DOI 或網址，讀者才找得到原文。")
    if saved is not None:
        unsaved = [key for key, entry in entries.items() if identifiers(entry) and not identifiers(entry) & saved]
        result["not_in_saved_literature"] = unsaved
        if unsaved:
            advice.append(f"條目 {'、'.join(unsaved)} 的 DOI 或網址不在本研究保存的文獻裡：先用 paper_search、"
                          "paper_fetch 或 literature_agent 取得並保存，或改寫成已保存紀錄中的 DOI 或網址；"
                          "沒有讀過的文獻不要引用。")
        if saved and not entries:
            advice.append("本研究保存了文獻，報告卻沒有文獻引用：用到文獻的論述以 [@鍵] 標註，條目寫成 "
                          "`[@鍵]: 作者, 標題, 期刊 卷(期), 頁碼 (年份). DOI`。")
    result["advice"] = advice
    result["note"] = ("A saved DOI or URL shows the source was retrieved, not that it supports the claim; "
                      "these checks never block rendering.")
    return result
