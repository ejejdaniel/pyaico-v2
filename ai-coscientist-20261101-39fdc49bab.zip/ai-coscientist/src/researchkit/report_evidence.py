"""Resolve only the explicitly selected frozen UTF-8 files for a report."""

from __future__ import annotations

import json
from pathlib import Path

from researchkit import records


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label}: expected nonblank text")


def _reference(ref):
    _text(ref, "record_ref")
    parts = ref.split("/")
    if (len(parts) != 4 or parts[:2] != [".research", "records"]
            or parts[3] != "record.json" or len(parts[2]) != 64
            or any(c not in "0123456789abcdef" for c in parts[2])):
        raise ValueError("Expected an exact relative .research/records/<hash>/record.json reference")
    return parts[2]


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate record key: {key}")
        result[key] = value
    return result


def validate_choices(choices, *, label="evidence_files") -> None:
    """Validate one explicit selection, including duplicates, before any reads."""
    if not isinstance(choices, list):
        raise ValueError(f"{label}: expected an array")
    selected = set()
    for item in choices:
        if not isinstance(item, dict) or set(item) != {"record_ref", "source_path"}:
            raise ValueError(f"{label} entry: expected exactly record_ref, source_path")
        _reference(item["record_ref"])
        _text(item["source_path"], "source_path")
        key = (item["record_ref"], item["source_path"])
        if key in selected:
            raise ValueError("Duplicate selected evidence file")
        selected.add(key)


def _saved_files(manifest, source, limit=12):
    """The record's own files, the most similar to the requested path first.

    v23 asked for .research/history_checks/... where the file was .research/history-checks/...; the
    error did not say which files the record holds, so the agent had to look them up.
    """
    from difflib import SequenceMatcher

    paths = [item["source_path"] for item in manifest["files"]
             if isinstance(item, dict) and isinstance(item.get("source_path"), str)]
    if not paths:
        return ""
    ranked = sorted(paths, key=lambda path: -SequenceMatcher(None, path, source).ratio())
    shown = ", ".join(ranked[:limit]) + (f" and {len(paths) - limit} more" if len(paths) > limit else "")
    return f". That record's files: {shown}"


def resolve(root: Path, choices, *, check_read=None) -> list[dict]:
    """Verify selected bytes before rendering; never traverse record dependencies."""
    validate_choices(choices)
    root = root.resolve()
    verified = {}
    resolved = []
    for choice in choices:
        ref, source = choice["record_ref"], choice["source_path"]
        manifest_path = records.local_path(root, ref)
        record_hash = ref.split("/")[2]
        records_root = records.local_path(root, ".research/records")
        if (manifest_path.name != "record.json" or manifest_path.parent.parent != records_root
                or manifest_path.parent.name != record_hash):
            raise ValueError(f"Record reference resolves outside its exact record folder: {ref}")
        if ref not in verified:
            if check_read:
                check_read(manifest_path)
            raw = manifest_path.read_bytes()
            if records.digest(raw) != record_hash:
                raise ValueError(f"Record content has changed: {ref}")
            try:
                manifest = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_keys)
            except UnicodeDecodeError as exc:
                raise ValueError(f"Selected record manifest is not UTF-8 text: {ref}") from exc
            if not isinstance(manifest, dict) or not isinstance(manifest.get("files"), list):
                raise ValueError(f"Invalid record files: {ref}")
            for field in ("title", "kind"):
                _text(manifest.get(field), f"Record {field}")
            verified[ref] = manifest
        manifest = verified[ref]
        matches = [item for item in manifest["files"]
                   if isinstance(item, dict) and item.get("source_path") == source]
        if len(matches) != 1:
            raise ValueError(f"source_path must exactly select one saved file: {ref}: {source}"
                             + _saved_files(manifest, source))
        entry = matches[0]
        _text(entry.get("snapshot"), "snapshot")
        snapshot = records.local_path(manifest_path.parent, entry["snapshot"])
        if not snapshot.is_relative_to(root):
            raise ValueError(f"Selected snapshot is outside this research workspace: {ref}: {source}")
        if check_read:
            check_read(snapshot)
        raw = snapshot.read_bytes()
        if (records.digest(raw) != entry.get("sha256") or type(entry.get("bytes")) is not int
                or len(raw) != entry["bytes"]):
            raise ValueError(f"Selected snapshot hash or bytes changed: {ref}: {source}")
        try:
            content = raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError(f"Selected snapshot is not UTF-8 text: {ref}: {source}") from exc
        if any(ord(character) < 32 and character not in "\t\n\r\f" for character in content):
            raise ValueError(f"Selected snapshot contains binary control characters: {ref}: {source}")
        resolved.append({"record_ref": ref, "source_path": source, "title": manifest["title"],
                         "kind": manifest["kind"], "sha256": entry["sha256"],
                         "bytes": entry["bytes"], "text": content})
    return resolved
