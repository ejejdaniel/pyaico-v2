"""Scientific-report presentation of authored Markdown and resolved evidence.

The page shell and styles follow the reference scientific renderer.  This module
does not select research artifacts, interpret their meaning, or write outputs.
"""

from __future__ import annotations

from html import escape
from html.parser import HTMLParser
import os
from pathlib import Path
import re
from urllib.parse import quote, urljoin, urlsplit, urlunsplit
from urllib.request import url2pathname

import markdown
from markdown.inlinepatterns import HTML_RE, InlineProcessor
from markdown.treeprocessors import Treeprocessor
from markdown.util import AtomicString

from researchkit import report_citations
from researchkit.report_style import plain_labels


_FULL_REPORT_HEADINGS = (
    "摘要",
    "1. 研究命題與問題邊界",
    "2. 共同研究資產與心智圖",
    "3. 機制假說",
    "4. 定量代理、實作與評估",
    "5. 樣本演化與多指標排名",
    "6. 科學審查與證據邊界",
    "7. 對原始問題的精準回答",
    "8. 證據索引與限制",
)
# Reader-first layout: the answer and the mechanism come first; how the study was run, the
# notes, the mind map and the saved originals follow as appendices. A heading may add a
# subtitle after a colon ("2. 機制：酸預算與溶解對比").
_READER_REPORT_HEADINGS = (
    "摘要",
    "1. 結論",
    "2. 機制",
    "3. 證據",
    "4. 候選與建議實驗",
    "5. 限制與未解問題",
)
_MARKDOWN_EXTENSIONS = ["fenced_code", "tables", "sane_lists", "toc", "footnotes"]
_MARKDOWN_CONFIG = {"footnotes": {"SEPARATOR": "-", "BACKLINK_TEXT": "↩", "BACKLINK_TITLE": "回到正文"}}
_VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input",
              "link", "meta", "param", "source", "track", "wbr"}


class _Math(InlineProcessor):
    """$...$ and $$...$$ LaTeX drawn as MathML, which the browser renders in the page and the PDF.

    Runs before Markdown's escapes and emphasis, so backslashes and underscores reach the
    converter intact; code spans are handled earlier and stay literal. LaTeX the converter
    cannot read is shown as code rather than failing the report.
    """

    PATTERN = r"\$\$(.+?)\$\$|(?<![\\$\w])\$(?=\S)([^$\n]+?)(?<=\S)\$(?![\d$])"

    def handleMatch(self, match, data):
        latex, display = (match.group(1), "block") if match.group(1) is not None else (match.group(2), "inline")
        try:
            from latex2mathml.converter import convert
            markup = convert(latex.strip(), display=display)
        except Exception:  # missing package or unreadable LaTeX: keep the source visible
            markup = f'<code class="math-source">{escape(latex.strip())}</code>'
        return self.md.htmlStash.store(markup), match.start(0), match.end(0)


class _Citation(InlineProcessor):
    """[@key] and [@a; @b] drawn as a superscript [1] or [1–3] linking to the reference list.

    Numbers come from the order of first citation in the source, so they read in order on the
    page. A key without an entry stays visible as [?key].
    """

    def __init__(self, md, numbers):
        super().__init__(report_citations.CITE.pattern, md)
        self.numbers = numbers

    def handleMatch(self, match, data):
        cited = report_citations.keys(match.group(0))
        parts = []
        for first, last in report_citations.runs(self.numbers[key] for key in cited if key in self.numbers):
            link = f'<a href="#literature-{first}">{first}</a>'
            if last > first:
                link += ("–" if last > first + 1 else ", ") + f'<a href="#literature-{last}">{last}</a>'
            parts.append(link)
        parts += [f'<span class="missing-reference">?{escape(key)}</span>'
                  for key in dict.fromkeys(cited) if key not in self.numbers]
        markup = f'<sup class="literature-cite">[{", ".join(parts)}]</sup>'
        return self.md.htmlStash.store(markup), match.start(0), match.end(0)


def _entry_html(entry: str) -> str:
    """One bibliography entry: escaped text, *italics*, and DOIs and URLs as links."""
    def inline(text):
        return re.sub(r"\*([^*\n]+)\*", r"<em>\1</em>", escape(text))

    pieces, last = [], 0
    for match in re.finditer(r"https?://[^\s<>\"]+|\b10\.\d{4,9}/[^\s<>\"]+", entry):
        token = match.group(0).rstrip(".,;:)]}'")
        href = token if token.lower().startswith("http") else "https://doi.org/" + token
        pieces += [inline(entry[last:match.start()]), f'<a href="{escape(href)}">{escape(token)}</a>']
        last = match.start() + len(token)
    pieces.append(inline(entry[last:]))
    return "".join(pieces)


def _references_list(entries, numbers, identities):
    rows = [f'<li id="{identities[number]}"><span class="ref-number">[{number}]</span>'
            f'<div>{_entry_html(entries[key])}</div></li>'
            for key, number in sorted(numbers.items(), key=lambda item: item[1])]
    return '<ol class="references">' + "\n".join(rows) + '</ol>'


class _LiteralHtml(InlineProcessor):
    def handleMatch(self, match, data):
        # Escape at the Markdown parser boundary, preserving fenced code exactly.
        return AtomicString(match.group(0)), match.start(0), match.end(0)


def _note_label(number: int) -> str:
    """1 -> a, 26 -> z, 27 -> aa: the same sequence as the CSS lower-alpha list of notes."""
    label = ""
    while number:
        number, rest = divmod(number - 1, 26)
        label = chr(97 + rest) + label
    return label


def _heading_matches(title: str, expected: str) -> bool:
    return title == expected or title.startswith((expected + "：", expected + ":"))


def _layout(titles) -> str:
    if tuple(titles[:len(_FULL_REPORT_HEADINGS)]) == _FULL_REPORT_HEADINGS:
        return "full"
    if len(titles) >= len(_READER_REPORT_HEADINGS) and all(
            _heading_matches(title, expected) for title, expected in zip(titles, _READER_REPORT_HEADINGS)):
        return "reader"
    return "generic"


class _ReportLinks(Treeprocessor):
    def __init__(self, parser, source: Path, output_directory: Path):
        super().__init__(parser)
        self.source = source
        self.output_directory = output_directory

    def run(self, root):
        for element in root.iter():
            classes = element.attrib.get("class", "").split()
            if element.tag == "a" and "footnote-ref" in classes:
                # Notes are lettered so they never read as the numbered citations.
                if re.fullmatch(r"[0-9]+", element.text or ""):
                    element.text = _note_label(int(element.text))
                    element.set("aria-label", f"註 {element.text}")
                continue
            if element.tag == "a" and "footnote-backref" in classes:
                continue
            if element.tag == "img":
                element.tag = "span"
                element.text = element.attrib.get("alt", "image")
                element.attrib.clear()
            elif element.tag == "a":
                href = element.attrib.get("href", "")
                parsed = urlsplit(href)
                if (any(ord(c) < 32 for c in href) or "\\" in href
                        or href.startswith("//")
                        or (parsed.scheme and parsed.scheme.lower() not in {"http", "https"})):
                    element.tag = "span"
                    element.attrib.clear()
                elif href and not href.startswith("#") and not parsed.scheme:
                    local = urlsplit(urljoin(self.source.as_uri(), href))
                    target = Path(url2pathname(local.path))
                    relative = Path(os.path.relpath(target, self.output_directory)).as_posix()
                    element.set("href", urlunsplit(("", "", quote(relative, safe="/"),
                                                    local.query, local.fragment)))
                if (element.tag == "a" and not parsed.scheme and parsed.fragment
                        and not len(element) and re.fullmatch(r"[0-9]+", element.text or "")):
                    # Typography only: retain the authored number and fragment,
                    # including the existing rebasing of local-file links.
                    element.set("class", "citation")
                    if re.fullmatch(r"evidence-[0-9]+", parsed.fragment):
                        # Internal evidence reads E1, E2 … so it never looks like a literature number.
                        element.text = "E" + element.text
                        element.set("aria-label", f"內部證據 {element.text}")
                    else:
                        element.set("aria-label", f"引用 {element.text}")


class _Blocks(HTMLParser):
    """Keep generated top-level HTML spans without reparsing their contents."""

    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source = source
        self.lines = [0] + [i + 1 for i, char in enumerate(source) if char == "\n"]
        self.depth = 0
        self.start = 0
        self.blocks = []

    def absolute_offset(self):
        line, column = self.getpos()
        return self.lines[line - 1] + column

    def finish(self, end):
        block = self.source[self.start:end]
        if block.strip():
            self.blocks.append(block.strip())
        self.start = end

    def handle_starttag(self, tag, attrs):
        if self.depth == 0:
            self.finish(self.absolute_offset())
        if tag not in _VOID_TAGS:
            self.depth += 1
        elif self.depth == 0:
            self.finish(self.absolute_offset() + len(self.get_starttag_text()))

    def handle_startendtag(self, tag, attrs):
        if self.depth == 0:
            self.finish(self.absolute_offset())
            self.finish(self.absolute_offset() + len(self.get_starttag_text()))

    def handle_endtag(self, tag):
        if tag not in _VOID_TAGS:
            self.depth -= 1
            if self.depth == 0:
                self.finish(self.absolute_offset() + len(f"</{tag}>"))


class _TextAndIds(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text = []
        self.ids = set()

    def handle_data(self, data):
        self.text.append(data)

    def handle_starttag(self, tag, attrs):
        identity = dict(attrs).get("id")
        if identity:
            self.ids.add(identity)


def _blocks(source):
    parser = _Blocks(source)
    parser.feed(source)
    parser.close()
    parser.finish(len(source))
    return parser.blocks


def _text(source):
    parser = _TextAndIds()
    parser.feed(source)
    return "".join(parser.text)


def _heading(block, level):
    return re.fullmatch(rf"<h{level}\b[^>]*>([\s\S]*)</h{level}>", block)


def _cards(blocks):
    # H3 is a typographic subsection, never an inferred scientific category.
    result = []
    opened = False
    for block in blocks:
        if _heading(block, 3):
            if opened:
                result.append("</article>")
            result.append('<article class="narrative-card">')
            opened = True
        elif _heading(block, 1) and opened:
            result.append("</article>")
            opened = False
        if block.startswith("<table>"):
            block = ('<div class="table-scroll" tabindex="0" role="region" '
                     'aria-label="可水平捲動的資料表">' + block + "</div>")
        result.append(block)
    if opened:
        result.append("</article>")
    return "\n".join(result)


EVIDENCE_FILE = "evidence.html"


def _evidence_index(evidence, allocate):
    """The report's short index of saved originals; the complete text is in a separate file."""
    rows = []
    for index, item in enumerate(evidence, 1):
        rows.append(
            f'<li class="evidence-ref" id="{allocate(f"evidence-{index}")}"><span class="e-number">E{index}</span>'
            f'<div><strong>{escape(item["title"])}</strong> <code>{escape(item["kind"])}</code><br>'
            f'<code>{escape(item["source_path"])}</code> · {escape(str(item["bytes"]))} bytes · '
            f'<a href="{EVIDENCE_FILE}#evidence-{index}">完整原文</a><br>'
            f'<small><code>{escape(item["record_ref"])}</code> · SHA-256 <code>{escape(str(item["sha256"]))}</code>'
            '</small></div></li>'
        )
    return (f'<p>完整原文另存在同一資料夾的 <a href="{EVIDENCE_FILE}">{EVIDENCE_FILE}</a>'
            ' 與同名 PDF。原文中的主張不因列在這裡而成為已驗證事實。</p>'
            '<ol class="evidence-index">' + "\n".join(rows) + '</ol>')


def build_evidence_html(evidence: list[dict], title: str) -> str:
    """A separate page with the complete saved originals, expanded, in selection order."""
    used = set()

    def allocate(base):
        used.add(base)
        return base

    css = (Path(__file__).parent / "assets" / "scientific-report.css").read_text(encoding="utf-8")
    panels = _evidence_panels(evidence, allocate).replace('<details class="raw">', '<details class="raw" open>')
    return f'''<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'"><title>{escape(title)}｜研究證據原文</title><style>{css}</style></head>
<body class="generic-report evidence-file"><main><header class="hero"><div class="eyebrow">研究證據原文</div><h1>{escape(title)}</h1><p class="subtitle">報告所選存檔原文的完整內容，依選取順序排列。</p></header>
<section class="chapter">{panels}</section></main></body></html>'''


def _evidence_panels(evidence, allocate):
    panels = []
    for index, item in enumerate(evidence, 1):
        metadata = "".join(
            f'<dt>{label}</dt><dd><code>{escape(str(item[key]))}</code></dd>'
            for label, key in (("record_ref", "record_ref"), ("source_path", "source_path"),
                               ("SHA-256", "sha256"), ("bytes", "bytes"))
        )
        panels.append(
            f'<article class="evidence" id="{allocate(f"evidence-{index}")}">'
            f'<header><span class="e-number">E{index}</span><div>'
            f'<h4>{escape(item["title"])}</h4><code>{escape(item["kind"])}</code>'
            '</div></header><dl class="hashes">' + metadata + '</dl>'
            '<details class="raw"><summary>檢視完整存檔原文</summary><pre><code>'
            + escape(item["text"]) + '</code></pre></details></article>'
        )
    return ('<p>以下依選取順序保留完整存檔原文與來源資訊；原文中的主張不因呈現而成為已驗證事實。</p>'
            '<div class="evidence-list">' + "\n".join(panels) + '</div>')


def layout_status(markdown_path: Path) -> dict:
    """Which layout build_html will use, and the first heading that keeps a report from the full one.

    The reader layout needs the level-two headings to start with _READER_REPORT_HEADINGS in
    order (each may add a subtitle after a colon); appendices follow, and selected mind maps
    and evidence files are appended as appendices. The older full layout (_FULL_REPORT_HEADINGS)
    still renders. Any other headings render as a generic report.
    """
    parser = markdown.Markdown(extensions=_MARKDOWN_EXTENSIONS, extension_configs=_MARKDOWN_CONFIG,
                               output_format="html5")
    parser.preprocessors.deregister("html_block")
    rendered = parser.convert(Path(markdown_path).read_text(encoding="utf-8-sig"))
    titles = [_text(match[1]) for block in _blocks(rendered) if (match := _heading(block, 2))]
    status = {"layout": _layout(titles), "reader_layout_headings": list(_READER_REPORT_HEADINGS),
              "full_layout_headings": list(_FULL_REPORT_HEADINGS)}
    if status["layout"] == "generic":
        def matched(headings):
            count = 0
            for title, expected in zip(titles, headings):
                if not _heading_matches(title, expected):
                    break
                count += 1
            return count
        # Name the difference from the layout the headings already follow further (the reader one on a tie).
        headings = (_FULL_REPORT_HEADINGS if matched(_FULL_REPORT_HEADINGS) > matched(_READER_REPORT_HEADINGS)
                    else _READER_REPORT_HEADINGS)
        position = matched(headings)
        status["first_difference"] = {"position": position + 1, "expected": headings[position],
                                      "found": titles[position] if position < len(titles) else None}
    return status


def build_html(markdown_path: Path, destination: Path, *, evidence: list[dict],
               mindmaps: list[dict]) -> str:
    """Return one self-contained HTML page for the destination directory.

    Evidence and mind maps are the caller's already resolved selections.  Only
    the authored Markdown and packaged stylesheet are read here.
    """
    markdown_path, destination = markdown_path.resolve(), destination.resolve()
    parser = markdown.Markdown(extensions=_MARKDOWN_EXTENSIONS, extension_configs=_MARKDOWN_CONFIG,
                               output_format="html5")
    parser.preprocessors.deregister("html_block")
    parser.inlinePatterns.register(_LiteralHtml(HTML_RE, parser), "html", 90)
    parser.inlinePatterns.register(_Math(_Math.PATTERN, parser), "math", 185)
    # [@key]: entry definitions become the reference list; [@key] in the text becomes [n].
    body, references, _ = report_citations.split(markdown_path.read_text(encoding="utf-8-sig"))
    body = plain_labels(body)  # a bold label opening a paragraph prints plain (report_style.plain_labels)
    numbers = report_citations.numbering(report_citations.cited_keys(body), references)
    parser.inlinePatterns.register(_Citation(parser, numbers), "literature", 172)
    parser.treeprocessors.register(_ReportLinks(parser, markdown_path, destination),
                                   "report_links", 4)
    rendered = parser.convert(body)
    inventory = _TextAndIds()
    inventory.feed(rendered)
    used_ids = inventory.ids

    def allocate(base):
        candidate, suffix = base, 2
        while candidate in used_ids:
            candidate = f"{base}-{suffix}"
            suffix += 1
        used_ids.add(candidate)
        return candidate

    # Authored heading targets take precedence over presentation identifiers.
    shell = {key: allocate(key) for key in ("main", "top", "theme", "map-dialog",
                                          "map-dialog-title", "map-close", "map-dialog-body")}
    reference_ids = {}
    for number in numbers.values():
        reference_ids[number] = allocate(f"literature-{number}")
        if reference_ids[number] != f"literature-{number}":
            rendered = rendered.replace(f'href="#literature-{number}"', f'href="#{reference_ids[number]}"')
    blocks = _blocks(rendered)
    title = markdown_path.stem
    hero_heading = f"<h1>{escape(title)}</h1>"
    for index, block in enumerate(blocks):
        match = _heading(block, 1)
        if match:
            title, hero_heading = _text(match[1]), blocks.pop(index)
            break

    notes = [block for block in blocks if block.startswith('<div class="footnote"')]
    blocks = [block for block in blocks if not block.startswith('<div class="footnote"')]
    sections, preamble = [], []
    for block in blocks:
        match = _heading(block, 2)
        if match:
            sections.append({"title": _text(match[1]), "heading": block, "blocks": []})
        elif sections:
            sections[-1]["blocks"].append(block)
        else:
            preamble.append(block)
    layout = _layout([section["title"] for section in sections])
    full_layout = layout == "full"
    reader_layout = layout == "reader"
    for section in sections:
        section["appendix"] = section["title"].startswith("附錄")
    # The reference list follows the main text, before any appendix, as in a paper.
    authored_end = next((index for index, section in enumerate(sections) if section["appendix"]), len(sections))
    if notes:
        # Side remarks, sources and version details collected from [^name] markers in the text.
        title = "附錄：註解" if reader_layout else "註解"
        sections.append({"title": title, "heading": f'<h2 id="{allocate("notes")}">{title}</h2>',
                         "blocks": notes, "appendix": True, "notes": True})
    maps_html = ""
    if mindmaps:
        from researchkit.report_mindmap import render_mindmap

        for index, item in enumerate(mindmaps, 1):
            namespace = f"report-map-{index}"
            while any(identity.startswith(namespace + "-") for identity in used_ids):
                namespace += "-map"
            used_ids.add(namespace + "-board")
            provenance = {key: value for key, value in item.items() if key != "content"}
            maps_html += render_mindmap(item["content"], provenance, namespace)
        # The map renderer uses this shell control for accessibility.
        maps_html = maps_html.replace('aria-controls="map-dialog"',
                                      f'aria-controls="{shell["map-dialog"]}"')
        if not reader_layout and len(sections) > 2 and sections[2]["title"] == _FULL_REPORT_HEADINGS[2]:
            sections[2]["supplement"] = maps_html
            sections[2]["map"] = True
        else:
            title = "附錄：研究心智圖" if reader_layout else "研究心智圖"
            sections.append({"title": title, "heading": f"<h2>{title}</h2>", "blocks": [],
                             "supplement": maps_html, "map": True, "appendix": reader_layout})
    if evidence:
        # Only an index here: the complete originals go to a separate file beside the report.
        evidence_html = _evidence_index(evidence, allocate)
        if not reader_layout and len(sections) > 8 and sections[8]["title"] == _FULL_REPORT_HEADINGS[8]:
            sections[8]["supplement"] = evidence_html
        else:
            title = "附錄：內部研究證據索引" if reader_layout else "內部研究證據索引"
            sections.append({"title": title, "heading": f"<h2>{title}</h2>", "blocks": [],
                             "supplement": evidence_html, "appendix": reader_layout})
    if numbers:
        listing = _references_list(references, numbers, reference_ids)
        authored = next((section for section in sections[:authored_end]
                         if section["title"].startswith("參考文獻")), None)
        if authored:  # the author placed the heading: fill it there
            authored["supplement"] = authored.get("supplement", "") + listing
            authored["references"] = True
        else:
            sections.insert(authored_end, {"title": "參考文獻", "references": True, "appendix": False,
                                           "heading": f'<h2 id="{allocate("references")}">參考文獻</h2>',
                                           "blocks": [], "supplement": listing})

    first_appendix = next((index for index, section in enumerate(sections) if section.get("appendix")), None)
    chapters, links = [], []
    number = appendices = 0
    for index, section in enumerate(sections):
        is_abstract = section["title"] == "摘要"
        if section.get("appendix"):
            appendices += 1
            label = "附錄"
        elif section.get("references"):
            label = "文獻"
        else:
            if not is_abstract:
                number += 1
            label = "摘要" if is_abstract else f"{number:02d}"
        identity = allocate(f"section-{index}")
        classes = "chapter" + (" abstract" if is_abstract else "") + (" appendix" if section.get("appendix") else "")
        if index == first_appendix:
            classes += " appendix-start"
        if section.get("notes"):
            classes += " notes-chapter"
        if section.get("map"):
            classes += " map-chapter"
        chapters.append(
            f'<section id="{identity}" class="{classes}"><div class="chapter-title">'
            f'<span>{label}</span>{section["heading"]}</div>'
            + _cards(section["blocks"]) + section.get("supplement", "") + '</section>'
        )
        if index != 0 or not is_abstract:
            links.append(f'<a href="#{identity}"><span>{label}</span>'
                         + escape(section["title"]) + '</a>')
    opening = _cards(preamble)
    if sections and sections[0]["title"] == "摘要":
        opening += chapters.pop(0)
    navigation = ('<nav class="toc" aria-label="報告章節"><h2>閱讀索引</h2>'
                  + "\n".join(links) + '</nav>') if links else ""
    css = (Path(__file__).parent / "assets" / "scientific-report.css").read_text(encoding="utf-8")
    for key in ("map-dialog", "map-close"):
        if shell[key] != key:
            css = css.replace(f"#{key}", f"#{shell[key]}")
    source_link = quote(Path(os.path.relpath(markdown_path, destination)).as_posix(), safe="/")
    body_class = ' class="reader-report"' if reader_layout else '' if full_layout else ' class="generic-report"'
    return f'''<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'"><title>{escape(title)}｜正式科研報告</title><style>{css}</style></head>
<body{body_class}><a class="skip" href="#{shell['main']}">跳至正文</a><div class="toolbar"><a href="#{shell['top']}">研究報告</a><button id="{shell['theme']}" type="button" aria-pressed="false">深色模式</button></div><main id="{shell['main']}"><header class="hero" id="{shell['top']}"><div class="eyebrow">研究成果與證據邊界 · HTML 審閱版</div>{hero_heading}<p class="subtitle">研究問題、研究發現與證據限制</p><p class="hero-boundary">分開閱讀來源量測、計算結果、作者主張與待驗證問題。</p></header>
{opening}<div class="reading-layout">{navigation}<div class="chapters">{''.join(chapters)}</div></div>
<footer><a href="{escape(source_link)}">正文來源</a> · PDF 由此 HTML 輸出。</footer></main>
<dialog id="{shell['map-dialog']}" aria-labelledby="{shell['map-dialog-title']}"><div class="map-dialog-toolbar"><div><h2 id="{shell['map-dialog-title']}">Mechanism landscape</h2><p>可上下、左右捲動；Esc 可返回報告。</p></div><button type="button" id="{shell['map-close']}">返回報告 ✕</button></div><div id="{shell['map-dialog-body']}"></div></dialog>
<script>
const dialog=document.getElementById('{shell['map-dialog']}');let board,placeholder;
function restoreMap(){{if(board&&placeholder&&dialog.contains(board)){{placeholder.after(board);placeholder.remove();}}}}
window.addEventListener('beforeprint',function(){{restoreMap();if(dialog.open)dialog.close();document.documentElement.dataset.theme='light';document.querySelectorAll('details').forEach(element=>{{element.open=true;}});}});
document.getElementById('{shell['theme']}').addEventListener('click',function(){{const dark=document.documentElement.dataset.theme!=='dark';document.documentElement.dataset.theme=dark?'dark':'light';this.setAttribute('aria-pressed',String(dark));this.textContent=dark?'淺色模式':'深色模式';}});
document.querySelectorAll('[data-map-target]').forEach(button=>button.addEventListener('click',function(){{board=document.getElementById(this.dataset.mapTarget);if(!board)return;placeholder=document.createComment('mindmap location');board.before(placeholder);document.getElementById('{shell['map-dialog-body']}').appendChild(board);dialog.showModal();}}));
document.getElementById('{shell['map-close']}').addEventListener('click',function(){{restoreMap();dialog.close();}});
dialog.addEventListener('close',restoreMap);
document.addEventListener('click',function(event){{const link=event.target.closest('a[href^="#"]');if(!link)return;const target=document.getElementById(link.getAttribute('href').slice(1));if(!target)return;if(dialog.open&&dialog.contains(link)){{restoreMap();dialog.close();}}if(target.matches('details'))target.open=true;}});
</script></body></html>'''
