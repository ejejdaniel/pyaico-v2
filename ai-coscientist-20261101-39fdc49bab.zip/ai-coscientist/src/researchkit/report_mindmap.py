"""Present an approved saved mind map in the scientific report's HTML style.

The diagram is a Python port of ``scripts/mindmap-diagram.mjs`` in the
reference workflow. Layout uses declared chains and relationship endpoints;
it does not interpret scientific prose. The report owns CSS and dialog behavior.
"""

from __future__ import annotations

from collections.abc import Mapping
from html import escape
import re

from .mindmap_schema import (
    RELATIONSHIP_PATTERN, effect_line, effect_short, observable_line, observables_by_id, side_effect_line,
    term_coverage, term_line, validate_map,
)


_STAGES = ("可調整的槓桿", "逐步機轉", "對目標的作用")
_FIELDS = (
    ("summary", "摘要"),
    ("principle", "作用原理"),
    ("scope_status", "範圍"),
    ("levers", "可調整的槓桿"),
    ("acts_on_terms", "作用於的主導項"),
    ("steps", "逐步機轉"),
    ("target_effect", "對目標的作用"),
    ("side_effects", "副作用"),
    ("prerequisites", "成立前提與禁忌"),
    ("early_check", "早期檢查"),
    ("main_bottleneck", "主要瓶頸"),
    ("expected_failure_mode", "預期失敗模式"),
    ("viability_band", "可行性說明"),
)
_SCOPE_LABELS = {"in_task": "任務範圍內", "outside_task": "超出任務範圍（列出供參考，不進入後續假說）"}


def _stage_items(family: dict, names: dict) -> tuple[list[str], list[str], list[str]]:
    """The three diagram columns of one route: levers, ordered steps, effect on each target."""
    return (
        list(family["levers"]),
        [f"{number}. {step['change']} → {step['quantity']}"
         for number, step in enumerate(family["steps"], 1)],
        [effect_short(item, names) for item in family["target_effect"]],
    )


def _field_text(key: str, value, names: dict) -> list[str]:
    """Every authored word of one field, as list items."""
    if key == "steps":
        return [f"{number}. {step['change']} → {step['quantity']}：{step['effect']}（證據：{step['evidence']}）"
                for number, step in enumerate(value, 1)]
    if key == "target_effect":
        return [effect_line(item, names) for item in value]
    if key == "side_effects":
        return [side_effect_line(item, names) for item in value]
    return list(value)
_PROVENANCE = ("record_ref", "source_path", "sha256")


def _esc(value: object) -> str:
    return escape(str(value), quote=True)


def _wrap(value: str, width: int) -> list[str]:
    """Wrap for typography only, retaining every word and Unicode character."""
    def units(text: str) -> float:
        return sum(0.62 if ord(char) < 128 else 1 for char in text)

    lines = []
    for paragraph in value.split("\n"):
        line = ""
        for word in paragraph.split():
            candidate = f"{line} {word}" if line else word
            if units(candidate) <= width:
                line = candidate
                continue
            if line:
                lines.append(line)
                line = ""
            if units(word) <= width:
                line = word
                continue
            for char in word:
                if line and units(line + char) > width:
                    lines.append(line)
                    line = ""
                line += char
        if line:
            lines.append(line)
    return lines or [""]


def _label(lines: list[str], x: float, y: float,
           css_class: str = "mm-text", line_height: int = 20) -> str:
    spans = "".join(
        f'<tspan x="{x:g}" dy="{line_height if index else 0}">{_esc(line)}</tspan>'
        for index, line in enumerate(lines)
    )
    return f'<text x="{x:g}" y="{y:g}" class="{css_class}">{spans}</text>'


def _box(x: float, y: int, height: int, css_class: str = "") -> str:
    return (f'<rect x="{x:g}" y="{y}" width="252" height="{height}" rx="8" '
            f'class="mm-box {css_class}"/>')


def _list(values: list[str]) -> str:
    return "<ul>" + "".join(f"<li>{_esc(value)}</li>" for value in values) + "</ul>"


def _family_details(family: dict, index: int, namespace: str, names: dict) -> str:
    fields = []
    for key, label in _FIELDS:
        value = family[key]
        if key == "scope_status":
            body = f"<p>{_esc(_SCOPE_LABELS[value])}（{_esc(value)}）</p>"
        elif isinstance(value, list):
            body = _list(_field_text(key, value, names)) if value else '<p><code>[]</code></p>'
        else:
            body = f"<p>{_esc(value)}</p>"
        fields.append(f'<div class="field" data-field="{key}">'
                      f'<h4>{label}</h4>{body}</div>')
    return (
        f'<details class="family" id="{namespace}-family-{index}" '
        f'data-family-id="{_esc(family["family_id"])}">'
        f'<summary><strong data-field="title">{_esc(family["title"])}</strong>'
        f'<span><span data-field="family_id">{_esc(family["family_id"])}</span>'
        ' · 完整原文</span></summary><div class="original">'
        + "".join(fields) + "</div></details>"
    )


def render_mindmap(content: dict, provenance: Mapping[str, object], namespace: str) -> str:
    """Return a self-contained HTML fragment, using the report's CSS and dialog.

    ``content`` is the existing approved map, not a new report-specific payload.
    ``provenance`` carries the saved record's existing reference, path and hash.
    The caller supplies a distinct HTML-safe namespace for each placement and
    handles ``.map-expand[data-map-target]`` through its shared ``map-dialog``.
    No files, scripts, remote resources or scientific content are generated here.
    """
    validate_map(content)
    if not isinstance(namespace, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*", namespace):
        raise ValueError("mind-map placement namespace must be a nonempty HTML-safe identifier")

    families = content["families"]
    names = observables_by_id(content)
    relations = []
    for original in content["supported_relationships"]:
        # validate_map has already checked this exact grammar and its endpoints.
        match = RELATIONSHIP_PATTERN.fullmatch(original)
        source, operator, target, explanation = match.groups()
        relations.append((source, operator, target, explanation, original))

    box_width, pitch = 252, 278
    width = max(760, len(families) * pitch + 24)
    start = (width - (len(families) * pitch - (pitch - box_width))) / 2
    xs = [start + index * pitch for index in range(len(families))]
    centers = {family["family_id"]: xs[index] + box_width / 2
               for index, family in enumerate(families)}
    title_lines = _wrap(content["title"], (width - 64) // 18)
    channel_start = 58 + len(title_lines) * 24
    head_y = channel_start + max(1, len(relations)) * 31 + 35
    header_lines = [_wrap(family["title"], 16) for family in families]
    id_lines = [_wrap(family["family_id"], 22) for family in families]
    head_height = (67 + max(map(len, header_lines)) * 21
                   + (max(map(len, id_lines)) - 1) * 16)
    groups = [
        [[_wrap(item, 19) for item in _stage_items(family, names)[stage]]
         for family in families]
        for stage in range(len(_STAGES))
    ]
    heights = [48 + max(sum(len(lines) * 20 + 8 for lines in items) for items in group)
               for group in groups]
    stage_ys = []
    cursor = head_y + head_height + 40
    for height in heights:
        stage_ys.append(cursor)
        cursor += height + 40
    risks = [_wrap(family["expected_failure_mode"], 19) for family in families]
    risk_height = 48 + max(map(len, risks)) * 20
    height = cursor + risk_height + 54
    arrow_id, grid_id = f"{namespace}-arrow", f"{namespace}-grid"
    arrows = []
    for index, (source, operator, target, _, original) in enumerate(relations):
        a, b = centers[source], centers[target]
        y = channel_start + index * 31
        route = f"M{a:g} {head_y - 9} C{a:g} {y} {b:g} {y} {b:g} {head_y - 9}"
        middle = (a + b) / 2
        backwards = f' marker-start="url(#{arrow_id})"' if operator == "<->" else ""
        arrows.append(
            f'<g class="mm-relation" data-from="{_esc(source)}" data-to="{_esc(target)}">'
            f'<title>{_esc(original)}</title><path d="{route}" '
            f'marker-end="url(#{arrow_id})"{backwards}/>'
            f'<rect x="{middle - 16:g}" y="{y - 17}" width="32" height="19" '
            'rx="9" class="mm-relation-chip"/>'
            f'{_label([f"R{index + 1}"], middle - 10, y - 4, "mm-relation-label")}</g>'
        )
    for x in xs:
        previous = head_y + head_height
        for stage, stage_y in enumerate(stage_ys):
            arrows.append(f'<path class="mm-flow" d="M{x + 140:g} {previous} V{stage_y}" '
                          f'marker-end="url(#{arrow_id})"/>')
            previous = stage_y + heights[stage]
        arrows.append(f'<path class="mm-risk-link" '
                      f'd="M{x + box_width / 2:g} {previous} V{cursor}"/>')

    lanes = []
    for index, family in enumerate(families):
        x = xs[index]
        parts = [
            _box(x, head_y, head_height, "mm-head"),
            _label([f"路線 {index + 1}" + ("（任務範圍外）" if family["scope_status"] == "outside_task" else "")],
                   x + 16, head_y + 23, "mm-small"),
            _label(header_lines[index], x + 16, head_y + 51, "mm-title", 21),
            _label(id_lines[index], x + 16,
                   head_y + head_height - 14 - (len(id_lines[index]) - 1) * 16, "mm-id", 16),
        ]
        for stage, stage_title in enumerate(_STAGES):
            y = stage_ys[stage]
            parts.extend((_box(x, y, heights[stage]),
                          _label([stage_title], x + 16, y + 25, "mm-stage")))
            text_y = y + 52
            for lines in groups[stage][index]:
                parts.extend((_label(["•"], x + 12, text_y), _label(lines, x + 27, text_y)))
                text_y += len(lines) * 20 + 8
        parts.extend((_box(x, cursor, risk_height, "mm-risk"),
                      _label(["風險／失敗模式"], x + 16, cursor + 25, "mm-stage"),
                      _label(risks[index], x + 16, cursor + 52)))
        lanes.append(f'<g class="mm-lane mm-lane-{index % 5}" id="{namespace}-lane-{index}" '
                     f'data-family-id="{_esc(family["family_id"])}">' + "".join(parts) + "</g>")

    source_attributes = "".join(
        f' data-{key.replace("_", "-")}="{_esc(provenance[key])}"'
        for key in _PROVENANCE if key in provenance
    )
    source = '<p class="source">保存成果來源' + "".join(
        f'<code>{key}: {_esc(provenance[key])}</code>'
        for key in _PROVENANCE if key in provenance
    ) + "</p>"
    relationships = (
        "<ol>" + "".join(
            f'<li><strong>R{index + 1} · {_esc(source)} {_esc(operator)} {_esc(target)}</strong>'
            f'<p>{_esc(explanation)}</p></li>'
            for index, (source, operator, target, explanation, _) in enumerate(relations)
        ) + "</ol>"
        if relations else '<p>本成果未聲明跨方向關係；不為了畫面完整而補線。</p>'
    )
    model = content["target_model"]
    observables = _list([observable_line(item) for item in model["observables"]])
    coverage = term_coverage(content)
    terms = _list([term_line(term, coverage[term["id"]]) for term in model["governing_terms"]])
    diagram = (
        '<div class="map-context-strip"><div><span>研究範圍 · 作者原文</span>'
        f'<p>{_esc(content["landscape_summary"])}</p></div>'
        f'<div id="{namespace}-target-model"><span>目標模型 · 各作用路線的共同基準</span>'
        f'{observables}<p>主導關係：{_esc(model["governing_relation"])}</p><p>主導項與作用路線：</p>{terms}'
        f'<p>觀測量之間的耦合：</p>{_list(model["couplings"]) if model["couplings"] else "<p>未列出。</p>"}</div>'
        f'<details id="{namespace}-gaps"><summary>未解資料缺口 · '
        f'{len(content["unresolved_gaps"])} 項</summary>{_list(content["unresolved_gaps"])}</details>'
        f'<details id="{namespace}-boundary"><summary>證據邊界 · 作者原文</summary>'
        f'<p>{_esc(content["evidence_boundary_summary"])}</p></details></div>'
        f'<div class="mechanism-diagram"{source_attributes}>'
        f'<svg xmlns="http://www.w3.org/2000/svg" class="mechanism-svg" width="{width}" '
        f'height="{height}" viewBox="0 0 {width} {height}" role="img" '
        f'aria-labelledby="{namespace}-title {namespace}-description">'
        f'<title id="{namespace}-title">{_esc(content["title"])}</title>'
        f'<desc id="{namespace}-description">正式 mind map 作者聲明的作用路線和跨路線關係；'
        '不是已驗證因果。分組箭頭不代表組內各項全互連。</desc>'
        f'<defs><pattern id="{grid_id}" width="32" height="32" patternUnits="userSpaceOnUse">'
        '<path d="M32 0H0V32" class="mm-grid-line" fill="none"/></pattern>'
        f'<marker id="{arrow_id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
        'markerHeight="7" orient="auto-start-reverse">'
        '<path d="M0 0 L10 5 L0 10 Z" class="mm-arrow-tip"/></marker></defs>'
        f'<rect width="{width}" height="{height}" fill="url(#{grid_id})"/>'
        + _label(title_lines, 28, 34, "mm-overview", 24)
        + "".join(arrows) + "".join(lanes) + '</svg></div>'
        '<p class="map-boundary">每一欄是一條作用路線：可調整的槓桿 → 逐步機轉 → 對目標的作用；'
        '箭頭呈現作者聲明的機制與耦合，並非本次已驗證的因果。'
        '風險框不是因果步驟。</p>'
        '<div class="map-relations"><h4>跨研究方向的關係與證據限制</h4>'
        + relationships + '</div>'
    )
    details = "".join(_family_details(family, index, namespace, names)
                      for index, family in enumerate(families))
    return (
        f'<figure class="landscape"{source_attributes}><figcaption><div>'
        '<span class="eyebrow">正式研究成果的機制圖</span>'
        f'<strong>{_esc(content["title"])}</strong></div>'
        f'<button class="map-expand" type="button" data-map-target="{namespace}-board" '
        'aria-haspopup="dialog" aria-controls="map-dialog">放大檢視 ↗</button></figcaption>'
        f'<div class="map-scroll" id="{namespace}-board" tabindex="0" role="region" '
        f'aria-label="機制研究圖，可左右捲動"{source_attributes}>'
        + diagram + '</div>' + source + '</figure>'
        f'<div class="family-grid" id="{namespace}-families">{details}</div>'
    )
