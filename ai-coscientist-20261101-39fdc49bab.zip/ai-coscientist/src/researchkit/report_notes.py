"""Plain-spoken notes on a delivered report: one model call at delivery, printed as a separate reading copy.

The person who commissions the research asked (2026-11-01) for notes on a report's key points in the most
spoken Chinese, so that a reader from another field understands its formulas, mechanisms and deciding
numbers, and said (2026-11-02) that the notes are meant to try to explain the mathematics, the physics and
the causes, also where the report does not, with a caution in the box. The notes are not part of the
report: the delivered report stays as reviewed, and the copy with the notes (notes/report.html and .pdf in
the delivery folder) is a reading aid beside it, each box ending in CAUTION. An explanation beyond the
report can be wrong (a trial note gave a cause the wrong way round), so the checks guard only the report
itself: a note is kept when the report holds its anchor outside the passages the review found contradicted
or unsupported, the note writes no number the report does not, and a second call, reading the whole report,
finds that it keeps the report's results and their strength.
"""

from __future__ import annotations

import json
import re

from researchkit.report import render
from researchkit.review_provider import complete_once

SYSTEM = """你是這份研究報告旁邊的白話解說員。讀者很聰明，但不是這個領域的人，也沒時間查資料。你的任務：從報告裡挑出最關鍵、又最難懂的 5 到 8 個地方，各寫一段白話註記，讓人一看就懂。

挑哪裡：
- 公式或數學：這條式子在講什麼、每個符號代表什麼、哪個量變大會讓結果往哪邊走。
- 物理或化學機制：為什麼會這樣、背後是什麼在作用，用生活裡的比喻把因果講清楚。
- 決定結論的關鍵數字：大還是小、跟什麼比、對讀者代表什麼。
- 會影響這份結果怎麼用的限制。

怎麼寫：
- 像坐在旁邊跟朋友聊天那樣講，用口語。可以說「你可以想成……」「簡單講就是……」「打個比方……」。
- 短句為主，偶爾一句長的。每則二到五句。
- 先給直覺，再講式子；講到式子，就用白話把它唸出來。
- 比喻要貼切，不要硬湊。
- 盡量把背後的數學和物理講透：式子為什麼長這樣、現象為什麼會發生、因果怎麼一步步串起來。報告沒寫原因的地方，也可以用學過的物理、化學和數學試著解釋；每個框都會附警語，說明這是推想、可能有誤。
- 報告本身的結果不能動：不要加新的數字、樣本結論或來源，不要把報告的結論講反，也不要講得比報告更確定或更不確定。
- 名詞的白話說法和因果的方向要準：寧可說得樸素，也不要為了好懂說錯。
- 全部用繁體中文。
- 不要用這些套話：值得注意的是、綜上所述、總而言之、不僅……更……、不是……而是……、讓我們、原因很簡單、一句話總結、無論……還是……、此外、事實上、換句話說。不要條列，不要粗體，不要用破折號（——）接句子。

語氣範例（別的領域，只示範口吻）：
原文：「散熱速率與物體和環境的溫差成正比。」
註記：「你可以想成一杯剛泡好的熱咖啡：剛倒出來燙手，冷得很快；放到溫溫的之後，要等很久才會再涼一點。散熱快慢看的是咖啡跟房間差幾度，差越多散越快。所以式子裡那個溫差，就是決定快慢的關鍵。」

輸出：只輸出一個 JSON 陣列，不要其他文字。每一項是 {"anchor": "從報告正文逐字複製的一句話", "note": "白話註記"}。anchor 選正文的句子；講公式時，選緊接著解釋它的那一句，不要選公式本身或表格。"""

CHECK = """你負責核對白話註記有沒有改動報告的結果。輸入是一個 JSON 物件：report 是整份報告，notes 是註記陣列，每一項有編號 i、註記所在的段落 paragraph、和註記 note。

註記本來就會試著解釋數學、物理和因果，報告沒寫的原因、機制和比喻都可以有，框裡另有警語，這些不算錯。
逐則判斷，註記有沒有做到下面任何一件事：
1. 寫出報告裡沒有的數字、樣本結論或來源。
2. 跟報告的結果矛盾，或把報告的結論講反。
3. 把報告的結論講得比報告更確定或更不確定。

報告別處寫過的內容不算新增。三件事都沒有，才算 ok。

只輸出一個 JSON 陣列，每一則都要有，不要其他文字：[{"i": 編號, "ok": true 或 false, "why": "一句話理由"}]。"""

LABEL = "白話說"
READING_COPY = ("> 這是加了白話註記的閱讀版：標著「白話說」的框會試著用白話解釋背後的數學、物理和因果，"
                "有些超出報告寫的內容，是解說員的推想，沒有經過審查，可能有誤；結論以報告正文為準。"
                "證據索引與心智圖請看正式報告。")
CAUTION = "警語：這段的原因與機制是解說員的推想，報告不一定這樣寫，也沒有經過審查，可能有誤。"  # plain text: the renderer escapes HTML
NUMBER = re.compile(r"(?<![\w.])[-−]?\d+(?:[.,]\d+)?(?:[eE][-−]?\d+)?")
# Simplified characters a model slips into Traditional Chinese (one in sixteen trial notes), each with its reading here.
TRADITIONAL = str.maketrans("们这个说为时来会对发现应关过还进动经实问题开结论数据计统验证测产质变",
                            "們這個說為時來會對發現應關過還進動經實問題開結論數據計統驗證測產質變")
WINDOW = 12  # characters of an anchor that still place a note the model copied with small slips


def _value(text):
    return float(text.replace("−", "-").replace(",", ""))


def new_numbers(note, report):
    """Numbers a note writes that the report does not, compared as values (-1 is -1.0)."""
    known = {_value(number) for number in NUMBER.findall(report)}
    return [number for number in NUMBER.findall(note)
            if not any(abs(_value(number) - value) <= 1e-9 * max(1.0, abs(value)) for value in known)]


def parse(reply):
    """The notes in a reply, a JSON array of {anchor, note}; a reply without one gives none."""
    match = re.search(r"\[.*\]", reply or "", re.S)
    try:
        value = json.loads(match.group(0)) if match else []
    except ValueError:
        return []
    return [{"anchor": item["anchor"].strip(), "note": item["note"].strip()} for item in value
            if isinstance(item, dict) and isinstance(item.get("anchor"), str) and isinstance(item.get("note"), str)
            and item["anchor"].strip() and item["note"].strip()]


def locate(text, notes, avoid=()):
    """(the Markdown's blocks, [(note, block index)] for the notes placed, the notes left unplaced).

    Anchors are compared without whitespace, since the Markdown wraps lines, and failing that by a stretch of
    WINDOW characters. A paragraph in code or a table takes no note, nor one holding a passage in avoid: what the
    review found contradicted or unsupported is not made easier to believe."""
    blocks = re.split(r"(\n\s*\n)", text)
    flat, open_fence, allowed = [], False, []
    shunned = [re.sub(r"\s+", "", passage) for passage in avoid if passage and passage.strip()]
    for block in blocks:
        flat.append(re.sub(r"\s+", "", block))
        code = open_fence or "```" in block
        open_fence ^= block.count("```") % 2 == 1
        allowed.append(not code and not block.lstrip().startswith("|") and not any(p in flat[-1] for p in shunned))
    found, unplaced = [], []
    for note in notes:
        anchor = re.sub(r"\s+", "", note["anchor"])
        probes = [anchor] + [anchor[start:start + WINDOW] for start in range(0, max(0, len(anchor) - WINDOW + 1), 3)]
        index = next((i for probe in probes if probe for i, block in enumerate(flat)
                      if allowed[i] and probe in block), None)
        if index is None:
            unplaced.append(note)
        else:
            found.append((note, index))
    return blocks, found, unplaced


def insert(blocks, found):
    """The Markdown with each note as a box after its paragraph, the box ending in CAUTION."""
    placed = {}
    for note, index in found:
        placed.setdefault(index, []).append(note["note"].translate(TRADITIONAL).replace("\n", " "))
    out = []
    for index, block in enumerate(blocks):
        out.append(block)
        out.extend(f"\n\n> **{LABEL}**　{note}\n>\n> {CAUTION}" for note in placed.get(index, []))
    return "".join(out)


def place(text, notes, avoid=()):
    """(the Markdown with each note as a box after the paragraph that holds its anchor, notes left unplaced)."""
    blocks, found, unplaced = locate(text, notes, avoid)
    return insert(blocks, found), unplaced


def unfaithful(ctx, found, blocks, report):
    """Indexes into found of the notes a second call finds changing the report's results, or None if its reply
    cannot be read. The call reads the whole report: judged against its paragraph alone, a note that drew on
    another chapter looked like an addition (six of eight in a trial)."""
    items = [{"i": i, "paragraph": blocks[index].strip(), "note": note["note"]} for i, (note, index) in enumerate(found)]
    content = json.dumps({"report": report, "notes": items}, ensure_ascii=False)
    reply = complete_once(ctx, system=CHECK, messages=[{"role": "user", "content": content}])
    match = re.search(r"\[.*\]", reply.text or "", re.S)
    try:
        verdicts = json.loads(match.group(0)) if match else None
    except ValueError:
        verdicts = None
    if not isinstance(verdicts, list):
        return None
    judged = {item.get("i"): item.get("ok") for item in verdicts if isinstance(item, dict)}
    if set(judged) != set(range(len(found))):
        return None
    return {i for i, ok in judged.items() if ok is not True}


def reading_copy(text):
    """The annotated Markdown with the line that says what the copy is, after the title when there is one."""
    lines = text.split("\n")
    at = next((i + 1 for i, line in enumerate(lines) if line.startswith("# ")), 0)
    return "\n".join([*lines[:at], "", READING_COPY, "", *lines[at:]])


def write(ctx, markdown, folder, avoid=()):
    """Ask for the notes, keep those that hold, and print the reading copy into folder / "notes".

    A note holds when the report has its anchor outside avoid, it writes no number the report does not, and a
    second call finds it keeps the report's results; when that call's reply cannot be read, no note is kept.
    Returns what happened, and the copy's paths when at least one note was kept."""
    reply = complete_once(ctx, system=SYSTEM, messages=[{"role": "user", "content": markdown}])
    notes = parse(reply.text)
    kept = [note for note in notes if not new_numbers(note["note"], markdown)]
    blocks, found, unplaced = locate(markdown, kept, avoid)
    summary = {"asked": len(notes), "placed": 0, "unplaced": len(unplaced),
               "dropped_for_numbers": len(notes) - len(kept), "dropped_by_check": 0}
    if found:
        drop = unfaithful(ctx, found, blocks, markdown)
        if drop is None:
            summary.update(dropped_by_check=len(found), check="unreadable")
            found = []
        else:
            summary["dropped_by_check"] = len(drop)
            found = [item for i, item in enumerate(found) if i not in drop]
    summary["placed"] = len(found)
    if not found:
        return summary
    text = insert(blocks, found)
    source = folder / "report_notes.md"
    source.write_text(reading_copy(text), encoding="utf-8")
    printed = render(source, folder / "notes")
    return {**summary, "html_path": printed["html_path"], "pdf_path": printed["pdf_path"]}
