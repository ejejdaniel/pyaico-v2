"""Print an exact HTML snapshot with an installed Chromium browser.

This internal export helper does not regenerate the report, download a browser,
or use PyMuPDF for layout. PyMuPDF only checks the browser's resulting PDF.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time
from uuid import uuid4
import warnings
from opencode import executor


_IS_WINDOWS = os.name == "nt"
_CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
_TIMEOUT_SECONDS = 120
_TEMP_PREFIX = "cosci-report-pdf-"


def _browser_executable() -> Path:
    names = (
        "chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
        "chrome", "msedge",
    )
    for name in names:
        located = shutil.which(name)
        if located and Path(located).is_file():
            return Path(located).resolve()
    roots = [os.environ.get(key) for key in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
    if _IS_WINDOWS:
        roots.extend(("C:/Program Files", "C:/Program Files (x86)"))
    candidates = [
        Path(root) / suffix
        for root in roots if root
        for suffix in ("Google/Chrome/Application/chrome.exe", "Microsoft/Edge/Application/msedge.exe")
    ]
    candidates.append(Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise RuntimeError(
        "Report PDF browser not found. Install Chrome, Chromium or Edge; no browser is downloaded."
    )


def _terminate_browser(process: subprocess.Popen) -> None:
    """Stop only the process tree launched for this export."""
    if _IS_WINDOWS:
        try:
            executor.run(
                ["taskkill.exe", "/PID", str(process.pid), "/T", "/F"],
                executor.Launch("framework_helper", "stop browser"),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=_CREATE_NO_WINDOW, timeout=10, check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            process.kill()
    else:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except OSError:
            process.kill()
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=10)


def _print_with_browser(executable: Path, args: list[str]) -> None:
    # Redirect stderr to a private file so an arbitrarily noisy browser cannot
    # grow an in-memory pipe buffer. Only the diagnostic tail enters the error.
    with tempfile.TemporaryFile() as errors:
        options = {"creationflags": _CREATE_NO_WINDOW} if _IS_WINDOWS else {"start_new_session": True}
        process = executor.spawn(
            [str(executable), *args], executor.Launch("framework_helper", "print PDF"),
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=errors, **options,
        )
        timed_out = False
        try:
            process.wait(timeout=_TIMEOUT_SECONDS)
        except subprocess.TimeoutExpired:
            timed_out = True
            _terminate_browser(process)
        except BaseException:
            _terminate_browser(process)
            raise
        errors.seek(0, os.SEEK_END)
        errors.seek(max(0, errors.tell() - 6000))
        diagnostic = errors.read().decode("utf-8", errors="replace").strip()
        if timed_out or process.returncode != 0:
            reason = "timed out" if timed_out else f"failed ({process.returncode})"
            raise RuntimeError(f"Report PDF browser {reason}: {diagnostic}")


def _validate_pdf(pdf: bytes) -> int:
    if len(pdf) < 1024 or not pdf.startswith(b"%PDF-"):
        raise ValueError("Report PDF is empty or has an invalid signature")
    import pymupdf

    with pymupdf.open(stream=pdf, filetype="pdf") as document:
        if not len(document) or not any(page.get_text().strip() for page in document):
            raise ValueError("Rendered PDF has no readable text")
        return len(document)


def _cleanup_temporary(temporary: Path, temporary_root: Path) -> None:
    # Resolve and check the exact directory before every recursive deletion,
    # including retries after browser file locks. Never delete a broader root
    # or follow a replaced symlink/junction to another directory.
    for attempt in range(4):
        target = temporary.resolve()
        if (target != temporary.absolute() or target.parent != temporary_root
                or not target.name.startswith(_TEMP_PREFIX)):
            raise ValueError(f"Refusing report PDF cleanup outside its private temporary directory: {temporary}")
        try:
            shutil.rmtree(target)
            return
        except FileNotFoundError:
            return
        except OSError as error:
            if attempt == 3:
                warnings.warn(f"Report PDF temporary cleanup incomplete: {temporary}: {error}", RuntimeWarning)
            else:
                time.sleep(0.2)


def export_pdf(html_path: Path, pdf_path: Path) -> dict:
    """Export exact saved HTML; the return value is internal rendering metadata."""
    requested_html = Path(html_path).absolute()
    # A source file may itself be a symlink. Keep its supplied base directory
    # just as the original browser URL would, rather than following that file
    # to a different directory and changing relative evidence links.
    html_path = requested_html.parent.resolve() / requested_html.name
    # Preserve the final component so exclusive creation also rejects an
    # existing symlink instead of resolving it into an absent destination.
    requested_pdf = Path(pdf_path).absolute()
    pdf_path = requested_pdf.parent.resolve() / requested_pdf.name
    if html_path.suffix.lower() != ".html" or pdf_path.suffix.lower() != ".pdf":
        raise ValueError("Expected HTML input and PDF output")
    html = html_path.read_bytes()
    html_sha256 = hashlib.sha256(html).hexdigest()
    executable = _browser_executable()
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_root = Path(tempfile.gettempdir()).resolve()
    output = pdf_path.open("xb")
    temporary = snapshot = None
    completed = False
    try:
        with output:
            temporary = Path(tempfile.mkdtemp(prefix=_TEMP_PREFIX, dir=temporary_root))
            candidate = html_path.with_name(f".report-pdf-{uuid4().hex}.html")
            with candidate.open("xb") as saved:
                snapshot = candidate
                saved.write(html)
            staged = temporary / "report.pdf"
            _print_with_browser(executable, [
                "--headless=new", "--disable-gpu", "--disable-extensions", "--disable-background-networking",
                "--no-first-run", "--no-default-browser-check", "--no-pdf-header-footer",
                "--run-all-compositor-stages-before-draw", "--virtual-time-budget=3000",
                f"--user-data-dir={temporary / 'profile'}", f"--print-to-pdf={staged}", snapshot.as_uri(),
            ])
            pdf = staged.read_bytes()
            pages = _validate_pdf(pdf)
            output.write(pdf)
        completed = True
        return {"pages": pages, "html_sha256": html_sha256, "browser": str(executable)}
    finally:
        if not completed:
            pdf_path.unlink(missing_ok=True)
        if snapshot is not None:
            try:
                snapshot.unlink(missing_ok=True)
            except OSError as error:
                warnings.warn(f"Report PDF snapshot cleanup incomplete: {snapshot}: {error}", RuntimeWarning)
        if temporary is not None:
            _cleanup_temporary(temporary, temporary_root)
