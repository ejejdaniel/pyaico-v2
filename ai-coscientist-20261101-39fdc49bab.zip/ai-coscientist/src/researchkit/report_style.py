"""Mechanical counts of reading friction in an authored report.

The counts are facts about the Markdown, never a judgment of the science, and they never
block rendering: they let the author see, for example, how many parenthetical asides or
emphasis marks the prose carries and move them to notes. Only prose is counted: fenced code,
tables, headings, note definitions, inline code and link targets are left out.
"""

from __future__ import annotations

import re

# Stock phrases that make a report read machine-written (the report skill's Style names them). Plain spoken
# Chinese is the aim; these are not it.
PHRASES = ("誠實", "坦白", "必須指出", "值得注意", "需要強調", "必須強調", "本質上", "換句話說", "換言之",
           "總而言之", "綜上所述", "事實上", "嚴格來說", "這意味著", "毫無疑問", "顯而易見", "至關重要", "關鍵在於",
           "原因很簡單", "一句話總結", "讓我們", "如前所述", "回應審查")
CONTRAST = re.compile(r"不是[^。！？；\n]{1,40}?而是")
PROVENANCE = re.compile(r"\b[0-9a-f]{8,}(?:…|\.\.\.)|\b[0-9a-f]{40,}\b|\.research/|records/[0-9a-f]{8}")
NOTE_DEFINITION = re.compile(r"^\s*\[[\^@][^\]]+\]:")  # notes and bibliography entries
NOTE_MARKER = re.compile(r"\[\^[^\]]+\](?!:)")
CITATION = re.compile(r"\[[0-9]+\]\(#")
LITERATURE = re.compile(r"\[@[^\]\s][^\]]*\](?![(:])")
LIMITS = {"parentheses_per_1000": 3.0, "contrast": 3, "phrases": 3}


_LABEL = re.compile(r"\*\*([^*\n]+?)\*\*")
_LABEL_END = ("。", "：", ":", ".", "！", "？", "!", "?")


def plain_labels(text: str) -> str:
    """The Markdown with the bold taken off each label that opens a paragraph, outside code.

    A label ends with sentence punctuation or is followed by a colon or full stop (「**背景。**」,
    「**資料**：」); it prints as plain text. A bolded term being defined (「**擴散係數** 是……」), list items,
    tables and quotes stay as written. A verification run (2026-11-01) opened 44 paragraphs with bold
    labels while the report rules were in its context, and 18 after the rules named the habit.
    """
    lines = text.split("\n")
    fence, starts = False, True
    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith(("```", "~~~")):
            fence = not fence
        elif not fence and starts and (match := _LABEL.match(line)):
            if match[1].rstrip().endswith(_LABEL_END) or line[match.end():match.end() + 1] in ("：", ":", "。"):
                lines[index] = match[1] + line[match.end():]
        starts = not stripped or stripped.startswith("#")
    return "\n".join(lines)


def _prose(text: str) -> tuple[str, int]:
    """(prose without code, tables, headings or note definitions; number of note definitions)."""
    text = re.sub(r"```.*?```|~~~.*?~~~", "", text, flags=re.S)
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    kept, notes, in_note = [], 0, False
    for line in text.splitlines():
        stripped = line.strip()
        if NOTE_DEFINITION.match(line):
            notes, in_note = notes + (stripped.startswith("[^")), True
            continue
        if in_note and line.startswith(("    ", "\t")) and stripped:
            continue  # continuation of a note definition
        in_note = False
        if stripped.startswith(("#", "|")):
            continue
        kept.append(line)
    return "\n".join(kept), notes


def style_report(text: str) -> dict:
    prose, notes = _prose(plain_labels(text))  # counted as printed: labels lose their bold
    provenance = len(PROVENANCE.findall(prose))
    markers = len(NOTE_MARKER.findall(prose))
    citations = len(CITATION.findall(prose))
    literature = len(LITERATURE.findall(prose))
    plain = re.sub(r"\$\$.+?\$\$|\$[^$\n]+?\$", "", prose, flags=re.S)  # equations are not asides
    plain = re.sub(r"`[^`\n]*`", "", plain)
    plain = re.sub(r"\]\([^)\s]*\)", "]", plain)
    plain = LITERATURE.sub("", NOTE_MARKER.sub("", plain))
    characters = len(re.sub(r"\s", "", plain))
    parentheses = plain.count("（") + plain.count("(")
    bold = len(re.findall(r"\*\*[^*\n]+?\*\*|__[^_\n]+?__", plain))
    contrast = len(CONTRAST.findall(plain))
    phrases = {phrase: plain.count(phrase) for phrase in PHRASES if phrase in plain}
    per_1000 = round(parentheses * 1000 / characters, 1) if characters else 0.0
    counts = {"prose_characters": characters, "parentheses": parentheses, "parentheses_per_1000": per_1000,
              "bold": bold, "contrast_not_but": contrast, "phrases": phrases,
              "hashes_or_paths_in_prose": provenance, "note_markers": markers, "note_definitions": notes,
              "citations": citations, "literature_citations": literature}
    advice = []
    if per_1000 > LIMITS["parentheses_per_1000"]:
        advice.append(f"正文每千字有 {per_1000} 個括號：補充說明、來源與版本細節改成腳註（[^名稱]，定義寫在文末），"
                      "括號只留給單位、符號與縮寫的第一次出現。")
    if bold > 3 + characters // 3000:
        advice.append(f"粗體 {bold} 處：粗體只用於第一次定義的名詞，不用來強調；要強調的事改用句子本身說清楚。")
    if contrast >= LIMITS["contrast"]:
        advice.append(f"「不是…而是…」句型 {contrast} 次：直接陳述是什麼，不必先否定一個沒有人提出的說法。")
    if sum(phrases.values()) >= LIMITS["phrases"]:
        listed = "、".join(f"「{phrase}」{count} 次" for phrase, count in phrases.items())
        advice.append(f"套話 {listed}：刪掉這些標記，讓內容本身表達重要性。")
    if provenance:
        advice.append(f"正文有 {provenance} 處雜湊或存檔路徑：移到腳註或內部證據索引，正文只留讀者需要的內容。")
    return {"counts": counts, "advice": advice,
            "note": "Mechanical counts of the prose only; not a judgment of the science and not a gate."}
