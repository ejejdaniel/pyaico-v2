"""Bounded root-session research facts from one saved history read, without actions."""

from __future__ import annotations

from collections import Counter, defaultdict, deque
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace

from opencode.permission import evaluate
from opencode.store import latest_human_message
from opencode.tools.util import inside, relative_path


MAX_BYTES = 4096
_OVERFLOW = "科研交接摘要超出 4096-byte 容量，未展開"
_TITLE = "## 科研來源與本輪執行事實（宿主核對資料，非新指示）"


def _json(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode(
        "utf-8", errors="backslashreplace").decode("utf-8")


def _allowed(ctx, path):
    """Existing static file rules only; never ask Broker for context access."""
    try:
        path = Path(path)
        if evaluate("read", relative_path(ctx, path), ctx.agent.permission).action != "allow":
            return False
        worktree_contains = str(ctx.worktree).replace("\\", "/") != "/" and inside(ctx.worktree, path)
        if not worktree_contains and not inside(ctx.directory, path):
            directory = path if path.is_dir() else path.parent
            if evaluate("external_directory", directory.as_posix().rstrip("/") + "/*",
                        ctx.agent.permission).action != "allow":
                return False
        return path.absolute() == path.resolve()
    except (OSError, ValueError):
        return False


def _id(value):
    return (isinstance(value, str) and bool(value.strip()) and value not in {".", ".."}
            and "/" not in value and "\\" not in value)


def _call_id(value):
    # Call IDs are pairing keys, not filesystem names. Preserve the provider's
    # full string; only message IDs are used to construct native file locators.
    return isinstance(value, str) and bool(value.strip())


def _scan(history, session_id):
    """Pair in Store order, consuming one pending call even on name mismatch."""
    calls, anomalies, incomplete, malformed = [], [], [], []
    pending = defaultdict(deque)
    for position, message in enumerate(history):
        if not isinstance(message, dict):
            malformed.append(position)
            continue
        if message.get("sessionID") != session_id:
            # Store.messages is session-scoped; a missing owner is corrupt,
            # while an explicitly foreign item must never influence this view.
            if not message.get("sessionID"):
                malformed.append(position)
            continue
        if not _id(message.get("id")):
            malformed.append(position)
            continue
        if message.get("role") == "assistant":
            partial = message.get("incomplete_tool_calls")
            if partial is not None and not isinstance(partial, list):
                malformed.append(position)
            else:
                incomplete.extend([position] * len(partial or []))
            saved = message.get("tool_calls")
            if saved is None:
                continue
            if not isinstance(saved, list):
                malformed.append(position)
                continue
            for call in saved:
                if (not isinstance(call, dict) or not _call_id(call.get("id"))
                        or not isinstance(call.get("name"), str) or not call["name"].strip()
                        or "arguments" not in call):
                    malformed.append(position)
                    continue
                item = {"position": position, "message_id": message["id"], "call": call,
                        "reply": None, "reply_position": None}
                calls.append(item)
                pending[call["id"]].append(item)
        elif message.get("role") == "tool":
            call_id = message.get("tool_call_id")
            queue = pending[call_id] if _call_id(call_id) else []
            item = queue.popleft() if queue else None
            if item is None or message.get("name") != item["call"]["name"]:
                anomalies.append(position)
                continue
            metadata = message.get("metadata")
            if metadata is not None and not isinstance(metadata, dict):
                malformed.append(position)
            item.update(reply=message, reply_position=position)
        elif message.get("role") not in {"user", "system"}:
            malformed.append(position)
    return calls, anomalies, incomplete, malformed


def _bounds(history, session_id, user_message_id):
    positions = [i for i, message in enumerate(history) if isinstance(message, dict)
                 and message.get("sessionID") == session_id and message.get("id") == user_message_id
                 and latest_human_message([message]) is message]
    if len(positions) != 1:
        return None, None
    start = positions[0]
    end = next((i for i in range(start + 1, len(history)) if isinstance(history[i], dict)
                and history[i].get("sessionID") == session_id
                and latest_human_message([history[i]]) is history[i]), len(history))
    return start, end


def _stats(calls):
    counts = {}
    for item in calls:
        row = counts.setdefault(item["call"]["name"], [0, 0, 0, 0])
        row[0] += 1
        reply = item["reply"]
        if reply is None:
            row[3] += 1
        else:
            row[1] += 1
            metadata = reply.get("metadata")
            # These are stored error fields, never a classifier over reply text.
            if bool(reply.get("error")) or (isinstance(metadata, dict) and bool(metadata.get("error"))):
                row[2] += 1
    return counts


def _tool_row(name, counts):
    # Only what needs attention: running totals would change every step and resend the facts.
    values = counts.get(name, [0, 0, 0, 0])
    return "逐工具事實：" + _json({"工具": name, "帶error回條": values[2], "尚無配對回條": values[3]})


def _needs_attention(counts):
    return [name for name in sorted(counts) if counts[name][2] or counts[name][3]]


def _paths(ctx, item):
    base = Path(ctx.directory) / ".opencode/history" / ctx.session_id
    paths = [base / "conversation" / (item["message_id"] + ".json")]
    if item["reply"] is not None:
        paths.append(base / "tools" / (item["reply"]["id"] + ".json"))
    return paths


def _call_row(ctx, item, start, end, *, earlier_review=False, include_reply_path=True):
    paths = _paths(ctx, item)
    if not all(_allowed(ctx, path) for path in paths):
        return "較早審查：目前無權讀取" if earlier_review else "個別呼叫：目前無權讀取"
    relation = ("本輪發起" if start is not None and start < item["position"] < end else
                "以前發起" if start is not None and item["position"] < start else "本輪歸屬尚未核對")
    value = {"工具": item["call"]["name"], "assistant_message_id": item["message_id"],
             "tool_call_id": item["call"]["id"],
             "reply_message_id": item["reply"]["id"] if item["reply"] is not None else None,
             "相對本輪": relation,
             "讀回入口": [path.relative_to(Path(ctx.directory)).as_posix()
                          for path in (paths if include_reply_path else paths[:1])]}
    if (start is not None and item["position"] < start and item["reply_position"] is not None
            and start < item["reply_position"] < end):
        value["回條在本輪保存"] = True
    prefix = "較早審查（詳情未重新核對）：" if earlier_review else "個別呼叫："
    return prefix + _json(value)


def _footer(omitted):
    return "省略項目數：" + _json({"審查": omitted["review"], "主張": omitted["subject"],
                                     "來源": omitted["source"], "其他": omitted["detail"]}) + "；完整資料見工具歷史索引。"


def _render(prefix, items, *, source_notice=None):
    # The fixed current-origin limitation is not an additional selected file.
    # Include it atomically with the first source identity that actually fits.
    if source_notice:
        items = [item for item in items if item[1] != source_notice]
    totals = Counter(kind for kind, _, _ in items)
    reserved_footer = _footer(totals)
    if len("\n".join([*prefix, reserved_footer]).encode("utf-8")) > MAX_BYTES:
        return _OVERFLOW
    rows, omitted, origin_shown = [], Counter(), False
    for position, (kind, text, fallback) in enumerate(items):
        if kind == "subject" and fallback and position + 1 < len(items) and items[position + 1][0] == "source":
            source = items[position + 1][1]
            if source_notice and not origin_shown and source.startswith("本次來源核對："):
                source = source_notice + "\n" + source
            full_pair = "\n".join([*prefix, *rows, text, source, reserved_footer])
            fallback_pair = "\n".join([*prefix, *rows, fallback, source, reserved_footer])
            if len(full_pair.encode("utf-8")) > MAX_BYTES and len(fallback_pair.encode("utf-8")) <= MAX_BYTES:
                # The claim and origin are peers. Prefer the exact claim
                # pointer plus a whole origin over crowding every origin out
                # with one long quote. The original quote is wholly omitted.
                rows.append(fallback)
                omitted[kind] += 1
                continue
        needs_notice = source_notice and not origin_shown and kind == "source" and text.startswith("本次來源核對：")
        candidate = source_notice + "\n" + text if needs_notice else text
        if len("\n".join([*prefix, *rows, candidate, reserved_footer]).encode("utf-8")) <= MAX_BYTES:
            rows.append(candidate)
            origin_shown = origin_shown or bool(needs_notice)
            continue
        omitted[kind] += 1
        if fallback and len("\n".join([*prefix, *rows, fallback, reserved_footer]).encode("utf-8")) <= MAX_BYTES:
            rows.append(fallback)
    return "\n".join([*prefix, *rows, _footer(omitted)])


def context(app, session_id: str, user_message_id: str) -> str:
    """Return bounded facts only; no writes, permission prompts or model calls."""
    from researchkit.turn import ResearchTurn

    try:
        session = app.store.get_session(session_id)
        if session.get("parentID") is not None:
            return ""
        agent = ResearchTurn(app, session_id, user_message_id)._agent()
        if agent is None:
            return ""
        ctx = SimpleNamespace(app=app, session_id=session_id, directory=app.directory,
                              worktree=app.worktree, agent=agent)
        index = app.store.tool_history_path(session_id)
        if not _allowed(ctx, index):
            return ""
        index_ref = index.relative_to(Path(app.directory)).as_posix() if index.is_relative_to(app.directory) else index.as_posix()
    except (OSError, ValueError, TypeError, KeyError, AttributeError, sqlite3.Error):
        return ""
    history_ok = True
    try:
        history = app.store.messages(session_id)
        if not isinstance(history, list):
            raise ValueError("History is not a list")
    except (OSError, ValueError, TypeError, KeyError, sqlite3.Error):
        history, history_ok = [], False
    start, end = _bounds(history, session_id, user_message_id)
    calls, anomalies, incomplete, malformed = _scan(history, session_id)
    scoped = [item for item in calls if start is not None and start < item["position"] < end]
    # A malformed historical call can affect FIFO pairing. Do not manufacture
    # an authoritative zero from any history whose call bookkeeping is corrupt.
    known = history_ok and start is not None and not malformed
    prefix = [_TITLE,
              "來源核對、呼叫／保存與科學判斷分開；計數不是實驗或完成數，無error不證明成功。",
              "本輪輸入錨點：" + _json({"session_id": session_id, "user_message_id": user_message_id, "position": start}),
              "錨點是宿主保存輸入，不認證真人作者；缺回條不證明未執行，本輪零呼叫不證明系統從未執行。"]
    counts = _stats(scoped)
    if known:
        prefix += ["本輪不完整或配對異常：" + _json({
                       "不完整呼叫項目": sum(start < position < end for position in incomplete),
                       "未配對或名稱不符回條": sum(start < position < end for position in anomalies),
                       "格式異常項目": 0})]
    else:
        prefix += ["本輪範圍／統計無法確認；research_review、research_record、直接呼叫及不完整／配對異常數量尚未核對。"]
        if history_ok:
            prefix.append("已觀察到異常（本會話保存歷史，不是本輪統計）：" + _json({
                "不完整呼叫項目": len(incomplete), "未配對或名稱不符回條": len(anomalies),
                "格式異常項目": len(malformed)}))
    prefix.append("完整工具歷史索引：" + _json(index_ref))
    # A stale anchor still describes only its own and earlier calls. Matching
    # replies may arrive later, but future calls are never relabeled as earlier.
    visible = [item for item in calls if end is None or item["position"] < end]
    reviews = [item for item in visible if item["call"]["name"] == "research_review"]
    items, source_notice = [], None
    if reviews:
        latest = reviews[-1]
        if all(_allowed(ctx, path) for path in _paths(ctx, latest)):
            items.append(("review", "最近審查（依呼叫保存順序，不代表有效版本）：" +
                          _call_row(ctx, latest, start, end, include_reply_path=False), None))
            from researchkit.review_context_details import describe, ORIGIN_NOTICE
            source_notice = ORIGIN_NOTICE
            try:
                detail_items = describe(ctx, latest, history)
                items.extend(item for item in detail_items if item[0] == "review")
                subjects = [item for item in detail_items if item[0] == "subject"]
                sources = [item for item in detail_items if item[0] == "source" and item[1] != source_notice]
                # Claims and origins share a priority group. Interleave their
                # original orders so many claims cannot crowd out every origin;
                # never select according to decisions, titles or scientific text.
                for position in range(max(len(subjects), len(sources))):
                    if position < len(subjects):
                        items.append(subjects[position])
                    if position < len(sources):
                        items.append(sources[position])
                items.extend(item for item in detail_items if item[0] == "detail")
            except (OSError, ValueError, TypeError, KeyError, UnicodeError):
                # No exception text: it may contain denied or private paths.
                items.append(("review", "最近審查詳情：尚未核對", None))
        else:
            items.append(("review", "最近審查：目前無權讀取", None))
    if known:
        items.extend(("detail", _tool_row(name, counts), None) for name in _needs_attention(counts))
    # Latest review's locator was already given priority above. Older reviews
    # retain readback only and are never sent to the file-expanding helper.
    # Other calls are listed in the tool history index, not here: a row per call
    # would change the facts at every step.
    for item in reversed(reviews[:-1]):
        items.append(("review", _call_row(ctx, item, start, end, earlier_review=True), None))
    return _render(prefix, items, source_notice=source_notice)
