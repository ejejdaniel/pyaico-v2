"""Freeze a candidate, obtain scoped review, then solve the identical input."""

from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import uuid

from opencode.provider import _check_abort
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import inference, records, reviewer
from researchkit.report_evidence import resolve


INPUT_SCHEMA = inference.INPUT_SCHEMA
REVIEW_SCOPE_PATH = Path(__file__).parent / "skills/materializer/references/inference-review.md"


def execute(args, ctx):
    root = ctx.directory.resolve()
    abort = _abort_event(ctx)
    arguments = deepcopy(args)

    def check_read(path):
        _check_abort(abort)
        ensure_access(ctx, path, "read")

    def authorize(path):
        _check_abort(abort)
        reviewer._save_path(root, path)
        for permission in ("edit", "read"):
            ensure_access(ctx, path, permission)

    def save(path, raw):
        authorize(path)
        with path.open("xb") as stream:
            stream.write(raw)
        check_read(path)
        if path.read_bytes() != raw:
            raise ValueError(f"Research inference saved bytes changed: {path}")

    def verified_bytes(saved, expected):
        """Check committed bytes against this invocation's captured authority."""
        _check_abort(abort)
        ref = saved["record_path"]
        manifest = records.read_record(root, ref, check_read=check_read)
        if {item["source_path"] for item in manifest["files"]} != set(expected):
            raise ValueError(f"Research inference published file selection changed: {ref}")
        for item in manifest["files"]:
            path = records.local_path((root / ref).parent, item["snapshot"])
            check_read(path)
            if path.read_bytes() != expected[item["source_path"]]:
                raise ValueError(f"Research inference frozen bytes changed: {ref}")

    _check_abort(abort)
    problem = inference.validate_input(arguments)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="check_inference", patterns=["*"],
                            always=["*"], ruleset=ctx.agent.permission, metadata={}, abort_event=abort)
    dependencies = inference.validate_sources(root, problem, check_read=check_read)
    records._read_dependencies(root, dependencies, check_read=check_read)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_review", patterns=dependencies,
                            always=["*"], ruleset=ctx.agent.permission, metadata={}, abort_event=abort)
    scope = REVIEW_SCOPE_PATH.read_text(encoding="utf-8")
    if not scope.strip():
        raise ValueError("Inference review commission must be nonblank")

    parent = root / ".research/inference-preparations"
    folder = parent / uuid.uuid4().hex
    candidate_paths = {name: folder / name for name in ("arguments.json", "input.json", "review.json")}
    for path in (parent, folder, *candidate_paths.values(), root / ".research/records"):
        authorize(path)
    _check_abort(abort)
    parent.mkdir(parents=True, exist_ok=True)
    reviewer._save_path(root, folder).mkdir()
    argument_raw, input_raw = records.encoded(arguments), records.encoded(problem)
    save(candidate_paths["arguments.json"], argument_raw)
    save(candidate_paths["input.json"], input_raw)
    initial = {candidate_paths[name].relative_to(root).as_posix(): raw
               for name, raw in (("arguments.json", argument_raw), ("input.json", input_raw))}
    input_source = candidate_paths["input.json"].relative_to(root).as_posix()
    candidate = records.publish(root, kind="implementation", title="Candidate formalization: " + problem["scope"],
                                files=list(initial), depends_on=dependencies, check_read=check_read)
    verified_bytes(candidate, initial)

    selected = list({(c["record_ref"], c["source_path"]):
                     {"record_ref": c["record_ref"], "source_path": c["source_path"]}
                     for c in inference._citations(problem)}.values())
    goal = problem["goal"]["source"]
    review_args = {
        "scope": scope,
        "reviewed_refs": [candidate["record_path"], goal["record_ref"]],
        "files": [*selected, {"record_ref": candidate["record_path"], "source_path": input_source}],
        "required_subjects": [
            {key: goal[key] for key in ("record_ref", "source_path", "quote")},
            {"record_ref": candidate["record_path"], "source_path": input_source, "quote": input_raw.decode("utf-8")},
        ],
    }
    # The reviewer receives the original claim and complete candidate, not a
    # solver result, inherited conversation, expected verdict or prior review.
    _check_abort(abort)
    assessed = reviewer.execute(review_args, ctx)
    _check_abort(abort)
    verified_bytes(candidate, initial)
    review_raw = assessed.output.encode("utf-8")
    review_value = inference.parse_json(review_raw)
    if len(review_raw) > inference.MAX_BYTES:
        raise ValueError("Research inference review exceeds 262144 UTF-8 bytes")
    save(candidate_paths["review.json"], review_raw)
    review_source = candidate_paths["review.json"].relative_to(root).as_posix()
    reviewed = records.publish(root, kind="review", title="Formalization and source assessment: " + problem["scope"],
                               files=[review_source],
                               depends_on=list(dict.fromkeys([candidate["record_path"], *dependencies])),
                               check_read=check_read)
    verified_bytes(reviewed, {review_source: review_raw})
    verified_bytes(candidate, initial)

    # Read the reviewed version from its verified snapshot. Re-serialization
    # must match it exactly before any computation; caller changes are irrelevant.
    frozen = resolve(root, [{"record_ref": candidate["record_path"], "source_path": input_source}],
                     check_read=check_read)[0]["text"].encode("utf-8")
    if frozen != input_raw:
        raise ValueError("Reviewed inference input changed before solver execution")
    solver_folder = records.local_path(root, f".research/inference-runs/{uuid.uuid4().hex}")
    authorize(solver_folder)
    solved = inference.run(frozen, root, solver_folder, check_read=check_read, abort=abort,
                           extra_dependencies=(candidate["record_path"], reviewed["record_path"]),
                           expected_input=input_raw)
    _check_abort(abort)
    verified_bytes(candidate, initial)
    verified_bytes(reviewed, {review_source: review_raw})
    result_source = (solver_folder / "result.json").relative_to(root).as_posix()
    outcome = inference.parse_json(resolve(root, [{"record_ref": solved["record_path"], "source_path": result_source}],
                                           check_read=check_read)[0]["text"])
    committed_review = inference.parse_json(resolve(root, [{"record_ref": reviewed["record_path"],
                                                          "source_path": review_source}], check_read=check_read)[0]["text"])
    if committed_review != review_value:
        raise ValueError("Published review changed before return")
    _check_abort(abort)
    # Decisions stay evidence for the author. No supported/unsupported routing,
    # science approval flag, automatic rewrite, or additional model call here.
    return ToolResult(title="research_inference", output=json.dumps(
        {**solved, "result": outcome, "review_record_ref": reviewed["record_path"], "review": committed_review},
        ensure_ascii=False, indent=2, allow_nan=False))
