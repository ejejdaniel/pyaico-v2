"""Validate exact review citations, without interpreting scientific support."""

from __future__ import annotations

import json
from pathlib import Path

from .records import digest, local_path


def _fail(path, message):
    raise ValueError(f"review.json{path}: {message}")


def _object(value, fields, path):
    if not isinstance(value, dict):
        _fail(path, "expected an object")
    missing = sorted(set(fields) - value.keys())
    extra = sorted(value.keys() - set(fields))
    if missing or extra:
        _fail(path, f"missing={missing}, unexpected={extra}")


def _text(value, path):
    if not isinstance(value, str) or not value.strip():
        _fail(path, "expected nonblank text")


def _array(value, path, *, nonempty=False):
    if not isinstance(value, list) or (nonempty and not value):
        _fail(path, "expected a nonempty array" if nonempty else "expected an array")


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            _fail("", f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def _newlines(text):
    return text.replace("\r\n", "\n").replace("\r", "\n")


def validate(root: Path, data: bytes, dependencies: list[str], verified: dict,
             *, check_read=None) -> None:
    return _validate(root, data, dependencies, verified, check_read=check_read,
                     read_snapshot=lambda path: path.read_bytes())


def _validate(root: Path, data: bytes, dependencies: list[str], verified: dict,
              *, check_read, read_snapshot) -> None:
    # data is the captured publication content, never a second working-file read.
    try:
        value = json.loads(data.decode("utf-8-sig"), object_pairs_hook=_unique_keys)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        _fail("", f"expected UTF-8 JSON: {exc}")
    _object(value, {"reviewed_refs", "checks"}, "")
    errors = []

    def inspect(fn, *args):
        try:
            return True, fn(*args)
        except ValueError as exc:
            errors.append(str(exc))
            return False, None

    reviewed = value["reviewed_refs"]
    _array(reviewed, "/reviewed_refs", nonempty=True)
    selected = set()
    for i, ref in enumerate(reviewed):
        path = f"/reviewed_refs/{i}"
        if not inspect(_text, ref, path)[0]:
            continue
        if ref not in dependencies:
            inspect(_fail, path, "must be an exact relative record_ref in direct depends_on")
            continue
        if ref in selected:
            inspect(_fail, path, "duplicate reviewed reference")
        selected.add(ref)

    texts = {}
    snapshots = {}

    def locator(item, path, allowed):
        _object(item, {"record_ref", "source_path", "quote"}, path)
        for field in ("record_ref", "source_path", "quote"):
            _text(item[field], f"{path}/{field}")
        ref, source, quote = item["record_ref"], item["source_path"], item["quote"]
        if ref not in allowed:
            _fail(path + "/record_ref", "not in the selected exact references")
        key = (ref, source)
        if key not in texts:
            matches = [f for f in verified[ref]["files"] if f["source_path"] == source]
            if len(matches) != 1:
                _fail(path + "/source_path", "must exactly select one files[].source_path")
            item_file = matches[0]
            folder = local_path(root, ref).parent
            snapshot = local_path(folder, item_file["snapshot"])
            if check_read:
                check_read(snapshot)
            raw = read_snapshot(snapshot)
            if digest(raw) != item_file["sha256"] or len(raw) != item_file["bytes"]:
                _fail(path, "selected snapshot changed before quote verification")
            try:
                texts[key] = _newlines(raw.decode("utf-8-sig"))
                snapshots[key] = snapshot
            except UnicodeDecodeError:
                _fail(path + "/source_path", "selected snapshot is not UTF-8 text")
        if _newlines(quote) not in texts[key]:
            _fail(path + "/quote", "literal quote not found in the selected snapshot; "
                  f"submitted={json.dumps(quote, ensure_ascii=False)}; "
                  f"record_ref={ref}; source_path={source}; "
                  f"read frozen source={json.dumps(str(snapshots[key]), ensure_ascii=False)}")
        return ref, source, quote

    checks = value["checks"]
    _array(checks, "/checks", nonempty=True)
    used = set()
    for i, check in enumerate(checks):
        path = f"/checks/{i}"
        if not inspect(_object, check, {"subject", "evidence", "decision", "reason"}, path)[0]:
            continue
        inspect(_text, check["reason"], path + "/reason")
        if check["decision"] not in ("supported", "conditional", "contradicted", "unsupported", "unassessed"):
            inspect(_fail, path + "/decision", "expected supported, conditional, contradicted, unsupported or unassessed")
        subject = check["subject"]
        if isinstance(subject, dict) and isinstance(subject.get("record_ref"), str):
            # An invalid quote is not also a missing subject declaration.
            used.add(subject["record_ref"])
        inspect(locator, subject, path + "/subject", selected)
        if not inspect(_array, check["evidence"], path + "/evidence")[0]:
            continue
        if not check["evidence"] and check["decision"] != "unassessed":
            inspect(_fail, path + "/evidence", "empty evidence requires decision=unassessed")
        seen = set()
        for j, evidence in enumerate(check["evidence"]):
            entry_path = f"{path}/evidence/{j}"
            valid, exact = inspect(locator, evidence, entry_path, verified)
            if not valid:
                continue
            if exact in seen:
                inspect(_fail, entry_path, "duplicate evidence locator")
            seen.add(exact)
    for i, ref in enumerate(reviewed):
        if isinstance(ref, str) and ref in selected and ref not in used:
            inspect(_fail, f"/reviewed_refs/{i}", "no check.subject refers to this record")
    if errors:
        raise ValueError("\n".join(errors))
