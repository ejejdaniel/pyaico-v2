"""Read-only details for one saved review call, without scientific adjudication."""

from collections import defaultdict, deque
import json
from pathlib import Path

from opencode import runtime_settings
from opencode.permission import evaluate
from opencode.tools.util import relative_path
from researchkit import records, review, reviewer, tool_receipts
from researchkit.source_provenance import NativeSources, _difference


MAX_BYTES = runtime_settings.get("model_request.max_bytes")  # the review packet; config/runtime.json
ORIGIN_NOTICE = ("以下來源身分是本次讀回對目前 Store 的重新核對，不是當時已核對或模型已讀取的證明；"
                 "不改變保存判詞，也不代表科學支持。")


def _q(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode(
        "utf-8", errors="backslashreplace").decode("utf-8")


class _Issue(ValueError):
    def __init__(self, status, path=None):
        self.status, self.path = status, path


def _parse(raw):
    def constant(value):
        raise ValueError("Invalid JSON constant")
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=review._unique_keys,
                      parse_constant=constant)


class _Reader:
    def __init__(self, ctx, history):
        self.ctx, self.history = ctx, history
        self.root = Path(ctx.directory).resolve()
        self.native = NativeSources(ctx, history=history)
        self.captured = {}
        self.verified, self.selected_raw, self.selection, self.entries = {}, {}, {}, {}

    def access(self, path, permission="read"):
        path = Path(path)
        if evaluate(permission, relative_path(self.ctx, path), self.ctx.agent.permission).action != "allow":
            raise _Issue("目前無權讀取")
        if path.absolute() != path.resolve() or not path.resolve().is_relative_to(self.root):
            raise _Issue("內容不符")

    def local(self, ref):
        path = self.root / ref
        self.access(path)
        return path

    def read(self, ref, *, limit=MAX_BYTES):
        path = self.local(ref)
        try:
            if path.stat().st_size > limit:
                raise _Issue("超過讀回容量", ref)
            with path.open("rb") as stream:
                raw = stream.read(limit + 1)
            if len(raw) > limit:
                raise _Issue("超過讀回容量", ref)
        except FileNotFoundError:
            raise _Issue("缺檔", ref) from None
        except PermissionError:
            raise _Issue("目前無權讀取") from None
        previous = self.captured.setdefault(path, raw)
        if previous != raw:
            raise _Issue("內容不符", ref)
        return raw

    def json(self, ref, *, canonical=False):
        raw = self.read(ref)
        value = _parse(raw)
        if canonical and records.encoded(value) != raw:
            raise _Issue("內容不符", ref)
        return value

    def manifest(self, ref, *, limit=MAX_BYTES):
        reviewer._reference(ref)
        raw = self.read(ref, limit=limit)
        if records.digest(raw) != ref.split("/")[2]:
            raise _Issue("內容不符", ref)
        value = _parse(raw)
        reviewer._object(value, ("kind", "title", "files", "depends_on"), "record")
        reviewer._text(value["kind"], "kind")
        reviewer._text(value["title"], "title")
        reviewer._array(value["files"], "files")
        if not isinstance(value["depends_on"], list):
            raise ValueError("Invalid record dependencies")
        for dependency in value["depends_on"]:
            reviewer._reference(dependency)
        for entry in value["files"]:
            reviewer._object(entry, ("source_path", "snapshot", "sha256", "bytes"), "record file")
        return value, raw

    def selected(self, args):
        used = 0
        for number, locator in enumerate(args["files"], 1):
            ref, source = locator["record_ref"], locator["source_path"]
            # Authorize the original locator as well as its frozen destination;
            # a denied path is never repeated in the resulting context.
            self.local(source)
            if ref not in self.verified:
                manifest, raw = self.manifest(ref, limit=MAX_BYTES - used)
                used += len(raw)
                self.verified[ref] = manifest
            entries = [item for item in self.verified[ref]["files"] if item["source_path"] == source]
            if len(entries) != 1:
                raise ValueError("Selected file does not resolve exactly")
            entry = entries[0]
            snapshot = (Path(ref).parent / entry["snapshot"]).as_posix()
            raw = self.read(snapshot, limit=MAX_BYTES - used)
            used += len(raw)
            if (records.digest(raw) != entry["sha256"] or type(entry["bytes"]) is not int
                    or len(raw) != entry["bytes"]):
                raise _Issue("內容不符", snapshot)
            content = review._newlines(raw.decode("utf-8-sig"))
            for subject in args.get("required_subjects", []):
                if (subject["record_ref"], subject["source_path"]) == (ref, source):
                    if review._newlines(subject["quote"]) not in content:
                        raise ValueError("Required subject is not in the selected file")
            lines = content.split("\n")
            if lines[-1] == "":
                lines.pop()
            self.selection[f"F{number}"] = {**locator, "lines": tuple(lines)}
            self.selected_raw[ref, source] = raw
            self.entries[ref, source] = entry

    def check_review(self, raw, args):
        if len(raw) > MAX_BYTES:
            raise _Issue("超過讀回容量")
        value = _parse(raw)
        if value.get("reviewed_refs") != args["reviewed_refs"]:
            raise ValueError("Review differs from the original reviewed references")
        selected = set(self.selected_raw)
        for check in value["checks"]:
            for locator in [check["subject"], *check["evidence"]]:
                if (locator["record_ref"], locator["source_path"]) not in selected:
                    raise ValueError("Citation was not an originally selected file")
        required = {reviewer._subject_key(item) for item in args.get("required_subjects", [])}
        if not required <= {reviewer._subject_key(item["subject"]) for item in value["checks"]}:
            raise ValueError("Missing required subject")

        def read_snapshot(path):
            if path not in self.captured:
                raise ValueError("Unselected snapshot")
            return self.captured[path]

        review._validate(self.root, raw, args["reviewed_refs"], self.verified,
                         check_read=self.access, read_snapshot=read_snapshot)
        return value

    def publication(self, value, *, notices=False):
        ref = value["record_path"]
        manifest, _ = self.manifest(ref)
        expected = records.present(self.root, {"record_path": ref, **manifest})
        extras = {"dependency_notice", "workspace_differences"} if notices else set()
        if set(value) - extras != set(expected) or any(value[key] != item for key, item in expected.items()):
            raise ValueError("Publication does not match the frozen manifest")
        return manifest

    def recheck(self):
        # Detect changes during this readback without expanding the selected set.
        for path, expected in self.captured.items():
            self.access(path)
            with path.open("rb") as stream:
                if stream.read(len(expected) + 1) != expected:
                    raise _Issue("內容不符", path.relative_to(self.root).as_posix())


def _record_returns(history, session_id):
    pending = defaultdict(deque)
    for position, message in enumerate(history):
        if message.get("sessionID") != session_id:
            continue
        if message.get("role") == "assistant":
            for call in message.get("tool_calls") or []:
                pending[call["id"]].append((position, call))
        elif message.get("role") == "tool":
            queue = pending[message.get("tool_call_id")]
            paired = queue.popleft() if queue else None
            if (paired and paired[1].get("name") == message.get("name") == "research_record"
                    and not message.get("error") and not (message.get("metadata") or {}).get("error")):
                yield paired[0], paired[1]["arguments"], message


def describe(ctx, call, history):
    """Return bounded-assembly items; never call a model, broker, or write files."""
    try:
        return _describe(ctx, call, history)
    except Exception:
        return [("review", "最近審查詳情：尚未核對", None)]


def _describe(ctx, call, history):
    reader = _Reader(ctx, history)
    items = []
    stages = {}

    def add(kind, label, value=None, fallback=None):
        items.append((kind, label if value is None else label + _q(value), fallback))

    def attempt(label, action, *, kind="review", path=None, stage=False):
        try:
            value = action()
            if stage:
                stages[label] = "可讀回核對"
            else:
                add(kind, label + "：可讀回核對", {"位置": path} if path else None)
            return value
        except Exception as error:
            status = error.status if isinstance(error, _Issue) else "內容不符"
            # Never expose exception prose: it may contain private file content.
            location = error.path if isinstance(error, _Issue) else path
            if status == "目前無權讀取":
                location = None
            if stage:
                stages[label] = status
            else:
                add(kind, label + "：" + status, {"位置": location} if location else None)
            return None

    def subjects(value, location, label, prefix=""):
        try:
            reader.local(location)
        except _Issue:
            add("subject", label + "主張定位：目前無權讀取")
            return
        items.insert(0, ("review", label + "主張所在檔（下列主張 JSON 位置均相對此檔）：" +
                         _q({"位置": location, "checks項數": len(value["checks"])}), None))
        for index, check in enumerate(value["checks"]):
            pointer = {"JSON位置": f"{prefix}/checks/{index}/subject"}
            fallback = "主張原句未展開：" + _q(pointer)
            add("subject", "主張：", {**pointer, "subject": check["subject"]}, fallback)

    try:
        message = history[call["position"]]
        if (message.get("sessionID") != ctx.session_id or message.get("role") != "assistant"
                or message.get("id") != call["message_id"] or call["call"].get("name") != "research_review"):
            raise ValueError("Review call differs from the current history snapshot")
        call_index = message["tool_calls"].index(call["call"])
        original = call["call"]["arguments"]
        if "revision_plan" in original:
            # The planning-bound revision mode was removed; its saved chain is not re-verified.
            return [("review", "最近審查詳情：此審查使用已移除的 revision_plan 模式，未核對", None)]
        submitted = original
        receipt_mode = bool(tool_receipts.validate_ids(submitted))
        reviewer._selection(submitted)
        identity = [ctx.session_id, call["message_id"], call["call"]["id"]]
        for value in identity:
            reviewer._text(value, "call identity")
        key = records.digest(_q(identity).encode("utf-8"))
        resolved_path = f".research/review-runs/{key}/resolved-arguments.json"
        initial = f".research/review-runs/{key}/initial"
        call_path = f".opencode/history/{ctx.session_id}/conversation/{call['message_id']}.json"
        reader.local(call_path)
    except Exception:
        return [("review", "最近審查詳情：尚未核對", None)]

    argument_pointer = f"/tool_calls/{call_index}/arguments"
    add("review", "原參數在最近審查 assistant 讀回入口的 JSON 位置：", argument_pointer)
    add("review", "原 scope（不是目前委託）：", submitted["scope"])
    for ref in submitted["reviewed_refs"]:
        reader.local(ref)
    add("review", "明選 reviewed_refs：", submitted["reviewed_refs"])
    add("review", "原參數範圍：", {"files": len(submitted["files"]),
        "commission_files": len(submitted.get("commission_files", [])),
        "required_subjects": len(submitted.get("required_subjects", [])),
        "欄位位置（相對原參數）": ["/files", "/commission_files", "/required_subjects"]})
    args, receipt_record = submitted, None
    if receipt_mode:
        resolved = attempt("resolved-arguments.json", lambda: tool_receipts.verify_saved(
            ctx, original, key, history=history, read_bytes=reader.read, check_read=reader.access),
            path=resolved_path, stage=True)
        args, receipt_record = resolved if resolved is not None else (None, None)
    selected = attempt("明選快照", lambda: (reader.selected(args), True)[1]) if args is not None else None
    origins = None
    if selected:
        try:
            origins = reader.native.origins(reader.selected_raw)
        except Exception as error:
            status = error.status if isinstance(error, _Issue) else "內容不符"
            add("source", "來源重新核對未完成：" + status,
                {"位置": resolved_path if receipt_mode else call_path,
                 "JSON位置": "/files" if receipt_mode else argument_pointer + "/files"})
    else:
        add("source", "來源重新核對未完成：尚未核對")

    initial_value = None
    if selected:
        def initial_review():
            if reader.json(initial + "/arguments.json") != submitted:
                raise ValueError("Initial arguments differ")
            response = reader.read(initial + "/response.txt").decode("utf-8")
            private = _parse(reviewer._unwrap_json_fence(response).encode("utf-8"))
            reviewer._object(private, ("checks",), "initial response")
            reviewer._array(private["checks"], "checks")
            assembled = reviewer._assemble(private["checks"], args, reader.selection).encode("utf-8")
            saved = reader.read(initial + "/review.json")
            if assembled != saved:
                raise ValueError("Initial response and review disagree")
            return reader.check_review(saved, args)
        initial_value = attempt("初審三檔", initial_review, path=initial, stage=True)

    saved_record = None
    returned = None
    from_file = None
    reply = call.get("reply")
    if reply is None:
        add("review", "審查工具返回：尚未核對（目前未找到配對回條）")
    elif selected:
        def native_return():
            nonlocal from_file
            paired = reader.native._receipt(reply["id"])
            if (paired[0]["id"] != call["message_id"] or paired[0]["tool_calls"] != [call["call"]]
                    or paired[1] != reply):
                raise ValueError("Native review pairing differs")
            reader.local(f".opencode/history/{ctx.session_id}/tools/{reply['id']}.json")
            review_file = (reply.get("metadata") or {}).get("review_file")
            if isinstance(review_file, str):
                # research_review returns a short summary; the review itself is the saved final review.json.
                from_file = review_file
                return reader.check_review(reader.read(review_file), args)
            raw = (reply.get("content") or "").encode("utf-8")
            if len(raw) > MAX_BYTES:
                raise _Issue("超過讀回容量")
            value = _parse(raw)
            if receipt_mode:
                reviewer._object(value, ("review", "receipt_record"), "review handoff")
                if _difference(receipt_record, value["receipt_record"]):
                    raise ValueError("Returned receipt record differs from the frozen selection")
                result = reader.check_review(json.dumps(value["review"], ensure_ascii=False).encode("utf-8"), args)
            else:
                result = reader.check_review(raw, args)
            return result
        returned = attempt("審查工具保存返回正文", native_return)
        if returned is not None:
            truncated = (reply.get("metadata") or {}).get("truncated")
            add("review", "原生返回完整性：" + ("完整返回" if truncated is False else
                "保存正文相符，已標截斷；完整原生返回尚無法核對" if truncated is True else
                "保存正文相符，完整性未知"))
            if reply.get("error") or (reply.get("metadata") or {}).get("error"):
                add("review", "原生返回攜帶 error；正文相符不代表執行成功。")
    else:
        add("review", "審查工具返回：尚未核對")

    if returned is not None and from_file:
        subjects(returned, from_file, "與工具保存的最終審查相符的", "")
    elif returned is not None:
        location = f".opencode/history/{ctx.session_id}/tools/{reply['id']}.txt"
        subjects(returned, location, "與原生返回相符的", "/review" if receipt_mode else "")
    elif initial_value is not None:
        subjects(initial_value, initial + "/review.json", "初審保存的（不代表複核完成）")

    if origins is not None:
        add("source", ORIGIN_NOTICE)
        for index, locator in enumerate(args["files"]):
            key = locator["record_ref"], locator["source_path"]
            entry = reader.entries[key]
            add("source", "本次來源核對：", {"files索引": index,
                "sha256": entry["sha256"], "bytes": entry["bytes"], "origin": origins[key]})

    if stages:
        locations = {}
        if stages.get("初審三檔") != "目前無權讀取":
            locations["初審根"] = initial
        if receipt_mode and stages.get("resolved-arguments.json") != "目前無權讀取":
            locations["展開參數"] = resolved_path
        # One compact item keeps stage status from consuming the subject/source budget.
        items.insert(0, ("review", "保存項目：" + _q({**locations, "狀態": stages}), None))

    # Inspect publication manifests only. Neither this display nor publication
    # lookup recursively reads dependencies or unrelated record snapshots.
    publications = []
    try:
        for position, arguments, receipt in _record_returns(history, ctx.session_id):
            if position < call["position"] or not isinstance(arguments, dict):
                continue
            try:
                reader.local(f".opencode/history/{ctx.session_id}/tools/{receipt['id']}.json")
                raw = (receipt.get("content") or "").encode("utf-8")
                if len(raw) > MAX_BYTES or (receipt.get("metadata") or {}).get("truncated") is True:
                    continue
                value = _parse(raw)
                manifest = reader.publication(value, notices=True)
                expected_deps = [records.local_path(reader.root, ref).relative_to(reader.root).as_posix()
                                 for ref in arguments.get("depends_on", [])]
                explicit = [records.local_path(reader.root, ref).relative_to(reader.root).as_posix()
                            for ref in arguments["files"]]
                if (manifest["kind"] != arguments.get("kind") or manifest["title"] != arguments.get("title")
                        or manifest["depends_on"] != expected_deps
                        or not set(explicit) <= {entry["source_path"] for entry in manifest["files"]}):
                    continue
                publications.append((position, value, manifest))
                if returned is not None and manifest["kind"] == "review":
                    candidates = [entry for entry in manifest["files"] if Path(entry["source_path"]).name == "review.json"]
                    if len(candidates) == 1:
                        entry = candidates[0]
                        source = (Path(value["record_path"]).parent / entry["snapshot"]).as_posix()
                        frozen = reader.read(source)
                        if (records.digest(frozen) == entry["sha256"] and len(frozen) == entry["bytes"]
                                and reader.check_review(frozen, args) == returned):
                            saved_record = value
                            add("detail", "與原生返回正文相符的已發布普通 review：", value["record_path"])
            except Exception:
                continue
    except Exception:
        add("detail", "後續發布定位：尚未核對")
    if saved_record:
        ref = saved_record["record_path"]
        add("detail", "review record 定位：", ref)
        dependents = [value["record_path"] for _, value, manifest in publications if ref in manifest["depends_on"]]
        add("detail", "後續紀錄宣告直接 depends_on（不代表已修訂）：", list(dict.fromkeys(dependents)))

    try:
        reader.recheck()
    except Exception:
        # Do not retain success labels derived from files that changed mid-read.
        return [("review", "最近審查讀回：內容不符或目前無權讀取；本次詳情尚未核對。", None)]
    return items
