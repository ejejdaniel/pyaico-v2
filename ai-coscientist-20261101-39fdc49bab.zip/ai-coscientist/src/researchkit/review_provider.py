"""One isolated, cancellable model completion for scientific review."""

from __future__ import annotations

from copy import copy, deepcopy
import threading

import httpx

from opencode.provider import (
    Completion, ProviderError, _RequestAbort, _anthropic_messages, _check_abort,
    _check_completion, _finish_reason, _post, _raise_http_error, _response_json, _sanitize_text,
)
from opencode.permission import PermissionDenied, PermissionRejected
from opencode.tools.util import _abort_event, ensure_access


_DEADLINE_SECONDS = 600
# Length limits would cut a reason off mid-sentence at generation time; the
# parser still enforces them afterwards.
_UNCONSTRAINED_KEYWORDS = ("minLength", "maxLength")


def generation_schema(schema):
    """Copy of a validation schema suitable for constraining generation."""
    if isinstance(schema, dict):
        return {key: generation_schema(value) for key, value in schema.items()
                if key not in _UNCONSTRAINED_KEYWORDS}
    if isinstance(schema, list):
        return [generation_schema(value) for value in schema]
    return schema


def _response_format(name, schema):
    return {"type": "json_schema", "json_schema": {"name": name, "strict": True, "schema": schema}}


def _rejected_format(error):
    """True when the server refused the request itself (not an outage or a limit)."""
    cause = error.__cause__
    status = getattr(getattr(cause, "response", None), "status_code", None)
    return isinstance(cause, httpx.HTTPStatusError) and status in (400, 422)


def output_constraint(frozen):
    """One line saying how this invocation's replies were produced, for error messages."""
    if not frozen or "output_constraint" not in frozen:
        return "output constraint: none"
    return "output constraint: " + frozen["output_constraint"]


def json_error_detail(text, error):
    """Exact position of a JSON syntax error in the complete reply, with the text around it.

    error.pos refers to the parsed copy; a removed ```json fence shifts it, so the
    position is recomputed against the complete reply that gets saved.
    """
    parsed = error.doc if isinstance(error.doc, str) else text
    offset = text.find(parsed) if parsed and parsed != text else 0
    position = max(offset, 0) + error.pos
    line = text.count("\n", 0, position) + 1
    column = position - (text.rfind("\n", 0, position) + 1) + 1
    before, after = text[max(0, position - 80):position], text[position:position + 40]
    return (f"{error.msg} at line {line}, column {column} (char {position} of {len(text)}); "
            f"text before: {before!r}; text from there: {after!r}")


def save_rejected(ctx, path, text):
    """Keep a rejected reply for diagnosis. Returns a note; never hides the original failure."""
    root = ctx.directory.resolve()
    try:
        ensure_access(ctx, path, "edit")
        resolved = path.resolve()
        if not resolved.is_relative_to(root) or resolved != path:
            raise ValueError(f"save path is outside this workspace: {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("x", encoding="utf-8", newline="") as stream:
            stream.write(text if isinstance(text, str) else repr(text))
    except (OSError, ValueError, PermissionDenied, PermissionRejected) as error:
        return f"the rejected reply could not be saved ({error})"
    return "complete rejected reply saved at " + path.relative_to(root).as_posix()


def _anthropic_once(client, provider, key, model, system, messages, temperature, signal) -> Completion:
    # Common normalizes pause_turn to stop. Review must inspect the original
    # reason before that distinction is lost, without changing Common behavior.
    body = {"model": model, "max_tokens": client.output_limit(provider, model),
            "messages": _anthropic_messages(messages)}
    if system:
        body["system"] = _sanitize_text(system)
    if temperature is not None:
        body["temperature"] = temperature
    headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    url = provider.base_url.rstrip("/") + "/messages"
    response = _post(url, headers, body, httpx.Timeout(600.0, connect=30.0), signal)
    if response.status_code >= 400:
        _raise_http_error(response, url, f"{provider.id} {response.status_code}: {response.text[:2000]}")
    data = _response_json(response)
    if not isinstance(data, dict) or not isinstance(data.get("content"), list):
        raise ProviderError("Model response is missing completion content")
    reason = data.get("stop_reason")
    if reason not in ("end_turn", "stop_sequence"):
        raise ProviderError(f"Research review requires a normal Anthropic completion; stop_reason={reason!r}")
    text, reasoning = [], []
    for block in data["content"]:
        if block.get("type") == "text":
            text.append(block.get("text") or "")
        elif block.get("type") == "thinking":
            reasoning.append(block.get("thinking") or "")
        elif block.get("type") == "tool_use":
            raise ProviderError("Research review completion must not contain tool calls")
        elif block.get("type") != "redacted_thinking":
            raise ProviderError(f"Research review completion contains an unsupported content block: {block.get('type')!r}")
    return _check_completion(Completion(
        text="".join(text), usage=data.get("usage") or {}, model=model,
        finish_reason=_finish_reason(reason, anthropic=True),
        reasoning_content="".join(reasoning) if reasoning else None,
    ))


def complete_once(ctx, *, system: str, messages: list[dict],
                  recovery_temperature: float | None = None,
                  prepared: dict | None = None,
                  frozen: dict | None = None,
                  response_schema: tuple[str, dict] | None = None) -> Completion:
    """Make one scoped call; the caller owns recovery policy and its budget.

    response_schema (name, JSON schema) constrains an OpenAI-compatible reply at
    generation time. If the server rejects the constraint, the same request is sent
    once without it and the shared `frozen` settings remember that for later stages.
    The caller still parses and validates the reply either way.
    """
    parent_abort = _abort_event(ctx)
    signal = _RequestAbort(parent_abort)
    expired = threading.Event()

    def expire():
        expired.set()
        signal.set()

    timer = threading.Timer(_DEADLINE_SECONDS, expire)
    timer.name = "researchkit-review-deadline"
    timer.start()
    try:
        try:
            _check_abort(signal)
            if prepared:
                client, provider, model = prepared["client"], prepared["provider"], prepared["model"]
                key, temperature = prepared["key"], prepared["temperature"]
                system, messages = prepared["system"], deepcopy(prepared["messages"])
            else:
                if frozen:
                    settings = frozen
                else:
                    client = ctx.app.provider
                    if prepared is not None or frozen is not None:
                        # Freeze generation settings for this invocation, while
                        # each stage owns its separate system/messages snapshot.
                        client = copy(client)
                        client.config = deepcopy(client.config)
                        client.providers = deepcopy(client.providers)
                    provider, model = client.resolve(ctx.app.store.get_session(ctx.session_id)["model"])
                    key = client.key_for(provider)
                    if not key and provider.id != "ollama":
                        raise ProviderError(f"Missing API key for provider '{provider.id}'.")
                    temperature = client._temperature(provider, model, ctx.agent.temperature, signal)
                    settings = dict(client=client, provider=provider, model=model, key=key,
                                    temperature=temperature)
                    if frozen is not None:
                        frozen.update(settings)
                client, provider, model = settings["client"], settings["provider"], settings["model"]
                key, temperature = settings["key"], settings["temperature"]
                messages = deepcopy(messages)
                if prepared is not None:
                    prepared.update(settings, system=system, messages=deepcopy(messages))
            if recovery_temperature is not None:
                adjusted = client._temperature(provider, model, recovery_temperature, signal)
                if adjusted is None:
                    raise ProviderError("Model does not support the requested recovery temperature")
                if adjusted == temperature:
                    raise ProviderError("Recovery temperature must differ from the original effective temperature")
                temperature = adjusted
            _check_abort(signal)
            if provider.api == "anthropic":
                result = _anthropic_once(client, provider, key or "", model, system, messages, temperature, signal)
            else:
                # Only preparation has a total deadline for OpenAI streaming.
                # Join before checking so a concurrent expiry cannot be lost.
                timer.cancel()
                timer.join()
                _check_abort(signal)
                rejected = frozen is not None and frozen.get("output_constraint", "").startswith("free")
                response_format = (_response_format(*response_schema)
                                   if response_schema is not None and not rejected else None)

                def send(response_format):
                    extra = {"response_format": response_format} if response_format is not None else {}
                    return client._openai(
                        provider, key or "ollama", model, system, messages, [], temperature, None,
                        abort_event=signal,
                        on_update=lambda completion: _check_abort(signal, completion),
                        **extra,
                    )

                try:
                    result = send(response_format)
                    if response_format is not None and frozen is not None:
                        frozen["output_constraint"] = "json_schema"
                except ProviderError as error:
                    if response_format is None or not _rejected_format(error):
                        raise
                    _check_abort(signal)
                    if frozen is not None:
                        frozen["output_constraint"] = ("free; the server rejected json_schema: "
                                                       + str(error)[:300])
                    result = send(None)
        finally:
            timer.cancel()
            timer.join()
        _check_abort(signal, result)
        return result
    except (ProviderError, httpx.HTTPError) as error:
        partial = getattr(error, "partial", None)
        _check_abort(parent_abort, partial)
        if expired.is_set():
            raise ProviderError(
                f"Research review model request exceeded its {_DEADLINE_SECONDS}-second local deadline",
                partial,
            ) from error
        if isinstance(error, ProviderError):
            raise
        raise ProviderError(str(error)) from error
