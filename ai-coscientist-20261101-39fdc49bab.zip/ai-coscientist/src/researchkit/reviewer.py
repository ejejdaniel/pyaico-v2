"""Two scoped review stages of explicitly selected, frozen text files."""

from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import re
from types import SimpleNamespace

from opencode import runtime_settings
from opencode.permission import PermissionDenied, PermissionRejected
from opencode.provider import _check_abort
from opencode.tools.types import ToolResult
from opencode.tools.util import _abort_event, ensure_access
from researchkit import records, review, tool_receipts
from researchkit.review_provider import complete_once, json_error_detail, output_constraint, save_rejected
from researchkit.knowledge import facts_block
from researchkit.source_provenance import NativeSources, origin_notice


MAX_BYTES = runtime_settings.get("model_request.max_bytes")  # one review request; config/runtime.json
SYSTEM_PATH = Path(__file__).parent / "skills/final-lca/references/reviewer-system.md"
FOLLOWUP_PATH = Path(__file__).parent / "skills/final-lca/references/reviewer-followup.md"
FORMAT_PATH = Path(__file__).parent / "skills/final-lca/references/reviewer-output.md"
VERIFICATION_PATH = Path(__file__).parent / "skills/materializer/references/verification.md"
MISSED_LABEL = ("Required subjects the initial review did not judge (one-based positions in the required "
                "subjects list); judge each of them in this stage:")
HANDOFF_LABEL = "Candidate claim and evidence quotations from the saved initial review (not judgments or evidence of support or completeness):"


def _object(value, fields, label):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise ValueError(f"{label}: expected exactly {', '.join(fields)}")


def _text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label}: expected nonblank text")


def _array(value, label):
    if not isinstance(value, list) or not value:
        raise ValueError(f"{label}: expected a nonempty array")


def _reference(ref, label="record_ref"):
    _text(ref, label)
    parts = ref.split("/")
    if (len(parts) != 4 or parts[:2] != [".research", "records"]
            or parts[3] != "record.json" or len(parts[2]) != 64
            or any(c not in "0123456789abcdef" for c in parts[2])):
        # Name the value: a run (2026-11-01) passed its report's file path here and was not told which entry.
        hint = ("; a file is cited through the record that saved it: save it with research_record and give the "
                "record.json path that call returns") if not ref.startswith(".research/records/") else ""
        raise ValueError(f"{label} {ref!r}: Expected an exact relative .research/records/<hash>/record.json "
                         f"reference{hint}")


def _selection(args):
    fields = ("scope", "reviewed_refs", "files")
    if isinstance(args, dict) and "required_subjects" in args:
        fields += ("required_subjects",)
    if isinstance(args, dict) and "commission_files" in args:
        fields += ("commission_files",)
    if isinstance(args, dict) and "tool_call_ids" in args:
        fields += ("tool_call_ids",)
    if isinstance(args, dict) and "second_assessment" in args:
        fields += ("second_assessment",)
        if not isinstance(args["second_assessment"], bool):
            raise ValueError("second_assessment: expected true or false")
    _object(args, fields, "research_review")
    tool_receipts.validate_ids(args)
    _text(args["scope"], "scope")
    _array(args["reviewed_refs"], "reviewed_refs")
    _array(args["files"], "files")
    # Every entry's problems at once: runs (2026-11-01) were refused once per problem, two or three times in a
    # row, because each refusal named only the first.
    problems = []

    def check(fn, *values):
        try:
            fn(*values)
            return True
        except ValueError as error:
            problems.append(str(error))
            return False

    reviewed = set()
    for ref in args["reviewed_refs"]:
        if not check(_reference, ref, "reviewed_refs entry"):
            continue
        if ref in reviewed:
            problems.append(f"Duplicate reviewed_refs entry: {ref}")
        reviewed.add(ref)
    selected = set()
    for item in args["files"]:
        if not (check(_object, item, ("record_ref", "source_path"), "files entry")
                and check(_reference, item["record_ref"], "files record_ref")
                and check(_text, item["source_path"], "source_path")):
            continue
        key = (item["record_ref"], item["source_path"])
        if key in selected:
            problems.append(f"Duplicate selected file: {item['record_ref']} {item['source_path']}")
        selected.add(key)
    bare = [ref for ref in reviewed if ref not in {ref for ref, _ in selected}]
    if bare:
        # v38 lost a call on each of these refusals; say which entry and how to fix it.
        problems.append("Every reviewed_ref must have at least one selected file; none is selected for "
                        + ", ".join(sorted(bare)) + ". Add files entries {record_ref, source_path} with the exact "
                        "files[].source_path of each of those records")
    commission = args.get("commission_files", [])
    if not isinstance(commission, list):
        problems.append("commission_files: expected an array")
        commission = []
    seen_commission = set()
    for item in commission:
        if not (check(_object, item, ("record_ref", "source_path"), "commission_files entry")
                and check(_reference, item["record_ref"], "commission_files record_ref")
                and check(_text, item["source_path"], "commission_files.source_path")):
            continue
        key = (item["record_ref"], item["source_path"])
        if key not in selected:
            problems.append(f"commission_files must refer to a selected file: {item['record_ref']} "
                            f"{item['source_path']} is not in files; add the same entry to files")
        if key in seen_commission:
            problems.append(f"Duplicate commission_files entry: {item['record_ref']} {item['source_path']}")
        seen_commission.add(key)
    required = args.get("required_subjects", [])
    if not isinstance(required, list):
        problems.append("required_subjects: expected an array")
        required = []
    seen = set()
    for item in required:
        if not (check(_object, item, ("record_ref", "source_path", "quote"), "required_subjects entry")
                and all(check(_text, item[field], f"required_subjects.{field}")
                        for field in ("record_ref", "source_path", "quote"))):
            continue
        if item["record_ref"] not in reviewed:
            problems.append(f"required_subjects record_ref must be in reviewed_refs: {item['record_ref']}")
        if (item["record_ref"], item["source_path"]) not in selected:
            problems.append(f"required_subjects must refer to a selected file: {item['record_ref']} "
                            f"{item['source_path']}")
        key = _subject_key(item)
        if key in seen:
            problems.append("Duplicate required_subjects entry after newline normalization")
        seen.add(key)
    if problems:
        from researchkit.calc_roles import all_problems
        raise ValueError(all_problems(problems))
    return reviewed, selected


def _subject_key(item):
    return item["record_ref"], item["source_path"], review._newlines(item["quote"])


def _required_subject(item, required_subjects):
    """Resolve only this invocation's strict, one-based private selector."""
    _object(item, ("required_subject",), "review required subject selector")
    number = item["required_subject"]
    if not required_subjects or type(number) is not int or not 1 <= number <= len(required_subjects):
        raise ValueError("required_subject must be an integer in the nonempty required_subjects list")
    subject = required_subjects[number - 1]
    return {**subject, "quote": review._newlines(subject["quote"])}


def _oversize(args, root, ctx):
    """The limit error, naming the largest selected files so the caller knows what to drop."""
    sizes = {}
    for locator in args["files"]:
        try:
            manifest_path = records.local_path(root, locator["record_ref"])
            ensure_access(ctx, manifest_path, "read")
            manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
            entry = next(item for item in manifest["files"] if item.get("source_path") == locator["source_path"])
            sizes[locator["source_path"]] = int(entry["bytes"])
        except (OSError, ValueError, KeyError, StopIteration, TypeError):
            continue
    largest = sorted(sizes.items(), key=lambda item: -item[1])[:5]
    listed = "; ".join(f"{path} {size} bytes" for path, size in largest)
    return (f"Review input files exceed the {MAX_BYTES}-byte limit (selected files total about "
            f"{sum(sizes.values())} bytes plus their record.json manifests). Largest: {listed}. Select fewer or "
            "smaller files, for example a summary of a large data file instead of the file itself. A leaderboard "
            "needs no review: the host checks the report's ranks, values and verdicts against it.")


def _quote_problem(root, ctx, quote, ref, source):
    """Which required quote the saved file lacks, and whether the working file has it.

    LIT (2026-11-01) edited the report after saving it and quoted the edit. The refusal named neither the quote
    nor the reason, so the agent shortened the two quotes that were fine and was refused again.
    """
    shown = quote if len(quote) <= 120 else quote[:120] + "…"
    text = (f"required_subjects quote is not a literal contiguous excerpt of {ref}: {source}: "
            f"{json.dumps(shown, ensure_ascii=False)}")
    try:
        working = (root / source).resolve()
        if not working.is_relative_to(root) or not working.is_file() or working.stat().st_size > MAX_BYTES:
            return text
        ensure_access(ctx, working, "read")
        current = working.read_bytes().decode("utf-8-sig")
    except Exception:
        return text
    if review._newlines(quote) in review._newlines(current):
        text += (f". The working file {source} has it, but this record's saved copy does not: the file changed "
                 "after the record was saved. Save the current file in a new record (research_record) and select "
                 "that record, or quote the saved text")
    return text


def _input(args, ctx, *, sources=None):
    root = ctx.directory.resolve()
    used = 0

    def read(path):
        nonlocal used
        _check_abort(_abort_event(ctx))
        ensure_access(ctx, path, "read")
        remaining = MAX_BYTES - used
        if path.stat().st_size > remaining:
            raise ValueError(_oversize(args, root, ctx))
        with path.open("rb") as stream:
            raw = stream.read(remaining + 1)
        if len(raw) > remaining:
            raise ValueError(_oversize(args, root, ctx))
        used += len(raw)
        return raw

    verified, snapshots, selection, problems = {}, {}, {}, []
    selected_raw, file_metadata = {}, {}
    commission = {(item["record_ref"], item["source_path"])
                  for item in args.get("commission_files", [])}
    commission_sections, research_sections = [], []
    sections = ["Review commission (scope):", json.dumps(args["scope"], ensure_ascii=False),
                "Reviewed record references (reviewed_refs):",
                json.dumps(args["reviewed_refs"], ensure_ascii=False)]
    for number, locator in enumerate(args["files"], start=1):
        ref, source = locator["record_ref"], locator["source_path"]
        path = records.local_path(root, ref)
        if ref not in verified:
            raw = read(path)
            if records.digest(raw) != ref.split("/")[2]:
                raise ValueError(f"Record content has changed: {ref}")
            try:
                manifest = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=review._unique_keys)
            except UnicodeDecodeError as exc:
                raise ValueError(f"Selected record manifest is not UTF-8 text: {ref}") from exc
            if not isinstance(manifest, dict) or not isinstance(manifest.get("files"), list):
                raise ValueError(f"Invalid record files: {ref}")
            verified[ref] = manifest
        entries = [item for item in verified[ref]["files"]
                   if isinstance(item, dict) and item.get("source_path") == source]
        if len(entries) != 1:
            # The same list research_record and render_report give: v25 asked for history_checks again.
            # Every such file at once: LIT (2026-11-01) had 5 of 15 wrong and was refused 5 times, one each.
            from researchkit.report_evidence import _saved_files
            problems.append(f"source_path must exactly select one saved file: {ref}: {source}"
                            + _saved_files(verified[ref], source))
            continue
        entry = entries[0]
        if not isinstance(entry.get("snapshot"), str):
            raise ValueError(f"Invalid snapshot path: {ref}: {source}")
        snapshot = records.local_path(path.parent, entry["snapshot"])
        raw = read(snapshot)
        if (records.digest(raw) != entry.get("sha256") or type(entry.get("bytes")) is not int
                or len(raw) != entry["bytes"]):
            raise ValueError(f"Selected snapshot hash or bytes changed: {ref}: {source}")
        try:
            content = raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise ValueError(f"Selected snapshot is not UTF-8 text: {ref}: {source}") from exc
        for subject in args.get("required_subjects", []):
            if (subject["record_ref"], subject["source_path"]) == (ref, source):
                # Public subjects may quote the complete file, including its
                # final LF. Preserve the existing public literal-text domain.
                if review._newlines(subject["quote"]) not in review._newlines(content):
                    problems.append(_quote_problem(root, ctx, subject["quote"], ref, source))
        snapshots[snapshot] = len(raw)
        # Only CRLF/CR are line separators. A final line terminator does not
        # create an extra source line; an empty file has no referenceable lines.
        lines = review._newlines(content).split("\n")
        if lines[-1] == "":
            lines.pop()
        file_id = f"F{number}"
        selection[file_id] = {"record_ref": ref, "source_path": source, "lines": tuple(lines)}
        selected_raw[ref, source] = raw
        file_metadata[file_id] = {
            "file_id": file_id, **locator, "sha256": entry["sha256"], "bytes": entry["bytes"],
            "declared_kind": verified[ref]["kind"], "declared_title": verified[ref]["title"],
        }
    if problems:
        from researchkit.calc_roles import all_problems
        raise ValueError(all_problems(problems))
    # Source provenance sees only the already verified, explicitly selected
    # snapshots. Build it once before either model stage or its shared recovery;
    # neither an unselected paired file nor a dependency becomes reviewer input.
    origins = (sources or NativeSources(ctx)).origins(selected_raw)
    for file_id, selected in selection.items():
        ref, source, lines = selected["record_ref"], selected["source_path"], selected["lines"]
        origin = origins[ref, source]
        file_sections = [
            "Selected frozen file:", json.dumps({**file_metadata[file_id], "origin": origin}, ensure_ascii=False),
            "Numbered UTF-8 lines (JSON array; numbers are not source content). "
            "Host source notice (not a source line or citable scientific observation): "
            + origin_notice(source, origin, ctx.session_id),
            json.dumps(list(enumerate(lines, start=1)), ensure_ascii=False),
        ]
        if commission:
            target = commission_sections if (ref, source) in commission else research_sections
            target.extend(file_sections)
        else:
            sections.extend(file_sections)
    if commission:
        # Partition the already-read source blocks. A role selection neither
        # rereads/recounts a snapshot nor changes its original file ID or lines.
        sections.extend([
            "Caller-selected original commission locators (commission_files):",
            json.dumps(args["commission_files"], ensure_ascii=False),
            "These source roles are explicitly assigned by the caller; the host does not authenticate authorship. "
            "Assess the research author's interpretations against these original commission contents. "
            "An old research note, including one named task, does not replace the original commission. "
            "The scope defines this review's assessment and limits; its factual claims do not themselves "
            "override an original requirement. Explain conflicts among original commission sources and any "
            "explicit modification of an earlier requirement in the current scope through the existing checks "
            "and reasons; the selected role alone does not establish a judgment.",
            "Original commission source contents:", *commission_sections,
            "Other selected research file contents:", *research_sections,
        ])
    # Records are named by long hashes; list each one's file IDs so the reviewer
    # can see which records still lack a subject.
    files_of = {ref: [file_id for file_id, item in selection.items() if item["record_ref"] == ref]
                for ref in args["reviewed_refs"]}
    sections.extend([
        "Coverage checklist (host-computed): every reviewed record needs at least one check whose subject "
        "quotes one of its files. Reviewed record -> its file IDs:",
        json.dumps(files_of, ensure_ascii=False),
    ])
    if args.get("required_subjects"):
        sections.extend([
            "Required exact subjects (one-based positions; every subject must be judged):",
            json.dumps(list(enumerate(args["required_subjects"], start=1)), ensure_ascii=False),
        ])
    # The isolated reviewer cannot follow the outer agent's skill links. Load the
    # private locator format and procedure here. The public review format is
    # produced mechanically below, not a second model output instruction.
    # The reviewer cannot run tools either; give it the same host-computed facts.
    facts = facts_block([{"source_path": source, "text": raw.decode("utf-8-sig", errors="replace")}
                         for (_, source), raw in selected_raw.items()])
    if facts:
        sections.extend(["", facts])
    system = _instructions(SYSTEM_PATH)
    message = "\n".join(sections)
    _request_size(system, message)
    return system, message, verified, snapshots, selection


def _instructions(stage_path):
    instructions = [path.read_text(encoding="utf-8")
                    for path in (stage_path, FORMAT_PATH, VERIFICATION_PATH)]
    if any(not text.strip() for text in instructions):
        raise ValueError("Review instructions, output format and method verification procedure must be nonblank")
    return "\n\n".join(instructions)


def _request_size(system, message):
    size, instructions = len(system.encode("utf-8")) + len(message.encode("utf-8")), len(system.encode("utf-8"))
    if size > MAX_BYTES:
        raise ValueError(f"Complete review request exceeds the {MAX_BYTES}-byte limit: it is {size} bytes, of which the "
                         f"reviewer's instructions take {instructions}, so the scope and selected files must stay under "
                         f"about {MAX_BYTES - instructions} bytes. Select fewer or smaller files: the report and the "
                         "few records its decisive claims rest on")


def _unwrap_json_fence(text):
    """Remove only a complete lowercase-json fence from a parsing copy."""
    fenced = text.strip(" \t\r\n")
    if fenced.startswith("```json\r\n"):
        start = 9
    elif fenced.startswith("```json\n"):
        start = 8
    else:
        return text
    if fenced.endswith("\r\n```"):
        end = 5
    elif fenced.endswith("\n```"):
        end = 4
    else:
        return text
    # Do not inspect backticks inside JSON strings or repair the payload. The
    # original parser rejects extra values, real second fences and invalid JSON.
    return fenced[start:-end]


def _near_miss(text, quote):
    """(first, last, differences) of the one span of text that equals quote except for a few retyped
    characters (whitespace runs compared as one space), or None when there is no such single span.

    Only substitutions count: an added or missing word is not a typo and is not repaired.
    """
    def collapse(value):
        chars, origin = [], []
        for index, char in enumerate(value):
            if char.isspace():
                if chars and chars[-1] == " ":
                    continue
                char = " "
            chars.append(char)
            origin.append(index)
        return "".join(chars), origin

    wanted = collapse(quote.strip())[0]
    if len(wanted) < NEAR_MISS_MIN:
        return None
    allowed = min(NEAR_MISS_MAX, max(1, len(wanted) // NEAR_MISS_PER))
    haystack, origin = collapse(text)
    found = []
    for offset in range(len(haystack) - len(wanted) + 1):
        differences = 0
        for a, b in zip(haystack[offset:offset + len(wanted)], wanted):
            if a != b:
                differences += 1
                if differences > allowed:
                    break
        else:
            found.append((offset, differences))
            if len(found) > 1:
                return None
    if len(found) != 1:
        return None
    offset, differences = found[0]
    return origin[offset], origin[offset + len(wanted) - 1] + 1, differences


NEAR_MISS_MIN = 20  # shorter quotes are too easy to match by chance
NEAR_MISS_PER = 40  # one retyped character allowed per this many characters of quote
NEAR_MISS_MAX = 3


def _quote_lines(lines, quote, start, end, repairs=None):
    """Where a subject quote occurs in its file: (start_line, end_line, exact file text).

    A subject is published as record, path and quote; its line numbers only help
    find it. The reviewer reads each file as a numbered JSON array, so it miscounts
    lines and retypes indentation across line breaks. The host fixes both: a quote
    cited with wrong line numbers is moved to where it occurs in the same file, and
    a quote that differs from the file only in whitespace is replaced by the file's
    exact text (the occurrence nearest the cited range). A quote that matches one
    place in the file except for a few retyped characters is replaced by the file's
    text too, and reported in repairs. Any other quote still fails, with where it
    stops matching.
    """
    if quote in "\n".join(lines[start - 1:end]):
        return start, end, quote
    text = "\n".join(lines)
    spans, offset = [], text.find(quote)
    while offset != -1:
        spans.append((offset, offset + len(quote)))
        offset = text.find(quote, offset + 1)
    words = quote.split()
    if not spans:
        spans = [match.span() for match in re.finditer(r"\s+".join(map(re.escape, words)), text)]
    if spans:
        located = [(text.count("\n", 0, first) + 1, text.count("\n", 0, last) + 1, first, last)
                   for first, last in spans]
        first_line, last_line, first, last = min(
            located, key=lambda span: max(0, span[0] - end, start - span[1]))
        return first_line, last_line, text[first:last]
    near = _near_miss(text, quote)
    if near is not None:
        first, last, differences = near
        if repairs is not None:
            repairs.append({"cited": quote, "file": text[first:last], "retyped_characters": differences})
        return text.count("\n", 0, first) + 1, text.count("\n", 0, last) + 1, text[first:last]
    low, high = 0, len(words)
    while low < high:  # most leading words that occur in the file, whitespace aside
        middle = (low + high + 1) // 2
        found = re.search(r"\s+".join(map(re.escape, words[:middle])), text)
        low, high = (middle, high) if found else (low, middle - 1)
    if low == 0:
        detail = "not even its first word occurs in the file"
    else:
        at = re.search(r"\s+".join(map(re.escape, words[:low])), text).end()
        detail = (f"its first {low} of {len(words)} words occur, then the quote has "
                  f"{json.dumps(' '.join(words[low:low + 6]), ensure_ascii=False)} where the file has "
                  f"{json.dumps(text[at:at + 50], ensure_ascii=False)}")
    raise ValueError("Review subject.quote must be a literal contiguous excerpt of its selected file; " + detail)


def _candidate_handoff(initial_text, selection, required_subjects=(), skip=()):
    """Pair verified claim text with frozen evidence, without initial judgments.

    skip: 1-based positions of initial checks that validation dropped as malformed.
    """
    initial = json.loads(_unwrap_json_fence(initial_text), object_pairs_hook=review._unique_keys)
    initial = {**initial, "checks": [check for number, check in enumerate(initial["checks"], 1)
                                     if number not in set(skip)]}

    def quoted(item, *, subject=False):
        if subject and isinstance(item, dict) and "required_subject" in item:
            _required_subject(item, required_subjects)
            return dict(item)
        fields = ("file_id", "start_line", "end_line", "quote") if subject else ("file_id", "start_line", "end_line")
        _object(item, fields, "review locator")
        _text(item["file_id"], "file_id")
        if item["file_id"] not in selection:
            raise ValueError("Review file_id is outside the selected files")
        lines = selection[item["file_id"]]["lines"]
        start, end = item["start_line"], item["end_line"]
        if type(start) is not int or type(end) is not int:
            raise ValueError("Review start_line and end_line must be integers, not booleans or other types")
        if not 1 <= start <= end <= len(lines):
            raise ValueError("Review line range is outside the selected file")
        if subject:
            _text(item["quote"], "review subject.quote")
            start, end, quote = _quote_lines(lines, review._newlines(item["quote"]), start, end)
        excerpt = "\n".join(lines[start - 1:end])
        if not excerpt.strip():
            raise ValueError("Review quote must be nonblank text")
        return {**item, "start_line": start, "end_line": end, "quote": quote if subject else excerpt}

    candidates = {"checks": [{"subject": quoted(check["subject"], subject=True),
                              "evidence": [quoted(item) for item in check["evidence"]]}
                             for check in initial["checks"]]}
    return json.dumps(candidates, ensure_ascii=False, separators=(",", ":"))


def _run_directory(ctx, *, resolved=False):
    """Authorize every save/readback path, then exclusively claim the call ID."""
    identity = [getattr(ctx, name, None) for name in ("session_id", "message_id", "call_id")]
    for name, value in zip(("session_id", "message_id", "call_id"), identity):
        _text(value, name)
    key = records.digest(json.dumps(identity, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    root = ctx.directory.resolve()
    parent = root / ".research" / "review-runs"
    run = parent / key
    paths = [parent, run]
    if resolved:
        paths.append(run / "resolved-arguments.json")
    for name in ("initial", ".initial.pending"):
        folder = run / name
        paths.extend([folder, *(folder / name for name in ("arguments.json", "response.txt", "review.json"))])
    paths.extend([run / "final", run / "final" / "review.json"])
    for path in paths:
        _check_abort(_abort_event(ctx))
        _save_path(root, path)
        for permission in ("edit", "read"):
            ensure_access(ctx, path, permission)
    _check_abort(_abort_event(ctx))
    _save_path(root, parent)
    parent.mkdir(exist_ok=True)
    _save_path(root, run)
    # No exists-then-create: exactly one invocation can spend model calls.
    # The claimed directory remains even after failure or cancellation.
    run.mkdir()
    return run


def _save_path(root, path):
    # Keep the authorized lexical destination, and reject links that would
    # redirect writes/readback away from it after the permission preflight.
    resolved = path.resolve()
    if not resolved.is_relative_to(root) or resolved != path:
        raise ValueError(f"Review save path changed or is outside this workspace: {path}")
    return path


def _save_initial(args, text, output, ctx, run_dir):
    """Commit the three exact initial-stage byte strings before any followup."""
    root = run_dir.parent.parent.parent
    pending, initial = run_dir / ".initial.pending", run_dir / "initial"
    contents = {
        "arguments.json": (json.dumps(args, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8"),
        "response.txt": text.encode("utf-8"),
        "review.json": output.encode("utf-8"),
    }

    def readback(folder):
        saved = {}
        for name, expected in contents.items():
            _check_abort(_abort_event(ctx))
            path = _save_path(root, folder / name)
            ensure_access(ctx, path, "read")
            with path.open("rb") as stream:
                actual = stream.read(len(expected) + 1)
            if actual != expected:
                raise ValueError(f"Saved initial review bytes changed: {path}")
            saved[name] = actual
        return saved

    _check_abort(_abort_event(ctx))
    _save_path(root, pending).mkdir()
    for name, raw in contents.items():
        _check_abort(_abort_event(ctx))
        path = _save_path(root, pending / name)
        ensure_access(ctx, path, "edit")
        with path.open("xb") as stream:
            stream.write(raw)
    readback(pending)
    _check_abort(_abort_event(ctx))
    _save_path(root, pending)
    _save_path(root, initial)
    ensure_access(ctx, pending, "edit")
    ensure_access(ctx, initial, "edit")
    if initial.exists():
        raise FileExistsError(f"Initial review destination already exists: {initial}")
    # The exclusive invocation directory guarantees one tool-owned writer on
    # every platform. Windows rename additionally refuses an existing target;
    # external filesystem races/tampering are outside this save guarantee.
    # Never use replace here.
    pending.rename(initial)
    return readback(initial)["response.txt"].decode("utf-8")


def _recheck_sources(args, ctx, verified, snapshots):
    """Verify every originally selected manifest/snapshot, including uncited ones."""
    root = ctx.directory.resolve()
    for ref in verified:
        _check_abort(_abort_event(ctx))
        path = records.local_path(root, ref)
        ensure_access(ctx, path, "read")
        with path.open("rb") as stream:
            raw = stream.read(MAX_BYTES + 1)
        if records.digest(raw) != ref.split("/")[2]:
            raise ValueError(f"Record content has changed: {ref}")
    for locator in args["files"]:
        _check_abort(_abort_event(ctx))
        ref, source = locator["record_ref"], locator["source_path"]
        entry = next(item for item in verified[ref]["files"]
                     if isinstance(item, dict) and item.get("source_path") == source)
        path = records.local_path(records.local_path(root, ref).parent, entry["snapshot"])
        ensure_access(ctx, path, "read")
        if path not in snapshots:
            raise ValueError("Selected snapshot path changed before source verification")
        with path.open("rb") as stream:
            raw = stream.read(snapshots[path] + 1)
        if len(raw) != snapshots[path] or records.digest(raw) != entry["sha256"]:
            raise ValueError(f"Selected snapshot changed before source verification: {ref}: {source}")


def _assemble(checks, args, selection, *, require_subjects=True, missing_out=None, repairs=None):
    """Assemble bound claims and full evidence ranges within the output cap."""
    parts, used = [], 0
    allowed = {(item["record_ref"], item["source_path"]) for item in args["files"]}
    reviewed = set(args["reviewed_refs"])
    subjects = set()

    def append(text):
        nonlocal used
        used += len(text.encode("utf-8"))
        if used > MAX_BYTES:
            raise ValueError("Assembled review.json exceeds the 262144-byte output limit")
        parts.append(text)

    def string(text):
        append('"')
        # Encode bounded fragments, never a potentially huge repeated quote or
        # reason before checking its complete compact-JSON byte contribution.
        for offset in range(0, len(text), 4096):
            append(json.dumps(text[offset:offset + 4096], ensure_ascii=False,
                              separators=(",", ":"))[1:-1])
        append('"')

    def locator(item, *, subject=False):
        if subject and isinstance(item, dict) and "required_subject" in item:
            resolved = _required_subject(item, args.get("required_subjects", []))
            subjects.add(_subject_key(resolved))
            append('{"record_ref":')
            string(resolved["record_ref"])
            append(',"source_path":')
            string(resolved["source_path"])
            append(',"quote":')
            string(resolved["quote"])
            append("}")
            return
        fields = ("file_id", "start_line", "end_line", "quote") if subject else ("file_id", "start_line", "end_line")
        _object(item, fields, "review locator")
        _text(item["file_id"], "file_id")
        if item["file_id"] not in selection:
            raise ValueError("Review file_id is outside the selected files")
        source = selection[item["file_id"]]
        ref, path, lines = source["record_ref"], source["source_path"], source["lines"]
        if (ref, path) not in allowed:
            raise ValueError("Review citation is outside the selected files")
        if subject and ref not in reviewed:
            raise ValueError("Review subject must refer to a requested reviewed_ref")
        start, end = item["start_line"], item["end_line"]
        if type(start) is not int or type(end) is not int:
            raise ValueError("Review start_line and end_line must be integers, not booleans or other types")
        if not 1 <= start <= end <= len(lines):
            raise ValueError("Review line range is outside the selected file")
        if subject:
            _text(item["quote"], "review subject.quote")
            start, end, quote = _quote_lines(lines, review._newlines(item["quote"]), start, end, repairs)
            subjects.add((ref, path, quote))
        if not any(lines[index].strip() for index in range(start - 1, end)):
            raise ValueError("Review quote must be nonblank text")
        append('{"record_ref":')
        string(ref)
        append(',"source_path":')
        string(path)
        append(',"quote":')
        if subject:
            string(quote)
        else:
            append('"')
            for index in range(start - 1, end):
                if index != start - 1:
                    append("\\n")
                line = lines[index]
                for offset in range(0, len(line), 4096):
                    append(json.dumps(line[offset:offset + 4096], ensure_ascii=False,
                                      separators=(",", ":"))[1:-1])
            append('"')
        append("}")

    append('{"reviewed_refs":[')
    for index, ref in enumerate(args["reviewed_refs"]):
        if index:
            append(",")
        string(ref)
    append('],"checks":[')
    for index, check in enumerate(checks):
        _object(check, ("subject", "evidence", "decision", "reason"), "check")
        if not isinstance(check["evidence"], list):
            raise ValueError("check.evidence must be an array")
        if check["decision"] not in ("supported", "conditional", "contradicted", "unsupported", "unassessed"):
            raise ValueError("check.decision must be supported, conditional, contradicted, unsupported or unassessed")
        _text(check["reason"], "check.reason")
        if index:
            append(",")
        append('{"subject":')
        locator(check["subject"], subject=True)
        append(',"evidence":[')
        for evidence_index, evidence in enumerate(check["evidence"]):
            if evidence_index:
                append(",")
            locator(evidence)
        append('],"decision":')
        string(check["decision"])
        append(',"reason":')
        string(check["reason"])
        append("}")
    append("]}\n")
    missing = [number for number, subject in enumerate(args.get("required_subjects", []), start=1)
               if _subject_key(subject) not in subjects]
    if missing and require_subjects:
        raise ValueError(f"Review is missing required_subjects positions: {missing}")
    if missing_out is not None:
        missing_out.extend(missing)
    return "".join(parts)


# An oversized result still fails the review. A check whose quotation is not in its file is
# dropped like a malformed one (never published), within the same share; more than that fails.
_NOT_FORMAT = ("output limit",)
MAX_DROPPED_SHARE = 0.25


def _usable_checks(checks, args, selection):
    """Split checks into usable ones and malformed ones (1-based position and problem).

    One malformed check (wrong fields, types, decision, line range, or a quotation
    that is not in its file) is dropped and reported instead of discarding the whole
    review: an error affects only the check it is in. More than MAX_DROPPED_SHARE
    dropped checks, or no usable check at all, still fail.
    """
    kept, dropped = [], []
    for number, check in enumerate(checks, 1):
        try:
            _assemble([check], args, selection, require_subjects=False)
        except ValueError as error:
            if any(marker in str(error) for marker in _NOT_FORMAT):
                raise ValueError(f"Review check {number}: {error}") from error
            dropped.append({"check": number, "problem": str(error)})
        else:
            kept.append(check)
    if not kept:
        raise ValueError(f"No check in the review output is usable; first problem: check {dropped[0]['check']}: "
                         + dropped[0]["problem"])
    if len(dropped) > max(1, int(len(checks) * MAX_DROPPED_SHARE)):
        raise ValueError(f"{len(dropped)} of {len(checks)} checks are malformed (first: check {dropped[0]['check']}: "
                         f"{dropped[0]['problem']}); the review output is not usable")
    return kept, dropped


DECISIONS = ("supported", "conditional", "contradicted", "unsupported", "unassessed")


def output_schema(args, selection):
    """Generation-time shape of the reviewer reply.

    The reason comes before the decision so the model writes its assessment before
    judging. File IDs and required-subject positions are limited to this invocation's
    values. The host still validates the reply and assembles the public field order.
    """
    file_id = {"type": "string", "enum": sorted(selection)}
    locator = {"type": "object", "additionalProperties": False, "required": ["file_id", "start_line", "end_line"],
               "properties": {"file_id": file_id, "start_line": {"type": "integer"},
                              "end_line": {"type": "integer"}}}
    quoted = {**locator, "required": [*locator["required"], "quote"],
              "properties": {**locator["properties"], "quote": {"type": "string"}}}
    required = args.get("required_subjects") or []
    subject = quoted if not required else {"anyOf": [quoted, {
        "type": "object", "additionalProperties": False, "required": ["required_subject"],
        "properties": {"required_subject": {"type": "integer", "enum": list(range(1, len(required) + 1))}}}]}
    check = {"type": "object", "additionalProperties": False,
             "required": ["subject", "evidence", "reason", "decision"],
             "properties": {"subject": subject, "evidence": {"type": "array", "items": locator},
                            "reason": {"type": "string"},
                            "decision": {"type": "string", "enum": list(DECISIONS)}}}
    return {"type": "object", "additionalProperties": False, "required": ["checks"],
            "properties": {"checks": {"type": "array", "minItems": 1, "items": check}}}


def _covered(args, checks, selection, unreviewed):
    """Narrow reviewed_refs to the records that the checks give a subject.

    A reviewer that leaves some reviewed records without a check still produced a
    valid review of the others. The review is published for the covered records and
    the rest are listed in unreviewed, instead of discarding every check.
    """
    used = set()
    for check in checks:
        subject = check["subject"]
        if "required_subject" in subject:
            used.add(_required_subject(subject, args.get("required_subjects", []))["record_ref"])
        else:
            used.add(selection[subject["file_id"]]["record_ref"])
    missing = [ref for ref in args["reviewed_refs"] if ref not in used]
    if not missing:
        return args
    if unreviewed is not None:
        unreviewed.extend(missing)
    return {**args, "reviewed_refs": [ref for ref in args["reviewed_refs"] if ref in used]}


def _validate_completion(completion, args, ctx, verified, snapshots, selection, dropped=None, unreviewed=None,
                         unjudged=None, repairs=None):
    if (completion.finish_reason != "stop" or completion.tool_calls
            or not isinstance(completion.text, str) or not completion.text.strip()):
        raise ValueError("Review did not produce a complete nonempty final answer without tool calls")
    raw = _unwrap_json_fence(completion.text).encode("utf-8")
    try:
        value = json.loads(raw, object_pairs_hook=review._unique_keys)
    except json.JSONDecodeError as exc:
        raise ValueError("Review final answer is not valid JSON: "
                         + json_error_detail(completion.text, exc)) from exc
    except UnicodeDecodeError as exc:
        raise ValueError("Review final answer must be the internal checks locator object") from exc
    _object(value, ("checks",), "reviewer output")
    _array(value["checks"], "checks")
    # Check scope and line ranges before the existing validator reads snapshots.
    kept, malformed = _usable_checks(value["checks"], args, selection)
    if dropped is not None:
        dropped.extend(malformed)
    args = _covered(args, kept, selection, unreviewed)
    # A required subject the reviewer did not judge is reported, not a reason to discard every other check.
    output = _assemble(kept, args, selection, require_subjects=unjudged is None, missing_out=unjudged,
                       repairs=repairs)
    raw = output.encode("utf-8")

    def check_read(path):
        _check_abort(_abort_event(ctx))
        ensure_access(ctx, path, "read")
        if path not in snapshots or path.stat().st_size != snapshots[path]:
            raise ValueError("Selected snapshot changed before quote verification")

    def read_snapshot(path):
        # Limit the read itself, including growth after the permission/stat check.
        with path.open("rb") as stream:
            data = stream.read(snapshots[path] + 1)
        if len(data) != snapshots[path]:
            raise ValueError("Selected snapshot changed before quote verification")
        return data

    _recheck_sources(args, ctx, verified, snapshots)
    review._validate(ctx.directory.resolve(), raw, args["reviewed_refs"], verified,
                     check_read=check_read, read_snapshot=read_snapshot)
    return output


def prepare(args, ctx, *, ask_permission=True):
    """Fix one complete selection before model dispatch or a revision commit."""
    args = deepcopy(args)
    _selection(args)
    if ask_permission:
        ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_review",
                                patterns=args["reviewed_refs"], always=["*"],
                                ruleset=ctx.agent.permission, metadata={}, abort_event=_abort_event(ctx))
    ids = tool_receipts.validate_ids(args)
    if not ids:
        inputs = _input(args, ctx)
        return {"original": args, "resolved": args, "inputs": inputs,
                "run_dir": _run_directory(ctx), "receipt_record": None}
    sources = NativeSources(ctx)
    selected = sources.selected_receipts(ids, check_read=lambda path: ensure_access(ctx, path, "read"))
    root = ctx.directory.resolve()
    manifest = tool_receipts.manifest_for(root, selected)
    ref = ".research/records/" + records.digest(records.encoded(manifest)) + "/record.json"
    # Resolve all IDs first, then exclusively claim this invocation before any
    # publication. A failed call cannot republish or spend another generation.
    run_dir = _run_directory(ctx, resolved=True)
    try:
        receipt = tool_receipts.publish(ctx, selected)
        resolved = tool_receipts.expanded(args, ref, [path.relative_to(root).as_posix()
                                                    for path, _ in selected[::2]])
        raw = tool_receipts.compact(resolved)
        path = _save_path(root, run_dir / "resolved-arguments.json")
        _check_abort(_abort_event(ctx))
        ensure_access(ctx, path, "edit")
        with path.open("xb") as stream:
            stream.write(raw)

        def recheck():
            contents = [(path, raw), (root / ref, records.encoded(manifest))]
            contents.extend(((root / ref).parent / item["snapshot"], content)
                            for item, (_, content) in zip(manifest["files"], selected))
            for saved, expected in contents:
                _check_abort(_abort_event(ctx))
                _save_path(root, saved)
                ensure_access(ctx, saved, "read")
                with saved.open("rb") as stream:
                    actual = stream.read(len(expected) + 1)
                if actual != expected:
                    raise ValueError(f"Selected tool receipt handoff bytes changed: {saved}")
            if receipt != records.present(root, {"record_path": ref, **manifest}):
                raise ValueError("Selected tool receipt return differs from the frozen record")

        recheck()
        _selection(resolved)
        inputs = _input(resolved, ctx, sources=sources)
        return {"original": args, "resolved": resolved, "inputs": inputs, "run_dir": run_dir,
                "receipt_record": receipt, "recheck": recheck}
    except (PermissionDenied, PermissionRejected):
        raise
    except Exception as error:
        tool_receipts.failure_location(error, ctx, run_dir, ref)
        raise


def execute(args, ctx, *, prepared=None, wrap=True, publish=False):
    """Two stages unless args says second_assessment false; publish saves the review as a record.

    The research_review tool asks for one stage and publication (tool_execute); direct callers such as
    research_inference keep both stages and save their own review record.
    """
    prepared = prepare(args, ctx) if prepared is None else prepared
    prepared["publish"] = publish
    try:
        output = _execute_prepared(ctx, prepared)
        if prepared["receipt_record"] is not None:
            prepared["recheck"]()
            if wrap:
                value = json.loads(output.output)
                extra = {}
                if isinstance(value, dict) and "review" in value:
                    extra = {key: item for key, item in value.items() if key != "review"}
                    value = value["review"]
                return ToolResult(title="research_review", output=tool_receipts.compact({
                    "receipt_record": prepared["receipt_record"], "review": value, **extra
                }).decode("utf-8"), metadata=dict(output.metadata))
        return output
    except (PermissionDenied, PermissionRejected):
        raise
    except Exception as error:
        if prepared["receipt_record"] is not None:
            tool_receipts.failure_location(error, ctx, prepared["run_dir"],
                                          prepared["receipt_record"]["record_path"])
        raise


def _reusable_initial(ctx, run_dir, original):
    """(saved first-stage reply, its folder) from an earlier run of these exact arguments whose second stage
    never finished, or None. Once any run of these arguments has finished, a new call is a new review and
    reuses nothing. The newest unfinished run wins; its text is validated again before use."""
    expected = (json.dumps(original, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
    root = ctx.directory.resolve()
    candidates = []
    for arguments in run_dir.parent.glob("*/initial/arguments.json"):
        folder = arguments.parent
        if folder.parent == run_dir:
            continue
        try:
            ensure_access(ctx, arguments, "read")
            if arguments.read_bytes() != expected:
                continue
            if (folder.parent / "final").exists():
                return None
            response = folder / "response.txt"
            ensure_access(ctx, response, "read")
            candidates.append((arguments.stat().st_mtime_ns, response.read_text(encoding="utf-8"),
                               folder.relative_to(root).as_posix()))
        except (OSError, ValueError, PermissionDenied):
            continue
    if not candidates:
        return None
    _, text, source = max(candidates)
    return text, source


def _save_final(ctx, run_dir, output):
    """Write the validated final review beside initial/; returns its path."""
    root = ctx.directory.resolve()
    folder = _save_path(root, run_dir / "final")
    path = _save_path(root, folder / "review.json")
    ensure_access(ctx, path, "edit")
    folder.mkdir()
    with path.open("xb") as stream:
        stream.write(output.encode("utf-8"))
    return path


def _publish_review(ctx, args, path):
    """Save the finished review as its own kind=review record and return its path.

    It depends on the reviewed records and on every record the reviewer read evidence from, which
    the review contract requires. v21 retyped and re-saved its review three times before it passed.
    """
    root = ctx.directory.resolve()
    reviewed = list(args["reviewed_refs"])
    depends_on = list(dict.fromkeys(reviewed + [item["record_ref"] for item in args["files"]]))
    ensure_access(ctx, root / ".research" / "records", "edit")
    shorts = ", ".join(ref.split("/")[2][:8] for ref in reviewed)
    saved = records.publish(root, kind="review", title=f"Review of {shorts}",
                            files=[path.relative_to(root).as_posix()], depends_on=depends_on,
                            check_read=lambda item: ensure_access(ctx, item, "read"))
    return saved["record_path"]


def _finish(ctx, run_dir, args, output, notes, initial_dropped, final_dropped, unreviewed, unjudged, repairs,
            *, publish=False):
    """Keep the final review as a file and as a review record, and return it with any notes."""
    stage = "single-stage" if args.get("second_assessment") is False else "second-stage"
    saved = {}
    try:
        path = _save_final(ctx, run_dir, output)
    except (OSError, ValueError) as error:  # a finished review is never lost to a convenience copy
        note = f"The final review could not be written to the run folder ({error}); save the review object yourself."
    else:
        relative = path.relative_to(ctx.directory.resolve()).as_posix()
        if not publish:
            note = (f"The final ({stage}) review is saved as {relative}. To keep it, save that file as its own "
                    "record instead of retyping it: research_record with kind review, files [that path], and "
                    "depends_on every reviewed record. A Final-LCA then depends on that review record; review.json "
                    "inside a Final-LCA or any other kind of record is not a review. initial/review.json is only the "
                    "first-stage assessment.")
        else:
            try:
                ref = _publish_review(ctx, args, path)
            except (PermissionDenied, PermissionRejected):
                raise
            except (OSError, ValueError, KeyError) as error:
                note = (f"The final ({stage}) review is saved as {relative}, but the host could not save it as a "
                        f"review record ({error}). Save that file as its own record instead of retyping it: "
                        "research_record with kind review, files [that path], and depends_on every reviewed record "
                        "and every record its evidence comes from.")
            else:
                saved = {"review_record": ref, "review_file": relative}
                note = (f"The final ({stage}) review is saved as {relative} and as review record {ref}; do not "
                        "save it again. Answer each check that is not supported (revise the report, or state the "
                        "limit in it), then deliver with research_deliver, which writes the Final-LCA and the "
                        "user_report.")
    metadata = {"host_note": " ".join([*notes, note]), **saved}
    if initial_dropped or final_dropped or unreviewed or unjudged or repairs:
        return ToolResult(title="research_review", output=_with_notes(
            ctx, run_dir, output, initial_dropped, final_dropped, unreviewed, unjudged, repairs),
            metadata=metadata)
    return ToolResult(title="research_review", output=output, metadata=metadata)


def _with_notes(ctx, run_dir, output, initial, final, unreviewed, unjudged=(), repairs=()):
    """Note dropped checks and unreviewed records beside the review without changing review.json's contract."""
    value = {"review": json.loads(output)}
    if repairs:
        value["quote_repairs"] = list(repairs)
        value["quote_repairs_note"] = (
            "These subject quotations differed from the selected file by a few retyped characters at one "
            "place; the review holds the file's exact text. Check that each decision is about that text.")
    if initial or final:
        note = {"initial": initial, "final": final}
        path = _save_path(ctx.directory.resolve(), run_dir / "dropped-checks.json")
        ensure_access(ctx, path, "edit")
        with path.open("xb") as stream:
            stream.write(json.dumps(note, ensure_ascii=False, indent=2).encode("utf-8"))
        value["dropped_checks"] = note
        value["dropped_note"] = (
            "Reviewer checks that were malformed or quoted text not in the selected file were dropped "
            "instead of discarding the review; the review below contains only valid checks. Save the "
            "review object as review.json and, as an explanation "
            f"file of the same record, {path.relative_to(ctx.directory.resolve()).as_posix()}.")
    if unreviewed:
        value["unreviewed_refs"] = unreviewed
        value["unreviewed_note"] = (
            "The reviewer gave no check to these reviewed records, so the review covers only the records in its "
            "reviewed_refs. They are not assessed (not passed, not failed). If their assessment matters, review "
            "them in a separate call with fewer records.")
    if unjudged:
        value["unjudged_required_subjects"] = list(unjudged)
        value["unjudged_note"] = (
            "The reviewer did not judge these required_subjects (one-based positions) in either stage, although "
            "the second stage was told which ones the first stage missed. They are not assessed (not passed, not "
            "failed); the review covers the rest. Review them separately if their assessment matters.")
    return json.dumps(value, ensure_ascii=False, indent=2)


def _execute_prepared(ctx, prepared):
    args, run_dir = prepared["resolved"], prepared["run_dir"]
    if "inputs" not in prepared:
        raise FileExistsError(f"Review invocation already dispatched; refusing to regenerate: {run_dir}")
    # Preparation is transferable to the revision composition exactly once.
    # Consume before dispatch, including model failure and cancellation paths.
    system, message, verified, snapshots, selection = prepared.pop("inputs")
    frozen = {}
    recovery_used = False
    schema = ("review_checks", output_schema(args, selection))

    def stage(name, system, message):
        nonlocal recovery_used
        if prepared.get("recheck") is not None:
            prepared["recheck"]()
        provider_prepared = {}
        messages = [{"role": "user", "content": message}]
        _check_abort(_abort_event(ctx))
        completion = complete_once(ctx, system=system, messages=messages, prepared=provider_prepared, frozen=frozen,
                                   response_schema=schema)
        _check_abort(_abort_event(ctx))
        if (not recovery_used
                and getattr(provider_prepared.get("provider"), "api", None) not in (None, "anthropic")
                and provider_prepared.get("temperature") != 0.6
                and completion.finish_reason in ("stop", "length") and not completion.tool_calls
                and isinstance(completion.text, str) and not completion.text.strip()
                and isinstance(completion.reasoning_content, str) and completion.reasoning_content.strip()):
            # One shared recovery for the entire invocation. The provider's
            # existing preparation confirms temperature capability before any
            # recovery generation is sent. Failure stops this invocation.
            # Consume before dispatch; errors/cancellation never restore it.
            recovery_used = True
            completion = complete_once(ctx, system=system, messages=messages, prepared=provider_prepared,
                                       frozen=frozen, recovery_temperature=0.6, response_schema=schema)
        _check_abort(_abort_event(ctx))
        dropped, unreviewed, unjudged, repairs = [], [], [], []
        try:
            output = _validate_completion(completion, args, ctx, verified, snapshots, selection, dropped,
                                          unreviewed, unjudged, repairs)
        except ValueError as error:
            # Keep the complete reply so the failure can be diagnosed from the workspace.
            note = (save_rejected(ctx, _save_path(ctx.directory.resolve(), run_dir / f"rejected-{name}.txt"),
                                  completion.text)
                    if isinstance(completion.text, str) and completion.text.strip() else "the reply was empty")
            error.args = (f"{error.args[0] if error.args else error} ({note}; {output_constraint(frozen)})",
                          *error.args[1:])
            raise
        return completion, output, dropped, unreviewed, unjudged, repairs

    notes = []
    reused = _reusable_initial(ctx, run_dir, prepared["original"])
    first = None
    if reused is not None:
        text, source = reused
        initial_dropped, initial_unjudged = [], []
        try:
            first = _validate_completion(SimpleNamespace(text=text, finish_reason="stop", tool_calls=None),
                                         args, ctx, verified, snapshots, selection, initial_dropped, [],
                                         initial_unjudged, [])
        except ValueError:
            first = None  # the saved first stage no longer validates; generate a new one
        else:
            completion = SimpleNamespace(text=text)
            notes.append(f"The first stage was reused from {source} (same arguments; its second stage had not "
                         "finished), so only the second stage ran.")
    initial_unreviewed, initial_repairs = [], []
    if first is None:
        (completion, first, initial_dropped, initial_unreviewed, initial_unjudged,
         initial_repairs) = stage("initial", system, message)
    output = first
    initial_text = _save_initial(prepared["original"], completion.text, output, ctx, run_dir)
    if args.get("second_assessment") is False:
        # One assessment unless asked: the second stage doubled the review's time in LIT runs (v16, v21,
        # v23) while the outer agent, the history checks and the host's report checks catch what it adds.
        return _finish(ctx, run_dir, args, output, notes, initial_dropped, [], initial_unreviewed,
                       initial_unjudged, initial_repairs, publish=prepared.get("publish", False))
    try:
        _check_abort(_abort_event(ctx))
        _recheck_sources(args, ctx, verified, snapshots)
        followup_system = _instructions(FOLLOWUP_PATH)
        missed = ("\n\n" + MISSED_LABEL + "\n" + json.dumps(initial_unjudged)) if initial_unjudged else ""
        followup_message = message + missed + "\n\n" + HANDOFF_LABEL + "\n" + _candidate_handoff(
            initial_text, selection, args.get("required_subjects", []),
            skip=[item["check"] for item in initial_dropped])
        _request_size(followup_system, followup_message)
        _, output, final_dropped, unreviewed, unjudged, repairs = stage("followup", followup_system, followup_message)
        return _finish(ctx, run_dir, args, output, notes, initial_dropped, final_dropped, unreviewed, unjudged,
                       repairs, publish=prepared.get("publish", False))
    except (PermissionDenied, PermissionRejected):
        raise
    except Exception as error:
        abort = _abort_event(ctx)
        if abort is None or not abort.is_set():
            # Preserve the original object/type, traceback, cause, and partial
            # completion. Common still owns permission and cancellation errors.
            message = (f"初審已保存、複核未完成：{run_dir / 'initial'}\n本次失敗原因：{error}\n"
                       "以相同參數重新呼叫 research_review 會沿用這次的初審，只重跑複審。")
            if isinstance(error, OSError) and error.strerror is not None:
                error.strerror = message
            elif isinstance(error, UnicodeError) and hasattr(error, "reason"):
                error.reason = message
            else:
                error.args = (message, *error.args[1:])
        raise


def tool_execute(args, ctx):
    """research_review: one assessment, saved as a review record, answered in a short summary.

    In LIT v16, v21 and v23 the review and its second stage took 34-45 minutes per delivery; the
    second stage was about 40% of the reviewer's time, and v25 asked for it when it could, so the
    agent is not offered it. v25's reviews (about 35 KB each) were cut by the tool-output limit
    together with the note saying how to deliver, and it reviewed five revisions instead of
    delivering: the agent now gets the counts, the checks to answer and the next step, and the full
    review stays in its record and file.
    """
    if isinstance(args, dict):
        args = {**args, "second_assessment": False}
    result = execute(args, ctx, publish=True)
    if not result.metadata.get("review_record"):
        return result
    try:
        text = summary(result.output, result.metadata)
    except (ValueError, KeyError, TypeError):
        return result
    metadata = {key: value for key, value in result.metadata.items() if key != "host_note"}
    return ToolResult(title=result.title, output=text, metadata=metadata)


UNASSESSED = ("unassessed means the reviewer lacked the evidence for that claim. Leaderboard ranks, values and "
              "verdicts are the host's computations, and the host compares the report's with them when the report is "
              "saved: answer such a check in research_deliver as a limitation naming the leaderboard record, without a "
              "second review. Review another claim again only when its missing files fit in one review (256 KB with "
              "the report); otherwise state it as a limitation. A run (2026-11-01) reviewed five more times to cover "
              "leaderboard numbers that did not fit.")
NEXT_STEP = ("Next: where a check shows an error, correct the report; where it shows a limit, state it. Render the "
             "report, save the delivered report so that it depends on this reviewed version, and deliver with "
             "research_deliver, answering each check above. A revised report needs no second review: the answers "
             "carry this review over. Review again only conclusions this review did not cover.")


SUMMARY_BYTES = 10000  # the checks' share of the summary; tool output is cut at 16 KB in the LIT runs


def _clip(text, limit):
    """The text in at most limit UTF-8 bytes (Chinese takes three bytes a character)."""
    text = " ".join(str(text or "").split())
    raw = text.encode("utf-8")
    if len(raw) <= limit:
        return text
    return raw[:limit].decode("utf-8", errors="ignore") + "…"


def summary(output, metadata):
    """What the agent needs from a saved review: its counts, the checks to answer and the next step."""
    value = json.loads(output)
    extras = {}
    if isinstance(value, dict) and "review" in value and "checks" not in value:
        extras = {key: item for key, item in value.items() if key != "review"}
        value = value["review"]
    checks = value["checks"]
    counts = {decision: sum(1 for check in checks if check.get("decision") == decision) for decision in DECISIONS}
    ref, path = metadata["review_record"], metadata["review_file"]
    lines = [f"Review saved as review record {ref}; the full review with each check's evidence is {path}. "
             f"{len(checks)} checks: " + ", ".join(f"{decision} {count}" for decision, count in counts.items() if count)
             + "."]
    if extras.get("receipt_record"):
        lines.append(f"The selected tool calls were frozen in {extras['receipt_record'].get('record_path')}.")
    if extras.get("dropped_checks"):
        dropped = sum(len(items or []) for items in extras["dropped_checks"].values())
        lines.append(f"{dropped} reviewer checks were malformed or quoted text not in the files and were left out.")
    if extras.get("unreviewed_refs"):
        lines.append("No check covers these reviewed records, so they are not assessed: "
                     + ", ".join(extras["unreviewed_refs"]) + ".")
    if extras.get("unjudged_required_subjects"):
        lines.append("Required subjects not judged (positions): "
                     + ", ".join(str(item) for item in extras["unjudged_required_subjects"]) + ".")
    if extras.get("quote_repairs"):
        lines.append(f"{len(extras['quote_repairs'])} subject quotations were repaired to the files' exact text.")
    answer = [(number, check) for number, check in enumerate(checks, 1) if check.get("decision") != "supported"]
    if not answer:
        lines.append("Every check is supported. Render the report, save it, and deliver with research_deliver; no "
                     "answers are needed.")
        return "\n".join(lines)
    share = max(240, SUMMARY_BYTES // len(answer))
    subject_limit, reason_limit = min(400, share // 3), share - min(400, share // 3)
    lines.append("Checks to answer in research_deliver (answers: {\"review_ref\": \"" + ref + "\", \"check\": n, "
                 "\"action\": \"revised\"|\"limitation\"|\"disputed\", \"note\": \"...\", \"quote\": "
                 "\"<the delivered report's text>\"}):")
    for number, check in answer:
        subject = check.get("subject") if isinstance(check.get("subject"), dict) else {}
        lines.append(f"- check {number} ({check.get('decision')}) on {subject.get('source_path')}: "
                     f"\"{_clip(subject.get('quote'), subject_limit)}\"")
        lines.append(f"  reason: {_clip(check.get('reason'), reason_limit)}")
    if counts["unassessed"]:
        lines.append(UNASSESSED)
    lines.append(NEXT_STEP)
    return "\n".join(lines)
