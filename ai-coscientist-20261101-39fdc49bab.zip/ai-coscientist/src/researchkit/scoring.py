"""Rank agreement on explicitly supplied target-satisfaction values.

Numerical definitions follow the previous domain/private_evaluator.py, without
its artifact/runtime imports. Undefined correlations are null, not a zero score.
"""

from __future__ import annotations

import itertools
import math
import random


def _numbers(value: dict) -> dict[str, float]:
    if not isinstance(value, dict) or not value:
        raise ValueError("Expected a nonempty object mapping sample IDs to finite numbers")
    if not all(isinstance(k, str) and k.strip() for k in value):
        raise ValueError("Sample IDs must be nonblank strings")
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in value.values()):
        raise ValueError("Every sample must have a finite numeric value; no skipped or default rows")
    return {k: float(v) for k, v in value.items()}


def _ranks(values):
    ordered = sorted(enumerate(values), key=lambda x: x[1])
    result = [0.0] * len(values)
    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and ordered[end][1] == ordered[start][1]:
            end += 1
        for index, _ in ordered[start:end]:
            result[index] = (start + 1 + end) / 2
        start = end
    return result


def tau_b(x, y) -> float | None:
    concordant = discordant = x_ties = y_ties = 0
    for i in range(len(x)):
        for j in range(i + 1, len(x)):
            a = (x[i] > x[j]) - (x[i] < x[j])
            b = (y[i] > y[j]) - (y[i] < y[j])
            if a == b == 0:
                continue
            if a == 0:
                x_ties += 1
            elif b == 0:
                y_ties += 1
            elif a == b:
                concordant += 1
            else:
                discordant += 1
    denominator = math.sqrt((concordant + discordant + x_ties) * (concordant + discordant + y_ties))
    return (concordant - discordant) / denominator if denominator else None


EXACT_LIMIT = 8  # 8! = 40320 orderings
DRAWS = 20000


def permutation_tau(x, y, *, sign=1, seed=0) -> dict | None:
    """How often a random reordering of y agrees with x at least as well as observed.

    Exact over every ordering for up to EXACT_LIMIT samples, otherwise a seeded
    Monte Carlo estimate. one_sided counts agreement in the declared direction.
    """
    observed = tau_b(x, y)
    if observed is None:
        return None
    observed *= sign
    eps = 1e-12
    if len(y) <= EXACT_LIMIT:
        orderings, exact = itertools.permutations(y), True
    else:
        rng = random.Random(seed)
        orderings, exact = (rng.sample(list(y), len(y)) for _ in range(DRAWS)), False
    total = two = one = extreme = 0
    top = -1.0
    for ordering in orderings:
        value = tau_b(x, ordering)
        value = 0.0 if value is None else sign * value
        total += 1
        two += abs(value) >= abs(observed) - eps
        one += value >= observed - eps
        if abs(value) > top + eps:
            top, extreme = abs(value), 1
        elif abs(value) >= top - eps:
            extreme += 1
    if exact:
        p_two, p_one, smallest = two / total, one / total, extreme / total
    else:
        p_two, p_one, smallest = (two + 1) / (total + 1), (one + 1) / (total + 1), None
    return {"two_sided": p_two, "one_sided": p_one, "smallest_possible_two_sided": smallest,
            "exact": exact, "orderings": total}


DIRECTIONS = ("higher", "lower", "target")
# What a hypothesis's mechanism says the measured KPI does as its formula's value rises.
MECHANISM = ("kpi_rises", "kpi_falls")
# A term of a quantitative model may also have none: one change with competing effects (a run's own
# script said the mechanism gives no sign, and the schema made it pick kpi_rises).
TERM_MECHANISM = (*MECHANISM, "unknown")


def mechanism_direction(mechanism, better):
    """The formula direction a mechanism and the KPI's better side imply, or None when they fix none."""
    if mechanism not in MECHANISM or better not in ("higher", "lower"):
        return None
    return "higher" if (mechanism == "kpi_rises") == (better == "higher") else "lower"


def check_direction(direction, target_value=None):
    """higher/lower: larger/smaller proxy values mean greater target satisfaction.
    target: the proxy predicts a quantity whose best value is target_value (nominal-the-best)."""
    if direction not in DIRECTIONS:
        raise ValueError("direction must be higher, lower or target, relative to increasing target satisfaction")
    if direction == "target":
        if isinstance(target_value, bool) or not isinstance(target_value, (int, float)) or not math.isfinite(target_value):
            raise ValueError("direction target needs a finite numeric target_value")
    elif target_value is not None:
        raise ValueError("target_value is only used with direction target")


def orient(value, direction, target_value=None):
    """A value on a scale where larger always means closer to target satisfaction."""
    if direction == "higher":
        return value
    if direction == "lower":
        return -value
    return -abs(value - target_value)


KPI_SHAPE = ('"kpi": {"record_ref": ".research/records/<hash>/record.json", "source_path": "...", '
             '"column": "<KPI column>", "better": "lower|higher|target", "target_value": 12.5}')


def check_kpi(kpi) -> list[str]:
    """Problems with a proxy_formula's kpi declaration: the measured KPI it ranks and which values are better."""
    if not isinstance(kpi, dict):
        return ["kpi must be an object naming the measured KPI values the formula ranks: " + KPI_SHAPE]
    problems = [f"kpi.{key} must be a nonblank string" for key in ("record_ref", "source_path")
                if not isinstance(kpi.get(key), str) or not kpi[key].strip()]
    if "column" in kpi and (not isinstance(kpi["column"], str) or not kpi["column"].strip()):
        problems.append("kpi.column, when given, must be a nonblank string")
    # The reason itself: a run (2026-11-01) read the one general line as "add a target_value" and added it to a
    # kpi whose better was lower, three times.
    better, target = kpi.get("better"), kpi.get("target_value")
    if better not in DIRECTIONS:
        problems.append(f"kpi.better must be higher, lower or target, not {better!r}: which measured KPI values are "
                        "better for the commission")
    elif better == "target" and (isinstance(target, bool) or not isinstance(target, (int, float))
                                 or not math.isfinite(target)):
        problems.append("kpi.better target needs a numeric kpi.target_value: the KPI's best value")
    elif better != "target" and target is not None:
        problems.append(f"kpi.target_value is only used with kpi.better target: leave it out of a kpi whose better "
                        f"is {better}, or declare kpi.better target if the commission sets a best value")
    unknown = sorted(set(kpi) - {"record_ref", "source_path", "column", "better", "target_value"})
    if unknown:
        problems.append("kpi has unknown keys: " + ", ".join(unknown))
    return problems


def kpi_order(predicted: dict, kpi: dict, direction, target_value, better, kpi_target=None) -> dict:
    """Whether a formula prefers the same samples as the measured KPI does.

    Both sides are oriented so that larger means better: the formula by its declared
    direction, the KPI by `better`. Pairs the KPI does not separate are not compared;
    pairs the formula ties count as ties, not as agreement. reversed means the formula
    prefers the worse sample in more pairs than the better one (direction-adjusted tau < 0).
    """
    samples = [sample for sample in predicted if sample in kpi]
    preference = {s: orient(predicted[s], direction, target_value) for s in samples}
    satisfaction = {s: orient(kpi[s], better, kpi_target) for s in samples}
    pairs = [(a, b) for a, b in itertools.combinations(samples, 2) if satisfaction[a] != satisfaction[b]]
    disagreements = [[a, b] for a, b in pairs
                     if (preference[a] - preference[b]) * (satisfaction[a] - satisfaction[b]) < 0]
    ties = [[a, b] for a, b in pairs if preference[a] == preference[b]]
    tau = (tau_b([preference[s] for s in samples], [satisfaction[s] for s in samples])
           if len(samples) > 1 else None)
    return {"compared_samples": samples, "pairs": len(pairs),
            "agreement": f"{len(pairs) - len(disagreements) - len(ties)}/{len(pairs)}",
            "disagreements": disagreements, "ties": ties, "kendall_tau_b": tau,
            "better_by_kpi": max(samples, key=lambda s: satisfaction[s]) if pairs else None,
            "reversed": tau is not None and tau < 0}


def compare(proxies: dict, targets: dict, direction: str, target_value=None) -> dict:
    proxies, targets = _numbers(proxies), _numbers(targets)
    if proxies.keys() != targets.keys():
        raise ValueError("Proxy and target sample IDs must match exactly; no automatic subset selection")
    check_direction(direction, target_value)
    ids = list(targets)
    # A target proxy predicts the quantity itself; its distance to the target is what ranks.
    x, y = [orient(proxies[i], direction, target_value) if direction == "target" else proxies[i]
            for i in ids], [targets[i] for i in ids]
    counts = dict(concordant=0, discordant=0, proxy_only_ties=0, target_only_ties=0, joint_ties=0)
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            a = (x[i] > x[j]) - (x[i] < x[j])
            b = (y[i] > y[j]) - (y[i] < y[j])
            key = ("joint_ties" if a == b == 0 else "proxy_only_ties" if a == 0 else
                   "target_only_ties" if b == 0 else "concordant" if a == b else "discordant")
            counts[key] += 1
    c, d = counts["concordant"], counts["discordant"]
    denominator = math.sqrt((c + d + counts["proxy_only_ties"]) * (c + d + counts["target_only_ties"]))
    tau = (c - d) / denominator if denominator else None
    rx, ry = _ranks(x), _ranks(y)
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    numerator = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    denominator = math.sqrt(sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry))
    rho = numerator / denominator if denominator else None
    sign = -1 if direction == "lower" else 1
    permutation = permutation_tau(x, y, sign=sign)
    limitations = (["A two-sample ordering cannot establish generalization."] if len(ids) == 2 else
                   ["Correlation is undefined for fewer than two observations or a constant ranking."] if tau is None else [])
    smallest = permutation and permutation["smallest_possible_two_sided"]
    if smallest is not None and smallest >= 0.05:
        limitations.append(f"With {len(ids)} samples no ordering can reach two-sided p < 0.05 "
                           f"(smallest possible p = {smallest:.3g}).")
    return {"sample_ids": ids, "sample_count": len(ids), "direction": direction,
            "kendall_tau_b": tau, "spearman_rho": rho,
            "direction_adjusted_kendall_tau_b": None if tau is None else sign * tau,
            "direction_adjusted_spearman_rho": None if rho is None else sign * rho,
            "permutation_p": permutation,
            "pair_counts": counts,
            "interpretation": "Agreement on the supplied dataset, not independent validation or a candidate's physical KPI.",
            "limitations": limitations}
