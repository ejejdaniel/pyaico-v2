"""Simulation routes: framework-written procedures that generate new data from a model of a system.

Separate from calc. calc checks numbers in the agent's reasoning; a route runs a
model of the system (force field, circuit model, optics model, benchmark) and
returns computed evidence that carries the model's assumptions and applicability.
Routes are addressed by research object x quantity (see taxonomy). Adding a route
means adding one file, routes/<object>/<method>.py, that defines ROUTE.
"""
