"""Run one route locally in a time-limited subprocess and describe what happened.

Every outcome becomes a result document, including refusals and failures, so a
report cannot cite only the runs that worked. Statuses:
- completed: the route ran and returned values;
- refused: not run (missing package, outside applicability, over the time limit,
  or a job-only route);
- failed: the route raised an error;
- timeout: the run exceeded its time limit and was stopped.
"""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

from researchkit.simulation import registry, runner
from researchkit.simulation.route import Route
from opencode import executor as launcher
from opencode import runtime_settings

# A run's default and longest time limits: config/runtime.json, compute.
DEFAULT_LIMIT_S = runtime_settings.get("compute.simulation_s")
LOCAL_LIMIT_S = runtime_settings.get("compute.simulation_max_s")
NOTE = ("Computed evidence from a model of the system, not a measurement and not validation. "
        "Cite it with its route, assumptions, applicability and uncertainty.")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _environment(versions):
    return {"python": platform.python_version(), "platform": platform.platform(), "packages": versions}


def _file_fields(route, inputs):
    """(label, container, key) for every workspace file named in the inputs ("a" or "a[].b")."""
    for spec in route.file_inputs:
        if "[]." in spec:
            name, key = spec.split("[].", 1)
            for index, item in enumerate(inputs.get(name, [])):
                if isinstance(item, dict) and isinstance(item.get(key), str):
                    yield f"{name}[{index}].{key}", item, key
        elif isinstance(inputs.get(spec), str):
            yield spec, inputs, spec


def _abort_set(abort):
    return abort is not None and abort.is_set()


def _wait(process, started, limit, abort):
    """Wait for the process, stopping it past the time limit or on abort: (timed_out, cancelled)."""
    timed_out = cancelled = False
    while process.poll() is None:
        if time.monotonic() - started > limit:
            timed_out = True
        elif _abort_set(abort):
            cancelled = True
        else:
            time.sleep(0.2)
            continue
        process.kill()
        process.wait()
    return timed_out, cancelled


def _reply(folder: Path):
    """The subprocess's reply, or None when it printed none."""
    stdout = (folder / "stdout.txt").read_text(encoding="utf-8", errors="replace")
    line = next((item for item in stdout.splitlines() if item.startswith(runner.MARKER)), None)
    return None if line is None else json.loads(line[len(runner.MARKER):])


def declare(file: Path, folder: Path, *, time_limit_s=60, abort=None) -> dict:
    """A task tool's declaration, read in its own process: {"ok": True, "manifest": {...}} or {"ok": False, ...}."""
    folder.mkdir(parents=True, exist_ok=True)
    request = folder / "request.json"
    request.write_text(json.dumps({"describe": str(file)}, ensure_ascii=False), encoding="utf-8")
    started = time.monotonic()
    with (folder / "stdout.txt").open("wb") as out, (folder / "stderr.txt").open("wb") as err:
        process = launcher.spawn([sys.executable, "-I", runner.__file__, str(request)],
                                 launcher.Launch("agent_code", f"declaration of {Path(file).parent.name}"),
                                 cwd=str(folder), stdout=out, stderr=err)
        timed_out, cancelled = _wait(process, started, time_limit_s, abort)
    if cancelled:
        from opencode.provider import _check_abort
        _check_abort(abort)
    stderr = (folder / "stderr.txt").read_text(encoding="utf-8", errors="replace")
    if timed_out:
        return {"ok": False, "error": f"reading the declaration took over {time_limit_s} s", "stderr_tail": stderr[-1500:]}
    reply = _reply(folder)
    if reply is None:
        return {"ok": False, "error": f"the process exited with code {process.returncode} without a declaration",
                "stderr_tail": stderr[-1500:]}
    return reply


def run(route_id, inputs, folder: Path, *, time_limit_s=None, abort=None, resolve_file=None) -> dict:
    """Result document for one run; artifacts are left under folder/work.

    route_id is a route's id, or a Route itself (a mounted task tool, simulation/task_tools.py).
    resolve_file(path) returns the absolute path of a workspace file named in a
    file input, after the caller's permission check. Invalid inputs raise
    ValueError (a usage error, nothing was simulated).
    """
    route = route_id if isinstance(route_id, Route) else registry.get(route_id)
    if not isinstance(inputs, dict):
        raise ValueError("input must be a JSON object; see describe for this route's inputs")
    filled = registry.with_defaults(route.inputs, inputs)
    registry.validate_inputs(route, filled)
    limit = DEFAULT_LIMIT_S if time_limit_s is None else time_limit_s
    if isinstance(limit, bool) or not isinstance(limit, (int, float)) or not 1 <= limit <= LOCAL_LIMIT_S:
        raise ValueError(f"time_limit_s must be between 1 and {LOCAL_LIMIT_S}")
    missing, versions = registry.availability(route)
    document = {
        "route": {"id": route.id, "version": route.version, "title": route.title, "tier": route.tier,
                  "executor": route.executor},
        "status": None,
        "inputs": filled,
        "input_sha256": digest(json.dumps(filled, sort_keys=True, ensure_ascii=False).encode("utf-8")),
        "seed": filled.get("seed"),
        "applicability": {"statement": route.applicability, "problems": []},
        "assumptions": list(route.assumptions),
        "uncertainty": route.uncertainty,
        "references": list(route.references),
        "values": {},
        "details": {},
        "warnings": [],
        "artifacts": [],
        "input_files": [],
        "environment": _environment(versions),
        "time_limit_s": limit,
        "note": NOTE,
    }

    def refused(reason):
        return {**document, "status": "refused", "reason": reason}

    if missing:
        return refused("unavailable: missing " + ", ".join(missing))
    run_inputs = deepcopy(filled)
    for field, holder, key in _file_fields(route, run_inputs):
        if resolve_file is None:
            raise ValueError(f"{field} names a workspace file, but no workspace is available")
        path = Path(resolve_file(holder[key]))
        if not path.is_file():
            raise ValueError(f"{field}: {holder[key]} is not a file")
        document["input_files"].append({"field": field, "path": holder[key], "sha256": digest(path.read_bytes())})
        holder[key] = str(path)
    issues = list(route.check(run_inputs))
    document["applicability"]["problems"] = issues
    if issues:
        return refused("outside applicability: " + "; ".join(issues))
    estimate = float(route.estimate_s(run_inputs))
    document["estimated_s"] = round(estimate, 1)
    if estimate > LOCAL_LIMIT_S:
        return refused(f"estimated {estimate:.0f} s exceeds the local limit of {LOCAL_LIMIT_S} s; this size "
                       "needs the job executor, which is not available yet. Reduce the size or ask the human.")
    if estimate > limit:
        return refused(f"estimated {estimate:.0f} s exceeds time_limit_s={limit}; raise time_limit_s "
                       f"(at most {LOCAL_LIMIT_S}) or reduce the size")

    work = folder / "work"
    work.mkdir(parents=True, exist_ok=True)
    request = folder / "request.json"
    request.write_text(json.dumps({"route": route.id, "inputs": run_inputs, "workdir": str(work),
                                   **({"file": route.file} if route.file else {})},
                                  ensure_ascii=False), encoding="utf-8")
    started = time.monotonic()
    with (folder / "stdout.txt").open("wb") as out, (folder / "stderr.txt").open("wb") as err:
        purpose = "agent_code" if route.runs_user_code else "framework_compute"
        process = launcher.spawn([sys.executable, "-I", runner.__file__, str(request)],
                                 launcher.Launch(purpose, route.id),
                                 cwd=str(work), stdout=out, stderr=err)
        timed_out, cancelled = _wait(process, started, limit, abort)
    elapsed = time.monotonic() - started
    document["elapsed_s"] = round(elapsed, 2)
    stderr = (folder / "stderr.txt").read_text(encoding="utf-8", errors="replace")
    if cancelled:
        from opencode.provider import _check_abort
        _check_abort(abort)  # stops this call the way other research tools stop
    if timed_out:
        return {**document, "status": "timeout",
                "reason": f"stopped after {limit} s (estimated {estimate:.0f} s)", "stderr_tail": stderr[-1500:]}
    reply = _reply(folder)
    if reply is None:
        return {**document, "status": "failed", "reason": f"the route process exited with code {process.returncode} "
                "without a result", "stderr_tail": stderr[-1500:]}
    if reply.get("refused"):  # a task tool's own applicability check, run beside its code
        document["applicability"]["problems"] = [reply["refused"]]
        return refused(reply["refused"])
    if not reply["ok"]:
        return {**document, "status": "failed", "reason": reply["error"], "trace_tail": reply.get("trace", "")[-1500:]}
    return _completed(route, document, reply, work)


def _completed(route, document, reply, work):
    result = reply["result"] if isinstance(reply.get("result"), dict) else {}
    warnings = [str(item) for item in result.get("warnings", [])] + list(reply.get("nonfinite", []))
    values = {}
    for name, value in (result.get("values") or {}).items():
        if name not in route.outputs:
            warnings.append(f"route returned undeclared output {name!r}; kept under details")
            document["details"][name] = value
            continue
        values[name] = {"value": value, "unit": route.outputs[name]["unit"]}
    absent = [name for name in route.outputs if name not in values]
    if absent:
        document["details"]["not_computed"] = absent
    artifacts = []
    for name in result.get("artifacts", []):
        path = (work / name).resolve()
        if not path.is_file() or work.resolve() not in path.parents:
            warnings.append(f"artifact {name!r} was not produced inside the run folder")
            continue
        artifacts.append({"path": path.relative_to(work.resolve()).as_posix(), "sha256": digest(path.read_bytes()),
                          "bytes": path.stat().st_size})
    return {**document, "status": "completed", "values": values,
            "details": {**document["details"], **(result.get("details") or {})},
            "warnings": warnings, "artifacts": artifacts}
