"""Numerical models shared by routes (not routes themselves)."""
