"""RC trees driven by an ideal unit step: Elmore delays and the exact linear response.

Node voltages obey C dv/dt = -G v + s for t > 0 with v(0) = 0, where s carries the
source through the resistances of nodes attached to it. In an RC tree every node
settles at the source voltage. Zero-capacitance nodes are eliminated (Schur
complement) before the generalized eigenproblem G phi = lambda C phi, and their
voltages are recovered from their neighbours.
"""

from __future__ import annotations

import numpy as np

SOURCE = "source"


def build(nodes):
    """Index the tree; nodes are dicts with name, parent, resistance_ohm, capacitance_F."""
    names = [node["name"] for node in nodes]
    if len(set(names)) != len(names) or SOURCE in names:
        raise ValueError(f"node names must be unique and not {SOURCE!r}")
    index = {name: i for i, name in enumerate(names)}
    parents = []
    for node in nodes:
        parent = node["parent"]
        if parent != SOURCE and parent not in index:
            raise ValueError(f"node {node['name']!r} has unknown parent {parent!r}")
        if node["resistance_ohm"] <= 0 or node["capacitance_F"] < 0:
            raise ValueError(f"node {node['name']!r} needs resistance > 0 and capacitance >= 0")
        parents.append(-1 if parent == SOURCE else index[parent])
    # Every node must reach the source without a cycle.
    for start in range(len(nodes)):
        seen, current = set(), start
        while current != -1:
            if current in seen:
                raise ValueError(f"node {names[start]!r} is on a cycle; an RC tree has none")
            seen.add(current)
            current = parents[current]
    resistance = np.array([float(node["resistance_ohm"]) for node in nodes])
    capacitance = np.array([float(node["capacitance_F"]) for node in nodes])
    return names, np.array(parents), resistance, capacitance


def elmore(parents, resistance, capacitance):
    """Elmore delay of every node: sum over its path edges of R_edge times the capacitance downstream."""
    n = len(parents)
    downstream = capacitance.copy()
    depth = np.zeros(n, dtype=int)
    for i in range(n):
        current, d = parents[i], 0
        while current != -1:
            d += 1
            current = parents[current]
        depth[i] = d
    for i in sorted(range(n), key=lambda k: -depth[k]):
        if parents[i] != -1:
            downstream[parents[i]] += downstream[i]
    delay = np.zeros(n)
    for i in sorted(range(n), key=lambda k: depth[k]):
        upstream = delay[parents[i]] if parents[i] != -1 else 0.0
        delay[i] = upstream + resistance[i] * downstream[i]
    return delay


def response(parents, resistance, capacitance):
    """A function t -> node voltages (all nodes) for a unit step at t = 0."""
    n = len(parents)
    g = 1.0 / resistance
    G = np.zeros((n, n))
    s = np.zeros(n)
    for i in range(n):
        G[i, i] += g[i]
        p = parents[i]
        if p == -1:
            s[i] += g[i]
        else:
            G[p, p] += g[i]
            G[i, p] -= g[i]
            G[p, i] -= g[i]
    keep = np.flatnonzero(capacitance > 0)
    drop = np.flatnonzero(capacitance <= 0)
    if keep.size == 0:
        raise ValueError("at least one node needs capacitance > 0")
    if drop.size:
        solve = np.linalg.solve(G[np.ix_(drop, drop)], np.column_stack([G[np.ix_(drop, keep)], s[drop]]))
        reduced = G[np.ix_(keep, keep)] - G[np.ix_(keep, drop)] @ solve[:, :-1]
    else:
        reduced = G
    from scipy.linalg import eigh
    lam, phi = eigh(reduced, np.diag(capacitance[keep]))
    # w = v - 1 decays from -1; coefficients in the C-orthonormal basis.
    coefficients = phi.T @ (capacitance[keep] * -np.ones(keep.size))

    def voltages(t):
        v = np.ones(n)
        v[keep] = 1.0 + phi @ (coefficients * np.exp(-lam * t))
        if drop.size:
            # G_bb v_b = s_b - G_ba v_a; with v_a known this recovers the eliminated nodes.
            v[drop] = solve[:, -1] - solve[:, :-1] @ v[keep]
        return v

    return voltages, lam


def crossing(voltages, node, level, guess):
    """First time node's voltage reaches level; the response of an RC tree is monotone."""
    from scipy.optimize import brentq
    high = max(guess, 1e-30)
    for _ in range(200):
        if voltages(high)[node] >= level:
            break
        high *= 2.0
    else:
        raise ValueError("response never reached the level")
    return brentq(lambda t: voltages(t)[node] - level, 0.0, high, xtol=high * 1e-12, rtol=1e-12, maxiter=500)


def ladder(total_resistance, total_capacitance, segments, driver_resistance=0.0, load_capacitance=0.0):
    """Uniform L-section ladder for a distributed line: R/N then C/N per segment, load at the far end."""
    nodes = []
    for k in range(1, segments + 1):
        nodes.append({
            "name": f"n{k}", "parent": SOURCE if k == 1 else f"n{k - 1}",
            "resistance_ohm": total_resistance / segments + (driver_resistance if k == 1 else 0.0),
            "capacitance_F": total_capacitance / segments + (load_capacitance if k == segments else 0.0),
        })
    return nodes


def far_end_delays(nodes):
    """(Elmore delay, 50% delay, 10-90% rise time) at the last node of a ladder."""
    names, parents, resistance, capacitance = build(nodes)
    delays = elmore(parents, resistance, capacitance)
    voltages, _ = response(parents, resistance, capacitance)
    last = len(names) - 1
    t50 = crossing(voltages, last, 0.5, delays[last])
    rise = crossing(voltages, last, 0.9, delays[last]) - crossing(voltages, last, 0.1, delays[last])
    return float(delays[last]), float(t50), float(rise)
