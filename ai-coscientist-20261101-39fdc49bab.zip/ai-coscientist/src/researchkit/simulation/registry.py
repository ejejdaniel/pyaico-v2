"""Find every route file, check its declaration, and answer catalog questions.

Adding a route means adding routes/<object>/<method>.py with a ROUTE; nothing else
changes. A file that fails to import or declares itself wrongly is listed as broken
rather than hiding the other routes.
"""

from __future__ import annotations

from copy import deepcopy
import difflib
import importlib
import importlib.metadata
import importlib.util
import pkgutil

import jsonschema

from researchkit.simulation import routes as routes_package
from researchkit.simulation.route import Route, problems
from researchkit.simulation.taxonomy import DISCIPLINES, OBJECTS, QUANTITIES, TIERS

_cache = None


def load():
    """(routes by id, broken files with their problems)."""
    global _cache
    if _cache is None:
        found, broken = {}, []
        for info in pkgutil.walk_packages(routes_package.__path__, routes_package.__name__ + "."):
            parts = info.name.split(".")
            if info.ispkg or len(parts) != len(routes_package.__name__.split(".")) + 2:
                continue
            package, module = parts[-2], parts[-1]
            try:
                route = importlib.import_module(info.name).ROUTE
            except Exception as error:  # a broken file must not hide the others
                broken.append({"file": f"routes/{package}/{module}.py",
                               "problems": [f"{type(error).__name__}: {error}"]})
                continue
            issues = problems(route, package=package, module=module) if isinstance(route, Route) else [
                "ROUTE is not a Route"]
            if not issues:
                try:
                    validate_inputs(route, with_defaults(route.inputs, route.example))
                except ValueError as error:
                    issues.append(f"example does not satisfy inputs: {error}")
            if issues or route.id in found:
                broken.append({"file": f"routes/{package}/{module}.py",
                               "problems": issues or [f"duplicate id {route.id}"]})
                continue
            found[route.id] = route
        _cache = (dict(sorted(found.items())), broken)
    return _cache


def get(route_id):
    found, _ = load()
    if route_id not in found:
        near = difflib.get_close_matches(str(route_id), list(found), n=3, cutoff=0.4)
        hint = f"; closest: {', '.join(near)}" if near else ""
        raise ValueError(f"unknown route {route_id!r}{hint}. Call research_simulate with action catalog.")
    return found[route_id]


def availability(route):
    """Missing requirements (module names), with installed versions of the present ones."""
    missing, versions = [], {}
    for name in route.requires:
        if importlib.util.find_spec(name) is None:
            missing.append(name)
            continue
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            module = importlib.import_module(name)
            versions[name] = getattr(module, "__version__", "unknown")
    if route.executor == "job":
        missing.append("job executor (not available yet)")
    return missing, versions


def with_defaults(schema, value):
    """Fill schema defaults into objects (recursively); the record keeps the filled inputs."""
    value = deepcopy(value)
    if isinstance(value, dict) and schema.get("type") == "object":
        for name, spec in schema.get("properties", {}).items():
            if name not in value and "default" in spec:
                value[name] = deepcopy(spec["default"])
            if name in value:
                value[name] = with_defaults(spec, value[name])
    elif isinstance(value, list) and isinstance(schema.get("items"), dict):
        value = [with_defaults(schema["items"], item) for item in value]
    return value


def validate_inputs(route, inputs):
    validator = jsonschema.Draft202012Validator(route.inputs)
    errors = sorted(validator.iter_errors(inputs), key=lambda error: list(error.absolute_path))
    if errors:
        raise ValueError("; ".join(
            f"{'/'.join(str(p) for p in error.absolute_path) or '(inputs)'}: {error.message}"
            for error in errors[:8]))


def _row(route):
    missing, _ = availability(route)
    row = {"id": route.id, "title": route.title, "summary": route.summary, "tier": route.tier,
           "available": not missing}
    if missing:
        row["missing"] = missing
    return row


def catalog(*, object=None, quantity=None, discipline=None):
    found, broken = load()
    for name, value, allowed in (("object", object, OBJECTS), ("quantity", quantity, QUANTITIES),
                                 ("discipline", discipline, DISCIPLINES)):
        if value is not None and value not in allowed:
            raise ValueError(f"{name} {value!r} is not one of: {', '.join(allowed)}")
    selected = [route for route in found.values()
                if (object is None or route.object == object)
                and (quantity is None or route.quantity == quantity)
                and (discipline is None or discipline in route.disciplines)]
    cells = {}
    for route in found.values():
        key = f"{route.object} x {route.quantity}"
        cells[key] = cells.get(key, 0) + 1
    return {
        "note": ("A route is a framework-written simulation: it generates new data from a model of the system, "
                 "with declared assumptions and applicability. Address: <object>.<quantity>.<method>. "
                 "Call describe for a route's inputs, outputs, assumptions and example."),
        "objects": OBJECTS, "quantities": QUANTITIES, "tiers": TIERS, "disciplines": list(DISCIPLINES),
        "cells_with_routes": cells,
        "routes": [_row(route) for route in selected],
        **({"broken_route_files": broken} if broken else {}),
    }


def describe(route_id):
    route = get(route_id)
    missing, versions = availability(route)
    return {**route.manifest(), "available": not missing, "missing": missing, "installed": versions,
            "object_meaning": OBJECTS[route.object], "quantity_meaning": QUANTITIES[route.quantity],
            "tier_meaning": TIERS[route.tier]}
