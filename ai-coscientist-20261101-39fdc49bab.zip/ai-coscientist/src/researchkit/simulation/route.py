"""The declaration every route file provides as `ROUTE`.

A route is a framework-written simulation procedure. Everything the research agent
needs to choose and read it is declared up front: inputs, outputs with units,
model assumptions, applicability, uncertainty, cost and requirements. The agent
only picks a route, fills its inputs and reads the result.

`run(inputs, workdir)` receives inputs with schema defaults filled and returns
{"values": {output: number or list}, "details": {...}, "warnings": [...],
"artifacts": [paths relative to workdir]}. Heavy imports belong inside run, so
the catalog loads without them and a missing package only marks the route
unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from typing import Callable

from researchkit.simulation.taxonomy import DISCIPLINES, OBJECTS, QUANTITIES, TIERS

ID_PATTERN = re.compile(r"^([a-z]+)\.([a-z]+)\.([a-z0-9_]+)$")
EXECUTORS = ("local", "job")


def _no_problems(inputs):
    return []


def _one_second(inputs):
    return 1.0


@dataclass(frozen=True)
class Route:
    id: str
    title: str
    summary: str
    tier: str
    disciplines: tuple
    inputs: dict
    outputs: dict
    assumptions: tuple
    applicability: str
    uncertainty: str
    references: tuple
    example: dict
    run: Callable
    check: Callable = field(default=_no_problems)
    estimate_s: Callable = field(default=_one_second)
    requires: tuple = ()
    executor: str = "local"
    version: str = "1"
    file_inputs: tuple = ()  # input fields naming workspace files: "field" or "list[].field"
    runs_user_code: bool = False
    # A task tool's route.py (simulation/task_tools.py): the route is loaded and run from it in the subprocess
    # only, never imported by the framework's own process.
    file: str = ""

    @property
    def object(self):
        return self.id.split(".")[0]

    @property
    def quantity(self):
        return self.id.split(".")[1]

    @property
    def method(self):
        return self.id.split(".")[2]

    def manifest(self):
        """Everything declared, without the callables."""
        return {
            "id": self.id, "version": self.version, "title": self.title, "summary": self.summary,
            "object": self.object, "quantity": self.quantity, "method": self.method, "tier": self.tier,
            "disciplines": list(self.disciplines), "executor": self.executor,
            "inputs": self.inputs, "outputs": self.outputs, "assumptions": list(self.assumptions),
            "applicability": self.applicability, "uncertainty": self.uncertainty,
            "references": list(self.references), "requires": list(self.requires),
            "file_inputs": list(self.file_inputs), "runs_user_code": self.runs_user_code,
            "example": self.example,
        }


def problems(route, *, package, module):
    """Declaration errors, so a malformed route is reported instead of silently listed."""
    found = []
    match = ID_PATTERN.match(route.id)
    if not match:
        return [f"id {route.id!r} is not <object>.<quantity>.<method>"]
    obj, quantity, method = match.groups()
    if obj not in OBJECTS:
        found.append(f"object {obj!r} is not in the taxonomy")
    if quantity not in QUANTITIES:
        found.append(f"quantity {quantity!r} is not in the taxonomy")
    if (package, module) != (obj, method):
        found.append(f"file routes/{package}/{module}.py must declare id {package}.<quantity>.{module}")
    if route.tier not in TIERS:
        found.append(f"tier {route.tier!r} is not one of {', '.join(TIERS)}")
    if route.executor not in EXECUTORS:
        found.append(f"executor {route.executor!r} is not one of {', '.join(EXECUTORS)}")
    unknown = [tag for tag in route.disciplines if tag not in DISCIPLINES]
    if unknown:
        found.append(f"unknown discipline tags: {', '.join(unknown)}")
    if not isinstance(route.inputs, dict) or route.inputs.get("type") != "object":
        found.append("inputs must be a JSON schema of type object")
    for name, spec in route.outputs.items():
        if not isinstance(spec, dict) or "unit" not in spec or "description" not in spec:
            found.append(f"output {name!r} needs unit and description")
    for name in route.file_inputs:
        if name.split("[]")[0] not in route.inputs.get("properties", {}):
            found.append(f"file input {name!r} does not start with an input property")
    if not route.assumptions or not route.applicability or not route.uncertainty or not route.references:
        found.append("assumptions, applicability, uncertainty and references are required")
    return found
