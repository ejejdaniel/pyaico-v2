"""Route files, one per method: <object>/<method>.py defining ROUTE."""
