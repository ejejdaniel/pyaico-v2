"""Benchmark optimizers written in the workspace against built-in baselines on standard test functions."""

from researchkit.simulation.route import Route

FUNCTIONS = ("sphere", "rosenbrock", "rastrigin", "ackley")
BASELINES = ("random_search", "nelder_mead")

INPUTS = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "candidates": {
            "type": "array", "maxItems": 4, "default": [],
            "description": "Optimizers to test. Each module defines function(f, bounds, budget, rng): f takes a 1-D "
                           "numpy array and returns a float; bounds is a (dimension, 2) array; budget is the number "
                           "of evaluations; rng is a numpy Generator. The host counts evaluations, stops the run at "
                           "the budget and scores the best value f returned, so the return value is ignored.",
            "items": {"type": "object", "additionalProperties": False, "required": ["name", "module", "function"],
                      "properties": {"name": {"type": "string", "minLength": 1, "maxLength": 40},
                                     "module": {"type": "string", "minLength": 1,
                                                "description": "Workspace path of the .py file"},
                                     "function": {"type": "string", "minLength": 1}}}},
        "baselines": {"type": "array", "uniqueItems": True, "items": {"type": "string", "enum": list(BASELINES)},
                      "default": list(BASELINES)},
        "functions": {"type": "array", "uniqueItems": True, "minItems": 1,
                      "items": {"type": "string", "enum": list(FUNCTIONS)}, "default": list(FUNCTIONS)},
        "dimension": {"type": "integer", "minimum": 1, "maximum": 100, "default": 5},
        "budget": {"type": "integer", "minimum": 10, "maximum": 1000000, "default": 2000,
                   "description": "Function evaluations per run"},
        "seeds": {"type": "integer", "minimum": 3, "maximum": 100, "default": 10},
        "base_seed": {"type": "integer", "minimum": 0, "default": 0},
        "shift": {"type": "boolean", "default": True,
                  "description": "Move each function's optimum to a random point per seed, so an optimizer cannot "
                                 "win by favouring the origin or the centre"},
        "target_error": {"type": "number", "exclusiveMinimum": 0, "default": 1e-4,
                         "description": "A run succeeds when f - f_min reaches this"},
    },
}

OUTPUTS = {
    "median_final_error": {"unit": "f units", "description": "Median best f - f_min per row of details.rows"},
    "iqr_final_error": {"unit": "f units", "description": "Interquartile range of the final error per row"},
    "success_rate": {"unit": "1", "description": "Share of seeds reaching target_error per row"},
    "expected_running_time": {"unit": "evaluations",
                              "description": "Evaluations spent over all seeds divided by successes per row "
                                             "(null without success)"},
    "comparison_p_holm": {"unit": "1", "description": "Two-sided Mann-Whitney p of final errors, Holm-adjusted over "
                                                      "all comparisons, per details.comparisons"},
    "comparison_a12": {"unit": "1", "description": "Probability that the candidate's final error is lower than the "
                                                   "baseline's (Vargha-Delaney A), per details.comparisons"},
}

BOUNDS = {"sphere": 5.12, "rosenbrock": 5.0, "rastrigin": 5.12, "ackley": 32.768}


def _value(name, z):
    import numpy as np
    if name == "sphere":
        return float(np.sum(z * z))
    if name == "rosenbrock":
        return float(np.sum(100.0 * (z[1:] - z[:-1] ** 2) ** 2 + (1.0 - z[:-1]) ** 2))
    if name == "rastrigin":
        return float(10.0 * z.size + np.sum(z * z - 10.0 * np.cos(2 * np.pi * z)))
    return float(-20.0 * np.exp(-0.2 * np.sqrt(np.mean(z * z))) - np.exp(np.mean(np.cos(2 * np.pi * z)))
                 + 20.0 + np.e)


class _Budget(Exception):
    pass


class _Problem:
    """Counts evaluations, records the best value and stops at the budget."""

    def __init__(self, name, optimum, budget, target):
        import numpy as np
        self.name, self.optimum, self.budget, self.target = name, optimum, budget, target
        self.count, self.best, self.hit = 0, np.inf, None
        self.trace = []

    def __call__(self, x):
        import numpy as np
        if self.count >= self.budget:
            raise _Budget()
        x = np.asarray(x, dtype=float).ravel()
        if x.size != self.optimum.size:
            raise ValueError(f"f expects a vector of length {self.optimum.size}, got {x.size}")
        z = x - self.optimum + (1.0 if self.name == "rosenbrock" else 0.0)
        value = _value(self.name, z)
        self.count += 1
        if value < self.best:
            self.best = value
            self.trace.append((self.count, value))
            if self.hit is None and value <= self.target:
                self.hit = self.count
        return value


def _random_search(f, bounds, budget, rng):
    while True:
        f(rng.uniform(bounds[:, 0], bounds[:, 1]))


def _nelder_mead(f, bounds, budget, rng):
    from scipy.optimize import minimize
    while True:  # restart from random points until the budget ends
        minimize(f, rng.uniform(bounds[:, 0], bounds[:, 1]), method="Nelder-Mead",
                 options={"maxfev": budget, "xatol": 1e-12, "fatol": 1e-14})


def _load(candidate):
    import importlib.util
    from pathlib import Path
    path = Path(candidate["module"])
    spec = importlib.util.spec_from_file_location(f"candidate_{abs(hash(str(path)))}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return getattr(module, candidate["function"])


def check(inputs):
    names = [c["name"] for c in inputs["candidates"]]
    found = []
    if len(set(names)) != len(names) or set(names) & set(BASELINES):
        found.append("candidate names must be unique and differ from baseline names")
    if not inputs["candidates"] and not inputs["baselines"]:
        found.append("nothing to run: give candidates or baselines")
    return found


def estimate_s(inputs):
    runs = (len(inputs["candidates"]) + len(inputs["baselines"])) * len(inputs["functions"]) * inputs["seeds"]
    return 3.0 + runs * inputs["budget"] * (25e-6 + 0.5e-6 * inputs["dimension"])


def run(inputs, workdir):
    import numpy as np
    from scipy.stats import mannwhitneyu

    optimizers = {name: fn for name, fn in (("random_search", _random_search), ("nelder_mead", _nelder_mead))
                  if name in inputs["baselines"]}
    candidates = [c["name"] for c in inputs["candidates"]]
    for candidate in inputs["candidates"]:
        optimizers[candidate["name"]] = _load(candidate)
    d, budget, target = inputs["dimension"], inputs["budget"], inputs["target_error"]
    finals, rows, traces, errors, csv = {}, [], {}, [], ["optimizer,function,seed,final_error,evaluations_to_target"]
    for fi, function in enumerate(inputs["functions"]):
        bound = BOUNDS[function]
        bounds = np.array([[-bound, bound]] * d)
        for name, optimizer in optimizers.items():
            results, hits = [], []
            for seed in range(inputs["seeds"]):
                place = np.random.default_rng([inputs["base_seed"], fi, seed, 1])
                # Where f reaches its minimum f_min = 0 (Rosenbrock is moved so that this holds too).
                optimum = place.uniform(-0.5 * bound, 0.5 * bound, d) if inputs["shift"] else np.zeros(d)
                problem = _Problem(function, optimum, budget, target)
                rng = np.random.default_rng([inputs["base_seed"], fi, seed, 2])  # same stream for every optimizer
                try:
                    optimizer(problem, bounds.copy(), budget, rng)
                except _Budget:
                    pass
                except Exception as error:  # the candidate's own failure is part of its result
                    errors.append(f"{name} on {function} seed {seed}: {type(error).__name__}: {str(error)[:160]}")
                final = float(problem.best) if problem.count else float("inf")
                results.append(final)
                hits.append(problem.hit)
                traces.setdefault((name, function), []).append(problem.trace)
                csv.append(f"{name},{function},{seed},{final:.6e},{'' if problem.hit is None else problem.hit}")
            values = np.array(results)
            successes = [h for h in hits if h is not None]
            spent = sum(h if h is not None else budget for h in hits)
            finals[(name, function)] = values
            rows.append({"optimizer": name, "function": function,
                         "median": float(np.median(values)),
                         "iqr": float(np.percentile(values, 75) - np.percentile(values, 25)),
                         "success": len(successes) / len(hits),
                         "ert": spent / len(successes) if successes else None})
    comparisons, p_values = [], []
    for candidate in candidates:
        for baseline in inputs["baselines"]:
            for function in inputs["functions"]:
                a, b = finals[(candidate, function)], finals[(baseline, function)]
                if np.allclose(a, b, rtol=0, atol=0):
                    p, a12 = 1.0, 0.5
                else:
                    test = mannwhitneyu(a, b, alternative="two-sided")
                    p = float(test.pvalue)
                    a12 = float(np.mean([(x < y) + 0.5 * (x == y) for x in a for y in b]))
                comparisons.append({"candidate": candidate, "baseline": baseline, "function": function})
                p_values.append(p)
                comparisons[-1]["a12"] = a12
    holm = _holm(p_values)
    _artifacts(workdir, inputs, rows, traces, csv)
    warnings = []
    if errors:
        warnings.append(f"{len(errors)} runs raised errors in the optimizer; their best value before the error is "
                        f"scored. First: {errors[0]}")
    if candidates and inputs["seeds"] < 10:
        warnings.append("fewer than 10 seeds: rank tests have little power")
    return {
        "values": {"median_final_error": [r["median"] for r in rows], "iqr_final_error": [r["iqr"] for r in rows],
                   "success_rate": [r["success"] for r in rows], "expected_running_time": [r["ert"] for r in rows],
                   "comparison_p_holm": holm, "comparison_a12": [c["a12"] for c in comparisons]},
        "warnings": warnings,
        "details": {"rows": [{"optimizer": r["optimizer"], "function": r["function"]} for r in rows],
                    "comparisons": [{k: c[k] for k in ("candidate", "baseline", "function")} for c in comparisons],
                    "bounds_half_width": {f: BOUNDS[f] for f in inputs["functions"]},
                    "errors": errors[:20]},
        "artifacts": ["runs.csv", "convergence.png"],
    }


def _holm(p_values):
    order = sorted(range(len(p_values)), key=lambda i: p_values[i])
    adjusted, running = [0.0] * len(p_values), 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(p_values) - rank) * p_values[i]))
        adjusted[i] = running
    return adjusted


def _artifacts(workdir, inputs, rows, traces, csv):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    (workdir / "runs.csv").write_text("\n".join(csv) + "\n", encoding="utf-8")
    functions = inputs["functions"]
    figure, axes = plt.subplots(1, len(functions), figsize=(3.2 * len(functions), 3.0), squeeze=False)
    grid = np.unique(np.geomspace(1, inputs["budget"], 60).astype(int))
    for axis, function in zip(axes[0], functions):
        for name in dict.fromkeys(r["optimizer"] for r in rows):
            curves = []
            for trace in traces[(name, function)]:
                best, k, curve = np.inf, 0, []
                for evaluation in grid:
                    while k < len(trace) and trace[k][0] <= evaluation:
                        best = trace[k][1]
                        k += 1
                    curve.append(best)
                curves.append(curve)
            axis.plot(grid, np.maximum(np.median(np.array(curves), axis=0), 1e-16), label=name)
        axis.set_xscale("log")
        axis.set_yscale("log")
        axis.set_title(function, fontsize=9)
        axis.set_xlabel("evaluations")
    axes[0][0].set_ylabel("median best f - f_min")
    axes[0][-1].legend(fontsize=7)
    figure.tight_layout()
    figure.savefig(workdir / "convergence.png", dpi=110)
    plt.close(figure)


ROUTE = Route(
    id="algorithm.performance.optimizer_benchmark",
    title="Optimizer benchmark on standard test functions",
    summary="Runs workspace optimizers and built-in baselines (random search, Nelder-Mead) over seeds with a fixed "
            "evaluation budget; reports final error, success rate, expected running time and rank tests",
    tier="T2",
    disciplines=("optimization", "ml"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Performance is measured on four standard synthetic functions with a shifted optimum, not on the real "
        "problem; good results here do not imply good results there",
        "The host counts every call to f and scores the best value seen, whatever the optimizer returns",
        "Every optimizer gets the same per-seed random stream and optimum location (common random numbers)",
    ),
    applicability=("Continuous box-constrained minimization in 1-100 dimensions. The candidate code runs in the "
                   "route's subprocess with the time limit; this is not a security sandbox, so run only code you "
                   "wrote for this purpose."),
    uncertainty=("Median and IQR over seeds; Mann-Whitney tests with Holm adjustment over all reported comparisons. "
                 "Few seeds give little power; differences on these functions may not transfer."),
    references=(
        "N. Hansen et al., COCO: a platform for comparing continuous optimizers, Optim. Methods Softw. 36, 114 (2021)",
        "A. Vargha, H. D. Delaney, J. Educ. Behav. Stat. 25, 101 (2000): the A measure",
        "S. Holm, Scand. J. Stat. 6, 65 (1979)",
    ),
    example={"candidates": [{"name": "mine", "module": "work/my_optimizer.py", "function": "optimize"}],
             "functions": ["sphere", "rastrigin"], "dimension": 5, "budget": 2000, "seeds": 10},
    run=run, check=check, estimate_s=estimate_s, requires=("numpy", "scipy", "matplotlib"),
    file_inputs=("candidates[].module",), runs_user_code=True,
)
