"""Elmore delay and exact step response of an RC tree."""

from researchkit.simulation.route import Route

MAX_NODES = 3000

NODE = {"type": "object", "additionalProperties": False,
        "required": ["name", "parent", "resistance_ohm", "capacitance_F"],
        "properties": {
            "name": {"type": "string", "minLength": 1},
            "parent": {"type": "string", "minLength": 1,
                       "description": "Parent node name, or \"source\" for a node driven directly by the step source"},
            "resistance_ohm": {"type": "number", "exclusiveMinimum": 0,
                               "description": "Resistance between the parent and this node"},
            "capacitance_F": {"type": "number", "minimum": 0, "description": "Capacitance from this node to ground"}}}

INPUTS = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "nodes": {"type": "array", "minItems": 1, "maxItems": MAX_NODES, "items": NODE,
                  "description": "The tree; give either nodes or ladder"},
        "ladder": {"type": "object", "additionalProperties": False,
                   "required": ["total_resistance_ohm", "total_capacitance_F"],
                   "description": "Uniform distributed line built as L-sections (R/N then C/N)",
                   "properties": {
                       "total_resistance_ohm": {"type": "number", "exclusiveMinimum": 0},
                       "total_capacitance_F": {"type": "number", "exclusiveMinimum": 0},
                       "segments": {"type": "integer", "minimum": 1, "maximum": MAX_NODES, "default": 200},
                       "driver_resistance_ohm": {"type": "number", "minimum": 0, "default": 0},
                       "load_capacitance_F": {"type": "number", "minimum": 0, "default": 0}}},
        "report_nodes": {"type": "array", "items": {"type": "string"}, "uniqueItems": True,
                         "description": "Nodes to report; default: every leaf (sink)"},
        "exact_response": {"type": "boolean", "default": True,
                           "description": "Also solve the linear step response for 50% delay and 10-90% rise time"},
    },
    "oneOf": [{"required": ["nodes"]}, {"required": ["ladder"]}],
}

OUTPUTS = {
    "elmore_delay_s": {"unit": "s", "description": "Elmore delay of each reported node (order in details.nodes)"},
    "t50_s": {"unit": "s", "description": "50% delay of each reported node from the exact linear response"},
    "rise_10_90_s": {"unit": "s", "description": "10-90% rise time of each reported node"},
    "worst_elmore_delay_s": {"unit": "s", "description": "Largest Elmore delay among reported nodes"},
    "worst_t50_s": {"unit": "s", "description": "Largest 50% delay among reported nodes"},
    "t50_over_elmore": {"unit": "1", "description": "Worst 50% delay divided by its node's Elmore delay"},
}


def _nodes(inputs):
    from researchkit.simulation.models import rc
    if "nodes" in inputs:
        return inputs["nodes"]
    line = inputs["ladder"]
    return rc.ladder(line["total_resistance_ohm"], line["total_capacitance_F"], line["segments"],
                     line["driver_resistance_ohm"], line["load_capacitance_F"])


def check(inputs):
    if "ladder" in inputs:
        return []
    names = {node["name"] for node in inputs["nodes"]}
    unknown = [name for name in inputs.get("report_nodes", []) if name not in names]
    return [f"report_nodes not in the tree: {', '.join(unknown)}"] if unknown else []


def estimate_s(inputs):
    n = len(inputs["nodes"]) if "nodes" in inputs else inputs["ladder"]["segments"]
    return 2.0 + (n / 1000.0) ** 3 * 4.0 + (n * 0.002 if inputs["exact_response"] else 0.0)


def run(inputs, workdir):
    from researchkit.simulation.models import rc
    nodes = _nodes(inputs)
    names, parents, resistance, capacitance = rc.build(nodes)
    leaves = [i for i in range(len(names)) if i not in set(parents.tolist())]
    chosen = ([names.index(name) for name in inputs["report_nodes"]] if inputs.get("report_nodes")
              else leaves)
    delays = rc.elmore(parents, resistance, capacitance)
    values = {"elmore_delay_s": [float(delays[i]) for i in chosen]}
    worst = max(chosen, key=lambda i: delays[i])
    values["worst_elmore_delay_s"] = float(delays[worst])
    warnings = []
    if inputs["exact_response"]:
        voltages, lam = rc.response(parents, resistance, capacitance)
        t50 = [rc.crossing(voltages, i, 0.5, delays[i]) for i in chosen]
        rise = [rc.crossing(voltages, i, 0.9, delays[i]) - rc.crossing(voltages, i, 0.1, delays[i]) for i in chosen]
        values.update({"t50_s": t50, "rise_10_90_s": rise})
        slowest = max(range(len(chosen)), key=lambda k: t50[k])
        values["worst_t50_s"] = t50[slowest]
        values["t50_over_elmore"] = t50[slowest] / float(delays[chosen[slowest]])
        if any(t > float(delays[i]) * (1 + 1e-9) for t, i in zip(t50, chosen)):
            warnings.append("a 50% delay exceeds its Elmore delay; Elmore bounds the 50% delay of RC trees, "
                            "so check the input for non-tree structure")
    if "ladder" in inputs:
        warnings.append(f"distributed line approximated by {len(names)} L-sections; discretization error "
                        "shrinks roughly as 1/segments")
    return {"values": values, "warnings": warnings,
            "details": {"nodes": [names[i] for i in chosen], "node_count": len(names),
                        "total_capacitance_F": float(capacitance.sum()),
                        "slowest_time_constant_s": (float(1 / lam[0]) if inputs["exact_response"] else None)}}


ROUTE = Route(
    id="circuit.electrical.rc_tree_delay",
    title="RC tree delay (Elmore and exact step response)",
    summary="Elmore delay, 50% delay and 10-90% rise time of an RC tree or uniform distributed line driven by a step",
    tier="T1",
    disciplines=("circuits", "semiconductor"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Ideal unit-step source; linear resistors and grounded capacitors only (no inductance, no coupling "
        "capacitance between nodes, no nonlinear driver)",
        "The network is a tree rooted at the source; every node settles at the source voltage",
        "A ladder is a lumped L-section approximation of a uniform distributed RC line",
    ),
    applicability=("RC-dominated interconnect and gate-load networks where inductance is negligible "
                   "(line delay much longer than the time of flight) and the driver acts as a linear resistance."),
    uncertainty=("Exact for the stated linear model (numerical tolerance about 1e-12 relative). Model error "
                 "comes from the driver and inductance assumptions; a ladder adds a discretization error of "
                 "order 1/segments."),
    references=(
        "W. C. Elmore, J. Appl. Phys. 19, 55 (1948)",
        "R. Gupta, B. Tutuianu, L. T. Pileggi, IEEE Trans. CAD 16(1), 95 (1997): Elmore delay as a bound for RC trees",
    ),
    example={"ladder": {"total_resistance_ohm": 1000.0, "total_capacitance_F": 1e-13, "segments": 100,
                        "driver_resistance_ohm": 500.0, "load_capacitance_F": 2e-15}},
    run=run, check=check, estimate_s=estimate_s, requires=("numpy", "scipy"),
)
