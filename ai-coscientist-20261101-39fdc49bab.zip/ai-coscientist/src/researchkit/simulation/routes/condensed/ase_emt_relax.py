"""Relaxed structure, mixing and vacancy energies and bulk modulus of fcc metals with EMT."""

from researchkit.simulation.route import Route

METALS = ["Al", "Cu", "Ag", "Au", "Ni", "Pd", "Pt"]

INPUTS = {
    "type": "object", "additionalProperties": False, "required": ["host"],
    "properties": {
        "host": {"type": "string", "enum": METALS, "description": "fcc host metal"},
        "supercell": {"type": "integer", "minimum": 1, "maximum": 6, "default": 3,
                      "description": "Repeats of the 4-atom cubic fcc cell along each axis"},
        "substitutions": {"type": "object", "default": {},
                          "propertyNames": {"enum": METALS},
                          "additionalProperties": {"type": "integer", "minimum": 1},
                          "description": "Solute element -> number of host atoms it replaces, placed at random"},
        "vacancies": {"type": "integer", "minimum": 0, "default": 0},
        "relax_cell": {"type": "boolean", "default": True},
        "fmax_eV_A": {"type": "number", "exclusiveMinimum": 0, "default": 0.01},
        "max_steps": {"type": "integer", "minimum": 10, "maximum": 5000, "default": 1000},
        "seed": {"type": "integer", "minimum": 0, "default": 0},
    },
}

OUTPUTS = {
    "lattice_constant_A": {"unit": "angstrom", "description": "Cubic lattice constant of the relaxed cell "
                                                              "(per 4-atom cell)"},
    "host_lattice_constant_A": {"unit": "angstrom", "description": "Relaxed lattice constant of the pure host"},
    "energy_per_atom_eV": {"unit": "eV", "description": "EMT energy per atom of the relaxed structure "
                                                         "(EMT zero, not a cohesive energy)"},
    "mixing_energy_eV_per_atom": {"unit": "eV", "description": "E - sum N_i e_i over atoms, with e_i the relaxed "
                                                                "pure-element energy per atom"},
    "vacancy_formation_energy_eV": {"unit": "eV", "description": "(E_defect - N_remaining e_host) per vacancy; "
                                                                 "pure host only"},
    "bulk_modulus_GPa": {"unit": "GPa", "description": "From an equation-of-state fit around the relaxed volume"},
}


def check(inputs):
    atoms = 4 * inputs["supercell"] ** 3
    used = sum(inputs["substitutions"].values()) + inputs["vacancies"]
    found = []
    if used >= atoms:
        found.append(f"substitutions and vacancies ({used}) must leave host atoms in the {atoms}-atom cell")
    if inputs["host"] in inputs["substitutions"]:
        found.append("a solute must differ from the host")
    return found


def estimate_s(inputs):
    atoms = 4 * inputs["supercell"] ** 3
    return 3.0 + atoms * inputs["max_steps"] * 1.5e-4 * (2 if inputs["relax_cell"] else 1) / 4 + atoms * 0.01


def _relaxed(atoms, relax_cell, fmax, steps):
    from ase.filters import FrechetCellFilter
    from ase.optimize import BFGS
    target = FrechetCellFilter(atoms) if relax_cell else atoms
    optimizer = BFGS(target, logfile=None)
    converged = optimizer.run(fmax=fmax, steps=steps)
    return atoms, bool(converged), optimizer.nsteps


def _pure(element, fmax, steps):
    from ase.build import bulk
    from ase.calculators.emt import EMT
    atoms = bulk(element, "fcc", cubic=True)
    atoms.calc = EMT()
    atoms, converged, _ = _relaxed(atoms, True, fmax, steps)
    return atoms.cell.lengths()[0], atoms.get_potential_energy() / len(atoms), converged


def run(inputs, workdir):
    import numpy as np
    from ase.calculators.emt import EMT
    from ase.eos import EquationOfState
    from ase.io import write
    from ase.units import GPa

    fmax, steps = inputs["fmax_eV_A"], inputs["max_steps"]
    warnings = []
    references = {}
    for element in [inputs["host"], *inputs["substitutions"]]:
        a, energy, converged = _pure(element, fmax, steps)
        references[element] = {"lattice_constant_A": float(a), "energy_per_atom_eV": float(energy)}
        if not converged:
            warnings.append(f"pure {element} reference did not converge")
    from ase.build import bulk
    n = inputs["supercell"]
    atoms = bulk(inputs["host"], "fcc", a=references[inputs["host"]]["lattice_constant_A"], cubic=True)
    atoms = atoms.repeat((n, n, n))
    rng = np.random.default_rng(inputs["seed"])
    order = list(rng.permutation(len(atoms)))
    for element, count in inputs["substitutions"].items():
        for _ in range(count):
            atoms[int(order.pop())].symbol = element
    if inputs["vacancies"]:
        del atoms[[int(order.pop()) for _ in range(inputs["vacancies"])]]
    atoms.calc = EMT()
    atoms, converged, used = _relaxed(atoms, inputs["relax_cell"], fmax, steps)
    if not converged:
        warnings.append(f"structure relaxation stopped after {used} steps above fmax={fmax} eV/A")
    energy = float(atoms.get_potential_energy())
    count = len(atoms)
    values = {"lattice_constant_A": float(np.cbrt(atoms.get_volume() / n ** 3)),
              "host_lattice_constant_A": references[inputs["host"]]["lattice_constant_A"],
              "energy_per_atom_eV": energy / count}
    symbols = atoms.get_chemical_symbols()
    if inputs["substitutions"]:
        reference = sum(references[s]["energy_per_atom_eV"] for s in symbols)
        values["mixing_energy_eV_per_atom"] = (energy - reference) / count
    if inputs["vacancies"] and not inputs["substitutions"]:
        values["vacancy_formation_energy_eV"] = (
            (energy - count * references[inputs["host"]]["energy_per_atom_eV"]) / inputs["vacancies"])
        if not inputs["relax_cell"]:
            warnings.append("vacancy energy at fixed cell (constant volume)")
    elif inputs["vacancies"]:
        warnings.append("vacancy_formation_energy_eV is reported only for a pure host")
    # Equation of state of the final structure, scaling the cell with fractional positions fixed.
    cell, volumes, energies = atoms.get_cell(), [], []
    for scale in np.linspace(0.97, 1.03, 7):
        trial = atoms.copy()
        trial.calc = EMT()
        trial.set_cell(cell * scale, scale_atoms=True)
        volumes.append(trial.get_volume())
        energies.append(trial.get_potential_energy())
    eos = EquationOfState(volumes, energies)
    _, _, modulus = eos.fit()
    values["bulk_modulus_GPa"] = float(modulus / GPa)
    if inputs["substitutions"] or inputs["vacancies"]:
        warnings.append("one random arrangement of solutes/vacancies (seed); other arrangements give other energies")
    write(workdir / "relaxed.extxyz", atoms)
    return {"values": values, "warnings": warnings,
            "details": {"atoms": count, "composition": {s: symbols.count(s) for s in sorted(set(symbols))},
                        "pure_references": references, "relaxation_steps": used,
                        "eos_volumes_A3": volumes, "eos_energies_eV": energies},
            "artifacts": ["relaxed.extxyz"]}


ROUTE = Route(
    id="condensed.energetics.ase_emt_relax",
    title="fcc metal relaxation with EMT",
    summary="Relaxed lattice, mixing energy of substitutional solutes, vacancy formation energy and bulk modulus "
            "of fcc metals with the effective-medium potential",
    tier="T2",
    disciplines=("materials", "physics"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Effective-medium theory (EMT) as implemented in ASE: a semi-empirical many-body potential fitted to fcc "
        "metals",
        "Periodic supercell at 0 K without zero-point or thermal effects; one random solute/vacancy arrangement",
        "Bulk modulus from an equation of state with fractional positions held fixed while the cell is scaled",
    ),
    applicability=("Al, Cu, Ag, Au, Ni, Pd, Pt and their substitutional alloys on an fcc lattice. Not for "
                   "non-fcc phases, compounds, surfaces with adsorbates, or elements outside this list."),
    uncertainty=("EMT is a qualitative-to-semiquantitative model: trends among these metals are more reliable than "
                 "absolute values. Small supercells add finite-size error to defect energies."),
    references=(
        "K. W. Jacobsen, P. Stoltze, J. K. Norskov, Surf. Sci. 366, 394 (1996): EMT for metals",
        "A. H. Larsen et al., J. Phys.: Condens. Matter 29, 273002 (2017): ASE",
    ),
    example={"host": "Cu", "supercell": 2, "substitutions": {"Ni": 4}},
    run=run, check=check, estimate_s=estimate_s, requires=("ase", "numpy", "scipy"),
)
