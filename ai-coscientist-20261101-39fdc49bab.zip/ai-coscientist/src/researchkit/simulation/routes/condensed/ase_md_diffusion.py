"""Self-diffusion coefficient from the mean-squared displacement of a classical MD run."""

from researchkit.simulation.route import Route

METALS = ["Al", "Cu", "Ag", "Au", "Ni", "Pd", "Pt"]

INPUTS = {
    "type": "object", "additionalProperties": False, "required": ["potential", "temperature_K"],
    "properties": {
        "potential": {"type": "string", "enum": ["lj", "emt"],
                      "description": "lj: one-component Lennard-Jones fluid; emt: an fcc metal with EMT"},
        "epsilon_eV": {"type": "number", "exclusiveMinimum": 0, "description": "lj well depth"},
        "sigma_A": {"type": "number", "exclusiveMinimum": 0, "description": "lj diameter"},
        "mass_amu": {"type": "number", "exclusiveMinimum": 0, "description": "lj particle mass"},
        "cutoff_sigma": {"type": "number", "minimum": 2.0, "maximum": 5.0, "default": 2.5},
        "element": {"type": "string", "enum": METALS, "description": "emt metal"},
        "density_g_cm3": {"type": "number", "exclusiveMinimum": 0,
                          "description": "Mass density of the simulated state (required for lj; emt default: the "
                                         "0 K EMT crystal density)"},
        "temperature_K": {"type": "number", "exclusiveMinimum": 0},
        "premelt_temperature_K": {"type": "number", "exclusiveMinimum": 0,
                                  "description": "Optional: run the first half of equilibration at this higher "
                                                 "temperature so the starting crystal melts, then cool to "
                                                 "temperature_K"},
        "cells": {"type": "integer", "minimum": 2, "maximum": 8, "default": 3,
                  "description": "Starting fcc lattice of 4 x cells^3 atoms"},
        "timestep_fs": {"type": "number", "exclusiveMinimum": 0, "maximum": 20, "default": 2.0},
        "equilibration_steps": {"type": "integer", "minimum": 100, "maximum": 200000, "default": 3000},
        "production_steps": {"type": "integer", "minimum": 500, "maximum": 500000, "default": 6000},
        "sample_every": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 10},
        "friction_per_fs": {"type": "number", "exclusiveMinimum": 0, "default": 0.01,
                            "description": "Langevin friction during equilibration only"},
        "seed": {"type": "integer", "minimum": 0, "default": 0},
    },
}

OUTPUTS = {
    "diffusion_coefficient_m2_s": {"unit": "m^2/s", "description": "Einstein-relation slope/6 of the mean-squared "
                                                                   "displacement"},
    "diffusion_block_spread_m2_s": {"unit": "m^2/s", "description": "Standard error from three production blocks"},
    "mean_temperature_K": {"unit": "K", "description": "Mean kinetic temperature during production (NVE)"},
    "energy_drift_eV_per_atom": {"unit": "eV", "description": "Change of total energy per atom over production"},
    "msd_fit_r2": {"unit": "1", "description": "Coefficient of determination of the linear MSD fit"},
    "atoms": {"unit": "1", "description": "Number of atoms simulated"},
}


def check(inputs):
    if inputs["potential"] == "lj":
        missing = [k for k in ("epsilon_eV", "sigma_A", "mass_amu", "density_g_cm3") if k not in inputs]
        return [f"lj needs {', '.join(missing)}"] if missing else []
    return [] if "element" in inputs else ["emt needs element"]


def estimate_s(inputs):
    atoms = 4 * inputs["cells"] ** 3
    per_step = atoms * (5e-5 if inputs["potential"] == "lj" else 7.5e-5)  # measured with ASE 3.29
    frames = inputs["production_steps"] // inputs["sample_every"]
    return 4.0 + per_step * (inputs["equilibration_steps"] + inputs["production_steps"]) + 2e-8 * atoms * frames ** 2


def _atoms(inputs):
    import numpy as np
    from ase.build import bulk
    from ase.calculators.emt import EMT
    from ase.calculators.lj import LennardJones
    from ase.units import _amu
    n = inputs["cells"]
    if inputs["potential"] == "lj":
        mass = inputs["mass_amu"]
        count = 4 * n ** 3
        volume_cm3 = count * mass * _amu * 1000 / inputs["density_g_cm3"]
        a = (volume_cm3 * 1e24) ** (1 / 3) / n
        atoms = bulk("Ar", "fcc", a=a, cubic=True).repeat((n, n, n))
        atoms.set_masses(np.full(len(atoms), mass))
        sigma = inputs["sigma_A"]
        atoms.calc = LennardJones(sigma=sigma, epsilon=inputs["epsilon_eV"], rc=inputs["cutoff_sigma"] * sigma,
                                  smooth=True)
        return atoms
    atoms = bulk(inputs["element"], "fcc", cubic=True).repeat((n, n, n))
    if "density_g_cm3" in inputs:
        current = atoms.get_masses().sum() * _amu * 1000 / (atoms.get_volume() * 1e-24)
        atoms.set_cell(atoms.get_cell() * (current / inputs["density_g_cm3"]) ** (1 / 3), scale_atoms=True)
    atoms.calc = EMT()
    return atoms


def run(inputs, workdir):
    import numpy as np
    from ase import units
    from ase.md.langevin import Langevin
    from ase.md.velocitydistribution import MaxwellBoltzmannDistribution, Stationary
    from ase.md.verlet import VelocityVerlet

    atoms = _atoms(inputs)
    rng = np.random.default_rng(inputs["seed"])
    MaxwellBoltzmannDistribution(atoms, temperature_K=inputs["temperature_K"], rng=rng)
    Stationary(atoms)
    dt = inputs["timestep_fs"] * units.fs
    friction = inputs["friction_per_fs"] / units.fs
    stages = [(inputs["temperature_K"], inputs["equilibration_steps"])]
    if "premelt_temperature_K" in inputs:
        half = inputs["equilibration_steps"] // 2
        stages = [(inputs["premelt_temperature_K"], half), (inputs["temperature_K"], inputs["equilibration_steps"] - half)]
    for temperature, count in stages:
        Langevin(atoms, dt, temperature_K=temperature, friction=friction, fixcm=False, rng=rng).run(count)
    Stationary(atoms)
    lengths = atoms.cell.lengths()
    positions, temperatures = [atoms.get_positions().copy()], [atoms.get_temperature()]
    start_energy = atoms.get_total_energy()
    dynamics = VelocityVerlet(atoms, dt)
    every = inputs["sample_every"]
    for _ in range(inputs["production_steps"] // every):
        dynamics.run(every)
        positions.append(atoms.get_positions().copy())
        temperatures.append(atoms.get_temperature())
    drift = (atoms.get_total_energy() - start_energy) / len(atoms)
    # Unwrap with the minimum image between samples, then remove centre-of-mass motion.
    steps = np.diff(np.array(positions), axis=0)
    steps -= lengths * np.round(steps / lengths)
    path = np.concatenate([np.zeros((1, *steps.shape[1:])), np.cumsum(steps, axis=0)])
    masses = atoms.get_masses()
    path -= (path * masses[None, :, None]).sum(axis=1, keepdims=True) / masses.sum()
    sample_dt_ps = inputs["timestep_fs"] * every / 1000.0
    frames = len(path)

    def msd_curve(segment):
        lags = np.arange(1, len(segment) // 2)
        return lags, np.array([np.mean(np.sum((segment[k:] - segment[:-k]) ** 2, axis=2)) for k in lags])

    def slope(segment):
        lags, msd = msd_curve(segment)
        t = lags * sample_dt_ps
        window = (lags >= max(1, len(segment) // 10))
        fit = np.polyfit(t[window], msd[window], 1)
        predicted = np.polyval(fit, t[window])
        r2 = 1 - np.sum((msd[window] - predicted) ** 2) / np.sum((msd[window] - msd[window].mean()) ** 2)
        return fit[0], r2, t, msd

    rate, r2, t, msd = slope(path)
    to_si = 1e-20 / 1e-12  # A^2/ps -> m^2/s
    blocks = [slope(block)[0] for block in np.array_split(path, 3) if len(block) > 8]
    spread = float(np.std(blocks, ddof=1) / np.sqrt(len(blocks)) * to_si / 6) if len(blocks) > 1 else None
    warnings = []
    window = t >= t[max(0, len(t) // 5 - 1)]
    exponent = float(np.polyfit(np.log(t[window]), np.log(np.maximum(msd[window], 1e-12)), 1)[0])
    if exponent < 0.85:
        warnings.append(f"MSD grows as t^{exponent:.2f} over the fitted lags, slower than diffusive (t^1): the "
                        "state looks solid or glassy, or the run is too short; D is not a diffusion coefficient here")
    mean_temperature = float(np.mean(temperatures[1:]))
    if abs(mean_temperature - inputs["temperature_K"]) > 0.05 * inputs["temperature_K"]:
        warnings.append(f"production ran at {mean_temperature:.1f} K, not {inputs['temperature_K']:g} K (NVE after "
                        "equilibration); lengthen equilibration_steps if the difference matters")
    if r2 < 0.98:
        warnings.append(f"MSD is not linear over the fitted lags (R^2 = {r2:.3f}); D is unreliable")
    warnings.append(f"finite box of {len(atoms)} atoms: periodic images slow diffusion (no Yeh-Hummer "
                    "correction applied)")
    _artifacts(workdir, t, msd)
    return {
        "values": {"diffusion_coefficient_m2_s": float(rate * to_si / 6), "diffusion_block_spread_m2_s": spread,
                   "mean_temperature_K": mean_temperature,
                   "energy_drift_eV_per_atom": float(drift), "msd_fit_r2": float(r2), "atoms": len(atoms)},
        "warnings": warnings,
        "details": {"diffusion_coefficient_A2_ps": float(rate / 6), "msd_loglog_exponent": exponent,
                    "msd_at_longest_lag_A2": float(msd[-1]), "temperature_std_K": float(np.std(temperatures)),
                    "production_ps": float((frames - 1) * sample_dt_ps), "box_A": [float(x) for x in lengths]},
        "artifacts": ["msd.csv", "msd.png"],
    }


def _artifacts(workdir, t, msd):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    (workdir / "msd.csv").write_text("lag_ps,msd_A2\n" + "".join(f"{a:.5f},{b:.6f}\n" for a, b in zip(t, msd)),
                                     encoding="utf-8")
    figure, axis = plt.subplots(figsize=(4.5, 3.2))
    axis.plot(t, msd)
    axis.set_xlabel("lag (ps)")
    axis.set_ylabel("MSD (A^2)")
    figure.tight_layout()
    figure.savefig(workdir / "msd.png", dpi=110)
    plt.close(figure)


ROUTE = Route(
    id="condensed.transport.ase_md_diffusion",
    title="Self-diffusion from classical MD",
    summary="Langevin equilibration then NVE molecular dynamics of a Lennard-Jones fluid or an EMT metal; "
            "self-diffusion coefficient from the mean-squared displacement",
    tier="T2",
    disciplines=("materials", "physics", "chemistry"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Classical dynamics with a pair (Lennard-Jones, smoothed cutoff) or EMT potential; no quantum effects",
        "Fixed volume set by the given density; Langevin thermostat only during equilibration, NVE production",
        "Einstein relation D = MSD slope / 6 fitted over lags from a tenth to a half of the production time",
    ),
    applicability=("Simple liquids described by one Lennard-Jones particle type, or fcc metals with EMT above "
                   "their melting point (solids show no diffusive regime at MD time scales). Not for molecular "
                   "liquids, polymers or ions."),
    uncertainty=("Statistical error from three production blocks is reported; finite-size and potential errors "
                 "are not included and can exceed it."),
    references=(
        "A. Rahman, Phys. Rev. 136, A405 (1964): liquid argon MD",
        "I.-C. Yeh, G. Hummer, J. Phys. Chem. B 108, 15873 (2004): finite-size effect on diffusion",
        "A. H. Larsen et al., J. Phys.: Condens. Matter 29, 273002 (2017): ASE",
    ),
    example={"potential": "lj", "epsilon_eV": 0.0103, "sigma_A": 3.4, "mass_amu": 39.95, "density_g_cm3": 1.4,
             "temperature_K": 90, "premelt_temperature_K": 300, "cells": 3},
    run=run, check=check, estimate_s=estimate_s, requires=("ase", "numpy", "matplotlib"),
)
