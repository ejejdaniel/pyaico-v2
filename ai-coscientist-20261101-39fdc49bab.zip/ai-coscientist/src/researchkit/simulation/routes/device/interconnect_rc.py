"""Resistance, capacitance and delay of an on-chip interconnect line from its geometry."""

from researchkit.simulation.route import Route

LADDER_SEGMENTS = 400

INPUTS = {
    "type": "object", "additionalProperties": False,
    "required": ["width_nm", "thickness_nm", "dielectric_height_nm", "length_um", "resistivity_ohm_m",
                 "relative_permittivity"],
    "properties": {
        "width_nm": {"type": "number", "exclusiveMinimum": 0, "description": "Line width W"},
        "thickness_nm": {"type": "number", "exclusiveMinimum": 0, "description": "Line thickness T"},
        "dielectric_height_nm": {"type": "number", "exclusiveMinimum": 0,
                                 "description": "Dielectric thickness H between the line and the ground plane below"},
        "spacing_nm": {"type": "number", "exclusiveMinimum": 0,
                       "description": "Edge-to-edge spacing S to each neighbouring line (required if neighbors > 0)"},
        "neighbors": {"type": "integer", "enum": [0, 1, 2], "default": 2,
                      "description": "Parallel neighbouring lines at spacing S"},
        "miller_factor": {"type": "number", "minimum": 0, "maximum": 2, "default": 1.0,
                          "description": "Coupling multiplier: 1 quiet neighbours, 0 switching the same way, "
                                         "2 switching the opposite way"},
        "length_um": {"type": "number", "exclusiveMinimum": 0},
        "resistivity_ohm_m": {"type": "number", "exclusiveMinimum": 0,
                              "description": "Conductor resistivity as used (bulk or a size-corrected value you cite)"},
        "barrier_nm": {"type": "number", "minimum": 0, "default": 0,
                       "description": "Non-conducting liner on the bottom and both sides; conducting area is "
                                      "(W - 2b)(T - b)"},
        "relative_permittivity": {"type": "number", "minimum": 1, "description": "Dielectric constant k"},
        "driver_resistance_ohm": {"type": "number", "minimum": 0, "default": 0},
        "load_capacitance_F": {"type": "number", "minimum": 0, "default": 0},
    },
}

OUTPUTS = {
    "resistance_ohm": {"unit": "ohm", "description": "Line resistance R = rho L / conducting area"},
    "ground_capacitance_F": {"unit": "F", "description": "Line-to-ground-plane capacitance (Sakurai-Tamaru)"},
    "coupling_capacitance_F": {"unit": "F", "description": "Capacitance to one neighbour (Sakurai)"},
    "total_capacitance_F": {"unit": "F", "description": "Ground plus neighbours x miller_factor x coupling"},
    "coupling_fraction": {"unit": "1", "description": "Share of the total capacitance that couples to neighbours"},
    "rc_s": {"unit": "s", "description": "R times total capacitance"},
    "elmore_delay_s": {"unit": "s", "description": "Elmore delay at the far end with driver and load"},
    "t50_s": {"unit": "s", "description": "50% delay at the far end, solved numerically on a fine RC ladder"},
    "rise_10_90_s": {"unit": "s", "description": "10-90% rise time at the far end"},
}

GROUND_RANGE = (0.3, 30.0)  # W/H and T/H range of the ground formula (Sakurai-Tamaru 1983)


def check(inputs):
    found = []
    w, t, h = inputs["width_nm"], inputs["thickness_nm"], inputs["dielectric_height_nm"]
    for label, ratio in (("W/H", w / h), ("T/H", t / h)):
        if not GROUND_RANGE[0] <= ratio <= GROUND_RANGE[1]:
            found.append(f"{label} = {ratio:.3g} is outside {GROUND_RANGE[0]}-{GROUND_RANGE[1]}, the range of the "
                         "ground-capacitance formula")
    if inputs["neighbors"] and "spacing_nm" not in inputs:
        found.append("spacing_nm is required when neighbors > 0")
    b = inputs["barrier_nm"]
    if w - 2 * b <= 0 or t - b <= 0:
        found.append("the barrier leaves no conducting area")
    return found


def estimate_s(inputs):
    return 6.0


def run(inputs, workdir):
    from scipy.constants import epsilon_0
    from researchkit.simulation.models import rc
    nm, um = 1e-9, 1e-6
    w, t, h = inputs["width_nm"], inputs["thickness_nm"], inputs["dielectric_height_nm"]
    length = inputs["length_um"] * um
    epsilon = epsilon_0 * inputs["relative_permittivity"]
    b = inputs["barrier_nm"]
    area = (w - 2 * b) * nm * (t - b) * nm
    resistance = inputs["resistivity_ohm_m"] * length / area
    ground = epsilon * (1.15 * (w / h) + 2.80 * (t / h) ** 0.222) * length
    warnings = []
    coupling = 0.0
    if inputs["neighbors"]:
        s = inputs["spacing_nm"]
        coupling = (epsilon * (0.03 * (w / h) + 0.83 * (t / h) - 0.07 * (t / h) ** 0.222)
                    * (s / h) ** -1.34 * length)
        if s < h:
            warnings.append(f"S/H = {s / h:.2g}: for closely spaced lines this coupling formula is reported to "
                            "underestimate the coupling; treat coupling_capacitance_F as a lower estimate")
    total = ground + inputs["neighbors"] * inputs["miller_factor"] * coupling
    elmore, t50, rise = rc.far_end_delays(rc.ladder(resistance, total, LADDER_SEGMENTS,
                                                    inputs["driver_resistance_ohm"], inputs["load_capacitance_F"]))
    coarse = rc.far_end_delays(rc.ladder(resistance, total, LADDER_SEGMENTS // 2,
                                         inputs["driver_resistance_ohm"], inputs["load_capacitance_F"]))[1]
    if w < 100:
        warnings.append("resistivity is used as given; at widths near the electron mean free path, surface and "
                        "grain-boundary scattering raise it above the bulk value")
    return {
        "values": {"resistance_ohm": resistance, "ground_capacitance_F": ground,
                   "coupling_capacitance_F": coupling, "total_capacitance_F": total,
                   "coupling_fraction": (total - ground) / total,
                   "rc_s": resistance * total, "elmore_delay_s": elmore, "t50_s": t50, "rise_10_90_s": rise},
        "warnings": warnings,
        "details": {"resistance_per_m_ohm": resistance / length, "capacitance_per_m_F": total / length,
                    "ratios": {"W/H": w / h, "T/H": t / h,
                               **({"S/H": inputs["spacing_nm"] / h} if inputs["neighbors"] else {})},
                    "ladder_segments": LADDER_SEGMENTS,
                    "ladder_discretization_change_s": t50 - coarse},
    }


ROUTE = Route(
    id="device.electrical.interconnect_rc",
    title="Interconnect line R, C and delay from geometry",
    summary="Resistance, ground and coupling capacitance (closed-form fits) and RC delay of an on-chip wire",
    tier="T1",
    disciplines=("semiconductor", "circuits"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Rectangular line over a ground plane with up to two parallel neighbours at equal spacing; uniform "
        "homogeneous dielectric",
        "Ground capacitance from the Sakurai-Tamaru fit; coupling capacitance from Sakurai's fit; neighbours' "
        "switching enters only through miller_factor",
        "Resistivity is uniform and as given (no size effect is added); no inductance or skin effect",
        "Delay is the linear step response of the distributed line with a resistive driver and a capacitive load",
    ),
    applicability=("0.3 <= W/H <= 30 and 0.3 <= T/H <= 30 (ground formula, about 6% error there); RC-dominated "
                   "on-chip wires. Closely spaced lines may have their coupling underestimated."),
    uncertainty=("Ground capacitance within about 6% inside its range; coupling capacitance is a cruder fit and "
                 "can be low for close spacing. Delay is exact for the stated RC model up to a ladder "
                 "discretization reported in details. Use a field solver (job route, later) when it matters."),
    references=(
        "T. Sakurai, K. Tamaru, IEEE Trans. Electron Devices 30(2), 183 (1983): ground capacitance fit",
        "T. Sakurai, IEEE Trans. Electron Devices 40(1), 118 (1993): coupling capacitance and delay",
    ),
    example={"width_nm": 50, "thickness_nm": 100, "dielectric_height_nm": 100, "spacing_nm": 100, "neighbors": 2,
             "length_um": 100, "resistivity_ohm_m": 2.2e-8, "relative_permittivity": 2.7,
             "driver_resistance_ohm": 1000, "load_capacitance_F": 1e-15},
    run=run, check=check, estimate_s=estimate_s, requires=("numpy", "scipy"),
)
