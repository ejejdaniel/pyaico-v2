"""Aerial image of a periodic line/space mask: thin-mask scalar Fourier optics with Abbe source integration."""

from researchkit.simulation.route import Route

ILLUMINATION = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "shape": {"type": "string", "enum": ["conventional", "annular", "dipole"], "default": "conventional",
                  "description": "dipole poles sit on the x axis, across the lines"},
        "sigma": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.5,
                  "description": "Conventional: outer partial coherence"},
        "sigma_inner": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.5},
        "sigma_outer": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.8},
        "pole_center": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.7},
        "pole_radius": {"type": "number", "exclusiveMinimum": 0, "maximum": 1, "default": 0.2},
        "grid": {"type": "integer", "minimum": 5, "maximum": 151, "default": 61,
                 "description": "Source points per axis over the unit pupil"},
    },
}

INPUTS = {
    "type": "object", "additionalProperties": False,
    "required": ["wavelength_nm", "numerical_aperture", "pitch_nm", "feature_nm"],
    "properties": {
        "wavelength_nm": {"type": "number", "exclusiveMinimum": 0},
        "numerical_aperture": {"type": "number", "exclusiveMinimum": 0},
        "medium_index": {"type": "number", "minimum": 1, "default": 1.0,
                         "description": "Image-space refractive index (above 1 for immersion)"},
        "pitch_nm": {"type": "number", "exclusiveMinimum": 0, "description": "Period at wafer scale"},
        "feature_nm": {"type": "number", "exclusiveMinimum": 0,
                       "description": "Nominal width of the feature at wafer scale (the target CD)"},
        "feature_type": {"type": "string", "enum": ["line", "space"], "default": "line",
                         "description": "line: dark feature in a bright field; space: bright opening in a dark field"},
        "mask": {"type": "string", "enum": ["binary", "attenuated_psm"], "default": "binary"},
        "psm_transmission": {"type": "number", "exclusiveMinimum": 0, "maximum": 1, "default": 0.06,
                             "description": "Intensity transmission of the attenuating absorber"},
        "psm_phase_deg": {"type": "number", "default": 180},
        "illumination": {**ILLUMINATION, "default": {}},
        "defocus_nm": {"type": "array", "items": {"type": "number"}, "minItems": 1, "maxItems": 41,
                       "default": [0]},
        "threshold": {"type": "number", "exclusiveMinimum": 0,
                      "description": "Resist threshold intensity (open frame = 1); default: the intensity at the "
                                     "nominal edge at the first defocus (dose to size)"},
        "reduction": {"type": "number", "minimum": 1, "default": 4,
                      "description": "Mask-to-wafer reduction, used only to judge thin-mask validity"},
        "samples_per_pitch": {"type": "integer", "minimum": 64, "maximum": 4096, "default": 512},
    },
}

OUTPUTS = {
    "image_contrast": {"unit": "1", "description": "(Imax - Imin)/(Imax + Imin) per defocus"},
    "nils": {"unit": "1", "description": "Normalized image log slope at the nominal edge, feature_nm x dlnI/dx, "
                                         "per defocus"},
    "intensity_at_nominal_edge": {"unit": "open-frame intensity", "description": "Per defocus"},
    "threshold_intensity": {"unit": "open-frame intensity", "description": "Threshold used for CD"},
    "cd_nm": {"unit": "nm", "description": "Printed feature width at the threshold per defocus (null if it does "
                                           "not print or merges)"},
    "orders_captured": {"unit": "1", "description": "Mean number of diffraction orders inside the pupil per "
                                                    "source point"},
}


def _source(illumination):
    import numpy as np
    n = illumination["grid"]
    axis = np.linspace(-1.0, 1.0, n)
    sx, sy = np.meshgrid(axis, axis)
    r = np.hypot(sx, sy)
    shape = illumination["shape"]
    if shape == "conventional":
        inside = r <= illumination["sigma"] + 1e-12
    elif shape == "annular":
        inside = (r >= illumination["sigma_inner"] - 1e-12) & (r <= illumination["sigma_outer"] + 1e-12)
    else:
        c, a = illumination["pole_center"], illumination["pole_radius"]
        inside = (np.hypot(sx - c, sy) <= a + 1e-12) | (np.hypot(sx + c, sy) <= a + 1e-12)
    inside &= r <= 1.0 + 1e-12
    if not inside.any():  # a coherent point source
        return np.array([0.0]), np.array([0.0])
    return sx[inside], sy[inside]


def check(inputs):
    found = []
    if inputs["numerical_aperture"] > inputs["medium_index"]:
        found.append("numerical_aperture cannot exceed medium_index")
    if inputs["feature_nm"] >= inputs["pitch_nm"]:
        found.append("feature_nm must be smaller than pitch_nm")
    ill = inputs["illumination"]
    if ill["shape"] == "annular" and ill["sigma_inner"] >= ill["sigma_outer"]:
        found.append("annular illumination needs sigma_inner < sigma_outer")
    if ill["shape"] == "dipole" and ill["pole_center"] + ill["pole_radius"] > 1.0 + 1e-9:
        found.append("dipole poles must lie inside the pupil (pole_center + pole_radius <= 1)")
    return found


def estimate_s(inputs):
    grid = inputs["illumination"]["grid"]
    return 2.0 + 2e-8 * grid * grid * inputs["samples_per_pitch"] * 40 * len(inputs["defocus_nm"])


def run(inputs, workdir):
    import numpy as np
    lam, na, n_m = inputs["wavelength_nm"], inputs["numerical_aperture"], inputs["medium_index"]
    p, w = inputs["pitch_nm"], inputs["feature_nm"]
    amplitude = np.sqrt(inputs["psm_transmission"]) * np.exp(1j * np.deg2rad(inputs["psm_phase_deg"]))
    dark = amplitude if inputs["mask"] == "attenuated_psm" else 0.0
    background, feature = (1.0, dark) if inputs["feature_type"] == "line" else (dark, 1.0)
    sx, sy = _source(inputs["illumination"])
    cutoff = na / lam
    reach = int(np.floor((1.0 + float(np.max(np.hypot(sx, sy)))) * cutoff * p)) + 1
    orders = np.arange(-reach, reach + 1)
    coefficients = (feature - background) * (w / p) * np.sinc(orders * w / p) + background * (orders == 0)
    fx = orders[None, :] / p + sx[:, None] * cutoff
    fy = np.broadcast_to(sy[:, None] * cutoff, fx.shape)
    passes = fx ** 2 + fy ** 2 <= cutoff ** 2 * (1 + 1e-12)
    kz = np.sqrt(np.maximum((n_m / lam) ** 2 - fx ** 2 - fy ** 2, 0.0))
    xs = np.linspace(-p / 2, p / 2, inputs["samples_per_pitch"], endpoint=False)
    phase = np.exp(2j * np.pi * orders[:, None] * xs[None, :] / p)
    edge = np.array([w / 2])

    def image(z, at):
        pupil = passes * np.exp(2j * np.pi * z * (kz - n_m / lam))
        spectrum = coefficients[None, :] * pupil
        basis = np.exp(2j * np.pi * orders[:, None] * at[None, :] / p)
        field = spectrum @ basis
        slope = spectrum @ (basis * (2j * np.pi * orders[:, None] / p))
        intensity = np.mean(np.abs(field) ** 2, axis=0)
        derivative = np.mean(2 * np.real(np.conj(field) * slope), axis=0)
        return intensity, derivative

    rows, contrast, nils, at_edge, cds = [], [], [], [], []
    first_edge = None
    for z in inputs["defocus_nm"]:
        intensity, _ = image(z, xs)
        i_edge, d_edge = image(z, edge)
        rows.append(intensity)
        contrast.append(float((intensity.max() - intensity.min()) / (intensity.max() + intensity.min())))
        at_edge.append(float(i_edge[0]))
        nils.append(float(w * abs(d_edge[0]) / i_edge[0]) if i_edge[0] > 0 else None)
        if first_edge is None:
            first_edge = float(i_edge[0])
    threshold = inputs.get("threshold", first_edge)
    half = np.linspace(0.0, p / 2, 4 * inputs["samples_per_pitch"] + 1)
    for z in inputs["defocus_nm"]:
        intensity, _ = image(z, half)
        printed = intensity >= threshold if inputs["feature_type"] == "line" else intensity <= threshold
        # line: the dark feature ends where light reaches the threshold; space: where it falls below it
        if printed[0]:
            cds.append(None)
            continue
        hits = np.flatnonzero(printed)
        if hits.size == 0:
            cds.append(None)
            continue
        k = hits[0]
        x0, x1, i0, i1 = half[k - 1], half[k], intensity[k - 1], intensity[k]
        cds.append(float(2 * (x0 + (threshold - i0) * (x1 - x0) / (i1 - i0))))
    warnings = []
    captured = passes.sum(axis=1)
    if np.all(captured <= 1):
        warnings.append("no source point passes more than one diffraction order: the pitch is below the "
                        "resolution limit for this wavelength, NA and illumination, so there is no image modulation")
    if na / n_m >= 0.6:
        warnings.append(f"NA/n = {na / n_m:.2f}: scalar imaging ignores polarization; vector effects grow with NA "
                        "(the 0.6 warning level is a heuristic)")
    mask_feature = w * inputs["reduction"]
    if lam < 20 or mask_feature < 5 * lam:
        warnings.append(f"mask-scale feature {mask_feature:.0f} nm vs wavelength {lam:g} nm: thin-mask (Kirchhoff) "
                        "results ignore absorber topography (shadowing, phase and best-focus shifts); for EUV or "
                        "features within a few wavelengths treat them as qualitative (3D mask simulation is a "
                        "later job route)")
    if any(cd is None for cd in cds):
        warnings.append("at some defocus the feature does not print at this threshold (cd_nm null)")
    _artifacts(workdir, xs, rows, inputs["defocus_nm"], threshold)
    return {
        "values": {"image_contrast": contrast, "nils": nils, "intensity_at_nominal_edge": at_edge,
                   "threshold_intensity": float(threshold), "cd_nm": cds,
                   "orders_captured": float(captured.mean())},
        "warnings": warnings,
        "details": {"defocus_nm": list(inputs["defocus_nm"]), "source_points": int(sx.size),
                    "orders_considered": int(orders.size), "k1": float(w * na / lam),
                    "half_pitch_k1": float(p / 2 * na / lam)},
        "artifacts": ["aerial_image.csv", "aerial_image.png"],
    }


def _artifacts(workdir, xs, rows, defocus, threshold):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    header = "x_nm," + ",".join(f"I_defocus_{z:g}nm" for z in defocus)
    lines = [header] + [",".join([f"{x:.4f}", *(f"{row[i]:.6f}" for row in rows)]) for i, x in enumerate(xs)]
    (workdir / "aerial_image.csv").write_text("\n".join(lines) + "\n", encoding="utf-8")
    figure, axis = plt.subplots(figsize=(6, 3.5))
    for z, row in zip(defocus, rows):
        axis.plot(xs, row, label=f"defocus {z:g} nm")
    axis.axhline(threshold, color="grey", linestyle="--", linewidth=0.8, label="threshold")
    axis.set_xlabel("x (nm, wafer scale)")
    axis.set_ylabel("intensity (open frame = 1)")
    axis.legend(fontsize=7)
    figure.tight_layout()
    figure.savefig(workdir / "aerial_image.png", dpi=120)
    plt.close(figure)


ROUTE = Route(
    id="device.optics.thin_mask_aerial_image",
    title="Aerial image of a line/space mask (thin mask, Abbe)",
    summary="Partially coherent aerial image of periodic lines or spaces: contrast, NILS, dose-to-size threshold "
            "and CD through focus, with image files",
    tier="T2",
    disciplines=("lithography", "optics", "semiconductor"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Kirchhoff thin mask: the mask is a transmission function with no thickness (no 3D absorber effects)",
        "Scalar Fourier optics: no polarization or vector high-NA effects; aberration-free pupil apart from defocus",
        "Abbe integration over a uniform sampled source; one-dimensional periodic pattern",
        "Constant-threshold resist: the printed edge is where the aerial image crosses the threshold (no resist "
        "blur, diffusion or development model)",
    ),
    applicability=("Periodic lines/spaces with features several wavelengths wide at mask scale, moderate NA. "
                   "For EUV or high-NA imaging the trends are indicative only; the result warns when this applies."),
    uncertainty=("Numerically converged for the model when the source grid and samples are fine enough (raise "
                 "illumination.grid to check). Model error from thin-mask, scalar and threshold assumptions can "
                 "dominate near the resolution limit."),
    references=(
        "H. H. Hopkins, Proc. R. Soc. A 217, 408 (1953): partially coherent imaging",
        "C. A. Mack, Fundamental Principles of Optical Lithography (Wiley, 2007): Abbe imaging, NILS",
    ),
    example={"wavelength_nm": 193, "numerical_aperture": 0.75, "pitch_nm": 260, "feature_nm": 130,
             "illumination": {"shape": "conventional", "sigma": 0.5}, "defocus_nm": [0, 100]},
    run=run, check=check, estimate_s=estimate_s, requires=("numpy", "matplotlib"),
)
