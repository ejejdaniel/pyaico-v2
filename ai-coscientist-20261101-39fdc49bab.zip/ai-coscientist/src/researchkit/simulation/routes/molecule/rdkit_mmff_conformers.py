"""Conformer search and MMFF94 energies of one molecule or ion."""

from researchkit.simulation.route import Route

MAX_HEAVY_ATOMS = 150

INPUTS = {
    "type": "object", "additionalProperties": False, "required": ["smiles"],
    "properties": {
        "smiles": {"type": "string", "minLength": 1, "description": "One molecule or ion (a single fragment)"},
        "n_conformers": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
        "variant": {"type": "string", "enum": ["MMFF94", "MMFF94s"], "default": "MMFF94"},
        "max_iterations": {"type": "integer", "minimum": 50, "maximum": 20000, "default": 2000},
        "prune_rms_A": {"type": "number", "minimum": 0, "default": 0.5,
                        "description": "Discard embedded conformers closer than this heavy-atom RMSD"},
        "energy_window_kcal_mol": {"type": "number", "exclusiveMinimum": 0, "default": 3.0,
                                   "description": "Count conformers within this window of the minimum"},
        "temperature_K": {"type": "number", "exclusiveMinimum": 0, "default": 298.15,
                          "description": "Temperature for Boltzmann populations"},
        "seed": {"type": "integer", "minimum": 0, "default": 42},
    },
}

OUTPUTS = {
    "min_energy_kcal_mol": {"unit": "kcal/mol", "description": "Lowest MMFF energy found (comparable only between "
                                                               "conformers of this same molecule)"},
    "conformers_converged": {"unit": "1", "description": "Optimized conformers that converged"},
    "conformers_within_window": {"unit": "1", "description": "Converged conformers within the energy window"},
    "boltzmann_mean_relative_energy_kcal_mol": {"unit": "kcal/mol",
                                                "description": "Population-weighted energy above the minimum"},
    "conformational_entropy_J_mol_K": {"unit": "J/(mol K)",
                                       "description": "-R sum p ln p over found conformers (flexibility index; "
                                                      "not a full entropy)"},
    "radius_of_gyration_A": {"unit": "angstrom", "description": "Heavy-atom radius of gyration of the lowest conformer"},
    "relative_energies_kcal_mol": {"unit": "kcal/mol", "description": "Converged conformer energies above the "
                                                                      "minimum, ascending"},
}


def _molecule(smiles):
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles)
    return mol


def check(inputs):
    from rdkit import Chem
    from rdkit.Chem import rdForceFieldHelpers
    mol = _molecule(inputs["smiles"])
    if mol is None:
        return ["RDKit cannot parse the SMILES"]
    found = []
    if len(Chem.GetMolFrags(mol)) != 1:
        found.append("give one fragment per run; energies of separate fragments are not comparable here")
    if mol.GetNumHeavyAtoms() > MAX_HEAVY_ATOMS:
        found.append(f"{mol.GetNumHeavyAtoms()} heavy atoms exceeds {MAX_HEAVY_ATOMS}")
    if not rdForceFieldHelpers.MMFFHasAllMoleculeParams(Chem.AddHs(mol)):
        found.append("MMFF94 has no parameters for some atom types in this structure")
    return found


def estimate_s(inputs):
    mol = _molecule(inputs["smiles"])
    heavy = mol.GetNumHeavyAtoms() if mol is not None else 30
    return 2.0 + inputs["n_conformers"] * (0.004 * heavy + 0.00008 * heavy ** 2)


def run(inputs, workdir):
    import math
    import numpy as np
    from rdkit import Chem
    from rdkit.Chem import AllChem, rdForceFieldHelpers, rdMolTransforms
    from scipy.constants import R, calorie

    mol = Chem.AddHs(_molecule(inputs["smiles"]))
    params = AllChem.ETKDGv3()
    params.randomSeed = inputs["seed"]
    params.pruneRmsThresh = inputs["prune_rms_A"]
    ids = list(AllChem.EmbedMultipleConfs(mol, numConfs=inputs["n_conformers"], params=params))
    if not ids:
        raise RuntimeError("no conformer could be embedded")
    results = rdForceFieldHelpers.MMFFOptimizeMoleculeConfs(
        mol, maxIters=inputs["max_iterations"], mmffVariant=inputs["variant"])
    energies = [(cid, energy) for cid, (not_converged, energy) in zip(ids, results) if not_converged == 0]
    warnings = []
    if len(energies) < len(ids):
        warnings.append(f"{len(ids) - len(energies)} of {len(ids)} conformers did not converge within "
                        f"{inputs['max_iterations']} iterations and are excluded")
    if not energies:
        raise RuntimeError("no conformer converged; raise max_iterations")
    energies.sort(key=lambda item: item[1])
    minimum = energies[0][1]
    relative = np.array([energy - minimum for _, energy in energies])
    kT = R * inputs["temperature_K"] / (1000 * calorie)  # kcal/mol
    weights = np.exp(-relative / kT)
    weights /= weights.sum()
    entropy = max(0.0, float(-R * sum(p * math.log(p) for p in weights if p > 0)))
    best = mol.GetConformer(energies[0][0])
    heavy = [atom.GetIdx() for atom in mol.GetAtoms() if atom.GetAtomicNum() > 1]
    coords = np.array([list(best.GetAtomPosition(i)) for i in heavy])
    gyration = float(np.sqrt(((coords - coords.mean(axis=0)) ** 2).sum(axis=1).mean()))
    charge = Chem.GetFormalCharge(mol)
    if charge:
        warnings.append(f"formal charge {charge:+d}: an isolated ion in vacuum; no counterion or solvent, so "
                        "electrostatics dominate the conformational preference more than in a film or solution")
    if len(energies) == inputs["n_conformers"] and relative[-1] < inputs["energy_window_kcal_mol"]:
        warnings.append("every requested conformer lies inside the window; the search may not have reached "
                        "the high-energy region; raise n_conformers")
    writer = Chem.SDWriter(str(workdir / "conformers.sdf"))
    for cid, energy in energies:
        mol.SetProp("MMFF_energy_kcal_mol", f"{energy:.6f}")
        mol.SetProp("relative_energy_kcal_mol", f"{energy - minimum:.6f}")
        writer.write(mol, confId=cid)
    writer.close()
    return {
        "values": {
            "min_energy_kcal_mol": minimum, "conformers_converged": len(energies),
            "conformers_within_window": int((relative <= inputs["energy_window_kcal_mol"]).sum()),
            "boltzmann_mean_relative_energy_kcal_mol": float((weights * relative).sum()),
            "conformational_entropy_J_mol_K": entropy, "radius_of_gyration_A": gyration,
            "relative_energies_kcal_mol": [float(x) for x in relative],
        },
        "warnings": warnings,
        "details": {"canonical_smiles": Chem.MolToSmiles(Chem.RemoveHs(mol)), "formal_charge": charge,
                    "atoms_with_hydrogens": mol.GetNumAtoms(), "embedded": len(ids),
                    "boltzmann_weights": [float(w) for w in weights]},
        "artifacts": ["conformers.sdf"],
    }


ROUTE = Route(
    id="molecule.energetics.rdkit_mmff_conformers",
    title="Conformer search with MMFF94 energies",
    summary="ETKDG conformer embedding and MMFF94 optimization of one molecule or ion: lowest energy, "
            "conformer spread, flexibility and size",
    tier="T2",
    disciplines=("chemistry", "materials", "polymer", "lithography"),
    inputs=INPUTS,
    outputs=OUTPUTS,
    assumptions=(
        "Classical MMFF94 force field in vacuum: no solvent, no counterion, no condensed-phase packing",
        "Conformers come from stochastic ETKDG embedding; the search is not exhaustive",
        "Populations use Boltzmann weights of potential energies only (no vibrational or entropic terms)",
    ),
    applicability=("Organic molecules and ions whose atom types MMFF94 parameterizes (checked before running), "
                   "up to 150 heavy atoms. Energies compare conformers of the same molecule; absolute MMFF energies "
                   "of different molecules are not comparable, and bond breaking or reactions are out of scope."),
    uncertainty=("Relative conformer energies are a classical force-field approximation and can differ from "
                 "quantum-chemical values; a different seed or more conformers can find a lower minimum."),
    references=(
        "T. A. Halgren, J. Comput. Chem. 17, 490 (1996): MMFF94",
        "S. Riniker, G. A. Landrum, J. Chem. Inf. Model. 55, 2562 (2015): ETKDG",
    ),
    example={"smiles": "OCCc1ccccc1", "n_conformers": 30},
    run=run, check=check, estimate_s=estimate_s, requires=("rdkit", "numpy", "scipy"),
)
