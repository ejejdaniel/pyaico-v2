"""Subprocess side of one route run.

Reads the request JSON named on the command line, runs the route and prints MARKER
followed by the JSON reply on stdout. Anything the route prints goes to stderr so it
cannot be mistaken for the result. Started with `python -I`, so the workspace on the
current directory cannot shadow framework modules. A task tool (simulation/task_tools.py)
is loaded here from its file, to read its declaration or to run it, and nowhere else.
"""

import contextlib
import json
import math
from pathlib import Path
import sys
import traceback

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

MARKER = "@@SIMULATION_RESULT@@"


def jsonable(value, problems, where="result"):
    """Plain JSON: numpy values become numbers or lists; NaN and infinity become null and are reported."""
    if hasattr(value, "tolist") and not isinstance(value, (str, bytes)):
        value = value.tolist()
    if isinstance(value, dict):
        return {str(key): jsonable(item, problems, f"{where}.{key}") for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(item, problems, f"{where}[{index}]") for index, item in enumerate(value)]
    if isinstance(value, float) and not math.isfinite(value):
        problems.append(f"{where} was {value}; reported as null")
        return None
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def task_route(file):
    """A task tool's ROUTE, loaded from its route.py; modules beside it import too (simulation/task_tools.py)."""
    import importlib.util
    from researchkit.simulation.route import Route

    path = Path(file).resolve()
    sys.path.insert(1, str(path.parent))
    sys.dont_write_bytecode = True  # no cache beside the tool's code (python -I ignores PYTHONDONTWRITEBYTECODE)
    spec = importlib.util.spec_from_file_location("task_tool_route", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    route = getattr(module, "ROUTE", None)
    if not isinstance(route, Route):
        raise TypeError("route.py must define ROUTE = Route(...), with Route from researchkit.simulation.route")
    return route


def main():
    request = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    with contextlib.redirect_stdout(sys.stderr):
        try:
            if "describe" in request:  # a task tool's declaration, read for mounting
                reply = {"ok": True, "manifest": task_route(request["describe"]).manifest()}
            elif request.get("file"):  # a task tool: its own check runs here, beside its code
                route = task_route(request["file"])
                problems = [str(item) for item in route.check(request["inputs"])]
                reply = ({"ok": False, "refused": "outside applicability: " + "; ".join(problems)} if problems else
                         {"ok": True, "result": route.run(request["inputs"], Path(request["workdir"]))})
            else:
                from researchkit.simulation import registry
                route = registry.get(request["route"])
                reply = {"ok": True, "result": route.run(request["inputs"], Path(request["workdir"]))}
        except Exception as error:
            reply = {"ok": False, "error": f"{type(error).__name__}: {error}",
                     "trace": traceback.format_exc()[-3000:]}
    problems = []
    reply = jsonable(reply, problems)
    if problems:
        reply["nonfinite"] = problems
    print(MARKER + json.dumps(reply, allow_nan=False), file=sys.__stdout__)


if __name__ == "__main__":
    main()
