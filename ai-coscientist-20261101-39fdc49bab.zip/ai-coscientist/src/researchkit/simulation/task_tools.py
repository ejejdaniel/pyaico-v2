"""Tools a task writes for itself: simulation routes kept in the workspace (stage C of
docs/design_meta_task_zones_20261030_zh-TW.md, under the skill and tool charter src/opencode/skill_charter.md).

A task tool is a route the working agent writes at .task/<top session>/tools/<name>/route.py, declaring
ROUTE = Route(id="task.<quantity>.<name>", ...) as the framework's routes do, with its known-answer tests
in tests.json beside it. Like the task's skills it lives as long as the session, through every round, and
a subagent shares it.

The framework never imports a task tool: it reads the declaration, runs the tests and runs the tool in a
time-limited subprocess (runner.py), so the tool's code cannot change the process that checks it.

Mounting (research_simulate action mount) copies the tool's files, checks the declaration against the
charter, runs every known-answer test on the copy and saves the outcome as a kind=task_tool record: the
files, their hash (the tool's version), the declaration and each test with its result. A run uses the
newest version mounted in this task, from that record's copy of the files, so an edit in the workspace
changes nothing until the tool is mounted again.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import uuid

from opencode import task_skills
from researchkit import records
from researchkit.simulation import registry
from researchkit.simulation.route import EXECUTORS, Route
from researchkit.simulation.taxonomy import TIERS

KIND = "task_tool"
NAME = re.compile(r"^[a-z][a-z0-9_]{0,39}$")
ID = re.compile(r"^task\.([a-z]+)\.([a-z][a-z0-9_]{0,39})$")
DECLARE_LIMIT_S = 60
MAX_FILES = 40
MAX_BYTES = 2_000_000
TESTS = "tests.json"
MOUNT = "mount.json"
TEST_SHAPE = ('tests.json is a list of known-answer tests: [{"name": "...", "input": {...the inputs...}, '
              '"expect": {"<output>": {"value": number or [numbers], "tolerance": absolute, or "relative": '
              'fraction}}, "source": "where the answer comes from: an analytical solution, a published '
              'example"}]')


def tools_dir(directory, root: str) -> Path:
    return Path(directory) / ".task" / root / "tools"


def _relative(path: Path, root_dir: Path) -> str:
    return path.relative_to(root_dir).as_posix() if path.is_relative_to(root_dir) else path.as_posix()


def tool_files(folder: Path) -> list[Path]:
    """The tool's files: everything in its folder except caches."""
    files = sorted(path for path in folder.rglob("*")
                   if path.is_file() and "__pycache__" not in path.parts and not path.is_symlink())
    if len(files) > MAX_FILES or sum(path.stat().st_size for path in files) > MAX_BYTES:
        raise ValueError(f"A task tool's folder holds at most {MAX_FILES} files and {MAX_BYTES} bytes; keep data "
                         "it reads elsewhere in the workspace and name it in a file input")
    return files


def version_of(folder: Path, files) -> str:
    """The hash of the tool's files, names and bytes: its version (skill charter article 2)."""
    digest = hashlib.sha256()
    for path in files:
        digest.update(path.relative_to(folder).as_posix().encode("utf-8") + b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return digest.hexdigest()


def _subprocess_only(inputs, workdir):
    raise RuntimeError("A task tool runs only in its own process")


def as_route(manifest: dict, file: Path, version: str) -> Route:
    """A Route the executor can run: the declaration read from the tool, its file and its version."""
    return Route(
        id=manifest["id"], title=manifest["title"], summary=manifest["summary"], tier=manifest["tier"],
        disciplines=tuple(manifest.get("disciplines") or ()), inputs=manifest["inputs"],
        outputs=manifest["outputs"], assumptions=tuple(manifest["assumptions"]),
        applicability=manifest["applicability"], uncertainty=manifest["uncertainty"],
        references=tuple(manifest.get("references") or ()), example=manifest.get("example") or {},
        run=_subprocess_only, requires=tuple(manifest.get("requires") or ()), executor="local", version=version,
        file_inputs=tuple(manifest.get("file_inputs") or ()), runs_user_code=True, file=str(file))


def declaration_problems(manifest: dict, name: str, rules: dict) -> list[str]:
    """What keeps a declaration from mounting; charter rules name their article."""
    found = []
    match = ID.match(str(manifest.get("id")))
    if not match:
        found.append(f"id {manifest.get('id')!r} is not task.<quantity>.<name>, lowercase "
                     "(skill and tool charter article 1)")
    elif match.group(2) != name:
        found.append(f"id {manifest['id']!r} must end with the tool's folder name {name!r} "
                     "(skill and tool charter article 1)")
    elif manifest["id"] in registry.load()[0]:
        found.append(f"{manifest['id']!r} is the id of a framework route (skill and tool charter article 1)")
    for field in rules["tool_fields"]:
        value = manifest.get(field)
        if not value or (isinstance(value, (list, tuple)) and not all(str(item).strip() for item in value)):
            found.append(f"{field} must be stated (skill and tool charter article 4)")
    for field in ("title", "summary"):
        if not str(manifest.get(field) or "").strip():
            found.append(f"{field} must be stated")
    if manifest.get("tier") not in TIERS or manifest.get("tier") == "T3":
        found.append(f"tier must be T1 or T2 (a task tool runs locally), not {manifest.get('tier')!r}")
    if manifest.get("executor") not in EXECUTORS or manifest.get("executor") != "local":
        found.append("executor must be local")
    inputs = manifest.get("inputs")
    if not isinstance(inputs, dict) or inputs.get("type") != "object":
        found.append("inputs must be a JSON schema of type object")
    outputs = manifest.get("outputs")
    if not isinstance(outputs, dict) or not outputs:
        found.append("outputs must name at least one output")
    else:
        for output, spec in outputs.items():
            if not isinstance(spec, dict) or "unit" not in spec or "description" not in spec:
                found.append(f"output {output!r} needs unit and description")
    if not found:
        route = as_route(manifest, Path("route.py"), "")
        for spec in route.file_inputs:
            if spec.split("[]")[0] not in route.inputs.get("properties", {}):
                found.append(f"file input {spec!r} does not start with an input property")
        try:
            registry.validate_inputs(route, registry.with_defaults(route.inputs, route.example))
        except ValueError as error:
            found.append(f"example does not satisfy inputs: {error}")
    return found


def _number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def read_tests(folder: Path, manifest: dict, rules: dict) -> tuple[list[dict], list[str]]:
    """The known-answer tests, and what is wrong with them (skill and tool charter article 4)."""
    path = folder / TESTS
    try:
        tests = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return [], [f"{TESTS} is missing (skill and tool charter article 4). {TEST_SHAPE}"]
    except (OSError, ValueError) as error:
        return [], [f"{TESTS} is not readable JSON: {error}. {TEST_SHAPE}"]
    if not isinstance(tests, list):
        return [], [f"{TESTS} must be a list. {TEST_SHAPE}"]
    found = []
    if len(tests) < rules["tool_tests_min"]:
        found.append(f"{len(tests)} known-answer tests; at least {rules['tool_tests_min']} are needed "
                     "(skill and tool charter article 4)")
    route = as_route(manifest, Path("route.py"), "")
    for number, test in enumerate(tests, 1):
        where = f"test {number}"
        if not isinstance(test, dict) or not str(test.get("name") or "").strip():
            found.append(f"{where} needs a name. {TEST_SHAPE}")
            continue
        where = f"test {number} ({test['name']})"
        if not str(test.get("source") or "").strip():
            found.append(f"{where} needs a source: where its answer comes from (skill and tool charter article 4)")
        if not isinstance(test.get("input"), dict):
            found.append(f"{where} needs input, an object")
        else:
            try:
                registry.validate_inputs(route, registry.with_defaults(route.inputs, test["input"]))
            except ValueError as error:
                found.append(f"{where}: input does not satisfy inputs: {error}")
        expect = test.get("expect")
        if not isinstance(expect, dict) or not expect:
            found.append(f"{where} needs expect: the outputs it checks")
            continue
        for output, spec in expect.items():
            values = spec.get("value") if isinstance(spec, dict) else None
            values = values if isinstance(values, list) else [values]
            tolerance = [spec.get(key) for key in ("tolerance", "relative")] if isinstance(spec, dict) else []
            if output not in route.outputs:
                found.append(f"{where}: {output!r} is not a declared output")
            elif not values or not all(_number(value) for value in values):
                found.append(f"{where}: expect.{output}.value must be a number or a list of numbers")
            elif not any(_number(item) and item >= 0 for item in tolerance):
                found.append(f"{where}: expect.{output} needs tolerance (absolute) or relative, at least 0")
    return tests, found


def compare(document: dict, test: dict) -> dict:
    """A test's outcome: passed only when the run completed and every expected output is within tolerance."""
    if document.get("status") != "completed":
        return {"status": "error", "detail": f"the run was {document.get('status')}: {document.get('reason')}"}
    misses = []
    for output, spec in test["expect"].items():
        expected = spec["value"]
        got = (document["values"].get(output) or {}).get("value")
        pairs = list(zip(expected, got)) if isinstance(expected, list) and isinstance(got, list) and \
            len(expected) == len(got) else [(expected, got)] if not isinstance(expected, list) else None
        if pairs is None:
            misses.append(f"{output}: expected {len(expected)} values, got {got!r}")
            continue
        for want, have in pairs:
            allowed = max(spec.get("tolerance") or 0, (spec.get("relative") or 0) * abs(want))
            if not _number(have) or abs(have - want) > allowed:
                misses.append(f"{output}: expected {want} within {allowed:g}, got {have!r}")
                break
    return {"status": "failed", "detail": "; ".join(misses)} if misses else {"status": "passed"}


def _mounts(root_dir: Path, root: str, *, check_read=None) -> list[tuple[float, str, dict, Path]]:
    """(saved at, record path, mount, record folder) for every mount of this task's tools, oldest first."""
    found = []
    folder = root_dir / ".research" / "records"
    for path in folder.glob("*/record.json") if folder.is_dir() else []:
        if path.parent.name.startswith(".staging-"):
            continue
        try:
            if json.loads(path.read_text(encoding="utf-8")).get("kind") != KIND:
                continue
            ref = path.relative_to(root_dir).as_posix()
            record = records.read_record(root_dir, ref, check_read=check_read)
            item = next(item for item in record["files"] if Path(item["source_path"]).name == MOUNT)
            mount = json.loads((path.parent / item["snapshot"]).read_text(encoding="utf-8"))
        except (OSError, ValueError, StopIteration):
            continue
        if mount.get("session") == root:
            found.append((path.stat().st_mtime, ref, mount, path.parent))
    return sorted(found, key=lambda item: item[0])


def mounted(root_dir: Path, root: str, route_id: str, *, check_read=None) -> tuple[Route, str, dict]:
    """The newest mounted version of a task tool: a Route that runs from the record's copy, the record, the mount."""
    for _, ref, mount, folder in reversed(_mounts(root_dir, root, check_read=check_read)):
        if mount.get("id") == route_id and mount.get("status") == "mounted":
            return as_route(mount["declaration"], folder / "files" / mount["route_file"], mount["version"]), ref, mount
    name = route_id.rsplit(".", 1)[-1]  # a refused declaration may hold no id, or another one
    tried = [mount for _, _, mount, _ in _mounts(root_dir, root) if mount.get("id") == route_id or mount.get("name") == name]
    hint = (f"; its last mount was refused: {tried[-1].get('reason')}" if tried else
            "; write it under this task's tools folder and mount it with research_simulate action mount")
    raise ValueError(f"task tool {route_id!r} is not mounted in this task{hint}")


def _passed(mount: dict) -> str:
    tests = mount.get("tests") or []
    return f"{sum(test.get('status') == 'passed' for test in tests)}/{len(tests)} known-answer tests passed"


def listing(root_dir: Path, root: str) -> dict:
    """This task's tools for the catalog: where to write them, and the newest mount of each."""
    newest = {}
    for _, ref, mount, _ in _mounts(root_dir, root):
        newest[mount.get("id") or mount.get("name")] = (ref, mount)
    folder = _relative(tools_dir(root_dir, root), root_dir)
    return {
        "note": (f"Tools this task writes for itself: {folder}/<name>/route.py declares ROUTE = Route(id="
                 "\"task.<quantity>.<name>\", ...) as framework routes do, and tests.json beside it holds its "
                 "known-answer tests. Mount it with {\"action\": \"mount\", \"tool\": \"<name>\"}; it is run "
                 "and described like a route by its id. Read the simulation skill first."),
        "folder": folder,
        "tools": [{"id": key, "status": mount.get("status"), "version": mount.get("version"),
                   "title": (mount.get("declaration") or {}).get("title"), "mounted_in_round": mount.get("round"),
                   "tests": _passed(mount), "record_path": ref,
                   **({"reason": mount["reason"]} if mount.get("reason") else {})}
                  for key, (ref, mount) in sorted(newest.items())],
    }


def review_text(root_dir: Path, root: str) -> str:
    """This task's tools as the round review reads them: each one's newest mount, with its tests and their sources,
    so the reviewer can judge whether the tests check what the tool is used for (charter article 4)."""
    newest = {}
    for _, ref, mount, _ in _mounts(root_dir, root):
        newest[mount.get("id") or mount.get("name")] = (ref, mount)
    lines = []
    for key, (ref, mount) in sorted(newest.items()):
        declaration = mount.get("declaration") or {}
        lines.append(f"{key} ({declaration.get('title')}): {mount.get('status')}, version "
                     f"{str(mount.get('version'))[:12]}, mounted in round {mount.get('round')}, record {ref}"
                     + (f"; {mount['reason']}" if mount.get("reason") else ""))
        lines += [f"  test {test.get('name')!r}, {test.get('status')}: its answer from {test.get('source')}"
                  for test in mount.get("tests") or []]
    return "\n".join(lines)


def workspace_version(root_dir: Path, root: str, name: str) -> str | None:
    """The version of the tool's folder in the workspace now, or None when it is gone or unreadable."""
    folder = tools_dir(root_dir, root) / name
    try:
        return version_of(folder, tool_files(folder)) if (folder / "route.py").is_file() else None
    except (OSError, ValueError):
        return None


def describe(root_dir: Path, root: str, route_id: str, *, check_read=None) -> dict:
    route, ref, mount = mounted(root_dir, root, route_id, check_read=check_read)
    missing, versions = registry.availability(route)
    return {**route.manifest(), "available": not missing, "missing": missing, "installed": versions,
            "task_tool": {"record_path": ref, "folder": mount["folder"], "mounted_in_round": mount["round"],
                          "charter": mount["charter"], "tests": [{key: test.get(key) for key in
                                                                  ("name", "source", "status")}
                                                                 for test in mount["tests"]],
                          "note": "A tool this task wrote and mounted; it runs from the mounted copy."}}


def mount(ctx, name: str, *, time_limit_s=None) -> dict:
    """Mount one of this task's tools: copy its files, read its declaration, run its known-answer tests on the
    copy and save the outcome, mounted or refused, as a kind=task_tool record. Returns the agent's summary."""
    from opencode.tools.util import _abort_event, ensure_access
    from researchkit.simulation import executor
    from researchkit.tools import _board_notice, file_for, root_for

    if not NAME.match(name or ""):
        raise ValueError("tool is the folder name of one of this task's tools: lowercase letters, digits and _, "
                         "starting with a letter, up to 40 characters")
    root_dir = root_for(ctx)
    root = task_skills.root_session(ctx.app.store, ctx.session_id)
    folder = tools_dir(root_dir, root) / name
    where = _relative(folder, root_dir)
    if not (folder / "route.py").is_file():
        raise ValueError(f"No task tool at {where}: write route.py there (ROUTE = Route(id=\"task.<quantity>.{name}\", "
                         f"...), as the framework's routes do) and {TESTS} beside it. {TEST_SHAPE}")
    files = tool_files(folder)
    for path in files:
        ensure_access(ctx, path, "read")
    abort = _abort_event(ctx)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_simulate", patterns=[f"mount {name}"],
                            ruleset=ctx.agent.permission, always=["*"], metadata={"tool": name}, abort_event=abort)
    command = f"python (research_simulate mounts task tool {name}: runs workspace code)"
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="bash", patterns=[command],
                            ruleset=ctx.agent.permission, always=[command], metadata={"command": command},
                            abort_event=abort)
    relative = f".research/simulations/{uuid.uuid4().hex}"
    out = file_for(ctx, relative, "edit")
    ensure_access(ctx, records.local_path(root_dir, ".research/records"), "edit")
    copy = out / "tool"  # what is tested is what is saved and what later runs use
    for path in files:
        target = copy / path.relative_to(folder)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
    copied = tool_files(copy)
    rules = task_skills.charter()
    record = {"name": name, "id": None, "status": "refused", "version": version_of(copy, copied), "session": root,
              "round": task_skills.current_round(root), "charter": str(rules["version"]), "folder": where,
              "route_file": f"{relative}/tool/route.py", "declaration": None, "problems": [], "tests": []}
    reply = executor.declare(copy / "route.py", out / "declare", time_limit_s=DECLARE_LIMIT_S, abort=abort)
    if not reply.get("ok"):
        record["problems"] = [f"its declaration could not be read: {reply.get('error')}"]
        record["trace_tail"] = reply.get("trace", reply.get("stderr_tail", ""))[-1500:]
    else:
        record["declaration"] = manifest = reply["manifest"]
        record["id"] = manifest.get("id")
        record["problems"] = declaration_problems(manifest, name, rules)
        tests = []
        if not record["problems"]:
            tests, record["problems"] = read_tests(copy, manifest, rules)
        if not record["problems"]:
            route = as_route(manifest, copy / "route.py", record["version"])
            resolve = lambda path: file_for(ctx, path)  # noqa: E731 - a file input of a test names a workspace file
            for number, test in enumerate(tests, 1):
                run = out / "tests" / str(number)
                run.mkdir(parents=True)
                try:
                    document = executor.run(route, test["input"], run, time_limit_s=time_limit_s, abort=abort,
                                            resolve_file=resolve)
                except ValueError as error:
                    document = {"status": "failed", "reason": str(error), "values": {}}
                (run / "result.json").write_bytes(records.encoded(document))
                record["tests"].append({"name": test["name"], "source": test["source"], "expect": test["expect"],
                                        **compare(document, test), "result_file": f"{relative}/tests/{number}/result.json"})
            failed = [test for test in record["tests"] if test["status"] != "passed"]
            if failed:
                record["problems"].append("known-answer tests not passed: " + "; ".join(
                    f"{test['name']}: {test['detail']}" for test in failed) + " (skill and tool charter article 4)")
    if record["problems"]:
        record["reason"] = "; ".join(record["problems"])
    else:
        record["status"] = "mounted"
    (out / MOUNT).write_bytes(records.encoded(record))
    saved = records.publish(root_dir, kind=KIND, title=f"task tool {record['id'] or name}: {record['status']}",
                            files=[*(f"{relative}/tool/{path.relative_to(copy).as_posix()}" for path in copied),
                                   f"{relative}/{MOUNT}", *(test["result_file"] for test in record["tests"])],
                            depends_on=[], check_read=lambda path: ensure_access(ctx, path, "read"))
    summary = {"status": record["status"], **({"reason": record["reason"]} if record.get("reason") else {}),
               "id": record["id"], "version": record["version"], "tests": [
                   {key: test.get(key) for key in ("name", "status", "detail") if test.get(key)}
                   for test in record["tests"]],
               "record_path": saved["record_path"],
               "note": ("Mounted: run it with {\"action\": \"run\", \"route\": \"" + str(record["id"]) + "\"}. Runs use "
                        "this mounted copy; after changing the tool, mount it again (a new version)."
                        if record["status"] == "mounted" else
                        "Not mounted. Fix the tool or its tests and mount again; this refusal is kept as a record.")}
    notice = _board_notice(ctx, saved["record_path"], KIND)
    if notice:
        summary["host_notice"] = notice
    return summary
