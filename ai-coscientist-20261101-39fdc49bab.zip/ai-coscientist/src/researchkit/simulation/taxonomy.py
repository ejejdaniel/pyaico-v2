"""Where a route sits: research object x quantity, plus tier and discipline tags.

The address of a route is `<object>.<quantity>.<method>`. Object and quantity are
the catalog cell; method distinguishes routes in the same cell. Tier decides cost,
approval and executor, not the address. Disciplines are many-to-many filter tags.
A new discipline usually adds routes to existing cells or a tag, not new cells.
"""

OBJECTS = {
    "element": "Elements and isotopes (atomic cross sections, nuclear data)",
    "molecule": "Small molecules and ions (acid generators, quenchers, drug molecules)",
    "macromolecule": "Synthetic polymers and biomacromolecules (resist polymers, proteins)",
    "condensed": "Crystals, amorphous solids, films and liquids (metals, semiconductors, polymer films)",
    "mixture": "Solutions, formulations and blends (resist formulations, alloy compositions)",
    "interface": "Surfaces, interfaces, particles and colloids (segregation, adsorption)",
    "device": "Components or structures with geometry (interconnects, mask patterns, transistors)",
    "circuit": "Circuit networks as abstract topology (RC trees, netlists)",
    "process": "Processes, reactors and systems (exposure and development, etching)",
    "data": "Data sets and measurements (experimental data, measurement uncertainty)",
    "algorithm": "Algorithms as the object of study (ML models, optimizers, numerical solvers)",
    "organism": "Organisms and populations (reserved)",
}

QUANTITIES = {
    "identity": "Identity and structure (composition, geometry, conformation, sequence, topology)",
    "energetics": "Energy and thermochemistry (relative energy, enthalpy, free energy, stability)",
    "electronic": "Electronic structure (orbitals, band gap, IP/EA)",
    "optics": "Optics and electromagnetics (propagation, diffraction, imaging, n/k, absorption)",
    "electrical": "Electrical behaviour at device and circuit level (resistance, capacitance, delay, power, noise)",
    "kinetics": "Reactivity and kinetics (rates, activation energies)",
    "equilibrium": "Equilibria (pKa, redox, binding, partitioning, solubility)",
    "transport": "Transport (diffusion, viscosity, conduction, permeation)",
    "phase": "Phase behaviour and thermal properties (Tg, melting, miscibility, phase diagrams)",
    "mechanics": "Mechanics and morphology (modulus, density, roughness)",
    "performance": "Performance (accuracy, convergence, robustness)",
    "cost": "Cost (compute time, memory, complexity)",
    "bioactivity": "Biological activity (reserved)",
}

TIERS = {
    "T1": "Analytical model or empirical formula; local",
    "T2": "Semi-empirical, classical force field or fast numerical model; local with a time limit",
    "T3": "First principles, large simulation or GPU training; job executor with human approval (not available yet)",
}

DISCIPLINES = (
    "chemistry", "materials", "polymer", "lithography", "semiconductor", "circuits", "optics",
    "ml", "optimization", "physics", "biology",
)

# The role an algorithm plays decides its cell: as the object of study it is
# algorithm x performance/cost; used as a tool (choosing samples) it is calc's
# experiment design, not simulation.
