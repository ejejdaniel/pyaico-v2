"""The research_simulate tool: catalog, describe and run routes; every run is saved as a record."""

from __future__ import annotations

import json
import uuid

from opencode.tools.types import ToolResult, prop, schema
from opencode.tools.util import _abort_event, ensure_access, truncate
from opencode import task_skills
from researchkit import records
from researchkit.simulation import executor, registry, task_tools
from researchkit.simulation.taxonomy import DISCIPLINES, OBJECTS, QUANTITIES

DESCRIPTION = (
    "Run framework-written simulations (routes) that generate new data from a model of the system: molecular "
    "force fields, molecular dynamics, interconnect and RC-circuit models, lithography imaging, optimizer "
    "benchmarks. Routes are addressed <object>.<quantity>.<method>. Start with action catalog, read a route with "
    "describe (inputs, outputs with units, assumptions, applicability, example), then run it. Every run, including "
    "refusals and failures, is saved automatically as a kind=simulation record; cite that record. Results are "
    "computed evidence under stated assumptions, not measurements. Read the simulation skill before relying on them. "
    "When no route computes what the task needs, write a task tool (a route of this task, with known-answer tests), "
    "mount it, and run it like a route; the catalog shows where."
)

INPUT_SCHEMA = schema({
    "action": prop("string", "catalog: list routes by object x quantity, and this task's tools; describe: one route "
                             "in full; run: execute; mount: check and test one of this task's tools so it can run",
                   enum=["catalog", "describe", "run", "mount"]),
    "route": prop("string", "Route id for describe and run, e.g. device.optics.thin_mask_aerial_image, or a task "
                            "tool's task.<quantity>.<name>"),
    "tool": prop("string", "mount: the folder name of one of this task's tools (see catalog)"),
    "input": prop("object", "run: the route's inputs (see describe; omitted fields take their defaults)"),
    "object": prop("string", "catalog filter: research object", enum=list(OBJECTS)),
    "quantity": prop("string", "catalog filter: quantity", enum=list(QUANTITIES)),
    "discipline": prop("string", "catalog filter: discipline tag", enum=list(DISCIPLINES)),
    "time_limit_s": prop("number", f"run: stop after this many seconds (default {executor.DEFAULT_LIMIT_S}, at most "
                                   f"{executor.LOCAL_LIMIT_S})", minimum=1, maximum=executor.LOCAL_LIMIT_S),
    "depends_on": prop("array", "run: exact record.json paths of records the inputs were taken from",
                       uniqueItems=True, items={"type": "string", "minLength": 1}),
}, ["action"])


def _output(value, title):
    return ToolResult(title=title, output=truncate(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False),
                                                   label=title))


def _task(ctx):
    """This task's workspace and top session, where its tools are kept (simulation/task_tools.py)."""
    from researchkit.tools import root_for
    return root_for(ctx), task_skills.root_session(ctx.app.store, ctx.session_id)


def execute(args, ctx):
    action = args["action"]
    if action == "catalog":
        value = registry.catalog(object=args.get("object"), quantity=args.get("quantity"),
                                 discipline=args.get("discipline"))
        return _output({**value, "task_tools": task_tools.listing(*_task(ctx))}, "research_simulate catalog")
    if action == "mount":
        if not args.get("tool"):
            raise ValueError("mount needs tool: the folder name of one of this task's tools; see catalog")
        return _output(task_tools.mount(ctx, args["tool"], time_limit_s=args.get("time_limit_s")),
                       f"research_simulate mount {args['tool']}")
    if not args.get("route"):
        raise ValueError(f"{action} needs route; call action catalog to list route ids")
    if action == "describe":
        value = (task_tools.describe(*_task(ctx), args["route"], check_read=lambda path: ensure_access(ctx, path, "read"))
                 if args["route"].startswith("task.") else registry.describe(args["route"]))
        return _output(value, f"research_simulate describe {args['route']}")
    return _run(args, ctx)


def _run(args, ctx):
    from researchkit.tools import _board_notice, file_for, root_for
    depends_on, mounted, mount_ref = list(args.get("depends_on", [])), None, None
    if args["route"].startswith("task."):
        workspace, task = _task(ctx)
        route, mount_ref, mounted = task_tools.mounted(workspace, task, args["route"],
                                                       check_read=lambda path: ensure_access(ctx, path, "read"))
        if records.local_path(workspace, mount_ref) not in {records.local_path(workspace, ref) for ref in depends_on}:
            depends_on.append(mount_ref)  # which version ran, and its tests
    else:
        route = registry.get(args["route"])
    abort = _abort_event(ctx)
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="research_simulate", patterns=[route.id],
                            ruleset=ctx.agent.permission, always=["*"], metadata={"route": route.id},
                            abort_event=abort)
    if route.runs_user_code:
        command = f"python (research_simulate {route.id} runs workspace code)"
        ctx.app.permissions.ask(session_id=ctx.session_id, permission="bash", patterns=[command],
                                ruleset=ctx.agent.permission, always=[command],
                                metadata={"command": command}, abort_event=abort)
    root = root_for(ctx)
    for ref in depends_on:
        file_for(ctx, ref)
    relative = f".research/simulations/{uuid.uuid4().hex}"
    folder = file_for(ctx, relative, "edit")
    ensure_access(ctx, records.local_path(root, ".research/records"), "edit")
    resolved = {}

    def resolve(name):
        path = file_for(ctx, name)
        resolved[name] = path.relative_to(root).as_posix()
        return path

    folder.mkdir(parents=True)
    document = executor.run(route, args.get("input", {}), folder, time_limit_s=args.get("time_limit_s"),
                            abort=abort, resolve_file=resolve)
    (folder / "result.json").write_bytes(records.encoded(document))
    files = [f"{relative}/result.json", *(f"{relative}/work/{item['path']}" for item in document["artifacts"]),
             *dict.fromkeys(resolved[item["path"]] for item in document["input_files"])]
    saved = records.publish(root, kind="simulation", title=f"{route.id}: {document['status']}", files=files,
                            depends_on=depends_on, check_read=lambda path: ensure_access(ctx, path, "read"))
    present = records.present(root, saved)
    snapshots = {item["source_path"]: item["snapshot"] for item in present["files"]}
    summary = {
        "status": document["status"],
        **({"reason": document["reason"]} if document.get("reason") else {}),
        "route": document["route"],
        "values": document["values"],
        "warnings": document["warnings"],
        "assumptions": document["assumptions"],
        "applicability": document["applicability"]["statement"],
        "uncertainty": document["uncertainty"],
        "elapsed_s": document.get("elapsed_s"),
        "record_path": saved["record_path"],
        "result_file": snapshots[f"{relative}/result.json"],
        "artifacts": [snapshots[f"{relative}/work/{item['path']}"] for item in document["artifacts"]],
        "note": document["note"] + " Full inputs, details and environment are in result_file.",
    }
    if document["artifacts"]:  # a table among them can be a values selection of the ranking tools
        summary["artifact_selections"] = [{"record_ref": saved["record_path"],
                                           "source_path": f"{relative}/work/{item['path']}"}
                                          for item in document["artifacts"]]
    if mounted is not None:
        summary["task_tool"] = {"version": mounted["version"], "record_path": mount_ref}
        if task_tools.workspace_version(*_task(ctx), mounted["name"]) != mounted["version"]:
            summary["task_tool"]["note"] = ("The tool's folder in the workspace differs from this mounted version; "
                                            "this run used the mounted version. Mount the tool again to run the change.")
    notice = _board_notice(ctx, saved["record_path"], "simulation")
    if notice:
        summary["host_notice"] = notice
    return _output(summary, f"research_simulate {route.id}")
