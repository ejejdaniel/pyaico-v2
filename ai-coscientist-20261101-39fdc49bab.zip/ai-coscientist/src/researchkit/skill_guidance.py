"""The rules of a research tool come back with the tool when compaction has dropped them.

An agent reads its skills early and keeps their text only as old tool results, which compaction
drops first. v40 read nine skills in its first thirteen calls (about 82,000 characters), was
compacted five times in two hours, and wrote its quantitative model from the summary alone: it
put the terms inside another object, where nothing read them.

After the agent has used a tool a skill governs, and that skill's text has not been in its context
since the last compaction, the research host facts carry the skill. The host attaches them to the
newest message, after the tool's reply, so the reply itself (often JSON read by other code) is not
changed. Nothing here orders the work: the guidance follows the tools the agent chose.

The report's rules come earlier than its tools. v41 and v42 wrote their reports before reading
them and rewrote them after: v42 wrote 16,054 characters, read the rules, then spent nine minutes
writing it again. An evolution record that states why it stopped ends the rounds, in any field,
and the report comes next; from then until a report is saved, its rules are carried too.
"""

from __future__ import annotations

# The skill whose rules a tool follows; research_record by the kind it saves.
TOOL_SKILLS = {
    "research_history_check": "final-kpi-proxy-discovery",
    "research_leaderboard": "sample",
    "research_compare_candidates": "sample",
    "render_report": "scientific-report-writer",
    "research_review": "final-lca",
    "research_deliver": "final-lca",
}
RECORD_SKILLS = {
    "prepared_data": "prepare-source-data",
    "hypothesis": "hypothesis-gen",
    "proxy_formula": "final-kpi-proxy-discovery",
    "sample_evolution": "sample",
    "report": "scientific-report-writer",
}
REPORT_SKILL = "scientific-report-writer"
TOOL_HEADER = ("[宿主附上：你用過的工具由 skill「{name}」規範，它的原文自上次壓縮後已不在你的上下文中，以下是原文。"
               "這是工具的使用規則，不是新的委託。]")
REPORT_HEADER = ("[宿主附上：演化紀錄已寫明停止理由，交付的報告由 skill「{name}」規範；它的原文不在你的上下文中，"
                 "以下是原文，寫報告之前先讀。這是報告的寫作規則，不是新的委託。]")


def governing(tool, args):
    if tool == "research_record":
        return RECORD_SKILLS.get(args.get("kind")) if isinstance(args, dict) else None
    return TOOL_SKILLS.get(tool)


def _since_compaction(history):
    start = 0
    for index, message in enumerate(history):
        if isinstance(message, dict) and message.get("compaction_through"):
            start = index + 1
    return [message for message in history[start:] if isinstance(message, dict)]


def _visible(message):
    """A tool reply the model still sees: not cleared by pruning."""
    return (message.get("metadata") or {}).get("compacted") is None


def _calls(messages):
    for message in messages:
        if isinstance(message, dict) and message.get("role") == "assistant":
            for call in message.get("tool_calls") or []:
                if isinstance(call, dict):
                    yield call.get("name"), call.get("arguments")


def _used(recent):
    """Skills governing the tools used in these messages, in order of first use."""
    used = []
    for tool, args in _calls(recent):
        name = governing(tool, args)
        if name and name not in used:
            used.append(name)
    return used


def report_next(history):
    """Whether the newest evolution saved states why it stopped, with no report saved after it.

    The whole history counts, not only what followed the last compaction: a compaction between the
    end of the rounds and the report must not take the report's rules away.
    """
    stopped = False
    for tool, args in _calls(history):
        if tool != "research_record" or not isinstance(args, dict):
            continue
        if args.get("kind") == "sample_evolution":
            template = args.get("template")
            reason = template.get("stop_reason") if isinstance(template, dict) else None
            stopped = isinstance(reason, str) and bool(reason.strip())
        elif args.get("kind") == "report":
            stopped = False
    return stopped


def missing(history, skills):
    """Skill names needed since the last compaction whose text the model no longer has, in order of use."""
    recent = _since_compaction(history)
    used = _used(recent)
    if REPORT_SKILL not in used and report_next(history):
        used.append(REPORT_SKILL)
    shown = {name for name in used for message in recent
             if message.get("role") == "tool" and _visible(message)
             and f'<skill_content name="{name}">' in (message.get("content") or "")}
    return [name for name in used if name not in shown and isinstance(getattr(skills.get(name), "body", None), str)
            and skills[name].body.strip()]


def context(history, skills):
    """Host-facts text carrying each missing skill, or an empty string."""
    try:
        names = missing(history, skills or {})
        by_tool = set(_used(_since_compaction(history)))
    except (AttributeError, TypeError):
        return ""
    return "\n\n".join(
        (TOOL_HEADER if name in by_tool else REPORT_HEADER).format(name=name) + f"\n\n{skills[name].body.strip()}"
        for name in names)
