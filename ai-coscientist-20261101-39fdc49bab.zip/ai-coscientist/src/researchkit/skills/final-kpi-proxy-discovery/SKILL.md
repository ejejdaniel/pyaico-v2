---
name: final-kpi-proxy-discovery
description: Discover or revise an interpretable executable scientific proxy, or assess an implemented proxy's agreement with the commissioned target.
---

# Proxy formulas

A proxy formula computes, for any design, what one hypothesis says about the
KPI, from that hypothesis's levers: quantities a candidate can set (see
hypothesis-gen). When reviewing existing formulas, use what follows as criteria.

## What a formula must say

- **Sign.** The mechanism says whether the KPI rises or falls as the formula's
  value rises (`mechanism_predicts`). Write it from the rationale, before and
  regardless of how the historical samples came out. Every term inside the
  formula has the sign the rationale gives it. A formula that predicts the KPI
  itself (its `measured` selects the KPI's own values) rises with the KPI by
  construction and leaves out `mechanism_predicts`; its mechanism lives in the
  signs of its terms: a quantity whose rise raises the KPI enters with a plus
  sign, one whose rise lowers it with a minus sign.
- **Size.** Not yours to pick. In the quantitative model below,
  research_history_check sets the coefficients from the history and the signs;
  anywhere else, a constant, exponent or weight needs a source.
- **Roles.** Use each component or input in the role and meaning the task gives
  it (see prepare-source-data). A component used in another role computes another
  mechanism.
- **No sign without a basis.** When even the sign needs a measurement or a tool
  you do not have, write no formula: mark the hypothesis
  `"proxy_status": {"status": "not_computable", "reason": "...", "missing": "<the
  measurement or tool>"}` and say in the report what would settle it.

After implementing, check the code against the mechanism with `calc` kind
`properties`: input pairs whose order the mechanism fixes, and inputs that must
give a number.

## Declaration

Save each formula as its own `proxy_formula` record that depends on its
`hypothesis` record, with `template` (stored as `proxy_formula.json`):

```json
{"formula_id": "P1", "expression": "...", "hypothesis_ids": ["H1"], "inputs": ["<lever>", "..."],
 "mechanism_predicts": "kpi_rises|kpi_falls", "direction": "higher|lower|target", "target_value": 12.5,
 "kpi": {"record_ref": "...", "source_path": "...", "column": "<KPI column>", "better": "lower|higher|target", "target_value": 12.5},
 "measured": {"record_ref": "...", "source_path": "...", "column": "..."}, "fitted_on": ["S1"]}
```

`direction` says which values of the formula are better. With `kpi.better`
higher or lower it follows from `mechanism_predicts` (a KPI that rises with the
formula, where lower KPI is better, makes `lower` better), and research_record
refuses a contradiction. `kpi` names the measured KPI and which of its values
are better; every formula has one when the task supplies measurements of the
KPI. When it supplies none, leave out `kpi` and `measured`: `direction` and
`target_value` state the commission's definition, and no data can check the
formula. A formula that predicts the KPI's own quantity declares `target` and
its `target_value`, and `measured` (the same quantity and unit) when that
quantity was measured; `"anchor": "mean_offset"` corrects a constant offset
only. A dimensionless index is `higher` or `lower`.

One hypothesis, one formula: each formula declares one hypothesis id and names
at least one of its levers in `expression` or `inputs`; research_record refuses
one that does not. research_leaderboard needs a sheet for every active
hypothesis, and refuses two sheets with identical values. Hypotheses that are
`deferred`, `not_computable` or `merged` need no sheet. The
only formula for several hypotheses is the model of a KPI with a target below, as
an extra sheet.

## Checking on the history

When the task supplies measured samples, compute every formula for them before
generating candidates, save the values table (`{"<sample id>": {"<formula id>": number}}`) as an
`implementation` record that depends on the formula records, and pass it to
`research_history_check`. Its sample IDs must be the ones the formula's `kpi`
file uses. The check reports the order against the KPI, the offset and spread
against `measured`, and predictions equal on every sample.

- **Reversed order.** Its finding lists what to check first, and what to report
  when nothing is wrong. Correct a real error in a revised formula (`revises`)
  that declares it: `"correction": {"error":
  "role|term_sign|implementation|unit|input_data", "what": "...", "basis": "<the
  task text, citation or code line>"}`.
- **Fitted.** Agreement on samples listed in `fitted_on`, or obtained by a
  formula saved after a reversed check of its hypothesis, is `history_fitted`,
  not evidence. Say in the report what was set or changed after seeing the data.

Two samples can show an ordering, not a general relation.

Without measured samples there is no history to check. Check each
implementation on cases whose answer is known (an analytic limit, a published
example); the report then says the formulas rest on their mechanisms and sources
alone.

## A KPI with a target

When the KPI's best value is a target, the commission needs how far to move
which lever. With measured samples, save one quantitative model that predicts
the KPI: direction
`target` with `target_value` and the task's `tolerance`, `measured` on the
measured KPI, the active hypotheses in `hypothesis_ids`, and one term each:

```json
"terms": [{"hypothesis_id": "H2", "lever": "<lever>", "quantity": "<values-table column>",
           "mechanism_predicts": "kpi_rises"}]
```

The model is an offset plus a coefficient times each quantity (`"offset": false`
drops the offset). You choose the quantities and compute them in code, one
column per term in the values table; the mechanism fixes each sign. When one
change has competing effects and its mechanism fixes no sign, write `unknown`:
the history alone then bounds that coefficient. At least one term needs its
sign. Write no coefficients: research_history_check finds every set that
reproduces the history with those signs (within `"noise": {"sd", "source"}`
when the KPI has a known measurement error), and research_leaderboard compares
candidates under all of them, naming the measurements that would set what the
history leaves open.

Without measured samples nothing can be fitted: the model that predicts the KPI
takes every constant from a source (a physical law, a standard, cited data),
declares direction `target` with `target_value` and the task's `tolerance`, and
names in `hypothesis_ids` the hypotheses whose levers it combines.

When commissioned to compare or revise methods after results exist, read
[method revision](references/method-revision.md).
