# Revising a selected method

Use this local procedure when commissioned to compare or change a selected
formula, ranking convention or implementation after results exist. In a review of
existing work, use it to assess the available evidence within the review scope;
unavailable material does not commission a repair or rerun. The procedure supports
scientific revision without prescribing the outer agent's next skill.
Use ordinary working notes and existing research records; no additional record
kind, table, metadata fields or note format is required.

Before editing, read the human commission and its explicit amendments alongside
the selected formula, code, inputs and actual outputs. Author-written task notes
are interpretations to check against those sources, not new human restrictions.
Keep their exact saved references. If any relevant result is still only in working
files, preserve it with `research_record` using the existing appropriate kind
and actual dependencies, then read its returned snapshots. Include unfavorable
scores, baseline/candidate ranks and completed rounds. Do not edit old snapshots
or replace the only surviving copy of the original comparison.

Before computing alternatives, write their scientific relationships and source
basis in ordinary working notes. Distinguish observations, literature passages,
derived relations and exploratory assumptions for the choices that can change
the recommendation. Use the actual retrieved source, not a later summary's
description of it. Choose plausible alternatives relevant to that uncertainty;
do not manufacture parameter ranges or a deliberately weak comparator. An
implementation defect and a change of scientific method are different repairs.

Save each formula version chosen for comparison as a `proxy_formula` record
before implementing it; reuse an exact existing record when that method is
unchanged. These are methods being compared, not a claim of final selection.
For the commissioned comparison, have the materializer responsibility implement
these frozen alternatives and execute them on the same saved baseline/candidate
inputs and declared target rule. Reuse compatible descriptors and expensive
calculations. For each method, save its baseline and candidate values (one
column of a values table, or an ID-to-value object) in an `implementation`
record that depends on its method. Use `research_compare_candidates` with this
exact file and column, method ref and explicit baseline/candidate IDs; a formula
record ranks by its own declared direction. Consume its saved best values,
delta and better/tie/worse result; do not substitute a remembered baseline from
another method. These are numerical comparisons, not evidence of physical success.
Preserve method versions, commands, outputs and failures before choosing between
methods. `research_compare` still checks agreement with matching observed targets;
it does not compare candidate and baseline groups. Do not invent candidate target
observations. Compare effects on recommendations as well as original-data agreement. If an
alternative cannot be evaluated from available inputs, retain that limit rather
than presenting a qualitative discussion as an executed numerical comparison.

Read the resulting files and decide whether to retain, revise or limit the
selected method and recommendation. Explain what changed the decision, what
remains unresolved and which observation could distinguish remaining alternatives.
An arbitrary assumption does not become supported merely because the program
implements it or several methods fit the same small dataset. Make the sequence
clear: what was selected before the run, what was observed, and what changed
after seeing it. Better agreement alone does not justify reversing the ranking
direction. Explicit target-guided calibration is allowed, but is not a
predeclared rule or independent validation, and must respect the actual commission.

For a separate assessment before consuming a revised decision, use the existing
`research_review` procedure. You still own the actual method revision.
Select original human sources in `commission_files`
as well as `files`; select the author's method restrictions and comparison claims
as reviewed content. Bind essential existing claims with `required_subjects`
without assigning their judgments. Include the selected method, actual code,
values and saved comparison result for implementation fidelity. The two stages
receive the original sources separately from author interpretations. Read the
returned checks and carry established findings into affected work; a valid
comparison record alone does not establish a faithful implementation or method.

Use `research_list` and exact saved dependencies to find downstream work, then
compare the selected change with its content to decide what remains usable.
The listed dependents locate work; they do not decide scientific compatibility.
Unchanged source data, descriptors and successful expensive computations can be
reused when their inputs, settings, units and scientific meaning still apply.
Explain that compatibility in the notes. Recompute only outputs affected by the
change; a ranking-only change can reuse valid numerical outputs and recalculate
the comparisons. A broken dependency or missing record calls for recording the
actual files with corrected dependencies, not repeating a successful experiment.

Select the exact saved method and implementation already compared without
repeating compatible computations. If the chosen formula is changed further,
save that new version before implementing the change. Preserve implementations and comparison
results through the existing records, with exact references to the versions
actually used. Apply the selected comparison rule to both baseline and candidates.
Retain original and revised outcomes, and state which version is now selected
and why. Update affected hypothesis explanations, candidate recommendations and
report conclusions within the current commission, not just the formula file or
a final caveat. If an existing review no longer covers the selected content,
preserve it as historical and state the remaining review scope. Preserve the
revised reasoning and outputs through `research_record` with the actual version
dependencies; read back those snapshots. A new filename or prose claim alone
does not freeze evidence, and adding a new formula beside an old result does not
change which method produced that result.

Carry forward prior use in the unit the commission limits: new designs, valid
evaluation batches, execution attempts or resources. Distinguish rescoring saved
inputs from introducing new designs; do not infer design rounds from execution
count. Count repeats when the commission includes them and preserve actual costs
in either case. Preserving a new method version and its comparison results is
not itself another counted round. A revised method, new session, repaired record
or renamed work does not reset prior use or create a new commission or allowance.

Resolve counting and revision questions using the commission and authorized
evidence and tools. When human intervention is excluded, do not introduce an
approval or arbitration step. If an interpretation remains unresolved, state it
and limit the conclusions and claimed allowance accordingly; continue other
authorized work. Assess affected downstream conclusions and reviews against the
change, keeping compatible evidence and reporting remaining uncertainty.
