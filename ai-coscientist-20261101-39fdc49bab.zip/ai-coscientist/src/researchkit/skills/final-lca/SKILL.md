---
name: final-lca
description: Critically audit scientific claims against sources, implementation, calibration and candidate evidence, preserving conditional and rejected conclusions.
---

# Final claim audit

Start from the actual commission and the selected report's conclusions. Identify
the claims whose failure could change those conclusions, then trace the evidence
needed to assess them. Available quotations do not determine the review scope.
Establish the exact versions under review; unchanged old evidence may be useful
but does not automatically answer a revised task. Follow provided references;
unread or inaccessible artifacts are not established to be absent. Before
selecting checks, read [claim coverage and the review file contract](references/review.md).
For a separate review invocation after gathering the required observations, use
`research_review` with the explicit commission and exact frozen files described
there. It returns an assessment without tools or publication; the outer agent
still chooses what work is needed and whether this review is appropriate.
When consuming an implementation-fidelity review, inspect its actual findings,
contradictions and unresolved effects before making the broader claim judgment.
Its presence or individual decisions do not establish completion of the commission.
When a claim depends on implementation fidelity, use the shared
[method verification procedure](../materializer/references/verification.md)
for the affected claims.

For continuation, reuse and completion decisions, follow
[the shared completion discipline](../research-practice/references/evidence.md#continuation-and-completion).
Do not treat a prior review's presence as coverage of the currently selected work.
`research_review` saves each review as its own `kind=review` record; a review.json
inside another record is not a review. Review the report Markdown before rendering
it. `research_deliver` then writes the Final-LCA and the `user_report` from the
saved reviews and your answers: one per check that is not supported and per host
check of the report (revised or limitation, quoting the delivered report, or
disputed with the reason). A review of an earlier version that the delivered report
depends on (the reviewed draft) covers the delivery once its checks are answered,
so a revised report needs no second review. The research board flags a newest
report that is neither reviewed nor built on a reviewed version.

For each claim state the supporting and contradicting evidence, assumptions,
uncertainty, confounders, scientific consistency, and whether it is supported
within a stated boundary, remains conditional, is rejected, or has a blocking
contradiction. Explain why. Distinguish a methodological defect from absent
future experimental validation; the latter limits release without erasing a
completed proxy study.

Do not promote two-point agreement or a candidate rank into measured KPI gain.
Same-author self-review is valid; describe it honestly rather than calling it
independent review. Limit the final judgment to the claims actually assessed.

The review record and the `final_lca` judgment are linked to the exact evidence
by the tools that save them. A required review is not finished by explaining
applicability in chat: deliver with `research_deliver`. A review authored by hand
explicitly includes `review.json` with claim and evidence quotations tied to frozen
versions, using the linked contract. Do not silently repair upstream
science while reviewing. A negative/conditional scientific conclusion is valid;
missing required computations or reports remain incomplete work.
