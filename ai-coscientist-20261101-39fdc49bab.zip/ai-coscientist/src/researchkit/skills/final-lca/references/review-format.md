# Review JSON format

The object has exactly these keys (replace placeholders with saved references):

```json
{
  "reviewed_refs": ["<exact relative record.json path>"],
  "checks": [{
    "subject": {
      "record_ref": "<reviewed record.json path>",
      "source_path": "<its exact files[].source_path>",
      "quote": "<verbatim claim from that snapshot>"
    },
    "evidence": [{
      "record_ref": "<selected evidence record.json path>",
      "source_path": "<its exact files[].source_path>",
      "quote": "<verbatim evidence from that snapshot>"
    }],
    "decision": "conditional",
    "reason": "<your assessment, scope and limitations>"
  }]
}
```

- `reviewed_refs` and `checks` are nonempty. References are exact workspace-relative
  `.research/records/<hash>/record.json` paths, not names or latest-version aliases.
  Use the saved references; do not calculate or guess hashes.
- Each reviewed reference has at least one subject. Every subject refers to a
  reviewed reference.
- All objects require exactly their shown keys. Duplicate JSON keys and duplicate
  reviewed references are errors. Within one check, evidence entries may cite
  the same file with different quotes; only identical
  `(record_ref, source_path, quote)` combinations are duplicates.
- `source_path` is the manifest field, not a guessed snapshot path. Select quotes
  from the corresponding frozen snapshot. Quotes and reasons are nonblank.
  Each quote is an unchanged, contiguous excerpt; only CRLF/CR versus LF
  differences are ignored. There is no hard quote length limit.
- Judge the exact original claim in `subject.quote`. A weaker replacement may
  be proposed in `reason`, but cannot replace that judgment.
- `decision` is one of:
  - `supported`: evidence supports the original claim's actual scope and strength.
  - `conditional`: the original claim is supported under explicit conditions,
    without weakening it or assuming future evidence.
  - `contradicted`: evidence is incompatible with the original claim; lack of
    support alone is not contradiction.
  - `unsupported`: assessment is complete, but the selected evidence does not
    support the original claim's strength; this does not prove the claim false.
  - `unassessed`: a necessary observation or capability is missing, preventing
    assessment; this is not a scheduling or drafting status.
- An empty evidence array is allowed only for `unassessed`. `unsupported`
  requires the selected materials actually inspected for that judgment. Do not
  invent a source to fill it. Explain evidence and limits in `reason`.
