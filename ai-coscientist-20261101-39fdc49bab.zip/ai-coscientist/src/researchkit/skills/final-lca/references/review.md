# Exact review citations

## Separate review invocation

When a separate assessment is useful, call `research_review(scope, reviewed_refs,
files)` after obtaining the observations required for that assessment. `scope`
states the current review commission, standards and limits. `reviewed_refs` lists
the exact relative record.json paths under review. `files` explicitly selects
`{record_ref, source_path}` pairs from their manifests and any evidence records;
select at least one file per reviewed reference. The reviewer receives only that
scope and those frozen text files, not the parent history or unselected sources.

When original human requirements are relevant, select those exact files in the
optional `commission_files` array of `{record_ref, source_path}` pairs, each also
present in `files`. Python carries their full text and source role into both
stages separately from other research documents. Author-written task summaries
do not become human requirements because they are titled task. Selection records
the caller's source choice; it does not authenticate authorship or settle conflicting
requirements. Omit or use [] to retain the existing undifferentiated input.
Commission sources need not themselves be in `reviewed_refs`; select the author's
interpretations or decisions as the claims under assessment.

Optionally provide `required_subjects`, an array of exact existing
`{record_ref, source_path, quote}` subjects, to bind passages that both stages
must assess. Each must be selected, reviewed, literal and unique; omit the array
or use [] for normal selection. Required subjects the first stage did not judge
are listed for the second stage; any still unjudged are returned as
`unjudged_required_subjects` (not assessed) instead of discarding the review. No
extra model call is made. The host supplies stable per-call positions so the model can
select those subjects without retyping them. The public review format and
decisions remain unchanged. Binding a subject does not prescribe its judgment
or prove semantic coverage.

The tool performs one assessment. The finished review is saved as a `kind=review`
record that depends on the reviewed records and the records of the selected files;
the tool returns a short summary (counts, the checks that are not supported, the
next step) and the full review is that record's review.json. Each selected file has a fixed `file_id` and its full
content is presented with line numbers in each stage. The mapping, source bytes,
source order and tool arguments remain fixed for the invocation, including any
permitted recovery; line numbers are not source content.
If execution matters, select its existing call IDs in optional `tool_call_ids`,
alongside the code, method and other frozen evidence in `files`. Each ID must
uniquely identify a call with a saved matching reply in this session. The host
freezes the selected call/reply JSON and text in one source record, appends only
each JSON to the actual review files, and carries the same evidence into both
stages. It does not choose calls, rerun tools, or follow files mentioned in an
output. Failed or truncated replies retain their actual status. A missing or
ambiguous pair fails before generation; do not replace it with an author's claim
that execution occurred. The new record is evidence, not a new reviewed subject
or human commission. Empty or omitted `tool_call_ids` retains existing behavior.

You can also preserve exact native history/source paths or inline message IDs
through `research_record` and select their frozen files yourself. JSON alone
contains the call and reply; native text-origin verification requires selecting
the paired JSON as well as its text. An unselected companion is not included.
The host checks origin without choosing scientific judgments. Missing/mismatched
native JSON fails before generation. Plain notes and unpaired text remain frozen
material without authenticated native origin. Other-session records remain
readable without accessing that session's history. Source matching does not prove
successful execution, scientific support or review independence.

With nonempty `tool_call_ids`, ordinary review returns `{receipt_record, review}`;
read the source record's exact paths and use only `review` as the public review
document. A failure after freezing preserves the source record and
`.research/review-runs/<key>/resolved-arguments.json`, which records the actual
expanded files. Inspect saved state before choosing further work. No extra model
call or retry is introduced by selecting receipts.

Form the scope as the questions, standards and limits to assess. Trace factual
summaries to the selected evidence; keep a code-derived expectation distinct
from an observed execution. For comparisons, identify which conditions are held
fixed and which are changed rather than assuming the current implementation's
outcome is authoritative. Do not combine a numerical condition, an execution
claim and a broader completion claim into an assumed finding.

For Materializer's implementation-fidelity review, commission consistency of the
selected method, code and observations, including auxiliary quantities, thresholds
and ranking rules. Keep established counterexamples and unresolved consequences
in the existing checks and reasons. The outer agent consumes this assessment and
separately decides whether the original commission permits repair, needs further
review or supports a bounded conclusion; do not delegate overall closure to that
fidelity call. A read-only commission remains read-only at both boundaries.

### Responding to a review

The same main agent owns the response to each check: revise the artifact,
withdraw the claim, retain it with evidence, or explain what remains unknown.
Record the actual revised work and necessary explanations with `research_record`,
depending on this review, the old work actually used and new evidence. A review
is evidence, not the revised artifact, and publishing a response does not
establish that the correction is adequate. When a check changes what you
believe, reflect it in the reasoning graph if you keep one (for example mark an
observation `overturned` or a conjecture `weakened`), so dependent decisions are
flagged for review. No extra review or fixed next action follows automatically.

### Formal inference evidence

When consuming `check_inference`, read its
[input and result contract](../../materializer/references/inference.md). Select
the exact original source, saved formalization in `input.json`, and observed
`result.json` with the relevant completed query evidence. The tool checks syntax,
types, citation provenance and declared logical relations; solver completion does
not establish scientific support or a faithful translation of source text.

Commission two distinct assessments in the existing checks: whether the
formalization faithfully represents the selected claim, meanings, conditions and
premises; and whether the actual evidence supports the original scientific claim.
If the formalization is a subject, include its `implementation` record in
`reviewed_refs` and quote that saved formalization as its subject. Evidence-only
selection does not make it a reviewed subject. Keep the exact original claim as
the subject of its own assessment; do not replace it with a weaker claim that is
easier to prove. The original source, formalization and result can be cited as
evidence using the existing format. Publication retains existing dependency rules.

Assess the relationship between each expression and its cited scientific text,
including variable meanings, units, conditions and the distinction between source
premises and added assumptions. Units are declared audit information, not a
dimensional check by the tool. Its syntactic rejection of a goal repeated as a
premise does not establish semantic independence. Valid citations and matching
hashes establish provenance, not correct interpretation.

An `unsat` counterexample query establishes entailment only under its checked,
consistent formal premises. A formal `sat` countermodel does not alone prove a
physical claim false. Entailment requiring added assumptions does not justify an
unconditional original claim. Inconsistent premises, `unknown`, failed or skipped
queries, and incomplete artifacts cannot be converted into a passed assessment.
Read the completed evidence and explain the actual scope in existing decisions
and reasons; never mechanically map a solver status to a review decision.

These are evidence-consumption instructions. They add no review fields, tools,
model calls, retries or authority to repair the selected scientific claim. The
existing isolated review remains read-only with the same two-stage procedure.

### Isolated assessment stages

Both model stages have no tools or automatic publication. The first request
loads [reviewer-system.md](reviewer-system.md), the private
[Reviewer output format](reviewer-output.md) and the existing
[method verification procedure](../../materializer/references/verification.md).
The second uses [reviewer-followup.md](reviewer-followup.md) with that same format
and read-only procedure. It receives the same complete frozen evidence and the
saved initial checks' bound `subject.quote` with its locator, paired with each
evidence locator and its full frozen lines copied by Python into `quote`. This
`{"checks": [...]}` handoff preserves original check and evidence order from the
verified initial readback. Model output evidence entries remain locator-only.
Initial decisions, reasons, derived judgment labels, reasoning traces and failed
drafts are not handed over. These candidate selections may be wrong or incomplete;
their locations establish neither support nor full coverage. The second stage
assesses the original claims from the full selected evidence and may choose
additional or different claims and evidence. It returns complete final checks,
explaining its own judgments, scope and limits in the existing reasons. The same
model performs both stages; they do not establish independent scientific evidence
or guarantee coverage.

### Generation and recovery

There are two normal generations. OpenAI-compatible providers share at most one
additional temperature recovery across both stages: at most three dispatches in
the whole tool invocation. Anthropic makes at most two dispatches, with no such
recovery. The second normal stage is an assessment, not a retry of the first.
The model, provider, endpoint and generation settings are fixed before the first
dispatch. Stage two has its own fixed request containing the candidate quotations;
recovery reuses only the current stage's request.

OpenAI-compatible recovery requires the current stage's first response to have
`stop` or `length`, no tool calls, blank formal answer text and nonblank reasoning.
The shared allowance must be unused and parent cancellation must not have
occurred. The model must support temperature, and its original effective
temperature must differ from `0.6`. Recovery changes only the current stage's
temperature to `0.6`; the allowance is consumed before dispatch even if transport
fails or cancellation follows. Stage two's normal temperature remains the
original effective value after a stage-one recovery. Reasoning is checked only
for presence; it is never an answer or part of a subsequent prompt. No reasoning
option is forced to `none`.

Every accepted stage must end with `stop`, contain no tool calls, and pass the
existing complete-answer, private format, scope, locator and public review
validation. A nonempty `length` answer fails even if its JSON prefix looks
complete. Transport errors, timeouts, cancellation and other invalid responses
do not trigger this recovery. There is no automatic format repair, background
rerun or continuation across tool calls. First-stage failure stops before stage
two; second-stage failure never returns the initial assessment as tool success.
Failures are tool failures, not scientific rejection.

Python verifies `subject.quote` as a literal contiguous excerpt of its selected
file (a quote cited with wrong line numbers or whitespace is replaced by the
file's exact text where it occurs),
normalizes only CRLF/CR to LF, and copies full evidence line ranges. It fills
the exact record and source paths and takes `reviewed_refs` from the tool arguments.
It preserves each
stage's check order, decisions and reasons without voting, combining judgments
or reassessing them. Success returns only stage two's assembled public
[review JSON format](review-format.md). Read its coverage and limits before using
it. For nonempty `tool_call_ids`, this public document is the returned `review`
inside the receipt wrapper. An error affects only the check it is in. A subject
quotation that differs from one place in its file by a few retyped characters is
replaced by the file's text and listed in `quote_repairs`; check that the decision
is about that text. If the reviewer emitted a few malformed checks, or checks whose
quotation is not in the selected file (at most a quarter), the host drops them
instead of failing the review: the result is then
`{"review": ..., "dropped_checks": ..., "dropped_note": ...}`, the review holds only
valid checks, and the run folder has `dropped-checks.json`. Save the `review` object
as review.json and keep `dropped-checks.json` in the same record; there is no need to
rerun the review for this. If the reviewer gave no check to some reviewed
records, the review covers only the others: its `reviewed_refs` lists those, and
the result adds `unreviewed_refs` and `unreviewed_note`. The unlisted records are
not assessed; review them in a separate call with fewer records if they matter.
Save it as a formal review with existing tools only if the commission
authorizes publication, listing reviewed and evidence records in `depends_on`.
The tool does not choose a final_lca or close the commission. Self-authored
reviews remain supported.

### Preserved initial assessment

Before spending model calls, the tool requires existing `read` and `edit`
permissions for its dedicated output paths as well as its existing review and
source-read permissions. These include `.research/review-runs`, the invocation
directory, `initial/` and its three files, and the sibling `.initial.pending/`
directory and matching files needed for writing, readback, rename and cleanup.
All paths must remain within the resolved workspace. Permission to run
`research_review` does not bypass file permissions or grant broader edits.

The invocation directory is keyed by the SHA-256 of the compact UTF-8 JSON array
`[ctx.session_id, ctx.message_id, ctx.call_id]`, using `ensure_ascii=False`.
Each existing identity must be a nonempty string. The tool atomically claims
that directory before generation; an existing directory fails without dispatch,
overwrite or automatic resume. The claimed directory remains after failure or
cancellation, even if no initial assessment completed.

After stage one passes validation, the tool preserves these three files under
`.research/review-runs/<invocation_key>/initial/`:

- `arguments.json`: the original review arguments, including selected optional
  fields and `tool_call_ids` when supplied;
  original array order, compact UTF-8 JSON and one final LF.
- `response.txt`: the exact validated first-stage formal answer string in UTF-8,
  without reformatting or an added newline; no reasoning or raw transport trace.
- `review.json`: the exact validated assembled first-stage public JSON bytes.

It writes and verifies all three in `.initial.pending/`, then atomically renames
that directory to `initial/` without replacing an existing destination. It reads
the committed files back, checks their bytes and the frozen sources again, and
only then prepares stage two. A partial pending directory is not a saved review.
`initial/review.json` is an initial assessment, not this tool's final result or
a published research record. After stage two succeeds, the validated final
review is written as `final/review.json` in the same run folder, and a host note
after the result names that path: list that file in `research_record` (kind
`review`) rather than retyping the review. Committed initial files remain after stage-two
success, failure or cancellation. The guarantee covers ordinary process failure
or cancellation after commit, not external tampering, storage failure or power
loss; contents and sources must still be checked before reuse.

An ordinary second-stage error identifies that the initial assessment was saved,
that follow-up is incomplete, its absolute path and the failure. Calling
`research_review` again with the same arguments reuses that saved initial
assessment and generates only the second stage (a host note says so); change the
arguments only when the selection itself was wrong. Once a run of the same
arguments has finished, a new call is a new review. Permission
denials and cancellation retain their existing error types. Common may present
only its fixed cancellation message, so cancellation does not guarantee a path
in the message. The path can be reconstructed from the existing call identities
and read with authorized file tools. Preservation does not create an automatic
resume entry or authorize another identical review.

### Capacity and execution limits

Selected manifests and snapshots together, each complete stage request, and each
assembled public UTF-8 JSON retain their separate 262144-byte limits. Public
JSON uses `ensure_ascii=False`, compact separators and one final LF, including
all fields, quotations and reasons. Stage two's request limit includes the full
evidence, candidate quotations with locators and follow-up guidance. If it does not fit,
the saved initial assessment remains and the tool fails without stage-two dispatch;
it does not summarize sources, crop quotations or remove candidate checks.
The private answer retains the model's existing token limit without a new
independent byte cap. Locator, citation or expanded-size failures do not permit
retries, partial reviews, quote truncation or deduplication.

Model preparation has a 600-second local deadline. OpenAI-compatible generation
streams without a total generation deadline; HTTP connection and no-data waits
remain 30 and 600 seconds. Anthropic retains its 600-second preparation and
generation deadline per request. Parent cancellation remains active and waits
for connection cleanup; no overall tool deadline is added. Each call retains
the current model's output limit, and usage is not added to the parent turn's
model usage accounting. Two stages and possible recovery increase input and
output cost; single-stage duration does not predict the total duration.

If Common presents a truncated tool response, read its existing full-output path
before using or saving the review; the preview is not the review.json document.
Both isolated assessments use only the selected saved observations; they cannot
follow outer skill links or perform missing computations. Loading guidance
establishes its delivery, not the assessment's correctness or completeness.

## Saved review format

`research_review` saves its review record itself. For a review authored by hand
with `research_record(kind="review")`, explicitly include exactly one
UTF-8 file named `review.json` in `files`. Other explanation files are optional.
Read the shared [review JSON format](review-format.md) before authoring a review.
This public contract is used for direct authoring and publication. The isolated
reviewer instead receives only its private output contract; Python assembles
the public result and validates it against the existing public contract. Other
record kinds are unchanged.

For publication, each reviewed reference must be a direct `depends_on`.
Evidence references must be in direct dependencies or their explicit dependency
chain. Read the saved manifests and corresponding frozen snapshots.

The host checks bytes, references, dependency membership and quotations. You
assess scientific support and whether the selected checks cover the commission.
A report repeating a claim is not independent evidence for that claim. Trace
it to the actual source and distinguish metadata/snippets from full text.
Legal citations do not prove correct interpretation or a complete review.
Do not generalize a partial read or file count to all claims being verified.

Old reviews remain readable but do not acquire this contract retroactively.
Repair a rejected new review using saved evidence; publication errors are not
instructions to search or calculate again. A review covers only its exact
reviewed versions. Link a retained report and its review in a delivery note
instead of endlessly revising the report just to link its own review.

## Choose coverage from the conclusions

Keep each invocation focused. Both stages read every selected file in full, so
selecting the whole study is slow and makes missed subjects more likely. Prefer
one invocation per group of consequential claims, with only the files their
evidence needs, over one invocation covering everything. The review that
closes a delivery assesses the report: put the report record in `reviewed_refs`
and select the study files its decisive claims rest on. An earlier review of the
same material can be cited as evidence instead of being repeated.

Read the commission and selected report before choosing checks or quotations.
Identify what the conclusions depend on: which methodological, numerical or
source claims, if false or unsupported, would change the comparison, selection,
ranking or release judgment? Let these dependencies determine the checks. Do not
stop after a convenient number of claims with easy citations, or drop a decisive
claim because its evidence is difficult to locate. Use the existing subjects,
evidence, decisions and reasons to express the assessment; no separate table or
fixed number of checks is required.

Trace each consequential claim to the actual saved method, implementation,
inputs, execution outputs and relevant history. For implementation fidelity, use
the shared [method verification procedure](../../materializer/references/verification.md)
to connect the selected condition, concrete inputs, code branch and output to
the claim's support. Apply its execution step before its assessment step within
this review, using existing tools and records; another agent or a full
materializer run is not required. Read the actual saved observation before
authoring the affected decision. If a needed observation cannot be obtained
within the commission, leave only conclusions depending on it unresolved;
retain established findings rather than treating a planned check as evidence.
The needed coverage follows the claim:

- For a comparison or selection among formulas, inspect every formula involved,
  its target transformation, inputs, units, assumptions and implemented terms.
  Agreement for one formula does not establish agreement for the others.
- For numerical or ranking conclusions, check the actual sample coverage,
  exclusions, missing results, score direction and ranking or selection rule,
  including consequential ties or thresholds. Trace reported values to execution
  outputs. A correct transcription does not establish method fidelity or show
  that a ranking measures KPI gain.
- When conclusions reuse or compare work across versions, or claim methodological
  consistency, improvement or frozen evaluation, compare the selected versions
  and saved iteration history. Inspect changes to
  formulas, transformations, calibration, comparison and ranking rules; assess
  their effect on comparability and disclose use of observed targets. Check a
  claimed iteration count against the saved history. Retained numbers alone do
  not establish an unchanged method or independent validation.

A failed or partial file read leaves the affected assessment unresolved; it does
not show that the artifact is absent or authorize recreating or rewriting it.
Resolve supplied references from the exact record manifest and its
`files[].snapshot`, following explicit dependencies as needed; stored snapshot
paths are relative to the record directory, while tool-returned snapshot paths
are directly readable. Match the
entry's `source_path` for citations. Read the relevant code and data before
declaring agreement; a guessed filename, nearby file, report paraphrase or failed
read is not implementation evidence. If the saved evidence remains unavailable,
use `unassessed` for a claim that cannot be assessed and explain the missing
evidence in `reason`. A conditional judgment describes limits on the original
claim; support for a weaker replacement does not establish that original claim.

Use the shared procedure's "State the claim judgment" guidance when writing
the existing checks. Compare the actual coverage with the consequential claims
identified from the commission. Explain what was checked, what remains unassessed
or unfinished, and how that bounds the conclusions in the existing reasons and
final prose. The final_lca and delivery must not claim wider coverage than these
actual checks.

## Reviewing a changed report

A report revised after its review and saved so that it depends on the reviewed
version needs no new review: `research_deliver` carries the review over once each
check it did not support is answered with a quotation of the delivered text (or
disputed with the reason). Review a changed report again only when it adds
conclusions the earlier review did not cover; then review just those.

Read the changed report, the prior review, and the underlying sources relevant
to the changed claims. For each affected claim, decide whether its actual
support and limitations carry over. Use the existing subject/evidence quotes
and reason to explain that decision; no extra compatibility format is needed.

Unchanged numbers justify retaining the corresponding numerical checks only
when their inputs, method and interpretation are also compatible. They do not
establish that a mechanism, attribution or causal explanation is unaffected.
A matching DOI or title proves traceability, not scientific support. For author
attribution inspect the saved author metadata, not just the title. Distinguish
source metadata, search excerpts and full text in each applicable reason.

Carry over sound prior work without repeating calculations, but include the
retained judgment and its scope in the new review of the selected report. A
prior review can be cited as history; it cannot supply missing source evidence
merely by repeating the claim. Use `unsupported` when assessment finds insufficient
support for the original claim, or `unassessed` when assessment cannot be completed.
These are valid bounded judgments, not a
reason to pretend support or leave the review unsaved.

Publish the review, read its saved manifest and checks, then save a final_lca
linked directly to the reviewed report and the new review. Its prose explains
the resulting release scope, including unresolved scientific limitations.
Pass these exact records to the user_report. Do not overwrite old judgments or
revise the report merely to insert links to the review that reviews it.
