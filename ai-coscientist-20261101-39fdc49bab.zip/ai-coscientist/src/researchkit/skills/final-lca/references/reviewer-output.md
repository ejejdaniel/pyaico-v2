# Reviewer output format

This is the private model-output contract for `research_review`. Return exactly
one JSON object with only `checks`, a nonempty array. Do not return
`reviewed_refs` or source paths. Bind each subject to its exact quoted claim;
the host assembles the public review from that claim and the frozen evidence.

The evidence packet separates caller-selected use from host-checked origin.
`commission_files` identifies the selected requirements; `declared_kind/title`
are the publisher's declarations. Neither authenticates authorship. Per-file
`sha256/bytes` establish frozen-content integrity. `origin.status` is
`snapshot_only`, `message_match` or `tool_match`: only the last two mean the
selected content was compared with this session's stored message or tool
exchange. A stored user message is a session input, not proof of human authorship;
an assistant account remains a claim, including an unfinished historical draft.

Read a matched tool receipt's actual call, arguments and returned content.
Execution, reading an author's note and producing a review are different uses
of tools: a matched receipt does not establish successful execution, independence
or scientific support. A review verdict is a judgment, not a new observation.
`retained_text` is separately saved truncated output whose original full bytes
were not authenticated; a matched preview remains limited to that preview.
`snapshot_only` and absent receipts do not establish that an event never happened.
Express any necessary missing observation through the existing checks and reasons;
the host does not choose a scientific decision from origin status. Cite selected
numbered source lines, not the host's origin metadata, as scientific evidence.

Each check has exactly `subject`, `evidence`, `reason` and `decision`, written in
that order: work out the assessment in `reason` first, then give the `decision`
that follows from it.

- `subject` is one locator object with the additional required `quote` string,
  or the required-subject selector described below when that list is nonempty.
- `evidence` is an array of locator objects. It may be empty only when `decision`
  is `unassessed`; do not invent evidence to fill it.
- `reason` is a nonblank string containing the assessment, scope and limits.
- `decision` uses one of the five judgments defined below.

Every locator uses these fields:

- `file_id`: the exact nonempty string assigned to a selected file in this
  invocation, such as `F1`. Use the supplied mapping, never guess an identifier.
- `start_line`: a one-based integer identifying the first selected line.
- `end_line`: an integer identifying the last selected line, inclusive.

Each subject has exactly those three fields plus `quote`. Each evidence entry
has exactly the three locator fields, without `quote`, even when the input
contains host-copied evidence quotations. Duplicate JSON keys are errors.

When the commission supplies a nonempty `required_subjects` list, each exact
`(record_ref, source_path, quote)` in it must appear as a judged subject in both
the initial review and the followup review. Other checks remain allowed. Another
claim from the same record, a shorter clause or a quotation appearing only in
evidence does not cover the required subject. This is a coverage obligation,
not an expected decision; assess each required claim's actual scope and strength.

For those supplied subjects only, `subject` may instead be exactly
`{"required_subject": 1}`, where the value is its one-based list position.
Use only a strict integer within the supplied list; booleans, floats, strings,
null, zero, out-of-range positions and extra fields are errors. This alternative
is unavailable when the list is absent or empty. The host copies the complete
validated subject, including any final newline, into the existing public
three-field subject. Do not retype a large required quote merely to select it.
Other subjects still use the original four-field locator. Evidence always uses
the original three-field locator; this selector is never valid for evidence.

The same frozen required-subject order applies to both stages and any permitted
empty-answer recovery. The host preserves saved initial `{"required_subject": n}`
selectors for the followup; their complete source references and quotations stay
in the shared `required_subjects` list. Other subjects retain the four-field
locator. The handoff excludes initial decisions and reasons. Copied candidate
subjects and evidence are not prior scientific findings.

Line numbers must satisfy `1 <= start_line <= end_line <=` the file's actual line
count. Booleans, floats, strings and null are not integers here. Empty files have
no selectable lines. Each subject must map to a requested reviewed record, and
every requested reviewed record needs at least one subject; the request's coverage
checklist lists each reviewed record's file IDs. Evidence may select
only files explicitly provided in this invocation.

`subject.quote` must be a nonblank string and a verbatim, contiguous excerpt
within its selected lines, joined with LF without the last line's terminator.
Only CRLF/CR are normalized to LF; no trimming, wording, punctuation or other
Unicode normalization is permitted. Select the whole passage or a complete
proposition within it, preserving its conditions, comparison and strength.
The model owns that scientific choice; the host checks only literal membership.
If its words are in the file but its line numbers or whitespace are off, the
host uses the file's exact text and lines; a quote whose words are not in the
file fails the review.

For evidence, select the complete consecutive lines needed. The host copies
them unchanged with the same LF joining; line-number labels are not copied.
A selected range must contain nonblank text. Within one check, different evidence
ranges in the same file are allowed, but identical public
`(record_ref, source_path, quote)` combinations are not.

The host retains the check order, decisions and reasons. It does not split
scientific propositions, repair locators, choose alternative sources or rewrite
quotations. Judge the bound `subject.quote`; a weaker replacement belongs only
as a proposed revision in `reason`, not as a substitute for that judgment.

- `supported`: evidence supports the original claim's actual scope and strength.
- `conditional`: the original claim is supported under explicit conditions,
  without weakening it or assuming future evidence.
- `contradicted`: evidence is incompatible with the original claim; lack of
  support alone is not contradiction.
- `unsupported`: assessment is complete, but the selected evidence does not
  support the original claim's strength; this does not prove the claim false.
- `unassessed`: a necessary observation or capability is missing, preventing
  assessment; this is not a scheduling or drafting status.

`unsupported` requires the selected materials actually inspected for that
judgment. Empty evidence remains permitted only for `unassessed`.

The assembled public UTF-8 JSON must fit 262144 bytes, using `ensure_ascii=False`,
compact JSON separators and one final LF. This includes every field, copied
range and reason. Select relevant ranges without dropping consequential claims.
Invalid locators, quotations or expanded size fail the invocation; they do not
permit partial reviews, shortened quotations, deleted checks or another request.
Missing required subjects also fail the invocation without a format retry.
