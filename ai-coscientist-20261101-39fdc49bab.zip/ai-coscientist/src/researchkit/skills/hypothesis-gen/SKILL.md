---
name: hypothesis-gen
description: Develop testable scientific hypotheses with explicit causal mechanisms, predictions, evidence, alternatives, risks and validation plans.
---

# Hypotheses

## Start from the data

When the task supplies historical samples, tabulate how they differ before
writing hypotheses: each quantity a design can set, and the KPI. Write the simplest estimate the data
allow (for example, the KPI change per unit of the one lever that changed) and
name everything else that changed with it, since that estimate holds only as
far as those other changes do not matter. Mechanisms then say which estimates to
trust, which signs they must have, and what the data cannot separate.

## What a hypothesis is

A hypothesis says how changing a lever moves the KPI, and why. A lever is a
quantity a candidate design can set and the task lets you change: a component's
loading, a choice among the supplied structures, a molecular weight, a process
condition the task names. Say where the task allows it. A property inside a
component (the split of a salt, an assumed share of one ingredient in another)
is not a lever: a design cannot set it.

Base each hypothesis on an `in_task` route of the mind map and name its
`family_id` and the step(s) it tests. Keep one mechanism per hypothesis; two
statements of one mechanism are one hypothesis, and one that mixes two
mechanisms is two. For each, state the mechanism, the predicted sign of the KPI
change, the evidence for it, what it is confounded with in the data, and the
measurement that would test it. Predict the measured quantity with its sign; a
distance to a set value is applied only when ranking.

## How many

`research.hypothesis_budget` (3 by default) is how many hypotheses go through
the full path first (formula, values, leaderboard sheet, report); it is a
ceiling, not a quota. Rank by how strongly each should move the primary KPI and
whether candidates can change its lever, and queue the rest with
`"proxy_status": {"status": "deferred", "basis": "budget", "reason": "<rank and why>"}`.
Merge a duplicate with `"proxy_status": {"status": "merged", "into": "H2"}`.
After the first delivery, activate queued hypotheses in rank order by saving a
revised hypotheses record (`revises`) that keeps every earlier id. The report
lists queued hypotheses as not yet evaluated.

## Saving

Save the hypotheses as prose in a `hypothesis` record that depends on the map
and sources used, with `template` (stored as `hypotheses.json`):
`{"hypotheses": [{"id": "H1", "statement": "...", "family_id": "...", "steps": [2],
"levers": ["mw_kDa"]}], "lever_table": {"record_ref": ".research/records/<hash>/record.json",
"source_path": "data/history.csv"}}`.
`levers` name the quantities each hypothesis changes, as the lever table names
them; the board then shows which levers vary across the historical records. Ids
are unique; other fields are allowed. Two rows cannot establish causation or
significance; do not claim a KPI improvement before measurements exist.
