---
name: literature-researcher
description: Find, read and critically compare external scientific evidence, preserving actual queries, source URLs, relevant passages and limits of access.
---

# Literature research

Start from the commissioned question, not a presupposed claim. Choose useful
queries and sources; they are alternatives, not a checklist. Do not send
explicitly private material to public services.

- `paper_search` with `openalex` covers journals, conference papers and
  preprints, with abstracts, citation counts and links to free legal full text;
  read those with `paper_fetch`. `crossref`, `arxiv` and `pubmed` remain
  available for DOI metadata, arXiv and biomedical abstracts.
- `websearch`, when it is offered, finds patents and other sites. A patent states
  what its applicant claims and is not peer reviewed; a preprint is not yet
  reviewed. Both are useful leads; say which kind of source supports a claim.
- `literature_agent`, when it is offered, asks the organisation's literature
  agent, which can search internal documents. Its synthesis is that agent's
  reading: check the claims you rely on against its references, and cite
  internal references exactly as it reported them.

Search results provide leads. Use `paper_fetch` for known documents and ordinary
Read/Grep on the saved complete text. Inspect the methods, conditions and passages
needed for your claim. If only metadata or an abstract is available, say so and
do not claim details only available in the paper. A 403/challenge is an access
failure, not evidence that no papers exist. Try a legitimate alternate source
or report the limit; do not invent support or loop on identical requests.

Save a literature synthesis with the original question, actual queries and
providers, sources retrieved, relevant quotations/locations, agreement,
contradiction, applicability and gaps. Cite with `[@key]` and write one entry
per source as `[@key]: authors, "title," venue volume(issue), pages (year). DOI
or URL`, so a report can reuse the entries unchanged. Do not fabricate fields.
Use the author/date/title of that exact DOI or URL, not a familiar work with a
similar title. Missing fields stay explicitly unknown. A downloaded abstract
page is still abstract-level evidence, even if its entire HTML was read.

When comparing whether a source claim follows from explicitly stated premises,
check it with `calc` kind `logic`; for a source-bound
record use `check_inference` with the
[shared inference handoff](../research-practice/references/inference-handoff.md).
Preserve the exact quoted claim, its conditions and any added assumptions. A
solver checks the declared inference; it does not retrieve a paper, establish
the source's empirical reliability or turn an assumption into an observation.

Read [shared evidence and handoff guidance](../research-practice/references/evidence.md)
for the source index, exact receipt citations and frozen downstream paths. Cite
the sources actually used, distinguishing snippets, metadata, abstracts and full
text. State the actual searched scope for negative findings. If an old receipt
points to a separate full-output file used as evidence, preserve that file too.
If only writing or recording failed, resume from saved sources rather than repeat
successful network work. Recheck source fidelity
after changing scientific prose. A narrow literature answer needs no mind map,
formula, simulation or invented result merely to fill a pipeline.
