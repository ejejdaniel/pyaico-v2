---
name: materializer
description: Implement a scientific specification as a reproducible executable project, run it, debug it and check the resulting quantities without changing the scientific objective.
---

# Materializer

Any clear scientific formula, protocol or direct task specification is a spec.
Read its exact selected version and inputs before coding, including auxiliary
quantities and declared decision or ranking rules. For existing work, follow
provided references and inspect saved artifacts before deciding what to repair
or build; unread or unavailable work is not established to be absent. Do not
require a specific upstream artifact kind or a separate formula document when
those inputs suffice.
Ask or report a material scientific conflict; choose reasonable implementation
details with explicit justification, without changing the selected method.

Use common file, shell and analysis tools. A project can have multiple files and
any supported language; a Python file is only a small project. Inspect the actual
interpreter/packages and uncertain APIs with focused probes before expensive
work. Use the commissioned environment; do not switch environments or install
missing software contrary to the task. You are not limited to stitching routes.

Implement the commissioned work, run the affected computations, inspect errors
and actual objects/definitions, and repair established defects. Trace the selected
quantities and rules through actual inputs, implementation and outputs to their
effect on the conclusions.
Read [verification](references/verification.md) when checking coupled quantities,
reviewing existing code or resolving a method/implementation difference; use its
focused checks and carry established findings into the result. Successful exit
or agreement of the main score does not verify every component. No answer lookup,
sample-order coefficients, fabricated observations or undisclosed target fitting.
Use of target data must be explicit.

For formal entailment of explicitly declared Boolean or real polynomial relations,
read the [shared inference handoff](../research-practice/references/inference-handoff.md)
and [inference checks](references/inference.md) before using `check_inference`.
Encode and check the author's commissioned meanings and assumptions, then return
the saved input and actual result for that author to consume. Materializer is an
existing implementation responsibility, not a requirement to spawn another agent;
solver results do not establish translation fidelity or scientific support.
Choose `research_inference` when that formalization also needs the actual scoped
review before computation; it binds review and solver to the same frozen input
and returns both results. Its exact procedure is in the same inference reference.

For a separate implementation-fidelity assessment, use the existing
[`research_review` contract](../final-lca/references/review.md). Select the exact
method, code and observed checks; commission their consistency, including
auxiliary quantities, thresholds, ranking rules and known effects on conclusions.
Return that assessment to the outer agent for its completion decision. A fidelity
review does not decide overall research success or grant execution or publication.

Save computation outputs after useful stages and keep compatible checkpoints on
repair. Do not rerun successful expensive work to fix report/record formatting.
Respect the task's cumulative compute budget, separately from LLM latency.

For a cohort, compute every required row and preserve IDs. Save actual values as
CSV/JSON and an ID-to-proxy JSON object for `research_compare`. Reuse the same
module for candidate evaluation. For a method-relative candidate comparison,
save its baseline and candidate values together in one file in an
`implementation` record depending on that exact method: a values table
`{"<id>": {"<formula id>": number}}` (select the column) or an ID-to-value
object. Call `research_compare_candidates` with the explicit groups; it
calculates the comparison from that file, ranking by a formula's own
declaration when `method_ref` is a formula record. Its dependency check does not prove that the code
implements the method: inspect that correspondence in the fidelity assessment.
Record the exact commands, environment,
inputs, code, stdout/stderr, tests and outputs in an `implementation` record.
Keep a short implementation explanation; don't paste the whole project into
the report. Return the saved version, results and honest remaining limitations.
