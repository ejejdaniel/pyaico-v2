# Checking declared inferences

Use `check_inference` when the commissioned relations fit the restricted Boolean
and real polynomial language below. It checks the logical consequences of those
relations with a local solver and no model calls. It does not discover scientific
meanings, repair a scientific theory, or decide a review or release outcome.
Ordinary numerical implementation and the [method verification procedure](verification.md)
remain available; this tool is not a required outer workflow stage.

## Responsibility and preparation

The scientific author owns the exact original claim, variable meanings,
conditions and any additional assumptions. This can be the author working in any
relevant scientific skill, not only a fixed outer phase. Read their selected saved versions.
Materializer translates those declared relations into executable expressions,
checks its translation and implementation defects, and reports unresolved
ambiguity. Do not add a premise, change a variable's meaning, weaken the goal or
change the scientific objective to obtain a favorable solver result. Return a
needed scientific revision to the responsibility that owns the claim.

Read the [shared inference handoff](../../research-practice/references/inference-handoff.md)
for result consumption and downstream version dependencies. These are existing
author and Materializer responsibilities, not new agents or a mandatory pipeline.

The tool mechanically validates the input, expression types, citations and frozen
source hashes, then runs the solver. Python does not interpret scientific prose
or infer relations from names, units, keywords or source quotations. A valid
citation establishes the quoted text's provenance, not faithful formalization.

## Exact input

Call `check_inference` with the structured object itself, not a file path. All
listed fields are required except the paired citation line numbers; objects accept exactly their listed keys. Extra keys
and wrong JSON types fail validation. The raw JSON loader rejects duplicate keys.
At tool dispatch Common supplies an already parsed object: duplicate keys lost
before that boundary cannot be reconstructed or certified absent by this tool.
This integration does not change Common's parsing.

| Object | Fields |
| --- | --- |
| Input | `scope: string`, `goal: Goal`, `variables: Variable[]`, `premises: Premise[]` |
| Goal | `source: Citation`, `expr: string`, `interpretation: string` |
| Variable | `name: string`, `sort: "Bool" | "Real"`, `meaning: string`, `unit: string | null` |
| Premise | `id: string`, `origin: "source" | "assumption"`, `expr: string`, `sources: Citation[]`, `interpretation: string` |
| Citation | `record_ref: string`, `source_path: string`, `quote: string`; paired optional `start_line: integer`, `end_line: integer` |

`scope` states the intended inference and its limits. `goal.source` cites the
original claim; its `interpretation` explains what `expr` means under the declared
variable meanings. Each premise's `interpretation` explains the asserted relation
and its scope. Do not place executable scientific meaning only in prose: the
solver uses `expr`, and the reviewer compares it with the cited text and meanings.

All text values are nonblank. Real variables require a nonblank declared unit,
including `"1"` for a dimensionless quantity; Boolean variables require `null`.
Units are audit information only: the tool does not check dimensions, convert
units or infer constraints. Declare required conversions and relations explicitly
within the selected scientific specification.

A `source` premise requires at least one citation. An `assumption` premise may
have no citations; any citations it does include undergo the same validation.
Label additional assumptions honestly even when they are plausible. `variables`
and `premises` may be empty, with at most 32 variables and 64 premises.

Variable names and premise IDs start with an ASCII letter, contain only ASCII
letters, digits and underscores, and are at most 64 characters. Variable names
and premise IDs share a namespace and must be unique across both arrays.
The reserved words are `Bool`, `Real`,
`Int`, `true`, `false`, `and`, `or`, `not`, `xor`, `distinct`, `ite`, `let`,
`forall`, `exists`, `lambda`, `as`, `match`, `par`, `to_real`, `to_int`, `is_int`,
`div`, `mod` and `abs`. The synthetic core identifier `__negated_goal` is reserved
for the tool and cannot be a submitted identifier.

Use the exact saved workspace-relative `record_ref` and its manifest's
`source_path`; do not substitute a working file or guess a snapshot path. The
tool resolves and hash-checks the selected frozen snapshot. Line numbers are
one-based and inclusive, with `end_line >= start_line >= 1`. `quote` must be a
nonblank contiguous excerpt inside that range. Only CRLF/CR versus LF is
normalized; whitespace, punctuation, spelling and other content must match.

Omit both line numbers to have Python locate the quote in that exact frozen
source. There must be one exact occurrence, including overlapping matches;
zero or multiple matches fail. Expand an ambiguous quote or supply both existing
line numbers. One missing number, nulls and invalid types fail. Explicit wrong
line numbers are never relocated. The saved input contains the resolved five-field
citation; its quote is unchanged. The same size limit applies after location.

The UTF-8 input is at most 256 KiB. Each expression is at most 8 KiB and has a
maximum nesting depth of 64.

## Expression language

Expressions use SMT-LIB-style S-expressions over declared `Bool` and `Real`
variables, Boolean literals `true` and `false`, and exact integer or rational
constants. Supported operations are `+`, `-`, `*`, `=`, `<`, `<=`, `>`, `>=`,
`and`, `or`, `not` and `=>`, with Boolean goals and premises and compatible
operand types. Real arithmetic is polynomial.

`and`, `or`, `+`, `*`, comparisons, `=` and `=>` require at least two operands;
`not` requires one, `-` at least one and `/` exactly two. Integer literals do not
have leading zeros except the literal `0` itself.

Write negative numbers with unary minus, such as `(- 1)`, not `-1`. Division
is allowed only as a rational constant whose numerator and nonzero denominator
are integer literals or unary negations of integer literals: `(/ 1 2)` and
`(/ 1 (- 2))` are valid forms. Variable division and arithmetic expressions in
the numerator or denominator are excluded. Decimal literals, powers, functions,
quantifiers, `ite`, exponential/logarithmic operations, raw Python and other
SMT-LIB constructs are excluded. Do not approximate an unsupported scientific
relation without a separately authorized scientific choice.

The tool rejects the goal's exact parsed expression when it is a whole premise
or a top-level `and` conjunct of a premise (flattening consecutive `and` nodes,
without crossing `or`, `not` or `=>`). This is a syntactic circularity check;
it does not detect every equivalent reformulation or establish scientific
independence of the premises.

## Queries and execution limits

Let `B` be the conjunction of `origin="source"` premises, `H` the conjunction
of additional `origin="assumption"` premises, and `C` the goal. An empty
conjunction is true. Query names and order are fixed inside this tool:

| Query | Formula | When executed |
| --- | --- | --- |
| `base_consistency` | `B` | First |
| `base_counterexample` | `B and not C` | Only if `base_consistency` is `sat` |
| `full_consistency` | `B and H` | Only if H is nonempty and B was not `unsat`, with no preceding timeout, error or cancellation |
| `full_counterexample` | `B and H and not C` | Only if `full_consistency` is `sat` |

If B is `unsat`, stop: inconsistent source premises do not establish the claim.
If H is empty, both full queries are `not_run`. If B is `unknown`, skip the base
counterexample; a nonempty H can still be checked by `full_consistency`.
`unknown` is not retried. Any timeout, error or cancellation stops the remaining
queries, and parent cancellation is propagated.

The four queries share a 30-second compute limit covering worker/solver launch,
checks, model extraction and preservation between queries. Source validation and
final artifact saving are outside that compute limit. There are at most four
solver checks, zero retries and zero
LLM calls. The optional `z3-solver` Python binding and its native library must
already be available locally; the tool does not download them or call a service.

## Saved result and its limits

The tool preserves `input.json` and saves each query's completed entry as
`NAME.json`, where `NAME` is its fixed query name. These entries use the Query
fields below and include `not_run` entries. Actual solver checks also preserve
`NAME.smt2` and raw solver text in `NAME.txt`; a skipped query has no solver input
or raw output. The whole worker's output is preserved as `stdout.txt` and
`stderr.txt`. The final `result.json` is saved when finalization completes.
Completed earlier work remains after a later failure. A partial directory or
missing final `result.json` is incomplete evidence, not a successful result.

`result.json` has exactly `input_sha256`, `solver_version`, `elapsed_ms` and
`queries`. `input_sha256` identifies the saved input bytes; `solver_version` is
a string or `null`. `elapsed_ms` is a nonnegative integer. `queries` contains all
four query entries in the order above, including entries that were not run.
Each entry has exactly these fields:

| Field | Value |
| --- | --- |
| `name` | One of the four query names above |
| `status` | `sat`, `unsat`, `unknown`, `timeout`, `cancelled`, `error` or `not_run` |
| `reason` | `null` for ordinary `sat`/`unsat`; a nonblank explanation for other statuses |
| `elapsed_ms` | Nonnegative integer |
| `values` | For `sat`, an object mapping every declared variable to its exact Z3 S-expression string; otherwise `null` |
| `core_ids` | For `unsat`, an array of premise IDs and, where relevant, `__negated_goal`; otherwise `null` |

A core is a sufficient inconsistent subset, not necessarily a minimum subset.
Model values use exact Z3 expressions; do not replace them with rounded values
and treat those rounded values as the solver's model. No status automatically
maps to a scientific review decision. In particular:

- Consistent B with an `unsat` base counterexample establishes entailment only
  inside the submitted formalization. Its translation and scientific premises
  still require assessment.
- A `sat` counterexample supplies a formal countermodel. It can expose an
  insufficiency in the declared inference; it does not by itself prove a physical
  claim false or show that the model is scientifically admissible.
- Entailment obtained only with H does not justify an unconditional original
  claim. Review the extra assumptions and their effect on that exact claim.
- `unknown`, timeout, cancellation, errors, skipped queries and incomplete files
  provide no passed inference check. Retain any completed earlier evidence with
  its actual scope.

The tool checks its named `check_inference` permission and the existing file
permissions before execution. After publication it compares the frozen bytes
with the captured computation evidence. A query error or timeout preserves
available evidence and raises a tool failure, rather than returning a successful
receipt; cancellation preserves committed local evidence.

The successful tool receipt retains `record_path`, `kind`, `title`, `files` and
`depends_on` for the existing `implementation` record and adds `result`. This
value is the complete parsed object from the verified frozen `result.json`, with
exactly `input_sha256`, `solver_version`, `elapsed_ms` and `queries` as described
above. It is not a prose summary or a second result format. The input and stored
record/result formats are unchanged; failure paths do not return a successful
receipt. `depends_on` names the exact saved source records actually used.

Use the returned result to inspect the checks, and read the manifest and frozen
`input.json` when interpreting their formalization and sources. Select the full
frozen `input.json` and `result.json` for downstream tool evidence; do not replace
them with a manually shortened summary. Retained stdout or a planned query alone
does not establish that a solver check completed. The author records the actual
effect on the original claim in existing prose or notes as described in the
shared handoff; a dependency alone does not show that this happened.

## Commissioning review

For an actual combined review-and-solve invocation, choose `research_inference`
with this same input. It freezes arguments and the canonical input, invokes the
existing two-stage `research_review` with the exact original claim and complete
candidate as required subjects, then solves those identical frozen input bytes.
Its reviewer receives the selected sources and candidate only, with no solver
outcome or parent reasoning. The scientific review scope is in
[inference-review.md](inference-review.md).

This entry requires existing inference, review and file permissions. Its two
normal model calls share the review's existing one empty-answer temperature
recovery; no scientific rewrite or format repair is added. Failed review stops
before solving and retains the candidate and any completed initial review.
Valid negative judgments remain evidence and do not prevent the formal
calculation. The returned inference receipt adds `review_record_ref` and the
complete frozen `review` object. The author interprets both, revises only within
the commission, and preserves previous versions. An inference record's
dependencies include the exact candidate and review, not a guessed latest draft.
Pure `check_inference` remains available with zero model calls.

Use the existing [review contract](../../final-lca/references/review.md) and
existing checks, evidence, decisions and reasons. Select the original source,
the input/formalization and actual result as frozen evidence. If the
formalization is itself a review subject, include its implementation record in
`reviewed_refs`; citing it only as evidence does not make it a reviewed subject.
Judge translation fidelity separately from scientific support for the exact
original claim, retaining that claim as its own subject. A weaker replacement
may be proposed in a reason but cannot substitute for judging the original.

The existing isolated reviewer remains read-only, with its same two stages and
recovery allowance. It assesses the supplied saved evidence; this tool does not
grant it execution tools or a further solver call. The outer agent consumes the
assessment and retains the final decision for the commissioned work.
