# Checking the selected method

Use the selected scientific specification as the authority for implementation
fidelity: whether the code implements that method. Selection does not establish
the method's scientific justification; assess that justification against the
commission and available evidence. Keep the reasoning in ordinary working notes
and the existing implementation or review explanation; this guidance does not
prescribe a new document or output format.

## Establish coverage

Identify the exact selected method and distinguish it from alternatives,
illustrations and superseded versions. Follow provided references and read the
relevant specification, code, inputs and saved outputs before deciding that
something is missing or needs replacement. Not provided, not read and not
accessible do not establish nonexistence. If tools or visibility prevent access,
state which assessment remains unresolved instead of rebuilding or overwriting
work on that basis.

Compare the candidate representation or code with the selected specification's
definitions, quantities, roles, relations, conditions, scope and strength. Assess
this source-to-encoding fidelity from the sources, definitions and candidate;
claims about observed computation behavior require actual execution evidence.
If specification passages conflict, present their different conditions and
consequences and resolve which version is authoritative before claiming
agreement; do not default to the code or rewrite the specification to describe it.

Trace each selected quantity, component and rule from its source definition
through the candidate representation or code branch to the claim that depends
on it. For claims about observed computation behavior, extend that trace through
the concrete input values, derivation and saved output. Include the declared
units, normalization, coefficients, assumptions and auxiliary formulas. Inspect
comparison operators, boundary
inclusion and unit conversions against the selected condition, including any
declared decision or ranking rule. Do not invent additional conditions.
Agreement of the main quantity cannot establish that another component or rule
is correct. State uncovered parts before claiming faithful implementation.

## Choose checks that can expose the difference

Use the actual saved inputs and outputs when they already expose the difference.
Otherwise choose a minimal independently worked example, analytic result, or
perturbation or boundary case that distinguishes the selected rule from the
implementation. Derive the expected behavior from the specification and compare
it with the relevant representation or code branch and, for claims about observed
behavior, the actual output. For an observed decision or ranking outcome, connect
the computed values to the actual selection behavior; a high target score or the
same selected candidate is not enough.

For claims that depend on observed computation behavior, keep execution and
assessment in separate steps within this skill:

1. Select the inputs and distinguishing calculation from the specification.
   Reuse sufficient saved execution evidence. If a new check is needed and
   authorized, run only that computation with the existing shell tools, without
   overwriting the reviewed artifacts. Wait for the tool result; do not write
   the claim decision in the call that requests the calculation.
2. Inspect the actual exit and output. A failed or incomplete check leaves only
   conclusions needing that missing observation unresolved; retain established
   findings. When preservation is commissioned, save the
   command, code, inputs and observed output in an existing `implementation`
   record, then read its exact snapshot from the returned manifest. In a
   read-only commission, inspect existing evidence and state any missing check;
   proposing that check does not authorize running or recording it.
3. Only after reading the observation, assess the affected claim against the
   selected specification. Distinguish reproduced code behavior from agreement
   with the method, and an isolated result from coverage of the complete run.
   Carry the observation into the existing review evidence and reason rather
   than replacing it with a predicted result or a general claim of completion.

Two calls through the same function, or agreement between a report and the code
that generated it, show internal consistency rather than independent evidence.
Likewise, a symmetry or invariant that both competing implementations preserve
does not resolve their difference. Select checks for what they can discriminate,
and state what they leave untested.

## Repair at the right responsibility

Once a concrete counterexample establishes a mismatch, carry it into the affected
quantities, conclusions and minimal proposed correction. Do not turn that finding
back into an unchecked possibility or repeat the same computation to rediscover
it. Distinguish the established defect from its still-unchecked downstream impact.

Repair implementation defects against the selected method within the commission;
a review identifies the correction without silently changing upstream work. If
resolution requires changing the scientific definition, its components or its
decision rules, return the proposed revision to the responsibility that selected
the method. Do not choose the alternative that yields a more favorable score or
ordering. A revised method is a separately selected version whose implementation
must be assessed against that version.

After a correction, reuse compatible outputs and checks; run only the smallest
checks needed to verify the correction and its affected downstream rules. A
documentation-only correction does not require repeating expensive calculations.
Preserve the selected version, concrete findings, their effect on claims and
remaining gaps in the existing explanation. Recording a proposed check does not
prove that it ran or passed.

## State the claim judgment

When selected evidence includes a `check_inference` result, assess the source-to-
constraint translation separately from the original claim. Read the cited source,
saved input and actual queries/results together. A source-labelled premise is an
author's translation, not an established fact; an added assumption is not source
evidence. Check whether a premise merely repeats the conclusion or combines
incompatible conditions. A countermodel refutes the encoded implication, not
necessarily the physical claim. Only consistent premises with an unsatisfiable
counterexample query establish formal implication; this still does not establish
faithful translation or scientific support. Added-assumption success cannot turn
an unconditional original claim into an accepted weaker hypothesis. Unknown,
timeout, cancellation and errors are not passes. Keep these distinctions in the
existing checks, evidence and reason; never map solver status directly to decision.
If the formalization itself is reviewed, explicitly include its implementation
record in reviewed_refs. Read-only review still does not authorize execution.

The existing `subject` identifies the original claim being assessed. When the
selected passage contains several propositions, identify the assessed claim in
`reason`. Decide that claim against the cited evidence and explain the finding,
its consequence and remaining limits. A weaker rewritten hypothesis may be worth
proposing, but its support does not establish support for the original claim.
Keep established defects distinct from missing observations; change a finding
only when evidence warrants it. Put interpretation in `reason` using the output
format required by the current invocation.
