---
name: mindmap-builder
description: Build and save a structured, evidence-grounded landscape of routes of action (distinct mechanisms (physical, chemical, biological, statistical or computational) that could move the target), each with a step-by-step mechanism, through source observation, route architecture and mechanism deepening. Use for defining or revising research families, not for producing a finished hypothesis or proxy formula, and not for summarizing or diagramming a document.
---

# Mechanism landscape

Create a landscape of routes of action. A shared `target_model` states where each
target observable stands, what change is needed and what governs it. Each family
is one route: a distinct mechanism (physical, chemical, biological, statistical or computational) that could move the
targets, like different treatments reaching one clinical goal through different
mechanisms of action. It has a stable `family_id`, the levers it uses, an ordered
step-by-step mechanism from the change to a target, its direction and rough size
against the needed change, side effects on other targets, an early check and
evidence limits. A family is an embryo for later research, not a finished
hypothesis, proxy formula, computed result or validation.
The outer agent decides dynamically whether the task needs this skill and what
to do with its result.

## Select sources and execute

Use `research_mindmap(scope, task_ref, files, resume_from?, pause_after?, additional_evidence?)` to run the skill's
remaining model stages and save their final result. `scope` states this landscape question
and its limits: the measured targets and where they must move, and any task
limits. It does not define what a family is; do not ask for descriptor, proxy
or prediction strategies as families. A required low-cost proxy is met later,
when a hypothesis picks a step of a route and its proxy computes that step's
quantity. `task_ref` is the exact saved `kind=task` record. Each `files`
selection has only `record_ref` and `source_path`, copied from the exact record's
`files[].source_path`; include at least one selected file from `task_ref`.
Choose all source text needed for the question, including explicitly used
literature or prior maps. Selecting a record does not select its other files
or dependencies. Build the map from the task, the measurements and the
literature, before descriptor or proxy plans where possible; do not select such
plans or score tables as sources, since their calculations would become the
routes' levers. They are used later, by the hypotheses and proxies.

Read the selected frozen contents before invocation. Task instructions govern
the objective and permissions; they are not measurement evidence. An index,
filename or earlier model summary cannot replace the source it describes.
If needed definitions or observations are unavailable, resolve that source gap
through the outer agent's authorized tools and select the resulting saved files.
Do not invent source contents or silently switch versions.

The tool loads the matching file-backed guidance for each stage:

1. [Source observation](references/observation.md): separate visible facts,
   tentative patterns, explicit meanings and scoped gaps.
2. [Route architecture](references/architecture.md): write the target model and
   define nonredundant routes and their explicit relationships.
3. [Architecture audit and deepening](references/deepening.md): check the target
   model and routes against the same full sources, check each route's direction
   against the needed change, and deepen each step and its limits.

These are a fixed procedure inside this skill, not a required outer research
sequence. Every stage receives the same complete original selected sources; later stages
also receive the relevant intermediate results marked as fallible. Stages have
no parent history, memory, wider workspace or additional tools. Missing input
returns to the outer agent for an explicit source selection.

## Preserve completed stages and resume

Each normally completed, structurally valid stage is saved and read back as an
immutable `mindmap_checkpoint` record before the next stage starts. This is
progress, not scientific acceptance or a finished map. If a later stage fails,
the error identifies the exact checkpoint with `record_ref` and `source_path`.
Keep the failure and completed work; decide whether to resume from the active
plan and authorization. Do not automatically restart or resume a failed invocation.

To resume, pass those two fields as `resume_from` together with the same
`scope`, `task_ref` and ordered `files`. The tool verifies the frozen sources,
stage guidance and completed-stage chain before any model request. It skips
completed stages; if deepening was already saved, only mechanical output and
publication remain. A mismatch fails rather than silently restarting.
Do not invent a checkpoint, choose one by recency, or use a partial response.

## Optional architecture pause and inference evidence

If a drafted family claim needs a formal inference check before deepening,
check it with `calc` kind `logic`; for a source-bound
record use `check_inference` and read the
[shared inference handoff](../research-practice/references/inference-handoff.md).
The scientific author chooses whether this question is useful and owns its
meaning; Materializer encodes and executes it. This does not require a new agent
or make a solver check mandatory for every landscape.

Set `pause_after="architecture"` to save and return the ordinary five-field
checkpoint receipt (`record_path`, `kind`, `title`, `files`, `depends_on`) with
`kind="mindmap_checkpoint"`. A fresh invocation runs observation and architecture;
an observation resume runs architecture; an architecture resume returns the same
verified receipt without model calls. A deepening resume rejects this pause.
Omitting `pause_after` preserves normal completion; no other value is accepted.

After a useful check, explicitly resume that architecture checkpoint without
`pause_after`. Keep the original `scope`, `task_ref` and ordered `files` unchanged.
Select the full frozen `input.json` and `result.json` in `additional_evidence`,
each using exactly `record_ref` and `source_path` from the saved solver record.
Read the actual input and result first; a manual summary or a dependency alone
does not replace their contents. Consume their effect in existing scientific
prose or notes, recording the affected claim, action or reasoned retention, and
limits. Assumptions and failed proofs are not measured observations.

Only deepening receives the full verified supplemental files, separately from
the original sources; the first two stages are not rerun. Nonempty new evidence
is accepted only on an explicit architecture resume without a pause. Entries
must have nonblank values, no extra keys, no duplicates and no overlap with an
original file selection. Empty arrays are allowed; `null` is invalid. The same
256 KiB model request limit applies, with no silent source truncation.

Only a deepening checkpoint may save `additional_evidence`; its absence in an
older checkpoint means an empty list. Resuming completed deepening inherits its
saved list when omitted; an explicit list must match exactly, including order.
An explicit empty array therefore cannot replace a saved nonempty list. The
original selections, scope, task and all three stage-guidance hashes still must
match. Preserve failed attempts and use the exact returned checkpoint; this
handoff adds no fourth checkpoint, model parameter or retry allowance.

## Result and boundaries

The tool validates the approved structured result and mechanically writes
`mindmap.json` and `mindmap.md` under a new `.research/mindmaps/` directory.
The JSON is the formal seven-field scientific content used for drawing; Markdown
contains the same content plus source observations and exact source locations.
Both files are saved together in a `mindmap` record. Dependencies contain the
original source records, followed by supplemental source records, keeping first
occurrences, then the last checkpoint. Each checkpoint uses the same source order
for its stage, followed by its previous checkpoint when one exists. A dependency
does not establish scientific consumption or acceptance. The saved result is
read back for consistency. Use the exact returned
record and paths; do not replace this result with a Markdown-only map, hand-built
envelope or copied older-system format.

Python checks structure, explicit family identities and relationship endpoints;
the model owns scientific meaning and uncertainty. A structurally valid map is
not proof of causal support. Retain prior IDs only when their scientific meaning
is unchanged, and preserve prior saved versions.

Each pending stage permits one initial generation and at most one additional
request, shared by these two recovery paths:

- A format or structural repair uses the same sources and complete rejected
  answer.
- If the first response ends normally with `stop`, has no tool calls, has an
  empty formal answer and nonempty reasoning, retry once with temperature
  `0.6`. Keep the complete system instructions, messages and evidence unchanged.
  Do not accept reasoning as a candidate or answer, or add it to the prompt.
  If the provider/model does not support setting temperature, or the original
  effective temperature is already `0.6`, fail before sending another request.

The two paths cannot stack: every stage has at most two generations, and all
three stages together have at most six. Any failure on the second generation
stops that stage, including a response that would otherwise qualify for the
other recovery path. This recovery belongs only to `research_mindmap`;
`research_review` and Common behavior are unchanged. Each `complete_once` call
produces at most one model completion. On an OpenAI-compatible provider it asks
the server to constrain the reply to the stage's JSON schema; if the server
rejects that request (HTTP 400/422, before any generation), the same request is
sent once without the constraint and the parser checks the reply as before.
A reply that fails validation is saved in full under
`.research/mindmaps/rejected-<id>/`, and the error states where the JSON broke.

A transport failure, cancellation, timeout, tool call, empty answer without
reasoning, exhausted output (`length`) or oversized context fails visibly
without the temperature retry. Other empty or incomplete responses also fail
unless they meet every condition above. Do not rerun the whole skill or discard
sources to hide a failure. Report the failing boundary and decide the next
action from the active plan.

When a report delivers this map, select its exact saved `mindmap.json` through
`render_report.mindmap_files` for the graph and complete content in HTML and PDF.
Use `evidence_files` separately when the original text is also needed as an
appendix.
