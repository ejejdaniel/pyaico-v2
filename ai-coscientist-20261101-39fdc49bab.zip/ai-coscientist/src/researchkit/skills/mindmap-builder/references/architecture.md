# Method architecture

Build the upper-level research landscape from the current scope, exact task
and full selected sources. The preceding observations are fallible navigation
and interpretation, not a new source. Verify factual statements against the
selected originals, citing exact record/file identities and useful locations
within the existing prose fields. The task determines requirements and allowed
work; it is not measurement evidence. Missing or unselected information retains
its actual scope and must not become a claim of global absence.

The scope states the research question and its limits; it does not change what
a family is. When the scope or a selected plan asks for descriptor, proxy or
prediction strategies, those are how a route will later be computed or tested:
a deliverable such as a low-cost proxy is met downstream, where a hypothesis
picks a step of a route and its proxy computes that step's quantity. Build the
routes first, and put the descriptors or calculations a route could use in its
`early_check`. Likewise, a task score or a prepared table of score values is
not the measured quantity; read the measurements behind it.

First write `target_model`, the shared yardstick that lets different routes be
compared. List each target as the measured quantity, not a score: when
the task ranks by a transform such as a distance to a set value, list the
underlying measurement and its target, and put the transform in
`ranking_score`. Give each a short `id` (such as `O1`), `name`,
`ranking_score` (how the task scores or ranks it, or "none"), `unit`, `kind`
(`larger_better`, `smaller_better`, or `nominal` when the best value is a set
target), `target_value`, `tolerance` (the allowed band for `nominal`, otherwise
0) and `current_values`, the historical measurements as numbers with a label for
each sample. In `needed_change`, say how far the current values are from the
target and why it matters; describe the quantity itself, not what the research
should build. The host computes from these numbers which way each quantity must
move, so the numbers must be the measured source values, never scores. When the
sources hold no measurement of a target, `current_values` is empty: say in
`needed_change` that its current value is unknown and what would establish it,
since an estimate is not a measurement.

For example, in an unrelated task that wants a solution concentration of
5 ± 0.2 mg/L and ranks samples by `-abs(c - 5)`, with past samples at 7.1 and
6.4 mg/L, the observable is the concentration: `name` "concentration c",
`unit` "mg/L", `kind` `nominal`, `target_value` 5, `tolerance` 0.2,
`current_values` 7.1 and 6.4, and `ranking_score` "-abs(c - 5), higher is
better". The host then works out that the concentration must decrease, and a
route that raises it moves away from the target. Listing the score itself,
with values -2.1 and -1.4 and a target of 0, would hide that.

Then state in `governing_relation` which quantities determine these observables, as an approximate relation where the
sources or first principles allow, and say where it is uncertain; a scoring or
ranking definition is not a governing relation. List each quantity in that
relation that could move a target as a `governing_terms` entry: a short `id`
(such as `G1`), the `quantity`, how it moves the targets
(`effect_on_targets`), and `uncovered_reason`, left empty when a route acts on
it. Every term needs at least one `in_task` route that names it in
`acts_on_terms`; when none can change it within the task, say why in
`uncovered_reason`. A term with neither is a missing route. In `couplings`, state how
pushing one observable tends to move the others and why. This model is a
reference, not the classification.

Define each family as one route of action: a distinct mechanism (physical, chemical, biological, statistical or computational) by which the target observables could be moved, the way different
treatments can reach one clinical goal through different mechanisms of action.
Families differ by principle, not by which component or ingredient they use;
one component may serve several routes and one route may use several
components. A route's levers are changes that can actually be made to the system studied (its materials, formulation, data, model or process) within the task. Descriptors, proxy
quantities, motif checks and other calculations are ways to estimate or test a
route; they belong in `early_check` or later hypotheses, not in `levers`, and
a family that is only such a method is not a route. Do not infer families from
names or make a classification inventory.

Cover the principles that could plausibly move the targets, including those the
present records do not vary; mark their evidence limits. A route the task does
not permit may still be listed with `scope_status` `outside_task` so the
landscape is complete; it will not feed later hypotheses. Choose only
nonredundant routes, without aiming for a fixed count. When prior maps are
explicitly selected, retain an ID only if its scientific meaning still fits.
Other selected hypotheses, formulas or rankings indicate explored space and
unresolved tensions; they do not define the taxonomy or prove mechanisms.

Return the complete seven-field JSON result required by the supplied contract:
`title`, `landscape_summary`, `target_model`, `families`,
`supported_relationships`, `unresolved_gaps` and `evidence_boundary_summary`.
Populate every required field even though this is a draft:

| Field | Scientific role |
|---|---|
| `family_id`, `title` | Stable identity and a name for the route. |
| `summary` | A short narrative of the route, without restating every step. |
| `principle` | The mechanism by which this route moves the targets. |
| `scope_status` | `in_task` or `outside_task`. |
| `levers` | Changes that can actually be made to the system studied (its materials, formulation, data, model or process) for this route in this task, with the allowed range. |
| `acts_on_terms` | The `governing_terms` ids this route changes. |
| `steps` | Ordered steps from the change to a target observable. Each gives `change` (what changes), `quantity` (the quantity affected), `effect` (direction and why) and `evidence` (source and location, or "inference, unverified"). The last step's `quantity` names a target observable by id or name. |
| `target_effect` | The observables this route mainly aims to move, by `observable_id`: `direction` (how and why it changes the measured quantity), then `predicted_sign` (`increases`, `decreases`, `mixed` or `unknown`: the sign the route's mechanism predicts for the quantity itself, not whether that is good), `evidence_status` (`supported`, `contradicted` or `untested` by this task's own measurements only: literature or other systems never make it `supported` and go in `basis`; data that vary several things at once cannot isolate this route, so they leave it `untested`), rough `magnitude`, and the `basis` for that size. The predicted sign is a hypothesis drawn from the mechanism and the sources; too few or confounded data make it `untested`, not `unknown`. Use `unknown` only when the mechanism itself cannot say which way the quantity moves. When the sources give numbers from comparable systems, give an order-of-magnitude estimate with the conversion and its caveats instead of 無法估計; write 無法估計 only when no number in the sources bears on the size, and give that reason as the basis. For a `nominal` quantity the size matters as much as the sign, since overshooting the target is as bad as falling short. |
| `side_effects` | Every other target observable, by `observable_id`, with the effect and reason; write that no effect is known when so. An `in_task` route accounts for every observable exactly once across `target_effect` and `side_effects`. |
| `prerequisites` | What must be true, and contraindications such as fixed conditions or task limits. |
| `early_check` | How existing data or a low-cost calculation can test this route first, and what result would weaken it. |
| `main_bottleneck` | The limiting scientific or practical uncertainty. |
| `expected_failure_mode` | A realistic, challengeable way the route could fail. |
| `viability_band` | Bounded present feasibility, justified by available evidence. |

Refer to observables only by their `id`. State only the sign of each
effect; the host compares it with where the quantity must go and shows whether
the route moves it toward or away from the target. For a `nominal` quantity,
note in `couplings` which routes could be tuned continuously to set its value
without disturbing the other targets (an adjustment factor), and which would
also move other targets.

Write each relationship in exactly one explicit form:

```text
source_family_id -> target_family_id: explanation
source_family_id <-> target_family_id: explanation
```

Relationships connect two routes only; a route's effect on an observable
belongs in its `target_effect` or `side_effects`, never in a relationship.
Copy both endpoints from this result's distinct family IDs. Use `->` for
directional influence or dependency and `<->` for mutual coupling, competition
or confounding; explain the scientific meaning and uncertainty. Endpoint
characters follow `[A-Za-z0-9_.:-]+`. Do not use a hierarchy as a causal edge,
self-connect a family or add a link merely to make the graph connected.
An empty relationship list is valid.

Audit whether a control is also held fixed in the same comparison, whether
normalization is needed between entity-level and system quantities, whether
confounded controls are assigned isolated effects, and whether competing
processes support the claimed direction. Preserve useful directions while
making unsupported links conditional and naming discriminating observations.

When the request includes host-computed structure facts, describe structures
consistently with them: ring sizes, element counts and the groups present are
facts, not interpretations.

Write natural Traditional Chinese in narrative fields and explain specialized
terms on first use. Keep exact IDs, formulas, units and source quotations.
Use `supported_relationships` for how routes combine, compete or share side
effects. Respect the supplied schema limits; return JSON only, with no extra fields,
artifact envelope, `revision_of`, Markdown, finished hypothesis, scoring proxy
formula, computed results, ranking or next action. The approximate relation in
`target_model` explains what governs the targets; it is not a scoring formula.
No tools or unselected sources are available in this stage.
