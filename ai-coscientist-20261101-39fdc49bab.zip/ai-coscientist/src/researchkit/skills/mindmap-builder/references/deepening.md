# Architecture audit and mechanism deepening

Audit the entire draft against the same complete selected sources and task
supplied to this call. The preceding observation and architecture outputs may
be wrong; neither becomes evidence by repetition. Direct source content wins
over their factual claims. The task governs the question and permissions but
does not prove a mechanism. Recheck stated gaps against the full input before
requesting new evidence, preserving the difference between unselected,
unread, unexecuted and confirmed absent.

First check `target_model` against the sources: each target must be the
measured quantity rather than a score, with the right `kind`,
`target_value`, `tolerance` and the numeric `current_values` the sources give
(none when they hold no measurement of it); any task score belongs in
`ranking_score`. If the draft listed a score (for example
values that are distances, with a target of 0), replace it with the measured
quantity, its unit and its measured values, then restate each route's
`predicted_sign` as the sign of the change in that measured quantity. The host
arithmetic supplied with the draft shows where each must move, and is only as
right as these numbers. Check that `governing_relation` names the quantities that actually determine the targets (a scoring definition
is not one), and that `couplings` include how pushing one target moves the
others. Correct it before judging the routes, since every route is measured
against it.

Read the host's term coverage: a governing term that no `in_task` route acts on
and that has no `uncovered_reason` is a missing route. Add a route for it, or
explain why it cannot be changed within the task. Check every structure
description against the host-computed structure facts, when supplied, and
correct any that differ.

Then inspect the architecture. Each family must be a route of action: a
distinct mechanism (physical, chemical, biological, statistical or computational) that moves the targets. Families that
differ only in which component they use, or that are methods of checking or
comparing rather than ways to move a target, are not separate routes: merge
them, or move the method into a route's `early_check`. Levers must be changes
that can be made to the system studied (its materials, formulation, data, model or process); a descriptor or
calculation listed as a lever moves to `early_check`. Retain valid identities
and supported detail. Merge, split or rename draft families when needed, and
update every affected relationship endpoint. Do not reorganize merely for
novelty. Prior-map IDs selected as evidence may be retained only when they keep
the same meaning. Add plausible principles missing from the draft with an
explicit evidence limitation; keep routes the task does not permit as
`outside_task`.

Then deepen each route step by step. Each step in `steps` says what changes,
which quantity it affects, in which direction and why, and its
evidence; the chain must run without gaps from the lever to a target
observable. Mark a step that rests on inference rather than a source. Use the
selected evidence and exact source locations; generic textbook description is
not a substitute for task-relevant reasoning.

Check that `evidence_status` separates the data from the mechanism and refers
to this task's own measurements only: a sign the steps predict but the records
cannot test is `untested`, not `unknown`; literature agreement goes in `basis`
and does not make it `supported`; records that change several controls at once
cannot isolate one route, so they leave it `untested`.
Check every route's `predicted_sign` against its steps: it is the sign
of the change in the measured quantity. Read the host arithmetic for each
route: where it says a route moves a quantity away from its target, the route
must not be described as a way to reach that target; reconsider the steps, keep
it as a route with that limitation, or explain the conditions under which the
sign reverses. `unknown` needs a reason that the steps cannot settle, not a
missing comparison. For a `nominal` quantity, judge whether the plausible size
of the change could overshoot the target. Give a rough magnitude only with a
basis, converting numbers from comparable systems in the sources to an order of
magnitude where they bear on it; otherwise write 無法估計 and the reason. Check that each coupling in `target_model` appears in the
`side_effects` of the routes it affects. `summary` must agree with `steps` and
add no claim they lack.

Check causal role assignments against explicit sources. Multiple changing
controls do not identify separate effects; rankings do not establish absolute
performance. A necessary condition or plausible mechanism does not prove that
it determines the target. Confirm that a varied control can change under the
stated fixed conditions, that entity-level and system-level quantities have
appropriate normalization, and that competing processes support the proposed
direction. If direction remains unresolved, identify an observation that could
distinguish the alternatives. Correct the unsupported link without erasing
supported detail.

Return your corrections in the supplied edits contract, not the whole map: the
host applies them to the draft and checks the result as a whole. Change only
what this audit finds wrong, missing or unsupported, and leave correct text
exactly as it is; do not reword, re-punctuate or restyle it. `map_fields`
holds each top-level field you change, given whole; `target_model` may give
only the parts it changes. `family_fields` holds, for each route you change,
its `family_id` and each changed field, given whole: a list such as `steps` is
replaced, not appended to. A new route goes in `added_families` with every
field (`family_id`, `title`, `summary`, `principle`, `scope_status`, `levers`,
`acts_on_terms`, `steps`, `target_effect`, `side_effects`, `prerequisites`,
`early_check`, `main_bottleneck`, `expected_failure_mode`, `viability_band`);
`removed_families` lists the IDs of routes merged away or dropped, and a renamed
route is removed and added. When routes are added, removed or renamed, give
`supported_relationships` whole with its updated endpoints. Leave all four
empty when the draft needs no correction. Refer to observables only by their
`id`; in the result an `in_task` route accounts for every observable exactly
once, in `target_effect` or `side_effects`.

Keep family IDs nonblank and unique. Every relationship uses two distinct,
existing IDs in exactly one of these forms:

```text
source_family_id -> target_family_id: explanation
source_family_id <-> target_family_id: explanation
```

Endpoint characters follow `[A-Za-z0-9_.:-]+`. Use the first form for directional
influence or dependency, the second for mutual coupling, competition,
combination or a shared side effect. Give a nonblank explanation with the evidence and uncertainty;
do not invent edges for visual completeness or mistake a hierarchy for a causal
relationship. Omit unsupported relations. Preserve the authored family order.

Write natural Traditional Chinese in narrative fields, explaining specialized
terms on first use while preserving exact identifiers, units and quotations.
Respect the supplied schema limits and add no new fields, publication envelope,
`revision_of`, Markdown, finished hypothesis, scoring formula, sample, validation
claim, ranking or next action. This stage cannot read additional files, browse or run
calculations. Return limitations for the outer agent instead of pretending
those actions occurred.
