# Source observation

Inspect the full selected sources supplied with this call. The task record
defines the objective, restrictions and meanings it explicitly states; it does
not prove measurements or mechanisms. Other selected files support only what
their actual contents show. Record metadata establishes identity and provenance,
not scientific support. Prior maps, reports and model summaries remain claims
to verify against their sources.

Return only the supplied four-field JSON contract:

- `source_observations`: direct visible facts and record-to-record comparisons.
  Identify the exact selected source and relevant location in the observation.
  For each target observable the task defines, include where its measured
  values stand relative to the target: which direction and how far they must
  move, or that the sources hold no measurement of it. This is arithmetic on
  the task and data, not an inference.
- `variation_patterns`: tentative interpretations of visible variation, with
  dataset scope, confounding and uncertainty retained.
- `explicit_scientific_meanings`: definitions and mappings explicitly stated
  by the task or source. Distinguish a task-defined meaning from a measured fact.
- `evidence_gaps`: unresolved scientific links or unavailable information,
  preserving the source and the scope of this call.

Follow the supplied schema without adding fields, Markdown, an envelope or
publication instructions. Write natural Traditional Chinese, explaining
specialized terms on first use while keeping exact identifiers, units, symbols
and source quotations.

Do not infer a scientific role from a label, filename or unexplained field.
A role inferred from structure is an interpretation, not an explicit mapping.
When records vary several controls, their difference does not isolate one
control's effect, causal direction, optimum, threshold or response shape.
Keep measured association separate from causality and independent validation.

Distinguish not selected here, not yet read, not yet executed and confirmed
absent in the inspected source. A source missing from this call is not evidence
that it does not exist or that another authorized consumer cannot use it.
Check all supplied relevant content before declaring a gap. Do not turn planned
later work into a source defect or infer unseen acceptance values from visible
ones.

This stage has no browsing, file-reading or execution tools. Describe missing
source material honestly for the outer agent to resolve; do not claim to have
inspected it. Do not draft methods, families, hypotheses, formulas or samples.
These observations remain fallible intermediate work: subsequent stages must
verify them against the same original sources.
