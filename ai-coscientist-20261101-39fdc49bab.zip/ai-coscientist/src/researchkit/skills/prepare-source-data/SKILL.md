---
name: prepare-source-data
description: Inspect and transform scientific source files into reproducible calculation and evaluation tables, preserving units, IDs, uncertainty and the commissioned cohort.
---

# Prepare scientific data

First inspect the file structure, task definitions and actual rows. Use a short
parsing program for a whole table rather than many model calls reading slices.
Scientific interpretation belongs in your documented transformation design;
the program implements that explicit design, not guesses from labels.

Preserve raw values and sample IDs, and every value a source gives for a
sample, also one stated only in its text (a loading, a setting). Document every
conversion, mapping, join, unit, duplicate and missing field. Verify row counts
and ID sets. Check every value you derive against what the source itself states
about it (a dimension written on a drawing, a role or structure described in its
text): a derived value the source states differently is a reading error to
resolve before anything uses it. Never silently invent a structure, split a composite term,
normalize ambiguous units, or drop a failed sample.

Provide calculation inputs plus evaluation targets when the task needs both.
Targets must implement the task's actual satisfaction quantity; raw measurements
are not interchangeable with distance-to-target. Keep the raw measurements
alongside: mechanism reasoning works on the measured quantity and its sign, and
a proxy that predicts that quantity can declare direction `target`. Derive them with a saved
script, not hand-typed answers. For `research_compare`, export two JSON objects
mapping exactly the same sample IDs to actual proxy values and target values.
The target mapping uses higher-is-better satisfaction; the formula separately
declares its expected proxy direction. Keep target values out of calculator
inputs unless their use is explicit and scientifically justified.

Map every component or input to the role and meaning the task defines for it
before anything uses it, quoting the definition. When the task defines roles by
chemical structure (a group one role must carry, a motif another has), check the
map with `calc` kind `roles`: the supplied structures, each component's
fragments (a salt or composite term lists all of them), the features as SMARTS
quoted from the task, and each role's required features, plus the roles you
assign. A component that lacks a feature its role requires cannot take that
role, however much one of its parts resembles a typical member of it; a role no
component can take is a data gap. Save the result with the prepared data and
use those roles from then on, in the notes, the mind map and the formulas.

Run validation on produced files: IDs/counts, units, exact transformations and
required fields. On failure, repair only the failing transform or validator and
reuse compatible successful outputs. Save design, scripts, tables and checks in
a `prepared_data` research record, depending on the selected task/source work.
