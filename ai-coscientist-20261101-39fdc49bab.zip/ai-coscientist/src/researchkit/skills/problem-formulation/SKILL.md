---
name: problem-formulation
description: Clarify and save a scientific task from the actual human discussion and source documents, including scope, targets, constraints and completion requirements.
---

# Problem formulation

Read the provided task documents and relevant human discussion before defining
the task. A path is not its content. Preserve explicit overrides and distinguish
requirements from suggestions. Execution data may be inspected by schema and
representative rows; read task-defining prose fully.

Write a concise task document with the question, data scope, primary target,
auxiliary conditions,
allowed methods/environments, computation and iteration limits, deliverables,
and unresolved decisions. Cite the exact source paths and passages. Do not
invent missing measurements or treat a label as a known structure.

State each target as the measured quantity with its unit, whether larger,
smaller or a set value is best, the target value and tolerance, and where the
current measurements, if any, sit relative to it; then give the task's scoring
transform, if any, as how it is ranked. Ask the question in terms of what could
move the measured quantity toward its target. Deliverable forms such as a
low-cost proxy are requirements on the answer, not the question itself.

If human interaction is available, ask about a material ambiguity. If the task
disables it, state a defensible bounded assumption or an unresolved limitation;
do not pretend the human approved it. Do not silently weaken explicit goals.

Save the document and source files with `research_record` using kind `task`.
Revisions are new records, not destructive edits to prior snapshots. General
chat and simple file inspection do not require a formal scientific task.
