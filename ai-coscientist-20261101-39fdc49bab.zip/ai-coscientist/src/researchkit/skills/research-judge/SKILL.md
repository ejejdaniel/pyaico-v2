---
name: research-judge
description: Score samples with a blinded, repeated LLM judge for a hypothesis that no formula can compute, so it still gets its own leaderboard sheet.
---

# Research judge

Every hypothesis gets its own proxy formula and leaderboard sheet. Use
`research_judge` only when a hypothesis cannot be computed even for new designs:
no descriptor, constant or model gives a number for it. That the historical
samples do not vary on this mechanism is not a reason; write a formula for it,
and the leaderboard marks that sheet as mechanism-only.

1. Save a `proxy_formula` record whose `template` (stored as `proxy_formula.json`) declares
   `"method": "llm_judge"`, `"hypothesis_ids": ["<one id>"]`, `"direction": "higher"`
   and an `expression` that states the criterion in words. It depends on the
   hypothesis record.
2. Call `research_judge` with that `formula_ref`, the criterion, and `samples`:
   every historical sample and every candidate, each described by its composition
   or structure only. Do not say which are historical or new, and do not include
   measured results; the host rejects descriptions that do.
3. The host runs several repeats in separate sub-sessions that can only fetch web
   pages, shuffles and re-codes the samples each time, and checks that every cited
   URL was actually fetched. It saves a `kind=judgment` record with `values.json`.
4. Use the returned `values_selection` as that hypothesis's sheet in
   `research_leaderboard`. The sheet's evidence is `llm_judge`: a candidate that
   leads only there is a conditional surpass ("if this hypothesis holds").

Report the agreement between repeats and any unsourced or unfetched citations.
Low agreement means the judge cannot rank these samples reliably; say so instead
of using the ranking as if it were stable.
