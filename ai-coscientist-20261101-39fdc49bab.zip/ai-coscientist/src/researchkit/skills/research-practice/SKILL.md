---
name: research-practice
description: Organize a scientific commission, evidence, reproducible files and honest delivery. Use only for research work; this is guidance, not a required workflow or a separate agent.
---

# Research practice

Work with the current human request and the actual sources. Choose the next
useful action yourself; the listed skills are responsibilities, not a sequence.

Size the work to what is asked. A question the sources or records already
answer (what happened, why, where it went wrong, whether something exists) is
answered in your reply: each claim names the file and line or the record it
comes from, an inference is marked as one, and what the sources do not settle
stays open. Such an answer needs no report file, review, Final-LCA or formal
delivery unless the request asks for one; small working notes or scripts that
help you read are fine. The formal path below (records, review, report and
delivery) is for commissions whose deliverable is a study, a design, a
prediction or a report. When the commission explicitly requires several
outputs, track them and their evidence. If `work-planning` is
installed, record the commission and its requirements with `planning_update`
when a multi-part commission starts, and revise them when a human message
changes them; that saved goal survives compaction and lets the host flag work
that relied on a changed requirement. Scientific criteria still come from the
commission and research skills; the planning tools do not review science or
choose the next skill. Read its guidance when using it. Keep todos for immediate
operations, not as a second source of scientific completion judgments.

## Continuation and completion

Reconcile the commission and later human changes with the summary, saved todos
and selected evidence. Todos and earlier completion claims are working judgments,
not proof that the whole commission is complete. File preservation, source
readback and substantive review are different accomplishments. Check what was
actually covered before marking commissioned work complete or delivering it.

When selected content changes, explain whether the existing review still applies
or needs updating. Reuse compatible computations and unchanged evidence; do not
restart the study. Follow remaining obligations or report them as unfinished.
A narrow follow-up does not require reopening the whole study. No fixed skill
order or additional review stage is required by this guidance.

The research board shows a reasoning graph that the host builds from your saved
records and their optional templates (questions, conjectures, observations and
decisions). Read [reasoning graph](references/reasoning-graph.md) for what to
attach when saving work, and for the few things only `research_graph_update`
records.

Read [evidence and handoff](references/evidence.md) for detailed source, revision,
review and recovery rules when needed. Relative links here start at the directory
containing this SKILL.md, not at the workspace root.

## Calculator

Use `calc` whenever a conclusion rests on arithmetic, chance or logic you would
otherwise judge by eye. One call answers; the first line is the conclusion.

| before you claim | kind | input |
|---|---|---|
| a correlation or difference is real, or a score separates formulas | stats | `{"x": [..], "y": [..]}` or `{"groups": {..}}` |
| a candidate beats history beyond your error | sensitivity | `{"sheets": {"P1": {"values": {..}, "direction": "higher", "sd": 0.3}}, "baseline_ids": [..], "candidate_ids": [..]}` |
| a ranking does not hinge on chosen weights | sensitivity | `{"expr": "a*x + b*y", "rows": {..}, "ranges": {..}}` |
| where a value lands, an overshoot, a spread | interval | `{"expr": "..", "ranges": {..}}` or `{"expr": "..", "normal": {"k": [6, 0.5]}}` |
| something follows from stated relations, constraints fit together, an example exists | logic | `{"premises": [".."], "goal": "A -> B"}` or `"find"` |
| your code computes what the formula and mechanism say | properties | `{"module": "work/model.py", "function": "f", "checks": [{"greater": [[a, b]], "why": ".."}]}` |
| the samples can tell two factors apart, or what to adjust for | causal | `{"rows": {..}, "target": "catalyst"}` or `{"edges": [..], "treatment": .., "outcome": ..}` |
| a constant or property value | constant | `{"names": ["R"]}`, `{"smiles": ".."}`, `{"compound": "..", "experimental": "pKa"}` |
| the units of a formula work out, a conversion, or a mole ratio from a recipe | units | `{"expr": "Ea/(R*T)", "units": {..}}`, `{"convert": "2.5 kcal/mol", "to": "kJ/mol"}` or `{"structures": {..}, "records": {..}, "ratio": ["Z", "X"]}` |
| which sample to make or measure next | design | `{"existing": {..}, "candidates": {..}, "pick": 2}` or `{"predictions": {..}, "sd": 0.4}` |
| a component plays the role the task defines by structure, or which ion is the acid or the base | roles | `{"structures": {..}, "components": {"salt": ["cation", "anion"]}, "features": {"f": "SMARTS"}, "roles": {"r": {"requires": ["f"]}}}` |

In scripts: `from researchkit import calc`, then for example
`r = calc.interval(expr="..", ranges={..}); print(r); r.save(".research/calc/name.json")`.

The answer is only as good as the numbers and relations you give it; say where
they came from. Results are drafts saved under `.research/calc/`; save that file
with `research_record` (kind `calc`) before citing it. For a formal check whose
premises are quoted from frozen sources, use `check_inference`; read
[inference handoff](references/inference-handoff.md).

For a study, plan for one complete delivery first: take a small active set of
hypotheses through the whole path, deliver it with its review and Final-LCA, and
only then widen the study; see the hypothesis-gen skill for active and deferred
hypotheses.

`calc` checks numbers you already have. When a quantity no source or table gives
could be computed from a model of the system (a molecule's conformers, a wire's
delay, a mask's image, an optimizer's performance), `research_simulate` runs
framework-written routes and saves each run as a record; read the
[simulation](../simulation/SKILL.md) skill.

For one bounded scientific method question, optionally use `research_method_explore`;
read [method exploration](../final-kpi-proxy-discovery/references/method-exploration.md).
Read its frozen note before choosing what to verify or develop next.

## Execution and delivery

The common Read, Grep, Glob, Write, Edit and Bash tools remain available. A skill
is instructions, not a permission gate, a new memory or an automatic worker.
Inspect the installed interpreter and available packages before implementing.
The host's own implementation (the researchkit and opencode source) is not
research material: tool inputs and results are in the tool descriptions, and
record templates and the report layout are in the skills. If a format is unclear,
call the tool; its error says what is missing. If a document is wrong or silent
about something you need, record that as a reasoning-graph question whose text
starts with `文件缺口：` (which document, what it does not say) and continue the
research. In scripts use only `calc`.
Do not install packages or use another environment unless the commission allows it.

`research_record` preserves exact files and dependencies. It does not grade
science or end the task. Use ordinary Markdown for scientific reasoning and
JSON/CSV where programs need structured inputs/outputs. No large JSON wrapper is
required around prose. Numerical conclusions still require actual executions.

Keep short working notes with the current question, confirmed findings,
provisional interpretations, failed approaches and next experiment. Reuse actual
saved results; a long conversation is not a reason to recompute. Keep operational todos
consistent with these notes and the selected evidence. If you stop, state the
exact remaining work and saved paths. Never relabel unfinished work.

Write user-facing explanations in the user's language. Return usable paths to
the delivered reports and code, plus the distinction between computed and
experimentally established conclusions. A file inventory is not an answer.
