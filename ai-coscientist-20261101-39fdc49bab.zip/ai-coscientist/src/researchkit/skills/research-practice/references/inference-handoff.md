# Shared inference handoff

Read this when considering or consuming `check_inference` in scientific work.
It checks the consequences of explicitly declared Boolean and real polynomial
relations with a local solver. The scientific author chooses it dynamically
when that question is useful; no skill, map stage or research phase must call it
by default. Missing measurements, uncertain source interpretation and unsupported
expression forms do not become solvable merely by invoking the tool.

## Ownership and selection

The author of the scientific work owns the exact original claim, variable
meanings, conditions, source premises and any additional assumptions. In the
tool's notation, `B` is the conjunction of source premises, `H` the conjunction
of additional assumptions, and `C` the original claim. Preserve those meanings
and the exact saved sources; do not weaken C or add H just to obtain entailment.
A needed scientific revision returns to its author.

Materializer owns faithful executable encoding, checking translation and
implementation defects, and executing the selected check. These are existing
responsibilities: the same authorized agent can perform them, and no additional
agent is required. Read [the exact input and solver contract](../../materializer/references/inference.md)
when doing this work. Use the existing file and tool permissions; reading this
guidance does not authorize extra execution or expose a parent's private context.

Python checks structure, expression types, exact source citations and frozen
file hashes, then runs the solver. It does not infer scientific relations from
names or prose, select a research path, or decide whether a scientific claim
passes. Valid provenance does not prove faithful translation.

`research_inference` combines the existing isolated review and solver for a
submitted candidate. Choose it when the source-to-encoding correspondence needs
that actual assessment. It accepts the same input, fixes the exact original
claim and complete candidate as review subjects, and returns the full `review`
and `review_record_ref` beside the ordinary solver receipt/result. The reviewer
does not see solver results. Negative judgments remain evidence for the author;
the tool does not rewrite expressions or decide the scientific outcome.

When that entry's result goes to mindmap deepening, explicitly select its frozen
input.json and result.json and the review record's review.json together as
additional_evidence. The author evaluates all three; a solver result cannot
replace a missing or negative assessment. Original observation and architecture
remain unchanged. Other scientific skills consume both judgments within their
own dynamically chosen work.

## Consume the result in the scientific work

A successful receipt includes `result`, the complete object read from verified
frozen `result.json`, as well as the existing record receipt fields. Inspect it
with the selected frozen `input.json` and original sources. Keep the exact input
and result available; a manual summary cannot replace them as tool evidence.
Failed execution and incomplete files retain their actual status and limitations.

Once the author chooses this check, close its handoff in the existing scientific
prose or ordinary working notes: identify the original claim affected, describe
the result's meaning under the submitted formalization, record the actual action
or a reasoned decision to retain the claim, and state the remaining limits. An
action may narrow a claim, make a condition explicit, repair a translation or
identify evidence still needed. Preserve the original version when revising.
No new field, template, record kind, acceptance gate or mandatory review stage is
required. If work stops before interpretation is complete, leave that obligation
explicitly unfinished instead of treating a saved solver record as consumption.

For interpretation:

- Consistent B with an `unsat` base counterexample means C follows only within
  the submitted formalization. Translation fidelity and scientific premises
  remain separate questions.
- A `sat` counterexample is a formal assignment permitted by that encoding.
  Assess its relevance to the declared conditions; it is not measured data or
  automatic experimental falsification.
- Entailment that requires H stays conditional on those additional assumptions.
  Assumptions are not observations, even when plausible or sufficient for proof.
- Inconsistent premises, `unknown`, skipped checks, failures and incomplete
  execution do not establish the original claim. Failed proof is not measured
  evidence of the opposite claim.

When saving the affected downstream scientific version, use its existing
`depends_on` to name the exact original claim record, solver implementation
record and source records actually used. Retain other actual dependencies and
preserve earlier versions. This records provenance; it does not itself prove
that the result was consumed or that the science passed. Follow only the review
and delivery obligations already commissioned.

## Optional mind-map handoff

For a useful inference question in a drafted mechanism landscape, the author
may select `research_mindmap(..., pause_after="architecture")`. The tool saves
the completed architecture checkpoint and returns its ordinary
`mindmap_checkpoint` receipt. This is an intentional pause, not a failed run or
a finished map. A fresh invocation completes observation and architecture;
an observation resume completes architecture; an architecture resume returns the
same checkpoint without model work. A deepening resume cannot request this pause.

Inspect the frozen architecture and original sources, state the exact scientific
question, and use Materializer's responsibility if the declared relations fit
the tool. After inspecting the check, resume the explicit architecture checkpoint
with unchanged `scope`, `task_ref` and ordered original `files`, omit
`pause_after`, and select the full frozen `input.json` and `result.json` through
`additional_evidence`. Each selection contains exactly the solver record's
`record_ref` and the matching manifest `source_path`. Do not supply only a
manual summary or merely the solver record without its two selected files.

Only deepening receives these supplemental contents, visibly separate from the
original sources. Observation and architecture are preserved. Deepening must
interpret their effect on the original claims through its existing scientific
content; the author retains responsibility for the action or reasoned retention
in the resulting prose or notes. Formal assumptions, countermodels and failures
must not be presented as measured observations. Selecting supplemental evidence
does not prescribe a scientific verdict or change the final map format.

Nonempty new supplemental selections are allowed only on an explicit architecture
resume without a pause. Each selection must be nonblank, have no extra keys, be
unique, and not duplicate an original `files` selection. Empty arrays are allowed;
`null` is not. Sources are verified in full under the existing 256 KiB model
request limit. Completed deepening resumes inherit their saved supplemental list
when omitted; an explicit list must match it exactly, including order. See
[mindmap-builder](../../mindmap-builder/SKILL.md) for checkpoint and recovery rules.
