# Reasoning graph

The reasoning graph keeps what you are asking, suspecting, finding and deciding
linked, so long research keeps its thread across many turns, compactions and
changed requests. Most of it is built by the host from work you already save;
the research board shows it on every step.

## What the host builds from your records

| node | built from |
|---|---|
| question | the mind map's `unresolved_gaps` |
| conjecture | each id in a hypothesis record's `hypotheses.json` |
| observation | calibration scores, host candidate comparisons, evolution rounds |
| decision | `direction` / `target_transform` in `proxy_formula.json`; `ranking_rule` / `stop_reason` in `evolution.json` |

Edges come from `depends_on` and from `hypothesis_ids`. Whether an observation
supports or contradicts a conjecture is your judgment: write it in the
calibration record's `calibration.json`. The host never decides that.

So the graph costs nothing extra: attach the optional templates described in
hypothesis-gen, final-kpi-proxy-discovery and sample when you save the work.
Notices about a record also come back in its `research_record` receipt.

## What only you can record

Use `research_graph_update` only for what the records cannot show:

- a question that is not a mind-map gap, and when one is answered or dropped;
- a decision that is not a template field, for example narrowing scope after a
  human request;
- an observation you now consider overturned;
- your reply to a flagged node (`reviews`, with the reason it still holds);
- a physical insight (see below).

## Physical insight

When a result surprises you, contradicts a hypothesis, or shows a trade-off
between candidates, explain why it happened. Name the physical, chemical or other mechanistic quantity at work, the chain from what was changed to that quantity to what was
measured, roughly how large the effect should be, and what else would have to be
true if the explanation holds. If two explanations fit, keep both and say what
would tell them apart. "Because the structures differ" explains nothing.

When a mechanism map exists, anchor the insight to it: name the route
(`family_id`) and step number whose prediction the result confirms or breaks,
compare the result with that step's expected direction and the route's
`target_effect` and `side_effects`, and say which link in the chain the result
calls into question.

Record each as a `conjecture` whose text starts with `Insight:` and that is
`based_on` the observation it explains (add the observation first if the host
has not built it), then give the report a short subsection that lists these
insights next to the results they explain.

Node types: `question` (open, answered, dropped), `conjecture` (proposed,
supported, weakened, refuted), `observation` (valid, overturned; must cite
records), `decision` (active, withdrawn). Edges: `based_on`, and `supports` /
`contradicts` from an observation to a conjecture. Never delete a node; change
its status or add one with `supersedes`. `expected_revision` is the graph
revision shown on the board (`null` for the first update).

## Board notices

Notices marked "needs action" carry an id such as `[N3fa21c]`: something looks
wrong, ambiguous or unverifiable (a wrong dependency, an unlinked formula
revision, a surpass claim without a host comparison, tied candidates). Fix the
record, or reply with `notice_replies` saying why it does not apply. Open notices
are listed again when you save a report or delivery, and shown to the human with
the delivered documents. Informational notices state caveats; no reply is needed.

## When something changes

When a node is superseded, overturned, withdrawn or edited, or a requirement a
decision cites (`requirement_ids`) changes in planning, the board lists the
nodes that relied on it as needing review, with the reason; nodes further down
are listed as indirectly affected. Update each flagged node, or put it in
`reviews` with the reason it still holds.

Changing a scoring rule, ranking rule or target after seeing results is a new
decision: save a new formula or evolution record with the changed rule and say
why. The board flags scoring that silently differs from the declared rule.
