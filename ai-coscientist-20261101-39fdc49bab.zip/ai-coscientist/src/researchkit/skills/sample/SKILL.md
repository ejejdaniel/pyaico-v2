---
name: sample
description: Propose and evaluate new scientific designs using a selected frozen implemented scorer, comparing against baseline controls with an explicit iteration limit.
---

# Sample evolution

The evaluation and recording steps below apply when commissioned to propose or
evaluate scientific designs. When reviewing existing work or excerpts, inspect
the supplied material and follow its existing references within authorized
scope before judging completeness. Material not supplied is not confirmed
absent. If evidence or tools are unavailable, state what cannot be verified
and limit the assessment; missing review material does not commission new
batches, record creation or reruns.

Read the task's design constraints, source inputs, selected formula, implemented
scorer and calibration evidence. Define the design space and comparison rule
before evaluating proposals. The design space may extend beyond the variables
the source data mentions (a process temperature, an additive no record uses):
declare each extension and the range you assume, and say in the report that
candidates there are extrapolation. Keep apart the limits the task sets and the
ranges you chose: a conclusion that no candidate can surpass holds only inside
your ranges, so say which limits are yours and what the formulas predict just
outside them. Distinguish the scorer's ranking convention from
any historical trend score. Keep the formula, implementation and ranking rule
fixed for the compared baseline and candidates. Generate candidates only with
formulas already checked: on the historical records with `research_history_check`
when the task has measured ones, otherwise on known cases (see
final-kpi-proxy-discovery).

Move each lever the way the formulas' declared directions reward: a candidate
that lowers a higher-is-better formula is worse on that sheet by construction.
When the sheets pull a lever in opposite directions, that is a trade-off to
explore and report, not a reason to follow one sheet silently. When the KPI has
a target, the quantitative model's sheet (see final-kpi-proxy-discovery) says
which candidates surely or possibly land within the tolerance; report those ranges.

Design each round after reading the previous round's leaderboard, and say in
the round's `reason` which result it acts on. Candidates computed together
before any ranking are one round, however they are labelled; the board flags a
round whose values were saved before the previous round was ranked.

When a design claim depends on declared constraints (a candidate stays below
an optimum, a constraint set can be met), check it with `calc` kind `logic` or
`interval`. Before claiming a surpass, check that the margin exceeds your
measurement or model error with `calc` kind `sensitivity`; the board prompts this
when the margin is small. Interpret the result in the design rationale; it does
not score a candidate, replace its actual evaluation, or reset the commissioned
iteration allowance.

Use the saved calculator module to evaluate complete new input records against
the same baseline. Reuse saved baseline outputs when their inputs,
code and settings remain applicable; calculate only missing or affected values.
Do not manually invent proxy values or change the scorer to reward candidates.
Preserve input validity and relevant task controls; unknown structures/measurements
cannot be filled by guessing. A metadata/ID change alone is not a new scientific
design.

Have the evaluation script write each round's values as one values table: a
row for every baseline and every candidate scored so far, a column
for every formula, numbers only:

```json
{"<baseline id>": {"P1": 1.25, "P2": 0.8}, "<candidate id>": {"P1": 1.4, "P2": 0.7}}
```

Save it in an `implementation` record whose `depends_on` lists the formula
records (already saved; a formula never depends on its values), and select it
as `{"record_ref": ..., "source_path": ..., "column": "<formula id>"}`
in `research_history_check`, `research_leaderboard` and
`research_compare_candidates`; the same file serves all three, so no per-tool
copies or conversions are needed. When `method_ref` is a formula record, the
comparison ranks by that formula's declared direction, target and anchoring,
as the leaderboard does.

Record each actually scored batch, candidate inputs, code version, numerical
outputs, baseline comparison and actual ranks. Keep failed and unscored attempts
visible without presenting them as completed evaluations. Before another batch,
identify what the commission limits: new designs, valid evaluation batches,
execution attempts or resource use. Recover prior activity from saved
`sample_evolution` records, outputs and working notes, including unfavorable
results under earlier versions, and account for it in that commissioned unit.
Distinguish reevaluating existing inputs from creating new designs; execution
count alone cannot establish a count of new designs. Count recalculations when
the commission includes them, and retain their actual resource costs regardless.
Keep cumulative use and remaining allowance in ordinary working notes. A restart,
new file, scorer revision or new record does not reset prior use; do not rename
or split continuing work to evade its limit. Recover missing history before
claiming an allowance.

Follow the commissioned iteration limit and early-exit condition. If a strict
improvement is not achieved by the valid limit, preserve that outcome and proceed
with other deliverables. When evidence warrants changing the scorer or ranking
rule, first preserve the current comparison and read
[method revision](../final-kpi-proxy-discovery/references/method-revision.md).
Keep earlier ranks and outcomes visible; compare baseline and candidates under
the same newly selected rule, keeping the revised comparison distinct from the
original results. Reuse compatible saved calculations and recompute only
affected results.

For multiple selected indices, document the same aggregation/tie rules for all
samples and retain the individual values. Improving proxy rank is not evidence
of improved real-world KPI. Save a `sample_evolution` record with all rounds and
exact formula, implementation, data and calibration dependencies, before the
report: research_deliver refuses a delivery whose leaderboards ranked
candidates without one.

Pass `template` in that `research_record` call (stored as `evolution.json`) so
the host can check the claim:
`{"proxy_formula_ref": "<formula record.json>", "direction": "higher|lower",
"target_transform": "...", "ranking_rule": "...", "baseline_ids": [...],
"primary_formula_ref": "<formula record.json>",
"rounds": [{"round": 1, "candidate_ids": [...], "comparison_ref": "<record.json>",
"leaderboard_ref": "<record.json>", "strategy": "explore|exploit", "levers": [...],
"reason": "..."}],
"stop_reason": "...", "tie_break": "...", "claims_surpass": true|false}`. Use
`research_compare_candidates` for each round's comparison and cite its record as
`comparison_ref`; a surpass claim without a host comparison is flagged.

Decide `tie_break` before scoring: how candidates with equal proxy values are
ordered, or that ties are reported as ties. Choosing an order after seeing the
scores is a rule changed after results. When candidates reach the same best value
or the proxy's maximum, later rounds cannot show improvement; say so instead of
presenting extra rounds as progress.

### Several sheets

With more than one formula, score each round's whole pool (baselines and
candidates) with `research_leaderboard` and cite it as the round's
`leaderboard_ref`, each sheet selecting its column of the round's values table.
`primary_formula_ref` is optional: name it before scoring when the commission has
one headline criterion.

The host gives each sheet an evidence level: `history` (the historical samples
differ on it, in the order of the measured KPI), `history_reversed` (the formula
prefers them in the opposite order to the measured KPI, so it is not history
evidence), `history_fitted` (its constants were set from those samples, declared
in `fitted_on`, so agreeing with them is not evidence either), `mechanism_only`
(they all tie) or `llm_judge`. Report verdicts as
the leaderboard gives them: `robust_surpass` needs two or more history sheets;
`surpass_one_sheet` means only one history sheet could judge it, so do not call
it robust; `tradeoff_surpass` names the mechanism that disagrees;
`conditional_surpass` holds only if the hypotheses in `conditional_on` hold.
Candidates may explore levers whose sheets are mechanism-only or judged; say that
their result is conditional. On the quantitative model's sheet a candidate is
better or worse only under every coefficient set the history allows, otherwise
undecided; settle undecided pairs by measuring a candidate from
`next_measurements`, not by choosing coefficients.
Candidates the sheets disagree on most are the most informative to measure;
with each hypothesis's predicted KPI and the measurement error, `calc` kind
`design` picks which ones tell the hypotheses apart best.

### Explore or exploit

Before scoring each round, record in that round's entry `"strategy": "explore"` or
`"exploit"`, the `levers` changed (for example `["catalyst"]`) and a short
`reason`. The board shows signals per evolution; they inform the choice, they do
not make it:

| signal | usually suggests |
|---|---|
| the goal is not met, scores still improve, candidates stay within the checked range | exploit |
| the best score stalled, candidates tie, or the proxy's maximum is reached | explore another lever or mechanism |
| candidates lie outside the checked range (the historical records, or where the model applies) | be cautious; prefer candidates robust on every sheet and say it is extrapolation |
| sheets disagree on the top candidates | report them as the most informative to measure |
| scores rest on very few records or uninformative judgments | do not over-exploit one proxy |
| the goal is met | stop early if the commission allows, or test robustness with the remaining rounds |
