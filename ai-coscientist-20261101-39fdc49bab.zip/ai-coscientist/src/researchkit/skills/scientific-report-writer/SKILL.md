---
name: scientific-report-writer
description: Compose or revise commissioned scientific reports from saved evidence: one report written for people, in Markdown, HTML and PDF, with notes and appendices for the details. Also supports scoped literature or methods reports.
---

# Scientific reporting

Follow the current commission. This skill presents existing research; it does
not select the next scientific responsibility, create missing research evidence
or add a whole-study prerequisite to a narrow report. Read
[the report delivery reference](references/report-delivery.md) when composing
or substantially revising a report; for a focused edit, read the relevant part.
Before declaring delivery complete, follow
[the shared completion discipline](../research-practice/references/evidence.md#continuation-and-completion).
File rendering and delivery checks do not replace the commissioned research review.

## Write for the reader

A person reads the report to learn the answer, why it holds and what to do
next. Order it by what they need, not by the order the work was done:

```markdown
## 摘要
## 1. 結論
## 2. 機制
## 3. 證據
## 4. 候選與建議實驗
## 5. 限制與未解問題
## 附錄 A. 研究過程與方法
```

Each heading may add a subtitle after a colon (`## 2. 機制：從可控輸入到量測指標`);
further `## 附錄 …` sections may follow. With these headings `render_report`
uses the reader layout and adds the notes, mechanism maps and saved originals as
appendices. Choose or combine sections for a narrower commission.

- 摘要: half a page with the question, the answer and its decisive numbers, how
  far it can be trusted, and the one measurement that would settle it.
- 1. 結論: answer the commission directly, saying for each claim whether it is
  measured, computed or inferred.
- 2. 機制: the physical story; see below.
- 3. 證據: what the measurements, if any, and the computations show and do not
  show: each proxy formula derived from the mechanism, its order against the
  measured history where there is one, calibration and scale checks, and review
  findings that changed a conclusion.
- 4. 候選與建議實驗: the candidates and why each was made, the predicted effect
  and its cost, the leaderboard verdicts as given, and which measurement is the
  most informative first.
- 5. 限制與未解問題: limits that change how the answer may be used, open
  questions, and hypotheses still queued (not yet evaluated, never "untestable").
- 附錄: how the study was run (data preparation, implementation, ranking rule,
  evolution rounds, versions and revisions, review exchanges), the internal
  evidence index and the external literature. Audit detail such as record hashes,
  file paths and superseded versions belongs here or in notes, never in the main text.

## The mechanism chapter

Explain how the system works before saying which hypotheses were tested, the
way a textbook chapter or the theory section of a paper would. Tell one causal
story from the controllable inputs to the measured KPI: name each physical or
chemical step, write the relation that governs it (define each symbol once;
LaTeX between `$…$` inline or `$$…$$` on its own line is drawn as an equation), and
put numbers in, from the data, the literature or an order-of-magnitude estimate,
saying which. Then place each hypothesis on that chain: which step it changes,
how far it could move the KPI, what competes with it, and which observation
would tell it apart from the others. Derive each proxy formula's terms and sign
from this chain instead of showing a formula and explaining it afterwards. Where
no quantitative relation is known, say so and give the direction with its
physical reason. For each surprising result, contradiction or trade-off, give
the mechanistic cause you propose, its expected size, the competing explanation
and what would separate them. Build on the mind map's routes and the reasoning
graph's `Insight:` conjectures, naming the route and step each one confirms or
breaks; do not invent mechanisms the research did not consider, and say plainly
where no explanation was found.

## Style

Write the way a sharp colleague explains the work to a smart reader from
another field, across a table: spoken, plain Traditional Chinese that reads
aloud naturally. A conversational tone is fine; the stiff register of official
documents (公文腔) is not. Keep identifiers, units, code and source quotations
exact, and keep every claim exactly as strong as its evidence: plain wording
neither loosens nor strengthens it, so a bound stays a bound and an estimate
stays an estimate.

The voice, shown on another field: 「這批樣品的電阻比預期高了三成。最可能的原因是燒結溫度不夠，晶粒沒長大，電子在晶界之間走得很辛苦。要確認不難：拿一片多燒半小時，電阻降下來就對了。」

- Say the point first, then why. Use short sentences, with a longer one where
  the reasoning needs it, so the rhythm varies; let each paragraph carry one
  line of reasoning.
- Explain a term in everyday words the first time it matters. Spoken does not
  mean without formulas: the mechanism chapter still writes each step's
  governing relation as an equation. Before or right after a formula, say in
  words what it means and which way the KPI moves when each quantity rises.
- Give each decisive number a meaning: compared with what, large or small, and
  what it changes for the reader.
- Take a clear position where the evidence allows one, and say plainly where it
  does not; one honest "we do not know" beats three hedges.
- Use tables for genuine comparisons and lists only for parallel items, never in
  place of the reasoning.
- Leave out the habits that make text read machine-written: stock phrases such
  as 值得注意的是、綜上所述、總而言之、事實上、換句話說、換言之、誠實、必須指出、原因很簡單、一句話總結;
  the frames 不僅……更……、不是……而是……、無論……還是……、讓我們……; stacked hedges;
  dashes (——) that string clauses together; bold for emphasis or as a label
  that opens a paragraph (「**背景。**」), since only a term at its definition is
  bold and a label becomes a heading or the paragraph's first sentence; and
  sentences about the report itself (「本節回應審查第 2 點」).
- Keep asides out of the main text. A side remark, a caveat that does not
  change the conclusion, a version detail, a file path or a record hash becomes
  a note: write `[^name]` where it applies and `[^name]: text` anywhere in the
  Markdown. The renderer shows a small superscript letter there and collects the
  notes in an appendix. Parentheses are for units, symbols and an abbreviation's
  first expansion.
- Cite the source of each consequential claim where the claim is made. Cite
  external literature as `[@key]` (several sources: `[@a; @b]`) and write one
  entry per key anywhere in the Markdown:
  `[@smith2019]: A. Smith and B. Lee, "Title of the paper," *Journal* 12(3), 45–67 (2019). doi:10.xxxx/yyyy`.
  Take every field from the saved search result or fetched document, and cite a
  paper only for what its saved text or abstract says. The renderer numbers the
  entries [1], [2] in order of first citation and lists them under 參考文獻 after
  the main text. Cite internal evidence as `[n](#evidence-n)`, shown as E1, E2.
  Notes use letters, so the three never mix.

`render_report` returns `style` counts (parentheses per thousand characters,
bold, stock phrases, hashes or paths in the prose) and `citations` (keys
without an entry, entries never cited, entries without a DOI or URL, and
entries matching no literature the research saved), each with advice. Resolve
the citation findings before delivering: retrieve and save the source, correct
the entry from the saved record, or drop the citation. The style counts are
counts, not a judgment of the science.

## One report, consistent with the saved work

Deliver one report in Markdown, HTML and PDF unless the user asks for another
version; the appendices carry the rigour that a separate technical version used
to. Read the selected task and the actual saved source versions before writing.
Preserve mechanism and hypothesis identities, complete relevant candidate
coverage, source roles and uncertainty. Distinguish observations, computations,
source claims, hypotheses and judgments, and saved selection reasons from your
own later interpretation.

Before rendering, check every section against the current saved versions: which
formula, which hypotheses it declares, which scores and evolution results. A
revision late in the work often leaves earlier sections describing the old
version. Saving a report or delivery returns a host digest of what it relies on;
compare it with the text, and address or answer the open board notices it lists.
When a leaderboard exists, report the Pareto front and each candidate's verdict
as given: robust (two or more history sheets), one-sheet, trade-off (and the
mechanism it loses on) or conditional ("if Hk holds", with the sheet's evidence
level, including a sheet reversed against the measured history). Never call a
one-sheet or conditional surpass robust, and never add sheets into a single total
score. Report the candidates the sheets disagree on most as the most informative
to measure.

Write Markdown, then use `render_report` for HTML and PDF. When delivering a
formal mechanism map, explicitly select its saved structured JSON through
`mindmap_files`; the renderer draws it in an appendix. Select saved original
text through `evidence_files` when readers need it: the originals are printed to
a separate `evidence.html` and `evidence.pdf`, and the report keeps only an
index. The reference explains the exact frozen-file semantics of both
selections. The renderer builds the reference list from the `[@key]:` entries
and the internal evidence index from the selected files; do not number either
by hand. Inspect the
rendered HTML and PDF, including notes, equations, maps, tables, Chinese glyphs
and the evidence file, and report any format or inspection that remains
unavailable.

When review is commissioned, review the report before rendering it. Save the
Markdown, with the evidence its conclusions rest on, as a `kind=report` record
and call `research_review` with that record in `reviewed_refs`, following
[the existing review instructions](../final-lca/references/review.md) to select
the underlying evidence. Carry the commissioned writing and source-support
questions into the actual review scope. The tool runs one assessment, saves the
review record itself and returns the checks that are not supported. Where a check is not supported,
revise the Markdown or state the limit in it; then render HTML and PDF and save
the delivered report as a new `kind=report` record that depends on the reviewed
draft. Deliver with `research_deliver`: the delivered report, the review
records, the decision and its scope, and one answer per check that is not
supported and per host check of the report (revised or limitation, quoting the
delivered text, or disputed with the reason). It writes the Final-LCA and the
`user_report`; the quoted answers carry the review over to the revised report,
so it needs no second review. Do not claim that a report has passed a review
that has not happened, and do not ask whether to save an already-authorized
review.

Save actual report sources and outputs with their evidence dependencies. Return
complete paths from the render receipt, conclusions, evidence scope, limitations
and verified formats. Report delivery alone does not prove scientific acceptance
or completion of the entire research workflow.
