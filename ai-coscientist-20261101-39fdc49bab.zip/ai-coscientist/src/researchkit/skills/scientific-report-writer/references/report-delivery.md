# Report delivery

## Scope, versions and evidence

Use the saved human request, constraints and selected research evidence to
determine what this report must answer. A literature comparison or methods
report does not need a mechanism map, proxy formula, candidate study or Final
LCA merely to be rendered. Missing evidence that the commission does require
is a stated limitation; unrelated stages are outside the report's scope.
Return needed new research to the active plan instead of silently expanding
report writing into another research workflow.

Actually read each source used for a consequential claim. For research records,
read the exact `record.json` manifest and the selected frozen snapshot. Match
its `files[].source_path`; snapshot paths in the manifest are relative to that
record directory. Do not select a latest version implicitly, reconstruct hashes,
or substitute a nearby file when a supplied reference does not resolve.
An index, render receipt, review score or later summary is not the underlying
scientific evidence. Preserve partial-read and unavailable-source limitations.

Explain which version of the request is being answered and why reused evidence
still applies. Distinguish evidence for the present question from historical
comparisons and claims not yet reassessed. An unchanged number or a shared
source does not establish unchanged methodology, interpretation or applicability.
Keep previous reports and saved artifacts intact; write revised reports to a
new delivery location.

Keep source measurements, program outputs, literature claims, author inferences,
hypotheses and review judgments distinct. Preserve negative results, ties,
excluded or missing cases and conflicting evidence. Where an upstream summary
differs from actual inputs or execution outputs, explain the difference and
its effect without rewriting the source. Report actual saved status and scope;
neither the existence of an artifact nor an author's release judgment proves
independent validation or overall task acceptance.

## Narrative coverage

Write for a person who wants the answer, the reason it holds and what to do
next, in the reader outline of the skill. Start each chapter with its point,
explain the physical reasoning in connected paragraphs, then show the evidence
and its limits. Use tables for genuine comparisons, not as a substitute for
explaining why a mechanism, formula or candidate was chosen. A readable tone
must preserve quantitative precision and uncertainty.

Report hypotheses still queued by the budget (`deferred`) as registered but not
yet evaluated, with their rank; do not present them as rejected, untestable or
tested.

`render_report` uses the reader layout when the level-two headings start with
these six, in this order (each may add a subtitle after a colon):

- 摘要
- 1. 結論
- 2. 機制
- 3. 證據
- 4. 候選與建議實驗
- 5. 限制與未解問題

`## 附錄 …` sections may follow; the renderer then appends the notes, the selected
`mindmap_files` and the selected `evidence_files` as further appendices. The
result states which layout it used and, for other headings, the first one that
differs. Reports written with the older nine process-order headings (摘要,
1. 研究命題與問題邊界 … 8. 證據索引與限制) still render in their original layout.

Choose or combine sections for the commission. Do not fill absent stages with
fabricated results or run new stages just to complete this outline. The details
below belong where the conclusions depend on them: the reasoning in the
mechanism and evidence chapters; the procedure (preparation, missingness,
versions and revisions, iteration coverage, implementation, ranking and stopping
rules) in 附錄 A; side remarks, file paths and record hashes in notes.

- Explain why the mechanism map separates its research families: which
  controllable property each family changes, which process carries that change
  to the measured outcome, and where families couple or compete. Then explain
  what each hypothesis predicts, the physical premise behind that prediction,
  the alternative explanation and the observation that could distinguish them.
  Preserve source identities, complete relevant coverage and declared links.
- Distinguish a scientific argument reconstructed from saved evidence from a
  recorded historical reason for choosing a method. A later map that depends
  on an existing formula is not proof that the map originally produced it.
  When a choice's rationale was not saved, say so rather than inventing the
  researcher's thought process.
- Present the complete candidate set relevant to the reported comparison,
  including actual parameters, units, values, exclusions and missing results.
  State which variables distinguish candidates and which design details are
  unspecified. A different represented input does not by itself establish
  scientific novelty or full design equivalence. Preserve consequential ties;
  a proxy ranking alone does not prove improvement in the target outcome.
- Walk from the measured quantity to each formula term: why that observable
  stands in for the quantity, why the sign and functional form are appropriate,
  how units and reference scales work, and where that approximation can fail.
  Separate a qualitative direction from a justified coefficient value. State
  the saved basis for constants, exponents and thresholds; if no quantitative
  basis exists, identify the modeling assumption instead of retrofitting a
  derivation. Explain missing terms and omitted competing mechanisms.
- Connect the selected formula to the actual implementation, exact inputs,
  execution outputs and ranking or selection rule. Explain the computation in
  prose before linking its complete code. A code listing shows an implementation,
  not proof that it ran or faithfully represents the scientific method.
  Keep formula comparisons, review opinions and candidate rankings distinct.
- For sample evolution, explain which variable changed, what physical effect
  it is meant to probe, what stayed fixed and what tradeoff remains unmeasured.
  Distinguish an algebraic optimum under the chosen proxy from an independent
  discovery. Explain the saved selection and stopping rules; do not invent why
  particular parameter values were originally proposed.
- Explain preparation, missingness, exclusions and source roles that affect the
  comparison. State actual iteration coverage and method changes across
  versions, including changes to formulas, transformations or ranking rules.
  Retaining old outputs does not establish a frozen evaluation.
- Disclose whether observed targets informed formula design, parameter choices
  or selection. Distinguish calibration from independent validation and identify
  which actual records support each. A manual comparison is not evidence that
  a named calibration tool executed. A missing validation result limits the
  conclusion; it is not permission to report a passing result or zero score.

## Mechanism maps from exact structured content

When the report delivers a formal mechanism map, select its exact saved
`mindmap.json` using `render_report.mindmap_files`. Each selection contains only
the nonblank `record_ref` and exact `files[].source_path` from an existing
`kind=mindmap` record. Do not duplicate a pair; preserve the intended map order.
The selected JSON must have the approved seven-field mind-map content: `title`,
`landscape_summary`, `target_model`, `families`, `supported_relationships`,
`unresolved_gaps` and `evidence_boundary_summary`. Maps saved in the earlier
format (families without `target_model` and route steps) cannot be drawn; they
may still be included as text through `evidence_files`.

```json
{
  "markdown_path": "<authored report Markdown path>",
  "mindmap_files": [
    {
      "record_ref": ".research/records/<exact saved hash>/record.json",
      "source_path": "<exact source_path of the structured map in that record>"
    }
  ]
}
```

The renderer verifies the frozen source's path, permissions, SHA-256, byte count
and UTF-8 content, then uses that same content for the graph and the full route
cards: the target model, each route's principle, levers, ordered steps, effect on
each target observable, side effects, prerequisites, early check, bottleneck,
failure mode, relationship explanations, gaps and evidence boundaries. Both HTML and PDF
must include the graph and complete text. Show the record title, exact record
reference, original source path and stored hash so the presented map can be
traced to its version.

Each graph column is one author-declared route: levers → ordered steps →
effect on the target observables, with risks on separate branches and only
explicit one-way or two-way route relationships. Routes marked outside the task
are drawn and labelled as such. Check route count, IDs and order, relationship
directions and explanations, and that each route's last step reaches a target
observable. The author owns any scientific correction; drawing does not
infer causal links, fill gaps or make a second scientific account. A palette's
number of colors does not determine the number of families.

Omitting `mindmap_files` or passing `[]` draws no structured map. This supports
reports whose scope does not include a map; it does not make drawing optional
when delivering a cited formal map. A malformed or historical Markdown-only
selection fails explicitly. Do not find a neighboring JSON file, choose a newer
version, guess structure from prose or fall back to text while claiming that
the map was drawn. Historical Markdown may still be included unchanged through
`evidence_files`, with its representation limit stated.

`evidence_files` keeps its complete original-text appendix meaning. The two
arrays may explicitly select the same pair to show both the rendered map and
its original JSON, using the same verified content. Neither selection expands
dependencies automatically or changes a reviewer's access. Other figures may
use supported Markdown image syntax with actual accessible files and a checked
relationship to the text.

## Sources and the complete evidence appendix

Cite each consequential claim where it is made. External literature uses
`[@key]` in the text (several sources: `[@a; @b]`) and one entry per key,
written anywhere in the Markdown, with continuation lines indented four spaces:

```markdown
[@smith2019]: A. Smith and B. Lee, "Title of the paper," *Journal* 12(3), 45–67 (2019). doi:10.xxxx/yyyy
```

The renderer numbers the entries in order of first citation, shows each
citation as a superscript [1] or [1–3] linked to its entry, and lists the
entries under 參考文獻 after the main text and before the appendices; a
`## 參考文獻` heading the author writes receives the list instead. Internal
research evidence (saved task, method, code, execution and review records) is
cited as `[n](#evidence-n)` with the numbers of the selected `evidence_files`,
shown as E1, E2, and indexed in an appendix. The author chooses which source
supports which claim and writes each entry; the renderer does not infer either.

Write each entry from the saved record of that exact DOI or URL: authors,
year, title, venue, volume, pages, and the DOI or URL. The receipt's
`citations` lists keys without an entry, entries never cited, entries without
a DOI or URL, and entries whose DOI or URL matches no saved search result,
fetched document or literature-agent answer. A paper known only from memory is
not a source: retrieve and save it first, or leave it out.

Side remarks are notes, not parentheses: write `[^name]` where a remark
applies and `[^name]: text` anywhere in the Markdown. The renderer shows a
superscript letter (a, b, c …) at that point, so notes never look like the
numbered citations, and collects the notes with links back into an appendix.
Remove citation-only path, hash and author-year parentheses from the prose;
keep parentheses for units, symbols and an abbreviation's first expansion.
Keep exact paths, hashes and file versions in the internal evidence entries
or in notes. Write "Smith and Lee showed …[@smith2019]" rather than an
author-year parenthesis.

Verify external attribution against saved provider metadata for that exact
DOI or URL; distinguish metadata, excerpts, abstracts and full text. A paper's
presence in a search result does not establish support for a mechanistic claim.
Where only a title was available, do not supply an unread paper's conclusion.
Check that every citation resolves in HTML and remains clickable in PDF, and
that every listed source has an actual role in the report. A delivery
note can link the report and its appendix without changing an already-reviewed
report merely to cite its own export.

Use `render_report` with the existing `markdown_path` and the approved optional
`evidence_files` selection when attaching saved originals:

```json
{
  "markdown_path": "<authored report Markdown path>",
  "evidence_files": [
    {
      "record_ref": ".research/records/<exact saved hash>/record.json",
      "source_path": "<exact files[].source_path from that manifest>"
    }
  ]
}
```

Each selection contains only `record_ref` and `source_path`; use nonblank exact
values and no duplicate pair. Select the full UTF-8 source files needed to
inspect the report's methods and evidence, including complete implementation
files where implementation is discussed. List them in the intended order.
The tool resolves the frozen snapshots, checks their stored identity, prints
their complete text to a separate `evidence.html` and `evidence.pdf` beside the
report, and keeps only an index (record, path, hash, link) in the report, so
the report stays readable however long the originals are. Do not transcribe long programs
or original artifacts into Markdown, use hidden Markdown markers to trigger
file loading, or assume that cited dependencies are included automatically.

Omitting `evidence_files` or passing `[]` produces no evidence file and no index.
Unreadable, non-text, unauthorized, mismatched or invalid selections must be
resolved explicitly; do not silently omit them, cut their content or substitute
another version. Binary figures belong in the authored report through supported
image syntax, not this text-only selection. The renderer displays source
content; it does not execute attached code, judge its scientific meaning or
establish that its claims are verified.

The evidence files show every original expanded, in HTML and PDF. Verify the
index in the report and the actual evidence title, kind, exact record
reference, original path, stored SHA-256 and complete content in the evidence
files. Preserve
the distinction between original source text and the report's interpretation.
The selection for rendering and the selection for review are separate decisions:
adding an appendix does not expand a reviewer's evidence access.

## One report

Deliver one report unless the user asks for another version. Its main text is
written for people; the appendices and notes keep the rigour (procedure,
versions, exact sources) that a separate technical version used to carry, so
there is one set of numbers and judgments to keep consistent. When the user
does ask for a second, shorter version, render the full report first, read its
receipt, and link the shorter one to that HTML; each `render_report` call
creates a different output directory, so do not guess a sibling folder. Write
local Markdown links relative to the Markdown file, keeping the exact target
fragment; the renderer rebases them. A shorter presentation is not another
scientific conclusion or an independent assessment.

## Review and delivery status

When the commission includes review, use the existing
[review instructions](../../final-lca/references/review.md) and
[review format](../../final-lca/references/review-format.md).
Select the exact report and sufficient underlying files for the consequential
claims using the existing `research_review.scope`, `reviewed_refs` and `files`.
Depending on those claims, these may include the original request and
constraints, mechanism map, complete hypotheses and candidates, formula,
implementation, numerical inputs, execution outputs and revision history.
Translate the current commission and the actual draft into questions in `scope`,
not the author's desired findings. Where relevant to the requested report, ask
whether each causal explanation connects the chosen physical property to the
outcome, whether formula directions and numerical coefficients have distinct
support, and whether candidate choices have saved reasons or are explicitly
the author's later interpretation. Ask whether the cited source actually
supports the adjacent claim at the available access level; matching a title,
number or earlier summary alone does not settle these questions.

Select both exact manuscripts when the delivery will describe both as reviewed,
even if they belong to the same record. Select the hypotheses, map, formula,
implementation, candidate history and original source responses needed for the
questions, within the existing size limit. If only a literature synthesis is
available, explicitly bound the commission to that synthesis rather than claim
the underlying paper was checked. Mechanical superscript/link checks belong to
render inspection; the review assesses scientific support and explanation.

The separate reviewer receives only the selected frozen files. Report prose
and an evidence index cannot stand in for unselected originals. If raw evidence
is unavailable or not selected, make the affected coverage limit explicit in
the existing checks and reasons; do not describe an indirect read as verification
of all sources. Use existing review decisions rather than adding fields,
statuses, checkers or a fixed number of checks.
After receiving the result, compare its actual checks and reasons with the
questions commissioned for each manuscript. Carry unanswered questions and
unsupported source coverage into the existing Final-LCA and delivery prose;
a count of supported checks does not establish complete report coverage.

Describe already-saved judgments with their actual scope. A report prepared
before its own review cannot say that review has passed. Keep that exact report
unchanged while saving its authorized review and Final LCA; use the existing
delivery note to link all three and state the resulting release scope.
This avoids a report changing merely to cite the review of itself.
For the same reason, do not write a delivery's own record hashes into files of
that delivery: changing the file changes the record, so the written hash is
stale again. The saved user_report receipt and the host's listing of saved
delivery work identify the delivery; refer to them instead of copying hashes. A substantive
report revision must receive only the review coverage actually applicable to
that revised version, as described by the existing review instructions.

## Render, inspect and hand off

Render HTML and PDF from the selected Markdown using the local Python
`render_report` tool. It prints the same saved HTML with an installed
Chromium, Chrome or Edge; it does not download a browser. Printing has a
120-second timeout and zero retries. A missing browser or export failure is an
explicit error. Preserve the research and any generated HTML while diagnosing
a presentation failure. Keep prior deliveries unchanged.

Inspect actual HTML at desktop and narrow widths and actual rendered PDF pages
when the authorized local tools support those views. Use available PDF/image
viewing tools; this skill does not grant a browser or other new capability.
Text extraction and a successful tool call alone do not establish visual
quality. Check Chinese glyphs, equations, headings, tables, figures, code
wrapping and page breaks. Check navigation from the body to the evidence index
and on to the original in evidence.html, and notes with their links back to the
text. Verify that
evidence.pdf retains every original in full, including long code and final
entries.

For every selected mechanism map, inspect the actual graph and full text in
both outputs. Check arrows, risk branches, long-label wrapping and the last
family; PDF page breaks must not crop content. Multiple maps must remain
separate with their source identities and input order intact. A successful
render call or extractable PDF text alone does not prove these checks.

If an output or visual inspection is unavailable, deliver only what exists and
state precisely what remains unverified. Do not call a missing PDF complete or
claim an unseen page is readable. Record actual Markdown, HTML and PDF files
using existing `files` and `depends_on`; no new artifact format is needed.

Return the actual complete paths copied from the render receipt, including full
hash directories. Explain the answer, evidence scope, actual review status and
remaining limitations. State which outputs and checks were completed, what was
not proven, and any remaining failing handoff or test gap. Separate report
delivery from scientific acceptance and whole-workflow completion.
