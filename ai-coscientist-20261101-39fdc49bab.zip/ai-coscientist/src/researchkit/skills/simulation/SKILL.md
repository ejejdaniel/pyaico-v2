---
name: simulation
description: Generate computed evidence with framework-written simulation routes (research_simulate), and cite it with its model assumptions and applicability.
---

# Simulation

A route is a simulation the framework has already written: a force field, a
molecular dynamics run, an interconnect or circuit model, a lithography imaging
model, an optimizer benchmark. You choose a route, fill its inputs and read the
result. Routes are addressed `<object>.<quantity>.<method>`, for example
`molecule.energetics.rdkit_mmff_conformers`: the research object, the quantity it
computes, and the method.

## When it is worth running

Simulate when a step of a route of action or a hypothesis needs a quantity that
the task data, the literature you read and `calc` cannot give, and a model of the
system can. Examples of such questions: how flexible two candidate molecules are,
how a wire's delay changes with spacing, whether a pitch still images at a given
NA, whether a modified optimizer beats its baseline. Do not simulate what is
already measured, and do not use a simulation as a substitute for the task's
measured target.

## How to use it

1. `research_simulate` with `{"action": "catalog"}` lists the taxonomy and the
   routes, and this task's own tools; filter routes with `object`, `quantity`
   or `discipline`.
2. `{"action": "describe", "route": "<id>"}` gives the inputs (JSON schema with
   defaults), outputs with units, assumptions, applicability, uncertainty,
   references and an example. Read the applicability and assumptions and decide
   whether they fit your system before running.
3. `{"action": "run", "route": "<id>", "input": {...}}`. Add `depends_on` with
   the record.json paths your inputs came from, and `time_limit_s` (default 120,
   at most 600) for longer runs.

The host checks the inputs, refuses runs outside the route's applicability or
over the time limit, and runs the route in a separate process. Every run is saved
automatically as a `kind=simulation` record whose `result.json` holds the route
and version, status, filled inputs and seed, values with units, assumptions,
applicability, uncertainty, warnings, environment and artifacts (images,
structures, tables). You do not save it again.

Statuses: `completed`, `refused` (missing package, outside applicability, too
large for the local limit), `failed` (the route raised an error), `timeout`.
Refused and failed runs are records too: a report lists the runs it relied on,
including the ones that did not work, and never cites only the favourable ones.

## Reading and citing results

- A simulation result is computed evidence from a model, not a measurement and
  not validation. Cite the record with the route, the assumptions that matter for
  your claim, and the uncertainty.
- Read every warning. A warning about applicability, convergence, finite size or
  a non-diffusive regime limits what the value can support; say so where you use
  it.
- Compare like with like: for example, absolute force-field energies of different
  molecules are not comparable, while conformer energies of one molecule are.
- Stochastic routes take a `seed`. When a conclusion depends on a small
  difference, rerun with other seeds or a larger size and report the spread.
- A simulated quantity can be an input of a proxy formula. Make the
  `proxy_formula` or implementation record depend on the simulation records it
  uses, so the board and the review can trace it.

## When no route fits: a task tool

When the task needs a quantity that no route computes and a model of the
system can, write the route yourself as a task tool. It belongs to this task:
it lasts through every round of this session and your subagents can use it;
another task does not see it.

1. The catalog's `task_tools.folder` is this task's tools folder. In it,
   `<name>/route.py` declares `ROUTE = Route(id="task.<quantity>.<name>", ...)`
   with `from researchkit.simulation.route import Route`, as the framework's
   routes do: inputs as a JSON schema, outputs with units, assumptions,
   applicability, uncertainty, an example, `run(inputs, workdir)` returning
   `{"values": {output: number or list}, "artifacts": [files it wrote in
   workdir]}` and, where it has limits, `check(inputs)` returning the problems
   that keep it from running. `<name>` is the folder's name and `<quantity>`
   one lowercase word for what it computes. Modules it imports sit in the same
   folder.
2. Beside it, `tests.json` lists known-answer tests: inputs whose answer comes
   from an independent source, such as an analytical solution, a limiting case
   or a published example, not from the tool itself.
   `[{"name": ..., "input": {...}, "expect": {"<output>": {"value": ...,
   "tolerance": ...}}, "source": "where the answer comes from"}]`; use
   `relative` instead of `tolerance` for a fraction. At least one is required.
3. `{"action": "mount", "tool": "<name>"}` reads the declaration, runs every
   test and saves the outcome as a `kind=task_tool` record, mounted or refused
   with the reason. Then describe and run it by its id like any route; each run
   is a `kind=simulation` record that depends on the mount record.

Runs use the mounted copy. After changing the tool, mount it again: that is a
new version with its own record, and earlier results stay with the earlier
version. Say so wherever results of two versions are compared.

A task tool computes quantities; it does not change what the commission asks
for or how it is judged. It runs in a separate, time-limited process, which is
not a security sandbox; it should not use the network.

A tool can write a values table in `workdir`, one row per sample (for example
`values.json`), and list it in `artifacts`. The run returns
`artifact_selections`; with a `column`,
the ranking tools (`research_history_check`, `research_leaderboard`,
`research_compare_candidates`) take one as their `values` when the run's
`depends_on` lists the formula records.

## Algorithms as the object of study

`algorithm.performance.optimizer_benchmark` runs optimizers you wrote in the
workspace against built-in baselines over seeds with a fixed evaluation budget.
The record keeps your code file and its hash. The test functions are synthetic:
a result there is evidence about the algorithm, not about the real problem. The
code runs in a time-limited process, not a security sandbox.

## Expensive simulations

Routes have a tier: T1 analytical, T2 semi-empirical or fast numerical (local),
T3 first-principles or large runs. T3 routes need the human's approval and a job
executor that is not available yet. When a valuable direction needs one, write
what you would run and why as a question for the human instead of approximating
it silently with a lower tier.
