"""Read-only, session-scoped native source handling for research publication/review.

The Store owns message identity and content. Workspace history files are only
projections; neither their names nor a publisher's claims authenticate content.
"""

from __future__ import annotations

from collections import defaultdict, deque
from copy import deepcopy
import json
from pathlib import Path, PurePosixPath
import re

from opencode.tools import builtin_tools
from opencode.tools.types import external_source_names
from opencode.tools.util import ensure_access
from researchkit.records import local_path


_MESSAGE_ID = re.compile(r"msg_[A-Za-z0-9_-]+\Z")


def _json_bytes(value) -> bytes:
    # Match the existing Store projection, including escaped lone surrogates.
    return json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8", errors="backslashreplace")


def _locator(source_path: str):
    parts = PurePosixPath(source_path).parts
    if len(parts) < 2 or parts[0] != ".opencode":
        return None
    if parts[1] == "sources" and len(parts) >= 4:
        session, lane, tail = parts[2], "sources", parts[3:]
    elif (parts[1] == "history" and len(parts) >= 5
          and parts[3] in {"conversation", "tools"}):
        session, lane, tail = parts[2], parts[3], parts[4:]
    else:
        return None
    # Generated indexes remain ordinary selectable documents.
    if tail == ("index.md",) or tail[0] == "by-tool":
        return None
    path = PurePosixPath(tail[-1])
    if (len(tail) != 1 or not _MESSAGE_ID.fullmatch(path.stem)
            or path.suffix not in ({".json"} if lane == "conversation" else {".json", ".txt"})):
        raise ValueError(f"Invalid native source locator: {source_path}")
    return session, lane, path.stem, path.suffix


def _snapshot_origin():
    return {"status": "snapshot_only", "content": "file", "session_id": None,
            "message_id": None, "call_message_id": None, "tool_call_id": None,
            "tool_name": None, "truncated": None}


def _parse_json(data: bytes, source_path: str):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"Duplicate JSON key {key!r}")
            result[key] = value
        return result

    def invalid_constant(value):
        raise ValueError(f"Invalid JSON constant {value}")

    try:
        return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs, parse_constant=invalid_constant)
    except (UnicodeDecodeError, ValueError) as exc:
        raise ValueError(f"Native source {source_path}: {exc}") from exc


def _difference(expected, actual, at="$"):
    if type(expected) is not type(actual):
        return f"{at}: value type differs"
    if isinstance(expected, dict):
        if set(expected) != set(actual):
            return (f"{at}: fields differ (missing={sorted(set(expected) - set(actual))}, "
                    f"unexpected={sorted(set(actual) - set(expected))})")
        for key in expected:
            difference = _difference(expected[key], actual[key], f"{at}.{key}")
            if difference:
                return difference
    elif isinstance(expected, list):
        if len(expected) != len(actual):
            return f"{at}: item count differs"
        for index, (left, right) in enumerate(zip(expected, actual)):
            difference = _difference(left, right, f"{at}[{index}]")
            if difference:
                return difference
    elif expected != actual:
        return f"{at}: value differs"
    return None


def _without_compacted(receipt, counterpart):
    # Only this precise presentation marker is ignored. All other metadata,
    # failure states, arguments and message fields remain part of the comparison.
    if isinstance(receipt, list) and len(receipt) == 2 and isinstance(receipt[1], dict):
        reply = receipt[1]
        if isinstance(reply.get("metadata"), dict):
            metadata = reply["metadata"]
            reply = {**reply, "metadata": {key: value for key, value in reply["metadata"].items()
                                           if key != "compacted"}}
            if (set(metadata) == {"compacted"} and isinstance(counterpart, list) and len(counterpart) == 2
                    and isinstance(counterpart[1], dict) and "metadata" not in counterpart[1]):
                # mark_tools_compacted may create this otherwise absent container.
                # Empty/missing metadata without that marker is still compared.
                del reply["metadata"]
        return [receipt[0], reply]
    return receipt


class NativeSources:
    def __init__(self, ctx, *, history=None):
        self.ctx = ctx
        self.root = ctx.directory.resolve()
        self.session_id = getattr(ctx, "session_id", None)
        self._messages = None
        self._pairs = None
        self._external = None
        self._history = deepcopy(history) if history is not None else None

    def _load(self):
        if self._messages is not None:
            return
        history = self._history if self._history is not None else deepcopy(self.ctx.app.store.messages(self.session_id))
        self._history = history
        self._messages = {message["id"]: message for message in history}
        calls = defaultdict(deque)
        self._pairs = {}
        for message in history:
            if message.get("role") == "assistant":
                for call in message.get("tool_calls") or []:
                    calls[call["id"]].append((message, call))
            elif message.get("role") == "tool":
                pending = calls[message.get("tool_call_id")]
                if pending:
                    self._pairs[message["id"]] = pending.popleft()

    def selected_receipts(self, call_ids, *, check_read=None):
        """Resolve explicit, unique call/reply identities from one history snapshot.

        Unlike publication of retained external text, this selection preserves
        only the saved reply content and never follows outputPath or file names.
        The caller supplies source access checks; read-only audits can use the
        already scoped history without invoking the permission broker.
        """
        self._load()
        selected = []
        for call_id in call_ids:
            calls = [(message, call) for message in self._history if message.get("role") == "assistant"
                     for call in message.get("tool_calls") or [] if call.get("id") == call_id]
            replies = [message for message in self._history
                       if message.get("role") == "tool" and message.get("tool_call_id") == call_id]
            if len(calls) != 1 or len(replies) != 1:
                raise ValueError(f"tool_call_ids {call_id!r}: expected one unique saved call and reply in current session")
            owner, _ = calls[0]
            reply = replies[0]
            if sum(message.get("id") == reply.get("id") for message in self._history) != 1:
                raise ValueError(f"tool_call_ids {call_id!r}: reply message identity is not unique")
            if sum(message.get("id") == owner.get("id") for message in self._history) != 1:
                raise ValueError(f"tool_call_ids {call_id!r}: call message identity is not unique")
            receipt = self._receipt(reply["id"])
            if receipt[0]["id"] != owner["id"]:
                raise ValueError(f"tool_call_ids {call_id!r}: call/reply pairing differs")
            # The tool-history lane preserves exactly the stored text, including
            # failed/truncated replies, for both local and external tools.
            path = self.root / f".opencode/history/{self.session_id}/tools/{reply['id']}.json"
            if local_path(self.root, str(path)) != path:
                raise ValueError(f"tool_call_ids {call_id!r}: native source path was redirected")
            _locator(path.relative_to(self.root).as_posix())
            pair = [(path, _json_bytes(receipt)),
                    (path.with_suffix(".txt"), (reply.get("content") or "").encode("utf-8"))]
            selected.extend(pair)
        # Validate every ID before any access check or persistence side effect.
        if check_read:
            for path, _ in selected:
                check_read(path)
        return selected

    def _external_names(self):
        if self._external is None:
            from opencode import deep
            self._external = external_source_names([*builtin_tools(), *deep.tools(self.ctx.app)])
        return self._external

    def _message(self, message_id: str):
        self._load()
        message = self._messages.get(message_id)
        if message is None:
            raise ValueError(f"Native source {message_id}: no message in current session {self.session_id}")
        if message.get("sessionID") != self.session_id:
            raise ValueError(f"Native source {message_id}: sessionID differs from current session")
        return message

    def _conversation(self, message_id: str):
        message = self._message(message_id)
        if message.get("role") not in {"user", "assistant", "system"}:
            raise ValueError(f"Native source {message_id}: conversation role mismatch")
        if message.get("role") == "assistant" and message_id == getattr(self.ctx, "message_id", None):
            raise ValueError(f"Native source {message_id}: current assistant message is still being written")
        return {key: value for key, value in message.items() if key not in {"reasoning", "reasoning_content"}}

    def _receipt(self, message_id: str):
        reply = self._message(message_id)
        if reply.get("role") != "tool":
            raise ValueError(f"Native source {message_id}: tool reply role mismatch")
        pair = self._pairs.get(message_id)
        if pair is None:
            raise ValueError(f"Native source {message_id}: no preceding paired tool call")
        owner, call = pair
        if owner.get("sessionID") != self.session_id or owner.get("role") != "assistant":
            raise ValueError(f"Native source {message_id}: tool call owner/session mismatch")
        if not call.get("id") or call.get("id") != reply.get("tool_call_id"):
            raise ValueError(f"Native source {message_id}: tool call ID mismatch")
        if not call.get("name") or call.get("name") != reply.get("name"):
            raise ValueError(f"Native source {message_id}: tool name mismatch")
        content = reply.get("content")
        if content is not None and not isinstance(content, str):
            raise ValueError(f"Native source {message_id}: tool content is not text")
        metadata = reply.get("metadata")
        if metadata is None:
            metadata = {}
        if not isinstance(metadata, dict):
            raise ValueError(f"Native source {message_id}: tool metadata is not an object")
        if "truncated" in metadata and not isinstance(metadata["truncated"], bool):
            raise ValueError(f"Native source {message_id}: truncated must be a boolean when present")
        return [{"id": owner["id"], "role": "assistant", "tool_calls": [call]}, reply]

    def _checked_path(self, path: Path):
        path = local_path(self.root, str(path))
        ensure_access(self.ctx, path, "read")
        return path

    def resolve_reference(self, reference: str) -> list[tuple[Path, bytes]]:
        if not _MESSAGE_ID.fullmatch(reference):
            return []
        message = self._message(reference)
        if message.get("role") == "tool":
            if message.get("name") in self._external_names():
                path = self.root / ".opencode" / "sources" / self.session_id / f"{reference}.json"
            else:
                path = self.root / ".opencode" / "history" / self.session_id / "tools" / f"{reference}.json"
        else:
            path = self.root / ".opencode" / "history" / self.session_id / "conversation" / f"{reference}.json"
        return self.resolve_path(path)

    def resolve_path(self, path: Path) -> list[tuple[Path, bytes]] | None:
        path = local_path(self.root, str(path))
        locator = _locator(path.relative_to(self.root).as_posix())
        if locator is None:
            return None
        session, lane, message_id, _ = locator
        if session != self.session_id:
            raise ValueError(f"Native source {path}: cross-session publication is not allowed")
        if lane == "conversation":
            return [(self._checked_path(path), _json_bytes(self._conversation(message_id)))]
        receipt = self._receipt(message_id)
        output = (receipt[1].get("content") or "").encode("utf-8")
        json_path, text_path = self._checked_path(path.with_suffix(".json")), self._checked_path(path.with_suffix(".txt"))
        metadata = receipt[1].get("metadata") or {}
        if lane == "sources" and metadata.get("truncated"):
            full_output = metadata.get("outputPath")
            if not isinstance(full_output, str) or not full_output:
                raise ValueError(f"Truncated source {message_id} has no full output path")
            full_path = Path(full_output)
            if not full_path.is_absolute():
                full_path = self.root / full_path
            full_path = full_path.resolve()
            # Retained output may live in Common's output directory; its existing
            # file permission is separate from workspace-local receipt permissions.
            ensure_access(self.ctx, full_path, "read")
            output = full_path.read_bytes()
        return [(json_path, _json_bytes(receipt)), (text_path, output)]

    def origins(self, selected: dict[tuple[str, str], bytes]) -> dict[tuple[str, str], dict]:
        origins = {key: _snapshot_origin() for key in selected}
        locators = {key: _locator(key[1]) for key in selected}
        receipts = {}
        for key, locator in locators.items():
            if locator is None or locator[0] != self.session_id or locator[3] != ".json":
                continue
            _, lane, message_id, _ = locator
            actual = _parse_json(selected[key], key[1])
            if lane == "conversation":
                expected = self._conversation(message_id)
            else:
                expected = self._receipt(message_id)
                actual, expected = _without_compacted(actual, expected), _without_compacted(expected, actual)
            difference = _difference(expected, actual)
            if difference:
                raise ValueError(f"Native source {key[1]}: {difference}")
            if lane == "conversation":
                origins[key].update(status="message_match", content="message", session_id=self.session_id,
                                    message_id=message_id)
            else:
                receipts[key] = expected
                origins[key] = self._tool_origin(expected, "receipt")
        for key, locator in locators.items():
            if locator is None or locator[0] != self.session_id or locator[3] != ".txt":
                continue
            paired = (key[0], str(PurePosixPath(key[1]).with_suffix(".json")))
            if paired not in receipts:
                continue
            receipt = receipts[paired]
            if selected[key] == (receipt[1].get("content") or "").encode("utf-8"):
                origins[key] = self._tool_origin(receipt, "stored_text")
            elif locator[1] == "sources" and (receipt[1].get("metadata") or {}).get("truncated") is True:
                origins[key].update(content="retained_text", truncated=True)
            else:
                raise ValueError(f"Native source {key[1]}: stored tool text bytes differ")
        return origins

    def _tool_origin(self, receipt, content):
        call, reply = receipt
        return {"status": "tool_match", "content": content, "session_id": self.session_id,
                "message_id": reply["id"], "call_message_id": call["id"],
                "tool_call_id": reply["tool_call_id"], "tool_name": reply["name"],
                "truncated": (reply.get("metadata") or {}).get("truncated")}


def origin_notice(source_path: str, origin: dict, session_id: str) -> str:
    """Fixed host interpretation, not a citable observation or scientific verdict."""
    if origin["content"] == "retained_text":
        return "Paired receipt matched; this retained full text has only frozen-content verification, not verification of all bytes originally returned."
    if origin["status"] == "message_match":
        return ("Matched a host-saved conversation message; role and synthetic/draft/interruption markers remain in its JSON. "
                "User role means saved conversation input, not authenticated human authorship; assistant content is an agent statement, not execution evidence.")
    if origin["status"] == "tool_match":
        return ("Matched a native call/reply or stored reply text; inspect the actual tool, arguments, return and failure/completeness metadata. "
                "This authenticates the saved return, not successful execution, scientific truth or independent review. "
                "A read return does not authenticate events asserted in the text it read; a review return is a judgment, not a new observation.")
    locator = _locator(source_path)
    cross_session = " Native source belongs to another session and was not checked across sessions." if (
        locator is not None and locator[0] != session_id) else ""
    return ("Only frozen content was verified; source authorship was not checked. This does not prove that an execution never occurred."
            + cross_session)
