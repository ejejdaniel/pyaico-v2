"""What every task gets around the working agent, however it is started (scripts/run_tui.py, co-scientist).

The loop (opencode/loop.py) calls two hooks on the app: the verification plan before the first step
(opencode/verification.py) and the review a stalled round pauses for; and a round ends with the review of
the round (opencode/round_review.py). All three are scoped model calls by the reviewer on the task's model.
They are the same in every task, interactive or unattended, light or long.

A test run watches them: guard() tells why a reviewer must not write now (the rest of the run's meta region
changed), and wrote(kind, record) adopts what a reviewer wrote and saves its record.
"""

from __future__ import annotations

from pathlib import Path
import threading
import time
from types import SimpleNamespace

from opencode.deep import skills as installed_skills

# Folders that are the framework's, not the task's, when a folder's files are taken as the task's sources.
NOT_SOURCES = {".git", ".opencode", ".research", ".task", "__pycache__", "node_modules"}


def model_call(app, session_id):
    """One scoped call on the task's model, for a reviewer. It has its own abort signal: a stage stop aborts
    the session before the review runs."""
    from researchkit.review_provider import complete_once, generation_schema

    session = app.store.get_session(session_id)
    agent = app.agents.get(session.get("agent") or "") or app.agents["build"]
    ctx = SimpleNamespace(app=app, session_id=session_id, agent=agent, directory=Path(app.directory),
                          worktree=Path(app.directory), abort=threading.Event())
    frozen = {}

    def complete(system, message, schema):
        name, value = schema
        return complete_once(ctx, system=system, messages=[{"role": "user", "content": message}], frozen=frozen,
                             response_schema=(name, generation_schema(value)))

    return complete


def task_sources(directory, limit: int = 200) -> list[str]:
    """A folder's own files, relative and sorted, outside the framework's folders: the task's sources when
    nothing else names them."""
    directory = Path(directory)
    found = []
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory)
        if path.is_file() and not (set(relative.parts) & NOT_SOURCES):
            found.append(relative.as_posix())
            if len(found) >= limit:
                break
    return found


def _humans(store, session_id: str) -> list[dict]:
    return [m for m in store.messages(session_id)
            if m.get("role") == "user" and not m.get("synthetic") and not m.get("compaction_through")]


def first_request(store, session_id: str) -> str:
    """The commission: the session's first human message."""
    humans = _humans(store, session_id)
    return str(humans[0].get("content") or "") if humans else ""


def latest_request(store, session_id: str) -> str:
    """This round's request: the session's latest human message."""
    humans = _humans(store, session_id)
    return str(humans[-1].get("content") or "") if humans else ""


def top_session(app) -> str | None:
    """The task's session when the app holds exactly one top session (a fresh unattended run)."""
    tops = [item["id"] for item in app.store.list_sessions() if item.get("parentID") is None]
    return tops[0] if len(tops) == 1 else None


def round_review(app, root, *, workspace, moment="at the end of the round", model=None, **facts) -> dict:
    """The review at the end of a round, or when a stalled round pauses for one (opencode/round_review.py).
    model(app, session_id) gives the reviewer's model call (default: model_call, looked up when it runs).
    A failure is recorded, not raised: the round's own result stands either way."""
    from opencode import round_review as reviews

    try:
        if root is None:
            root = top_session(app)
            if root is None:
                tops = [item for item in app.store.list_sessions() if item.get("parentID") is None]
                return {"status": "skipped", "reason": f"the run has {len(tops)} top sessions, not one"}
        try:
            from researchkit import board as research_board
            board = research_board.render(research_board.build(workspace), limit=reviews.LIMITS["extra"])
        except Exception as exc:  # noqa: BLE001 - the review goes on without the board
            board = f"(the research board could not be built: {type(exc).__name__}: {exc})"
        extra = [("B1", f"the research board {moment}", ".research (the research_board tool)", board)]
        try:
            from researchkit.simulation import task_tools
            tools = task_tools.review_text(Path(workspace), root)
        except Exception as exc:  # noqa: BLE001 - the review goes on without them
            tools = f"(the task's tools could not be listed: {type(exc).__name__}: {exc})"
        extra.append(("M1", "the tools this task wrote, each with its newest mount and known-answer tests",
                      ".research/records (kind=task_tool)", tools))
        model = model or (lambda a, s: model_call(a, s))
        return reviews.review(model(app, root), store=app.store, root=root, directory=workspace, extra=extra,
                              core=installed_skills(app), **facts)
    except Exception as exc:  # noqa: BLE001
        return {"status": "failed", "session": root, "error": f"{type(exc).__name__}: {exc}"}


class Hooks:
    """The reviewer's hooks for one round of a task: app.plan_verification and app.pause_review.

    sources: the task's source files, relative to the workspace (default: the folder's own files when the
    plan is written). started: when the round began (default: now)."""

    def __init__(self, app, *, workspace, sources=None, started=None, no_review=False, model=None,
                 guard=None, wrote=None):
        self.app, self.workspace = app, Path(workspace)
        self.sources = None if sources is None else list(sources)
        self.started = started if started is not None else time.time()
        # model_call is looked up when a reviewer runs, so a stand-in for it takes effect.
        self.model = model or (lambda a, s: model_call(a, s))
        self.no_review, self.guard, self.wrote = no_review, guard, wrote
        self._tried: dict[tuple[str, int], dict] = {}

    def _blocked(self) -> str | None:
        if self.no_review:
            return "turned off with --no-review"
        return self.guard() if self.guard else None

    def _sources(self) -> list[str]:
        return task_sources(self.workspace) if self.sources is None else self.sources

    def plan_verification(self, session_id: str) -> dict:
        """The task's verification plan, written by the reviewer before the agent's first step of a round that
        has none (opencode/verification.py). Tried once a round: a plan that failed is not tried again before
        each later message of the same round."""
        from opencode import task_skills, verification
        key = (session_id, task_skills.current_round(session_id))
        if key in self._tried:
            return self._tried[key]
        reason = self._blocked()
        if reason:
            record = {"status": "skipped", "reason": reason}
        else:
            print("[verification plan] writing the task's verification plan before the first step", flush=True)
            try:
                record = verification.plan(self.model(self.app, session_id), root=session_id, directory=self.workspace,
                                           commission=first_request(self.app.store, session_id),
                                           request=latest_request(self.app.store, session_id), round_=key[1],
                                           sources=self._sources(), core=installed_skills(self.app))
            except Exception as exc:  # noqa: BLE001 - the round goes on without a plan
                record = {"status": "failed", "session": session_id, "error": f"{type(exc).__name__}: {exc}"}
            print(f"[verification plan] {record.get('status')}", flush=True)
        self._tried[key] = record
        if self.wrote:
            self.wrote("plan", record)
        return record

    def pause_review(self, session_id: str, stall: int) -> dict:
        """The review a stalled round pauses for, on the round so far."""
        reason = self._blocked()
        if reason:
            return {"status": "skipped", "reason": reason}
        from opencode import task_skills
        round_ = task_skills.current_round(task_skills.root_session(self.app.store, session_id))
        print(f"[round review] paused: the last {stall} model calls made no progress the host can see; "
              f"reviewing round {round_} so far", flush=True)
        record = round_review(
            self.app, session_id, workspace=self.workspace, moment="when the round was paused", model=self.model,
            round_=round_, commission=first_request(self.app.store, session_id),
            request=latest_request(self.app.store, session_id), answer="", since=self.started,
            sources=self._sources(), ended={"status": "paused", "stall": stall, "seconds": time.time() - self.started})
        if self.wrote:
            self.wrote("pause", record)
        print(f"[round review] pause review: {record.get('status')}", flush=True)
        return record


def attach(app, **options) -> Hooks:
    """Give the app the reviewer's hooks for this round; the loop calls them (opencode/loop.py)."""
    hooks = Hooks(app, **options)
    app.plan_verification = hooks.plan_verification
    app.pause_review = hooks.pause_review
    return hooks
