"""A proxy formula with terms: the author's quantities, the mechanisms' signs, coefficients from the history.

The author chooses the physical quantities of a quantitative model and computes them in code, one
values-table column per term; each term's hypothesis gives its sign, or "unknown" when the mechanism
of one change has competing effects. The coefficients are not
declared: research_history_check describes every set that reproduces the historical measurements
with those signs, and research_leaderboard compares samples under all of them (see coefficients).
A run had written its model's sizes as assumptions; one was a fifth of what its own samples require
once the other mechanisms' signs are taken into account.
"""

from __future__ import annotations

import math

from researchkit import coefficients as co
from researchkit import values_table


def is_model(template):
    """Whether a formula is a quantitative model whose terms name values-table quantities."""
    terms = template.get("terms")
    return isinstance(terms, list) and bool(terms) and all(
        isinstance(term, dict) and isinstance(term.get("quantity"), str) for term in terms)


def names(template):
    return [term["quantity"] for term in template["terms"]]


SIGN = {"kpi_rises": 1, "kpi_falls": -1, "unknown": 0}


def signs(template):
    return {term["quantity"]: SIGN[term["mechanism_predicts"]] for term in template["terms"]}


def noise(template):
    declared = template.get("noise")
    return float(declared["sd"]) if isinstance(declared, dict) and isinstance(declared.get("sd"), (int, float)) else 0.0


def label(template, quantity):
    hypothesis = next(term["hypothesis_id"] for term in template["terms"] if term["quantity"] == quantity)
    return f"c[{quantity}] ({hypothesis})"


def read_quantities(root, template, selection, samples, read, owner):
    """{sample: {quantity: number}} from the values file a sheet selects, one column per term."""
    found = {}
    for quantity in names(template):
        picked = {key: selection[key] for key in ("record_ref", "source_path") if key in selection}
        try:
            column, _ = values_table.read(root, {**picked, "column": quantity}, read, "values")
        except ValueError as error:
            raise ValueError(f"{owner}: {error}. The values table of a model with terms holds each term's quantity "
                             "per sample, in the column its terms[].quantity names; research_history_check sets the "
                             "coefficients") from None
        missing = [sample for sample in samples if sample not in column]
        if missing:
            # Both sides, as research_leaderboard says: a run (2026-11-01) keyed its rows S1 and S2 where the
            # samples were named by the data file's labels, and had to guess which side was wrong.
            shown = list(column)[:12]
            raise ValueError(f"{owner}: column {quantity!r} of {selection['source_path']} has no value for "
                             f"{', '.join(missing)}; that file's sample IDs are {', '.join(shown)}"
                             + (f" and {len(column) - 12} more" if len(column) > 12 else "")
                             + ". Key its rows by the same sample IDs")
        for sample in samples:
            found.setdefault(sample, {})[quantity] = column[sample]
    return found


def read_measured(root, template, baseline_ids, read, owner):
    selection = template["measured"]
    measured = values_table.read(root, selection, read, "measured")[0]
    return values_table.require_samples(measured, baseline_ids, selection, "measured", owner)


def _number(value):
    return f"{value:.4g}"


def describe(template, bounds):
    """One phrase per coefficient: what the history and the signs leave of it."""
    parts = []
    for quantity in names(template):
        low, high, sign = bounds[quantity]["low"], bounds[quantity]["high"], signs(template)[quantity]
        name = label(template, quantity)
        if bounds[quantity]["determined"]:
            parts.append(f"{name} = {_number(low)}")
        elif not sign:
            parts.append(f"{name}: no sign from its mechanism, "
                         + ("sign and size not set" if math.isinf(low) and math.isinf(high)
                            else f">= {_number(low)}" if math.isinf(high)
                            else f"<= {_number(high)}" if math.isinf(low)
                            else f"{_number(low)} to {_number(high)}"))
        elif sign > 0 and math.isinf(high):
            parts.append(f"{name} >= {_number(low)}" if low > 1e-12 else f"{name} > 0, size not set")
        elif sign < 0 and math.isinf(low):
            parts.append(f"{name} <= {_number(high)}" if high < -1e-12 else f"{name} < 0, size not set")
        else:
            parts.append(f"{_number(low)} <= {name} <= {_number(high)}")
    return "; ".join(parts)


CHECK_MODEL = ("Check each term first: the quantity its code computes (each input in the role and meaning the task "
               "gives it), the sign its mechanism gives, the implementation (calc kind properties), and where each "
               "input value comes from (the task, a cited source or a calc result; name each one you assumed); "
               "correct an error in a revised formula that declares it in correction. Never change a sign the "
               "mechanism gives to make the model fit.")


def history_row(template, quantities, measured, baseline_ids):
    """Flags and findings of research_history_check for a model with terms."""
    history = {sample: quantities[sample] for sample in baseline_ids}
    shown = {sample: measured[sample] for sample in baseline_ids if sample in measured}
    model = co.fit(names(template), signs(template), {s: history[s] for s in shown}, shown,
                   offset=template.get("offset", True) is not False, noise=noise(template))
    error = noise(template)
    row = {"predicted": None, "flags": [], "findings": [], "order_checked": False,
           "model": {"samples": list(shown), "noise_sd": error, "feasible": model.feasible}}
    where = f"the measured values of {', '.join(shown)}" + (f" within the declared error {error:g}" if error else
                                                             " exactly (no measurement error declared)")
    if not model.feasible:
        row["flags"].append("coefficients_infeasible")
        row["model"]["min_noise"] = model.min_noise
        row["findings"].append(
            f"No coefficients with the signs the mechanisms give reproduce {where}; the smallest error that would is "
            f"{model.min_noise:.3g}. " + CHECK_MODEL + " If the measurements are known to be that uncertain, declare "
            "\"noise\": {\"sd\", \"source\"}; otherwise the model as stated contradicts the history: report it.")
        return row
    bounds = co.coefficients(model)
    row["model"]["coefficients"] = {name: {"low": _finite(b["low"]), "high": _finite(b["high"]),
                                           "determined": b["determined"]} for name, b in bounds.items()}
    row["flags"].append("fitted_history")
    if model.pinned:
        row["flags"].append("coefficient_pinned_zero")
        row["findings"].append(
            "The history leaves " + ", ".join(label(template, q) for q in model.pinned) + " no room but zero: its "
            "mechanism says the KPI moves with that quantity, and these samples say it does not. " + CHECK_MODEL
            + " Comparisons treat it as zero.")
    open_ = [q for q in names(template) if not bounds[q]["determined"]]
    if open_:
        row["flags"].append("coefficients_undetermined")
    row["findings"].append(
        f"Coefficients consistent with {where} and the mechanisms' signs: {describe(template, bounds)}. "
        + (f"These samples do not set {', '.join(label(template, q) for q in open_)}; a sample that changes only "
           "that quantity from a historical one would. " if open_ else "")
        + "The coefficients are set from these samples, so the model agrees with them by construction "
        "(history_fitted); research_leaderboard compares samples under every set above.")
    return row


def _finite(value):
    return value if math.isfinite(value) else None


def sheet(template, quantities, measured, baseline_ids, candidate_ids, owner):
    """What research_leaderboard needs from a model with terms: relations under every coefficient set."""
    samples = [*baseline_ids, *candidate_ids]
    history = {s: quantities[s] for s in baseline_ids if s in measured}
    model = co.fit(names(template), signs(template), history, {s: measured[s] for s in history},
                   offset=template.get("offset", True) is not False, noise=noise(template),
                   samples={s: quantities[s] for s in samples})
    if not model.feasible:
        raise ValueError(f"{owner}: no coefficients with the signs its mechanisms give reproduce the history (the "
                         f"smallest error that would is {model.min_noise:.3g}); research_history_check says what to "
                         "check. Revise the model before ranking with it")
    bounds = co.coefficients(model)
    direction, target = template["direction"], template.get("target_value")
    beats, ties = {s: [] for s in samples}, []
    for i, a in enumerate(samples):
        for b in samples[i + 1:]:
            found = co.relation(model, quantities[a], quantities[b], direction, target)
            if found == "better":
                beats[a].append(b)
            elif found == "worse":
                beats[b].append(a)
            elif found == "tie":
                ties.append([a, b])
    ranges = {s: [_finite(v) for v in co.prediction(model, quantities[s])] for s in samples}
    # Without a declared tolerance the band is the target value itself: v38's model declared none,
    # and four candidates whose predictions all lay below 39 were not marked as overshooting.
    tolerance = template.get("tolerance")
    width = float(tolerance) if isinstance(tolerance, (int, float)) and not isinstance(tolerance, bool) else 0.0
    band = None
    if direction == "target":
        band = {s: co.band(*co.prediction(model, quantities[s]), target, width) for s in samples}
    spans = {q: (min(history[s][q] for s in history), max(history[s][q] for s in history)) for q in names(template)}
    outside = [c for c in candidate_ids
               if any(not spans[q][0] - 1e-12 <= quantities[c][q] <= spans[q][1] + 1e-12 for q in names(template))]
    setting = co.setting_measurements(model, history, {c: quantities[c] for c in candidate_ids}, bounds)
    return {"coefficients": {name: {"low": _finite(b["low"]), "high": _finite(b["high"]),
                                    "determined": b["determined"]} for name, b in bounds.items()},
            "coefficient_text": describe(template, bounds), "pinned_zero": model.pinned,
            "beats": beats, "ties": ties, "ranges": ranges,
            **({"band": band, "band_tolerance": width} if band else {}),
            "extrapolated": outside,
            "next_measurements": {label(template, q): ids for q, ids in setting.items()},
            "quantities": {s: quantities[s] for s in samples}}


def relation(sheet_model, a, b):
    """better, worse, tie or undecided for sample a against b on a model sheet."""
    if b in sheet_model["beats"][a]:
        return "better"
    if a in sheet_model["beats"][b]:
        return "worse"
    if [a, b] in sheet_model["ties"] or [b, a] in sheet_model["ties"]:
        return "tie"
    return "undecided"
