"""Mechanical selection, freezing and readback of explicitly chosen tool receipts."""

from __future__ import annotations

from copy import deepcopy
import json

from opencode.tools.util import ensure_access
from researchkit import records
from researchkit.source_provenance import NativeSources, _difference, _parse_json, _without_compacted


def validate_ids(arguments):
    value = arguments.get("tool_call_ids", [])
    if (not isinstance(value, list)
            or any(not isinstance(item, str) or not item.strip() for item in value)):
        raise ValueError("tool_call_ids must be an array of nonblank strings")
    if len(set(value)) != len(value):
        raise ValueError("Duplicate tool_call_ids entry")
    return list(value)


def compact(value):
    return (json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def expanded(arguments, record_ref, source_paths):
    result = deepcopy({key: value for key, value in arguments.items()
                       if key not in {"revision_plan", "tool_call_ids"}})
    selected = {(item["record_ref"], item["source_path"]) for item in result["files"]}
    for source_path in source_paths:
        key = record_ref, source_path
        if key not in selected:
            result["files"].append({"record_ref": record_ref, "source_path": source_path})
            selected.add(key)
    return result


def manifest_for(root, selected):
    return {"kind": "source", "title": "Selected tool receipts", "files": [
        {"source_path": path.relative_to(root).as_posix(),
         "snapshot": "files/" + path.relative_to(root).as_posix(),
         "sha256": records.digest(raw), "bytes": len(raw)} for path, raw in selected], "depends_on": []}


def publish(ctx, selected):
    """Use the existing publisher with only already resolved native bytes."""
    root = ctx.directory.resolve()
    contents = dict(selected)
    expected = manifest_for(root, selected)
    ref = ".research/records/" + records.digest(records.encoded(expected)) + "/record.json"
    folder = root / ref
    # Keep existing source-read and destination read/edit authority. No new
    # research_record permission is introduced by this explicit composition.
    from researchkit.reviewer import _save_path
    for path in [root / ".research/records", folder.parent, folder,
                 *(folder.parent / item["snapshot"] for item in expected["files"])]:
        _save_path(root, path)
        for permission in ("read", "edit"):
            ensure_access(ctx, path, permission)
    saved = records.publish(root, kind="source", title="Selected tool receipts",
                            files=[path.relative_to(root).as_posix() for path, _ in selected], depends_on=[],
                            check_read=lambda path: ensure_access(ctx, path, "read"),
                            resolve_path=lambda path: [(path, contents[path])])
    if saved != {"record_path": ref, **expected}:
        raise ValueError("Selected tool receipt publication differs from its frozen native inputs")
    if folder.read_bytes() != records.encoded(expected):
        raise ValueError("Selected tool receipt manifest bytes changed")
    for item, (_, raw) in zip(expected["files"], selected):
        path = folder.parent / item["snapshot"]
        ensure_access(ctx, path, "read")
        if path.read_bytes() != raw:
            raise ValueError(f"Selected tool receipt snapshot bytes changed: {path}")
    return records.present(root, saved)


def verify_saved(ctx, original_args, invocation_key, *, history=None, read_bytes=None,
                 check_read=None, receipt_record=None):
    """Read-only audit of the approved original-arguments → frozen-input handoff.

    read_bytes receives workspace-relative paths. Supplying it keeps all disk
    reads under the caller's authority/cache, without contacting a permission
    broker. history is one caller-selected current-session snapshot. The return
    is (resolved_arguments, existing records.present receipt), never a publish.
    """
    ids = validate_ids(original_args)
    if not ids:
        raise ValueError("Saved receipt verification requires nonempty tool_call_ids")
    root = ctx.directory.resolve()

    def read(ref):
        path = records.local_path(root, ref)
        if read_bytes is not None:
            return read_bytes(path.relative_to(root).as_posix())
        ensure_access(ctx, path, "read")
        return path.read_bytes()

    sidecar = f".research/review-runs/{invocation_key}/resolved-arguments.json"
    raw = read(sidecar)
    resolved = _parse_json(raw, sidecar)
    if not isinstance(resolved, dict) or compact(resolved) != raw:
        raise ValueError("Resolved review arguments must be exact compact UTF-8 JSON with final LF")
    from researchkit.reviewer import _selection
    _selection({key: value for key, value in original_args.items() if key != "revision_plan"})
    _selection(resolved)
    sources = NativeSources(ctx, history=history)
    selected = sources.selected_receipts(ids, check_read=check_read or (
        None if read_bytes is not None else lambda path: ensure_access(ctx, path, "read")))
    source_paths = [path.relative_to(root).as_posix() for path, _ in selected]
    json_paths = source_paths[::2]
    # The permitted difference itself identifies the record even when the
    # invocation failed before producing any handoff or public return.
    refs = list(dict.fromkeys(item["record_ref"] for item in resolved["files"]))
    candidates = [ref for ref in refs
                  if _difference(expanded(original_args, ref, json_paths), resolved) is None]
    if receipt_record is not None:
        candidates = [ref for ref in candidates if isinstance(receipt_record, dict)
                      and receipt_record.get("record_path") == ref]
    verified = []
    for ref in candidates:
        manifest_raw = read(ref)
        manifest = _parse_json(manifest_raw, ref)
        if records.digest(manifest_raw) != ref.split("/")[2] or records.encoded(manifest) != manifest_raw:
            raise ValueError("Selected tool receipt manifest bytes or content address changed")
        if (not isinstance(manifest, dict) or set(manifest) != {"kind", "title", "files", "depends_on"}
                or manifest["kind"] != "source" or manifest["title"] != "Selected tool receipts"
                or manifest["depends_on"] != [] or not isinstance(manifest["files"], list)
                or len(manifest["files"]) != len(selected)):
            continue
        folder = records.local_path(root, ref).parent
        for item, source_path, (_, expected) in zip(manifest["files"], source_paths, selected):
            if (not isinstance(item, dict) or set(item) != {"source_path", "snapshot", "sha256", "bytes"}
                    or item["source_path"] != source_path or item["snapshot"] != "files/" + source_path):
                raise ValueError("Selected tool receipt file set/order differs from the explicit IDs")
            snapshot = (folder / item["snapshot"]).relative_to(root).as_posix()
            actual = read(snapshot)
            if (type(item["bytes"]) is not int or item["bytes"] != len(actual)
                    or records.digest(actual) != item["sha256"]):
                raise ValueError("Selected tool receipt frozen bytes changed")
            if source_path.endswith(".json"):
                actual_value, expected_value = _parse_json(actual, snapshot), _parse_json(expected, source_path)
                difference = _difference(_without_compacted(expected_value, actual_value),
                                         _without_compacted(actual_value, expected_value))
                if difference:
                    raise ValueError(f"Selected tool receipt differs from current-session identity: {difference}")
            elif actual != expected:
                raise ValueError("Selected tool receipt stored text differs from its native reply")
        verified.append(records.present(root, {"record_path": ref, **manifest}))
    if len(verified) != 1:
        raise ValueError("Resolved review arguments must identify exactly one selected tool receipt record")
    if receipt_record is not None and _difference(verified[0], receipt_record):
        raise ValueError("Returned receipt_record differs from the exact frozen record")
    return resolved, verified[0]


def failure_location(error, ctx, run_dir, receipt_ref):
    """Keep the existing exception type while exposing retained artifact paths."""
    from opencode.tools.util import _abort_event
    abort = _abort_event(ctx)
    if abort is not None and abort.is_set():
        return
    locations = (f"明選工具回條保存位置：{ctx.directory.resolve() / receipt_ref}；"
                 f"展開參數保存位置：{run_dir / 'resolved-arguments.json'}。")
    if locations in str(error):
        return
    detail = locations + f"\n{error}"
    if isinstance(error, OSError) and error.strerror is not None:
        error.strerror = detail
    elif isinstance(error, UnicodeError) and hasattr(error, "reason"):
        error.reason = detail
    else:
        error.args = (detail, *error.args[1:])
