"""Optional tools loaded through the existing local Python extension interface."""

from __future__ import annotations

from datetime import datetime, timezone
import functools
import math
import json
from pathlib import Path
import re
import uuid

import httpx

from opencode.tools.types import Tool, ToolResult, external_source, external_source_names, prop, schema
from opencode.tools.util import _abort_event, ensure_access, inside, session_path, truncate
from researchkit import literature, records, report_citations, scoring
from researchkit import literature_agent as literature_agent_module
from researchkit.candidate_comparison import INPUT_SCHEMA as CANDIDATE_COMPARISON_INPUT_SCHEMA, execute as _compare_candidates
from researchkit.leaderboard import INPUT_SCHEMA as LEADERBOARD_INPUT_SCHEMA, execute as _leaderboard
from researchkit.history_check import INPUT_SCHEMA as HISTORY_CHECK_INPUT_SCHEMA, execute as _history_check
from researchkit.judge import INPUT_SCHEMA as _JUDGE_SCHEMA, execute as _judge
from researchkit.inference import INPUT_SCHEMA as INFERENCE_INPUT_SCHEMA, execute as _inference
from researchkit.research_inference import execute as _research_inference
from researchkit.mindmap import INPUT_SCHEMA as MINDMAP_INPUT_SCHEMA, execute as _mindmap
from researchkit.method_exploration import INPUT_SCHEMA as METHOD_EXPLORATION_INPUT_SCHEMA, execute as _method_explore
from researchkit.reviewer import tool_execute as _review
from researchkit.delivery import DESCRIPTION as DELIVER_DESCRIPTION, INPUT_SCHEMA as DELIVER_SCHEMA
from researchkit.delivery import execute as _deliver
from researchkit.simulation.tool import DESCRIPTION as SIMULATE_DESCRIPTION, INPUT_SCHEMA as SIMULATE_SCHEMA
from researchkit.simulation.tool import execute as _simulate
from researchkit.turn import TURN_EXTENSION
from researchkit.source_provenance import NativeSources


def result(value, title: str) -> ToolResult:
    return ToolResult(title=title, output=truncate(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), label=title))


def root_for(ctx) -> Path:
    return ctx.directory.resolve()


def file_for(ctx, name: str, permission="read") -> Path:
    root = root_for(ctx)
    located = session_path(name, ctx)
    if inside(root, located):
        name = located.relative_to(root.resolve()).as_posix()
    path = records.local_path(root, name)
    ensure_access(ctx, path, permission)
    return path


TEMPLATE_FILES = {"hypothesis": "hypotheses.json", "proxy_formula": "proxy_formula.json",
                  "calibration": "calibration.json", "sample_evolution": "evolution.json"}


PROXY_SHAPE = ('{"formula_id": "P1", "expression": "...", "hypothesis_ids": ["H1"], '
               '"mechanism_predicts": "kpi_rises|kpi_falls", "direction": "higher|lower|target", "target_value": 12.5, '
               '"kpi": {"record_ref": ".research/records/<hash>/record.json", "source_path": "...", '
               '"column": "<KPI column>", "better": "lower|higher|target", "target_value": 12.5}, '
               '"measured": {"record_ref": ".research/records/<hash>/record.json", "source_path": "...", '
               '"column": "..."}, "anchor": "mean_offset" or {"reference_sample": "<baseline id>"}, '
               '"fitted_on": ["<historical sample id>", ...], '
               '"correction": {"error": "role|term_sign|implementation|unit|input_data", "what": "...", "basis": "..."}} '
               '(mechanism_predicts: what the hypothesis\'s mechanism says the measured KPI does as this formula\'s '
               'value rises; left out for a formula that predicts the KPI itself, whose terms\' signs carry the '
               'mechanism; with kpi.better it fixes direction; '
               'kpi: the measured KPI the formula ranks; measured, only when it predicts that quantity on its own scale; '
               'fitted_on, the historical samples whose measurements set any of its constants; correction, only on a '
               'revision that fixes an error; terms, only on the quantitative model of a KPI with a target, see '
               'final-kpi-proxy-discovery)')


def check_proxy_formula(template):
    """Reject a proxy_formula declaration the scoring tools would misread, before it is saved."""
    from researchkit import anchoring
    problems = []
    direction = template.get("direction")
    if direction is None:
        # v23 left it out twice, reading kpi.better as the formula's direction; the history check refused it later.
        problems.append("direction is required: higher or lower (which values of this formula are better), or "
                        "target with target_value. kpi.better says which values of the measured KPI are better, not "
                        "which values of the formula are")
    elif direction not in scoring.DIRECTIONS:
        problems.append(f"direction must be one of {', '.join(scoring.DIRECTIONS)}, not {direction!r}")
    target = template.get("target_value")
    if direction == "target" and (isinstance(target, bool) or not isinstance(target, (int, float))):
        problems.append("direction target needs a numeric target_value")
    elif direction in ("higher", "lower") and target is not None:
        # The ranking tools refuse it; a run (2026-11-01) had it accepted here and refused there, twice.
        problems.append(f"target_value is only used with direction target: leave it out of a {direction} formula, "
                        "or declare direction target if the formula's values have a best value")
    fitted = template.get("fitted_on")
    if fitted is not None and (not isinstance(fitted, list) or not all(isinstance(i, str) and i.strip() for i in fitted)
                               or len(set(fitted)) != len(fitted)):
        problems.append("fitted_on must list the distinct historical sample IDs whose measured values set any of the "
                        "formula's constants")
    ids = template.get("hypothesis_ids")
    if ids is not None and (not isinstance(ids, list) or not all(isinstance(i, str) for i in ids)):
        problems.append("hypothesis_ids must be a list of hypothesis id strings")
    measured = template.get("measured")
    if measured is not None and (not isinstance(measured, dict) or not all(
            isinstance(measured.get(key), str) and measured[key].strip()
            for key in ("record_ref", "source_path", "column"))):
        problems.append("measured must be an object with record_ref, source_path and column naming the "
                        "measured values the formula predicts, not a string or number")
    if "kpi" in template:
        problems += scoring.check_kpi(template["kpi"])
    problems += _mechanism_problems(template, direction)
    problems += _correction_problems(template.get("correction"))
    # v40 wrote its model's terms inside "model": {"offset": ..., "terms": [...]}; nothing reads them there,
    # so the model was saved as a plain formula and the agent fitted its coefficients itself.
    nested = [key for key, value in template.items() if isinstance(value, dict) and "terms" in value]
    if "terms" not in template and nested:
        problems.append(f"terms belongs at the top level of the template, not inside {nested[0]}: move terms "
                        "(and offset, noise) out of it, or the formula is saved as one without terms")
    problems += _term_problems(template, direction)
    if "anchor" in template:
        try:
            mode, _ = anchoring.anchor_mode(template["anchor"])
        except ValueError as error:
            problems.append(f"{error} (the host computes the offset; do not write the number)")
        else:
            if mode != "none" and (direction != "target" or measured is None):
                problems.append("anchor needs direction target and a measured selection")
    if problems:
        raise ValueError("proxy_formula template: " + "; ".join(problems) + ". Expected shape: " + PROXY_SHAPE)


# Runs declared kpi_falls for a formula that predicts the KPI itself in every LIT run; told to declare kpi_rises,
# one (2026-11-01) also negated two expressions whose rationale said the quantity raises the KPI.
PREDICTION_SIGN = ("this formula predicts the KPI itself (its measured selects the KPI's own values), so it rises with "
                   "the KPI by construction: leave out mechanism_predicts. Its mechanism is in the sign of each term: "
                   "a quantity whose rise raises the KPI enters with a plus sign, one whose rise lowers it with a minus "
                   "sign. Do not flip the whole expression to suit this field; that would contradict the rationale")
AN_INDEX = ("If it is instead an index whose rise lowers the KPI, it does not predict the KPI: keep kpi_falls and leave "
            "out measured (and anchor)")


def predicts_the_kpi(template):
    """Whether measured selects the KPI's own column: the formula is then a prediction of the KPI on its scale."""
    kpi, measured = template.get("kpi"), template.get("measured")
    return (isinstance(kpi, dict) and isinstance(measured, dict) and bool(measured.get("column"))
            and all(kpi.get(key) == measured.get(key) for key in ("source_path", "column")))


def _mechanism_problems(template, direction):
    """The direction must be the one the hypothesis's mechanism predicts.

    v30 declared P1 higher-is-better although its rationale said the index rises with the dose
    (lower dose is better): that matched its two historical samples, and the history check then
    counted the agreement as evidence. Stating the mechanism's sign separately makes such a
    direction a contradiction the host can see.
    """
    mechanism = template.get("mechanism_predicts")
    kpi = template.get("kpi") if isinstance(template.get("kpi"), dict) else {}
    if mechanism is not None and mechanism not in scoring.MECHANISM:
        return [f"mechanism_predicts must be kpi_rises or kpi_falls, not {mechanism!r}: what the hypothesis's "
                "mechanism says the measured KPI does as this formula's value rises"]
    if predicts_the_kpi(template):
        if mechanism == "kpi_falls":
            return [PREDICTION_SIGN + ". " + AN_INDEX]
        mechanism = "kpi_rises"  # by construction; the field may be left out
    if direction not in ("higher", "lower") or kpi.get("better") not in ("higher", "lower"):
        return []
    if mechanism is None:
        return ["mechanism_predicts is required when kpi.better is higher or lower: kpi_rises or kpi_falls, what "
                "the hypothesis's mechanism (the rationale) says the measured KPI does as this formula's value "
                "rises. With kpi.better it fixes direction; it is the hypothesis's prediction, written from the "
                "mechanism, not from which historical sample should come out ahead"]
    wanted = scoring.mechanism_direction(mechanism, kpi["better"])
    if wanted == direction:
        return []
    return [f"direction {direction} contradicts mechanism_predicts {mechanism} with kpi.better {kpi['better']}: "
            f"a KPI that {'rises' if mechanism == 'kpi_rises' else 'falls'} with the formula, where "
            f"{kpi['better']} KPI values are better, makes {wanted} formula values better, so direction is "
            f"{wanted}. If the rationale says otherwise, correct mechanism_predicts to match it. Whether the "
            "historical samples agree is what research_history_check reports; a formula whose mechanism they "
            "contradict is a finding about the hypothesis, not a direction to change"]


CORRECTION_ERRORS = ("role", "term_sign", "implementation", "unit", "input_data")


def _text_ok(value):
    return isinstance(value, str) and bool(value.strip())


def _correction_problems(correction):
    """A revision that fixes an error says which kind, what, and on what independent basis.

    A run misread a component's role and gave a term the opposite sign of its mechanism; correcting
    those is not the same as flipping a direction to match the history, and the report has to be
    able to say which it was.
    """
    if correction is None:
        return []
    if (not isinstance(correction, dict) or correction.get("error") not in CORRECTION_ERRORS
            or not _text_ok(correction.get("what")) or not _text_ok(correction.get("basis"))):
        return ["correction must be {\"error\": \"" + "|".join(CORRECTION_ERRORS) + "\", \"what\": \"...\", "
                "\"basis\": \"...\"}: the kind of error this version corrects, what was wrong, and the source that "
                "shows it (the task's definition, a citation, the code), not the historical order"]
    return []


TERM_SHAPE = ('terms must be a nonempty list of {"hypothesis_id", "lever", "quantity": "<values-table column '
              'holding this term\'s quantity for every sample>", "mechanism_predicts": "kpi_rises|kpi_falls|unknown"}')


def _term_problems(template, direction):
    """A quantitative model of a KPI: one term per hypothesis, its quantity and the sign its mechanism gives.

    A KPI with a target cannot be reached by ranks alone: where a candidate lands depends on how
    large each effect is. The author chooses the quantities and the mechanism fixes each sign; the
    sizes are not declared. A run wrote its sizes as assumptions, and one of them was a fifth of what
    its own samples require; research_history_check sets them (see term_model).
    """
    terms = template.get("terms")
    if terms is None:
        return []
    if not isinstance(terms, list) or not terms or not all(isinstance(term, dict) for term in terms):
        return [TERM_SHAPE]
    problems = []
    if direction != "target" or not isinstance(template.get("measured"), dict):
        problems.append("a formula with terms predicts the KPI itself: declare direction target with the KPI's "
                        "target_value, and measured selecting the measured KPI")
    if "anchor" in template:
        problems.append("a formula with terms has no anchor: its offset is set with its coefficients")
    ids = template.get("hypothesis_ids") if isinstance(template.get("hypothesis_ids"), list) else []
    seen = set()
    for number, term in enumerate(terms, 1):
        label = f"terms[{number}]"
        if "coefficient" in term or "basis" in term:
            problems.append(f"{label}: coefficients are not declared; research_history_check sets them from the "
                            "historical measurements and the signs the mechanisms give. Give quantity instead")
            continue
        if not (_text_ok(term.get("hypothesis_id")) and _text_ok(term.get("lever")) and _text_ok(term.get("quantity"))
                and term.get("mechanism_predicts") in scoring.TERM_MECHANISM):
            problems.append(f"{label}: {TERM_SHAPE}")
            continue
        if term["hypothesis_id"] not in ids:
            problems.append(f"{label}: hypothesis_id {term['hypothesis_id']} is not in hypothesis_ids")
        if term["quantity"] in seen:
            problems.append(f"{label}: quantity {term['quantity']} is already another term's")
        seen.add(term["quantity"])
    named = {term.get("hypothesis_id") for term in terms if isinstance(term, dict)}
    missing = [h for h in ids if h not in named]
    if missing:
        problems.append(f"terms has no term for {', '.join(missing)}: give each hypothesis of the model its term")
    if all(term.get("mechanism_predicts") == "unknown" for term in terms):
        problems.append("every term's mechanism_predicts is unknown: a model whose mechanisms give no sign at all is "
                        "a fit to the history, not a mechanism. Give at least one term the sign its mechanism gives")
    if "offset" in template and not isinstance(template["offset"], bool):
        problems.append("offset must be true or false: whether the model has a constant term (default true)")
    noise = template.get("noise")
    if noise is not None and not (isinstance(noise, dict) and isinstance(noise.get("sd"), (int, float))
                                  and not isinstance(noise["sd"], bool) and math.isfinite(noise["sd"])
                                  and noise["sd"] >= 0 and _text_ok(noise.get("source"))):
        problems.append('noise must be {"sd": <measurement error of the KPI, >= 0>, "source": "<where it comes '
                        'from>"}')
    tolerance = template.get("tolerance")
    if tolerance is not None and not (isinstance(tolerance, (int, float)) and not isinstance(tolerance, bool)
                                      and math.isfinite(tolerance) and tolerance > 0):
        problems.append("tolerance must be the positive tolerance the task gives around target_value")
    return problems


def check_selections(template, ctx):
    """Read a formula's kpi and measured values now, the way the ranking tools will read them.

    v21 saved formulas whose kpi named a CSV the tools could not read yet and found out only at
    research_history_check, after the candidates were built. A selection that cannot be read is
    refused while the formula is still unsaved and cheap to fix.
    """
    from researchkit import values_table
    problems, samples, numbers = [], {}, {}
    for label in ("kpi", "measured"):
        selection = template.get(label)
        if not isinstance(selection, dict):
            continue
        picked = {key: selection[key] for key in ("record_ref", "source_path", "column") if key in selection}
        try:
            numbers[label], _ = values_table.read(root_for(ctx), picked, lambda p: ensure_access(ctx, p, "read"),
                                                  label)
        except (OSError, ValueError, KeyError) as error:
            problems.append(f"{label} cannot be read: {error}")
        else:
            samples[label] = list(numbers[label])
    if problems:
        raise ValueError("proxy_formula template: " + "; ".join(problems) + ". research_history_check and "
                         "research_leaderboard read these values the same way, so the formula was not saved; "
                         "select a file of a saved record (and its column) that holds the values")
    if template.get("mechanism_predicts") == "kpi_falls" and _measures_the_kpi(template, numbers):
        raise ValueError(f"proxy_formula template: mechanism_predicts kpi_falls contradicts measured: {PREDICTION_SIGN}. "
                         f"{AN_INDEX}")
    return samples


def _measures_the_kpi(template, numbers):
    """Whether measured selects the KPI's own values: the same file and column, or equal on two samples or more.

    A run's formula predicted the KPI itself, its measured and kpi naming the same column, and declared
    that the KPI falls as the formula rises; its expression rose with a rate its rationale said lowers
    the KPI. Nothing compared the two, because a target formula's direction is not checked against
    mechanism_predicts.
    """
    kpi, measured = numbers.get("kpi"), numbers.get("measured")
    if not kpi or not measured:
        return False
    selections = [template["kpi"], template["measured"]]
    if all(selections[0].get(key) == selections[1].get(key) for key in ("source_path", "column")):
        return True
    shared = [sample for sample in kpi if sample in measured]
    return len(shared) >= 2 and all(kpi[sample] == measured[sample] for sample in shared)


def check_evolution(args, ctx):
    """Refuse an evolution record whose declaration the host cannot check, listing everything at once."""
    from researchkit import board
    from researchkit.calc_roles import all_problems

    declared = _declaration(args, ctx, "evolution.json")
    if declared is None:
        raise ValueError(f"a {args['kind']} record declares its rounds in evolution.json: pass it as template "
                         f"({board.EVOLUTION_SHAPE}). Nothing was saved")
    value = board.build(root_for(ctx), check_read=lambda p: ensure_access(ctx, p, "read"))
    problems = board.evolution_problems(declared, value)
    if problems:
        raise ValueError("evolution.json: " + all_problems(problems) + f"\nExpected shape: {board.EVOLUTION_SHAPE}. "
                         "Nothing was saved")


def check_levers(template, args, ctx):
    """Refuse a formula that names none of its own hypothesis's levers (see one_to_one)."""
    from researchkit import board, one_to_one
    read = lambda p: ensure_access(ctx, p, "read")
    closure = records._read_dependencies(root_for(ctx), args.get("depends_on", []), check_read=read)
    lineage = [ref for ref, record in closure.items() if record["kind"] == "hypothesis"]
    if not lineage:
        return
    value = board.build(root_for(ctx), check_read=read)
    label = template.get("formula_id") if isinstance(template.get("formula_id"), str) else "this formula"
    one_to_one.check_formula(template, one_to_one.current_rows(value, lineage), label)


def _inline_template(args, ctx):
    """Write an inline template under its required file name and add it to the record's files."""
    template = args.get("template")
    if template is None:
        return args
    name = TEMPLATE_FILES.get(args["kind"]) or ("evolution.json" if "evolution" in args["kind"] else None)
    if name is None:
        raise ValueError(f"template is for kind {', '.join(TEMPLATE_FILES)}; kind {args['kind']!r} takes files only")
    if not isinstance(template, dict):
        raise ValueError(f"template must be the JSON object that {name} holds")
    same = [f for f in args.get("files", []) if Path(f).name == name]
    if same:
        # v22 kept its own results in data/evolution.json and notes/hypotheses.json and passed template too,
        # eight times, because the error did not say which file was in the way.
        raise ValueError(f"give the {name} content as template or as a file in files, not both: files include "
                         f"{', '.join(same)}, and a file named {name} is this record's declaration. If that file is "
                         f"the declaration, leave out template. If it is your own data, give it another name (or "
                         f"leave it out of files) and keep template; the host stores template as {name}")
    relative = f".research/templates/{uuid.uuid4().hex}/{name}"
    path = file_for(ctx, relative, "edit")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {**args, "files": [*args.get("files", []), relative]}


def _revision(args, ctx):
    """Check that revises names an earlier record of the same kind, and depend on it."""
    revises = args.get("revises")
    if not revises:
        return args
    file_for(ctx, revises)
    check = lambda p: ensure_access(ctx, p, "read")
    try:
        earlier = records.read_record(root_for(ctx), revises, check_read=check)
    except (OSError, ValueError) as error:
        raise ValueError(f"revises must be an exact earlier record.json path (or a unique prefix of its hash): "
                         f"{error}") from error
    if earlier["kind"] != args["kind"]:
        raise ValueError(f"revises names a {earlier['kind']} record, but this record is {args['kind']}. A revision "
                         "replaces an earlier version of the same kind; to build on another kind of record, "
                         "list it in depends_on.")
    folder = records.local_path(root_for(ctx), revises).parent

    def earlier_template(name):
        for item in earlier["files"]:
            if Path(item["source_path"]).name == name:
                try:
                    return json.loads(records.local_path(folder, item["snapshot"]).read_text(encoding="utf-8-sig"))
                except (OSError, ValueError):
                    return None
        return None

    if args["kind"] == "hypothesis":
        dropped = sorted(_hypothesis_ids(earlier_template("hypotheses.json"))
                         - _hypothesis_ids(_declaration(args, ctx, "hypotheses.json")))
        if dropped:
            raise ValueError(f"A revised hypotheses set keeps every earlier id, but {', '.join(dropped)} is missing. "
                             "Keep retired hypotheses with proxy_status deferred or not_computable and the reason; "
                             "to add hypotheses beside the earlier set instead, list it in depends_on, not revises.")
    if args["kind"] == "proxy_formula":
        mine = _formula_id(_proxy_declaration(args, ctx))
        theirs = _formula_id(earlier_template("proxy_formula.json"))
        if mine and theirs and mine != theirs:
            raise ValueError(f"revises links versions of one formula, but formula_id {mine!r} differs from the "
                             f"revised record's {theirs!r}. Keep formula_id {theirs!r} for a revision, or list the "
                             "earlier record in depends_on if this is a new formula that builds on it.")
    depends_on = list(args.get("depends_on") or [])
    return {**args, "depends_on": depends_on if revises in depends_on else [*depends_on, revises]}


def _saved_hypotheses(ctx, ref):
    """The hypotheses.json of a saved hypothesis record, or None."""
    try:
        record = records.read_record(root_for(ctx), ref, check_read=lambda p: ensure_access(ctx, p, "read"))
    except (OSError, ValueError):
        return None
    if record["kind"] != "hypothesis":
        return None
    folder = records.local_path(root_for(ctx), ref).parent
    for item in record["files"]:
        if Path(item["source_path"]).name == "hypotheses.json":
            try:
                return json.loads(records.local_path(folder, item["snapshot"]).read_text(encoding="utf-8-sig"))
            except (OSError, ValueError):
                return None
    return None


def _status(item):
    status = item.get("proxy_status") if isinstance(item, dict) else None
    return status.get("status") if isinstance(status, dict) else None


def _keep_deferred(args, ctx, declared):
    """Refuse a new version of a hypothesis set that silently drops a budget-queued status.

    v24 regenerated its hypotheses.json to fix one sign and lost H4-H6's deferred status; the board
    then counted them as active hypotheses without formulas, and the agent built three formulas for
    them before its first delivery (about 50 minutes).
    """
    new = {item.get("id"): item for item in declared.get("hypotheses", []) if isinstance(item, dict)}
    earlier = [ref for ref in [args.get("revises"), *args.get("depends_on", [])] if ref]
    lost = {}
    for ref in dict.fromkeys(earlier):
        value = _saved_hypotheses(ctx, ref)
        for item in (value or {}).get("hypotheses", []) if isinstance(value, dict) else []:
            if _status(item) == "deferred" and item.get("id") in new and _status(new[item["id"]]) is None:
                lost.setdefault(item["id"], ref)
    if lost:
        names = ", ".join(sorted(lost))
        refs = ", ".join(sorted(set(lost.values())))
        raise ValueError(f"{names} were queued by the budget (proxy_status deferred) in {refs}, and this version has no "
                         "proxy_status for them, which would make them active hypotheses that need formulas now. Keep "
                         "their proxy_status as it was; to start them deliberately (after the first delivery), write "
                         '"proxy_status": {"status": "active", "reason": "..."}. Nothing was saved')


def _formula_id(value):
    return value.get("formula_id") if isinstance(value, dict) and isinstance(value.get("formula_id"), str) else None


def _hypothesis_ids(value):
    items = value.get("hypotheses") if isinstance(value, dict) else None
    return {item["id"] for item in items or [] if isinstance(item, dict) and isinstance(item.get("id"), str)}


def _proxy_declaration(args, ctx):
    return _declaration(args, ctx, "proxy_formula.json")


def _declaration(args, ctx, template):
    for name in args.get("files", []):
        if Path(name).name == template:
            try:
                return json.loads(file_for(ctx, name).read_text(encoding="utf-8-sig"))
            except (OSError, ValueError) as error:
                raise ValueError(f"{name} is not readable JSON: {error}") from error
    return None


# Kinds only their own tool saves: it builds and checks them (v35 wrote a mind map with its own script).
TOOL_MADE = {"mindmap": "research_mindmap", "mindmap_checkpoint": "research_mindmap"}


def _publish(args, ctx):
    if args.get("kind") in TOOL_MADE:
        raise ValueError(f"kind {args['kind']} is the research route landscape that {TOOL_MADE[args['kind']]} builds "
                         "and checks. A mind map for another purpose (a paper summary, a diagram) is an ordinary file: "
                         "save it under another kind, such as notes. Nothing was saved")
    args = _inline_template(args, ctx)
    if not args.get("files"):
        raise ValueError("files must list at least one file, unless template supplies the record's content")
    # Named, not the system's "[Errno 2]": a run (2026-11-01) renamed a file in files without renaming it on disk.
    from researchkit.source_provenance import _locator
    absent = []
    for name in args["files"]:
        path = file_for(ctx, name)
        # A session source (.opencode/sources/...) is read from the session store, not from a file.
        if not path.is_file() and _locator(path.relative_to(root_for(ctx).resolve()).as_posix()) is None:
            absent.append(name)
    if absent:
        raise ValueError(f"files lists {', '.join(absent)}, which {'is' if len(absent) == 1 else 'are'} not a file in "
                         "the workspace: write it first, or list the file that holds this content. Nothing was saved")
    if args["kind"] == "hypothesis":
        from researchkit.board import HYPOTHESES_SHAPE, hypothesis_problems
        declared = _declaration(args, ctx, "hypotheses.json")
        problems = hypothesis_problems(declared) if declared is not None else []
        if problems:
            raise ValueError("hypotheses.json: " + "; ".join(problems) + f". Expected shape: {HYPOTHESES_SHAPE}. "
                             "Nothing was saved; the research board cannot read a set saved like this")
        if declared is not None:
            _keep_deferred(args, ctx, declared)
    if "evolution" in args["kind"]:
        check_evolution(args, ctx)
    args = _revision(args, ctx)
    for name in [*args["files"], *args.get("depends_on", [])]:
        file_for(ctx, name)
    selected_samples = {}
    if args["kind"] == "proxy_formula":
        declared = _proxy_declaration(args, ctx)
        if isinstance(declared, dict):
            check_proxy_formula(declared)
            selected_samples = check_selections(declared, ctx)
            check_levers(declared, args, ctx)
    file_for(ctx, ".research/records", "edit")
    paths = []
    differences = records.workspace_differences(root_for(ctx), args.get("depends_on", []), paths=paths,
                                                check_read=lambda p: ensure_access(ctx, p, "read"))
    sources = NativeSources(ctx)

    saved = records.publish(root_for(ctx), kind=args["kind"], title=args["title"], files=args["files"],
                            depends_on=args.get("depends_on", []),
                            check_read=lambda p: ensure_access(ctx, p, "read"),
                            resolve_source=sources.resolve_reference, resolve_path=sources.resolve_path)
    if differences:
        # These observations describe the current workspace, not the immutable record.
        saved = {"record_path": saved["record_path"],
                 "dependency_notice": "Saved, but selected dependency snapshots differ from working files. "
                 "Compare the exact snapshots with what this work actually used. If you used revised files, "
                 "record those versions and correct dependent records. Intentional use of historical versions "
                 "is valid; explain it. This is not an instruction to recompute or choose the latest version. "
                 "Re-recording unchanged files with corrected dependencies does not rerun calculations. "
                 "Adding a new input beside an old dependent record does not change that record's dependencies.\n"
                 + _dependency_paths(saved, paths),
                 **saved, "workspace_differences": [
                     {key: item[key] for key in ("record_path", "source_path", "status") if key in item}
                     for item in differences[:NOTICE_ITEMS]]}
        if len(differences) > NOTICE_ITEMS:
            saved["workspace_differences_total"] = len(differences)
    if args["kind"] == "user_report":
        # The same chain the end-of-turn delivery check verifies, reported now rather than after the answer.
        issues = records.delivery_issues(root_for(ctx), saved["record_path"],
                                         check_read=lambda p: ensure_access(ctx, p, "read"))
        if issues:
            saved = {**saved, "delivery_issues": issues, "delivery_note": (
                "This delivery is not yet bound: fix these before the final answer (a review whose reviewed_refs "
                "include the delivered report, a Final-LCA depending on both, and a new user_report). "
                "research_deliver writes the Final-LCA and the user_report in one call and checks this chain.")}
    if args["kind"] == "hypothesis":
        carried = _carried_formulas(ctx, saved["record_path"])
        if carried:
            saved = {**saved, "formulas_carried_over": carried, "formulas_note": (
                "The formulas built on the earlier version stay the formulas of these hypotheses; do not save them "
                "again just to depend on this version (each new formula version needs its values and history check "
                "again). Revise a formula only when its hypothesis changed in a way the formula no longer follows.")}
    if args["kind"] == "report":
        found = _report_checks(ctx, saved["record_path"])
        if found:
            saved = {**saved, "report_checks": found, "report_checks_note": (
                "The host compared this report's candidate verdicts and table numbers with the newest leaderboards "
                "and saved noise checks. Correct the report, or keep these as stated limits; research_deliver asks "
                "for an answer to each one that remains.")}
    if args["kind"] == "proxy_formula":
        saved = {**saved, "history_check_hint": (
            "Before generating candidates, compute this formula for the historical samples and pass those values "
            "to research_history_check: predictions off the measured scale and equal predictions are cheap to fix "
            "now and expensive after a leaderboard. An order against the declared kpi calls for the checks its "
            "finding lists, not for changing the formula's direction."
            + "".join(f" Its {label} reads values for {', '.join(ids[:6])}{' and more' if len(ids) > 6 else ''}: key the "
                      "historical samples' rows of the values table and baseline_ids by these IDs."
                      for label, ids in selected_samples.items()))}
    if args.get("revises"):
        saved = {**saved, "revises": args["revises"],
                 "revision_notice": "The research board now lists this record as the current version and leaves "
                                     "the revised one out; research_list still shows both."}
    try:
        unbound = records.unbound_reviews(root_for(ctx), saved, check_read=lambda p: ensure_access(ctx, p, "read"))
    except Exception as exc:  # The record is already committed; never report it as failed.
        saved = {**saved, "review_binding_notice": f"已保存；宿主未能完成審查依賴檢查：{exc}"}
    else:
        if unbound:
            saved = {**saved, "review_binding_notice": records.unbound_review_notice(saved["record_path"], unbound),
                     "unbound_reviews": unbound}
    notice = _board_notice(ctx, saved["record_path"], args["kind"])
    if notice:
        saved = {**saved, "host_notice": notice}
    # Keep the committed receipt complete for recovery and delivery selection.
    # Common bounds its prompt/UI presentation and provides saved-text readback.
    return ToolResult(title="research_record", output=json.dumps(
        records.present(root_for(ctx), saved), ensure_ascii=False, indent=2, allow_nan=False))


NOTICE_ITEMS = 5


def _dependency_paths(saved, paths):
    """The first few dependency witnesses; a long list would crowd out the research in context."""
    short = Path(saved["record_path"]).parent.name[:8]
    lines = [f"{saved['kind']} {short} -> {path}" for path in paths[:NOTICE_ITEMS]]
    more = len(paths) - len(lines)
    return ("Dependency paths (one witness per selected root and differing ancestor; records by their first 8 "
            "hash characters" + (f"; first {len(lines)} of {len(paths)}" if more else "") + "):\n"
            + "\n".join(lines)
            + (f"\n... {more} more." if more else "")
            + "\nresearch_list shows each record's workspace_differences in full, with hashes and snapshot paths.")


def _carried_formulas(ctx, record_path):
    """{hypothesis id: [formula ids]} that a just-saved hypothesis version keeps from earlier versions.

    v24 revised one hypothesis and then saved all three formulas again so that they depended on the new
    version, which sent every one of them back through values and the history check.
    """
    from researchkit import board
    try:
        value = board.build(root_for(ctx), check_read=lambda p: ensure_access(ctx, p, "read"))
    except Exception:  # The record is already committed; never report it as failed.
        return {}
    row = next((row for row in value["hypotheses"] if row["ref"] == record_path), None)
    formulas = {f["ref"]: (f.get("template") or {}).get("formula_id") or f["ref"].split("/")[2][:8]
                for f in value["proxy_formulas"] if not f.get("superseded_by")}
    carried = {}
    for item in (row or {}).get("items") or []:
        names = list(dict.fromkeys(formulas[ref] for ref in item.get("proxy_formula_refs") or [] if ref in formulas))
        if names:
            carried[item["id"]] = names
    return carried


def _report_checks(ctx, record_path):
    """Host checks of each Markdown file of a just-saved report; never fails the saved record."""
    from researchkit import report_checks
    from researchkit.report_evidence import resolve
    root = root_for(ctx)
    read = lambda p: ensure_access(ctx, p, "read")
    try:
        record = records.read_record(root, record_path, check_read=read)
        known = report_checks.facts(root, read)
        found = []
        for item in record["files"]:
            if not item["source_path"].lower().endswith(".md"):
                continue
            frozen, = resolve(root, [{"record_ref": record_path, "source_path": item["source_path"]}], check_read=read)
            found += [f"{item['source_path']}: {finding['text']}"
                      for finding in report_checks.check(root, frozen["text"], read, known)]
        return found[:report_checks.MAX_FINDINGS]
    except Exception as exc:  # The record is already committed; never report it as failed.
        return [f"已保存；宿主未能完成報告比對：{exc}"]


def _board_notice(ctx, record_path, kind=None):
    """Board notices for the record just saved, shown where the author is looking now.

    A delivery (report, final_lca, user_report) also lists every open action
    notice and a digest of the formulas, scores and evolutions it relies on, so
    the author can check the delivered text against the saved records.
    """
    from researchkit import board
    try:
        value = board.build(root_for(ctx), check_read=lambda p: ensure_access(ctx, p, "read"),
                            hypothesis_budget=board.configured_budget(getattr(ctx.app, "config", None)))
        digest = (board.delivery_digest(root_for(ctx), value, record_path,
                                        check_read=lambda p: ensure_access(ctx, p, "read"))
                  if kind in board.DELIVERY_KINDS else [])
    except Exception as exc:  # The record is already committed; never report it as failed.
        return f"已保存；宿主未能完成看板檢查：{exc}"
    short = record_path.split("/")[2][:8] if record_path.count("/") == 3 else record_path
    if kind in board.DELIVERY_KINDS:
        related = [f"[{item['id']}] {item['text']}" for item in board.open_actions(value)]
    else:
        related = [f"[{item['id']}] {item['text']}" for item in value["notice_items"]
                   if short in item["text"] and not item["reply"]]
    if digest:
        related.append("此交付所依賴紀錄的宿主摘要（請與交付文字核對）：\n"
                       + "\n".join(f"  {line}" for line in digest))
    if not related:
        return None
    return ("宿主看板提醒（機械比對，不是科學判斷；不擋發布，已保存紀錄不可改寫）：\n"
            + "\n".join(f"- {item}" for item in related))


def _list(args, ctx):
    file_for(ctx, ".research/records")
    root = root_for(ctx)
    saved = records.inventory(root, check_read=lambda p: ensure_access(ctx, p, "read"))
    differences = records.workspace_differences(root, [r["record_path"] for r in saved],
                                                check_read=lambda p: ensure_access(ctx, p, "read"))
    by_ref = {}
    for item in differences:
        by_ref.setdefault(item["record_path"], []).append(item)
    dependents = records.direct_dependents(saved)
    listed = []
    for record in saved:
        item = {**record, "depended_on_by": dependents.get(record["record_path"], [])}
        if record["record_path"] in by_ref:
            item["workspace_differences"] = by_ref[record["record_path"]]
        listed.append(records.present(root, item))
    return result(listed, "research_list")


def _board(args, ctx):
    from researchkit import board, graph
    file_for(ctx, ".research/records")
    value = board.build(root_for(ctx), history=ctx.app.store.messages(ctx.session_id),
                        hypothesis_budget=board.configured_budget(getattr(ctx.app, "config", None)),
                        check_read=lambda p: ensure_access(ctx, p, "read"),
                        requirements=graph.planning_requirements(ctx.app, ctx.session_id))
    # Text, not the build dictionary: the same content in about an eighth of the bytes.
    return ToolResult(title="research_board", output=board.render(value, full=True))


def _graph_update(args, ctx):
    from researchkit import graph
    store = graph.GraphStore(root_for(ctx), check_read=lambda p: ensure_access(ctx, p, "read"),
                             check_edit=lambda p: ensure_access(ctx, p, "edit"))
    value = store.update(args, requirements=graph.planning_requirements(ctx.app, ctx.session_id))
    return result(value, "research_graph_update")


_GRAPH_ID = {"type": "string", "pattern": "^[A-Za-z][A-Za-z0-9_-]{0,63}$"}
GRAPH_UPDATE_SCHEMA = schema({
    "expected_revision": {"anyOf": [{"type": "string", "minLength": 1}, {"type": "null"}],
                          "description": "Current graph revision_ref shown on the research board; null for the first update"},
    "reason": prop("string", "Why the graph changes now"),
    "nodes": prop("array", "Nodes to add or replace by id. Nodes are never deleted; change status or supersede.",
                  maxItems=64, items=schema({
                      "id": {**_GRAPH_ID, "description": "Stable id, e.g. Q1, C1, O1, D1"},
                      "type": prop("string", "question | conjecture | observation | decision",
                                   enum=["question", "conjecture", "observation", "decision"]),
                      "text": prop("string", "The question, claim, fact or choice in one or two sentences"),
                      "status": prop("string", "question: open|answered|dropped; conjecture: proposed|supported|"
                                     "weakened|refuted; observation: valid|overturned; decision: active|withdrawn"),
                      "reason": prop("string", "Why this node or its status is what it is now"),
                      "records": prop("array", "Exact saved record.json paths. Required for observation.",
                                      items={"type": "string"}),
                      "edges": prop("array", "Outgoing edges. based_on: this node relies on the target. supports / "
                                    "contradicts: from an observation to a conjecture.", items=schema({
                                        "type": prop("string", "Edge type", enum=["based_on", "supports", "contradicts"]),
                                        "to": _GRAPH_ID}, ["type", "to"])),
                      "supersedes": {**_GRAPH_ID, "description": "Older node of the same type that this one replaces"},
                      "requirement_ids": prop("array", "Planning requirement ids this node serves (decisions)",
                                              items=_GRAPH_ID)},
                      ["id", "type", "text", "status", "reason"])),
    "reviews": prop("array", "Flagged nodes you re-checked and keep unchanged, each with the reason it still holds",
                    items=schema({"node_id": _GRAPH_ID, "reason": prop("string", "Why it still holds")},
                                 ["node_id", "reason"])),
    "notice_replies": prop("array", "Replies to board notices marked [N......]: what you changed, or why the notice "
                           "does not apply. Answered notices leave the open list.",
                           items=schema({"notice_id": {"type": "string", "pattern": "^N[0-9a-f]{6}$"},
                                         "reason": prop("string", "What was done, or why it does not apply")},
                                        ["notice_id", "reason"]))},
    ["expected_revision", "reason"])


def _compare(args, ctx):
    proxy = file_for(ctx, args["proxy_path"])
    target = file_for(ctx, args["target_path"])
    proxy_bytes, target_bytes = proxy.read_bytes(), target.read_bytes()
    evaluation = scoring.compare(json.loads(proxy_bytes), json.loads(target_bytes), args["direction"],
                                 args.get("target_value"))
    evaluation["input_files"] = [{"path": args["proxy_path"], "sha256": records.digest(proxy_bytes)},
                                {"path": args["target_path"], "sha256": records.digest(target_bytes)}]
    data = records.encoded(evaluation)
    destination = file_for(ctx, f".research/calibrations/{records.digest(data)}.json", "edit")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.read_bytes() != data:
        raise ValueError("Stored calibration changed; refusing to overwrite")
    destination.write_bytes(data)
    return result({"result_path": str(destination), **evaluation}, "research_compare")


def _calc_fetch(ctx):
    def fetch(url, form=None):
        ctx.app.permissions.ask(session_id=ctx.session_id, permission="webfetch", patterns=[url],
                                ruleset=ctx.agent.permission, always=["*"], metadata={"url": url},
                                abort_event=_abort_event(ctx))
        with httpx.Client(timeout=30, follow_redirects=True) as client:
            response = client.post(url, data=form) if form else client.get(url)
        return response.status_code, response.text
    return fetch


def _calc(args, ctx):
    from researchkit import calc
    kind, data = args["kind"], args["input"]
    if kind == "properties" and isinstance(data, dict) and isinstance(data.get("module"), str):
        module = file_for(ctx, data["module"])
        command = f"python {data['module']} (calc properties: {data.get('function')})"
        ctx.app.permissions.ask(session_id=ctx.session_id, permission="bash", patterns=[command],
                                ruleset=ctx.agent.permission, always=[command],
                                metadata={"command": command, "module": str(module)},
                                abort_event=_abort_event(ctx))
    value = calc.run(kind, data, root=root_for(ctx), fetch=_calc_fetch(ctx))
    data = records.encoded(calc.document(args["kind"], args["input"], value))
    relative = f"{calc.CALC_DIR}/{records.digest(data)[:16]}.json"
    destination = file_for(ctx, relative, "edit")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        destination.write_bytes(data)
    details = {key: item for key, item in value.items() if key != "conclusion"}
    text = (f"{value['conclusion']}\n\n"
            + json.dumps(details, ensure_ascii=False, indent=2, allow_nan=False, default=str)
            + f"\n\nDraft saved at {relative}. To cite it as evidence, save that file with research_record "
              "(kind=\"calc\"); until then it is a working calculation.")
    return ToolResult(title=f"calc {args['kind']}", output=truncate(text, label="calc"))


CALC_DESCRIPTION = (
    "Deterministic checks for what is easy to get wrong by eye; the answer starts with its conclusion. "
    "kind and an example input:\n"
    "- stats (more than chance?): {\"x\": [..], \"y\": [..]} or {\"groups\": {\"A\": [..], ..}}\n"
    "- sensitivity (does a ranking survive error or weights?): {\"sheets\": {\"P1\": {\"values\": {..}, "
    "\"direction\": \"higher\", \"sd\": 0.3}}, \"baseline_ids\": [..], \"candidate_ids\": [..]}, "
    "or {\"expr\": .., \"rows\": {..}, \"ranges\": {..}}\n"
    "- interval (range of a formula): {\"expr\": \"12 - k*(x - 2)\", \"ranges\": {\"k\": [0.5, 1.5], \"x\": [2, 3]}}, "
    "or \"normal\"/\"uniform\" for percentiles\n"
    "- logic (does a claim follow?): {\"premises\": [\"y = 12 - k*(x - 2)\", \"0.5 <= k <= 1.5\"], "
    "\"goal\": \"x <= 3 -> y >= 10\"}; \"find\" for an example\n"
    "- properties (does your code do what you say?): {\"module\": \"work/model.py\", \"function\": \"score\", "
    "\"checks\": [{\"value\": [[40.0, 0.0]], \"why\": \"known answer f(40) = 0\"}, {\"greater\": [[41.0, 45.0]], "
    "\"why\": \"f(41) > f(45)\"}]}; value pairs an input with its known output, greater/less/equal compare the "
    "outputs of two inputs; \"call\": \"kwargs\" for keyword inputs (each input an object), \"output\" picks part "
    "of the return value\n"
    "- causal (can the data separate an effect?): {\"rows\": {\"r1\": {\"catalyst\": \"X\", \"T\": 300}, ..}, "
    "\"target\": \"catalyst\"}, or {\"edges\": [..], \"treatment\": .., \"outcome\": ..}\n"
    "- constant (values with a source): {\"names\": [\"R\"]}, {\"smiles\": \"..\"}, {\"compound\": \"..\", "
    "\"experimental\": \"Boiling Point\"}\n"
    "- units: {\"expr\": \"Ea/(R*T)\", \"units\": {\"Ea\": \"kJ/mol\", ..}}, {\"convert\": \"2.5 kcal/mol\", "
    "\"to\": \"kJ/mol\"}, or recipe moles: {\"structures\": {name: SMILES}, \"records\": {\"A\": {\"resin\": "
    "{\"g\": 100, \"mol\": {\"X\": 35, \"Y\": 65}}, \"salt\": {\"g\": 5, \"wt\": {\"Z\": 1}}}}, \"ratio\": "
    "[\"Z\", \"X\"]}; \"readings\": {name: records} if a basis is unclear\n"
    "- design (what to measure next): {\"existing\": {..}, \"candidates\": {..}, \"pick\": 2}, or "
    "{\"predictions\": {\"H1\": {..}}, \"sd\": 0.4}\n"
    "- roles (which component can take a role defined by structure; each ion's acid strength): "
    "{\"structures\": {name: SMILES}, \"components\": {name: [fragments]}, \"features\": {feature: SMARTS}, "
    "\"roles\": {role: {\"requires\": [features]}}}\n"
    "Results are drafts under .research/calc/; research_record (kind calc) saves one to cite. Scripts: "
    "from researchkit import calc; calc.stats(x=[..], y=[..]). Zero model calls.")


@external_source
def _search(args, ctx):
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="websearch", patterns=[args["query"]],
                            ruleset=ctx.agent.permission, always=["*"], metadata={"provider": args["provider"]},
                            abort_event=_abort_event(ctx))
    destination = file_for(ctx, f".research/searches/{uuid.uuid4().hex}.json", "edit")
    response = literature.search(args["query"], args["provider"], args.get("limit", 5))
    response["retrieved_at"] = datetime.now(timezone.utc).isoformat()
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(records.encoded(response))
    # The receipt carries the bibliographic summary; the raw provider response
    # stays in the saved file (it repeated every item and made context grow fast).
    return ToolResult(title="paper_search", output=literature.summary(response, abstract_limit=500, authors_limit=3) +
                      f"\n\nComplete query, metadata, full abstracts and raw provider response: {destination}")


@external_source
def _literature_agent(args, ctx):
    from researchkit import literature_agent as agent
    url = agent.configured_url()
    if url is None:
        raise ValueError("No literature agent is configured (RESEARCH_LITERATURE_AGENT_URL)")
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="literature_agent", patterns=[url],
                            ruleset=ctx.agent.permission, always=["*"], metadata={"url": url},
                            abort_event=_abort_event(ctx))
    destination = file_for(ctx, f".research/agent-literature/{uuid.uuid4().hex}.json", "edit")
    client = agent.Client(url)
    saved = {"query": args["query"], "context_id": args.get("context_id"), "task_id": args.get("task_id"),
             "agent_url": url, "retrieved_at": datetime.now(timezone.utc).isoformat()}
    try:
        result = client.ask(args["query"], context_id=args.get("context_id"), task_id=args.get("task_id"))
    except agent.AgentError as error:
        saved.update(error=str(error), exchanges=client.exchanges, agent_card=client._card)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(records.encoded(saved))
        raise ValueError(f"{error}. The exchange so far is saved at {destination}") from None
    saved.update(agent_card=client.card(), result=result, exchanges=client.exchanges)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(records.encoded(saved))
    return ToolResult(title="literature_agent", output=agent.render(result, client.card(), str(destination)))


LITERATURE_AGENT_TOOL = Tool(
    "literature_agent", "Ask the organisation's literature agent (an external agent, over A2A) a research "
    "question in natural language. It breaks the question down, searches its own literature, including internal "
    "documents this session cannot search, and returns a synthesis with references. The synthesis is that agent's "
    "reading, not evidence read here: check the claims that matter against its references, fetch public ones with "
    "paper_fetch, and cite internal ones exactly as reported. If it needs more input, answer with the same "
    "context_id and task_id. The complete exchange is saved for citation.",
    schema({"query": prop("string", "The research question, in plain language, with its conditions"),
            "context_id": prop("string", "Continue an earlier exchange (from a previous answer)"),
            "task_id": prop("string", "Answer an agent that asked for more input (from a previous answer)")},
           ["query"]), _literature_agent)


@external_source
def _fetch(args, ctx):
    from opencode.tools.web import _html_to_text
    url = args["url"]
    if not isinstance(url, str) or not url.startswith(("http://", "https://")):
        raise ValueError("Use a public http(s) document URL")
    ctx.app.permissions.ask(session_id=ctx.session_id, permission="webfetch", patterns=[url],
                            ruleset=ctx.agent.permission, always=["*"], metadata={"url": url},
                            abort_event=_abort_event(ctx))
    folder = file_for(ctx, f".research/documents/{uuid.uuid4().hex}", "edit")
    with httpx.Client(timeout=60, follow_redirects=True) as client:
        with client.stream("GET", url, headers={"User-Agent": "researchkit/0.1"}) as response:
            response.raise_for_status()
            chunks = bytearray()
            for chunk in response.iter_bytes():
                chunks.extend(chunk)
                if len(chunks) > 20 * 1024 * 1024:
                    raise ValueError("Document exceeds 20 MiB; no partial download is presented as complete")
            content_type = response.headers.get("content-type", "")
            final_url = str(response.url)
            encoding = response.encoding or "utf-8"
    data = bytes(chunks)
    folder.mkdir(parents=True)
    (folder / "original.bin").write_bytes(data)
    metadata = {"requested_url": url, "final_url": final_url, "content_type": content_type,
                "sha256": records.digest(data), "retrieved_at": datetime.now(timezone.utc).isoformat()}
    (folder / "source.json").write_bytes(records.encoded(metadata))
    if data.startswith(b"%PDF"):
        import pymupdf
        with pymupdf.open(stream=data, filetype="pdf") as pdf:
            text = "\n\n".join(f"## Page {i + 1}\n{page.get_text()}" for i, page in enumerate(pdf))
    elif "html" in content_type:
        text = _html_to_text(data.decode(encoding, errors="replace"))
    elif content_type.startswith("text/") or "json" in content_type or "xml" in content_type:
        text = data.decode(encoding, errors="replace")
    else:
        raise ValueError(f"Unsupported document type {content_type}; downloaded original is at {folder}")
    text, replaced = clean_extracted_text(text)
    destination = folder / "text.txt"
    destination.write_text(text, encoding="utf-8")
    note = (f"{replaced} control characters from the extraction were replaced with spaces; "
            f"the original bytes are unchanged in {folder / 'original.bin'}.\n" if replaced else "")
    # v36 filled its context in 14 minutes, about 41,000 characters of it fetched full texts. The opening
    # (title, abstract, introduction) comes back; the rest is read or searched in the saved file when needed.
    shown = text if len(text) <= FETCH_EXCERPT else (
        text[:FETCH_EXCERPT] + f"\n\n…（全文共 {len(text)} 字，此處只列開頭；其餘請用 read 或 grep 讀 {destination}）")
    return ToolResult(title="paper_fetch", output=(
        f"Source receipt: {folder / 'source.json'}\nExtracted text: {destination} ({len(text)} characters)\n" + note +
        "Extraction alone does not verify relevance, completeness or scientific support; inspect the text.\n\n" + shown
        ))


FETCH_EXCERPT = 4000


_CONTROL = re.compile(r"[\x00-\x08\x0b\x0e-\x1f\x7f]")


def clean_extracted_text(text):
    """Replace control characters that PDF/HTML extraction leaves behind (e.g. unmapped glyphs).

    Keeps tab, newline, carriage return and form feed, which saved evidence may contain.
    Returns the text and how many characters were replaced.
    """
    return _CONTROL.subn(" ", text)


def _render(args, ctx):
    from researchkit.report import render
    from researchkit.report_evidence import resolve, validate_choices
    from researchkit.mindmap_schema import parse_map
    source = file_for(ctx, args["markdown_path"])
    evidence_choices = args.get("evidence_files", [])
    map_choices = args.get("mindmap_files", [])
    validate_choices(evidence_choices)
    validate_choices(map_choices, label="mindmap_files")
    # A file explicitly selected for both projections is read and verified once.
    choices = list({(item["record_ref"], item["source_path"]): item
                    for item in [*evidence_choices, *map_choices]}.values())
    resolved = resolve(root_for(ctx), choices, check_read=lambda path: ensure_access(ctx, path, "read"))
    by_choice = {(item["record_ref"], item["source_path"]): item for item in resolved}
    evidence = [by_choice[(item["record_ref"], item["source_path"])] for item in evidence_choices]
    mindmaps = []
    for choice in map_choices:
        item = by_choice[(choice["record_ref"], choice["source_path"])]
        if item["kind"] != "mindmap":
            raise ValueError("mindmap_files must select a saved kind=mindmap record")
        mindmaps.append({**item, "content": parse_map(item["text"])})
    # Only the DOIs and URLs of saved literature are read, to check the report's bibliography.
    saved_literature = report_citations.saved_identifiers(file_for(ctx, ".research"))
    destination = file_for(ctx, f".research/reports/{uuid.uuid4().hex}", "edit")
    try:
        options = {"evidence": evidence, "saved_literature": saved_literature}
        if mindmaps:
            options["mindmaps"] = mindmaps
        rendered = render(source, destination, **options)
        receipt = result(rendered, "render_report")
        receipt.metadata["files"] = [rendered["html_path"], rendered["pdf_path"],
                                     *(rendered[key] for key in ("evidence_html_path", "evidence_pdf_path")
                                       if key in rendered)]
        return receipt
    except Exception as exc:
        raise RuntimeError(f"Report render did not complete: {exc}. Any partial files remain at {destination}") from exc


TOOLS = [
    Tool("check_inference", "Check one source-bound formal implication with exact Bool/Real polynomial constraints "
         "(read materializer/references/inference.md first). Premises cite exact frozen files and literal quotes; "
         "added assumptions are kept apart from them. Saves the input, queries and result in an implementation "
         "record. A countermodel concerns the encoded relations, not measured samples; no result approves science.",
         INFERENCE_INPUT_SCHEMA, _inference),
    Tool("research_inference", "Like check_inference, but first runs the two-stage scientific review on the claim "
         "and its formalization without showing solver results, then solves the same frozen input (read "
         "materializer/references/inference.md). Returns the inference result and the saved review.",
         INFERENCE_INPUT_SCHEMA, _research_inference),
    Tool("research_method_explore", "Ask one bounded question about candidate scientific methods; a separate model "
         "call answers it from the selected frozen files and scope only (read "
         "final-kpi-proxy-discovery/references/method-exploration.md). Put the original commission in "
         "commission_files, also listed in files. Saves the note as a kind=method_exploration record; it adopts no "
         "formula.", METHOD_EXPLORATION_INPUT_SCHEMA, _method_explore),
    Tool("research_mindmap", "Build the research route landscape (mindmap-builder's source observation, route "
         "architecture and mechanism deepening) from selected frozen files; read mindmap-builder/SKILL.md first. "
         "task_ref is the saved task record, and one of its files must be in files. Saves a kind=mindmap record, "
         "and a checkpoint after each stage: resume_from continues from one, pause_after=architecture stops before "
         "deepening, and additional_evidence adds files at a deepening resume.", MINDMAP_INPUT_SCHEMA, _mindmap),
    Tool("research_review", "Run one scoped review of selected frozen files (read final-lca/references/review.md "
         "for selection and the review.json contract). Saves a kind=review record and returns the counts by decision "
         "and each check that is not supported, which research_deliver asks you to answer. Review the report "
         "Markdown before rendering it; a revised report needs no second review. Optional: commission_files (the "
         "original request, shown apart), required_subjects (quotes both review stages must assess), tool_call_ids "
         "(saved tool replies from this session to include as evidence). A review does not guarantee accuracy.",
         schema({"scope": prop("string", "Specific review commission, standards and limits", minLength=1),
                 "reviewed_refs": prop("array", "Exact relative record.json paths to assess", minItems=1,
                                       uniqueItems=True, items={"type": "string", "minLength": 1}),
                 "tool_call_ids": prop("array", "Optional saved tool call IDs from this session to include as evidence",
                                       uniqueItems=True, items={"type": "string", "minLength": 1, "pattern": "\\S"}),
                 "files": prop("array", "Exact frozen files made visible to the reviewer; select at least one "
                               "from each reviewed reference and explicitly include any evidence files", minItems=1,
                               uniqueItems=True, items=schema({
                                   "record_ref": prop("string", "Exact relative record.json path", minLength=1),
                                   "source_path": prop("string", "Exact files[].source_path", minLength=1)},
                                   ["record_ref", "source_path"])),
                 "commission_files": prop("array", "Optional original commission files, each also in files",
                                          uniqueItems=True, items=schema({
                                              "record_ref": prop("string", "Exact relative selected record.json path", minLength=1),
                                              "source_path": prop("string", "Exact selected source_path", minLength=1)},
                                              ["record_ref", "source_path"])),
                 "required_subjects": prop("array", "Optional exact quotes, from reviewed files, both stages must assess",
                                           uniqueItems=True, items=schema({
                                               "record_ref": prop("string", "Exact reviewed record.json path", minLength=1),
                                               "source_path": prop("string", "Exact selected source_path", minLength=1),
                                               "quote": prop("string", "Literal nonblank source quotation", minLength=1)},
                                               ["record_ref", "source_path", "quote"]))},
                ["scope", "reviewed_refs", "files"]), _review),
    Tool("research_deliver", DELIVER_DESCRIPTION, DELIVER_SCHEMA, _deliver),
    Tool("research_record", "Save exact copies of listed workspace files as an immutable record, with depends_on "
         "naming the earlier record.json paths actually used. List every file to keep (code, data, HTML, PDF); "
         "links inside files select nothing. For kind hypothesis, proxy_formula, calibration or sample_evolution "
         "pass template, the JSON the host stores for the board. revises replaces an earlier record of the same "
         "kind. Inline code holding a saved msg_ ID of this session also freezes that message or tool reply. "
         "kind=review needs a review.json (read final-lca/references/review.md). Only a successful kind=user_report "
         "publication selects this session's delivery version; research_deliver writes it with the Final-LCA. "
         "Mind maps come from research_mindmap. Read saved files with read.",
         schema({"kind": prop("string", "Record kind, e.g. task, prepared_data, hypothesis, proxy_formula, "
                              "implementation, calc, report"),
                 "title": prop("string", "Concise description"),
                 "files": prop("array", "Workspace file paths to preserve, including numerical/code evidence when relevant", items={"type": "string"}),
                 "depends_on": prop("array", "Exact earlier record.json paths actually used", items={"type": "string"}),
                 "revises": prop("string", "Optional record.json of an earlier record of the same kind that this one "
                                 "replaces; the board then shows only the newer one (a formula keeps its formula_id)"),
                 "template": prop("object", "For kind hypothesis, proxy_formula, calibration or sample_evolution: the "
                                  "JSON saved as hypotheses.json, proxy_formula.json, calibration.json or "
                                  "evolution.json in this record. One formula per proxy_formula record.")},
                ["kind", "title"]), _publish),
    Tool("research_list", "List saved records with their files, dependencies and depended_on_by. files[].snapshot "
         "paths are readable with read.", schema({}, []), _list),
    Tool("research_board", "Read the research board rebuilt from saved records: task, hypotheses, formulas, history "
         "checks, leaderboards, evolutions, reviews and open notices. Read-only; it lists facts, not scientific "
         "judgments.", schema({}, []), _board),
    Tool("research_graph_update", "Record reasoning the saved records do not hold: open questions and their answers, "
         "decisions that are not template fields, overturned observations, and replies to board notices ([N…]). "
         "Edges: based_on, and supports/contradicts from an observation to a conjecture; a conjecture other than "
         "proposed needs that evidence. When something upstream changes, the board marks dependent nodes for "
         "review.", GRAPH_UPDATE_SCHEMA, _graph_update),
    Tool("research_history_check", "Check proxy formulas on the historical samples before generating candidates. "
         "Save the formula records, then a values table as an implementation record that depends on them, and "
         "give each formula's column; for a model with terms the table holds each term's quantity per sample, in "
         "the column its terms[].quantity names, not a score column. Reports the order against each formula's kpi (confounded_with when the "
         "samples cannot separate formulas) and, with measured, the offset and spread; a model with terms gets the "
         "coefficients its history and signs allow instead. Saves a kind=history_check record.",
         HISTORY_CHECK_INPUT_SCHEMA, _history_check),
    Tool("research_leaderboard", "Rank one pool of historical baselines and candidates on every active hypothesis's "
         "formula, one sheet each (identical sheets are refused), reading one values table with a column per "
         "formula (values.column), or for a model with terms a column per term quantity (terms[].quantity), "
         "the same table research_history_check read. Ranks only, never a weighted total. Each sheet gets an evidence level (history, "
         "history_reversed, history_fitted, mechanism_only, llm_judge) and each candidate a verdict: robust_surpass "
         "(better on a history sheet, worse on none, two or more history sheets), surpass_one_sheet, "
         "tradeoff_surpass, conditional_surpass (see conditional_on) or no_surpass; also the Pareto front and the "
         "most disputed candidates. A model with terms compares under every coefficient set its history allows "
         "(better, worse or undecided). Saves a kind=leaderboard record; ranks do not prove a real KPI.",
         LEADERBOARD_INPUT_SCHEMA, _leaderboard),
    Tool("research_judge", "Score samples with a blinded, repeated LLM judge for a hypothesis no formula can compute "
         "even for new designs (read the research-judge skill first). samples describe composition or structure "
         "only. Saves a kind=judgment record whose values make an llm_judge sheet in research_leaderboard "
         "(conditional surpass only).",
         _JUDGE_SCHEMA, _judge),
    Tool("research_compare_candidates", "Compare chosen baseline and candidate IDs on one values file, read as "
         "research_leaderboard reads it. When method_ref is a proxy_formula record, its declared direction, target "
         "and anchor rank the samples; otherwise give direction (and target_value). The values record must depend "
         "on method_ref. Saves comparison.json in an implementation record; a positive delta means better.",
         CANDIDATE_COMPARISON_INPUT_SCHEMA, _compare_candidates),
    Tool("research_compare", "Compute Kendall tau-b and Spearman agreement for actual proxy values versus the task-defined "
         "target-satisfaction values. The author supplies the target transform; this tool does not guess it or fit a formula.",
         schema({"proxy_path": prop("string", "JSON object mapping every selected sample ID to its actual numeric proxy value"),
                 "target_path": prop("string", "JSON object with the same IDs and declared target-satisfaction values, higher is better"),
                 "direction": prop("string", "Which proxy direction predicts greater target satisfaction; target when "
                                   "the proxy predicts a quantity whose best value is target_value", enum=["higher", "lower", "target"]),
                 "target_value": prop("number", "Best value of the predicted quantity; only with direction target")},
                ["proxy_path", "target_path", "direction"]), _compare),
    Tool("calc", CALC_DESCRIPTION,
         schema({"kind": prop("string", "What to calculate", enum=["stats", "sensitivity", "interval", "logic", "properties", "causal",
                                                          "constant", "units", "design", "roles"]),
                 "input": prop("object", "Inputs for that kind, as in the examples above")}, ["kind", "input"]),
         _calc),
    Tool("research_simulate", SIMULATE_DESCRIPTION, SIMULATE_SCHEMA, _simulate),
    Tool("paper_search", "Search scholarly metadata and abstracts: openalex (broadest, with links to free full "
         "text), crossref (DOI metadata), arxiv (preprints), pubmed (biomedical). Returns each hit's title, year, "
         "DOI, link and the start of its abstract; the complete response is saved (read its path for more). Use "
         "paper_fetch for a known document URL, websearch for patents and general sites.",
         schema({"query": prop("string", "Specific research question/terms; arxiv also accepts its API query syntax"),
                 "provider": prop("string", "Select a relevant provider",
                                  enum=["openalex", "crossref", "arxiv", "pubmed"]),
                 "limit": prop("integer", "Maximum results, 1-10", minimum=1, maximum=10)}, ["query", "provider"]), _search),
    Tool("paper_fetch", "Fetch a known paper/document URL and save its original bytes, URL provenance and extracted HTML/PDF text. "
         "HTTP failures remain failures; use read for complete saved text.",
         schema({"url": prop("string", "Document URL obtained from an actual source")}, ["url"]), _fetch),
    Tool("render_report", "Render report Markdown to HTML and PDF (needs an installed Chromium, Chrome or Edge). "
         "Cite literature as [@key] (several: [@a; @b]) with entries written [@key]: authors, title, venue "
         "volume(issue), pages (year). DOI; they are numbered in order and checked against saved literature. "
         "Notes [^name] go to an appendix; evidence links [n](#evidence-n) read as En. evidence_files are printed "
         "in full to evidence.html/pdf; mindmap_files draw saved mind maps. Returns the paths and the citation, "
         "layout and style checks.",
         schema({"markdown_path": prop("string", "Existing report Markdown in this workspace"),
                 "evidence_files": prop("array", "Optional frozen text files printed in full to evidence.html/pdf",
                                        uniqueItems=True, items=schema({
                                            "record_ref": prop("string", "Exact relative .research/records/<hash>/record.json path",
                                                               minLength=1),
                                            "source_path": prop("string", "Exact files[].source_path", minLength=1)},
                                            ["record_ref", "source_path"])),
                 "mindmap_files": prop("array", "Optional saved mindmap.json files to draw",
                                       uniqueItems=True, items=schema({
                                           "record_ref": prop("string", "Exact relative kind=mindmap record.json path",
                                                              minLength=1),
                                           "source_path": prop("string", "Exact files[].source_path", minLength=1)},
                                           ["record_ref", "source_path"]))}, ["markdown_path"]), _render),
]

# Offered only when a literature agent is configured, so the model never calls an absent service.
if literature_agent_module.configured_url():
    TOOLS.append(LITERATURE_AGENT_TOOL)


def _resolving(tool):
    """Make record references exact before the tool runs, and say what was changed."""
    run = tool.execute

    @functools.wraps(run)
    def execute(args, ctx):
        args, notes = records.resolve_references(args, root_for(ctx))
        result = run(args, ctx)
        if notes and isinstance(result, ToolResult):
            result.output += ("\n\nHost note: resolved record references whose leading characters match "
                              "exactly one saved record: " + "; ".join(notes))
        # A tool can leave a note for the model in its metadata without changing its output contract.
        if isinstance(result, ToolResult) and isinstance(result.metadata.get("host_note"), str):
            result.output += "\n\nHost note: " + result.metadata.pop("host_note")
        return result

    if external_source_names([tool]):
        external_source(execute)  # source producers are registered by their execute function
    return Tool(tool.name, tool.description, tool.parameters, execute)


TOOLS = [_resolving(tool) for tool in TOOLS]
