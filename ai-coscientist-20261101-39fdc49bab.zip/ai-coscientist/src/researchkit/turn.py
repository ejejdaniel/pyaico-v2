"""Research-only recovery and display on the installed Common turn interface."""

import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace

from opencode.deep import skills as installed_skills, tools as deep_tools
from opencode.permission import Rule, merge
from opencode.tools import builtin_tools, tools_for
from opencode.tools.types import external_source_names
from opencode.tools.util import ensure_access
from researchkit import records


class ResearchTurn:
    def __init__(self, app, session_id: str, user_message_id: str):
        self.app = app
        self.session_id = session_id
        self.user_message_id = user_message_id

    def _agent(self):
        session = self.app.store.get_session(self.session_id)
        name = session.get("agent") or self.app.default_agent
        agent = self.app.agents[name]
        if agent.hidden and agent.name in {"title", "summary", "compaction"}:
            return None
        agent = replace(agent, permission=merge(agent.permission,
                        [Rule(**rule) for rule in session.get("permission") or []]))
        # Deep research's tools too (opencode/deep.py): with only the folder's own, no research turn ran from the
        # switch (2026-10-31) until 2026-11-01.
        return agent if any(t.name == "research_record" for t in tools_for(agent, deep_tools(self.app))) else None

    def _check_read(self, path: Path):
        agent = self._agent()
        if agent is None:
            raise PermissionError("Research publication is not authorized for the current agent")
        ctx = SimpleNamespace(app=self.app, session_id=self.session_id, agent=agent,
                              directory=self.app.directory, worktree=self.app.worktree)
        ensure_access(ctx, path, "read")

    def context(self) -> str:
        if self._agent() is None:
            return ""
        python_environment = ""
        if self.app.store.get_session(self.session_id)["parentID"] is None:
            if not sys.executable:
                raise RuntimeError("Cannot deliver Python environment information: sys.executable is empty")
            python_environment = ("本工作階段使用的 Python 直譯器完整路徑："
                                  f"{json.dumps(os.path.abspath(sys.executable), ensure_ascii=False)}。")
        # Research publication can cite saved message IDs. Their discoverability
        # belongs to this explicitly installed extension, not the Common prompt.
        producers = external_source_names([*builtin_tools(self.app.config), *deep_tools(self.app)])
        self.app.store.export_tool_history(self.session_id, source_tools=producers)
        from researchkit.research_context import context as evidence_context
        from researchkit import board, graph
        history = self.app.store.messages(self.session_id)
        try:
            research_board = board.context(self.app.directory, history, check_read=self._check_read,
                                           requirements=graph.planning_requirements(self.app, self.session_id),
                                           hypothesis_budget=board.configured_budget(self.app.config))
        except (OSError, ValueError, KeyError, TypeError) as exc:
            research_board = f"{board.TITLE}\n目前無法由已保存紀錄產生：{exc}"
        from researchkit import host_source
        research_config = self.app.config.get("research") if isinstance(self.app.config, dict) else None
        self_improvement = isinstance(research_config, dict) and research_config.get("self_improvement") is True
        utf8 = ("shell 工具執行的 Python 已是 UTF-8 模式（PYTHONUTF8=1）：讀寫檔案與印出中文都不需要包裝 "
                "sys.stdout 或處理 cp950。") if python_environment else ""
        from researchkit import skill_guidance
        return "\n\n".join(filter(None, [
            python_environment,
            host_source.notice(history, self_improvement=self_improvement),
            records.delivery_progress(self.app.directory, history, check_read=self._check_read),
            self.app.store.tool_history_overview(self.session_id),
            self.app.store.source_overview(self.session_id),
            evidence_context(self.app, self.session_id, self.user_message_id),
            research_board,
            self._verification_evidence(),
            utf8,
            # Deep research's skills too (opencode/deep.py): the research turn runs only while it is on.
            skill_guidance.context(history, installed_skills(self.app)),
        ]))

    def _verification_evidence(self) -> str:
        """The checking evidence the host can see, when the task has a verification plan with checks
        (opencode/verification.py; a verdict that none is needed has none).

        Only saved, framework-checked things count: a mounted task tool's known-answer tests, run when it was
        mounted, and the value and leaderboard records the framework computes. A check of the plan whose
        evidence is not here is not ready, whatever the agent concluded."""
        from opencode.task_skills import root_session
        from opencode.verification import saved_plan

        root = root_session(self.app.store, self.session_id)
        if not (saved_plan(root) or {}).get("checks"):
            return ""
        directory = Path(self.app.directory)
        try:
            from researchkit.simulation import task_tools
            tools = [f"{tool['id']}（{tool['tests']}）" for tool in task_tools.listing(directory, root)["tools"]
                     if tool.get("status") == "mounted"]
        except (OSError, ValueError, KeyError, TypeError) as exc:
            tools = [f"無法列出：{exc}"]
        kinds = {"implementation": "實作數值", "simulation": "模擬數值", "leaderboard": "排名"}
        saved = []
        for path in sorted((directory / ".research" / "records").glob("*/record.json")):
            if path.parent.name.startswith(".staging-"):
                continue
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if record.get("kind") in kinds:
                saved.append(f"{kinds[record['kind']]}「{record.get('title')}」")
        return ("驗證計畫的就緒證據（宿主依已存紀錄列出，不是判斷）：已掛載、已知答案測試通過的任務工具："
                + ("、".join(tools[:6]) if tools else "無")
                + "；框架算出的數值與排名紀錄：" + ("、".join(saved[-6:]) if saved else "無")
                + "。驗證計畫裡要靠工具或算出數值的檢查，就緒的證據還沒出現在這裡的，都是未就緒；"
                  "靠出處核對的檢查，以答案裡可回查的出處為準，不必另存紀錄。")

    def delivery_state(self) -> str | None:
        """'clean' or 'issues' for a delivery selected in this turn, None when there is none.

        The loop asks this before reminding about open todos: a delivery with issues
        goes to the delivery check, and a clean one only needs a stale todo list closed.
        """
        if self._agent() is None:
            return None
        history = self.app.store.messages(self.session_id)
        start = next(i for i, m in enumerate(history) if m["id"] == self.user_message_id)
        ref = records.selected_delivery(history[start + 1:])
        if ref is None:
            return None
        return "issues" if records.delivery_issues(self.app.directory, ref, check_read=self._check_read) else "clean"

    def feedback(self) -> str | None:
        if self._agent() is None:
            return None
        history = self.app.store.messages(self.session_id)
        start = next(i for i, m in enumerate(history) if m["id"] == self.user_message_id)
        # Saved context does not commission repairs; this turn must select a delivery.
        ref = records.selected_delivery(history[start + 1:])
        issues = records.delivery_issues(self.app.directory, ref, check_read=self._check_read) if ref else []
        return records.delivery_repair_packet(ref, issues) if issues else None

    def present(self, text: str, status: str) -> str:
        if self._agent() is None:
            return text
        history = self.app.store.messages(self.session_id)
        ref = records.selected_delivery(history)
        if ref is None:
            return text
        if status != "completed":
            return text + f"\n\n本輪已停止，未宣稱完成交付。已保存交付定位：`{ref}`。"
        issues = records.delivery_issues(self.app.directory, ref, check_read=self._check_read)
        if issues:
            return text + ("\n\n## 科研交付尚未接妥\n\n"
                           f"本工作階段選定 `{ref}`，但下列正式交接仍未完成。"
                           "模型的口頭完成宣稱不能取代這些成果；已完成工作保留，未自動重跑。\n\n" +
                           "\n".join(f"- {issue}" for issue in issues))
        # Only a matched publication made after this human message selects a new display.
        start = next(i for i, m in enumerate(history) if m["id"] == self.user_message_id)
        if records.selected_delivery(history[start + 1:]) != ref:
            return text
        return self._documents(ref) + self._open_notices() + "\n\n## 本輪工作說明（模型原文）\n\n" + text

    def _open_notices(self) -> str:
        """Action notices the author left unanswered, shown to the human with the delivery."""
        from researchkit import board
        try:
            value = board.build(self.app.directory, check_read=self._check_read)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            return f"\n\n## 宿主看板提醒\n\n未能完成看板檢查：{exc}"
        items = board.open_actions(value)
        if not items:
            return ""
        return ("\n\n## 尚未處理的宿主提醒\n\n以下是機械比對的結果，不是科學判斷；交付已保存，但作者沒有處理或回覆這些提醒。\n\n"
                + "\n".join(f"- [{item['id']}] {item['text']}" for item in items))

    def _documents(self, ref: str) -> str:
        root = self.app.directory
        record = records.read_record(root, ref, check_read=self._check_read)
        folder = records.local_path(root, ref).parent
        parts = ["## 已保存的交付文件", f"精確成果：`{ref}`。以下是凍結原文，不代表宿主判定科學內容正確。"]
        used_bytes = used_lines = 0
        for item in record["files"]:
            path = records.local_path(folder, item["snapshot"])
            parts.append(f"### {item['source_path']}\n\n[原始凍結檔案](<{path.as_posix()}>) "
                         f"（{item['bytes']} bytes，SHA-256 `{item['sha256']}`）")
            if path.suffix.lower() not in {".md", ".markdown", ".txt"}:
                continue
            data = path.read_bytes()
            if records.digest(data) != item["sha256"] or len(data) != item["bytes"]:
                raise ValueError(f"Recorded file changed during presentation: {path}")
            try:
                body = data.decode("utf-8-sig")
            except UnicodeDecodeError:
                parts.append("此檔案不是有效 UTF-8，未展開正文；請由上述入口讀取原檔。")
                continue
            size, lines = len(data), len(body.splitlines())
            if used_bytes + size > 50 * 1024 or used_lines + lines > 2000:
                parts.append("此文件超過本次內嵌呈現的剩餘容量，未展開；上述入口保留完整原文。")
                continue
            used_bytes += size
            used_lines += lines
            parts.append(body)
        for dependency in record["depends_on"]:
            report = records.read_record(root, dependency, check_read=self._check_read)
            if report["kind"] != "report":
                continue
            parts.append(f"### 報告檔案\n\n精確成果：`{dependency}`")
            report_folder = records.local_path(root, dependency).parent
            for item in report["files"]:
                path = records.local_path(report_folder, item["snapshot"])
                if path.suffix.lower() in {".html", ".pdf"}:
                    parts.append(f"- [{item['source_path']}](<{path.as_posix()}>) "
                                 f"（{item['bytes']} bytes，SHA-256 `{item['sha256']}`）")
        return "\n\n".join(parts)


TURN_EXTENSION = ResearchTurn
