"""One values file read the same way by every tool that ranks or compares proxy values.

A values file is a table with one row per sample (historical baselines and candidates) and one
column per formula, `{"<sample id>": {"<formula id>": number, ...}, ...}`, read one column at a
time through `column`; a flat `{"<sample id>": number}` map is read without `column`.
research_history_check, research_leaderboard and research_compare_candidates all select values
with {record_ref, source_path, column?}, so one saved file serves all three. A CSV/TSV file is
read one column at a time too, with the sample IDs in its first column: a formula's kpi or
measured selection can point at the prepared data table where the measurements are.

A JSON list of rows is a values table as well when one field names each row's sample (a run kept
its measurements as [{"sample_id": "S1", "measured": {"yield_pct": 12.1}}, ...], was refused, and
spent six minutes copying them into new files). Nested columns are named with dots, as
"measured.yield_pct".
"""

from __future__ import annotations

import difflib
import json
import math

from researchkit.knowledge import tables
from researchkit.report_evidence import resolve

MAX_BYTES = 262144
_TEXT = {"type": "string", "minLength": 1, "pattern": r"\S"}
SELECTION = {
    "type": "object",
    # column null means no column, as when it is left out: a flat map is selected whole.
    "properties": {"record_ref": dict(_TEXT), "source_path": dict(_TEXT),
                   "column": {"type": ["string", "null"], "minLength": 1, "pattern": r"\S"}},
    "required": ["record_ref", "source_path"], "additionalProperties": False,
}
SHAPE = ('{"<sample id>": {"<column>": number, ...}, ...}, or a list of rows [{"<id field>": "<sample id>", '
         '"<column>": number, ...}, ...]')
SAVE_ORDER = ("Save each formula as its own kind=proxy_formula record first; then save the values table in a "
              "kind=implementation record whose depends_on lists every formula record it has a column for, or "
              "select the table a research_simulate run saved (a route's or a task tool's kind=simulation record, "
              "run with depends_on listing those formula records). "
              "The values depend on the formulas, never the reverse.")
# Kinds of record a values selection may name; research_judge's kind=judgment is accepted by the leaderboard only.
VALUE_KINDS = ("implementation", "simulation")


def selection(value):
    """The selection without a null column, as it is stored and echoed."""
    return {key: item for key, item in value.items() if not (key == "column" and item is None)}


def dependency_error(root, method_ref, values_ref, read, label):
    """Why a values record does not depend on its formula, and how to save it so that it does."""
    from researchkit import records

    message = f"{label} must directly or recursively depend on {method_ref}. {SAVE_ORDER}"
    try:
        method_closure = records._read_dependencies(root, [method_ref], check_read=read)
        values_closure = records._read_dependencies(root, [values_ref], check_read=read)
    except (OSError, ValueError, KeyError):
        return ValueError(message)
    formulas = [ref for ref, record in values_closure.items() if record.get("kind") == "proxy_formula"]
    if values_ref in method_closure:
        message += (f" Here {method_ref} itself depends on {values_ref}, the opposite direction: save the values "
                    "table again as a new implementation record that depends on the formula records; the formula "
                    "records can stay as they are.")
    elif earlier := [ref for ref in formulas if ref in method_closure]:
        message += (f" The values depend on {', '.join(earlier)}, which {method_ref} itself builds on: an earlier "
                    f"version, so the values predate it. Save the values table again as an implementation record "
                    f"that depends on {method_ref}; recompute the values first if the revision changed how they are "
                    "calculated.")
    else:
        message += (f" The values record depends on these formula records: {', '.join(formulas) or 'none'}.")
    return ValueError(message)


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError(f"Invalid JSON constant: {value}")


NO_VALUE = ("Every selected sample needs a number. A formula with no value for some samples (undefined on the "
            "historical samples, say) cannot be ranked or checked on them: leave its sheet out of this call, or "
            "select values that cover every sample")


def _number(sample_id, number):
    if type(number) not in (int, float):
        # v24 kept null for a formula undefined on the history and was told only "not a boolean or string",
        # seven times.
        found = ("null (no value)" if number is None else f"the text {number!r}" if isinstance(number, str)
                 else f"{str(number).lower()}" if isinstance(number, bool) else f"a {type(number).__name__}")
        raise ValueError(f"Value for {sample_id!r} is {found}, not a JSON number. {NO_VALUE}")
    try:
        number = float(number)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"Value for {sample_id!r} cannot convert to a finite float") from exc
    if not math.isfinite(number):
        raise ValueError(f"Value for {sample_id!r} must convert to a finite float")
    return number


def numeric_values(text):
    """{sample: float} from a flat JSON map of sample IDs to numbers."""
    values = json.loads(text, object_pairs_hook=_unique_keys, parse_constant=_invalid_constant)
    if not isinstance(values, dict) or not values:
        raise ValueError("Selected values must be a nonempty JSON object mapping IDs to numbers")
    converted = {}
    for sample_id, number in values.items():
        if not isinstance(sample_id, str) or not sample_id.strip():
            raise ValueError("Every values ID must be nonblank text")
        converted[sample_id] = _number(sample_id, number)
    return converted


def _names(items):
    items = list(items)
    return ", ".join(items[:6]) + (f" and {len(items) - 6} more" if len(items) > 6 else "")


def _flat(row, prefix=""):
    """A row by column, nested objects joined with dots: {"measured": {"yield": 1}} -> {"measured.yield": 1}."""
    flat = {}
    for key, value in row.items():
        if isinstance(value, dict) and value:
            flat.update(_flat(value, f"{prefix}{key}."))
        else:
            flat[f"{prefix}{key}"] = value
    return flat


def _id_field(rows, label):
    """The one field of a list of rows that names each row's sample: unique nonblank text in every row."""
    shared = [key for key in rows[0] if all(key in row for row in rows[1:])]
    found = [key for key in shared if all(isinstance(row[key], str) and row[key].strip() for row in rows)
             and len({row[key] for row in rows}) == len(rows)]
    if len(found) > 1:
        named = [key for key in found if key.lower().endswith("id")]
        found = named if len(named) == 1 else found
    if len(found) != 1:
        which = f"several fields could ({_names(found)})" if found else "no field has unique sample IDs in every row"
        raise ValueError(f"The {label} file is a list of rows, and {which}. Give every row one field of unique "
                         f"sample IDs (its name ending in id when other fields are unique too), or write {SHAPE}")
    return found[0]


def _numbers_only(flat):
    """Columns holding a number in at least one row."""
    return [key for key in dict.fromkeys(k for row in flat.values() for k in row)
            if any(type(row.get(key)) in (int, float) for row in flat.values())]


def column_values(text, column, label="values"):
    """{sample: float} from a flat map (column None) or one column of a values table."""
    data = json.loads(text, object_pairs_hook=_unique_keys, parse_constant=_invalid_constant)
    if isinstance(data, list) and data:
        if not all(isinstance(row, dict) and row for row in data):
            raise ValueError(f"The {label} file is a JSON list; a list must hold one object per sample: {SHAPE}")
        key = _id_field(data, label)
        data = {row[key]: {name: value for name, value in row.items() if name != key} for row in data}
    if not isinstance(data, dict) or not data:
        raise ValueError(f"The {label} file must be a nonempty JSON values table: {SHAPE}")
    rows = [sample for sample, value in data.items() if isinstance(value, dict)]
    plain = [sample for sample in data if sample not in rows]
    if rows and plain:
        raise ValueError(f"The {label} file mixes plain numbers ({_names(plain)}) with rows ({_names(rows)}). "
                         f"Write one row per sample, each with the same columns: {SHAPE}")
    if column is None:
        columns = list(dict.fromkeys(key for row in data.values() if isinstance(row, dict) for key in _flat(row)))
        if columns:
            raise ValueError(f"The {label} file is a values table (one row per sample); add {label}.column "
                             f"naming the column to use: {_names(columns)}")
        return numeric_values(text)
    if not rows:
        raise ValueError(f"{label}.column selects a column of a values table {SHAPE}; this file maps samples "
                         "straight to numbers, so leave column out")
    flat = {sample: _flat(row) for sample, row in data.items()}
    absent = [sample for sample, row in flat.items() if column not in row]
    if absent:
        numbers = _numbers_only(flat)
        others = [key for key in numbers if key != column]
        like = [key for key in others if column.lower() in key.lower()] or difflib.get_close_matches(column, others)
        raise ValueError(f"Column {column!r} is missing for: {_names(absent)}. "
                         + (f"Number columns like it: {', '.join(like[:6])}. " if like else "")
                         + f"Number columns in the file: {_names(numbers)}")
    return {sample: _number(sample, row[column]) for sample, row in flat.items()}


def table_column(source_path, text, column, label="values"):
    """{sample: float} from one column of a CSV/TSV whose first column holds the sample IDs.

    Measured KPIs usually stay in the prepared data table, so a kpi or measured selection can
    point at it directly. A blank cell means that sample has no value in this column.
    """
    parsed = tables.read_table({"source_path": source_path, "text": text})
    if parsed is None:
        raise ValueError(f"The {label} file {source_path} is not a table: it needs a header row and data rows "
                         "of the same length")
    header, body = parsed
    if column is None:
        raise ValueError(f"The {label} file {source_path} is a table; add {label}.column naming the column to "
                         f"use: {_names(header[1:])}")
    if column not in header:
        raise ValueError(f"Column {column!r} is not in {source_path}. Columns: {_names(header)}")
    index = header.index(column)
    if index == 0:
        raise ValueError(f"{label}.column {column!r} is the first column of {source_path}, which holds the "
                         "sample IDs; name a column of values")
    values, seen = {}, set()
    for row in body:
        sample, cell = row[0].strip(), row[index].strip()
        if not sample:
            raise ValueError(f"A row of {source_path} has no sample ID in its first column ({header[0]})")
        if sample in seen:
            raise ValueError(f"Sample ID {sample!r} appears more than once in {source_path}")
        seen.add(sample)
        if not cell:
            continue
        number = tables.number(cell)
        if number is None:
            raise ValueError(f"Column {column!r} of {source_path} has no number for {sample!r}: {cell!r}")
        values[sample] = number
    if not values:
        raise ValueError(f"Column {column!r} of {source_path} has no numbers")
    return values


def require_samples(values, sample_ids, selection, label, owner=None):
    """Refuse measured values keyed by none of the historical samples they are compared on.

    v22 pointed kpi at a CSV keyed by formulation strings while its predictions used HIST1 and
    HIST2; nothing matched, and the history check reported only that the order was unchecked.
    v32 met the same mismatch, was told to "select, or save" values keyed by its IDs, and saved
    nine KPI tables in 25 minutes: the selection is inside the saved formula, so a new table
    alone changes nothing.
    """
    if any(sample in values for sample in sample_ids):
        return values
    where = selection["source_path"] + (f" column {selection['column']!r}" if selection.get("column") else "")
    whose = f"{owner}'s" if owner else "The formula's"
    raise ValueError(
        f"The {label} values in {where} have no entry for the historical samples {_names(sample_ids)}; that file's "
        f"sample IDs are {_names(values)}. {whose} {label} selection is part of its saved proxy_formula.json, which "
        f"does not change, so saving another {label} table alone changes nothing. Either (1) use the file's IDs for "
        f"the historical samples: key their rows of the values table by {_names(values)} and pass those IDs as "
        f"baseline_ids; or (2) save a revised formula (research_record with revises) whose {label} selects values "
        f"keyed by {_names(sample_ids)}. A revision made to fix this, before the formula's history has been "
        "checked, is not counted as fitted")


def read(root, selection, check_read, label="values"):
    """(numbers, sha256 of the file) for one {record_ref, source_path, column?} selection."""
    selected, = resolve(root, [{k: v for k, v in selection.items() if k != "column"}], check_read=check_read)
    if selected["bytes"] > MAX_BYTES:
        raise ValueError(f"Selected {label} file has {selected['bytes']} bytes, more than {MAX_BYTES}. Select a file "
                         "with only the samples this call uses (the historical samples and the candidates it ranks), "
                         "not the whole design space")
    path = selected["source_path"]
    try:
        if path.lower().endswith((".csv", ".tsv")):
            return table_column(path, selected["text"], selection.get("column"), label), selected["sha256"]
        try:
            return column_values(selected["text"], selection.get("column"), label), selected["sha256"]
        except json.JSONDecodeError as exc:
            raise ValueError(f"The {label} file {path} is not JSON ({exc}). Select a JSON values table {SHAPE}, a "
                             f"flat JSON map of sample IDs to numbers, or a CSV/TSV whose first column holds the "
                             f"sample IDs with {label}.column naming the column") from None
    except ValueError as error:
        raise ValueError(f"{error}{_stale(root, path, selected['sha256'], selection.get('record_ref'), check_read)}"
                         ) from None


def _stale(root, path, sha256, ref, check_read):
    """A note when the working file differs from the copy the record saved, which is what the tools read.

    A run (2026-11-01) rewrote a values file three times and was refused three times the same way: the
    leaderboard read the record's saved copy, and the refusal did not say so.
    """
    from pathlib import Path
    from researchkit import records
    try:
        working = Path(root) / path
        if not working.is_file():
            return ""
        if check_read:
            check_read(working)
        if records.digest(working.read_bytes()) == sha256:
            return ""
    except Exception:
        return ""
    return (f". The tools read the copy that record {ref} saved, and the working file {path} has changed since: "
            "save the current file in a new record (research_record) and select that record")
