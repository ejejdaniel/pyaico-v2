"""Deterministic App cancellation boundaries; no remote models are called."""

import json
import socket
import threading
import time
from contextlib import contextmanager
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.compaction import compact
from opencode.loop import _title
from opencode.permission import PermissionRejected
from opencode.provider import Completion, ProviderError
from opencode.store import Store
from opencode.tools.types import ToolResult


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    runtime = App(tmp_path, store=Store(tmp_path / "state.db"), config={"model": "local/test"})
    runtime.generate_titles = False
    def unexpected_request(**kwargs):
        raise AssertionError("This boundary must install its own deterministic model response")
    runtime.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                       complete=unexpected_request)
    yield runtime
    for session in runtime.store.list_sessions():
        runtime.abort(session["id"])
    runtime.store._conn.close()


def _child(app, parent):
    return app.store.create_session(directory=str(app.directory), agent="build", model="local/test",
                                    parent_id=parent)["id"]


def _wait(predicate, timeout=2):
    deadline = time.monotonic() + timeout
    while not predicate():
        if time.monotonic() > deadline:
            raise AssertionError("Timed out waiting for the tested boundary")
        threading.Event().wait(0.005)


@contextmanager
def _blocked_http():
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    listener.settimeout(5)
    state = {"ready": threading.Event(), "closed": threading.Event()}

    def serve():
        try:
            connection, _ = listener.accept()
            with connection:
                connection.settimeout(5)
                data = b""
                while b"\r\n\r\n" not in data:
                    chunk = connection.recv(65536)
                    if not chunk:
                        raise AssertionError("Client closed before sending its request")
                    data += chunk
                header, body = data.split(b"\r\n\r\n", 1)
                size = next(int(line.split(b":", 1)[1]) for line in header.split(b"\r\n")
                            if line.lower().startswith(b"content-length:"))
                while len(body) < size:
                    body += connection.recv(65536)
                state["body"] = json.loads(body)
                state["ready"].set()
                try:
                    if connection.recv(1) == b"":
                        state["closed"].set()
                except ConnectionResetError:
                    state["closed"].set()
        except BaseException as exc:
            state["error"] = exc
            state["ready"].set()

    thread = threading.Thread(target=serve, name="app-abort-http-server")
    thread.start()
    try:
        state["url"] = f"http://127.0.0.1:{listener.getsockname()[1]}/v1"
        yield state
    finally:
        listener.close()
        thread.join(6)
        assert not thread.is_alive()
        if "error" in state:
            raise state["error"]


def test_app_abort_closes_real_provider_socket_and_saves_interrupted_message(app):
    with _blocked_http() as server:
        from opencode.provider import Client

        app.provider = Client(app.auth, {"provider": {"local": {
            "api": "openai", "options": {"baseURL": server["url"], "apiKey": "local-test"},
            "models": {"test": {}},
        }}})
        sid = app.create_session()["id"]
        outcome = {}

        def prompt():
            try:
                outcome["result"] = app.prompt(sid, "Preserve this exact human request")
            except BaseException as exc:
                outcome["error"] = exc

        thread = threading.Thread(target=prompt)
        thread.start()
        try:
            assert server["ready"].wait(3)
            assert "error" not in server
            started = time.monotonic()
            app.abort(sid)
            thread.join(2)
            assert not thread.is_alive()
            assert time.monotonic() - started < 1
            assert server["closed"].wait(1), "App returned before actual HTTP cancellation"
            assert "error" not in outcome
            assert outcome["result"]["status"] == "aborted"
            assert sid not in app._running
            messages = app.store.messages(sid)
            assert [m["content"] for m in messages if m["role"] == "user"] == [
                "Preserve this exact human request"
            ]
            assert messages[-1]["error"] == "aborted"
            assert "abort_event" not in server["body"]
            assert not any(t.name == "opencode-provider-request" for t in threading.enumerate())
        finally:
            app.abort(sid)
            thread.join(6)


def test_idle_parent_abort_reaches_grandchild_and_actual_background_owner(app):
    parent = app.create_session()["id"]
    child = _child(app, parent)
    grandchild = _child(app, child)
    unrelated = app.create_session()["id"]
    resumed = _child(app, unrelated)
    control = threading.Event()
    app._task_parents[child] = parent
    app._task_parents[grandchild] = child
    # A resumed task's current parent can differ from its original stored parent.
    app._background[resumed] = control
    app._task_parents[resumed] = parent
    app.abort(parent)
    assert all(app.abort_event(sid).is_set() for sid in (parent, child, grandchild, resumed))
    assert control.is_set()
    assert not app.abort_event(unrelated).is_set()


def test_old_stored_parent_cannot_cancel_a_task_owned_by_another_parent(app):
    original_parent = app.create_session()["id"]
    current_parent = app.create_session()["id"]
    child = _child(app, original_parent)
    app._task_parents[child] = current_parent
    app.abort(original_parent)
    assert not app.abort_event(child).is_set()
    app.abort(current_parent)
    assert app.abort_event(child).is_set()


def test_sync_child_cannot_clear_abort_after_parent_has_stopped(app, monkeypatch):
    parent = app.create_session()["id"]
    child = _child(app, parent)
    calls = []
    monkeypatch.setattr("opencode.app.run_loop", lambda *a, **k: calls.append(a))
    app.abort(parent)
    with pytest.raises(ProviderError, match="aborted"):
        app.run_prompt(child, "This must not start")
    assert calls == []
    assert app.abort_event(child).is_set()
    assert app.store.messages(child) == []


def test_reused_sync_task_uses_current_parent_for_abort(app):
    from opencode.tools.extra import _task

    original_parent = app.create_session()["id"]
    parent = app.create_session()["id"]
    child = _child(app, original_parent)
    entered = threading.Event()
    outcome = {}

    def complete(**kwargs):
        assert kwargs["abort_event"] is app.abort_event(child)
        entered.set()
        assert kwargs["abort_event"].wait(2), "Current parent abort never reached its reused child"
        raise ProviderError("aborted")

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                   complete=complete)
    app.permissions.auto = True
    ctx = SimpleNamespace(app=app, session_id=parent, agent=app.agents["build"],
                          directory=app.directory, depth=0)
    # The old parent may already be stopped; it no longer owns this invocation.
    app.abort(original_parent)

    def invoke():
        try:
            outcome["result"] = _task({"task_id": child, "prompt": "Continue this child",
                                       "description": "Continue inspection", "subagent_type": "general"}, ctx)
        except BaseException as exc:
            outcome["error"] = exc

    thread = threading.Thread(target=invoke)
    thread.start()
    try:
        assert entered.wait(2)
        app.abort(parent)
        thread.join(2)
        assert not thread.is_alive()
        assert isinstance(outcome.get("error"), ProviderError)
        assert str(outcome["error"]) == "Task cancelled"
        assert app.abort_event(child).is_set()
        assert child not in app._task_parents
    finally:
        app.abort(parent)
        thread.join(3)


def test_cancelled_scheduled_child_stays_cancelled_after_new_parent_turn(app, monkeypatch):
    parent = app.create_session()["id"]
    child = _child(app, parent)
    scheduled = []
    real_start = threading.Thread.start
    with monkeypatch.context() as scoped:
        scoped.setattr(threading.Thread, "start", lambda thread: scheduled.append(thread))
        app.spawn_background(child, "Old mission", "build", 1, parent)
    assert len(scheduled) == 1
    app.abort(parent)
    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                   complete=lambda **_: Completion(text="new human result", finish_reason='stop'))
    assert app.prompt(parent, "New human request")["status"] == "completed"
    assert not app.abort_event(parent).is_set()
    real_start(scheduled[0])
    scheduled[0].join(2)
    assert not scheduled[0].is_alive()
    assert app.store.messages(child) == []
    assert not app._background
    assert not app._task_parents
    assert not any("task_notification" in m.get("content", "") for m in app.store.messages(parent))


def test_recursive_abort_releases_permission_and_question_waiters(app):
    parent = app.create_session()["id"]
    child = _child(app, parent)
    grandchild = _child(app, child)
    app._task_parents[child] = parent
    app._task_parents[grandchild] = child
    errors = {}

    def permission():
        try:
            app.permissions.ask(session_id=child, permission="bash", patterns=["git status"], ruleset=[])
        except BaseException as exc:
            errors["permission"] = exc

    def question():
        try:
            app.ask_questions(grandchild, [{"question": "Continue?"}])
        except BaseException as exc:
            errors["question"] = exc

    threads = [threading.Thread(target=permission), threading.Thread(target=question)]
    for thread in threads:
        thread.start()
    try:
        _wait(lambda: app.permissions.list_pending() and app.pending_questions())
        app.abort(parent)
        for thread in threads:
            thread.join(1)
            assert not thread.is_alive()
        assert isinstance(errors["permission"], PermissionRejected)
        assert "cancelled" in str(errors["question"])
        assert app.permissions.list_pending() == []
        assert app.pending_questions() == []
    finally:
        app.abort(parent)
        for thread in threads:
            thread.join(2)


def test_snapshot_ack_does_not_consume_a_later_notification(app):
    sid = app.create_session()["id"]
    app.store.add_message(sid, "user", {"content": "Original human"})
    first = app.store.add_message(sid, "user", {"content": "first result", "synthetic": True})
    app._pending_notifications[sid] = {first["id"]}
    _, observed = app._context_snapshot(sid)
    second = app.store.add_message(sid, "user", {"content": "second result", "synthetic": True})
    app._pending_notifications[sid].add(second["id"])
    app._acknowledge_notifications(sid, observed)
    assert app._pending_notifications[sid] == {second["id"]}


def test_committed_summary_represents_older_pending_notifications(app):
    sid = app.create_session()["id"]
    app.store.add_message(sid, "user", {"content": "Original human"})
    note = app.store.add_message(sid, "user", {"content": "child result", "synthetic": True})
    boundary = app.store.add_message(sid, "assistant", {"content": "read result"})
    app._pending_notifications[sid] = {note["id"]}
    app.store.commit_compaction(sid, boundary["id"], "Retain the human objective and child result")
    history, observed = app._context_snapshot(sid)
    assert note["id"] not in {m["id"] for m in history}
    assert observed == {note["id"]}
    app._acknowledge_notifications(sid, observed)
    assert not app._has_pending_notifications(sid)


def test_notification_arriving_during_overflow_summary_survives_replay(app):
    sid = app.create_session()["id"]
    app.config["compaction"] = {"tail_turns": 0}
    app.store.add_message(sid, "user", {"content": "First human"})
    app.store.add_message(sid, "assistant", {"content": "First answer"})
    app.store.add_message(sid, "user", {"content": "Oversized final request"})
    app.store.add_message(sid, "assistant", {"content": "", "error": "413"})
    snapshot = app.store.context_messages(sid)
    late = {}

    def summary(**kwargs):
        assert "LATE CHILD RESULT" not in json.dumps(kwargs["messages"])
        late.update(app.store.add_message(sid, "user", {"content": "LATE CHILD RESULT", "synthetic": True}))
        app._pending_notifications[sid] = {late["id"]}
        return Completion(text="Accepted summary of the first turn", finish_reason='stop')

    app.provider = SimpleNamespace(complete=summary)
    compact(app, sid, snapshot, SimpleNamespace(id="local", context=128_000), "test", force=True, overflow=True)
    history, observed = app._context_snapshot(sid)
    assert any(m["id"] == late["id"] and m["content"] == "LATE CHILD RESULT" for m in history)
    assert any(m.get("content") == "Oversized final request" for m in history)
    assert late["id"] in observed
    app._acknowledge_notifications(sid, observed)
    assert not app._has_pending_notifications(sid)
    # The exclusion is durable and must not hide the notification on later reads.
    assert late["id"] in {m["id"] for m in app.store.context_messages(sid)}


def test_old_title_keeps_its_stop_after_new_human_turn(app, monkeypatch):
    sid = app.create_session()["id"]
    app.store.add_message(sid, "user", {"content": "Old human request"})
    scheduled = []
    real_start = threading.Thread.start
    old_abort = app.abort_event(sid)
    seen = []

    def complete(**kwargs):
        if kwargs["abort_event"] is old_abort:
            seen.append(kwargs["abort_event"].is_set())
            raise ProviderError("aborted")
        return Completion(text="fresh answer", finish_reason='stop')

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                   complete=complete)
    with monkeypatch.context() as scoped:
        scoped.setattr(threading.Thread, "start", lambda thread: scheduled.append(thread))
        _title(app, sid, "Old human request", SimpleNamespace(id="local"), "test")
    app.abort(sid)
    assert app.prompt(sid, "New human request")["status"] == "completed"
    assert old_abort.is_set(), "A new run erased an older consumer's cancellation"
    real_start(scheduled[0])
    scheduled[0].join(2)
    assert not scheduled[0].is_alive()
    assert seen == [True]
    assert not app.store.get_session(sid)["title"]


def test_direct_shell_has_one_owner_and_can_start_again_after_abort(app, monkeypatch):
    sid = app.create_session()["id"]
    entered = threading.Event()
    outcome = {}
    events = []
    joined = {}

    def queued_prompt():
        try:
            joined["result"] = app.prompt(sid, "overlapping human")
        except ProviderError as error:
            joined["error"] = error

    def bash(args, ctx):
        event = app.abort_event(ctx.session_id)
        events.append(event)
        if args["command"] == "first":
            entered.set()
            assert event.wait(2)
            return ToolResult(title="first", output="User aborted the command")
        assert not event.is_set()
        return ToolResult(title="second", output="second command result")

    monkeypatch.setattr("opencode.tools.shell._bash", bash)
    thread = threading.Thread(target=lambda: outcome.update(app.shell(sid, "first")))
    waiter = threading.Thread(target=queued_prompt)
    thread.start()
    try:
        assert entered.wait(2)
        with pytest.raises(RuntimeError, match="already running"):
            app.shell(sid, "overlapping")
        waiter.start()
        _wait(lambda: any(m.get("content") == "overlapping human" for m in app.store.messages(sid)))
        assert waiter.is_alive()
        app.abort(sid)
        thread.join(2)
        waiter.join(2)
        assert not thread.is_alive()
        assert not waiter.is_alive()
        assert "aborted" in str(joined["error"])
        assert "aborted" in outcome["output"]
        assert app.shell(sid, "second")["output"] == "second command result"
        assert events[0].is_set() and not events[1].is_set()
        assert sid not in app._running
    finally:
        app.abort(sid)
        thread.join(3)
        if waiter.ident is not None:
            waiter.join(3)


def test_background_notification_waits_for_direct_shell_to_release(app, monkeypatch):
    sid = app.create_session()["id"]
    child = _child(app, sid)
    entered, release = threading.Event(), threading.Event()
    outcome = {}
    inputs = []

    def bash(args, ctx):
        entered.set()
        assert release.wait(2)
        return ToolResult(title="command", output="shell output")

    def complete(**kwargs):
        inputs.append(kwargs["messages"])
        return Completion(text="processed child result", finish_reason='stop')

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                   complete=complete)
    monkeypatch.setattr("opencode.tools.shell._bash", bash)
    thread = threading.Thread(target=lambda: outcome.update(app.shell(sid, "command")))
    thread.start()
    try:
        assert entered.wait(2)
        app.spawn_background(child, "Child mission", "build", 1, sid)
        _wait(lambda: app._has_pending_notifications(sid))
        assert len(inputs) == 1, "Parent model started while its shell still owned the session"
        release.set()
        thread.join(2)
        assert not thread.is_alive()
        _wait(lambda: sid not in app._running)
        assert len(inputs) == 2
        assert "task_notification" in json.dumps(inputs[-1])
        assert not app._has_pending_notifications(sid)
        assert [m["content"] for m in app.store.messages(sid) if m["role"] == "user" and not m.get("synthetic")] == ["$ command"]
    finally:
        release.set()
        app.abort(sid)
        thread.join(3)
        _wait(lambda: sid not in app._running and child not in app._running)


def test_finishing_background_task_reserves_child_until_notification_commit(app, monkeypatch):
    parent = app.create_session()["id"]
    child = _child(app, parent)
    returned, release = threading.Event(), threading.Event()
    joined = {}
    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128_000), "test"),
                                   complete=lambda **_: Completion(text="result", finish_reason='stop'))
    app.prompt(parent, "Original human")
    real_prompt = app.prompt

    def prompt(sid, text, **kwargs):
        result = real_prompt(sid, text, **kwargs)
        if sid == child:
            returned.set()
            assert release.wait(2)
        return result

    monkeypatch.setattr(app, "prompt", prompt)
    app.spawn_background(child, "Child mission", "build", 1, parent)
    waiter = threading.Thread(target=lambda: joined.update(real_prompt(child, "Overlapping child mission")))
    try:
        assert returned.wait(2)
        assert child not in app._running and child in app._background
        waiter.start()
        _wait(lambda: any(m.get("content") == "Overlapping child mission" for m in app.store.messages(child)))
        assert waiter.is_alive()
        with pytest.raises(RuntimeError, match="already running"):
            app.shell(child, "Overlapping command")
    finally:
        release.set()
        def settled():
            with app._execution_lock:
                return child not in app._background and parent not in app._running
        _wait(settled)
        if waiter.ident is not None:
            waiter.join(3)
        assert not waiter.is_alive()
        assert joined["status"] == "completed"


@pytest.mark.parametrize("entry", ["prompt", "shell"])
def test_keyboard_interrupt_cancels_descendants_before_releasing_owner(app, monkeypatch, entry):
    sid = app.create_session()["id"]
    child = _child(app, sid)
    grandchild = _child(app, child)
    app._task_parents[child] = sid
    app._task_parents[grandchild] = child

    def interrupt(*args, **kwargs):
        raise KeyboardInterrupt

    monkeypatch.setattr("opencode.app.run_loop" if entry == "prompt" else "opencode.tools.shell._bash", interrupt)
    with pytest.raises(KeyboardInterrupt):
        getattr(app, entry)(sid, "Interrupted work")
    assert all(app.abort_event(s).is_set() for s in (sid, child, grandchild))
    assert sid not in app._running


def test_interrupt_before_http_worker_registration_still_prevents_transport(monkeypatch):
    from opencode import provider

    abort = threading.Event()
    called = []

    class InterruptedWait:
        def wait(self, timeout):
            raise KeyboardInterrupt

        def set(self):
            pass

    class DelayedWorker:
        def __init__(self, target, **kwargs):
            self.target = target

        def start(self):
            pass  # The interrupted caller has not let this worker start yet.

        def join(self):
            self.target()

    async def request():
        called.append(True)

    monkeypatch.setattr(provider, "threading", SimpleNamespace(Event=InterruptedWait, Lock=threading.Lock, Thread=DelayedWorker))
    with pytest.raises(KeyboardInterrupt):
        provider._run_cancellable(request, abort)
    assert abort.is_set()
    assert called == []
