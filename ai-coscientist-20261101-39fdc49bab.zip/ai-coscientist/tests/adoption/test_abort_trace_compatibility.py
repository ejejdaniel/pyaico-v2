"""Offline recorder boundaries; protocol fixtures never become research inputs."""

import asyncio
from contextlib import ExitStack
import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
from types import SimpleNamespace
from unittest.mock import patch

import httpx
import pytest

from opencode.provider import Client, Completion, ProviderError


def fixture_config():
    return {"model": "local/fixture", "provider": {"local": {
        "options": {"baseURL": "http://model.invalid/v1", "apiKey": "fixture"},
        "models": {"fixture": {"limit": {"context": 131072, "output": 12000},
                               "interleaved": {"field": "reasoning"},
                               "options": {"reasoningEffort": "medium"}}},
    }}}


def boundary_app(abort_event):
    history = []

    class FixtureStore:
        def __init__(self, *args, **kwargs):
            pass

        def close(self):
            pass

        def list_sessions(self):
            return []

        def messages(self, session_id):
            return list(history)

    class FixtureApp:
        def __init__(self, directory=None, *, store=None, config=None, **kwargs):
            self.store = store or FixtureStore()
            self.auth = SimpleNamespace(get=lambda _: None)
            self.config = config or fixture_config()
            self.provider = Client(self.auth, self.config)
            self.default_agent = "build"
            self.agents = {"build": SimpleNamespace(steps=100)}
            self.permissions = SimpleNamespace(ask=lambda **kwargs: None)

        def create_session(self, **kwargs):
            return {"id": "fixture-session"}

        def prompt(self, session_id, text, on_text=None, **kwargs):
            provider, model = self.provider.resolve(None)
            result = self.provider.complete(
                provider=provider, model=model, system="Protocol fixture only.",
                messages=[*history, {"role": "user", "content": text}],
                tools=[], on_text=on_text, abort_event=abort_event,
            )
            history.extend([{"role": "user", "content": text}, {
                "role": "assistant", "content": result.text,
                "reasoning_content": result.reasoning_content,
            }])
            return {"status": "completed", "sessionID": session_id, "text": result.text}

    return FixtureApp, FixtureStore


def script_context(monkeypatch, tmp_path, module, abort_event):
    """Keep runner setup inside the fixture directory and replace unrelated App work."""
    project = tmp_path / "fixture-project"
    (project / "scripts").mkdir(parents=True)
    (project / "src").mkdir()
    script = project / "scripts" / Path(module.__file__).name
    script.write_bytes(Path(module.__file__).read_bytes())
    (project / "config").mkdir()
    (project / "config/llm.opencode.json").write_bytes(
        (Path(module.__file__).resolve().parents[1] / "config/llm.opencode.json").read_bytes())
    monkeypatch.setattr(module, "__file__", str(script))
    app, store = boundary_app(abort_event)
    monkeypatch.setattr("opencode.app.App", app)
    monkeypatch.setattr("opencode.store.Store", store)
    if hasattr(module, "subprocess"):
        monkeypatch.setattr(module.subprocess, "run", lambda *args, **kwargs: None)
    stack = ExitStack()
    stack.enter_context(patch.dict(os.environ))
    stack.enter_context(patch.object(tempfile, "tempdir", str(tmp_path)))
    stack.enter_context(patch.object(sys, "path", list(sys.path)))
    stack.enter_context(patch.object(sys, "dont_write_bytecode", True))
    return stack, app, store


def recorded_client(tmp_path):
    """The client a recorded run (scripts/recording.py) gives the app, saving into tmp_path/recorded."""
    from scripts.recording import recording_client

    output = tmp_path / "recorded"
    output.mkdir()
    return recording_client(output)(SimpleNamespace(get=lambda _: None), fixture_config()), output


@pytest.mark.parametrize("concurrent", [False, True])
def test_recorded_client_forwards_event_without_serializing_it(monkeypatch, tmp_path, concurrent):
    event = threading.Event()
    client, output = recorded_client(tmp_path)
    seen = []
    slow, cancelled = threading.Event(), threading.Event()
    first_entered, second_entered, release = threading.Event(), threading.Event(), threading.Event()

    def complete(self, *args, on_update=None, on_tool_call=None, abort_event=None):
        seen.append(abort_event)
        if concurrent:
            if abort_event is slow:
                first_entered.set()
                assert release.wait(3)
            else:
                second_entered.set()
                assert abort_event.wait(3)
                raise ProviderError("Model request aborted")
        return Completion(text="Protocol fixture answer.", finish_reason="stop")

    monkeypatch.setattr(Client, "_openai", complete)
    provider, model = client.resolve(None)
    if concurrent:
        errors = []

        def invoke(signal):
            try:
                client.complete(provider=provider, model=model, system="Protocol fixture only.", messages=[],
                                tools=[], abort_event=signal)
            except Exception as error:
                errors.append(error)

        first = threading.Thread(target=invoke, args=(slow,))
        second = threading.Thread(target=invoke, args=(cancelled,))
        first.start()
        try:
            assert first_entered.wait(1)
            second.start()
            assert second_entered.wait(1)
            cancelled.set()
            second.join(1)
            assert not second.is_alive() and first.is_alive()
        finally:
            cancelled.set()
            release.set()
            first.join(2)
            if second.ident is not None:
                second.join(2)
        assert not first.is_alive() and not second.is_alive()
        assert len(errors) == 1 and isinstance(errors[0], ProviderError)
        assert seen == [slow, cancelled]
    else:
        for _ in range(2):
            client.complete(provider=provider, model=model, system="Protocol fixture only.", messages=[], tools=[],
                            abort_event=event)
        assert seen == [event, event]
    requests = sorted(output.glob("request-*.json"))
    assert len(requests) == len(seen)
    for path in requests:
        assert set(json.loads(path.read_text(encoding="utf-8"))) == {
            "provider", "model", "system", "messages", "tools", "temperature",
        }


def test_recorded_client_passes_further_request_options_through(monkeypatch, tmp_path):
    # Review and mind-map sub-calls send response_format; the recorder must not reject it.
    client, output = recorded_client(tmp_path)
    response_format = {"type": "json_schema", "json_schema": {"name": "fixture", "strict": True,
                                                              "schema": {"type": "object"}}}
    received = []

    def complete(self, *args, on_update=None, on_tool_call=None, abort_event=None, **options):
        received.append(options)
        return Completion(text="{}", finish_reason="stop")

    monkeypatch.setattr(Client, "_openai", complete)
    provider, model = client.resolve(None)
    client._openai(provider, "fixture", model, "Protocol fixture only.", [], [], 0, None,
                   response_format=response_format)
    assert received == [{"response_format": response_format}]
    saved = json.loads(sorted(output.glob("request-*.json"))[0].read_text(encoding="utf-8"))
    assert saved["response_format"] == response_format
    assert json.loads((output / "response-001.json").read_text(encoding="utf-8"))["text"] == "{}"


def offline_transport(monkeypatch, respond):
    sync_init, async_init = httpx.Client.__init__, httpx.AsyncClient.__init__
    transport = httpx.MockTransport(respond)

    def init_sync(self, *args, **kwargs):
        sync_init(self, *args, **{**kwargs, "transport": transport})

    def init_async(self, *args, **kwargs):
        async_init(self, *args, **{**kwargs, "transport": transport})

    monkeypatch.setattr(httpx.Client, "__init__", init_sync)
    monkeypatch.setattr(httpx.AsyncClient, "__init__", init_async)


def prepare_wire_script(monkeypatch, tmp_path, script_name, event):
    module = importlib.import_module("scripts." + script_name)
    stack, app, store = script_context(monkeypatch, tmp_path, module, event)
    output = tmp_path / "wire"
    arguments = ["--output", str(output), "--base-url", "http://model.invalid/v1"]
    if script_name == "check_reasoning_roundtrip":
        arguments.extend(["--model", "fixture"])
    else:
        monkeypatch.setattr(module, "App", app)
        monkeypatch.setattr(module, "ResumeStore", store)
        monkeypatch.setattr(module, "restore", lambda *args: "fixture-session")
        original_client = module.ContinuationClient

        def already_restored(*args, **kwargs):
            client = original_client(*args, **kwargs)
            client.injected = True
            return client

        monkeypatch.setattr(module, "ContinuationClient", already_restored)
        case = tmp_path / "case"
        arm = case / "arm"
        arm.mkdir(parents=True)
        source = tmp_path / "source"
        source.mkdir()
        archive = case / "archive.json"
        archive.write_text(json.dumps([{"role": "assistant"}] * 14), encoding="utf-8")
        questions = ["Fixture Q1", "Fixture Q2"]
        frozen = {"model": "fixture", "max_tokens": 12000, "reasoning_effort": "medium",
                  "messages": [{}, {}, {"content": questions[0]}]}
        for path, value in ((case / "settings.json", {"source": str(source), "config": fixture_config()}),
                            (case / "source-manifest.json", {}), (case / "questions.json", questions),
                            (arm / "removed.request.json", frozen), (arm / "removed.response.bin", {})):
            path.write_text(json.dumps(value), encoding="utf-8")
        arguments.extend(["--case", str(case), "--archive", str(archive), "--arm", str(arm)])
    monkeypatch.setattr(sys, "argv", [script_name, *arguments])
    return module, output, stack


@pytest.mark.parametrize("script_name", ["continue_reasoning_replay", "check_reasoning_roundtrip"])
@pytest.mark.parametrize("cancellable", [False, True])
def test_wire_recorders_cover_sync_and_cancellable_async_requests(monkeypatch, tmp_path, script_name, cancellable):
    module, output, stack = prepare_wire_script(
        monkeypatch, tmp_path, script_name, threading.Event() if cancellable else None,
    )
    sent = []

    def respond(request):
        body = json.loads(request.content)
        sent.append(body)
        if body.get("stream"):
            event = {"choices": [{"delta": {"content": "2026-11-05", "reasoning": "Fixture reasoning."},
                                  "finish_reason": "stop"}]}
            return httpx.Response(200, text="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n")
        return httpx.Response(200, json={"choices": [{"message": {
            "content": "2026-11-05 Delta-42", "reasoning": "Fixture reasoning."},
            "finish_reason": "stop"}], "usage": {"total_tokens": 12}})

    offline_transport(monkeypatch, respond)
    with stack:
        result = module.main()
    assert len(sent) == 2
    if script_name == "check_reasoning_roundtrip":
        assert result == 0
        summary = json.loads((output / "result.json").read_text(encoding="utf-8"))
        assert summary["requests"] == 2 and all(summary["checks"].values())
        assert (output / "wire-response-01.sse").read_text(encoding="utf-8").startswith("data: ")
        assert (output / "wire-response-02.json").is_file()
        pattern = "wire-request-*.json"
    else:
        calls = json.loads((output / "calls.json").read_text(encoding="utf-8"))
        assert len(calls) == 2 and all(item["finished"] for item in calls)
        assert all(set(item) == {"index", "started", "finished", "seconds", "http_status", "usage", "finish_reason"}
                   for item in calls)
        assert (output / "response-001.json").is_file() and (output / "response-002.json").is_file()
        pattern = "request-*.json"
    assert [json.loads(path.read_text(encoding="utf-8")) for path in sorted(output.glob(pattern))] == sent
    assert all("abort_event" not in body for body in sent)


@pytest.mark.parametrize("script_name", ["continue_reasoning_replay", "check_reasoning_roundtrip"])
def test_async_trace_preserves_partial_record_and_joins_transport_cleanup(monkeypatch, tmp_path, script_name):
    abort = threading.Event()
    closed = threading.Event()
    finalized = threading.Event()
    module, output, stack = prepare_wire_script(monkeypatch, tmp_path, script_name, abort)

    class InterruptedStream(httpx.AsyncByteStream):
        async def __aiter__(self):
            try:
                yield b'data: {"choices":[{"delta":{"content":"partial"}}]}\n\n'
                abort.set()
                await asyncio.Future()
            finally:
                finalized.set()

        async def aclose(self):
            closed.set()

    async def respond(request):
        return httpx.Response(200, stream=InterruptedStream())

    offline_transport(monkeypatch, respond)
    with stack:
        if script_name == "continue_reasoning_replay":
            with pytest.raises(ProviderError, match="aborted"):
                module.main()
        else:
            assert module.main() == 1
    assert closed.is_set() and finalized.is_set()
    assert not any(thread.name == "opencode-provider-request" for thread in threading.enumerate())
    if script_name == "continue_reasoning_replay":
        calls = json.loads((output / "calls.json").read_text(encoding="utf-8"))
        assert len(calls) == 1 and not calls[0]["finished"]
        assert (output / "request-001.json").is_file()
        assert not (output / "response-001.json").exists()
    else:
        assert (output / "wire-request-01.json").is_file()
        assert "partial" in (output / "wire-response-01.sse").read_text(encoding="utf-8")


def test_cancelled_restoration_does_not_inject_or_write_records(tmp_path):
    from scripts.continue_reasoning_replay import ContinuationClient

    abort = threading.Event()
    abort.set()
    client = ContinuationClient(SimpleNamespace(get=lambda _: None), fixture_config(), frozen={}, response={},
                                old_case=tmp_path, output=tmp_path, execute=True)
    with pytest.raises(ProviderError, match="aborted"):
        client.complete(system="Fixture", messages=[], tools=[], abort_event=abort)
    assert not client.injected
    assert list(tmp_path.iterdir()) == []
