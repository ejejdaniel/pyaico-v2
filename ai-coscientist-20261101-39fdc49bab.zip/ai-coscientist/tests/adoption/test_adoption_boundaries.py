"""Offline adoption regression tests for the supplied baseline defects.

Run with py_opencode/src on PYTHONPATH. No real model or public service is used.
"""

import json
import os
import tempfile
import threading
import unittest
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import httpx

from opencode.app import App
from opencode.loop import ToolContext, _maybe_compact
from opencode.provider import Client, Completion, ProviderError, ToolCall
from opencode.store import Store
from opencode.tools.files import _edit, _read
from opencode.tools.extra import _apply_patch
from opencode.tools.web import _websearch


@contextmanager
def mock_provider_transport():
    """Keep wire assertions identical for synchronous and abort-capable calls."""
    with patch("opencode.provider.httpx.Client") as transport:
        class AsyncTransport:
            def __init__(self, **kwargs):
                self.context = transport(**kwargs)

            async def __aenter__(self):
                self.client = self.context.__enter__()
                return self

            async def __aexit__(self, *args):
                self.context.__exit__(*args)

            async def post(self, *args, **kwargs):
                return self.client.post(*args, **kwargs)

            @asynccontextmanager
            async def stream(self, *args, **kwargs):
                with self.client.stream(*args, **kwargs) as response:
                    class AsyncResponse:
                        status_code = response.status_code

                        async def aread(self):
                            return response.read()

                        async def aiter_lines(self):
                            for line in response.iter_lines():
                                yield line

                    yield AsyncResponse()

        with patch("opencode.provider.httpx.AsyncClient", AsyncTransport):
            yield transport


class ScriptedProvider:
    def __init__(self, responses=(), context=100000):
        self.responses = list(responses)
        self.calls = []
        self.info = SimpleNamespace(id="fake", context=context)

    def resolve(self, model=None):
        return self.info, "test"

    def complete(self, **kwargs):
        self.calls.append(kwargs)
        if not self.responses:
            raise AssertionError("Unexpected model call")
        response = self.responses.pop(0)
        return response(kwargs) if callable(response) else response


@contextmanager
def mock_stream_responses(responses):
    """Replay protocol fixtures through the product streaming parser."""
    remaining = iter(responses)
    sent = []

    def stream(url, headers, body, timeout, consume, abort_event):
        sent.append(json.loads(json.dumps(body)))
        response = next(remaining).json()
        for choice in response["choices"]:
            message = dict(choice.get("message") or {})
            if message.get("tool_calls"):
                message["tool_calls"] = [dict(call, index=index) for index, call in enumerate(message["tool_calls"])]
            consume("data: " + json.dumps({"choices": [{"delta": message, "finish_reason": choice.get("finish_reason")}]}))
        if response.get("usage"):
            consume("data: " + json.dumps({"choices": [], "usage": response["usage"]}))

    with patch("opencode.provider._stream", side_effect=stream):
        yield sent


class Boundaries(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"),
            "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_DATA_HOME": str(self.root / "data"),
            "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        self.env.start()
        self.addCleanup(self.env.stop)
        self.project = self.root / "project"
        self.project.mkdir()
        (self.project / ".git").mkdir()
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.app = App(self.project, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.session = self.app.create_session()
        self.sid = self.session["id"]

    def ctx(self):
        return ToolContext(self.app, self.sid, self.app.agents["build"], "m", "c", 0,
                           self.project, self.project, set(), 1)

    def test_tool_history_unifies_sources_survives_compaction_and_rebuilds_from_store(self):
        calls = [
            {"id": "paper", "name": "paper_search", "arguments": {"query": "specific question", "provider": "crossref"}},
            {"id": "web", "name": "websearch", "arguments": {"query": "alternate source"}},
        ]
        self.store.add_message(self.sid, "assistant", {
            "content": "working explanation", "reasoning_content": "PRIVATE_REASONS", "tool_calls": calls,
        })
        paper = self.store.add_message(self.sid, "tool", {
            "name": "paper_search", "tool_call_id": "paper", "content": "provider metadata at exact/path.json",
        })
        web = self.store.add_message(self.sid, "tool", {
            "name": "websearch", "tool_call_id": "web", "content": "Saved snippet https://example.org/paper",
        })
        index = self.store.export_tool_history(self.sid)
        original = self.store.messages(self.sid)
        self.store.commit_compaction(self.sid, web["id"], "Short summary omitting source details")
        self.assertNotIn(web, self.store.context_messages(self.sid))
        self.assertTrue(index.is_relative_to(self.project))
        self.assertIn("paper_search: 1", index.read_text(encoding="utf-8"))
        self.assertIn("websearch: 1", index.read_text(encoding="utf-8"))
        groups = [p.read_text(encoding="utf-8") for p in (index.parent / "by-tool").glob("*.md")]
        self.assertEqual(len(groups), 2)
        self.assertTrue(any(paper["id"] in group and web["id"] not in group for group in groups))
        self.assertTrue(any(web["id"] in group and paper["id"] not in group for group in groups))
        receipt = index.parent / (web["id"] + ".json")
        captured = json.loads(receipt.read_text(encoding="utf-8"))
        self.assertEqual(captured[0]["tool_calls"], [calls[1]])
        self.assertEqual(captured[1], web)
        self.assertNotIn("PRIVATE_REASONS", "".join(p.read_text(encoding="utf-8")
                         for p in index.parent.rglob("*") if p.is_file()))
        index.write_text("edited projection", encoding="utf-8")
        receipt.write_text("not authoritative", encoding="utf-8")
        reopened = Store(self.store.path)
        try:
            reopened.export_tool_history(self.sid)
            self.assertEqual(json.loads(receipt.read_text(encoding="utf-8")), captured)
            self.assertNotIn("edited projection", index.read_text(encoding="utf-8"))
            self.assertEqual(reopened.messages(self.sid)[:len(original)], original)
        finally:
            reopened.close()

    def test_tool_history_is_session_scoped_and_still_needs_read_permission(self):
        other = self.app.create_session()["id"]
        self.store.add_message(other, "tool", {"name": "websearch", "content": "OTHER_SESSION_SECRET"})
        index = self.store.export_tool_history(self.sid)
        self.assertNotIn("OTHER_SESSION_SECRET", index.read_text(encoding="utf-8"))
        with patch.object(self.app.permissions, "ask", side_effect=PermissionError("read denied")):
            with self.assertRaisesRegex(PermissionError, "read denied"):
                _read({"filePath": str(index)}, self.ctx())

    def test_local_receipt_view_does_not_replace_legacy_export_and_append_is_idempotent(self):
        legacy = self.store.path.parent / "history" / self.sid / "tools" / "index.md"
        legacy.parent.mkdir(parents=True)
        legacy.write_text("old export retained", encoding="utf-8")
        first = self.store.add_message(self.sid, "tool", {"name": "websearch", "content": "old saved result"})
        call = self.store.add_message(self.sid, "assistant", {"tool_calls": [
            {"id": "next", "name": "paper_search", "arguments": {"query": "next query"}}]})
        second = self.store.add_message(self.sid, "tool", {
            "tool_call_id": "next", "name": "paper_search", "content": "next result"})
        index = self.store.export_tool_history(self.sid, [call, second])
        self.store.export_tool_history(self.sid, [call, second])
        self.assertEqual(legacy.read_text(encoding="utf-8"), "old export retained")
        self.assertIn("websearch: 1", index.read_text(encoding="utf-8"))
        self.assertIn("paper_search: 1", index.read_text(encoding="utf-8"))
        self.assertTrue((index.parent / (first["id"] + ".json")).is_file())
        groups = "".join(p.read_text(encoding="utf-8") for p in (index.parent / "by-tool").glob("*.md"))
        self.assertEqual(groups.count("call next |"), 1)

    def test_native_loop_exports_actual_saved_results_before_next_model_call(self):
        source = self.project / "input.txt"
        source.write_text("actual observation", encoding="utf-8")
        def inspect(kwargs):
            index = self.store.tool_history_path(self.sid)
            self.assertNotIn(str(index), kwargs["system"])
            receipts = list(index.parent.glob("msg_*.json"))
            self.assertEqual(len(receipts), 1)
            self.assertIn("actual observation", receipts[0].read_text(encoding="utf-8"))
            return Completion(text="Done", finish_reason='stop')
        self.app.provider = ScriptedProvider([
            Completion(tool_calls=[ToolCall("read1", "read", {"filePath": str(source)})], finish_reason='tool-calls'), inspect,
        ])
        self.assertEqual(self.app.prompt(self.sid, "Read the file")["status"], "completed")
        index = self.store.tool_history_path(self.sid)
        before = index.read_text(encoding="utf-8")
        self.store.export_tool_history(self.sid)
        self.assertEqual(index.read_text(encoding="utf-8"), before)

    def test_large_tool_receipt_is_exact_and_read_uses_source_line_limit(self):
        content = "x" * 100000 + "END_OF_RECEIPT"
        saved = self.store.add_message(self.sid, "tool", {"name": "websearch", "content": content})
        index = self.store.export_tool_history(self.sid)
        receipt = index.parent / (saved["id"] + ".json")
        self.assertEqual(json.loads(receipt.read_text(encoding="utf-8")), [saved])
        result = _read({"filePath": str(receipt)}, self.ctx())
        self.assertIn("line truncated to 2000 chars", result.output)
        self.assertNotIn("nextCharOffset", result.metadata)

    def test_tool_history_includes_abort_before_execution(self):
        target = self.project / "not_written.txt"
        def abort(kwargs):
            self.app.abort_event(self.sid).set()
            return Completion(tool_calls=[ToolCall("never-run", "write", {
                "filePath": str(target), "content": "not executed",
            })], finish_reason='tool-calls')
        self.app.provider = ScriptedProvider([abort])
        self.assertEqual(self.app.prompt(self.sid, "Test abort")["status"], "aborted")
        index = self.store.tool_history_path(self.sid)
        receipts = list(index.parent.glob("msg_*.json"))
        self.assertEqual(len(receipts), 1)
        self.assertIn("Tool execution aborted", receipts[0].read_text(encoding="utf-8"))
        self.assertFalse(target.exists())

    def test_tool_history_includes_rejected_repeat_before_next_model_call(self):
        source = self.project / "source.txt"
        source.write_text("evidence", encoding="utf-8")
        replies = [Completion(tool_calls=[ToolCall(f"call-{i}", "read", {"filePath": str(source)}) for i in range(3)], finish_reason="tool-calls")]
        def inspect(kwargs):
            receipts = list(self.store.tool_history_path(self.sid).parent.glob("msg_*.json"))
            self.assertEqual(len(receipts), 3)
            self.assertTrue(any("repeat denied" in p.read_text(encoding="utf-8") for p in receipts))
            return Completion(text="No more repetitions", finish_reason='stop')
        self.app.provider = ScriptedProvider([*replies, inspect])
        ask = self.app.permissions.ask
        def reject_repeat(**kwargs):
            if kwargs["permission"] == "doom_loop":
                raise PermissionError("repeat denied")
            return ask(**kwargs)
        with patch.object(self.app.permissions, "ask", side_effect=reject_repeat):
            self.assertEqual(self.app.prompt(self.sid, "Test receipt visibility")["status"], "completed")

    def compactable_history(self):
        original = self.store.add_message(self.sid, "user", {"content": "original-request " * 800})
        self.store.add_message(self.sid, "assistant", {"content": "", "tool_calls": [
            {"id": "old-call", "name": "read", "arguments": {"filePath": "exact-evidence-location.json"}}
        ]})
        self.store.add_message(self.sid, "tool", {"content": "evidence " * 2000, "tool_call_id": "old-call", "name": "read"})
        self.store.add_message(self.sid, "user", {"content": "second question"})
        self.store.add_message(self.sid, "assistant", {"content": "second answer"})
        self.store.add_message(self.sid, "user", {"content": "third question"})
        return original

    def test_error_returns_to_loop_and_alternative_tool_can_answer(self):
        source = self.project / "evidence.txt"
        source.write_text("evidence-on-disk", encoding="utf-8")
        provider = ScriptedProvider([
            Completion(text="Locate the evidence.", tool_calls=[ToolCall("a", "read", {"filePath": str(self.project / "missing.txt")})], finish_reason='tool-calls'),
            Completion(text="The guessed path failed; list matching files.", tool_calls=[ToolCall("b", "glob", {"pattern": "*.txt"})], finish_reason='tool-calls'),
            Completion(tool_calls=[ToolCall("c", "read", {"filePath": str(source)})], finish_reason='tool-calls'),
            Completion(text="Answer with evidence.", finish_reason='stop'),
        ])
        self.app.provider = provider
        result = self.app.prompt(self.sid, "Inspect the file")
        self.assertEqual(result["text"], "Answer with evidence.")
        self.assertIn("does not exist", json.dumps(provider.calls[1]["messages"]))
        self.assertIn("guessed path failed", json.dumps(provider.calls[-1]["messages"]))
        self.assertIn("evidence-on-disk", json.dumps(provider.calls[-1]["messages"]))

    def test_restart_restores_notes_and_tool_results(self):
        self.store.add_message(self.sid, "user", {"content": "first request"})
        self.store.add_message(self.sid, "assistant", {"content": "working explanation", "tool_calls": [
            {"id": "c", "name": "read", "arguments": {"filePath": "sample.txt"}}
        ]})
        self.store.add_message(self.sid, "tool", {"name": "read", "tool_call_id": "c", "content": "exact evidence"})
        self.store.add_message(self.sid, "assistant", {"content": "first answer"})
        second_store = Store(self.store.path)
        try:
            restarted = App(self.project, store=second_store, auto_approve=True, config={})
            restarted.generate_titles = False
            restarted.provider = ScriptedProvider([Completion(text="follow-up answer", finish_reason='stop')])
            restarted.prompt(self.sid, "continue the investigation")
            sent = json.dumps(restarted.provider.calls[0]["messages"])
            self.assertIn("working explanation", sent)
            self.assertIn("exact evidence", sent)
        finally:
            second_store.close()

    def test_local_skill_and_tool_extension_use_the_same_loop(self):
        skill = self.project / ".opencode" / "skills" / "test-domain" / "SKILL.md"
        skill.parent.mkdir(parents=True)
        skill.write_text("---\nname: test-domain\ndescription: Test-only guidance\n---\nUse evidence; do not invent results.\n", encoding="utf-8")
        tool = self.project / ".opencode" / "tools" / "domain.py"
        tool.parent.mkdir(parents=True)
        tool.write_text("from opencode.tools.types import Tool, ToolResult\nTOOLS = [Tool('domain_echo', 'Test extension', {'type': 'object', 'properties': {}}, lambda args, ctx: ToolResult(output='extension-evidence'))]\n", encoding="utf-8")
        app = App(self.project, store=self.store, auto_approve=True, config={})
        app.generate_titles = False
        app.provider = ScriptedProvider([
            Completion(tool_calls=[ToolCall("s", "skill", {"name": "test-domain"})], finish_reason='tool-calls'),
            Completion(tool_calls=[ToolCall("t", "domain_echo", {})], finish_reason='tool-calls'),
            Completion(text="extension answer", finish_reason='stop'),
        ])
        self.assertEqual(app.prompt(self.sid, "Use the test extension")["text"], "extension answer")
        self.assertIn("do not invent", json.dumps(app.provider.calls[-1]["messages"]))
        self.assertIn("extension-evidence", json.dumps(app.provider.calls[-1]["messages"]))

    def test_single_long_human_turn_can_compact(self):
        self.store.add_message(self.sid, "user", {"content": "Investigate"})
        self.store.add_message(self.sid, "tool", {"content": "large-result " * 2000})
        self.app.provider = ScriptedProvider([Completion(text="summary", finish_reason='stop')], context=4096)
        _maybe_compact(self.app, self.sid, self.store.messages(self.sid), self.app.provider.info, "test", force=True)
        self.assertEqual(len(self.app.provider.calls), 1)

    def test_compaction_keeps_original_history_retrievable(self):
        original = self.compactable_history()
        self.app.provider = ScriptedProvider([Completion(text="summary", finish_reason='stop')], context=8192)
        _maybe_compact(self.app, self.sid, self.store.messages(self.sid), self.app.provider.info, "test", force=True)
        row = self.store._conn.execute("SELECT data FROM message WHERE id=?", (original["id"],)).fetchone()
        self.assertIsNotNone(row, "Compaction physically deletes original messages")
        self.assertTrue(self.store.context_messages(self.sid)[0].get("compaction_through"))

    def test_empty_completed_summary_retains_originals_and_commits_like_source(self):
        original = self.compactable_history()
        self.app.provider = ScriptedProvider([Completion(text="", finish_reason="stop")], context=8192)
        _maybe_compact(self.app, self.sid, self.store.messages(self.sid), self.app.provider.info, "test", force=True)
        self.assertIn(original["id"], [m["id"] for m in self.store.messages(self.sid)])
        self.assertTrue(any(m.get("compaction_through") for m in self.store.context_messages(self.sid)))

    def test_compactor_receives_tool_arguments(self):
        self.compactable_history()
        self.app.provider = ScriptedProvider([Completion(text="summary", finish_reason='stop')], context=8192)
        _maybe_compact(self.app, self.sid, self.store.messages(self.sid), self.app.provider.info, "test", force=True)
        self.assertIn("exact-evidence-location.json", json.dumps([c["messages"] for c in self.app.provider.calls]))

    def test_legacy_summary_projects_as_assistant_without_rewriting_history(self):
        from opencode.provider import openai_messages_from_history
        self.store.add_message(self.sid, "user", {"content": "Check actual sources, not the report"})
        tool = self.store.add_message(self.sid, "tool", {"name": "read", "content": "observed data"})
        legacy = self.store.add_message(self.sid, "user", {
            "content": "<previous-summary>Old incorrect judgment</previous-summary>",
            "synthetic": True, "compaction_through": tool["id"], "finish_reason": "stop",
        })
        before = self.store.messages(self.sid)
        self.assertEqual([m["role"] for m in self.store.context_messages(self.sid)], ["assistant"])
        self.assertEqual([m["role"] for m in openai_messages_from_history([legacy])], ["user", "assistant"])
        self.assertEqual(openai_messages_from_history([legacy])[0]["content"], "What did we do so far?")
        self.assertEqual(self.store.messages(self.sid), before)

    def test_recompaction_preserves_checkpoint_and_uncovered_suffix_after_restart(self):
        human = self.store.add_message(self.sid, "user", {"content": "Keep the original requested quantity and verify sources"})
        last = self.store.add_message(self.sid, "assistant", {"content": "Old judgment " * 1000})
        self.store.commit_compaction(self.sid, last["id"], "Old summary " * 1000)
        tail = self.store.add_message(self.sid, "assistant", {"content": "latest work stays"})
        self.app.provider = ScriptedProvider([Completion(text="Working account", finish_reason='stop')], context=32000)
        with patch("opencode.compaction.retained_split", return_value=0):
            _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        checkpoint = self.store.context_messages(self.sid)[0]
        self.assertEqual(checkpoint["compaction_through"], last["id"])
        self.assertEqual(checkpoint["role"], "assistant")
        restarted = Store(self.store.path)
        try:
            context = restarted.context_messages(self.sid)
            self.assertEqual(context[1], tail)
            self.assertTrue(context[-1]["synthetic"])
            self.assertEqual(context[-1]["role"], "user")
            self.assertNotIn(human["id"], [m["id"] for m in context])
            self.assertIn(human, restarted.messages(self.sid))
        finally:
            restarted.close()

    def test_retention_keeps_complete_exchange_suffix_of_an_oversized_earlier_turn(self):
        from opencode.compaction import exchanges, retained_split
        history = [
            {"role": "user", "content": "previous question"},
            {"role": "tool", "content": "original sources " * 2000},
            {"role": "assistant", "content": "I verified everything"},
            {"role": "user", "content": "Please recheck the sources"},
            {"role": "assistant", "tool_calls": [{"id": "r", "name": "read", "arguments": {}}]},
            {"role": "tool", "tool_call_id": "r", "content": "latest result"},
        ]
        groups = exchanges(history)
        kept = [m for group in groups[retained_split(groups, 1000):] for m in group]
        self.assertEqual(kept, history[2:])

    def test_compactor_receives_native_roles_and_reasoning_without_mutating_history(self):
        self.store.add_message(self.sid, "user", {"content": "first request"})
        self.store.add_message(self.sid, "assistant", {"content": "tentative explanation", "reasoning_content": "hidden",
            "tool_calls": [{"id": "s", "name": "websearch", "arguments": {"query": "actual question"}}]})
        self.store.add_message(self.sid, "tool", {"name": "websearch", "tool_call_id": "s", "content": "actual result " * 1500})
        self.store.add_message(self.sid, "user", {"content": "current question"})
        self.app.provider = ScriptedProvider([Completion(text="Working account of first question", finish_reason='stop')], context=32000)
        before = self.store.messages(self.sid)
        with patch("opencode.compaction.retained_split", return_value=2):
            _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        request = self.app.provider.calls[0]["messages"]
        self.assertEqual([m["role"] for m in request], ["user", "assistant", "tool", "user"])
        self.assertEqual(request[1]["tool_calls"][0]["function"]["name"], "websearch")
        self.assertIn("actual question", request[1]["tool_calls"][0]["function"]["arguments"])
        self.assertEqual(request[1]["reasoning_content"], "hidden")
        self.assertEqual(self.store.context_messages(self.sid)[-2]["content"], "current question")
        self.assertEqual(self.store.messages(self.sid)[:len(before)], before)

    def test_compactor_preserves_empty_assistant_bodies_and_tool_protocol(self):
        from opencode.compaction import _summary_messages
        for body in (None, "", " \n\t"):
            with self.subTest(body=body):
                history = [
                    {"role": "user", "content": "Investigate without running the old work."},
                    {"id": "a", "role": "assistant", "content": body, "reasoning_content": "PRIVATE",
                     "tool_calls": [{"id": "r", "name": "read", "arguments": {"filePath": "source.json"}}]},
                    {"role": "tool", "tool_call_id": "r", "content": "Exact source result."},
                ]
                original = json.dumps(history)
                sent = _summary_messages(history, "archive.json")
                self.assertEqual([m["role"] for m in sent], ["user", "assistant", "tool", "user"])
                self.assertEqual(sent[0]["content"], history[0]["content"])
                self.assertEqual(sent[1]["content"], body or "")
                self.assertEqual(sent[1]["tool_calls"][0]["id"], "r")
                self.assertEqual(json.loads(sent[1]["tool_calls"][0]["function"]["arguments"]),
                                 {"filePath": "source.json"})
                self.assertEqual(sent[2]["content"], history[2]["content"])
                self.assertIn("## Objective", sent[-1]["content"])
                self.assertNotIn("working account", sent[-1]["content"])
                self.assertEqual(sent[1]["reasoning_content"], "PRIVATE")
                self.assertEqual(json.dumps(history), original)

    def test_compactor_preserves_actual_assistant_body_without_added_attribution(self):
        from opencode.compaction import _summary_messages
        body = "The command failed. Its cause is not established.\nKeep the exact error."
        history = [{"id": "note-1", "role": "assistant", "content": body,
                    "tool_calls": [{"id": "r", "name": "read", "arguments": {"filePath": "error.log"}}]},
                   {"role": "tool", "tool_call_id": "r", "content": "original error"}]
        original = json.dumps(history)
        sent = _summary_messages(history, "archive.json")
        self.assertEqual(sent[0]["content"], body)
        self.assertNotIn("archive.json", json.dumps(sent))
        self.assertIn("## Work State", sent[-1]["content"])
        self.assertIn("## Next Move", sent[-1]["content"])
        self.assertEqual(json.dumps(history), original)

    def test_previous_summary_is_embedded_only_in_the_final_user_prompt(self):
        from opencode.compaction import _summary_messages
        for fields in ({"compaction_through": "old", "finish_reason": "stop"}, {"synthetic": True}, {"error": "aborted"}):
            with self.subTest(fields=fields):
                sent = _summary_messages([{"id": "a", "role": "assistant", "content": "Original text.",
                                           **fields}], "archive.json", "Earlier generated account.")
                if fields.get("synthetic") or fields.get("error") == "aborted":
                    self.assertEqual([m["role"] for m in sent], ["assistant", "user"])
                    self.assertEqual(sent[0]["content"], "Original text.")
                else:
                    self.assertEqual([m["role"] for m in sent], ["user"])
                    self.assertNotIn("Original text.", sent[0]["content"])
                self.assertIn("<previous-summary>\nEarlier generated account.\n</previous-summary>", sent[-1]["content"])
                self.assertEqual(json.dumps(sent).count("Earlier generated account."), 1)
                self.assertNotIn("archive.json", json.dumps(sent))

    def test_summary_template_is_stable_across_text_and_tool_only_batches(self):
        from opencode.compaction import _summary_messages
        first = _summary_messages([{"id": "n", "role": "assistant", "content": "A tentative account."}],
                                  "archive.json")
        later = _summary_messages([{"role": "assistant", "tool_calls": [
            {"id": "r", "name": "read", "arguments": {"filePath": "second.txt"}}]},
            {"role": "tool", "tool_call_id": "r", "content": "new observation"}],
            "archive.json", "Summary of the earlier account.")
        for heading in ("## Objective", "## Important Details", "## Work State", "### Completed",
                        "### Active", "### Blocked", "## Next Move", "## Relevant Files"):
            self.assertIn(heading, first[-1]["content"])
            self.assertIn(heading, later[-1]["content"])
        self.assertIn("Summary of the earlier account.", later[-1]["content"])
        self.assertEqual(later[1]["content"], "new observation")

    def test_tool_only_compaction_keeps_uncovered_exchanges_after_restart(self):
        from opencode.provider import openai_messages_from_history
        human = self.store.add_message(self.sid, "user", {"content": "Inspect the original records; do not rerun."})
        self.store.add_message(self.sid, "assistant", {"tool_calls": [
            {"id": "old", "name": "read", "arguments": {"filePath": "old.log"}}]})
        older = self.store.add_message(self.sid, "tool", {"tool_call_id": "old", "content": "Old observation. " * 1800})
        tail = []
        for i in range(7):
            tail.append(self.store.add_message(self.sid, "assistant", {"content": "", "reasoning_content": f"protocol-{i}",
                "tool_calls": [{"id": f"r{i}", "name": "read", "arguments": {"filePath": f"source-{i}.json"}}]}))
            tail.append(self.store.add_message(self.sid, "tool", {"tool_call_id": f"r{i}", "name": "read",
                "content": f"Exact observation {i}, including its original identifiers and uncertainty."}))
        before = self.store.messages(self.sid)
        self.app.provider = ScriptedProvider([Completion(text="Observed old records; not a verified conclusion.", finish_reason='stop')], context=64000)
        with patch("opencode.compaction.retained_split", return_value=2):
            _maybe_compact(self.app, self.sid, before, self.app.provider.info, "test", force=True)
        request = self.app.provider.calls[0]["messages"]
        self.assertEqual(request[1]["content"], "")
        self.assertEqual(request[2]["content"], older["content"][:2000] +
                         f"\n[Tool output truncated for compaction: omitted {len(older['content']) - 2000} chars]")
        self.assertIn("## Next Move", request[-1]["content"])
        self.assertEqual(self.store.messages(self.sid)[:len(before)], before)
        restarted = Store(self.store.path)
        try:
            projected = restarted.context_messages(self.sid)
            self.assertEqual(projected[0]["compaction_through"], older["id"])
            self.assertEqual(projected[1:-1], tail)
            self.assertTrue(projected[-1]["synthetic"])
            self.assertNotIn(human["id"], [m["id"] for m in projected])
            self.assertEqual(openai_messages_from_history(projected[1:-1]), openai_messages_from_history(tail))
        finally:
            restarted.close()

    def test_oversized_assistant_is_sent_in_one_summary_request(self):
        self.store.add_message(self.sid, "user", {"content": "Continue investigating."})
        body = "Still investigating the evidence. " * 3000
        self.store.add_message(self.sid, "assistant", {"content": body})
        self.app.provider = ScriptedProvider([Completion(text="Observation summary.", finish_reason="stop")], context=4096)
        _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        self.assertEqual(len(self.app.provider.calls), 1)
        self.assertIn(body, [m.get("content") for m in self.app.provider.calls[0]["messages"]])

    def test_reply_counts_do_not_depend_on_a_summary_or_repeated_full_scans(self):
        self.store.add_message(self.sid, "tool", {"name": "paper_search", "content": "metadata"})
        saved = self.store.add_message(self.sid, "tool", {"name": "websearch", "content": "actual snippet"})
        self.store.export_tool_history(self.sid)
        self.store.commit_compaction(self.sid, saved["id"], "There was only a paper_search, no websearch")
        with patch.object(self.store, "messages", side_effect=AssertionError("unexpected full scan")):
            overview = self.store.tool_history_overview(self.sid)
            self.assertIn(str(self.store.tool_history_path(self.sid)), overview)
            index = self.store.tool_history_path(self.sid).read_text(encoding="utf-8")
            self.assertIn("paper_search: 1", index)
            self.assertIn("websearch: 1", index)
            self.assertNotIn("paper_search: 1", overview)
        self.store.export_tool_history(self.sid)
        self.assertEqual(overview, self.store.tool_history_overview(self.sid))

    def test_large_tool_result_is_truncated_only_for_summary_and_keeps_exact_saved_content(self):
        from opencode.compaction import estimate_tokens, input_budget
        self.store.add_message(self.sid, "user", {"content": "Investigate the original output"})
        self.store.add_message(self.sid, "assistant", {"tool_calls": [
            {"id": "large", "name": "read", "arguments": {"filePath": "large.json"}}]})
        original = '\\"\t' * 20000
        receipt = self.store.add_message(self.sid, "tool", {
            "tool_call_id": "large", "name": "read", "content": original})
        self.store.add_message(self.sid, "user", {"content": "Continue checking"})
        self.app.provider = ScriptedProvider([Completion(text="working summary", finish_reason='stop')], context=8192)
        _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        calls = self.app.provider.calls
        self.assertEqual(len(calls), 1)
        sent_tool = next(m for m in calls[0]["messages"] if m["role"] == "tool")
        self.assertEqual(sent_tool["content"], original[:2000] +
                         f"\n[Tool output truncated for compaction: omitted {len(original) - 2000} chars]")
        self.assertNotIn("Incomplete archived exchange", json.dumps(calls[0]["messages"]))
        for call in calls:
            budget = input_budget(self.app, self.app.provider.info, "test", call["system"])
            self.assertLessEqual(estimate_tokens(call["messages"]), budget)
        saved = next(m for m in self.store.messages(self.sid) if m["id"] == receipt["id"])
        self.assertEqual(saved["content"], original)

    def test_read_presentation_keeps_facts_without_guessing_authorship(self):
        from opencode.loop import _present_history
        path = self.project / "arbitrary-name.txt"
        def save_pair(name, identifier, args, metadata):
            call = self.store.add_message(self.sid, "assistant", {"tool_calls": [
                {"id": identifier, "name": name, "arguments": args}]})
            result = self.store.add_message(self.sid, "tool", {
                "tool_call_id": identifier, "name": name, "content": "raw result", "metadata": metadata,
            })
            self.store.export_tool_history(self.sid, [call, result])
            return result
        initial = save_pair("read", "before", {"filePath": str(path)}, {"path": str(path)})
        write = save_pair("write", "w", {"filePath": str(path), "content": "claim"}, {"path": str(path)})
        read = save_pair("read", "r", {"filePath": str(path), "offset": 4, "limit": 2},
                         {"path": str(path), "nextOffset": 6, "nextCharOffset": 0})
        presented = _present_history([initial, read], self.store, self.sid)
        self.assertNotIn("No prior successful", presented[0]["content"])
        self.assertNotIn(write["id"], presented[0]["content"])
        self.assertNotIn(write["id"], presented[1]["content"])
        self.assertNotIn("not independent confirmation", presented[1]["content"])
        self.assertEqual(presented[1]["content"], "raw result")
        self.assertEqual(self.store.messages(self.sid)[-1]["content"], "raw result")
        self.store.export_tool_history(self.sid)
        self.assertEqual(presented, _present_history([initial, read], self.store, self.sid))

    def test_failed_write_does_not_add_authorship_judgment(self):
        path = self.project / "input.txt"
        path.write_text("source", encoding="utf-8")
        self.store.add_message(self.sid, "assistant", {"tool_calls": [
            {"id": "w", "name": "write", "arguments": {"filePath": str(path), "content": "not written"}}]})
        self.store.add_message(self.sid, "tool", {"tool_call_id": "w", "name": "write", "title": "error", "content": "Error"})
        self.store.export_tool_history(self.sid)
        self.app.provider = ScriptedProvider([
            Completion(tool_calls=[ToolCall("r", "read", {"filePath": str(path)})], finish_reason='tool-calls'), Completion(text="answer", finish_reason='stop'),
        ])
        self.app.prompt(self.sid, "Read")
        self.assertNotIn("No prior successful", self.app.provider.calls[-1]["messages"][-1]["content"])
        self.assertIn("source", self.app.provider.calls[-1]["messages"][-1]["content"])

    def test_read_has_total_output_budget(self):
        path = self.project / "large.txt"
        path.write_text(("x" * 1900 + "\n") * 2000, encoding="utf-8")
        result = _read({"filePath": str(path)}, self.ctx())
        self.assertLess(len(result.output.encode("utf-8")), 60 * 1024)

    def test_abort_leaves_no_unanswered_tool_call_in_next_prompt(self):
        from opencode.tools.types import Tool, ToolResult
        def stop(args, ctx):
            self.app.abort(self.sid)
            return ToolResult(output="stopped")
        self.app.extra_tools = [Tool("stop_test", "test", {"type": "object", "properties": {}}, stop)]
        self.app.provider = ScriptedProvider([Completion(tool_calls=[
            ToolCall("executed", "stop_test", {}), ToolCall("not-executed", "glob", {"pattern": "*.txt"})
        ], finish_reason='tool-calls')])
        self.app.prompt(self.sid, "first turn")
        self.app.provider = ScriptedProvider([Completion(text="resumed", finish_reason='stop')])
        self.app.prompt(self.sid, "resume")
        messages = self.app.provider.calls[0]["messages"]
        requested = {c["id"] for m in messages for c in m.get("tool_calls", [])}
        answered = {m["tool_call_id"] for m in messages if m["role"] == "tool"}
        self.assertEqual(requested, answered)

    def test_question_wait_can_be_stopped(self):
        done = threading.Event()
        errors = []
        def ask():
            try:
                self.app.ask_questions(self.sid, [{"question": "Which option?"}])
            except RuntimeError as exc:
                errors.append(str(exc))
            finally:
                done.set()
        worker = threading.Thread(target=ask)
        worker.start()
        try:
            self.app.abort(self.sid)
            self.assertTrue(done.wait(0.15), "abort does not release the human-question wait")
            self.assertIn("cancelled", errors[0])
        finally:
            for pending in self.app.pending_questions():
                self.app.reply_question(pending["id"], [["answer"]])
            worker.join(timeout=2)
            if worker.is_alive():
                raise RuntimeError("Test worker did not stop")

    def test_length_stop_preserves_empty_response_and_finish(self):
        client = Client(self.app.auth, {"provider": {"local": {"options": {"baseURL": "http://127.0.0.1:1/v1", "apiKey": "test"}}}})
        provider = client.providers["local"]
        response = httpx.Response(200, json={"choices": [{"finish_reason": "length", "message": {"content": ""}}]})
        with mock_provider_transport() as transport:
            transport.return_value.__enter__.return_value.post.return_value = response
            result = client.complete(provider=provider, model="test", system="", messages=[], tools=None)
        self.assertEqual((result.text, result.finish_reason), ("", "length"))

    def test_openai_request_preserves_auth_and_model_options(self):
        client = Client(self.app.auth, {"provider": {"local": {
            "options": {"baseURL": "http://127.0.0.1:1/v1", "apiKey": "test-token"},
            "models": {"test": {"limit": {"output": 12000},
                                "options": {"reasoningEffort": "medium", "top_p": 0.9}}},
        }}})
        response = httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {"content": "answer"}}]})
        with mock_provider_transport() as transport:
            post = transport.return_value.__enter__.return_value.post
            post.return_value = response
            client.complete(provider=client.providers["local"], model="test", system="", messages=[])
            sent = post.call_args.kwargs
        self.assertEqual(sent["headers"]["Authorization"], "Bearer test-token")
        self.assertEqual(sent["json"]["reasoning_effort"], "medium")
        self.assertEqual(sent["json"]["top_p"], 0.9)
        self.assertEqual(sent["json"]["max_tokens"], 12000)

    def test_empty_stop_preserves_provider_output_without_local_retry(self):
        client = Client(self.app.auth, {"provider": {"local": {
            "options": {"baseURL": "http://127.0.0.1:1/v1", "apiKey": "test"}}}})
        response = httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {"content": "  "}}]})
        with mock_provider_transport() as transport:
            transport.return_value.__enter__.return_value.post.return_value = response
            result = client.complete(provider=client.providers["local"], model="test", system="", messages=[])
        self.assertEqual((result.text, result.finish_reason), ("  ", "stop"))

    def test_empty_final_does_not_deliver_previous_work_note(self):
        self.app.provider = ScriptedProvider([
            Completion(text="Still looking, not an answer.", tool_calls=[ToolCall("x", "glob", {"pattern": "*.txt"})], finish_reason="tool-calls"),
            Completion(text="", finish_reason="stop"),
            Completion(text="", finish_reason="stop"),
        ])
        result = self.app.prompt(self.sid, "Investigate")
        # An empty stop after tool work is asked once for the answer; a second empty stop ends the turn.
        self.assertEqual(result["text"], "")
        self.assertNotIn("error", self.store.messages(self.sid)[-1])
        self.assertTrue(any(m.get("synthetic") and "沒有給出任何回答" in (m.get("content") or "")
                            for m in self.store.messages(self.sid)))

    def test_snapshot_turn_is_reserved_before_interrupted_tool(self):
        from opencode.tools.types import Tool, ToolResult
        observed = []
        class ProcessInterrupted(BaseException):
            pass
        def interrupted(args, ctx):
            observed.append(ctx.turn)
            raise ProcessInterrupted()
        self.app.extra_tools.append(Tool("interrupted", "Test interruption", {}, interrupted))
        self.app.provider = ScriptedProvider([Completion(tool_calls=[ToolCall("a", "interrupted", {})], finish_reason='tool-calls')])
        with self.assertRaises(ProcessInterrupted):
            self.app.prompt(self.sid, "first")
        self.assertEqual(self.store.get_session(self.sid)["meta"]["turn"], 1)
        def resumed(args, ctx):
            observed.append(ctx.turn)
            return ToolResult(output="completed")
        self.app.extra_tools = [Tool("resumed", "Test continuation", {}, resumed)]
        self.app.provider = ScriptedProvider([
            Completion(tool_calls=[ToolCall("b", "resumed", {})], finish_reason='tool-calls'), Completion(text="done", finish_reason='stop')])
        self.app.prompt(self.sid, "continue")
        self.assertEqual(observed, [1, 2])
        self.assertIn("Tool execution aborted", json.dumps(self.app.provider.calls[0]["messages"]))

    def test_model_context_limit_is_honored(self):
        client = Client(self.app.auth, {"provider": {"local": {"models": {"test": {"limit": {"context": 4096}}}}}})
        provider, _ = client.resolve("local/test")
        self.assertEqual(provider.context, 4096)

    def test_undo_restores_start_of_turn_after_two_edits(self):
        path = self.project / "source.txt"
        path.write_text("first", encoding="utf-8")
        ctx = self.ctx()
        _read({"filePath": str(path)}, ctx)
        _edit({"filePath": str(path), "oldString": "first", "newString": "second"}, ctx)
        _edit({"filePath": str(path), "oldString": "second", "newString": "third"}, ctx)
        self.store.revert(self.sid)
        self.assertEqual(path.read_text(encoding="utf-8"), "first")

    def test_search_http_error_is_returned_without_an_unrelated_provider_fallback(self):
        response = httpx.Response(403, request=httpx.Request("POST", "https://mcp.exa.ai/mcp"))
        with patch.dict(os.environ, {"OPENCODE_WEBSEARCH_PROVIDER": "exa"}), patch("opencode.tools.web.httpx.AsyncClient") as transport:
            post = transport.return_value.__aenter__.return_value.post
            post.return_value = response
            with self.assertRaises(Exception):
                _websearch({"query": "test query"}, self.ctx())
            self.assertEqual(post.call_count, 1)

    def test_subdirectory_patch_checks_and_writes_same_file(self):
        child = self.project / "subdir"
        child.mkdir()
        target = self.project / "source.txt"
        target.write_text("original", encoding="utf-8")
        ctx = self.ctx()
        ctx.directory = child
        _apply_patch({"patchText": "*** Begin Patch\n*** Add File: source.txt\n+new\n*** End Patch"}, ctx)
        self.assertEqual(target.read_text(encoding="utf-8"), "original")
        self.assertEqual((child / "source.txt").read_text(encoding="utf-8"), "new\n")

    def test_long_unicode_line_follows_source_limit_and_next_lines_remain_readable(self):
        original = "數據🙂" * 40000
        path = self.project / "long.jsonl"
        path.write_text(original + "\nlast", encoding="utf-8")
        result = _read({"filePath": str(path)}, self.ctx())
        # JS substring counts UTF-16 units: these three characters use four.
        self.assertIn("數據🙂" * 500 + "... (line truncated to 2000 chars)", result.output)
        self.assertIn("2: last", result.output)
        self.assertNotIn("charOffset", result.metadata)
        self.assertEqual(path.read_text(encoding="utf-8"), original + "\nlast")

    def test_compaction_restart_preserves_archive_and_new_suffix(self):
        original = self.compactable_history()
        self.app.provider = ScriptedProvider([Completion(text="summary", finish_reason='stop')], context=8192)
        _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        self.store.add_message(self.sid, "user", {"content": "new question after checkpoint"})
        restarted = Store(self.store.path)
        try:
            context = restarted.context_messages(self.sid)
            self.assertEqual("summary", context[0]["content"])
            self.assertEqual(context[-1]["content"], "new question after checkpoint")
            self.assertNotIn(original["id"], [m["id"] for m in context])
            self.assertIn(original["id"], [m["id"] for m in restarted.messages(self.sid)])
            archives = list((self.store.path.parent / "history" / self.sid).glob("*.json"))
            self.assertEqual(len(archives), 1)
            archived = json.loads(archives[0].read_text(encoding="utf-8"))
            self.assertEqual(archived[0]["content"], original["content"])
        finally:
            restarted.close()

    def test_incomplete_single_summary_keeps_old_context_without_retry(self):
        self.compactable_history()
        before = self.store.context_messages(self.sid)
        def incomplete(_):
            raise ProviderError("Model response incomplete: length", Completion(text="partial summary", finish_reason="length"))
        self.app.provider = ScriptedProvider([incomplete], context=8192)
        with self.assertRaisesRegex(ProviderError, "incomplete"):
            _maybe_compact(self.app, self.sid, before, self.app.provider.info, "test", force=True)
        self.assertEqual(len(self.app.provider.calls), 1)
        self.assertEqual(self.store.context_messages(self.sid)[:len(before)], before)
        self.assertIn("incomplete", self.store.messages(self.sid)[-1]["error"])

    def test_same_session_joins_existing_loop_without_clearing_abort(self):
        entered, release = threading.Event(), threading.Event()
        results = []
        def response(_):
            entered.set()
            release.wait(2)
            return Completion(text="late response", finish_reason="stop")
        self.app.provider = ScriptedProvider([response])
        first = threading.Thread(target=lambda: results.append(self.app.prompt(self.sid, "first")))
        second = threading.Thread(target=lambda: results.append(self.app.prompt(self.sid, "second")))
        first.start()
        try:
            self.assertTrue(entered.wait(1))
            self.app.abort(self.sid)
            second.start()
            self.assertTrue(self.app.abort_event(self.sid).is_set())
        finally:
            release.set()
            first.join(3)
            second.join(3)
        self.assertFalse(first.is_alive() or second.is_alive())
        self.assertEqual([r["status"] for r in results], ["aborted", "aborted"])
        self.assertEqual([m.get("content") for m in self.store.messages(self.sid) if m["role"] == "user"], ["first", "second"])

    def test_late_model_tool_call_is_not_executed_after_stop(self):
        def response(_):
            self.app.abort(self.sid)
            return Completion(tool_calls=[ToolCall("late", "write", {
                "filePath": str(self.project / "must-not-exist"), "content": "late write"})], finish_reason='tool-calls')
        self.app.provider = ScriptedProvider([response])
        result = self.app.prompt(self.sid, "work")
        self.assertEqual(result["status"], "aborted")
        self.assertFalse((self.project / "must-not-exist").exists())
        receipts = [m for m in self.store.messages(self.sid) if m["role"] == "tool"]
        self.assertEqual(len(receipts), 1)
        self.assertEqual(receipts[0]["tool_call_id"], "late")
        self.assertIn("Tool execution aborted", receipts[0]["content"])

    def test_incomplete_model_output_is_saved_but_not_executed(self):
        partial = Completion(text="unfinished", tool_calls=[ToolCall("x", "write", {})], finish_reason="length")
        def response(_):
            raise ProviderError("Model response incomplete: length", partial)
        self.app.provider = ScriptedProvider([response])
        with self.assertRaises(ProviderError):
            self.app.prompt(self.sid, "work")
        saved = next(m for m in self.store.messages(self.sid) if m["role"] == "assistant")
        self.assertEqual(saved["content"], "unfinished")
        self.assertEqual(saved["incomplete_tool_calls"][0]["id"], "x")
        self.assertEqual(saved["tool_calls"], [{"id": "x", "name": "write", "arguments": {}}])
        receipt = self.store.messages(self.sid)[-1]
        self.assertEqual(receipt["role"], "tool")
        self.assertEqual(receipt["tool_call_id"], "x")
        self.assertIn("Tool execution aborted", receipt["content"])

    def test_model_limits_do_not_leak_between_models(self):
        client = Client(self.app.auth, {"provider": {"local": {"models": {
            "small": {"limit": {"context": 4096, "output": 500}},
            "large": {"limit": {"context": 64000, "output": 12000}},
        }}}})
        small, _ = client.resolve("local/small")
        large, _ = client.resolve("local/large")
        self.assertEqual(small.context, 4096)
        self.assertEqual(large.context, 64000)
        self.assertEqual(client.output_limit(small, "small"), 500)
        self.assertEqual(client.output_limit(large, "large"), 12000)

    def test_stream_length_stop_routes_partial_tool_arguments_to_invalid(self):
        from opencode.provider import repair_tool_calls
        client = Client(self.app.auth, {})
        response = httpx.Response(200, content=(
            'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"x","function":{"name":"write","arguments":"{"}}]}}]}\n\n'
            'data: {"choices":[{"delta":{},"finish_reason":"length"}]}\n\n'
            'data: [DONE]\n\n').encode())
        with mock_provider_transport() as transport:
            transport.return_value.__enter__.return_value.stream.return_value.__enter__.return_value = response
            completion = client._openai_stream("test", {}, {}, 10, "test", lambda _: None)
        repaired = repair_tool_calls(completion, [{"name": "write", "parameters": {"type": "object"}}])
        self.assertEqual(repaired.finish_reason, "length")
        self.assertEqual(repaired.tool_calls[0].name, "invalid")

    def test_permission_wait_is_cancelled(self):
        from opencode.permission import PermissionRejected
        self.app.permissions.auto = False
        ready, done = threading.Event(), threading.Event()
        errors = []
        def ask():
            ready.set()
            try:
                self.app.permissions.ask(session_id=self.sid, permission="test", patterns=["x"], ruleset=[])
            except PermissionRejected as exc:
                errors.append(str(exc))
            finally:
                done.set()
        worker = threading.Thread(target=ask)
        worker.start()
        try:
            self.assertTrue(ready.wait(1))
            self.app.abort(self.sid)
            self.assertTrue(done.wait(1))
        finally:
            self.app.abort(self.sid)
            worker.join(2)
        self.assertTrue(errors)
        self.assertEqual(self.app.permissions.list_pending(), [])

    def test_move_patch_and_undo_cover_both_paths(self):
        child = self.project / "child"
        child.mkdir()
        source = child / "a.txt"
        destination = child / "b.txt"
        source.write_text("old\n", encoding="utf-8")
        destination.write_text("prior destination\n", encoding="utf-8")
        ctx = self.ctx()
        ctx.directory = child
        _read({"filePath": str(source)}, ctx)
        _read({"filePath": str(destination)}, ctx)
        _apply_patch({"patchText": "*** Begin Patch\n*** Update File: a.txt\n*** Move to: b.txt\n@@\n-old\n+new\n*** End Patch"}, ctx)
        self.assertFalse(source.exists())
        self.assertEqual(destination.read_text(), "new\n")
        self.store.revert(self.sid)
        self.assertEqual(source.read_text(), "old\n")
        self.assertEqual(destination.read_text(), "prior destination\n")

    def test_compaction_prompt_has_work_state_and_concrete_next_move(self):
        from opencode.compaction import _summary_messages
        prompt = _summary_messages([
            {"role": "user", "content": "Continue the saved work and keep uncertainties."},
            {"role": "assistant", "content": "Still checking one receipt."},
        ], "archive.json")[-1]["content"]
        positions = [prompt.index(heading) for heading in (
            "## Objective", "## Important Details", "## Work State", "## Next Move", "## Relevant Files")]
        self.assertEqual(positions, sorted(positions))
        self.assertIn("### Blocked", prompt)
        self.assertIn("immediate concrete action", prompt)
        self.assertNotIn("Do not propose a next file", prompt)
        self.assertNotIn("archive.json", prompt)

    def test_recompacting_summary_does_not_retire_uncovered_tail(self):
        first = self.store.add_message(self.sid, "user", {"content": "old request"})
        tail = self.store.add_message(self.sid, "assistant", {"content": "must remain verbatim"})
        self.store.commit_compaction(self.sid, first["id"], "Long summary " * 100)
        self.app.provider = ScriptedProvider([Completion(text="short summary", finish_reason='stop')], context=8192)
        with patch("opencode.compaction.retained_split", return_value=0):
            _maybe_compact(self.app, self.sid, self.store.context_messages(self.sid), self.app.provider.info, "test", force=True)
        self.assertEqual(self.store.context_messages(self.sid)[-2]["id"], tail["id"])
        self.assertTrue(self.store.context_messages(self.sid)[-1]["synthetic"])

    def test_background_notification_does_not_split_tool_exchange(self):
        from opencode.compaction import exchanges
        from opencode.provider import openai_messages_from_history
        history = [
            {"role": "assistant", "tool_calls": [{"id": "c", "name": "task", "arguments": {}}]},
            {"role": "user", "content": "background result"},
            {"role": "tool", "tool_call_id": "c", "content": "started"},
            {"role": "assistant", "content": "next step"},
        ]
        self.assertEqual(len(exchanges(history)[0]), 3)
        sent = openai_messages_from_history(history)
        self.assertEqual([m["role"] for m in sent], ["assistant", "tool", "user", "assistant"])
        self.assertEqual(sent[2]["content"], "background result")

    def test_prompt_budget_counts_system_and_tools(self):
        from opencode.compaction import input_budget
        provider = SimpleNamespace(id="test", context=16000)
        plain = input_budget(self.app, provider, "test")
        loaded = input_budget(self.app, provider, "test", "instructions " * 100, [{"description": "tool " * 100}])
        self.assertLess(loaded, plain)

    def test_truncate_long_line_keeps_whole_lines_and_exact_file(self):
        from opencode.tools.util import truncate_output
        text = "line-without-newlines" * 10000
        output, metadata = truncate_output(text, max_bytes=1000)
        self.assertTrue(metadata["truncated"])
        self.assertNotIn("line-without-newlines", output)
        self.assertEqual(Path(metadata["outputPath"]).read_text(encoding="utf-8"), text)

    def recovery_client(self):
        options = {"reasoningEffort": "medium", "include_stream_usage": True}
        return Client(self.app.auth, {"provider": {"local": {
            "options": {"baseURL": "http://127.0.0.1:1/v1", "apiKey": "test"},
            "models": {"test": {"limit": {"context": 131072, "output": 12000}, "options": options}},
        }}})

    def test_empty_length_finish_ends_turn_without_downgrade_or_tool_execution(self):
        client = self.recovery_client()
        self.app.provider = client
        path = self.project / "created.txt"
        responses = [
            httpx.Response(200, json={"choices": [{"finish_reason": "length", "message": {"content": ""}}]}),
            httpx.Response(200, json={"choices": [{"finish_reason": "tool_calls", "message": {"tool_calls": [
                {"id": "write-once", "function": {"name": "write", "arguments": json.dumps({"filePath": str(path), "content": "actual output"})}}
            ]}}]}),
            httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {"content": "done"}}]}),
        ]
        with mock_stream_responses(responses) as sent:
            outcome = self.app.prompt(self.sid, "write the file", model="local/test")
        # Deliberate deviation from the source: output cut off by the length limit
        # is not a final answer, so the turn ends as output_limit, not completed.
        self.assertEqual(outcome["status"], "output_limit")
        self.assertFalse(path.exists())
        self.assertEqual([s["reasoning_effort"] for s in sent], ["medium"])
        tool_messages = [m for m in self.store.messages(self.sid) if m["role"] == "tool"]
        self.assertEqual(len(tool_messages), 0)

    def test_empty_length_completion_returns_once_and_preserves_config(self):
        client = self.recovery_client()
        response = httpx.Response(200, json={"choices": [{"finish_reason": "length", "message": {"content": ""}}]})
        with mock_provider_transport() as transport:
            post = transport.return_value.__enter__.return_value.post
            post.return_value = response
            result = client.complete(provider=client.providers["local"], model="test", system="s", messages=[])
        self.assertEqual(result.finish_reason, "length")
        self.assertEqual(post.call_count, 1)
        self.assertEqual(client._model_config("local", "test")["options"]["reasoningEffort"], "medium")

    def test_nonretryable_error_is_not_retried(self):
        client = self.recovery_client()
        with patch.object(client, "_openai", side_effect=ProviderError("length", Completion(finish_reason="length"))) as call:
            with self.assertRaises(ProviderError):
                client.complete(provider=client.providers["local"], model="test", system="s", messages=[])
        self.assertEqual(call.call_count, 1)

    def test_partial_or_other_failures_are_not_empty_output_retries(self):
        for partial in [Completion(text="incomplete text", finish_reason="length"),
                        Completion(tool_calls=[ToolCall("x", "write", {})], finish_reason="length"),
                        Completion(finish_reason="content_filter"), None]:
            with self.subTest(partial=partial):
                client = self.recovery_client()
                with patch.object(client, "_openai", side_effect=ProviderError("incomplete", partial)) as call:
                    with self.assertRaises(ProviderError):
                        client.complete(provider=client.providers["local"], model="test", system="s", messages=[])
                self.assertEqual(call.call_count, 1)

    def test_usage_is_requested_and_preserved_for_streamed_completion(self):
        client = self.recovery_client()
        events = [
            {"choices": [{"delta": {"content": "answer"}, "finish_reason": "stop"}]},
            {"choices": [], "usage": {"prompt_tokens": 10, "completion_tokens": 2, "total_tokens": 12}},
        ]
        with mock_provider_transport() as transport:
            stream = transport.return_value.__enter__.return_value.stream
            response = stream.return_value.__enter__.return_value
            response.status_code = 200
            response.iter_lines.return_value = ["data: " + json.dumps(e) for e in events] + ["data: [DONE]"]
            result = client.complete(provider=client.providers["local"], model="test", system="s", messages=[], on_text=lambda _: None)
        self.assertEqual(stream.call_args.kwargs["json"]["stream_options"], {"include_usage": True})
        self.assertEqual(result.usage["total_tokens"], 12)

    def test_system_uses_source_environment_without_python_interpreter_hint(self):
        import sys
        from opencode.tools.shell import description
        self.app.provider = ScriptedProvider([Completion(text="answer", finish_reason="stop")])
        self.app.prompt(self.sid, "check the environment")
        self.assertNotIn(sys.executable, self.app.provider.calls[0]["system"])
        self.assertIn(f"Working directory: {self.project}", self.app.provider.calls[0]["system"])
        self.assertTrue(description())

    def test_reasoning_protocol_survives_tools_restart_and_new_user_turn(self):
        client = self.recovery_client()
        client._model_config("local", "test")["interleaved"] = {"field": "reasoning_content"}
        self.app.provider = client
        (self.project / "evidence.txt").write_text("observed", encoding="utf-8")
        replies = [
            httpx.Response(200, json={"choices": [{"finish_reason": "tool_calls", "message": {
                "content": "Reading.", "reasoning_content": "protocol-only first",
                "tool_calls": [{"id": "read1", "function": {"name": "read", "arguments": json.dumps({
                    "filePath": str(self.project / "evidence.txt")})}}]}}]}),
            httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {
                "content": "Answered.", "reasoning_content": "protocol-only second"}}]}),
            httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {
                "content": "Follow-up.", "reasoning_content": ""}}]}),
        ]
        with mock_stream_responses(replies) as requests:
            self.app.prompt(self.sid, "read the file", model="local/test")
            reopened = Store(self.store.path)
            try:
                app = App(self.project, store=reopened, auto_approve=True, config={})
                app.generate_titles = False
                app.provider = client
                self.assertEqual(app.prompt(self.sid, "explain further")["text"], "Follow-up.")
            finally:
                reopened.close()
        sent = [request["messages"] for request in requests]
        self.assertEqual([m["reasoning_content"] for m in sent[1] if m["role"] == "assistant"], ["protocol-only first"])
        self.assertEqual([m["reasoning_content"] for m in sent[2] if m["role"] == "assistant"],
                         ["protocol-only first", "protocol-only second"])
        self.assertNotIn("protocol-only", "".join(m.get("content", "") for m in self.store.messages(self.sid)))

    def test_reasoning_stream_is_separate_and_empty_is_preserved(self):
        client = self.recovery_client()
        events = [{"choices": [{"delta": {"reasoning_content": value}}]} for value in ["", "part1", "part2"]]
        events.append({"choices": [{"delta": {"content": "answer"}, "finish_reason": "stop"}]})
        visible = []
        with mock_provider_transport() as transport:
            response = transport.return_value.__enter__.return_value.stream.return_value.__enter__.return_value
            response.status_code = 200
            response.iter_lines.return_value = ["data: " + json.dumps(e) for e in events] + ["data: [DONE]"]
            result = client.complete(provider=client.providers["local"], model="test", system="s", messages=[], on_text=visible.append)
            self.assertEqual(result.reasoning_content, "part1part2")
            self.assertEqual(visible, ["answer"])
            response.iter_lines.return_value = ["data: " + json.dumps({"choices": [{
                "delta": {"reasoning_content": "", "content": "answer"}, "finish_reason": "stop"}]})]
            result = client.complete(provider=client.providers["local"], model="test", system="s", messages=[], on_text=visible.append)
            self.assertEqual(result.reasoning_content, "")

    def test_reasoning_wire_field_matches_sdk_and_does_not_mutate_history(self):
        client = self.recovery_client()
        messages = [{"role": "assistant", "content": "old answer", "reasoning_content": "protocol"},
                    {"role": "assistant", "content": "legacy answer"}, {"role": "user", "content": "next"}]
        original = json.loads(json.dumps(messages))
        response = httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": {"content": "answer"}}]})
        with mock_provider_transport() as transport:
            post = transport.return_value.__enter__.return_value.post
            post.return_value = response
            client.complete(provider=client.providers["local"], model="test", system="", messages=messages)
            plain = post.call_args.kwargs["json"]["messages"]
            self.assertEqual(plain[0]["reasoning_content"], "protocol")
            self.assertNotIn("reasoning_content", plain[1])
            client._model_config("local", "test")["interleaved"] = {"field": "reasoning_content"}
            client.complete(provider=client.providers["local"], model="test", system="", messages=messages)
            sent = post.call_args.kwargs["json"]["messages"]
            self.assertEqual(sent[0]["reasoning_content"], "protocol")
            self.assertEqual(sent[1]["reasoning_content"], "")
            self.assertNotIn("reasoning_content", sent[2])
        self.assertEqual(messages, original)

    def test_partial_reasoning_is_saved_but_not_replayed_as_completed(self):
        from opencode.provider import openai_messages_from_history
        partial = Completion(reasoning_content="unfinished protocol", finish_reason="length")
        self.app.provider = ScriptedProvider([lambda _: (_ for _ in ()).throw(ProviderError("limit", partial))])
        with self.assertRaises(ProviderError):
            self.app.prompt(self.sid, "work")
        saved = self.store.messages(self.sid)
        self.assertEqual(saved[-1]["reasoning_content"], "unfinished protocol")
        self.assertNotIn("unfinished protocol", json.dumps(openai_messages_from_history(saved)))

    def test_vllm_reasoning_alias_in_stream_nonstream_and_request(self):
        client = self.recovery_client()
        client._model_config("local", "test")["interleaved"] = {"field": "reasoning"}
        message = {"content": "answer", "reasoning": "actual server reasoning"}
        response = httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": message}]})
        history = [{"role": "assistant", "content": "old answer", "reasoning_content": "prior reasoning"}]
        with mock_provider_transport() as transport:
            post = transport.return_value.__enter__.return_value.post
            post.return_value = response
            result = client.complete(provider=client.providers["local"], model="test", system="", messages=history)
            self.assertEqual(result.reasoning_content, "actual server reasoning")
            sent = post.call_args.kwargs["json"]["messages"][0]
            self.assertEqual(sent["reasoning"], "prior reasoning")
            self.assertNotIn("reasoning_content", sent)
            response = transport.return_value.__enter__.return_value.stream.return_value.__enter__.return_value
            response.status_code = 200
            response.iter_lines.return_value = ["data: " + json.dumps({"choices": [{
                "delta": message, "finish_reason": "stop"}]})]
            result = client.complete(provider=client.providers["local"], model="test", system="", messages=history, on_text=lambda _: None)
            self.assertEqual(result.reasoning_content, "actual server reasoning")

    def test_reasoning_counts_toward_context_and_is_preserved_in_summary_input(self):
        from opencode.provider import openai_messages_from_history
        from opencode.compaction import estimate_tokens
        self.store.add_message(self.sid, "user", {"content": "original task"})
        protocol = "private-protocol-only " * 4000
        self.store.add_message(self.sid, "assistant", {"content": "Observed fact.", "reasoning_content": protocol})
        self.store.add_message(self.sid, "user", {"content": "recent question"})
        self.store.add_message(self.sid, "assistant", {"content": "recent answer", "reasoning_content": "recent-protocol"})
        before = self.store.context_messages(self.sid)
        self.assertGreater(estimate_tokens(openai_messages_from_history(before)), 8192)
        self.app.provider = ScriptedProvider([Completion(text="Short observed summary.", finish_reason="stop")], context=64000)
        with patch("opencode.compaction.retained_split", return_value=2):
            _maybe_compact(self.app, self.sid, before, self.app.provider.info, "test", force=True)
        self.assertEqual(len(self.app.provider.calls), 1)
        self.assertIn("private-protocol-only", json.dumps(self.app.provider.calls[0]["messages"]))
        self.assertIn("Observed fact.", json.dumps(self.app.provider.calls[0]["messages"]))
        self.assertIn("recent-protocol", json.dumps(openai_messages_from_history(self.store.context_messages(self.sid))))
        self.assertIn(protocol, [m.get("reasoning_content") for m in self.store.messages(self.sid)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
