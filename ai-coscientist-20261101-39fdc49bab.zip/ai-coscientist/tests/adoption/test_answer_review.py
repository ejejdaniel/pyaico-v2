"""Delivery/lifecycle boundaries only; scripted replies do not prove diagnosis quality."""

import copy
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.context import working_context
from opencode.loop import _present_history
from opencode.provider import Completion, ProviderError, ToolCall
from opencode.store import Store


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    root = tmp_path / "project"
    root.mkdir()
    (root / ".git").mkdir()
    store = Store(tmp_path / "session.db")
    config = {"steps": 8, "agent": {"build": {"options": {"answer_review_skill": "investigate"}}}}
    config["skills"] = {"paths": [str(Path(__file__).resolve().parents[2] / "src/opencode/skill_assets")]}
    app = App(root, store=store, auto_approve=True, config=config)
    app.generate_titles = False
    sid = app.create_session()["id"]
    yield root, app, sid
    store.close()


def model(app, replies):
    calls = []
    replies = iter(replies)

    def complete(**kwargs):
        calls.append(kwargs)
        reply = next(replies)
        if isinstance(reply, Exception):
            raise reply
        return reply(kwargs) if callable(reply) else reply

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=200000), "test"),
                                   complete=complete)
    return calls


def state(app, sid):
    human = [m for m in app.store.messages(sid) if m["role"] == "user"][-1]
    return app.store.answer_review(sid, human["id"])


def test_plain_disabled_answer_has_no_extra_call_or_control_record(case):
    _, app, sid = case
    app.agents["build"].options = {}
    calls = model(app, [Completion(text="ordinary reply", finish_reason='stop')])
    assert app.prompt(sid, "Hello")["text"] == "ordinary reply"
    assert len(calls) == 1 and state(app, sid) is None


def test_draft_is_not_streamed_and_same_agent_can_inspect_evidence(case):
    root, app, sid = case
    (root / "source.txt").write_text("ORIGINAL_OBSERVATION", encoding="utf-8")
    emitted = []

    def draft(kw):
        # Keep the caller's streaming transport, but buffer candidate text.
        assert callable(kw["on_text"])
        kw["on_text"]("UNVERIFIED_CAUSE")
        return Completion(text="UNVERIFIED_CAUSE", finish_reason='stop')

    def inspect(kw):
        assert app.store.answer_review(sid, state(app, sid)["user_message_id"])["phase"] == "checking"
        assert "UNVERIFIED_CAUSE" not in "".join(emitted)
        text = json.dumps(kw["messages"])
        assert "Undelivered assistant draft" in text
        assert "one verification phase" in text
        return Completion(tool_calls=[ToolCall("read-original", "read", {"filePath": str(root / "source.txt")})], finish_reason='tool-calls')

    def finish(kw):
        assert "ORIGINAL_OBSERVATION" in json.dumps(kw["messages"])
        return Completion(text="Withdrawn causal claim; bounded conclusion.", finish_reason='stop')

    calls = model(app, [draft, inspect, finish])
    result = app.prompt(sid, "Investigate without restarting anything", on_text=emitted.append)
    assert result["text"] == "Withdrawn causal claim; bounded conclusion."
    assert len(calls) == 3 and state(app, sid)["steps_used"] == 3
    assert state(app, sid)["phase"] == "delivered"
    messages = app.store.messages(sid)
    roles = [m["answer_review_role"] for m in messages if m.get("answer_review_role")]
    assert roles == ["draft", "check", "answer"]
    assert [m["content"] for m in messages if m["role"] == "user"] == ["Investigate without restarting anything"]
    assert all(c["tools"] == calls[0]["tools"] for c in calls)
    assert "UNVERIFIED_CAUSE" not in "".join(emitted)


@pytest.mark.parametrize("steps", [1, 2])
def test_no_extra_step_and_no_draft_delivery_at_limit(case, steps):
    _, app, sid = case
    app.agents["build"].steps = steps
    replies = [Completion(text="CANDIDATE", finish_reason='stop')]
    if steps > 1:
        replies.append(Completion(tool_calls=[ToolCall("pending", "todowrite", {"todos": [
            {"id": "gap", "content": "Still missing original input", "status": "in_progress", "priority": "high"}]} )], finish_reason='tool-calls'))
    calls = model(app, replies)
    result = app.prompt(sid, "Investigate")
    assert result["status"] == "step_limit" and "CANDIDATE" not in result["text"]
    current = state(app, sid)
    assert current["steps_used"] == steps == current["step_limit"]
    assert current["answer_message_id"] is None
    assert current["phase"] == ("collecting" if steps == 1 else "checking")
    with pytest.raises(ValueError, match="remaining steps"):
        app.prompt(sid, "Investigate", resume_user_message_id=current["user_message_id"])
    assert len(calls) == steps


def test_failure_and_restart_preserve_notice_and_reservation(case):
    root, app, sid = case
    model(app, [Completion(text="DRAFT", finish_reason='stop'), ProviderError("Disconnected")])
    with pytest.raises(ProviderError):
        app.prompt(sid, "Original question")
    original = state(app, sid)
    assert original["steps_used"] == 2 and original["phase"] == "checking"
    # Disable the setting and change discovery: a saved checking turn must still
    # finish its original review, not silently become an ordinary new answer.
    reloaded = Store(app.store.path)
    try:
        restarted = App(root, store=reloaded, auto_approve=True, config={"steps": 10000})
        restarted.generate_titles = False
        calls = model(restarted, [Completion(text="Checked answer", finish_reason='stop')])
        result = restarted.prompt(sid, "Original question", resume_user_message_id=original["user_message_id"])
        assert result["text"] == "Checked answer"
        current = state(restarted, sid)
        assert current["step_limit"] == original["step_limit"] == 8
        assert current["steps_used"] == 3
        assert current["notice_message_id"] == original["notice_message_id"]
        assert len([m for m in reloaded.messages(sid) if m.get("answer_review_role") == "check"]) == 1
        assert len([m for m in reloaded.messages(sid) if m["role"] == "user"]) == 1
        assert "DRAFT" in json.dumps(calls[0]["messages"])
    finally:
        reloaded.close()


def test_pending_review_survives_compaction_without_refilling_covered_request(case):
    _, app, sid = case
    model(app, [Completion(text="UNVERIFIED", finish_reason='stop'), ProviderError("Disconnected")])
    with pytest.raises(ProviderError):
        app.prompt(sid, "Exact original question")
    current = state(app, sid)
    app.store.commit_compaction(sid, app.store.messages(sid)[-1]["id"], "Short summary with no draft")
    model_calls = model(app, [Completion(text="Only the supported scope", finish_reason='stop')])
    app.prompt(sid, "Exact original question", resume_user_message_id=current["user_message_id"])
    prompt = json.dumps(model_calls[0]["messages"])
    assert "Exact original question" not in prompt and "UNVERIFIED" in prompt
    assert "File-backed verification guidance" in prompt
    assert state(app, sid)["notice_message_id"] == current["notice_message_id"]


@pytest.mark.parametrize("change", ["text", "new-human", "other-session", "delivered", "fake-human"])
def test_resume_rejects_mismatch_without_model_calls(case, change):
    _, app, sid = case
    model(app, [Completion(text="Draft", finish_reason='stop'), ProviderError("Stopped")])
    with pytest.raises(ProviderError):
        app.prompt(sid, "Original")
    current = state(app, sid)
    human_id = current["user_message_id"]
    text = "Original"
    if change == "text":
        text = "Different"
    elif change == "new-human":
        app.store.add_message(sid, "user", {"content": "New question"})
    elif change == "other-session":
        sid = app.create_session()["id"]
    elif change == "delivered":
        app.store.commit_answer_review(sid, human_id, {"content": "Saved answer"})
    else:
        human_id = app.store.add_message(sid, "user", {"content": "Original", "synthetic": True})["id"]
    before = copy.deepcopy(app.store.messages(sid))
    calls = model(app, [])
    with pytest.raises(ValueError):
        app.prompt(sid, text, resume_user_message_id=human_id)
    assert not calls and before == app.store.messages(sid)


def test_stop_after_model_does_not_begin_or_deliver_review(case):
    _, app, sid = case

    def stop(kw):
        app.abort(sid)
        return Completion(text="UNVERIFIED", finish_reason='stop')

    calls = model(app, [stop])
    result = app.prompt(sid, "Investigate")
    assert result["status"] == "aborted" and "UNVERIFIED" not in result["text"]
    assert len(calls) == 1 and state(app, sid)["phase"] == "collecting"


@pytest.mark.parametrize("name", ["", "missing-skill", True])
def test_invalid_setting_fails_before_model(case, name):
    _, app, sid = case
    app.agents["build"].options["answer_review_skill"] = name
    calls = model(app, [])
    with pytest.raises(ValueError):
        app.prompt(sid, "Question")
    assert not calls


def test_skill_permission_denial_cannot_skip_review(case):
    _, app, sid = case
    from opencode.permission import Rule, PermissionDenied
    app.agents["build"].permission.append(Rule("skill", "investigate", "deny"))
    calls = model(app, [])
    with pytest.raises(PermissionDenied):
        app.prompt(sid, "Question")
    assert not calls


def test_old_answer_and_retraction_keep_authorship_and_originals(case):
    _, app, sid = case
    old = app.store.add_message(sid, "assistant", {"content": "Old unsupported cause"})
    correction = app.store.add_message(sid, "assistant", {"content": "Withdrawn: evidence only establishes endpoints"})
    app.store.export_work_history(sid)
    before = copy.deepcopy(app.store.messages(sid))
    shown = working_context(_present_history(before, app.store, sid), app.store, sid)
    for saved in (old, correction):
        item = next(m for m in shown if m.get("id") == saved["id"])
        assert item["role"] == "assistant" and item["content"] == saved["content"]
    assert app.store.messages(sid) == before


def test_commit_transaction_does_not_leave_partial_draft(case):
    _, app, sid = case
    human = app.store.add_message(sid, "user", {"content": "Question"})
    app.store.start_answer_review(sid, human["id"], "investigate", 4)
    app.store.reserve_answer_review_step(sid, human["id"])
    app.store._conn.execute("CREATE TRIGGER reject_notice BEFORE INSERT ON message "
                            "WHEN instr(NEW.data, 'check') > 0 BEGIN SELECT RAISE(ABORT, 'fail-notice'); END")
    with pytest.raises(Exception, match="fail-notice"):
        app.store.commit_answer_review(sid, human["id"], {"content": "draft"}, "notice")
    assert len(app.store.messages(sid)) == 1
    assert state(app, sid)["phase"] == "collecting" and state(app, sid)["draft_message_id"] is None


def test_web_marks_drafts_and_does_not_treat_notice_as_completion():
    from pathlib import Path
    import opencode
    html = (Path(opencode.__file__).parent / "web/index.html").read_text(encoding="utf-8")
    assert 'reviewLabels[message.answer_review_role]' in html
    assert '!["draft", "check"].includes(last.answer_review_role)' in html


@pytest.mark.parametrize("boundary", ["feedback", "present"])
def test_extension_failure_keeps_candidate_without_claiming_delivery(case, boundary):
    _, app, sid = case
    broken = False

    def feedback():
        if broken and boundary == "feedback":
            raise RuntimeError("source unavailable")

    def present(text, status):
        if broken and boundary == "present":
            raise RuntimeError("source unavailable")
        return text

    app.turn_extension_factory = lambda *args: SimpleNamespace(context=lambda: "", feedback=feedback, present=present)

    def candidate(_):
        nonlocal broken
        broken = True
        return Completion(text="CANDIDATE_RETAINED", finish_reason='stop')

    model(app, [Completion(text="INITIAL_DRAFT", finish_reason='stop'), candidate])
    with pytest.raises(RuntimeError, match="source unavailable"):
        app.prompt(sid, "Original question")
    saved = state(app, sid)
    assert saved["phase"] == "checking" and saved["steps_used"] == 2
    assert any(m.get("content") == "CANDIDATE_RETAINED" and m.get("answer_review_role") == "draft"
               for m in app.store.messages(sid))
    broken = False
    model(app, [Completion(text="FINAL", finish_reason='stop')])
    result = app.prompt(sid, "Original question", resume_user_message_id=saved["user_message_id"])
    assert result["text"] == "FINAL" and state(app, sid)["steps_used"] == 3
    assert len([m for m in app.store.messages(sid) if m.get("answer_review_role") == "check"]) == 1


def test_repeated_structural_gap_cannot_deliver_at_last_step(case):
    _, app, sid = case
    app.agents["build"].steps = 3
    gap = False
    app.turn_extension_factory = lambda *args: SimpleNamespace(
        context=lambda: "", feedback=lambda: "Unresolved delivery" if gap else None,
        present=lambda text, status: text)

    def unready(_):
        nonlocal gap
        gap = True
        return Completion(text="STILL_UNREADY", finish_reason='stop')

    calls = model(app, [Completion(text="Draft", finish_reason='stop'), unready, unready])
    result = app.prompt(sid, "Question")
    assert result["status"] == "step_limit" and "STILL_UNREADY" not in result["text"]
    assert len(calls) == 3 and state(app, sid)["phase"] == "checking"
    assert state(app, sid)["answer_message_id"] is None


def test_cli_displays_check_and_answer_without_draft(case, capsys):
    from opencode import cli
    _, app, sid = case
    model(app, [Completion(text="PRIVATE_DRAFT", finish_reason='stop'), Completion(text="FINAL_RESPONSE", finish_reason='stop')])
    cli._print_prompt(app, sid, "Question", SimpleNamespace(agent=None, model=None))
    output = capsys.readouterr().out
    assert "PRIVATE_DRAFT" not in output and "交付前核對" in output
    assert output.count("FINAL_RESPONSE") == 1


@pytest.mark.parametrize("boundary", ["feedback", "present"])
def test_abort_during_extension_does_not_commit_delivery(case, boundary):
    _, app, sid = case
    checking = False

    def feedback():
        if checking and boundary == "feedback":
            app.abort(sid)

    def present(text, status):
        if checking and boundary == "present" and status == "completed":
            app.abort(sid)
        return text

    app.turn_extension_factory = lambda *args: SimpleNamespace(context=lambda: "", feedback=feedback, present=present)

    def answer(_):
        nonlocal checking
        checking = True
        return Completion(text="STOPPED_CANDIDATE", finish_reason='stop')

    calls = model(app, [Completion(text="Draft", finish_reason='stop'), answer])
    result = app.prompt(sid, "Original")
    assert result["status"] == "aborted" and "STOPPED_CANDIDATE" not in result["text"]
    assert state(app, sid)["phase"] == "checking" and len(calls) == 2
    assert any(m.get("content") == "STOPPED_CANDIDATE" for m in app.store.messages(sid))


def test_unfinished_check_is_not_cloned_by_session_fork(case):
    # Existing fork operations copy messages, not control records; a new turn
    # must not claim that it delivered the original unfinished turn.
    _, app, sid = case
    model(app, [Completion(text="Draft", finish_reason='stop'), ProviderError("Disconnected")])
    with pytest.raises(ProviderError):
        app.prompt(sid, "Original")
    original = state(app, sid)
    other = app.create_session()["id"]
    for message in app.store.messages(sid):
        app.store.add_message(other, message["role"], {k: v for k, v in message.items()
                                                    if k not in {"id", "sessionID", "created"}})
    model(app, [])
    with pytest.raises(ValueError):
        app.prompt(other, "Original", resume_user_message_id=original["user_message_id"])
    assert state(app, sid)["phase"] == "checking"
