"""S20 cancellation reaches human waits and foreground jobs, without stopping the parent."""

import threading
import time
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.lsp import LspError
from opencode.permission import Broker, PermissionRejected
from opencode.provider import Completion, ProviderError
from opencode.store import Store
from opencode.tools.extra import _task


def wait_until(predicate):
    deadline = time.monotonic() + 3
    while not predicate():
        assert time.monotonic() < deadline, "Timed out waiting for the exercised boundary"
        threading.Event().wait(0.005)


def launch(call):
    outcome = {}

    def run():
        try:
            outcome["result"] = call()
        except BaseException as error:
            outcome["error"] = error

    thread = threading.Thread(target=run)
    thread.start()
    return thread, outcome


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    for name in ("XDG_DATA_HOME", "XDG_CONFIG_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME", "OPENCODE_TEST_HOME"):
        monkeypatch.setenv(name, str(tmp_path / name))
    app = App(tmp_path, store=Store(tmp_path / "session.db"), config={"model": "local/test"}, auto_approve=True)
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)

    def unexpected(**kwargs):
        raise AssertionError("Install a deterministic provider response for this boundary")

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="local", context=128000), "test"), complete=unexpected)
    yield app
    for session in app.store.list_sessions():
        app.abort(session["id"])
    wait_until(lambda: not app._background)
    app.store.close()


def test_permission_attempt_cancel_removes_only_that_wait_and_allows_next_attempt():
    session_abort, attempt = threading.Event(), threading.Event()
    broker = Broker()
    broker.abort_event = lambda _: session_abort
    arguments = dict(session_id="session", permission="bash", patterns=["git status"], ruleset=[])
    first, outcome = launch(lambda: broker.ask(**arguments, abort_event=attempt))
    try:
        wait_until(lambda: broker.list_pending())
        request = broker.list_pending()[0]
        assert set(request) == {"id", "sessionID", "permission", "patterns", "always", "metadata"}
        attempt.set()
        first.join(2)
        assert not first.is_alive()
        assert isinstance(outcome["error"], PermissionRejected)
        assert broker.list_pending() == []
        assert not session_abort.is_set()
        assert broker.reply(request["id"], "always") is False

        second, outcome2 = launch(lambda: broker.ask(**arguments, abort_event=threading.Event()))
        wait_until(lambda: broker.list_pending())
        broker.reply(broker.list_pending()[0]["id"], "once")
        second.join(2)
        assert not second.is_alive() and outcome2 == {"result": None}
    finally:
        attempt.set()
        broker.abort("session")
        first.join(2)


def test_cancelled_permission_callback_cannot_install_a_late_always_approval():
    entered, release, callback_done, attempt = (threading.Event() for _ in range(4))

    def callback(request):
        entered.set()
        try:
            assert release.wait(3)
            return "always"
        finally:
            callback_done.set()

    broker = Broker(callback=callback)
    arguments = dict(session_id="session", permission="bash", patterns=["git status"], ruleset=[], always=["git *"])
    thread, outcome = launch(lambda: broker.ask(**arguments, abort_event=attempt))
    try:
        assert entered.wait(2)
        attempt.set()
        thread.join(2)
        assert not thread.is_alive() and isinstance(outcome["error"], PermissionRejected)
        assert broker.list_pending() == []
        release.set()
        assert callback_done.wait(2)
        # The cancelled callback is not allowed to approve the next attempt.
        broker.callback = lambda _: "reject"
        with pytest.raises(PermissionRejected, match="user rejected"):
            broker.ask(**arguments, abort_event=threading.Event())
    finally:
        release.set()
        attempt.set()
        thread.join(2)


def test_question_attempt_cancel_cleans_pending_and_accepts_next_answer(runtime):
    sid = runtime.create_session()["id"]
    attempt = threading.Event()
    questions = [{"question": "Choose a path"}]
    thread, outcome = launch(lambda: runtime.ask_questions(sid, questions, abort_event=attempt))
    try:
        wait_until(lambda: runtime.pending_questions())
        first = runtime.pending_questions()[0]
        attempt.set()
        thread.join(2)
        assert not thread.is_alive()
        assert isinstance(outcome["error"], RuntimeError)
        assert runtime.pending_questions() == []
        assert not runtime.abort_event(sid).is_set()
        assert runtime.reply_question(first["id"], [["stale"]]) is False
        second, outcome2 = launch(lambda: runtime.ask_questions(sid, questions, abort_event=threading.Event()))
        wait_until(lambda: runtime.pending_questions())
        runtime.reply_question(runtime.pending_questions()[0]["id"], [["current"]])
        second.join(2)
        assert not second.is_alive() and outcome2 == {"result": [["current"]]}
    finally:
        attempt.set()
        thread.join(2)


def test_question_callback_wait_is_cancellable_and_late_answer_is_ignored(runtime):
    sid = runtime.create_session()["id"]
    entered, release, done, attempt = (threading.Event() for _ in range(4))

    def answer(questions):
        entered.set()
        try:
            assert release.wait(3)
            return [["stale"]]
        finally:
            done.set()

    runtime.question_callback = answer
    thread, outcome = launch(lambda: runtime.ask_questions(sid, [], abort_event=attempt))
    try:
        assert entered.wait(2)
        attempt.set()
        thread.join(2)
        assert not thread.is_alive() and isinstance(outcome["error"], RuntimeError)
        assert not runtime.abort_event(sid).is_set()
        release.set()
        assert done.wait(2)
        runtime.question_callback = lambda _: [["current"]]
        assert runtime.ask_questions(sid, [], abort_event=threading.Event()) == [["current"]]
    finally:
        release.set()
        attempt.set()
        thread.join(2)


@pytest.mark.parametrize("error", [RuntimeError("wait failed"), KeyboardInterrupt()])
def test_question_wait_exception_removes_pending_request(runtime, monkeypatch, error):
    sid = runtime.create_session()["id"]
    requests = []

    def publish(name, data):
        if name != "question.asked":
            return
        requests.append(data["id"])

        def fail_wait(timeout):
            raise error

        monkeypatch.setattr(runtime._questions[data["id"]]["event"], "wait", fail_wait)

    monkeypatch.setattr(runtime.bus, "publish", publish)
    with pytest.raises(type(error)):
        runtime.ask_questions(sid, [{"question": "Choose"}], abort_event=threading.Event())
    assert len(requests) == 1
    assert runtime.pending_questions() == []
    assert runtime.reply_question(requests[0], [["stale"]]) is False


def task_context(app, parent, abort):
    return ToolContext(app, parent, app.agents["build"], None, "call", 0, app.directory, app.worktree, set(), 0, abort=abort)


def test_foreground_child_stops_with_attempt_parent_and_retry_remain_usable(runtime):
    parent = runtime.create_session()["id"]
    entered, attempt = threading.Event(), threading.Event()
    calls = []

    def complete(**kwargs):
        calls.append(kwargs)
        if len(calls) == 1:
            entered.set()
            assert kwargs["abort_event"].wait(3)
            raise ProviderError("aborted")
        return Completion(text="retry child completed", finish_reason="stop")

    runtime.provider.complete = complete
    args = {"description": "Scoped child", "prompt": "First invocation", "subagent_type": "general"}
    thread, outcome = launch(lambda: _task(args, task_context(runtime, parent, attempt)))
    try:
        assert entered.wait(2)
        child, = runtime._background
        attempt.set()
        thread.join(2)
        assert not thread.is_alive() and isinstance(outcome["error"], ProviderError)
        wait_until(lambda: child not in runtime._background)
        assert runtime.abort_event(child).is_set()
        assert not runtime.abort_event(parent).is_set()
        assert child not in runtime._task_waiters and child not in runtime._task_parents
        result = _task({**args, "task_id": child, "prompt": "Retry invocation"},
                       task_context(runtime, parent, threading.Event()))
        assert "retry child completed" in result.output
        assert len(calls) == 2
        assert runtime.store.messages(parent) == []
    finally:
        attempt.set()
        runtime.abort(parent)
        thread.join(3)


@pytest.mark.parametrize("cancel_retry", [False, True])
def test_retry_same_child_waits_for_cancelled_runner_cleanup(runtime, cancel_retry):
    parent = runtime.create_session()["id"]
    entered, release, waiting, attempt = (threading.Event() for _ in range(4))
    calls = []

    class RetryAbort(threading.Event):
        def wait(self, timeout=None):
            waiting.set()
            return super().wait(timeout)

    retry_abort = RetryAbort()

    def complete(**kwargs):
        calls.append(kwargs)
        if len(calls) == 1:
            entered.set()
            assert kwargs["abort_event"].wait(3)
            # Keep the old child inside its execution scope after cancellation.
            assert release.wait(3)
            raise ProviderError("aborted")
        assert not kwargs["abort_event"].is_set()
        return Completion(text="new foreground result", finish_reason="stop")

    runtime.provider.complete = complete
    args = {"description": "Scoped child", "prompt": "First invocation", "subagent_type": "general"}
    first, first_outcome = launch(lambda: _task(args, task_context(runtime, parent, attempt)))
    second = None
    try:
        assert entered.wait(2)
        child, = runtime._background
        attempt.set()
        first.join(2)
        assert not first.is_alive() and isinstance(first_outcome["error"], ProviderError)
        assert runtime._background[child].is_set()
        second, second_outcome = launch(lambda: _task(
            {**args, "task_id": child, "prompt": "Retry invocation"},
            task_context(runtime, parent, retry_abort)))
        assert waiting.wait(2)
        assert second.is_alive()
        assert child in runtime._running
        assert runtime._background_inputs[child] == []
        assert len(calls) == 1
        if cancel_retry:
            retry_abort.set()
            second.join(2)
            assert not second.is_alive() and isinstance(second_outcome["error"], ProviderError)
        release.set()
        if not cancel_retry:
            second.join(2)
            assert not second.is_alive()
            assert "new foreground result" in second_outcome["result"].output
            assert 'state="completed"' in second_outcome["result"].output
            assert len(calls) == 2
            assert calls[0]["abort_event"] is not calls[1]["abort_event"]
        wait_until(lambda: child not in runtime._background)
        assert len(calls) == (1 if cancel_retry else 2)
        assert child not in runtime._running and child not in runtime._task_waiters
        assert not runtime.abort_event(parent).is_set()
        assert runtime.store.messages(parent) == []
        saved_users = [message["content"] for message in runtime.store.messages(child) if message["role"] == "user"]
        assert saved_users == (["First invocation"] if cancel_retry else ["First invocation", "Retry invocation"])
    finally:
        release.set()
        attempt.set()
        retry_abort.set()
        runtime.abort(parent)
        first.join(2)
        if second is not None:
            second.join(2)


def test_attempt_cancel_does_not_stop_a_detached_background_child(runtime):
    parent = runtime.create_session()["id"]
    attempt, entered, release = (threading.Event() for _ in range(3))
    observed = []
    # Keep the parent busy to inspect the queued notification without another turn.
    runtime._running.add(parent)

    def complete(**kwargs):
        observed.append(kwargs["abort_event"])
        entered.set()
        assert release.wait(3)
        return Completion(text="background completed", finish_reason="stop")

    runtime.provider.complete = complete
    args = {"description": "Detached child", "prompt": "Continue independently", "subagent_type": "general", "background": True}
    try:
        result = _task(args, task_context(runtime, parent, attempt))
        assert entered.wait(2)
        child = result.metadata["sessionID"]
        attempt.set()
        assert not observed[0].is_set()
        assert not runtime.abort_event(child).is_set()
        assert not runtime.abort_event(parent).is_set()
        release.set()
        wait_until(lambda: child not in runtime._background)
        messages = runtime.store.messages(parent)
        assert len(messages) == 1 and "background completed" in messages[0]["content"]
    finally:
        release.set()
        runtime._running.discard(parent)


def test_foreground_attempt_already_cancelled_does_not_start_child(runtime):
    parent = runtime.create_session()["id"]
    child = runtime.store.create_session(directory=str(runtime.directory), agent="general", model="local/test", parent_id=parent)["id"]
    attempt = threading.Event()
    attempt.set()
    with pytest.raises(ProviderError, match="cancelled"):
        runtime.run_prompt(child, "Do not dispatch", _parent_id=parent, _abort_event=attempt)
    assert child not in runtime._background and child not in runtime._task_waiters
    assert runtime.store.messages(child) == []
    assert not runtime.abort_event(parent).is_set()


def test_foreground_attempt_cancels_a_registered_job_before_its_thread_starts(runtime, monkeypatch):
    parent = runtime.create_session()["id"]
    attempt = threading.Event()
    delayed = []
    original_start = threading.Thread.start

    def start(thread):
        if thread.name == "opencode-background-task":
            delayed.append(thread)
            return
        return original_start(thread)

    monkeypatch.setattr(threading.Thread, "start", start)
    args = {"description": "Not yet running", "prompt": "Do not dispatch", "subagent_type": "general"}
    thread, outcome = launch(lambda: _task(args, task_context(runtime, parent, attempt)))
    try:
        wait_until(lambda: delayed)
        child, = runtime._background
        attempt.set()
        thread.join(2)
        assert not thread.is_alive() and isinstance(outcome["error"], ProviderError)
        assert runtime.store.messages(child) == []
        assert child not in runtime._task_waiters
        assert not runtime.abort_event(parent).is_set()
        original_start(delayed[0])
        delayed[0].join(2)
        assert not delayed[0].is_alive()
        assert child not in runtime._background and child not in runtime._task_parents
        assert runtime.store.messages(child) == []
    finally:
        attempt.set()
        runtime.abort(parent)
        thread.join(2)
        for worker in delayed:
            if worker.ident is None:
                original_start(worker)
            worker.join(2)


def test_lsp_client_creation_lock_wait_observes_attempt_abort(runtime, monkeypatch):
    monkeypatch.setattr("opencode.app.resolve_config", lambda *_: (["unused-server"], {}, {}))
    attempt = threading.Event()
    runtime._lsp_lock.acquire()
    thread, outcome = launch(lambda: runtime.lsp_operation("hover", runtime.directory / "file.py", 1, 1, None,
                                                          abort_event=attempt))
    try:
        attempt.set()
        thread.join(2)
        assert not thread.is_alive() and isinstance(outcome["error"], LspError)
        assert runtime._lsp == {}
    finally:
        runtime._lsp_lock.release()
        thread.join(2)
