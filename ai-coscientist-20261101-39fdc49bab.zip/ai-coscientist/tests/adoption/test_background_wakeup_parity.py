"""Deterministic background handoffs through the real loop, without a model service.

These cases exercise session ownership and saved notifications. They do not
claim that a real model interprets the child result correctly.
"""

import copy
from pathlib import Path
import threading
from collections import Counter
from types import SimpleNamespace

import pytest

import opencode.app as app_module
import opencode
from opencode.app import App
from opencode.provider import Completion, ProviderError, ToolCall
from opencode.store import Store
from tests.prompt_view import host_facts


TIMEOUT = 5


class BackgroundCase:
    def __init__(self, app, monkeypatch):
        self.app = app
        self.sid = app.create_session()["id"]
        self.events = []
        self.threads = []
        self.releases = []
        self.barriers = []
        self.failures = []
        self.calls = []
        self.runs = []
        self.active = Counter()
        self.maximum = Counter()
        self.condition = threading.Condition()
        self.after_loop = None
        real_thread = threading.Thread
        case = self

        class TrackedThread(real_thread):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                case.threads.append(self)

        monkeypatch.setattr(app_module.threading, "Thread", TrackedThread)
        real_publish = app.bus.publish

        def publish(kind, properties=None):
            real_publish(kind, properties)
            with self.condition:
                self.events.append((kind, dict(properties or {})))
                self.condition.notify_all()

        monkeypatch.setattr(app.bus, "publish", publish)
        real_loop = app_module.run_loop

        def tracked_loop(app, sid, text, **kwargs):
            with self.condition:
                self.runs.append((sid, text, dict(kwargs)))
                self.active[sid] += 1
                self.maximum[sid] = max(self.maximum[sid], self.active[sid])
            try:
                result = real_loop(app, sid, text, **kwargs)
                if self.after_loop:
                    self.after_loop(sid, kwargs, result)
                return result
            finally:
                with self.condition:
                    self.active[sid] -= 1
                    self.condition.notify_all()

        monkeypatch.setattr(app_module, "run_loop", tracked_loop)

    def event(self):
        event = threading.Event()
        self.releases.append(event)
        return event

    def barrier(self, parties):
        barrier = threading.Barrier(parties, timeout=TIMEOUT)
        self.barriers.append(barrier)
        return barrier

    @staticmethod
    def wait(event):
        assert event.wait(TIMEOUT), "Timed out at a controlled background boundary"

    def model(self, handler):
        counts = Counter()

        def complete(**kwargs):
            with self.app._execution_lock:
                sid = next(sid for sid, event in self.app._aborts.items()
                           if event is kwargs["abort_event"])
            with self.condition:
                number = counts[sid]
                counts[sid] += 1
                self.calls.append((sid, copy.deepcopy(kwargs["messages"]), kwargs["system"]))
            return handler(sid, number, kwargs)

        self.app.provider = SimpleNamespace(
            resolve=lambda _: (SimpleNamespace(id="test", context=200000), "test"),
            complete=complete,
        )

    def start_prompt(self, text):
        box = {}

        def run():
            try:
                box["result"] = self.app.prompt(self.sid, text)
            except BaseException as exc:
                box["error"] = exc
                self.failures.append(exc)

        thread = threading.Thread(target=run, name="test-parent-prompt")
        thread.start()
        return thread, box

    def spawn(self, text="Inspect the assigned input"):
        child = self.app.store.create_session(
            directory=str(self.app.directory), agent="general", title="Assigned child",
            model=self.app.session_model(self.sid), parent_id=self.sid,
        )["id"]
        self.app.spawn_background(child, text, "general", 1, self.sid)
        return child

    def wait_notifications(self, count=1, child=None):
        def received():
            return sum(kind == "task.completed" and props.get("sessionID") == self.sid
                       and (child is None or props.get("task") == child)
                       for kind, props in self.events) >= count

        with self.condition:
            assert self.condition.wait_for(received, TIMEOUT), "Missing saved child notification"

    def join(self):
        # A finishing child may create a continuation while it is being joined.
        index = 0
        while index < len(self.threads):
            thread = self.threads[index]
            index += 1
            if thread.ident is not None:
                thread.join(TIMEOUT)
                assert not thread.is_alive(), f"Thread did not finish: {thread.name}"
        assert not self.failures, repr(self.failures)

    def notifications(self):
        return [m for m in self.app.store.messages(self.sid)
                if m.get("synthetic") and m["role"] == "user"
                and m.get("content", "").startswith("<task_notification ")]

    def humans(self):
        return [m for m in self.app.store.messages(self.sid)
                if m["role"] == "user" and not m.get("synthetic")]

    def parent_inputs(self):
        return [messages for sid, messages, _ in self.calls if sid == self.sid]

    def parent_runs(self):
        return [kwargs for sid, _, kwargs in self.runs if sid == self.sid]


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    store = Store(tmp_path / "session.db")
    app = App(project, store=store, auto_approve=True, config={"steps": 8,
              "skills": {"paths": [str(Path(opencode.__file__).parent / "skill_assets")]}})
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)
    control = BackgroundCase(app, monkeypatch)
    try:
        yield control
    finally:
        for sid in list(app._running):
            app.abort(sid)
        for event in control.releases:
            event.set()
        for barrier in control.barriers:
            barrier.abort()
        try:
            control.join()
        finally:
            store.close()


def has_notification(messages, child):
    return sum(m.get("content", "").count(f'<task_notification id="{child}"') for m in messages)


def test_idle_child_completion_wakes_once_without_a_new_human(case):
    c, app = case, case.app
    c.model(lambda sid, number, _: Completion(text=("initial answer" if number == 0 else "child incorporated")
                                             if sid == c.sid else "child observation", finish_reason='stop'))
    assert app.prompt(c.sid, "Keep working when the child finishes")["status"] == "completed"
    original = c.humans()[0]["id"]
    child = c.spawn()
    c.wait_notifications(child=child)
    c.join()

    assert [m["id"] for m in c.humans()] == [original]
    assert len(c.notifications()) == 1
    assert len(c.parent_inputs()) == 2
    assert has_notification(c.parent_inputs()[0], child) == 0
    assert has_notification(c.parent_inputs()[1], child) == 1
    assert [run.get("_continue", False) for run in c.parent_runs()] == [False, True]
    assert c.maximum[c.sid] == 1 and not app._has_pending_notifications(c.sid)
    assert app.store.messages(c.sid)[-1]["content"] == "child incorporated"


def test_completion_during_busy_model_call_is_consumed_by_its_next_input(case):
    c, app = case, case.app
    entered, release = c.event(), c.event()

    def respond(sid, number, _):
        if sid != c.sid:
            return Completion(text="completed while parent was inferring", finish_reason='stop')
        if number == 0:
            entered.set()
            c.wait(release)
        return Completion(text="parent answer", finish_reason='stop')

    c.model(respond)
    _, box = c.start_prompt("Continue after child results")
    c.wait(entered)
    joined, second = c.start_prompt("A second human joins the active loop")
    for _ in range(500):
        if len(c.humans()) == 2:
            break
        threading.Event().wait(0.005)
    assert len(c.humans()) == 2
    assert joined.is_alive()
    child = c.spawn()
    c.wait_notifications(child=child)
    assert app._has_pending_notifications(c.sid)
    release.set()
    c.join()

    assert box["result"]["status"] == "completed"
    assert second["result"] == box["result"]
    assert len(c.parent_runs()) == 1 and c.maximum[c.sid] == 1
    assert [has_notification(messages, child) for messages in c.parent_inputs()] == [0, 1]
    assert len(c.humans()) == 2 and len(c.notifications()) == 1
    assert any(message.get("content") == "A second human joins the active loop" for message in c.parent_inputs()[-1])
    assert not app._has_pending_notifications(c.sid)


def test_notification_after_snapshot_is_not_acknowledged_by_the_older_input(case, monkeypatch):
    c, app = case, case.app
    captured, release = c.event(), c.event()
    real_snapshot = app._context_snapshot
    first = True

    def snapshot(sid):
        nonlocal first
        result = real_snapshot(sid)
        if sid == c.sid and first:
            first = False
            captured.set()
            c.wait(release)
        return result

    monkeypatch.setattr(app, "_context_snapshot", snapshot)
    c.model(lambda sid, number, _: Completion(text="parent result" if sid == c.sid else "late child", finish_reason='stop'))
    c.start_prompt("Observe a result published after the input snapshot")
    c.wait(captured)
    child = c.spawn()
    c.wait_notifications(child=child)
    release.set()
    c.join()

    assert [has_notification(messages, child) for messages in c.parent_inputs()] == [0, 1]
    assert len(c.parent_runs()) == 1 and c.maximum[c.sid] == 1
    assert not app._has_pending_notifications(c.sid)


def test_notification_between_task_call_and_result_keeps_a_paired_provider_exchange(case, monkeypatch):
    c, app = case, case.app
    real_spawn = app.spawn_background
    children = []

    def spawn(child, *args, **kwargs):
        children.append(child)
        real_spawn(child, *args, **kwargs)
        # Force publication before the task tool is allowed to return its result.
        c.wait_notifications(child=child)

    monkeypatch.setattr(app, "spawn_background", spawn)

    def respond(sid, number, _):
        if sid != c.sid:
            return Completion(text="child result between call and tool result", finish_reason='stop')
        if number == 0:
            return Completion(tool_calls=[ToolCall("background-call", "task", {
                "description": "Inspect independently", "prompt": "Inspect assigned input",
                "subagent_type": "general", "background": True,
            })], finish_reason='tool-calls')
        return Completion(text="paired result incorporated", finish_reason='stop')

    c.model(respond)
    assert app.prompt(c.sid, "Delegate this inspection")["status"] == "completed"
    c.join()
    child, = children
    saved = app.store.messages(c.sid)
    notification = c.notifications()[0]
    tool = next(m for m in saved if m["role"] == "tool" and m["tool_call_id"] == "background-call")
    assert saved.index(notification) < saved.index(tool)
    sent = c.parent_inputs()[1]
    call_at = next(i for i, m in enumerate(sent)
                   if any(call["id"] == "background-call" for call in m.get("tool_calls", [])))
    assert sent[call_at + 1]["role"] == "tool"
    assert sent[call_at + 1]["tool_call_id"] == "background-call"
    assert has_notification(sent[call_at + 2:call_at + 3], child) == 1
    assert len(c.parent_runs()) == 1 and c.maximum[c.sid] == 1
    assert not app._has_pending_notifications(c.sid)


def test_completion_after_last_loop_input_survives_the_busy_to_idle_handoff(case):
    c, app = case, case.app
    returned, release_parent, release_child = c.event(), c.event(), c.event()

    def after_loop(sid, kwargs, result):
        if sid == c.sid and not kwargs.get("_continue"):
            assert result["status"] == "completed"
            returned.set()
            c.wait(release_parent)

    def respond(sid, number, _):
        if sid != c.sid:
            c.wait(release_child)
            return Completion(text="published after the last input", finish_reason='stop')
        return Completion(text="initial" if number == 0 else "handoff notification incorporated", finish_reason='stop')

    c.after_loop = after_loop
    c.model(respond)
    _, box = c.start_prompt("Continue even at the idle boundary")
    c.wait(returned)
    child = c.spawn()
    release_child.set()
    c.wait_notifications(child=child)
    assert c.sid in app._running and len(c.parent_runs()) == 1
    release_parent.set()
    c.join()

    assert box["result"]["text"] == "handoff notification incorporated"
    assert [run.get("_continue", False) for run in c.parent_runs()] == [False, True]
    assert c.maximum[c.sid] == 1 and len(c.humans()) == len(c.notifications()) == 1
    assert has_notification(c.parent_inputs()[-1], child) == 1
    assert not app._has_pending_notifications(c.sid)


def test_simultaneous_children_publish_once_each_and_share_one_parent_owner(case, monkeypatch):
    c, app = case, case.app
    finish_together = c.barrier(3)

    def respond(sid, number, _):
        if sid != c.sid:
            finish_together.wait()
            return Completion(text=f"observation from {sid}", finish_reason='stop')
        return Completion(text="initial" if number == 0 else "both children incorporated", finish_reason='stop')

    c.model(respond)
    app.prompt(c.sid, "Collect two independent results")
    real_snapshot = app._context_snapshot

    def snapshot(sid):
        if sid == c.sid:
            c.wait_notifications(2)
        return real_snapshot(sid)

    monkeypatch.setattr(app, "_context_snapshot", snapshot)
    children = [c.spawn("First assigned input"), c.spawn("Second assigned input")]
    finish_together.wait()
    c.wait_notifications(2)
    c.join()

    assert len(c.notifications()) == 2
    assert all(has_notification(c.notifications(), child) == 1 for child in children)
    assert all(has_notification(c.parent_inputs()[-1], child) == 1 for child in children)
    assert len(c.parent_inputs()) == len(c.parent_runs()) == 2
    assert c.maximum[c.sid] == 1 and len(c.humans()) == 1
    assert not app._has_pending_notifications(c.sid)


@pytest.mark.parametrize("cancelled", [False, True], ids=["error-notifies", "abort-is-silent"])
def test_child_error_notifies_but_child_abort_does_not(case, cancelled):
    c, app = case, case.app

    def respond(sid, number, _):
        if sid == c.sid:
            return Completion(text="initial" if number == 0 else "child error acknowledged", finish_reason='stop')
        if cancelled:
            app.abort(sid)
        raise ProviderError("controlled child failure")

    c.model(respond)
    app.prompt(c.sid, "Report a real child error")
    child = c.spawn()
    c.join()

    assert len(c.notifications()) == (0 if cancelled else 1)
    assert len(c.parent_inputs()) == (1 if cancelled else 2)
    assert child not in app._background and not app._has_pending_notifications(c.sid)
    if not cancelled:
        notice, = c.notifications()
        assert 'state="error"' in notice["content"]
        assert "controlled child failure" in notice["content"]


def test_new_human_clearing_parent_abort_cannot_revive_an_old_child(case):
    c, app = case, case.app
    child_entered, release_child = c.event(), c.event()

    def respond(sid, number, _):
        if sid == c.sid:
            return Completion(text="parent reply", finish_reason='stop')
        child_entered.set()
        c.wait(release_child)
        # Deliberately ignore the provider's abort argument to reproduce a late
        # transport return after a fresh human prompt clears the parent's flag.
        return Completion(text="stale child completion", finish_reason='stop')

    c.model(respond)
    app.prompt(c.sid, "Original request")
    child = c.spawn()
    c.wait(child_entered)
    app.abort(c.sid)
    assert app.abort_event(child).is_set()
    assert app.prompt(c.sid, "New human request")["status"] == "completed"
    assert not app.abort_event(c.sid).is_set()
    release_child.set()
    c.join()

    assert app.abort_event(child).is_set()
    assert not c.notifications() and len(c.parent_runs()) == len(c.parent_inputs()) == 2
    assert [m["content"] for m in c.humans()] == ["Original request", "New human request"]
    assert not app._has_pending_notifications(c.sid)


def install_extension(case):
    calls = []

    class Extension:
        def __init__(self, sid, human_id):
            self.sid, self.human_id = sid, human_id

        def context(self):
            return f"Saved turn extension for human {self.human_id}"

        def feedback(self):
            return None

        def present(self, text, status):
            calls.append(("present", self.sid, self.human_id, text, status))
            return f"Presented: {text}"

    def factory(app, sid, human_id):
        calls.append(("create", sid, human_id))
        return Extension(sid, human_id)

    case.app.turn_extension_factory = factory
    return calls


def test_delivered_review_is_not_reopened_and_extension_keeps_the_original_human(case, monkeypatch):
    c, app = case, case.app
    app.agents["build"].options["answer_review_skill"] = "investigate"
    app.generate_titles = True
    title_calls = []
    monkeypatch.setattr("opencode.loop._title", lambda *args: title_calls.append(args[1]))
    extension_calls = install_extension(c)

    def respond(sid, number, _):
        if sid != c.sid:
            return Completion(text="child observation", finish_reason='stop')
        return Completion(text=["Initial draft", "Checked initial answer", "Ordinary background follow-up"][number], finish_reason='stop')

    c.model(respond)
    assert app.prompt(c.sid, "Original reviewed request")["text"] == "Presented: Checked initial answer"
    human, = c.humans()
    before = dict(app.store.answer_review(c.sid, human["id"]))
    child = c.spawn()
    c.wait_notifications(child=child)
    c.join()

    assert app.store.answer_review(c.sid, human["id"]) == before
    assert before["phase"] == "delivered" and before["steps_used"] == 2
    assert [entry[2] for entry in extension_calls if entry[:2] == ("create", c.sid)] == [human["id"], human["id"]]
    assert [entry[3] for entry in extension_calls if entry[:2] == ("present", c.sid)] == [
        "Checked initial answer", "Ordinary background follow-up"]
    assert title_calls == [c.sid] and len(c.humans()) == 1
    final = app.store.messages(c.sid)[-1]
    assert final["content"] == "Ordinary background follow-up" and not final.get("answer_review_role")
    assert f"Saved turn extension for human {human['id']}" in [
        host_facts({"messages": messages}) for sid, messages, _ in c.calls if sid == c.sid][-1]
    assert len([m for m in app.store.messages(c.sid) if m.get("answer_review_role") == "check"]) == 1


@pytest.mark.parametrize("phase", ["collecting", "checking"])
def test_background_continues_unfinished_review_with_the_same_remaining_budget(case, phase):
    c, app = case, case.app
    app.agents["build"].options["answer_review_skill"] = "investigate"
    app.agents["build"].steps = 4
    extension_calls = install_extension(c)
    failed_number = 0 if phase == "collecting" else 1

    def respond(sid, number, _):
        if sid != c.sid:
            return Completion(text="child evidence", finish_reason='stop')
        if number == failed_number:
            raise ProviderError("controlled interruption")
        return Completion(text="Draft pending review" if number < 2 else "Checked after child evidence", finish_reason='stop')

    c.model(respond)
    with pytest.raises(ProviderError, match="controlled interruption"):
        app.prompt(c.sid, "Keep the original review budget")
    human, = c.humans()
    before = dict(app.store.answer_review(c.sid, human["id"]))
    assert before["phase"] == phase and before["steps_used"] == failed_number + 1
    child = c.spawn()
    c.wait_notifications(child=child)
    c.join()

    after = app.store.answer_review(c.sid, human["id"])
    assert after["phase"] == "delivered" and after["step_limit"] == 4 and after["steps_used"] == 3
    if phase == "checking":
        assert after["notice_message_id"] == before["notice_message_id"]
        assert after["draft_message_id"] == before["draft_message_id"]
    assert len(c.humans()) == 1 and len(c.parent_runs()) == 2
    assert [entry[2] for entry in extension_calls if entry[:2] == ("create", c.sid)] == [human["id"], human["id"]]
    assert len([m for m in app.store.messages(c.sid) if m.get("answer_review_role") == "check"]) == 1
    assert app.store.messages(c.sid)[-1]["content"] == "Checked after child evidence"
    assert has_notification(c.parent_inputs()[-1], child) == 1
    assert not app._has_pending_notifications(c.sid)
