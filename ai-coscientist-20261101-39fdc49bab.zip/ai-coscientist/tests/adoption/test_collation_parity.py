"""Offline ICU boundaries and an optional pinned local Bun comparison.

Fixtures were checked against official Bun 1.3.14 Windows x64 baseline
(ICU 73.2, Unicode 15.0). Windows ICU 72.1.0.4 matched the exercised cases
with normalization enabled. This is not proof of equality across ICU releases.
No test downloads a runtime, installs a package, or calls a model/network.
"""

import ctypes
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest

from opencode import collation


_ZH_TW_CASES = [
    ("", "", 0),
    ("", "a", -1),
    ("a", "A", -1),
    ("a", "á", 1),
    ("ä", "z", -1),
    ("2", "10", 1),
    ("_a", "a", -1),
    ("阿", "八", 1),
    ("一", "丁", -1),
    ("吕", "呂", -1),
    ("😀", "😃", -1),
    ("é", "e\u0301", 0),
    ("\ud800", "a", 1),
    ("a\u0301\u0327", "a\u0327\u0301", 0),
    ("\u1e69", "s\u0307\u0323", 0),
]


@pytest.fixture(scope="module")
def collator():
    return collation._Collator("zh-TW")


@pytest.mark.parametrize("left,right,expected", _ZH_TW_CASES,
                         ids=["empty", "empty-first", "case", "accent", "latin", "numeric-off", "punctuation",
                              "han-stroke", "han-stroke-two", "han-variant", "emoji", "decomposed",
                              "lone-surrogate", "combining-order", "normalization-required"])
def test_native_icu_matches_offline_bun_fixtures(collator, left, right, expected):
    assert collator.compare(left, right) == expected
    assert collator.compare(right, left) == -expected


def test_locale_key_keeps_equal_names_in_original_order(collator, monkeypatch):
    monkeypatch.setattr(collation, "_default_collator", lambda: collator)
    records = [("é", 1), ("e\u0301", 2), ("a", 3), ("é", 4)]
    result = sorted(records, key=lambda entry: collation._locale_key(entry[0]))
    assert [index for _, index in result if index != 3] == [1, 2, 4]
    assert collation._locale_compare("\u1e69", "s\u0307\u0323") == 0


@pytest.mark.parametrize("platform,found,expected", [
    ("win32", None, ["icu.dll"]),
    ("darwin", None, ["/usr/lib/libicucore.A.dylib"]),
    ("linux", "libicui18n.so.73", ["libicui18n.so.73", "libicui18n.so"]),
    ("linux", None, ["libicui18n.so"]),
])
def test_standard_library_locations(monkeypatch, platform, found, expected):
    monkeypatch.setattr(collation.sys, "platform", platform)
    monkeypatch.setattr(collation.ctypes.util, "find_library", lambda _: found)
    assert collation._library_names() == expected


@pytest.mark.parametrize("name,suffix", [("libicui18n.so.73", "_73"), ("libicui18n.so", "_72"),
                                        ("/usr/lib/libicucore.A.dylib", "")])
def test_loader_finds_unversioned_or_renamed_c_api(monkeypatch, name, suffix):
    library = SimpleNamespace(**{function + suffix: object() for function in collation._FUNCTIONS})
    monkeypatch.setattr(collation.sys, "platform", "linux")
    monkeypatch.setattr(collation, "_library_names", lambda: [name])
    monkeypatch.setattr(collation.ctypes, "CDLL", lambda _: library)
    assert collation._load_icu() == (library, suffix)


def test_windows_loader_only_searches_system_directory(monkeypatch):
    library = SimpleNamespace(**{function: object() for function in collation._FUNCTIONS})
    calls = []
    monkeypatch.setattr(collation.sys, "platform", "win32")
    monkeypatch.setattr(collation, "_library_names", lambda: ["icu.dll"])
    monkeypatch.setattr(collation.ctypes, "CDLL", lambda name, **options: calls.append((name, options)) or library)
    assert collation._load_icu() == (library, "")
    assert calls == [("icu.dll", {"winmode": 0x00000800})]


@pytest.mark.parametrize("failure", ["missing-library", "missing-symbols"])
def test_missing_icu_is_an_explicit_dependency_error(monkeypatch, failure):
    monkeypatch.setattr(collation.sys, "platform", "linux")
    monkeypatch.setattr(collation, "_library_names", lambda: ["libicui18n.so"])

    def load(_):
        if failure == "missing-library":
            raise OSError("ICU is not installed")
        return SimpleNamespace()

    monkeypatch.setattr(collation.ctypes, "CDLL", load)
    with pytest.raises(RuntimeError, match="ICU collation is required but unavailable"):
        collation._Collator()


class _Function:
    def __init__(self, action):
        self.action = action

    def __call__(self, *args):
        return self.action(*args)


def _fake_library(monkeypatch, *, open_status=-128, attribute_status=0):
    calls = []

    def open_collator(locale, status):
        calls.append(("open", locale))
        ctypes.cast(status, ctypes.POINTER(ctypes.c_int32))[0] = open_status
        return 123

    def set_attribute(handle, attribute, value, status):
        calls.append(("attribute", handle, attribute, value))
        ctypes.cast(status, ctypes.POINTER(ctypes.c_int32))[0] = attribute_status

    def compare(handle, left, left_length, right, right_length):
        calls.append(("compare", handle, list(left)[:left_length], list(right)[:right_length]))
        return -1

    library = SimpleNamespace(ucol_open=_Function(open_collator), ucol_setAttribute=_Function(set_attribute),
                              ucol_strcoll=_Function(compare),
                              ucol_close=_Function(lambda handle: calls.append(("close", handle))))
    monkeypatch.setattr(collation, "_load_icu", lambda: (library, ""))
    return calls


def test_default_locale_normalization_utf16_and_cleanup(monkeypatch):
    calls = _fake_library(monkeypatch)
    instance = collation._Collator()
    assert calls == [("open", None), ("attribute", 123, 4, 17)]
    assert instance.compare("😀\ud800\0", "") == -1
    assert calls[-1] == ("compare", 123, [0xD83D, 0xDE00, 0xD800, 0], [])
    instance._finalizer()
    instance._finalizer()
    assert calls.count(("close", 123)) == 1


@pytest.mark.parametrize("where", ["open", "normalization"])
def test_icu_failure_closes_handle_without_a_sorting_fallback(monkeypatch, where):
    calls = _fake_library(monkeypatch, open_status=1 if where == "open" else -128,
                          attribute_status=1 if where == "normalization" else 0)
    with pytest.raises(RuntimeError, match="UErrorCode 1"):
        collation._Collator()
    assert calls.count(("close", 123)) == 1


def test_default_collator_against_explicitly_downloaded_bun_1_3_14():
    # This test uses only the exact optional probe previously downloaded by the
    # authorized source investigation. It never runs a PATH-selected runtime.
    executable = (Path(__file__).resolve().parents[2] / "tmp" / "bun-1.3.14-collation-probe" /
                  "bun-windows-x64-baseline" / "bun.exe")
    if not executable.is_file() or collation.sys.platform != "win32":
        pytest.skip("Pinned Bun 1.3.14 Windows probe is not present; no runtime is downloaded")
    pairs = [(left, right) for left, right, _ in _ZH_TW_CASES]
    # These newer emoji exposed an ICU 72 vs host Node/ICU 78 difference. They
    # match the actual pinned Bun/ICU 73 oracle, not that unrelated Node version.
    pairs.extend([("\U0001fae9", "\U0001fae8"), ("\U0001fae9", "😀"), ("\U0001faea", "😀")])
    script = ("const pairs=" + json.dumps(pairs, ensure_ascii=True) + ";console.log(JSON.stringify({"
              "bun:Bun.version,icu:process.versions.icu,unicode:process.versions.unicode,"
              "locale:new Intl.Collator().resolvedOptions().locale,"
              "results:pairs.map(([a,b])=>a.localeCompare(b))}));")
    oracle = json.loads(subprocess.check_output([str(executable), "-e", script], encoding="utf-8", timeout=20))
    assert (oracle["bun"], oracle["icu"], oracle["unicode"]) == ("1.3.14", "73.2", "15.0")
    assert [collation._locale_compare(left, right) for left, right in pairs] == oracle["results"]
