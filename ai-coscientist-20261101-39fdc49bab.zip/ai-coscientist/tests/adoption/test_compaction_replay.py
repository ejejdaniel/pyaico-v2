"""Offline checks for the saved-request replay; no tools or real models run."""

from copy import deepcopy
import json
from pathlib import Path
import runpy
import tempfile
import unittest

import httpx


REPLAY = runpy.run_path(str(Path(__file__).resolve().parents[2] / "scripts/replay_compaction_boundary.py"))


class CompactionReplay(unittest.TestCase):
    def requests(self):
        archived = [
            {"id": "u", "role": "user", "content": "Original request."},
            {"id": "a", "role": "assistant", "content": "", "reasoning_content": "PRIVATE",
             "tool_calls": [{"id": "r", "name": "read", "arguments": {"filePath": "original.log"}}]},
            {"id": "t", "role": "tool", "tool_call_id": "r", "content": "Exact observation."},
        ]
        compact = {
            "model": "recorded-model", "temperature": 0, "reasoning_effort": "medium", "max_tokens": 12000,
            "messages": [
                {"role": "system", "content": "Summarize."},
                {"role": "user", "content": "Original request."},
                {"role": "assistant", "content": "Old empty-body annotation", "reasoning": "", "tool_calls": [
                    {"id": "r", "type": "function", "function": {"name": "read", "arguments": '{"filePath": "original.log"}'}}]},
                {"role": "tool", "tool_call_id": "r", "content": "Receipt locator.\nExact observation."},
                {"role": "user", "content": "Old summary instructions."},
            ],
        }
        answer = {"model": "recorded-model", "reasoning_effort": "medium", "max_tokens": 12000,
                  "tools": [{"type": "function", "function": {"name": "read"}}], "messages": [
            {"role": "system", "content": "Ordinary agent instructions."},
            {"role": "assistant", "content": "<previous-summary>\nOld summary\n</previous-summary>", "reasoning": ""},
            {"role": "user", "content": "Original request."},
            {"role": "assistant", "content": "", "reasoning": "Original protocol reasoning", "tool_calls": [
                {"id": "r", "type": "function", "function": {"name": "read", "arguments": "{}"}}]},
            {"role": "tool", "tool_call_id": "r", "content": "Exact recent observation."},
        ]}
        return compact, answer, archived

    def test_two_requests_keep_evidence_controls_reasoning_and_never_execute_tools(self):
        compact, answer, archive = self.requests()
        before = deepcopy((compact, answer, archive))
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        self.assertEqual(prepared["messages"][2]["content"], "")
        self.assertEqual(prepared["messages"][3], compact["messages"][3])
        self.assertEqual(prepared["messages"][2]["reasoning"], "")
        self.assertNotIn("PRIVATE", json.dumps(prepared))
        for heading in ("## Objective", "## Important Details", "## Work State", "## Next Move", "## Relevant Files"):
            self.assertIn(heading, prepared["messages"][-1]["content"])
        self.assertNotIn("archive.json", prepared["messages"][-1]["content"])
        calls = []

        def respond(request):
            calls.append(json.loads(request.content))
            message = {"content": "New summary."} if len(calls) == 1 else {
                "content": "", "tool_calls": [{"id": "next", "function": {"name": "read", "arguments": "{}"}}]}
            return httpx.Response(200, json={"choices": [{"finish_reason": "stop", "message": message}],
                                             "usage": {"total_tokens": 20}})

        with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
            result = REPLAY["execute"](client, "http://model.invalid/v1", prepared, answer, "archive.json", directory)
            self.assertEqual(result["calls"], 2)
            self.assertEqual(result["tools_executed"], 0)
            self.assertFalse(result["has_text_answer"])
            self.assertEqual(len(result["returned_tool_calls"]), 1)
            self.assertEqual(len(calls), 2)
            followup = deepcopy(calls[1])
            self.assertIn("New summary.", followup["messages"][1]["content"])
            self.assertNotIn("Original messages (including tool arguments/results)", followup["messages"][1]["content"])
            followup["messages"][1]["content"] = answer["messages"][1]["content"]
            self.assertEqual(followup, answer)
        self.assertEqual((compact, answer, archive), before)

    def test_nonempty_wire_reasoning_and_generation_controls_are_preserved(self):
        compact, _, archive = self.requests()
        compact["messages"][2]["reasoning"] = "Actual recorded protocol"
        before = deepcopy(compact)
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        self.assertEqual(prepared["messages"][2]["reasoning"], "Actual recorded protocol")
        self.assertNotIn("PRIVATE", json.dumps(prepared))
        self.assertEqual({key: value for key, value in prepared.items() if key != "messages"},
                         {key: value for key, value in compact.items() if key != "messages"})
        self.assertEqual(compact, before)

    def test_large_tool_input_is_truncated_while_wire_reasoning_and_originals_stay_intact(self):
        compact, _, archive = self.requests()
        body = "Exact observation with original identifiers. " * 2000
        archive[-1]["content"] = body
        compact["messages"][3]["content"] = "Receipt locator.\n" + body
        compact["messages"][2]["reasoning"] = "Recorded reasoning"
        before = deepcopy((compact, archive))
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        result = prepared["messages"][3]["content"]
        source = compact["messages"][3]["content"]
        self.assertEqual(result, source[:2000] +
                         f"\n[Tool output truncated for compaction: omitted {len(source) - 2000} chars]")
        self.assertEqual(prepared["messages"][2]["reasoning"], "Recorded reasoning")
        self.assertEqual(prepared["messages"][1], compact["messages"][1])
        self.assertEqual((compact, archive), before)

    def test_length_compaction_preserves_plain_summary_and_sends_continuation(self):
        compact, answer, archive = self.requests()
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        calls = []

        def respond(request):
            calls.append(request)
            return httpx.Response(200, json={"choices": [{"finish_reason": "length", "message": {
                "content": "Partial", "reasoning_content": "summary reasoning"}}]})

        with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
            REPLAY["execute"](client, "http://model.invalid/v1", prepared, answer, "archive.json", directory)
            self.assertEqual(len(calls), 2)
            checkpoint = json.loads(calls[1].content)["messages"][1]
            self.assertEqual(checkpoint["content"], "Partial")
            self.assertEqual(checkpoint["reasoning"], "summary reasoning")
            self.assertTrue((Path(directory) / "compaction.response.bin").exists())
            self.assertTrue((Path(directory) / "continuation.request.json").exists())

    def test_transport_error_does_not_send_continuation(self):
        compact, answer, archive = self.requests()
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        calls = []

        def respond(request):
            calls.append(request)
            return httpx.Response(400, json={"error": {"message": "context_length_exceeded"}})

        with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
            with self.assertRaises(httpx.HTTPStatusError):
                REPLAY["execute"](client, "http://model.invalid/v1", prepared, answer, "archive.json", directory)
            self.assertEqual(len(calls), 1)
            self.assertFalse((Path(directory) / "continuation.request.json").exists())

    def test_summary_tool_call_does_not_send_continuation(self):
        compact, answer, archive = self.requests()
        prepared = REPLAY["prepare_request"](compact, archive, "archive.json")
        calls = []

        def respond(request):
            calls.append(request)
            return httpx.Response(200, json={"choices": [{"finish_reason": "tool_calls", "message": {
                "tool_calls": [{"id": "call", "function": {"name": "read", "arguments": "{}"}}]}}]})

        with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
            with self.assertRaisesRegex(ValueError, "Tool call not allowed while generating summary: read"):
                REPLAY["execute"](client, "http://model.invalid/v1", prepared, answer, "archive.json", directory)
            self.assertEqual(len(calls), 1)
            self.assertFalse((Path(directory) / "continuation.request.json").exists())

    def test_mismatched_archived_tool_is_rejected_before_replay(self):
        compact, _, archive = self.requests()
        archive[-1]["tool_call_id"] = "different"
        with self.assertRaises(AssertionError):
            REPLAY["prepare_request"](compact, archive, "archive.json")


if __name__ == "__main__":
    unittest.main()
