"""Source-defined loop and session handoffs; no live model calls."""
import copy
import threading
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.loop import _reminders
from opencode.permission import PermissionCorrected, PermissionRejected
from opencode.prompts import load
from opencode.provider import Completion, ProviderError, ToolCall
from opencode.store import Store
from opencode.tools.types import Tool, ToolResult


@pytest.fixture
def app(tmp_path, monkeypatch):
    for key in ("XDG_DATA_HOME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME", "OPENCODE_TEST_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    instance = App(project, store=Store(tmp_path / "session.db"), config={}, auto_approve=True)
    instance.generate_titles = False
    monkeypatch.setattr(instance, "ensure_mcp", lambda: None)
    yield instance
    for sid in list(instance._running):
        instance.abort(sid)
    instance.store.close()


def model(app, respond):
    calls = []
    def complete(**kwargs):
        calls.append(copy.deepcopy(kwargs["messages"]))
        return respond(len(calls), kwargs)
    app.provider = SimpleNamespace(resolve=lambda ref: (SimpleNamespace(id="test", context=128000), (ref or "test/model").split("/")[-1]), complete=complete)
    return calls


def noop(app, execute=None):
    app.extra_tools = [Tool("noop", "local test operation", {"type": "object", "properties": {}, "additionalProperties": False},
                           execute or (lambda args, ctx: ToolResult(output="observed")))]


def call():
    return Completion(tool_calls=[ToolCall("one", "noop", {})], finish_reason="tool-calls")


def test_saved_human_and_foreground_tool_output_are_not_rewritten(app):
    noop(app)
    calls = model(app, lambda n, _: call() if n == 1 else Completion(text="done", finish_reason="stop"))
    sid = app.create_session()["id"]
    app.prompt(sid, "exact human input")
    assert calls[0] == [{"role": "user", "content": "exact human input"}]
    assert calls[1][-1] == {"role": "tool", "tool_call_id": "one", "content": "observed"}
    assert app.store.messages(sid)[0]["content"] == "exact human input"


def test_default_loop_has_no_local_hundred_step_cutoff(app):
    # Each step's call differs: an identical call repeated after refusals now ends an
    # unattended turn (repeat_limit, a deliberate deviation); this test is about step count.
    app.extra_tools = [Tool("step", "local test operation",
                            {"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"],
                             "additionalProperties": False},
                            lambda args, ctx: ToolResult(output="observed"))]
    calls = model(app, lambda n, _: Completion(tool_calls=[ToolCall(f"c{n}", "step", {"n": n})],
                                               finish_reason="tool-calls")
                  if n <= 102 else Completion(text="done", finish_reason="stop"))
    sid = app.create_session()["id"]
    assert app.prompt(sid, "continue")["text"] == "done"
    assert len(calls) == 103


def test_agent_step_limit_is_source_prompt_and_keeps_tools_available(app):
    app.agents["build"].steps = 1
    noop(app)
    def respond(n, kwargs):
        assert kwargs["messages"][-1]["content"] == load("max-steps.txt")
        assert any(tool["name"] == "noop" for tool in kwargs["tools"])
        return call() if n == 1 else Completion(text="done", finish_reason="stop")
    calls = model(app, respond)
    assert app.prompt(app.create_session()["id"], "finish")["text"] == "done"
    assert len(calls) == 2


@pytest.mark.parametrize("reason", ["stop", "unknown"])
def test_truthy_terminal_finish_can_return_empty_text(app, reason):
    calls = model(app, lambda *_: Completion(finish_reason=reason))
    assert app.prompt(app.create_session()["id"], "request")["text"] == ""
    assert len(calls) == 1


def test_length_finish_is_not_a_completed_answer(app):
    # Deliberate deviation from the source (LIT v4): text cut off by the output
    # limit was delivered as the final answer. It now ends the turn as output_limit.
    calls = model(app, lambda *_: Completion(text="repeated paragraph", finish_reason="length"))
    result = app.prompt(app.create_session()["id"], "request")
    assert result["status"] == "output_limit" and "no completion is claimed" in result["text"]
    assert len(calls) == 1


def test_missing_finish_continues_and_does_not_deliver_partial_answer(app):
    calls = model(app, lambda n, _: Completion(text="partial") if n == 1 else Completion(text="done", finish_reason="stop"))
    assert app.prompt(app.create_session()["id"], "request")["text"] == "done"
    assert len(calls) == 2


def test_streaming_reasoning_and_text_are_saved_before_transport_finishes(app):
    sid = app.create_session()["id"]
    def respond(_, kwargs):
        kwargs["on_text"]("part")
        assert app.store.messages(sid)[-1]["content"] == "part"
        partial = Completion(text="partial", reasoning_content="reasoning", finish_reason=None)
        kwargs["on_update"](partial)
        saved = app.store.messages(sid)[-1]
        assert saved["reasoning_content"] == "reasoning"
        raise ProviderError("broken stream", partial)
    model(app, respond)
    with pytest.raises(ProviderError, match="broken stream"):
        app.prompt(sid, "request")
    saved = app.store.messages(sid)
    assert [m["role"] for m in saved] == ["user", "assistant"]
    assert saved[-1]["content"] == "partial" and saved[-1]["error"] == "broken stream"


@pytest.mark.parametrize("error,keep_going", [(PermissionRejected("no"), False), (PermissionCorrected("use another way"), True)])
@pytest.mark.parametrize("continue_on_deny", [False, True])
def test_rejection_and_correction_follow_processor_policy(app, error, keep_going, continue_on_deny):
    app.config["experimental"] = {"continue_loop_on_deny": continue_on_deny}
    def reject(*_):
        raise error
    noop(app, reject)
    calls = model(app, lambda n, _: call() if n == 1 else Completion(text="continued", finish_reason="stop"))
    app.prompt(app.create_session()["id"], "request")
    assert len(calls) == (2 if keep_going or continue_on_deny else 1)


def test_prompt_tools_persists_session_permission_and_changes_exposure(app):
    noop(app)
    def respond(_, kwargs):
        assert all(tool["name"] != "noop" for tool in kwargs["tools"])
        return Completion(text="done", finish_reason="stop")
    model(app, respond)
    sid = app.create_session()["id"]
    app.prompt(sid, "request", tools={"noop": False})
    app.prompt(sid, "again")
    assert app.store.get_session(sid)["permission"] == [{"permission": "noop", "pattern": "*", "action": "deny"}]


def test_reminders_use_any_prior_plan_and_leave_stored_human_unchanged(app):
    history = [{"role": "assistant", "agent": "plan", "content": "plan"},
               {"role": "assistant", "agent": "build", "content": "working"},
               {"role": "user", "content": "next"}]
    shown = _reminders(history, app.agents["build"])
    assert shown[-1]["content"] == "next\n\n" + load("build-switch.txt")
    assert history[-1]["content"] == "next"


def test_busy_prompt_joins_one_loop_and_both_callers_receive_latest_answer(app):
    entered, release = threading.Event(), threading.Event()
    results, errors = [], []
    def respond(n, _):
        if n == 1:
            entered.set()
            assert release.wait(3)
        return Completion(text=f"answer {n}", finish_reason="stop")
    calls = model(app, respond)
    sid = app.create_session()["id"]
    def request(text):
        try:
            results.append(app.prompt(sid, text))
        except BaseException as exc:
            errors.append(exc)
    first = threading.Thread(target=request, args=("first",))
    second = threading.Thread(target=request, args=("second",))
    first.start()
    try:
        assert entered.wait(3)
        second.start()
        for _ in range(300):
            if app._has_pending_notifications(sid):
                break
            threading.Event().wait(.01)
        assert app._has_pending_notifications(sid)
    finally:
        release.set()
        first.join(4)
        second.join(4)
    assert not first.is_alive() and not second.is_alive() and not errors
    assert [r["text"] for r in results] == ["answer 2", "answer 2"]
    assert len(calls) == 2
    assert [m["content"] for m in app.store.messages(sid) if m["role"] == "user"] == ["first", "second"]


def test_prompt_file_image_is_resolved_to_data_and_text_file_uses_read(app):
    image = app.directory / "image.png"
    image.write_bytes(b"\x89PNG\r\n\x1a\nimage")
    document = app.directory / "notes.txt"
    document.write_text("first\nsecond", encoding="utf-8")
    calls = model(app, lambda *_: Completion(text="done", finish_reason="stop"))
    app.prompt(app.create_session()["id"], "", parts=[
        {"type": "text", "text": "Inspect these"},
        {"type": "file", "mime": "image/png", "url": image.as_uri()},
        {"type": "file", "mime": "text/plain", "url": document.as_uri() + "?start=2&end=2"},
    ])
    parts = calls[0][0]["content"]
    assert parts[1]["image_url"]["url"].startswith("data:image/png;base64,")
    assert "2: second" in parts[0]["text"] and "1: first" not in parts[0]["text"]


def test_invalid_tool_repair_is_saved_and_returned_without_exposing_invalid(app):
    def respond(n, kwargs):
        assert "invalid" not in [tool["name"] for tool in kwargs["tools"]]
        if n == 1:
            return Completion(tool_calls=[ToolCall("wrong", "does_not_exist", {})], finish_reason="tool-calls")
        assert kwargs["messages"][-1]["role"] == "tool"
        assert "The arguments provided to the tool are invalid:" in kwargs["messages"][-1]["content"]
        return Completion(text="corrected", finish_reason="stop")
    model(app, respond)
    sid = app.create_session()["id"]
    assert app.prompt(sid, "request")["text"] == "corrected"
    saved = next(m for m in app.store.messages(sid) if m.get("tool_calls"))
    assert saved["tool_calls"][0]["name"] == "invalid"
    assert saved["tool_calls"][0]["arguments"]["tool"] == "does_not_exist"


def test_unattended_stop_with_open_todos_is_reminded_once_then_respected(app):
    sid = app.create_session()["id"]
    app.store.set_todos(sid, [{"content": "write the report", "status": "pending"},
                              {"content": "fetch data", "status": "completed"}])
    calls = model(app, lambda n, _: Completion(text=f"stopping {n}", finish_reason="stop"))
    result = app.prompt(sid, "do the work")
    assert result["status"] == "completed" and result["text"] == "stopping 2"
    assert len(calls) == 2
    reminder = calls[1][-1]["content"]
    assert "無人值守" in reminder and "1 項未完成" in reminder and "write the report" in reminder
    assert "fetch data" not in reminder


@pytest.mark.parametrize("auto, todos", [(True, [{"content": "x", "status": "completed"}]),
                                         (True, []),
                                         (False, [{"content": "x", "status": "pending"}])])
def test_no_reminder_when_todos_are_done_or_a_user_is_present(app, auto, todos):
    app.permissions.auto = auto
    sid = app.create_session()["id"]
    app.store.set_todos(sid, todos)
    calls = model(app, lambda n, _: Completion(text="done", finish_reason="stop"))
    app.prompt(sid, "do the work")
    assert len(calls) == 1


def test_each_unattended_stop_after_new_work_is_reminded_but_two_stops_in_a_row_end(app):
    noop(app)
    sid = app.create_session()["id"]
    app.store.set_todos(sid, [{"content": "write the report", "status": "pending"}])
    # stop -> reminder -> work -> stop -> reminder -> stop again: the turn ends.
    script = {1: "stop", 2: "work", 3: "stop", 4: "stop"}
    calls = model(app, lambda n, _: call() if script[n] == "work" else Completion(text=f"stop {n}", finish_reason="stop"))
    result = app.prompt(sid, "do the work")
    assert len(calls) == 4 and result["text"] == "stop 4"
    reminders = [m for m in app.store.messages(sid) if m.get("synthetic") and "無人值守" in (m.get("content") or "")]
    assert len(reminders) == 2


def probe(app, outputs):
    """A tool whose calls differ in arguments (like slightly edited scripts) but whose outputs are scripted."""
    seen = []

    def execute(args, ctx):
        seen.append(args["x"])
        return ToolResult(output=outputs(len(seen)))

    app.extra_tools = [Tool("probe", "local test calculation",
                            {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"],
                             "additionalProperties": False}, execute)]


def probe_call(n):
    return Completion(tool_calls=[ToolCall(f"call-{n}", "probe", {"x": n})], finish_reason="tool-calls")


REMINDER = "連續 3 次回傳完全相同的結果"


def test_same_tool_result_three_times_in_a_row_gets_one_reminder(app):
    probe(app, lambda n: "ranking: S096 first" if n <= 4 else "ranking: changed")
    calls = model(app, lambda n, _: probe_call(n) if n <= 5 else Completion(text="done", finish_reason="stop"))
    sid = app.create_session()["id"]
    app.prompt(sid, "rank the candidates")
    notices = [m for m in app.store.messages(sid) if m.get("synthetic") and REMINDER in (m.get("content") or "")]
    assert len(notices) == 1 and "probe" in notices[0]["content"]
    # The reminder reaches the model right after the third identical result, not before.
    assert any(REMINDER in str(m.get("content")) for m in calls[3])
    assert not any(REMINDER in str(m.get("content")) for m in calls[2])


def test_different_results_or_fewer_repeats_get_no_reminder(app):
    probe(app, lambda n: f"result {n % 2}")  # alternates, never three in a row
    model(app, lambda n, _: probe_call(n) if n <= 6 else Completion(text="done", finish_reason="stop"))
    sid = app.create_session()["id"]
    app.prompt(sid, "work")
    assert not any(REMINDER in (m.get("content") or "") for m in app.store.messages(sid))


class _Delivery:
    """A turn extension that only reports the state of a selected delivery."""

    def __init__(self, state):
        self.state = state

    def context(self):
        return ""

    def feedback(self):
        return None

    def present(self, text, status):
        return text

    def delivery_state(self):
        return self.state


def test_a_clean_delivery_ends_the_turn_without_a_todo_reminder(app):
    # v42 spent six minutes after a clean delivery rewriting its stale todo list and repeating its answer.
    sid = app.create_session()["id"]
    app.store.set_todos(sid, [{"content": "re-render the report", "status": "pending"}])
    app.turn_extension_factory = lambda *_: _Delivery("clean")
    calls = model(app, lambda n, _: Completion(text=f"stopping {n}", finish_reason="stop"))
    app.prompt(sid, "do the work")
    assert len(calls) == 1 and not any("待辦清單" in str(m.get("content")) for m in calls[0])


def test_an_undelivered_stop_with_open_todos_is_reminded_once(app):
    sid = app.create_session()["id"]
    app.store.set_todos(sid, [{"content": "re-render the report", "status": "pending"}])
    app.turn_extension_factory = lambda *_: _Delivery(None)
    calls = model(app, lambda n, _: Completion(text=f"stopping {n}", finish_reason="stop"))
    app.prompt(sid, "do the work")
    reminder = next(m["content"] for m in calls[1] if "宿主" in str(m.get("content")))
    assert "待辦清單仍有 1 項未完成" in reminder and "re-render the report" in reminder and len(calls) == 2


def test_a_delivery_with_gaps_goes_to_the_delivery_check_not_the_todo_reminder(app):
    sid = app.create_session()["id"]
    app.store.set_todos(sid, [{"content": "re-render the report", "status": "pending"}])
    app.turn_extension_factory = lambda *_: _Delivery("issues")
    calls = model(app, lambda n, _: Completion(text=f"stopping {n}", finish_reason="stop"))
    app.prompt(sid, "do the work")
    assert not any("待辦清單" in str(m.get("content")) for call in calls for m in call)


def test_network_queries_stop_at_the_task_cap_with_a_notice_to_answer(app, monkeypatch):
    # A TUI search fetched 33 search-engine pages without an answer; network calls are capped per task.
    from opencode import loop
    monkeypatch.setattr(loop, "NETWORK_TOOLS", {"probe"})
    app.config["network"] = {"max_queries": 2}
    probe(app, lambda n: f"page {n}")
    calls = model(app, lambda n, _: probe_call(n) if n <= 3 else Completion(text="answer", finish_reason="stop"))
    sid = app.create_session()["id"]
    assert app.prompt(sid, "find it")["text"] == "answer"
    results = [m["content"] for m in app.store.messages(sid) if m.get("role") == "tool"]
    assert "[本任務聯網查詢已用 1/2 次]" in results[0]
    assert "已用完，請依目前結果作答" in results[1]
    assert "已達本任務的聯網查詢上限（2 次），這次查詢沒有執行" in results[2] and len(calls) == 4


def test_an_empty_stop_after_tool_work_is_asked_once_for_the_answer(app):
    # The same search ended on an empty reply after a repeat notice, and the person got nothing.
    probe(app, lambda n: "found")
    script = {1: probe_call(1), 2: Completion(text="", finish_reason="stop"), 3: Completion(text="answer", finish_reason="stop")}
    calls = model(app, lambda n, _: script[n])
    sid = app.create_session()["id"]
    assert app.prompt(sid, "find it")["text"] == "answer" and len(calls) == 3
    assert any(m.get("synthetic") and "你停了下來但沒有給出任何回答" in (m.get("content") or "")
               for m in app.store.messages(sid))
