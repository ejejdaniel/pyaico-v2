"""Source util/media.ts signatures and tool/read.ts complete attachments."""

import base64

import pytest

from opencode.media import attachment_from_bytes, sniff_mime


@pytest.mark.parametrize(("raw", "expected"), [
    (b"GIF8", "image/gif"),
    (b"%PDF-1.7", "application/pdf"),
    (b"%PDF", "application/octet-stream"),
    (b"RIFF1234WEBP", "image/webp"),
    (b"RIFF1234WEB", "application/octet-stream"),
])
def test_media_sniff_matches_source_prefixes(raw, expected):
    assert sniff_mime(raw) == expected


def test_read_sized_attachment_is_not_silently_dropped_at_local_twenty_mb_limit():
    raw = b"%PDF-1.7\n" + b"x" * (20 * 1024 * 1024)
    attachment = attachment_from_bytes(raw, "application/pdf", filename="source.pdf")
    assert attachment["mime"] == "application/pdf"
    assert attachment["filename"] == "source.pdf"
    assert base64.b64decode(attachment["url"].split(",", 1)[1]) == raw
