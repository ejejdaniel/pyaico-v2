"""Provider/compaction boundaries from OpenCode v1.18.9; no model/network calls.

Sources: session/{processor,compaction,message-v2}.ts, provider/transform.ts,
and the source-pinned @ai-sdk/openai-compatible 2.0.41 chat converter.
"""

from copy import deepcopy
import json
import threading
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import httpx

from opencode.compaction import compact, usable_budget, usage_overflow
from opencode.provider import (Client, Completion, ProviderError, ToolCall, _anthropic_messages, _parse_args,
                               _retry_delay, openai_messages_from_history, repair_tool_calls, tool_call_error)
from opencode.store import Store


def client_for(api="openai", *, interleaved=None, options=None, limits=None):
    definition = {"options": options or {}, "limit": limits or {"context": 64000, "output": 8000}}
    if interleaved is not None:
        definition["interleaved"] = interleaved
    client = Client(SimpleNamespace(get=lambda _: "test-token"), {"provider": {"test": {
        "api": api, "options": {"baseURL": "https://invalid.example/v1"}, "models": {"model": definition},
    }}})
    provider, model = client.resolve("test/model")
    return client, provider, model


def response(data):
    return SimpleNamespace(status_code=200, json=lambda: data)


@pytest.mark.parametrize("finish,expected", [
    ("stop", "stop"), ("length", "length"), ("max_tokens", "unknown"),
    ("content_filter", "content-filter"), (None, "unknown"),
])
def test_empty_or_length_response_is_not_retried_with_lower_effort(finish, expected):
    client, provider, model = client_for(options={"reasoningEffort": "high", "empty_output_retry_effort": "none"})
    wire = {"choices": [{"finish_reason": finish, "message": {"content": "", "reasoning_content": "working"}}]}
    with patch("opencode.provider._post", return_value=response(wire)) as send:
        completion = client.complete(provider=provider, model=model, system="", messages=[])
    assert send.call_count == 1
    assert send.call_args.args[2]["reasoning_effort"] == "high"
    assert completion.finish_reason == expected
    assert completion.reasoning_content == "working"


@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize("options,expected", [
    ({}, None),
    ({"reasoning_effort": "high"}, None),
    ({"reasoningEffort": "medium"}, "medium"),
    ({"reasoning_effort": "high", "reasoningEffort": "low"}, "low"),
    ({"reasoningEffort": "provider-specific"}, "provider-specific"),
    ({"reasoningEffort": ""}, ""),
])
def test_reasoning_effort_matches_pinned_sdk_serialized_request(streaming, options, expected):
    options = {**options, "top_p": 0.9}
    before = deepcopy(options)
    client, provider, model = client_for(options=options)
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        if streaming:
            event = {"choices": [{"delta": {"content": "answer"}, "finish_reason": "stop"}]}
            return httpx.Response(200, text="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n",
                                  headers={"Content-Type": "text/event-stream"})
        return httpx.Response(200, json={"choices": [
            {"message": {"content": "answer"}, "finish_reason": "stop"},
        ]})

    http_client = httpx.Client(transport=httpx.MockTransport(receive))
    with patch("opencode.provider.httpx.Client", return_value=http_client):
        completion = client.complete(provider=provider, model=model, system="", messages=[],
                                     on_text=(lambda _: None) if streaming else None)
    assert completion.text == "answer"
    assert len(sent) == 1
    if expected is None:
        assert "reasoning_effort" not in sent[0]
    else:
        assert sent[0]["reasoning_effort"] == expected
    assert "reasoningEffort" not in sent[0]
    assert sent[0]["top_p"] == 0.9
    assert options == before


@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize("effort", [None, False, 1, [], {}])
def test_nonstring_reasoning_effort_fails_before_transport(streaming, effort):
    client, provider, model = client_for(options={"reasoningEffort": effort, "reasoning_effort": "high"})
    with patch("opencode.provider._post") as post, patch("opencode.provider._stream") as stream:
        with pytest.raises(ProviderError, match="reasoningEffort must be a string"):
            client.complete(provider=provider, model=model, system="", messages=[],
                            on_text=(lambda _: None) if streaming else None)
    post.assert_not_called()
    stream.assert_not_called()


@pytest.mark.parametrize("interleaved,field,empty", [
    (None, "reasoning_content", False), (False, "reasoning_content", False),
    ({"field": "reasoning_content"}, "reasoning_content", True),
    ({"field": "reasoning"}, "reasoning", True),
])
def test_pinned_sdk_interleaved_wire_field_and_unconfigured_reasoning(interleaved, field, empty):
    client, provider, model = client_for(interleaved=interleaved)
    messages = [{"role": "assistant", "content": "answer", "reasoning_content": "reason"},
                {"role": "assistant", "content": "next"}]
    before = deepcopy(messages)
    with patch("opencode.provider._post", return_value=response({"choices": [{"finish_reason": "stop", "message": {}}]})) as send:
        client.complete(provider=provider, model=model, system="", messages=messages)
    body = send.call_args.args[2]
    assert body["messages"][0][field] == "reason"
    assert (field in body["messages"][1]) is empty
    assert messages == before


def test_message_projection_converts_only_different_model_reasoning_to_text():
    stored = [{"role": "assistant", "model": "test/model", "content": "answer", "reasoning_content": "reason"}]
    assert openai_messages_from_history(stored, model_ref="test/model")[0]["reasoning_content"] == "reason"
    different = openai_messages_from_history(stored, model_ref="other/model")[0]
    assert different == {"role": "assistant", "content": "reason\n\nanswer"}
    assert stored[0]["reasoning_content"] == "reason"


def test_provider_sanitizes_lone_surrogates_without_mutating_saved_text():
    client, provider, model = client_for()
    messages = [{"role": "assistant", "content": "a\ud800b", "reasoning_content": "c\udfff"}]
    with patch("opencode.provider._post", return_value=response({"choices": [{"finish_reason": "stop", "message": {}}]})) as send:
        client.complete(provider=provider, model=model, system="s\ud800", messages=messages)
    assert send.call_args.args[2]["messages"] == [
        {"role": "system", "content": "s�"},
        {"role": "assistant", "content": "a�b", "reasoning_content": "c�"},
    ]
    assert messages[0]["content"] == "a\ud800b"


def test_provider_output_cap_and_zero_context_match_upstream():
    for limit, expected in [(0, 32000), (100000, 32000), (1234, 1234)]:
        client, provider, model = client_for(limits={"context": 0, "output": limit})
        assert client.output_limit(provider, model) == expected
        app = SimpleNamespace(config={}, provider=client)
        assert usable_budget(app, provider, model) == 0
        assert usage_overflow(app, "unused", provider, model) is False


def test_anthropic_reasoning_is_preserved_and_empty_history_is_filtered():
    client, provider, model = client_for(api="anthropic")
    data = {"content": [{"type": "thinking", "thinking": "reason"}, {"type": "text", "text": "answer"}],
            "stop_reason": "max_tokens", "usage": {"input_tokens": 2, "output_tokens": 4}}
    with patch("opencode.provider._post", return_value=response(data)):
        result = client.complete(provider=provider, model=model, system="", messages=[])
    assert result.reasoning_content == "reason"
    assert result.finish_reason == "length"
    assert _anthropic_messages([{"role": "assistant", "content": ""},
                                {"role": "user", "content": [{"type": "text", "text": ""}]}]) == []


def stream_events(events, *, failure=None):
    def stream(url, headers, body, timeout, consume, abort_event):
        for event in events:
            consume("data: " + json.dumps(event))
        if failure:
            raise failure
    return stream


def test_stream_reasoning_and_tool_progress_notify_existing_completion_fields():
    client, provider, model = client_for()
    updates = []
    events = [
        {"choices": [{"delta": {"reasoning_content": "reason"}}]},
        {"choices": [{"delta": {"tool_calls": [
            {"index": 0, "id": "call", "function": {"name": "read", "arguments": '{"filePath":'}}]}}]},
        {"choices": [{"delta": {"tool_calls": [
            {"index": 0, "function": {"arguments": '"x"}'}}]}, "finish_reason": "tool_calls"}]},
        {"choices": [], "usage": {"total_tokens": 14}},
    ]
    with patch("opencode.provider._stream", side_effect=stream_events(events)) as send:
        result = client.complete(provider=provider, model=model, system="", messages=[], on_update=updates.append)
    assert updates[0].reasoning_content == "reason"
    assert updates[1].tool_calls[0].arguments == {"_raw": '{"filePath":'}
    assert result.tool_calls[0].arguments == {"filePath": "x"}
    assert updates[-1].usage == {"total_tokens": 14}
    assert all(update.finish_reason is None for update in updates[:-1])
    assert updates[-1].finish_reason == "tool-calls"
    assert send.call_args.args[2]["stream_options"] == {"include_usage": True}


def test_stream_error_keeps_accumulated_reasoning_and_text():
    client, provider, model = client_for()
    events = [{"choices": [{"delta": {"reasoning_content": "reason", "content": "partial"}}]}]
    with patch("opencode.provider._stream", side_effect=stream_events(events, failure=ProviderError("broken"))):
        with pytest.raises(ProviderError) as failed:
            client.complete(provider=provider, model=model, system="", messages=[], on_text=lambda _: None)
    assert failed.value.partial.text == "partial"
    assert failed.value.partial.reasoning_content == "reason"


def test_raw_finish_before_failed_flush_does_not_mark_assistant_complete():
    client, provider, model = client_for()
    updates = []
    events = [{"choices": [{"delta": {"content": "partial"}, "finish_reason": "stop"}]}]
    with patch("opencode.provider._stream", side_effect=stream_events(events, failure=ProviderError("broken"))):
        with pytest.raises(ProviderError) as failed:
            client.complete(provider=provider, model=model, system="", messages=[], on_update=updates.append)
    assert failed.value.partial.finish_reason is None
    assert updates[0].finish_reason is None


def test_abort_after_completed_response_preserves_received_finish():
    client, provider, model = client_for()
    abort = threading.Event()

    def completed(*args, **kwargs):
        abort.set()
        return Completion(text="completed", finish_reason="stop")

    with patch.object(client, "_openai", side_effect=completed):
        with pytest.raises(ProviderError, match="aborted") as failed:
            client.complete(provider=provider, model=model, system="", messages=[], abort_event=abort)
    assert failed.value.partial.finish_reason == "stop"


def test_provider_retries_transient_failures_beyond_local_three_attempt_limit():
    client, provider, model = client_for()
    final = Completion(text="answer", finish_reason="stop")
    with patch.object(client, "_openai", side_effect=[ProviderError("test 503: unavailable")] * 3 + [final]) as run:
        with patch("opencode.provider.time.sleep") as sleep:
            result = client.complete(provider=provider, model=model, system="", messages=[])
    assert run.call_count == 4
    assert [call.args[0] for call in sleep.call_args_list] == [2, 4, 8]
    assert result is final
    assert _retry_delay(ProviderError("cannot generate result"), 1) is None
    assert _retry_delay(ProviderError("test 500: context_length_exceeded"), 1) is None


def test_retry_after_transport_headers_survive_without_new_error_fields():
    import httpx
    client, provider, model = client_for()
    retry = httpx.Response(429, headers={"retry-after-ms": "123"}, text="too many requests")
    final = response({"choices": [{"finish_reason": "stop", "message": {"content": "answer"}}]})
    with patch("opencode.provider._post", side_effect=[retry, final]), patch("opencode.provider.time.sleep") as sleep:
        result = client.complete(provider=provider, model=model, system="", messages=[])
    assert result.text == "answer"
    sleep.assert_called_once_with(0.123)


def test_source_network_retry_and_openai_404_exception():
    import httpx
    client, provider, model = client_for()
    final = response({"choices": [{"finish_reason": "stop", "message": {"content": "answer"}}]})
    with patch("opencode.provider._post", side_effect=[httpx.ConnectError("Connection refused"), final]) as send:
        with patch("opencode.provider.time.sleep") as sleep:
            result = client.complete(provider=provider, model=model, system="", messages=[])
    assert result.text == "answer" and send.call_count == 2
    sleep.assert_called_once_with(2)
    assert _retry_delay(ProviderError("openai 404: missing"), 1, "openai") == 2
    assert _retry_delay(ProviderError("custom 404: missing"), 1, "custom") is None


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_nonstream_malformed_json_has_a_normal_provider_error(api):
    import httpx
    client, provider, model = client_for(api=api)
    with patch("opencode.provider._post", return_value=httpx.Response(200, text="malformed")) as send:
        with pytest.raises(ProviderError, match="Invalid JSON"):
            client.complete(provider=provider, model=model, system="", messages=[])
    assert send.call_count == 1


def test_unlimited_source_retry_stops_on_abort_without_another_request():
    client, provider, model = client_for()
    abort = threading.Event()

    def cancel(delay):
        assert delay == 2
        abort.set()
        return True

    with patch.object(client, "_openai", side_effect=ProviderError("test 503: unavailable")) as request:
        with patch.object(abort, "wait", side_effect=cancel):
            with pytest.raises(ProviderError, match="aborted"):
                client.complete(provider=provider, model=model, system="", messages=[], abort_event=abort)
    assert request.call_count == 1


def test_no_wire_finish_does_not_invent_an_incomplete_response_error():
    client, provider, model = client_for()
    with patch("opencode.provider._stream", side_effect=stream_events([
        {"choices": [{"delta": {"content": "partial"}}]},
    ])):
        result = client.complete(provider=provider, model=model, system="", messages=[], on_text=lambda _: None)
    assert result.finish_reason == "unknown"


@pytest.mark.parametrize("events,pattern", [
    ([{"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"name": "read"}}]}}]}], "missing id"),
    ([{"error": {"message": "provider rejected request"}}], "provider rejected"),
])
def test_invalid_tool_or_stream_data_never_becomes_an_executable_call(events, pattern):
    client, provider, model = client_for()
    with patch("opencode.provider._stream", side_effect=stream_events(events)):
        with pytest.raises(ProviderError, match=pattern) as failed:
            client.complete(provider=provider, model=model, system="", messages=[], on_text=lambda _: None)
    assert failed.value.partial is not None
    if failed.value.partial.tool_calls:
        assert failed.value.partial.tool_calls[0].arguments == {"_raw": '{"unfinished":'}


@pytest.mark.parametrize("name,raw,expected", [
    ("READ", '{"filePath":"x"}', "read"),
    ("unknown", "{}", "invalid"),
    ("read", '{"unfinished":', "invalid"),
    ("read", '{"filePath":3}', "invalid"),
])
def test_source_tool_repair_handles_case_name_json_and_schema(name, raw, expected):
    client, provider, model = client_for()
    events = [{"choices": [{"delta": {"tool_calls": [{"index": 0, "id": "call", "function": {
        "name": name, "arguments": raw}}]}, "finish_reason": "tool_calls"}]}]
    with patch("opencode.provider._stream", side_effect=stream_events(events)):
        result = client.complete(provider=provider, model=model, system="", messages=[], on_text=lambda _: None)
    tools = [{"name": "read", "parameters": {"type": "object", "properties": {"filePath": {"type": "string"}},
                                              "required": ["filePath"]}}]
    repaired = repair_tool_calls(result, tools)
    call, = repaired.tool_calls
    assert call.name == expected and call.id == "call"
    if expected == "invalid":
        assert set(call.arguments) == {"tool", "error"}
        assert call.arguments["tool"] == name and call.arguments["error"]
    else:
        assert call.arguments == {"filePath": "x"}


def test_tool_repair_does_not_misclassify_raw_named_fields_or_empty_input():
    tools = [{"name": "read", "parameters": {"type": "object"}}]
    for raw in ('{"_raw":"valid field"}', '  '):
        original = Completion(tool_calls=[ToolCall("call", "read", _parse_args(raw, strict=True))])
        repaired = repair_tool_calls(original, tools)
        assert repaired.tool_calls[0].name == "read"
        assert tool_call_error(repaired.tool_calls[0]) is None


def test_failed_lowercase_repair_does_not_run_a_second_invalid_tool_repair():
    original = Completion(tool_calls=[ToolCall("call", "READ", _parse_args('{"unfinished":', strict=True))])
    repaired = repair_tool_calls(original, [{"name": "read", "parameters": {"type": "object"}}])
    call, = repaired.tool_calls
    assert call.name == "READ"
    assert "not valid JSON" in tool_call_error(call)
    assert json.loads(json.dumps(call.arguments)) == {"_raw": '{"unfinished":'}


def test_repeated_tool_name_and_finished_delta_follow_pinned_sdk():
    client, provider, model = client_for()
    events = [{"choices": [{"delta": {"tool_calls": [
        {"index": 0, "id": "call", "function": {"name": "read", "arguments": '{"filePath":'}}]}}]},
        {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"name": "read", "arguments": '"x"}'}}]}}]},
        {"choices": [{"delta": {"tool_calls": [{"index": 0, "function": {"arguments": "ignored"}}]}, "finish_reason": "tool_calls"}]}]
    with patch("opencode.provider._stream", side_effect=stream_events(events)):
        result = client.complete(provider=provider, model=model, system="", messages=[], on_text=lambda _: None)
    assert result.tool_calls[0].name == "read"
    assert result.tool_calls[0].arguments == {"filePath": "x"}


def test_missing_completion_message_is_not_a_valid_empty_answer():
    client, provider, model = client_for()
    with patch("opencode.provider._post", return_value=response({"choices": []})):
        with pytest.raises(ProviderError, match="missing a completion message"):
            client.complete(provider=provider, model=model, system="", messages=[])


@pytest.fixture
def summary_case(tmp_path):
    store = Store(tmp_path / "session.db")
    session = store.create_session(directory=str(tmp_path), agent="build", model="test/model")
    abort = threading.Event()
    events, requests = [], []
    provider = SimpleNamespace(id="test", context=20)
    app = SimpleNamespace(config={"compaction": {"tail_turns": 0}}, store=store,
                          agents={"compaction": SimpleNamespace(prompt="Summarize.", model=None, temperature=None)},
                          abort_event=lambda _: abort, bus=SimpleNamespace(publish=lambda *args: events.append(args)))

    def reply(result):
        def complete(**kwargs):
            requests.append(kwargs)
            if isinstance(result, Exception):
                raise result
            return result
        app.provider = SimpleNamespace(complete=complete, output_limit=lambda *_: 100,
                                       resolve=lambda _: (provider, "model"))

    human = store.add_message(session["id"], "user", {"content": "Human objective " * 300})
    yield app, session["id"], provider, human, reply, events, requests
    store.close()


def test_summary_keeps_reasoning_model_usage_finish_and_plain_text(summary_case):
    app, sid, provider, human, reply, events, _ = summary_case
    reply(Completion(text="  anchored summary  ", reasoning_content="reason", usage={"total_tokens": 45},
                     model="model", finish_reason="length"))
    compact(app, sid, app.store.context_messages(sid), provider, "model", force=True, system="large" * 1000)
    stored = app.store.messages(sid)
    summary = stored[-2]
    assert summary["content"] == "  anchored summary  "
    assert summary["reasoning_content"] == "reason"
    assert summary["model"] == "test/model"
    assert summary["tokens"] == {"total_tokens": 45}
    assert summary["finish_reason"] == "length"
    assert app.store.context_messages(sid)[0]["id"] == summary["id"]
    assert openai_messages_from_history(app.store.context_messages(sid), model_ref="test/model")[1]["reasoning_content"] == "reason"
    assert openai_messages_from_history(app.store.context_messages(sid), model_ref="other/model")[1]["content"] == "reason\n\n  anchored summary  "
    assert events == [("session.compacted", {"sessionID": sid})]


@pytest.mark.parametrize("finish", ["stop", "length", "content_filter"])
def test_empty_finished_summary_is_not_rejected_by_local_gate(summary_case, finish):
    app, sid, provider, human, reply, events, _ = summary_case
    reply(Completion(text="", reasoning_content="reason", finish_reason=finish))
    compact(app, sid, app.store.context_messages(sid), provider, "model", force=True)
    assert app.store.context_messages(sid)[0]["compaction_through"] == human["id"]
    assert app.store.context_messages(sid)[0]["content"] == ""
    assert len(events) == 1


@pytest.mark.parametrize("streaming", [False, True])
def test_summary_tool_call_is_rejected_before_checkpoint_or_continuation(summary_case, streaming):
    app, sid, provider, human, reply, events, _ = summary_case
    result = Completion(text="partial", reasoning_content="reason", tool_calls=[ToolCall("call", "read", {})],
                        finish_reason="tool-calls" if not streaming else None)
    reply(result)
    if streaming:
        def complete(**kwargs):
            kwargs["on_update"](result)
            pytest.fail("The summary processor must stop on tool-input-start")
        app.provider.complete = complete
    with pytest.raises(ProviderError, match="Tool call not allowed while generating summary: read"):
        compact(app, sid, app.store.context_messages(sid), provider, "model", force=True)
    saved = app.store.messages(sid)[-1]
    assert saved["content"] == "partial"
    assert saved["reasoning_content"] == "reason"
    assert saved["error"] == "Tool call not allowed while generating summary: read"
    assert app.store.context_messages(sid)[0]["id"] == human["id"]
    assert events == []


def test_unfinished_summary_does_not_replace_original_context(summary_case):
    app, sid, provider, human, reply, _, _ = summary_case
    reply(Completion(text="partial summary", reasoning_content="reason", finish_reason=None))
    compact(app, sid, app.store.context_messages(sid), provider, "model", force=True)
    assert app.store.context_messages(sid)[0]["id"] == human["id"]
    assert app.store.messages(sid)[-2]["finish_reason"] is None


def test_failed_summary_retains_previous_context_and_failure_evidence(summary_case):
    app, sid, provider, human, reply, events, _ = summary_case
    previous = app.store.commit_compaction(sid, human["id"], "previous")
    reply(ProviderError("context_length_exceeded", Completion(text="partial", reasoning_content="reason", usage={"total_tokens": 12})))
    with pytest.raises(ProviderError, match="Session too large to compact"):
        compact(app, sid, app.store.context_messages(sid), provider, "model", force=True)
    saved = app.store.messages(sid)[-1]
    assert saved["content"] == "partial"
    assert saved["error"] == "Session too large to compact - context exceeds model limit even after stripping media"
    assert saved["reasoning_content"] == "reason"
    assert saved["finish_reason"] == "error"
    assert app.store.context_messages(sid)[0]["id"] == previous["id"]
    assert events == []


def test_character_estimate_alone_does_not_start_auto_compaction(summary_case):
    app, sid, provider, _, reply, events, requests = summary_case
    reply(Completion(text="unused", finish_reason="stop"))
    compact(app, sid, app.store.context_messages(sid), provider, "model")
    assert requests == []
    assert events == []


def test_summary_progress_is_saved_before_the_request_finishes(summary_case):
    app, sid, provider, human, reply, _, _ = summary_case
    reply(None)

    def complete(**kwargs):
        checkpoint = app.store.messages(sid)[-1]
        assert checkpoint["compaction_through"] == human["id"]
        assert checkpoint["finish_reason"] is None
        kwargs["on_update"](Completion(reasoning_content="in progress", finish_reason=None))
        assert app.store.messages(sid)[-1]["reasoning_content"] == "in progress"
        assert app.store.context_messages(sid)[0]["id"] == human["id"]
        return Completion(text="summary", reasoning_content="in progress", finish_reason="stop")

    app.provider.complete = complete
    compact(app, sid, app.store.context_messages(sid), provider, "model", force=True)
    assert app.store.context_messages(sid)[0]["content"] == "summary"


def test_legacy_summary_wrapper_is_not_sent_as_assistant_text(summary_case):
    app, sid, _, human, _, _, _ = summary_case
    app.store.add_message(sid, "assistant", {"content": "<previous-summary>\nold\n</previous-summary>",
                                            "compaction_through": human["id"], "synthetic": True, "finish_reason": "stop"})
    assert app.store.context_messages(sid)[0]["content"] == "old"


def test_missing_summary_finish_is_not_an_implicit_legacy_completion(summary_case):
    app, sid, _, human, _, _, _ = summary_case
    app.store.add_message(sid, "assistant", {"content": "unfinished", "compaction_through": human["id"]})
    assert app.store.context_messages(sid)[0]["id"] == human["id"]
