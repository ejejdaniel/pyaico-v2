"""Question tools call the supplied source's Question service directly."""

from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.permission import PermissionRejected
from opencode.provider import Completion, ToolCall
from opencode.store import Store

from opencode.tools.extra import _plan_exit, _question


def context(tmp_path, answers, history=None):
    questions, updates = [], []
    history = [] if history is None else history

    def permission(**kwargs):
        raise AssertionError("Question service must not require a preceding permission prompt")

    app = SimpleNamespace(
        permissions=SimpleNamespace(ask=permission),
        ask_questions=lambda session_id, prompts, **kwargs: questions.append((session_id, prompts)) or answers,
        provider=SimpleNamespace(resolve=lambda ref: (SimpleNamespace(id="local"), "default")),
        store=SimpleNamespace(update_session=lambda session_id, **values: updates.append((session_id, values)),
                              messages=lambda session_id: history,
                              add_message=lambda session_id, role, data: history.append({"role": role, **data})),
    )
    return SimpleNamespace(app=app, session_id="session", worktree=tmp_path, switch_agent=None), questions, updates


def test_question_reaches_question_service_without_a_permission_prompt(tmp_path):
    ctx, asked, updates = context(tmp_path, [["First"]])
    prompts = [{"question": "Choose an option", "header": "Choice", "options": [
        {"label": "First", "description": "Use the first option"},
    ]}]
    result = _question({"questions": prompts}, ctx)
    assert asked == [("session", prompts)]
    assert result.metadata == {"answers": [["First"]]}
    assert '"Choose an option"="First"' in result.output
    assert updates == []


def test_plan_exit_reaches_question_service_without_a_permission_prompt(tmp_path):
    ctx, asked, updates = context(tmp_path, [["Yes"]])
    result = _plan_exit({}, ctx)
    assert len(asked) == 1 and asked[0][0] == "session"
    assert asked[0][1][0]["header"] == "Build Agent"
    assert result.title == "Switching to build agent"
    assert ctx.switch_agent == "build"
    assert updates == [("session", {"agent": "build"})]
    assert result.output == "User approved switching to build agent. Wait for further instructions."
    saved = ctx.app.store.messages("session")[-1]
    assert saved == {"role": "user", "synthetic": True, "agent": "build", "model": "local/default",
                     "content": f"The plan at {Path('.opencode') / 'plans' / 'session.md'} has been approved, you can now edit files. Execute the plan"}


def test_plan_exit_uses_latest_user_model_not_assistant_or_a_model_less_message(tmp_path):
    history = [{"role": "user", "model": "local/old"}, {"role": "user", "model": "local/human"},
               {"role": "assistant", "model": "local/other"}, {"role": "user", "content": "No model"}]
    ctx, _, _ = context(tmp_path, [["Yes"]], history)
    _plan_exit({}, ctx)
    assert history[-1]["model"] == "local/human"


def test_plan_exit_no_rejects_without_saving_a_switch(tmp_path):
    ctx, _, updates = context(tmp_path, [["No"]])
    with pytest.raises(PermissionRejected, match="The user dismissed this question"):
        _plan_exit({}, ctx)
    assert ctx.app.store.messages("session") == []
    assert updates == [] and ctx.switch_agent is None


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    for name in ("XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME", "OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR"):
        monkeypatch.setenv(name, str(tmp_path / name))
    app = App(tmp_path, store=Store(tmp_path / "state.db"), config={
        "model": "local/default", "provider": {"local": {
            "api": "openai", "options": {"baseURL": "http://model.invalid/v1", "apiKey": "fixture"},
            "models": {"default": {}},
        }},
    })
    app.generate_titles = False

    def permission(**kwargs):
        raise AssertionError("Question service must not require a preceding permission prompt")

    monkeypatch.setattr(app.permissions, "ask", permission)
    yield app, app.create_session(agent="plan")["id"]
    app.store.close()


@pytest.mark.parametrize("continue_on_deny", [False, True])
def test_plan_exit_no_obeys_existing_loop_denial_behavior(runtime, monkeypatch, continue_on_deny):
    app, sid = runtime
    app.question_callback = lambda _: [["No"]]
    app.config["experimental"] = {"continue_loop_on_deny": continue_on_deny}
    calls = []

    def complete(**kwargs):
        calls.append(kwargs["messages"])
        return (Completion(tool_calls=[ToolCall("exit", "plan_exit", {})], finish_reason="tool-calls")
                if len(calls) == 1 else Completion(text="Continue planning", finish_reason="stop"))

    monkeypatch.setattr(app.provider, "complete", complete)
    app.prompt(sid, "Plan the work")
    assert len(calls) == (2 if continue_on_deny else 1)
    messages = app.store.messages(sid)
    result, = [message for message in messages if message["role"] == "tool"]
    assert result["metadata"]["error"] is True
    assert "The user dismissed this question" in result["content"]
    assert not any(message.get("synthetic") and message.get("agent") == "build" for message in messages)


def test_plan_exit_yes_switches_existing_loop_and_presents_saved_instruction(runtime, monkeypatch):
    app, sid = runtime
    app.question_callback = lambda _: [["Yes"]]
    calls = []

    def complete(**kwargs):
        calls.append(kwargs["messages"])
        return (Completion(tool_calls=[ToolCall("exit", "plan_exit", {})], finish_reason="tool-calls")
                if len(calls) == 1 else Completion(text="Ready to implement", finish_reason="stop"))

    monkeypatch.setattr(app.provider, "complete", complete)
    assert app.prompt(sid, "Plan the work")["text"] == "Ready to implement"
    assert len(calls) == 2
    assert any(message["role"] == "user" and "has been approved, you can now edit files" in message["content"]
               for message in calls[1])
    assert app.store.messages(sid)[-1]["agent"] == "build"


def test_a_run_without_input_says_no_one_can_answer(tmp_path):
    # v42 ran unattended, asked a test question and got only "EOF when reading a line".
    ctx, _, _ = context(tmp_path, [])

    def no_input(session_id, prompts, **kwargs):
        raise EOFError("EOF when reading a line")

    ctx.app.ask_questions = no_input
    result = _question({"questions": [{"question": "test", "header": "t", "options": [{"label": "a"}]}]}, ctx)
    assert result.output.startswith("No one can answer questions in this run") and "notes" in result.output
    assert result.metadata == {"answers": []}
