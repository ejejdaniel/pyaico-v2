"""Deterministic boundaries for the v1.18.9 runtime-service port; no model calls."""

import base64
import json
import os
import queue
from pathlib import Path
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

import httpx
import pytest

from opencode.auth import AuthStore
from opencode.bus import Bus
from opencode.config import directories, load_config, validate_config
from opencode.lsp import LspClient, LspError, detect_command, resolve_config
from opencode.mcp import McpHub, McpServer, _project_result
from opencode.mcp_oauth import McpAuthStore
from opencode.permission import Broker, PermissionDenied, Rule
from opencode.patch import Chunk, Hunk, apply_chunks, apply_hunks, parse_patch
from opencode import paths
from opencode.server import Server


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_DIR", "OPENCODE_CONFIG_CONTENT", "OPENCODE_DISABLE_PROJECT_CONFIG", "OPENCODE_PERMISSION", "OPENCODE_AUTH_CONTENT", "OPENCODE_SERVER_PASSWORD", "OPENCODE_SERVER_USERNAME"):
        monkeypatch.delenv(name, raising=False)
    for name in ("CONFIG", "DATA", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{name}_HOME", str(tmp_path / name.lower()))
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    root = tmp_path / "repo"
    root.mkdir()
    (root / ".git").mkdir()
    return root


def _json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def test_xdg_paths_and_config_override_are_separate(isolated, monkeypatch):
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(isolated / "custom"))
    assert paths.config_dir() == isolated.parent / "config" / "opencode"
    assert paths.truncation_dir() == paths.data_dir() / "tool-output"
    assert directories(isolated, isolated) == [paths.config_dir(), isolated / "custom"]


def test_project_config_precedence_is_per_directory(isolated):
    leaf = isolated / "child"
    leaf.mkdir()
    _json(isolated / "opencode.json", {"model": "root-json"})
    _json(isolated / "opencode.jsonc", {"model": "root-jsonc"})
    _json(leaf / "opencode.json", {"model": "leaf-json"})
    assert load_config(leaf)["model"] == "leaf-json"
    _json(leaf / "opencode.jsonc", {"model": "leaf-jsonc"})
    assert load_config(leaf)["model"] == "leaf-jsonc"


def test_disabled_project_config_keeps_global_home_override_and_parses_false(isolated, monkeypatch):
    _json(isolated / "opencode.json", {"model": "project"})
    _json(paths.config_dir() / "opencode.json", {"model": "global"})
    agent = paths.config_dir() / "agents" / "nested" / "review.md"
    agent.parent.mkdir(parents=True)
    agent.write_text("---\ndescription: Review\npermission:\n  edit: deny\ntemperature: 0\n---\nReview carefully", encoding="utf-8")
    monkeypatch.setenv("OPENCODE_DISABLE_PROJECT_CONFIG", "false")
    assert load_config(isolated)["model"] == "project"
    monkeypatch.setenv("OPENCODE_DISABLE_PROJECT_CONFIG", "TRUE")
    config = load_config(isolated)
    assert config["model"] == "global"
    assert config["agent"]["nested/review"]["permission"] == {"edit": "deny"}
    assert config["agent"]["nested/review"]["temperature"] == 0
    _json(paths.home() / ".opencode" / "opencode.json", {"model": "home"})
    assert load_config(isolated)["model"] == "home"
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(isolated / "override"))
    _json(isolated / "override" / "opencode.json", {"model": "override"})
    assert load_config(isolated)["model"] == "override"


def test_config_substitutions_escape_files_and_reject_missing(isolated, monkeypatch):
    monkeypatch.setenv("PORT_MODEL", "vendor/model")
    (isolated / "prompt.txt").write_text(' line one\n"line two" ', encoding="utf-8")
    (isolated / "opencode.jsonc").write_text('// {file:missing-comment.txt}\n{"model":"{env:PORT_MODEL}","agent":{"build":{"prompt":"{file:prompt.txt}"}}}', encoding="utf-8")
    config = load_config(isolated)
    assert config["model"] == "vendor/model"
    assert config["agent"]["build"]["prompt"] == 'line one\n"line two"'
    monkeypatch.setenv("OPENCODE_CONFIG_CONTENT", '{"model":"{env:PORT_MODEL}"}')
    assert load_config(isolated)["model"] == "vendor/model"
    (isolated / "prompt.txt").unlink()
    with pytest.raises(FileNotFoundError):
        load_config(isolated)


@pytest.mark.parametrize("value", [0, -1, 1.5, "2", True, None])
def test_output_limit_config_rejects_nonpositive_and_noninteger_values(isolated, value):
    for key in ("max_lines", "max_bytes"):
        _json(isolated / "opencode.json", {"tool_output": {key: value}})
        with pytest.raises(ValueError, match="positive integer"):
            load_config(isolated)


@pytest.mark.parametrize("value", ["true", "false", 0, 1, None])
def test_deny_loop_config_requires_a_boolean(isolated, value):
    _json(isolated / "opencode.json", {"experimental": {"continue_loop_on_deny": value}})
    with pytest.raises(ValueError, match="must be a boolean"):
        load_config(isolated)


def test_approved_config_limit_and_deny_values_are_accepted():
    validate_config({"tool_output": {"max_lines": 1, "max_bytes": 1}, "experimental": {"continue_loop_on_deny": False}})


@pytest.mark.parametrize("value", [-1, 1.5, "2", True, None])
def test_compaction_integer_config_is_checked_before_runtime(isolated, value):
    for key in ("tail_turns", "preserve_recent_tokens", "reserved"):
        _json(isolated / "opencode.json", {"compaction": {key: value}})
        with pytest.raises(ValueError, match=rf"compaction\.{key} must be a nonnegative integer"):
            load_config(isolated)


@pytest.mark.parametrize("value", ["true", "false", 0, 1, None])
def test_compaction_prune_requires_a_boolean(isolated, monkeypatch, value):
    monkeypatch.setenv("OPENCODE_CONFIG_CONTENT", json.dumps({"compaction": {"prune": value}}))
    with pytest.raises(ValueError, match=r"compaction\.prune must be a boolean"):
        load_config(isolated)


@pytest.mark.parametrize("value", [-1, 1.5, "2", True, None, float("inf"), float("nan")])
def test_model_input_limit_keeps_approved_nonnegative_integer_contract(value):
    config = {"provider": {"custom": {"models": {"model": {"limit": {"input": value}}}}}}
    with pytest.raises(ValueError, match=r"provider\.custom\.models\.model\.limit\.input must be a nonnegative integer"):
        validate_config(config)


@pytest.mark.parametrize("field,value", [
    ("disabled", "false"), ("disabled", 0), ("disabled", None),
    ("env", None), ("env", []), ("env", {"PORT": 3}), ("env", {"FLAG": True}), ("env", {1: "value"}),
    ("initialization", None), ("initialization", []), ("initialization", "settings"), ("initialization", {1: "value"}),
])
def test_lsp_approved_fields_reject_wrong_types(field, value):
    with pytest.raises(ValueError, match=rf"lsp\.custom\.{field}"):
        validate_config({"lsp": {"custom": {"command": ["server"], "extensions": [".py"], field: value}}})


@pytest.mark.parametrize("config", [
    {"compaction": None}, {"compaction": []},
    {"lsp": None}, {"lsp": []}, {"lsp": 0}, {"lsp": {"custom": None}},
    {"tool_output": None}, {"experimental": None},
])
def test_approved_config_objects_reject_wrong_containers(config):
    with pytest.raises(ValueError, match="must be"):
        validate_config(config)


def test_approved_config_omission_zero_boolean_and_arbitrary_initialization(isolated):
    omitted = {}
    validate_config(omitted)
    assert omitted == {}
    for value in (False, True):
        validate_config({"lsp": value})
        validate_config({"compaction": {"prune": value}, "experimental": {"continue_loop_on_deny": value}})
    config = {
        "compaction": {"tail_turns": 0, "preserve_recent_tokens": 0, "reserved": 0, "prune": False},
        "provider": {"custom": {"models": {"zero": {"limit": {"input": 0}}, "positive": {"limit": {"input": 1}}}}},
        "lsp": {"custom": {"command": ["server"], "extensions": [".py"], "disabled": False,
                           "env": {"FLAG": "false", "EMPTY": ""}, "initialization": {"nested": [True, 0, None, {"value": "x"}]}}},
        "tool_output": {"max_lines": 1, "max_bytes": 1},
    }
    _json(isolated / "opencode.json", config)
    loaded = load_config(isolated)
    for key, value in config.items():
        assert loaded[key] == value
    # V1's literal-true Disabled branch accepts an entry without command or env parsing.
    validate_config({"lsp": {"custom": {"disabled": True, "env": None, "initialization": None}}})


def test_frontmatter_nested_command_name_and_colon_fallback(isolated):
    target = isolated / ".opencode" / "commands" / "ops" / "check.md"
    target.parent.mkdir(parents=True)
    target.write_text("---\ndescription: check: all files\nsubtask: true\n---\nInspect $ARGUMENTS", encoding="utf-8")
    command = load_config(isolated)["command"]["ops/check"]
    assert command["description"] == "check: all files"
    assert command["subtask"] is True


MCP_SOURCE = r'''
import json, os, sys, time
for line in sys.stdin:
    request = json.loads(line)
    method = request.get("method")
    if "id" not in request:
        continue
    if method == "initialize":
        result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "instructions": "  local  "}
    elif method == "tools/list":
        cursor = request.get("params", {}).get("cursor")
        result = {"tools": [{"name": "second" if cursor else "first/tool", "inputSchema": {"type": "object"}}]}
        if not cursor: result["nextCursor"] = "page-2"
    elif method == "tools/call":
        result = {"content": [], "structuredContent": {"cwd": os.getcwd(), "env": os.environ.get("PORT_TEST")}}
    else:
        result = {}
    print(json.dumps({"jsonrpc": "2.0", "id": request["id"], "result": result}), flush=True)
'''


def test_mcp_stdio_newline_cwd_namespace_and_cleanup(isolated):
    script = isolated / "mcp_server.py"
    script.write_text(MCP_SOURCE, encoding="utf-8")
    hub = McpHub({"mcp": {"test.server": {"type": "local", "command": [sys.executable, str(script)], "environment": {"PORT_TEST": "supplied"}}}}, isolated)
    try:
        hub.connect_all()
        server = hub.servers["test.server"]
        assert server.connected, server.error
        assert [tool.name for tool in hub.tool_specs()] == ["test_server_first_tool"]
        output, attachments = hub.call(server, "first/tool", {})
        assert json.loads(output) == {"cwd": str(isolated), "env": "supplied"}
        assert attachments == []
        assert "  local  " not in hub.instructions()
    finally:
        hub.close()
    assert server.process.poll() is not None
    assert hub.tool_specs() == []
    assert hub.instructions() == ""


def test_mcp_failed_initialization_times_out_and_cleans_process(isolated):
    hub = McpHub({"mcp": {"silent": {"command": [sys.executable, "-c", "import time;time.sleep(30)"], "timeout": 100}}}, isolated)
    started = time.monotonic()
    hub.connect_all()
    server = hub.servers["silent"]
    assert time.monotonic() - started < 5
    assert "timed out" in server.error
    assert server.status()["status"] == "failed"
    assert server.process.poll() is not None


def test_mcp_capability_absence_and_disabled_status(isolated):
    hub = McpHub({"mcp": {"off": {"enabled": False, "command": ["missing"]}}}, isolated)
    assert hub.servers["off"].status()["status"] == "disabled"
    server = McpServer("no-tools")
    called = []

    def rpc(server, method, params):
        called.append(method)
        return {"capabilities": {}}

    hub._finish_initialize(server, rpc, lambda *args: None)
    assert called == ["initialize"]
    assert server.tools == []


def test_mcp_list_does_not_add_unapproved_cursor_payload(isolated):
    hub = McpHub({}, isolated)
    calls = []

    def rpc(server, method, params):
        calls.append((method, params))
        return {"capabilities": {"tools": {}}} if method == "initialize" else {"tools": [], "nextCursor": "same"}

    hub._finish_initialize(McpServer("paged"), rpc, lambda *args: None)
    assert [params for method, params in calls if method == "tools/list"] == [{}]


def test_mcp_permission_uses_the_exposed_namespaced_tool_identifier(isolated):
    hub = McpHub({}, isolated)
    hub.servers["test.server"] = McpServer("test.server", connected=True, tools=[{"name": "tool/name"}])
    ctx = SimpleNamespace(app=SimpleNamespace(permissions=Broker()), session_id="test", agent=SimpleNamespace(permission=[Rule("test_server_tool_name", "*", "deny")]))
    with pytest.raises(PermissionDenied):
        hub.tool_specs()[0].execute({}, ctx)


MCP_NOTIFICATION_SOURCE = r'''
import json, sys, time
phase = 0
def reply(request, result):
    print(json.dumps({"jsonrpc":"2.0", "id":request["id"], "result":result}), flush=True)
for line in sys.stdin:
    request = json.loads(line)
    method = request.get("method")
    if "id" not in request: continue
    if method == "initialize":
        reply(request, {"capabilities":{"tools":{"listChanged":True}}})
    elif method == "tools/list":
        if phase == 2:
            print(json.dumps({"jsonrpc":"2.0", "id":request["id"], "error":{"code":-32000,"message":"catalog unavailable"}}), flush=True)
        else:
            reply(request, {"tools":[{"name":"old" if phase == 0 else "new", "inputSchema":{"type":"object"}}]})
    elif method == "tools/call":
        name = request["params"]["name"]
        if name == "refresh":
            phase = request["params"]["arguments"]["phase"]
            print(json.dumps({"jsonrpc":"2.0","method":"notifications/tools/list_changed"}), flush=True)
        else:
            token = request["params"].get("_meta", {}).get("progressToken", "unsolicited")
            for progress in range(4):
                time.sleep(0.07)
                print(json.dumps({"jsonrpc":"2.0","method":"notifications/progress", "params":{"progressToken":token if name == "matching" else "other", "progress":progress}}), flush=True)
        reply(request, {"content":[{"type":"text","text":"done"}]})
'''


def _until(predicate, timeout=2):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    assert predicate()


def test_mcp_dynamic_catalog_and_progress_timeout_reset(isolated):
    script = isolated / "mcp_notifications.py"
    script.write_text(MCP_NOTIFICATION_SOURCE, encoding="utf-8")
    hub = McpHub({"mcp": {"test": {"command": [sys.executable, str(script)], "timeout": 180}}}, isolated)
    try:
        hub.connect_all()
        server = hub.servers["test"]
        assert server.connected, server.error
        assert [tool.name for tool in hub.tool_specs()] == ["test_old"]
        hub.call(server, "refresh", {"phase": 1})
        _until(lambda: [tool.name for tool in hub.tool_specs()] == ["test_new"])
        hub.call(server, "refresh", {"phase": 2})
        _until(lambda: not server._refresh_running)
        assert [tool.name for tool in hub.tool_specs()] == ["test_new"]
        with pytest.raises(LspError, match="timed out"):
            hub.call(server, "matching", {})
        assert server.connected
    finally:
        hub.close()


def test_mcp_structured_content_is_fallback_only():
    assert _project_result({"content": [], "structuredContent": {"value": 4}}) == ('{"value":4}', [])
    assert _project_result({"content": [{"type": "text", "text": "original"}], "structuredContent": {"value": 4}}) == ("original", [])


@pytest.mark.parametrize("legacy_sse", [False, True])
def test_remote_mcp_http_and_sse_transport_boundaries(isolated, legacy_sse):
    messages = queue.Queue()
    stopped = threading.Event()
    notification_ready = threading.Event()
    requests = []
    phase = [0]

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            if legacy_sse:
                self.wfile.write(b"event: endpoint\ndata: /messages\n\n")
                self.wfile.flush()
            notification_ready.set()
            try:
                while not stopped.is_set():
                    try:
                        payload = messages.get(timeout=0.1)
                    except queue.Empty:
                        continue
                    self.wfile.write(b"event: message\ndata: " + json.dumps(payload).encode() + b"\n\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_POST(self):
            payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))))
            requests.append((self.path, payload, dict(self.headers)))
            if legacy_sse and self.path == "/mcp":
                self.send_response(405)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            method = payload["method"]
            result = {"content": [{"type": "text", "text": "remote result"}]}
            if method == "initialize":
                result = {"capabilities": {"tools": {"listChanged": True}}}
            elif method == "tools/list":
                result = {"tools": [{"name": "remote" if phase[0] == 0 else "updated", "inputSchema": {"type": "object"}}]}
            elif method == "tools/call":
                phase[0] = 1
            response = {"jsonrpc": "2.0", "id": payload.get("id"), "result": result}
            if legacy_sse or "id" not in payload:
                self.send_response(202)
                self.send_header("Content-Length", "0")
                self.end_headers()
                if "id" in payload:
                    if method == "tools/call":
                        messages.put({"jsonrpc": "2.0", "method": "notifications/tools/list_changed"})
                    messages.put(response)
                return
            notification = {"jsonrpc": "2.0", "method": "notifications/tools/list_changed" if method == "tools/call" else "notifications/progress", "params": {}}
            body = ("data: " + json.dumps(notification) + "\n\ndata: " + json.dumps(response) + "\n\n").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Mcp-Session-Id", "session-1")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    hub = McpHub({"mcp": {"test": {"type": "remote", "url": f"http://127.0.0.1:{httpd.server_port}/mcp", "oauth": False, "timeout": 200}}}, isolated)
    try:
        hub.connect_all()
        server = hub.servers["test"]
        assert server.connected, server.error
        assert [tool.name for tool in hub.tool_specs()] == ["test_remote"]
        assert notification_ready.wait(1)
        time.sleep(0.3)  # An idle notification stream must outlive the request timeout.
        assert server.connected
        phase[0] = 1
        messages.put({"jsonrpc": "2.0", "method": "notifications/tools/list_changed"})
        _until(lambda: [tool.name for tool in hub.tool_specs()] == ["test_updated"])
        assert hub.call(server, "remote", {}) == ("remote result", [])
        _until(lambda: [tool.name for tool in hub.tool_specs()] == ["test_updated"])
        if not legacy_sse:
            assert requests[-1][2]["Mcp-Session-Id"] == "session-1"
    finally:
        stopped.set()
        hub.close()
        httpd.shutdown()
        httpd.server_close()


def test_remote_mcp_progress_resets_only_matching_request_timeout(isolated):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            assert "_meta" not in payload["params"]
            token = "unsolicited"
            try:
                for progress in range(4):
                    time.sleep(0.07)
                    params = {"progressToken": token if payload["params"]["name"] == "matching" else "other", "progress": progress}
                    self.wfile.write(("data: " + json.dumps({"jsonrpc":"2.0", "method":"notifications/progress", "params":params}) + "\n\n").encode())
                    self.wfile.flush()
                self.wfile.write(("data: " + json.dumps({"jsonrpc":"2.0", "id":payload["id"], "result":{"content":[{"type":"text","text":"done"}]}}) + "\n\n").encode())
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass

    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    hub = McpHub({}, isolated)
    server = McpServer("http", url=f"http://127.0.0.1:{httpd.server_port}", timeout=0.18, connected=True)
    try:
        with pytest.raises(LspError, match="timed out"):
            hub.call(server, "matching", {})
    finally:
        hub._close(server)
        httpd.shutdown()
        httpd.server_close()


def test_mcp_existing_progress_token_resets_only_the_matching_waiter(isolated):
    hub = McpHub({}, isolated)
    server = McpServer("test", timeout=0.1)
    for notification_token, succeeds in (("existing", True), ("different", False)):
        messages = queue.Queue()

        def send_progress():
            for value in range(4):
                time.sleep(0.04)
                messages.put({"jsonrpc":"2.0", "method":"notifications/progress", "params":{"progressToken":notification_token, "progress":value}})
            messages.put({"jsonrpc":"2.0", "id":1, "result":{"content":[]}})

        thread = threading.Thread(target=send_progress, daemon=True)
        thread.start()
        if succeeds:
            assert hub._await_response(server, messages, 1, "tools/call", progress_token="existing") == {"content":[]}
        else:
            with pytest.raises(LspError, match="timed out"):
                hub._await_response(server, messages, 1, "tools/call", progress_token="existing")
        thread.join()


def test_mcp_missing_client_registration_uses_approved_status(isolated, monkeypatch):
    from opencode.mcp import Unauthorized
    from opencode.mcp_oauth import OAuthError
    hub = McpHub({"mcp": {"remote": {"type": "remote", "url": "https://unused.example"}}}, isolated)
    monkeypatch.setattr(hub, "_remote_initialize", lambda *args: (_ for _ in ()).throw(Unauthorized()))
    monkeypatch.setattr("opencode.mcp.obtain_token", lambda *args, **kwargs: (_ for _ in ()).throw(OAuthError("client registration unavailable")))
    hub.connect_remote(hub.servers["remote"], opener=lambda _: None)
    assert hub.servers["remote"].status()["status"] == "needs_client_registration"
    assert "provide clientId" in hub.servers["remote"].status()["error"]


LSP_SOURCE = r'''
import json, os, sys
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line: raise EOFError()
        if line == b"\r\n": break
        key, value = line.decode().split(":", 1)
        headers[key.lower()] = value.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def write(payload):
    body = json.dumps(payload).encode()
    sys.stdout.buffer.write(f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
    sys.stdout.buffer.flush()
events = []
while True:
    message = read()
    method = message.get("method")
    events.append(message)
    if method == "initialize":
        write({"jsonrpc":"2.0", "id": "server-config", "method":"workspace/configuration", "params":{"items":[{"section":"nested.value"}]}})
        write({"jsonrpc":"2.0", "id": message["id"], "result":{"capabilities":{"textDocumentSync":2}}})
    elif method == "inspect":
        write({"jsonrpc":"2.0", "id": message["id"], "result":{"cwd":os.getcwd(),"env":os.environ.get("PORT_TEST"),"events":events}})
'''


def test_lsp_cwd_env_initialize_without_unapproved_payloads(isolated):
    script = isolated / "lsp_server.py"
    script.write_text(LSP_SOURCE, encoding="utf-8")
    target = isolated / "file.py"
    target.write_text("value = '😀'\n", encoding="utf-8")
    client = LspClient([sys.executable, str(script)], isolated, env={"PORT_TEST": "supplied"}, initialization={"nested": {"value": 7}}, timeout=3)
    try:
        client.start()
        client.open_file(target)
        target.write_text("value = 2\n", encoding="utf-8")
        client.open_file(target)
        observed = client.request("inspect", {})
        assert observed["cwd"] == str(isolated)
        assert observed["env"] == "supplied"
        events = observed["events"]
        assert events[0]["params"]["initializationOptions"] == {"nested": {"value": 7}}
        assert not any(e.get("id") == "server-config" for e in events)
        capabilities = events[0]["params"]["capabilities"]
        assert "window" not in capabilities
        assert "configuration" not in capabilities["workspace"]
        opened = next(e for e in events if e.get("method") == "textDocument/didOpen")
        assert opened["params"]["textDocument"]["version"] == 0
        assert not {"textDocument/didChange", "workspace/didChangeConfiguration", "workspace/didChangeWatchedFiles"}.intersection(e.get("method") for e in events)
    finally:
        client.stop()
    assert client.process.poll() is not None


def test_lsp_initialize_timeout_cleans_process(isolated):
    client = LspClient([sys.executable, "-c", "import time;time.sleep(30)"], isolated, timeout=0.1)
    with pytest.raises(LspError, match="timed out"):
        client.start()
    assert client.process.poll() is not None


def test_lsp_disabled_and_approved_settings(isolated, monkeypatch):
    monkeypatch.setattr("opencode.lsp.which", lambda name: name)
    path = isolated / "file.py"
    assert detect_command(path, {"lsp": {"pyright": {"disabled": True}}}) is None
    assert resolve_config(path, {"lsp": True}) == (["pyright-langserver", "--stdio"], {}, {})
    config = {"lsp": {"custom": {"command": ["server"], "extensions": [".py"], "env": {"KEY": "value"}, "initialization": {"nested": True}}}}
    assert resolve_config(path, config) == (["server"], {"KEY": "value"}, {"nested": True})


LSP_DIAGNOSTIC_SOURCE = LSP_SOURCE.split("events = []", 1)[0] + r'''
events = []
mode = os.environ["DIAG_MODE"]
uri = None
diagnostic = {"range":{"start":{"line":0,"character":0},"end":{"line":0,"character":1}},"severity":1,"message":"diagnostic","source":"protocol-test"}
def result(request, value):
    write({"jsonrpc":"2.0","id":request["id"],"result":value})
while True:
    request = read()
    events.append(request)
    method = request.get("method")
    if not method: continue
    if method == "initialize":
        capabilities = {"textDocumentSync":2}
        if mode in {"static", "timeout"}: capabilities["diagnosticProvider"] = {}
        result(request, {"capabilities":capabilities})
    elif method in {"textDocument/didOpen", "textDocument/didChange"}:
        uri = request["params"]["textDocument"]["uri"]
        version = request["params"]["textDocument"]["version"]
        if mode in {"push", "static"}:
            write({"jsonrpc":"2.0","method":"textDocument/publishDiagnostics","params":{"uri":uri,"version":version,"diagnostics":[diagnostic,diagnostic]}})
        elif mode in {"dynamic", "workspace"}:
            write({"jsonrpc":"2.0","id":"register","method":"client/registerCapability","params":{"registrations":[{"id":"diagnostics","method":"textDocument/diagnostic","registerOptions":{"identifier":"registered","workspaceDiagnostics":mode == "workspace"}}]}})
    elif method == "textDocument/diagnostic":
        if mode == "timeout": continue
        items = [] if mode == "dynamic" and not request["params"].get("identifier") else [diagnostic]
        result(request, {"kind":"full","items":items,"relatedDocuments":{uri.rsplit("/",1)[0]+"/related.py":{"kind":"full","items":[diagnostic]}}})
    elif method == "workspace/diagnostic":
        result(request, {"items":[{"uri":uri,"kind":"full","items":[diagnostic]}]})
    elif method == "textDocument/prepareCallHierarchy":
        result(request, [{"name":"real item","kind":12,"uri":uri,"range":diagnostic["range"],"selectionRange":diagnostic["range"],"data":{"opaque":"keep this"}}])
    elif method in {"callHierarchy/incomingCalls", "callHierarchy/outgoingCalls"}:
        result(request, [{"from":request["params"]["item"]}])
    elif method == "workspace/symbol":
        result(request, [{"name":"file","kind":1}] + [{"name":"function","kind":12} for _ in range(14)])
    elif method == "textDocument/hover":
        result(request, {"contents":"hover"})
    elif method == "inspect":
        result(request, events)
    elif "id" in request:
        result(request, [])
'''


def _diagnostic_client(isolated, mode):
    script = isolated / "lsp_diagnostics.py"
    script.write_text(LSP_DIAGNOSTIC_SOURCE, encoding="utf-8")
    target = isolated / "file.py"
    target.write_text("value = 1\n", encoding="utf-8")
    client = LspClient([sys.executable, str(script)], isolated, env={"DIAG_MODE": mode}, timeout=2)
    client.start()
    return client, target


@pytest.mark.parametrize("mode", ["push", "static"])
def test_lsp_push_diagnostics_without_adding_diagnostic_request_payloads(isolated, mode):
    client, path = _diagnostic_client(isolated, mode)
    try:
        started = time.monotonic()
        version = client.open_file(path)
        client.wait_for_diagnostics(path, version, mode="full" if mode == "workspace" else "document", after=started, timeout=1)
        assert len(client.diagnostics[str(path)]) == 1
        assert client.diagnostics[str(path)][0]["message"] == "diagnostic"
        events = client.request("inspect", {})
        methods = [event.get("method") for event in events]
        assert "textDocument/diagnostic" not in methods
        assert "workspace/diagnostic" not in methods
    finally:
        client.stop()


def test_lsp_diagnostic_timeout_does_not_kill_server(isolated):
    client, path = _diagnostic_client(isolated, "timeout")
    try:
        started = time.monotonic()
        version = client.open_file(path)
        client.wait_for_diagnostics(path, version, after=started, timeout=0.15)
        assert time.monotonic() - started < 1
        assert client.process.poll() is None
        assert all(event.get("method") != "textDocument/diagnostic" for event in client.request("inspect", {}))
    finally:
        client.stop()


def test_lsp_existing_operations_keep_original_payload_and_result_shapes(isolated):
    client, path = _diagnostic_client(isolated, "static")
    try:
        for operation in ("incomingCalls", "outgoingCalls"):
            result = client.operation(operation, path, 2, 3)
            assert set(result[0]["from"]) == {"uri", "range", "name", "kind"}
            assert result[0]["from"]["range"]["start"] == {"line": 1, "character": 2}
        assert client.operation("hover", path, 1, 1) == {"contents": "hover"}
        assert len(client.operation("workspaceSymbol", path, 1, 1, "query")) == 15
        for operation in ("goToDefinition", "findReferences", "documentSymbol", "goToImplementation"):
            assert client.operation(operation, path, 1, 1) == []
        assert client.operation("prepareCallHierarchy", path, 1, 1)[0]["name"] == "real item"
        events = client.request("inspect", {})
        prepare = next(event for event in events if event.get("method") == "textDocument/prepareCallHierarchy")
        assert prepare["params"]["position"] == {"line": 0, "character": 0}
        references = next(event for event in events if event.get("method") == "textDocument/references")
        assert references["params"]["context"] == {"includeDeclaration": True}
        workspace = next(event for event in events if event.get("method") == "workspace/symbol")
        assert workspace["params"]["query"] == "query"
    finally:
        client.stop()


def test_http_env_auth_cors_and_prompt_passthrough(isolated, monkeypatch):
    monkeypatch.setenv("OPENCODE_SERVER_PASSWORD", "secret")
    monkeypatch.setenv("OPENCODE_SERVER_USERNAME", "custom")
    seen = []
    app = SimpleNamespace(create_session=lambda **kwargs: seen.append(kwargs) or kwargs, prompt=lambda *args, **kwargs: seen.append(kwargs) or {})
    server = Server(app, cors=["https://allowed.example"])
    server.start()
    try:
        with httpx.Client(base_url=server.url, timeout=3) as client:
            assert client.get("/global/health").status_code == 401
            assert client.get("/global/health-extra").status_code == 401
            assert client.post("/global/health").status_code == 401
            client.headers["Authorization"] = "Basic " + base64.b64encode(b"custom:secret").decode()
            assert client.get("/global/health").status_code == 200
            assert "access-control-allow-origin" not in client.get("/global/health", headers={"Origin": "https://evil.example"}).headers
            for origin in ("https://allowed.example", "http://localhost:3333", "https://app.opencode.ai"):
                assert client.get("/global/health", headers={"Origin": origin}).headers["access-control-allow-origin"] == origin
            rules = [{"permission": "bash", "pattern": "*", "action": "deny"}]
            assert client.post("/session", json={"permission": rules}).status_code == 200
            assert seen[-1]["permission"] == rules
            assert client.post("/session/test/message", json={"text": "hello", "tools": {"bash": False}}).status_code == 200
            assert seen[-1]["tools"] == {"bash": False}
            response = client.post("/session/test/prompt_async", json={"text": "hi", "tools": {"read": True}})
            assert response.status_code == 204
            assert response.content == b""
            assert response.headers["content-length"] == "0"
            assert client.get("/global/health").status_code == 200
    finally:
        server.stop()


def test_auth_binding_normalization_and_permissions(isolated):
    auth = AuthStore(isolated / "auth.json")
    auth.set("https://provider.example/", "key")
    assert auth.get("https://provider.example") == "key"
    assert "https://provider.example/" not in json.loads(auth.path.read_text())
    auth.remove("https://provider.example/")
    assert auth.get("https://provider.example") is None
    mcp = McpAuthStore(isolated / "mcp-auth.json")
    mcp.update("server", tokens={"accessToken": "a"})
    assert mcp.get("server", "https://one.example") is None
    mcp.update("server", serverUrl="https://one.example")
    assert mcp.get("server", "https://one.example") is not None
    assert mcp.get("server", "https://two.example") is None
    if os.name != "nt":
        assert auth.path.stat().st_mode & 0o777 == 0o600
        assert mcp.path.stat().st_mode & 0o777 == 0o600


def test_mcp_noninteractive_refresh_uses_bound_existing_fields(isolated, monkeypatch):
    store = McpAuthStore(isolated / "mcp-auth.json")
    store.update("remote", serverUrl="https://mcp.example", tokens={"accessToken": "old", "refreshToken": "refresh", "expiresAt": 1}, clientInfo={"clientId": "client"})
    monkeypatch.setattr("opencode.mcp_oauth.discover", lambda *args: {"token_endpoint": "https://issuer.example/token", "resource": "https://mcp.example"})
    monkeypatch.setattr("opencode.mcp_oauth.refresh_tokens", lambda *args, **kwargs: {"access_token": "new", "expires_in": 1000})
    monkeypatch.setattr("opencode.mcp_oauth._interactive_grant", lambda *args: pytest.fail("must not open browser"))
    hub = McpHub({"mcp": {"remote": {"type": "remote", "url": "https://mcp.example"}}}, isolated, auth_store=store)
    assert hub._bearer(hub.servers["remote"]) == "new"
    assert store.get("remote", "https://mcp.example")["tokens"]["refreshToken"] == "refresh"


def test_patch_pure_addition_order_final_blank_and_newline(isolated):
    chunks = [Chunk([], ["tail"]), Chunk(["a"], ["A"])]
    assert apply_chunks("a\nb\n", chunks, "file") == "A\nb\ntail\n"
    assert apply_chunks("a\n\n", [Chunk([], ["tail"])], "file") == "a\ntail\n"
    hunks = parse_patch("*** Begin Patch\n*** Add File: blank.txt\n+\n*** End Patch")
    assert hunks[0].contents == "\n"
    apply_hunks(hunks, isolated)
    assert (isolated / "blank.txt").read_bytes() == os.linesep.encode()
    with pytest.raises(FileNotFoundError):
        apply_hunks([Hunk("delete", "missing.txt")], isolated)
    with pytest.raises(ValueError):
        parse_patch("*** Begin Patch\n*** Add File:\n+bad\n*** End Patch")


def test_bus_does_not_drop_events_at_previous_queue_limit():
    bus = Bus()
    box = bus.subscribe()
    for index in range(600):
        bus.publish("test", {"index": index})
    assert [box.get_nowait()["properties"]["index"] for _ in range(600)] == list(range(600))
