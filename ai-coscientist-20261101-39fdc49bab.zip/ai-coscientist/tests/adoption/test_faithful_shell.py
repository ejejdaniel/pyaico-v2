"""Source-backed shell invocation and bounded streaming; no model/network calls."""

import os
import sys
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.permission import Broker, Rule
from opencode.tools import shell, shell_ast


@pytest.fixture
def ctx(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    directory = tmp_path / "project"
    directory.mkdir()
    abort = threading.Event()
    app = SimpleNamespace(config={}, permissions=Broker(auto=True), abort_event=lambda _: abort,
                          store=SimpleNamespace(get_session=lambda _: {"meta": {"former_directories": ["C:/old"]}}))
    return SimpleNamespace(app=app, directory=directory, worktree=directory, session_id="shell",
                           agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]))


def emit(*chunks, exit=0, reason=""):
    def run(command, cwd, env, timeout, abort, **kwargs):
        for text in chunks:
            kwargs["on_chunk"](text)
        return "", "", exit, reason
    return run


def test_configured_shell_then_shell_environment_and_platform_fallback(monkeypatch):
    available = {"configured": "configured-path", "from-env": "env-path", "pwsh": "pwsh-path", "bash": "/bin/bash"}
    monkeypatch.setattr(shell, "which", available.get)
    monkeypatch.setenv("SHELL", "from-env")
    monkeypatch.setenv("OPENCODE_SHELL", "must-not-use")
    assert shell._shell_executable({"shell": "configured"}) == "configured-path"
    assert shell._shell_executable({}) == "env-path"
    assert shell._shell_executable({"shell": "fish"}) == ("pwsh-path" if os.name == "nt" else "/bin/bash")


def test_command_lines_contain_no_local_powershell_prelude_or_login_shell():
    command = "Get-Content 'C:/old/file.txt'"
    assert shell._command_line(command, "powershell") == ["powershell", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
    assert shell._command_line("printf ok", "bash") == ["bash", "-c", "printf ok"]


@pytest.mark.parametrize("name, marker", [("powershell", "Windows PowerShell (5.1) shell notes"),
                                       ("pwsh", "PowerShell (7+) shell notes"), ("cmd", "cmd.exe shell notes"),
                                       ("bash", "Directory Verification:")])
def test_complete_upstream_shell_guidance_and_configured_limits(monkeypatch, name, marker):
    monkeypatch.setattr(shell, "_shell_executable", lambda config=None: name)
    description = shell.description({"tool_output": {"max_lines": 77, "max_bytes": 9000}})
    assert marker in description
    assert "77 lines or 9000 bytes" in description
    assert "120000ms" in description
    assert "${" not in description
    assert "Git and GitHub" in description and "Command Execution" in description
    if name == "powershell":
        assert "avoid '&&' in this shell" in description
    if name == "pwsh":
        assert "supports pipeline chain operators" in description


def test_command_and_environment_are_forwarded_without_relocation_or_injection(ctx, monkeypatch):
    monkeypatch.delenv("AGENT", raising=False)
    monkeypatch.delenv("OPENCODE", raising=False)
    calls = []
    monkeypatch.setattr(shell, "_ask", lambda *args: None)
    monkeypatch.setattr(shell, "_shell_executable", lambda config=None: "bash")
    def run(command, cwd, env, *args, **kwargs):
        calls.append((command, cwd, env))
        kwargs["on_chunk"]("output")
        return "", "", 0, ""
    monkeypatch.setattr(shell, "_run", run)
    result = shell._bash({"command": "echo 'C:/old/file.txt'"}, ctx)
    assert calls[0][0] == "echo 'C:/old/file.txt'"
    assert "AGENT" not in calls[0][2] and "OPENCODE" not in calls[0][2]
    assert result.output == "output" and result.title == calls[0][0]


def test_streamed_tail_and_complete_file_preserve_received_order(ctx, monkeypatch):
    ctx.app.config["tool_output"] = {"max_lines": 3, "max_bytes": 40}
    chunks = ["stdout-1\n", "stderr-1\n", "stdout-2\n", "stderr-2\n", "last-line"]
    monkeypatch.setattr(shell, "_run", emit(*chunks, exit=7))
    result = shell._bash({"command": "bounded-command"}, ctx)
    assert Path(result.metadata["outputPath"]).read_bytes() == "".join(chunks).encode()
    # Unlike upstream, a nonzero exit is stated after the output so the model can tell failure from silence.
    assert result.output.endswith("stdout-2\nstderr-2\nlast-line\n\n<shell_metadata>\nCommand exited with code 7.\n"
                                  "</shell_metadata>")
    assert result.metadata["exit"] == 7 and result.metadata["truncated"] is True
    assert result.metadata["output"] == "".join(chunks)


def test_single_long_unicode_line_keeps_tail_without_splitting_utf8(ctx, monkeypatch):
    ctx.app.config["tool_output"] = {"max_lines": 2000, "max_bytes": 11}
    text = "中文😀" * 30 + "終"
    monkeypatch.setattr(shell, "_run", emit(text))
    result = shell._bash({"command": "bounded-command"}, ctx)
    assert Path(result.metadata["outputPath"]).read_bytes() == text.encode()
    assert result.output.split("\n\n")[-1] == text.encode()[-11:].decode("utf-8", "ignore")


def test_line_only_limit_still_saves_full_output(ctx, monkeypatch):
    ctx.app.config["tool_output"] = {"max_lines": 2, "max_bytes": 1000}
    monkeypatch.setattr(shell, "_run", emit("one\ntwo\nthree"))
    result = shell._bash({"command": "bounded-command"}, ctx)
    assert result.output.endswith("two\nthree")
    assert Path(result.metadata["outputPath"]).read_bytes() == b"one\ntwo\nthree"


@pytest.mark.parametrize("reason, marker", [("timeout", "exceeding timeout 10 ms"), ("abort", "User aborted the command")])
def test_interruption_preserves_partial_output_and_nullable_exit(ctx, monkeypatch, reason, marker):
    monkeypatch.setattr(shell, "_run", emit("partial", exit=None, reason=reason))
    result = shell._bash({"command": "bounded-command", "timeout": 10}, ctx)
    assert result.output.startswith("partial\n\n<shell_metadata>")
    assert marker in result.output
    assert result.metadata["exit"] is None


def test_current_directory_is_in_scope_even_when_it_is_outside_worktree(ctx, tmp_path):
    other = tmp_path / "other-tree"
    other.mkdir()
    file = ctx.directory / "file.txt"
    file.write_text("data", encoding="utf-8")
    directories, _, _ = shell_ast.scan(f'cat "{file}"', ctx.directory, other, "bash", directory=ctx.directory)
    assert directories == []


def test_real_subprocess_stdout_stderr_order_and_nonzero_exit(ctx):
    command = "import sys,time\nfor i in range(3):\n print('OUT'+str(i), flush=True)\n time.sleep(.03)\n print('ERR'+str(i), file=sys.stderr, flush=True)\n time.sleep(.03)\nsys.exit(3)\n"
    stdout, stderr, code, reason = shell._run(command, ctx.directory, os.environ.copy(), 10,
                                             ctx.app.abort_event(ctx.session_id), executable=sys.executable)
    assert stdout.splitlines() == [item + str(i) for i in range(3) for item in ("OUT", "ERR")]
    assert stderr == "" and code == 3 and reason == ""


def test_python_children_print_utf8_unless_the_user_set_otherwise(ctx, monkeypatch):
    # Output is decoded as UTF-8; on Windows Python would otherwise write the local code page.
    envs = []
    monkeypatch.setattr(shell, "_ask", lambda *args: None)
    monkeypatch.setattr(shell, "_shell_executable", lambda config=None: "bash")
    monkeypatch.setattr(shell, "_run", lambda command, cwd, env, *a, **k: envs.append(env) or ("", "", 0, ""))
    monkeypatch.delenv("PYTHONUTF8", raising=False)
    shell._bash({"command": "python -c 'print(1)'"}, ctx)
    monkeypatch.setenv("PYTHONUTF8", "0")
    shell._bash({"command": "python -c 'print(1)'"}, ctx)
    assert [env["PYTHONUTF8"] for env in envs] == ["1", "0"]


def test_failed_command_without_output_is_not_reported_as_silent_success(ctx, monkeypatch):
    monkeypatch.setattr(shell, "_run", emit(exit=49))
    output = shell._bash({"command": "python count.py"}, ctx).output
    assert output.startswith("(no output)") and "Command exited with code 49." in output
    monkeypatch.setattr(shell, "_run", emit("ok\n"))
    assert "exited with code" not in shell._bash({"command": "true"}, ctx).output
