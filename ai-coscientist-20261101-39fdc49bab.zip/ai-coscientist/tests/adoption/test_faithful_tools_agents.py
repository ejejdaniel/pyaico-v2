"""Deterministic boundaries ported from opencode-v1.18.9 tool/agent sources.

No remote model or network service is used. These tests do not prove a complete
research workflow or provider execution.
"""

import io
import json
import os
import shutil
import sys
import tarfile
import threading
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.agent import Agent, build_agents, default_agent_name
from opencode.app import App
from opencode.instructions import clear, collect
from opencode.permission import PermissionDenied, PermissionRejected, Rule, evaluate
from opencode.skills import Skill, discover, render
from opencode.store import Store
from opencode.tools import tools_for
from opencode.tools.extra import _apply_patch, _skill, _task
from opencode.tools.files import _edit, _glob, _grep, _read, _replace, _write, file_tools
from opencode.tools.util import ensure_access
from opencode.tools import files as file_module


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(tmp_path / "config"))
    for name in ("DATA", "CONFIG", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{name}_HOME", str(tmp_path / name.lower()))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    app = App(project, store=Store(tmp_path / "state.db"), config={"model": "local/parent"}, auto_approve=True)
    app.generate_titles = False
    yield app
    app.store.close()


def context(app, sid=None, **kwargs):
    if sid is None:
        sid = app.create_session(model="local/parent")["id"]
    values = dict(app=app, session_id=sid, agent=app.agents["build"], directory=app.directory,
                  worktree=app.worktree, depth=0, turn=1, read_files=set())
    values.update(kwargs)
    return SimpleNamespace(**values)


def write_skill(path, name, body="Task-specific guidance"):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"---\nname: {name}\ndescription: Test guidance\n---\n{body}\n", encoding="utf-8")


def task_input(prompt, **kwargs):
    return {"description": "Bounded test task", "subagent_type": "general", "prompt": prompt, **kwargs}


def test_unknown_subagent_does_not_fall_back_or_create_a_session(runtime):
    ctx = context(runtime)
    before = runtime.store.list_sessions()
    with pytest.raises(ValueError, match="Unknown agent type: absent"):
        _task(task_input("Do a bounded task", subagent_type="absent"), ctx)
    assert runtime.store.list_sessions() == before


def test_task_does_not_invent_required_inputs(runtime):
    with pytest.raises(ValueError, match="description is required"):
        _task({"prompt": "Missing agent choice"}, context(runtime))


def test_task_depth_uses_saved_ancestry_and_honors_zero(runtime):
    root = context(runtime)
    child = runtime.store.create_session(directory=str(runtime.directory), agent="general", model="local/parent",
                                         parent_id=root.session_id)
    with pytest.raises(RuntimeError, match="Subagent depth limit reached"):
        _task(task_input("Nested task"), context(runtime, child["id"], depth=0))
    runtime.config["subagent_depth"] = 0
    with pytest.raises(RuntimeError, match=r"\(0\)"):
        _task(task_input("No child allowed"), root)


@pytest.mark.parametrize("configured, expected", [(None, "local/current"), ("local/special", "local/special")])
def test_task_model_uses_subagent_override_or_current_parent_assistant(runtime, monkeypatch, configured, expected):
    ctx = context(runtime)
    runtime.agents["general"].model = configured
    msg = runtime.store.add_message(ctx.session_id, "assistant", {"content": "", "model": "local/current"})
    ctx.message_id = msg["id"]
    calls = []
    monkeypatch.setattr(runtime, "run_prompt", lambda sid, text, **kw: calls.append((sid, text, kw)) or {"text": "done"})
    result = _task(task_input("A bounded task", description="Small task"), ctx)
    child = runtime.store.get_session(result.metadata["sessionID"])
    assert child["model"] == expected
    assert child["parentID"] == ctx.session_id
    assert child["title"] == "Small task (@general subagent)"
    assert calls[0][2]["_parent_id"] == ctx.session_id
    assert calls[0][2]["model"] == expected


def test_active_background_task_is_extended_even_without_background_flag(runtime, monkeypatch):
    ctx = context(runtime)
    child = runtime.store.create_session(directory=str(runtime.directory), agent="general", model="local/old")
    runtime._background[child["id"]] = threading.Event()
    calls = []
    monkeypatch.setattr(runtime, "spawn_background", lambda *args, **kwargs: calls.append((args, kwargs)))
    monkeypatch.setattr(runtime, "run_prompt", lambda *args, **kwargs: pytest.fail("running task must be extended"))
    result = _task(task_input("Add context", task_id=child["id"], background=False), ctx)
    assert "Background task updated" in result.output
    assert '<task_result>\nAdditional context sent' in result.output
    assert calls[0][0][0:3] == (child["id"], "Add context", "general")
    assert calls[0][1]["model"] == "local/parent"
    runtime._background.pop(child["id"])


def test_resumed_task_uses_current_parent_model_and_invalid_id_creates_new(runtime, monkeypatch):
    ctx = context(runtime)
    old = runtime.store.create_session(directory=str(runtime.directory), agent="general", model="local/old")
    monkeypatch.setattr(runtime, "run_prompt", lambda *args, **kwargs: {"text": "done"})
    result = _task(task_input("Continue", task_id=old["id"]), ctx)
    assert result.metadata["sessionID"] == old["id"]
    assert runtime.store.get_session(old["id"])["model"] == "local/parent"
    result = _task(task_input("Continue", task_id="ses_missing"), ctx)
    assert result.metadata["sessionID"] != "ses_missing"


def test_child_inherits_session_denies_and_external_rules_but_not_parent_agent_rules(runtime, monkeypatch):
    ctx = context(runtime)
    rules = [{"permission": "read", "pattern": "private/*", "action": "deny"},
             {"permission": "external_directory", "pattern": "/sources/*", "action": "allow"},
             {"permission": "write", "pattern": "*", "action": "allow"}]
    runtime.store.update_session(ctx.session_id, permission=rules)
    ctx.agent.permission.append(Rule("bash", "*", "deny"))
    monkeypatch.setattr(runtime, "run_prompt", lambda *args, **kwargs: {"text": "done"})
    result = _task(task_input("A child mission"), ctx)
    child = runtime.store.get_session(result.metadata["sessionID"])
    assert rules[0] in child["permission"] and rules[1] in child["permission"]
    assert rules[2] not in child["permission"]
    assert not any(rule["permission"] == "bash" for rule in child["permission"])
    assert {"permission": "task", "pattern": "*", "action": "deny"} in child["permission"]


def test_resumed_child_retains_its_permission_rules(runtime, monkeypatch):
    ctx = context(runtime)
    rules = [{"permission": "edit", "pattern": "*", "action": "deny"}]
    child = runtime.store.create_session(directory=str(runtime.directory), agent="general", model="local/old",
                                         permission=rules)
    monkeypatch.setattr(runtime, "run_prompt", lambda *args, **kwargs: {"text": "done"})
    _task(task_input("Continue the same session", task_id=child["id"]), ctx)
    assert runtime.store.get_session(child["id"])["permission"] == rules


@pytest.mark.parametrize("model, patch", [("gpt-5.4", True), ("gpt-4.1", False), ("gpt-oss-120b", False),
                                         ("claude-opus-4", False), ("gemini-3", False)])
def test_tool_exposure_tracks_upstream_model_predicate(runtime, model, patch):
    names = {tool.name for tool in tools_for(runtime.agents["build"], model_id=model)}
    assert ("apply_patch" in names) is patch
    assert ("edit" in names) is not patch
    assert ("write" in names) is not patch


def test_task_description_lists_only_permitted_nonprimary_agents(runtime):
    runtime.agents["build"].permission.append(Rule("task", "general", "deny"))
    task = next(tool for tool in tools_for(runtime.agents["build"], agents=runtime.agents) if tool.name == "task")
    assert "- explore:" in task.description
    assert "- general:" not in task.description
    assert "- build:" not in task.description


def test_session_permission_filters_edit_tool_aliases(runtime):
    names = {tool.name for tool in tools_for(runtime.agents["build"], model_id="gpt-5.4",
                                           permission=[Rule("edit", "*", "deny")])}
    assert "apply_patch" not in names


def test_custom_agent_inherits_global_rules_and_defaults_to_all(tmp_path):
    agents = build_agents({"permission": {"bash": "deny"}, "agent": {"custom": {}}}, worktree=tmp_path)
    assert agents["custom"].mode == "all"
    assert evaluate("bash", "echo hi", agents["custom"].permission).action == "deny"


def test_explicit_permission_overrides_deprecated_tools_setting(tmp_path):
    agent = build_agents({"tools": {"bash": False}, "permission": {"bash": "allow"}}, worktree=tmp_path)["build"]
    assert evaluate("bash", "echo hi", agent.permission).action == "allow"


@pytest.mark.parametrize("name, error", [("absent", "not found"), ("general", "is a subagent"), ("summary", "is hidden")])
def test_invalid_default_agent_fails_instead_of_silent_build_fallback(tmp_path, name, error):
    with pytest.raises(ValueError, match=error):
        default_agent_name({"default_agent": name}, build_agents({}, worktree=tmp_path))


def test_automatic_discovery_does_not_include_packaged_investigate(runtime):
    assert "investigate" not in discover(runtime.directory, runtime.worktree, {})


def test_skill_discovery_uses_explicit_frontmatter_and_local_override(runtime, monkeypatch, tmp_path):
    home = tmp_path / "home"
    write_skill(home / ".agents" / "skills" / "example" / "SKILL.md", "same", "global body")
    write_skill(runtime.directory / ".opencode" / "skills" / "example" / "SKILL.md", "same", "local body")
    unnamed = runtime.directory / ".opencode" / "skills" / "unnamed" / "SKILL.md"
    unnamed.parent.mkdir(parents=True)
    unnamed.write_text("No frontmatter", encoding="utf-8")
    write_skill(runtime.directory / "skills" / "unconfigured" / "SKILL.md", "unconfigured")
    write_skill(runtime.directory / "additional" / "explicit" / "SKILL.md", "explicit")
    result = discover(runtime.directory, runtime.worktree, {"skills": {"paths": ["additional"]}})
    assert result["same"].body == "local body"
    assert "unnamed" not in result and "unconfigured" not in result
    assert result["explicit"].location.is_absolute()


def test_skill_listing_obeys_permissions_and_load_explains_base_directory(runtime):
    path = runtime.directory / "guidance" / "SKILL.md"
    write_skill(path, "sample")
    for index in range(15):
        (path.parent / f"reference-{index}.txt").write_text("source", encoding="utf-8")
    runtime.skills = {"sample": Skill("sample", "A test skill", path, "Read reference-0.txt")}
    ctx = context(runtime)
    result = _skill({"name": "sample"}, ctx)
    assert result.title == "Loaded skill: sample"
    assert f"Base directory for this skill: {path.parent}" in result.output
    assert result.output.count("<file>") == 10
    assert f"<file>{path}</file>" not in result.output
    ctx.agent.permission.append(Rule("skill", "sample", "deny"))
    assert "<name>sample</name>" not in render(runtime.skills, ctx.agent)


def test_instruction_glob_visits_each_ancestor_and_deduplicates(runtime):
    folder = runtime.directory / "a" / "b"
    folder.mkdir(parents=True)
    paths = [runtime.directory / "AGENTS.md", runtime.directory / "a" / "guide.txt", folder / "guide.txt"]
    for index, path in enumerate(paths):
        path.write_text(f"Instruction {index}", encoding="utf-8")
    documents = collect(folder, runtime.directory, {"instructions": ["guide.txt", "AGENTS.md"]})
    assert {str(path) for path in paths} == {name for name, _ in documents}
    assert len(documents) == 3


def test_nested_instructions_follow_filename_priority_and_claim_once_per_message(runtime):
    folder = runtime.directory / "src" / "nested"
    folder.mkdir(parents=True)
    parent = folder.parent / "AGENTS.md"
    local = folder / "AGENTS.md"
    parent.write_text("Parent instruction", encoding="utf-8")
    local.write_text("Nested instruction", encoding="utf-8")
    (folder / "CLAUDE.md").write_text("Lower priority", encoding="utf-8")
    path = folder / "code.py"
    path.write_text("value = 1\n", encoding="utf-8")
    ctx = context(runtime, message_id="msg_same")
    first = _read({"filePath": str(path)}, ctx)
    second = _read({"filePath": str(path)}, ctx)
    assert first.metadata["loaded"] == [str(local), str(parent)]
    assert "Nested instruction" in first.output and "Parent instruction" in first.output
    assert "Lower priority" not in first.output
    assert second.metadata["loaded"] == []
    clear(runtime, "msg_same")


def test_active_read_receipts_suppress_reload_but_compacted_receipts_do_not(runtime):
    folder = runtime.directory / "nested"
    folder.mkdir()
    guide = folder / "AGENTS.md"
    guide.write_text("Instruction to reload", encoding="utf-8")
    path = folder / "file.txt"
    path.write_text("content", encoding="utf-8")
    ctx = context(runtime, message_id="msg_first")
    first = _read({"filePath": str(path)}, ctx)
    saved = runtime.store.add_message(ctx.session_id, "tool", {
        "name": "read", "content": first.output, "metadata": first.metadata,
    })
    clear(runtime, "msg_first")
    ctx.message_id = "msg_second"
    assert _read({"filePath": str(path)}, ctx).metadata["loaded"] == []
    runtime.store.mark_tools_compacted(ctx.session_id, [saved["id"]], 123)
    ctx.message_id = "msg_third"
    reloaded = _read({"filePath": str(path)}, ctx)
    assert reloaded.metadata["loaded"] == [str(guide)]
    assert "Instruction to reload" in reloaded.output
    clear(runtime, "msg_second")
    clear(runtime, "msg_third")


def test_reading_instruction_itself_or_directory_does_not_attach_it_again(runtime):
    folder = runtime.directory / "nested"
    folder.mkdir()
    guide = folder / "AGENTS.md"
    guide.write_text("Instruction", encoding="utf-8")
    ctx = context(runtime)
    assert _read({"filePath": str(guide)}, ctx).metadata["loaded"] == []
    assert _read({"filePath": str(folder)}, ctx).metadata["loaded"] == []


def test_read_matches_line_number_limit_and_overflow_behavior(runtime):
    path = runtime.directory / "long.txt"
    path.write_text("x" * 2400 + "\nsecond\nthird", encoding="utf-8")
    result = _read({"filePath": str(path), "limit": 1}, context(runtime))
    assert f"1: {'x' * 2000}... (line truncated to 2000 chars)" in result.output
    assert "Showing lines 1-1 of 3. Use offset=2 to continue." in result.output
    assert "charOffset" not in result.output
    assert "charOffset" not in next(tool for tool in file_tools() if tool.name == "read").parameters["properties"]
    with pytest.raises(ValueError, match="out of range"):
        _read({"filePath": str(path), "offset": 4}, context(runtime))
    path.write_text(("x" * 1900 + "\n") * 40, encoding="utf-8")
    result = _read({"filePath": str(path)}, context(runtime))
    assert "Output capped at 50 KB" in result.output


@pytest.mark.parametrize("text,expected", [
    ("a" * 2000, "a" * 2000),
    ("😀" * 1000, "😀" * 1000),
    ("e\u0301" * 1000, "e\u0301" * 1000),
    ("中" * 2001, "中" * 2000 + "... (line truncated to 2000 chars)"),
    ("😀" * 1001, "😀" * 1000 + "... (line truncated to 2000 chars)"),
    ("a" * 1999 + "😀", "a" * 1999 + "\ud83d... (line truncated to 2000 chars)"),
], ids=["ascii-boundary", "pair-boundary", "combining-boundary", "bmp-overflow", "pair-overflow", "split-pair"])
def test_read_long_lines_use_source_utf16_length_and_substring(runtime, text, expected):
    # read.ts checks text.length before substring(0, 2000), even mid-pair.
    path = runtime.directory / "unicode.txt"
    path.write_text(text, encoding="utf-8")
    result = _read({"filePath": str(path)}, context(runtime))
    assert result.output == (f"<path>{path}</path>\n<type>file</type>\n<content>\n\n"
                             f"1: {expected}\n\n(End of file - total 1 lines)\n</content>")
    assert result.metadata["truncated"] is False


@pytest.mark.parametrize("last_length,capped", [(1138, False), (1139, False), (1140, True)])
def test_read_byte_cap_counts_split_surrogate_as_three_utf8_bytes(runtime, last_length, capped):
    # The source's Buffer.byteLength returns 2036 for the clipped first line:
    # 1999 ASCII bytes + 3 replacement bytes + 34 suffix bytes. With separators,
    # the 1139-character final line reaches exactly 50 * 1024 bytes.
    path = runtime.directory / "byte-limit.txt"
    path.write_text("\n".join(["a" * 1999 + "😀", *(["b" * 2000] * 24), "c" * last_length]),
                    encoding="utf-8")
    result = _read({"filePath": str(path)}, context(runtime))
    assert "1: " + "a" * 1999 + "\ud83d... (line truncated to 2000 chars)" in result.output
    assert result.metadata["truncated"] is capped
    if capped:
        assert "26: " not in result.output
        assert "Output capped at 50 KB. Showing lines 1-25. Use offset=26 to continue." in result.output
    else:
        assert "26: " + "c" * last_length in result.output
        assert "End of file - total 26 lines" in result.output


def test_directory_read_keeps_hidden_and_build_directories(runtime):
    for name in (".git", "node_modules", "build"):
        (runtime.directory / name).mkdir(exist_ok=True)
    result = _read({"filePath": str(runtime.directory)}, context(runtime))
    assert all(name + "/" in result.output for name in (".git", "node_modules", "build"))


@pytest.mark.parametrize("filename, data", [("data.dat", b"text"), ("binary.txt", b"a\x00b")])
def test_binary_read_is_an_explicit_error(runtime, filename, data):
    path = runtime.directory / filename
    path.write_bytes(data)
    with pytest.raises(ValueError, match="Cannot read binary file"):
        _read({"filePath": str(path)}, context(runtime))


def test_write_and_edit_have_no_extra_preread_gate_and_preserve_bom_line_endings(runtime):
    path = runtime.directory / "note.txt"
    path.write_bytes(b"\xef\xbb\xbffirst\r\nsecond\r\n")
    ctx = context(runtime)
    _edit({"filePath": str(path), "oldString": "first\nsecond", "newString": "first\nlast"}, ctx)
    assert path.read_bytes() == b"\xef\xbb\xbffirst\r\nlast\r\n"
    ctx.read_files.clear()
    _write({"filePath": str(path), "content": "replaced\n"}, ctx)
    assert path.read_bytes() == b"\xef\xbb\xbfreplaced\n"


def test_empty_old_string_creates_new_file_but_cannot_replace_existing(runtime):
    path = runtime.directory / "nested" / "new.txt"
    ctx = context(runtime)
    _edit({"filePath": str(path), "oldString": "", "newString": "new file\n"}, ctx)
    assert path.read_bytes() == b"new file\n"
    with pytest.raises(ValueError, match="oldString cannot be empty"):
        _edit({"filePath": str(path), "oldString": "", "newString": "replacement"}, ctx)


@pytest.mark.parametrize("content, old, new, expected", [
    ("  one\n    two\n", "one\ntwo", "changed", "changed\n"),
    ("before: foo   bar; after", "foo bar", "new", "before: new; after"),
    ("start\nvalue = 10;\nend", "start\nvalue = 11;\nend", "changed", "changed"),
    ("one\ntwo", r"one\ntwo", "new", "new"),
    ("prefix: token suffix", "  token  ", "new", "prefix: new suffix"),
])
def test_edit_uses_upstream_replacement_fallbacks(content, old, new, expected):
    assert _replace(content, old, new) == expected


def test_edit_rejects_ambiguous_and_unrelated_anchor_matches():
    with pytest.raises(ValueError, match="multiple matches"):
        _replace("duplicate duplicate", "duplicate", "replacement")
    assert _replace("duplicate duplicate", "duplicate", "replacement", True) == "replacement replacement"
    original = "function configure() {\n  removeAllUserData()\n}"
    with pytest.raises(ValueError, match="Could not find oldString"):
        _replace(original, "function configure() {\n  const enabled = true\n}", "new")
    original = "function configure() {\n  keepState()\n  removeData()\n  archive()\n  audit()\n}"
    with pytest.raises(ValueError, match="Could not find oldString"):
        _replace(original, "function configure() {\n  const enabled = true\n}", "new")


def test_patch_validates_all_files_before_writing_and_needs_no_prior_read(runtime):
    first = runtime.directory / "first.txt"
    second = runtime.directory / "second.txt"
    first.write_text("first\n", encoding="utf-8")
    second.write_text("second\n", encoding="utf-8")
    patch = "*** Begin Patch\n*** Update File: first.txt\n@@\n-first\n+changed\n*** Update File: second.txt\n@@\n-missing\n+changed\n*** End Patch"
    ctx = context(runtime)
    with pytest.raises(ValueError, match="Failed to find expected lines"):
        _apply_patch({"patchText": patch}, ctx)
    assert first.read_text(encoding="utf-8") == "first\n"
    result = _apply_patch({"patchText": patch.replace("-missing", "-second")}, ctx)
    assert first.read_bytes() == b"changed\n"
    assert "M first.txt" in result.output and "M second.txt" in result.output


def permission_calls(runtime, monkeypatch):
    calls = []
    original = runtime.permissions.ask

    def ask(**kwargs):
        calls.append(kwargs)
        return original(**kwargs)

    monkeypatch.setattr(runtime.permissions, "ask", ask)
    return calls


@pytest.mark.parametrize("kind", ["file", "directory"])
def test_read_asks_external_directory_before_relative_read(runtime, monkeypatch, kind):
    # read.ts + external-directory.ts: directory reads scope the directory itself.
    folder = runtime.directory.parent / "outside"
    folder.mkdir()
    path = folder if kind == "directory" else folder / "source.txt"
    if kind == "file":
        path.write_text("source", encoding="utf-8")
    calls = permission_calls(runtime, monkeypatch)
    _read({"filePath": str(path)}, context(runtime))
    assert [(call["permission"], call["patterns"], call["always"]) for call in calls] == [
        ("external_directory", [folder.as_posix() + "/*"], [folder.as_posix() + "/*"]),
        ("read", [os.path.relpath(path, runtime.worktree)], ["*"]),
    ]


def test_external_denial_precedes_read_permission(runtime, monkeypatch):
    path = runtime.directory.parent / "outside.txt"
    path.write_text("private", encoding="utf-8")
    ctx = context(runtime)
    ctx.agent.permission.append(Rule("external_directory", "*", "deny"))
    calls = permission_calls(runtime, monkeypatch)
    with pytest.raises(PermissionDenied, match="external_directory"):
        _read({"filePath": str(path)}, ctx)
    assert [call["permission"] for call in calls] == ["external_directory"]


def test_read_permission_is_relative_to_worktree_not_current_directory(runtime):
    folder = runtime.directory / "nested"
    folder.mkdir()
    path = folder / "private.txt"
    path.write_text("private", encoding="utf-8")
    ctx = context(runtime, directory=folder)
    ctx.agent.permission.append(Rule("read", "nested/private.txt", "deny"))
    with pytest.raises(PermissionDenied, match="read"):
        _read({"filePath": "private.txt"}, ctx)


def test_read_env_pattern_asks_and_example_override_allows(runtime, monkeypatch):
    # agent.ts patterns match worktree-relative file names at the read boundary.
    runtime.permissions.auto = False
    requests = []
    runtime.permissions.callback = lambda pending: requests.append(pending) or "once"
    for name in (".env", ".env.example"):
        (runtime.directory / name).write_text("test", encoding="utf-8")
        _read({"filePath": name}, context(runtime))
    assert [(request.permission, request.patterns) for request in requests] == [("read", [".env"])]


@pytest.mark.parametrize("tool,args", [(_write, {"content": "changed"}),
                                        (_edit, {"oldString": "original", "newString": "changed"})])
def test_file_mutation_asks_external_then_relative_edit(runtime, monkeypatch, tool, args):
    path = runtime.directory.parent / "outside.txt"
    path.write_text("original", encoding="utf-8")
    calls = permission_calls(runtime, monkeypatch)
    tool({"filePath": str(path), **args}, context(runtime))
    assert [(call["permission"], call["patterns"]) for call in calls] == [
        ("external_directory", [path.parent.as_posix() + "/*"]),
        ("edit", [os.path.relpath(path, runtime.worktree)]),
    ]
    assert calls[-1]["always"] == ["*"]


def test_invalid_edit_does_not_ask_to_approve_nonexistent_change(runtime, monkeypatch):
    path = runtime.directory / "file.txt"
    path.write_text("original", encoding="utf-8")
    calls = permission_calls(runtime, monkeypatch)
    with pytest.raises(ValueError, match="Could not find oldString"):
        _edit({"filePath": str(path), "oldString": "missing", "newString": "changed"}, context(runtime))
    assert calls == []
    assert path.read_text(encoding="utf-8") == "original"


@pytest.mark.parametrize("tool,pattern", [(_grep, "needle.*"), (_glob, "*.txt")])
def test_search_permission_uses_query_before_external_directory(runtime, monkeypatch, tool, pattern):
    folder = runtime.directory.parent / "outside"
    folder.mkdir()
    monkeypatch.setattr(file_module, "_ripgrep", lambda *args, **kwargs: [])
    calls = permission_calls(runtime, monkeypatch)
    tool({"pattern": pattern, "path": str(folder)}, context(runtime))
    assert [(call["permission"], call["patterns"], call["always"]) for call in calls] == [
        ("grep" if tool is _grep else "glob", [pattern], ["*"]),
        ("external_directory", [folder.as_posix() + "/*"], [folder.as_posix() + "/*"]),
    ]


def test_glob_file_path_fails_before_external_permission(runtime, monkeypatch):
    path = runtime.directory.parent / "outside.txt"
    path.write_text("source", encoding="utf-8")
    calls = permission_calls(runtime, monkeypatch)
    with pytest.raises(ValueError, match="glob path must be a directory"):
        _glob({"pattern": "*.txt", "path": str(path)}, context(runtime))
    assert [call["permission"] for call in calls] == ["glob"]


def test_glob_missing_directory_scopes_target_not_parent(runtime, monkeypatch):
    path = runtime.directory.parent / "missing"
    monkeypatch.setattr(file_module, "_ripgrep", lambda *args, **kwargs: [])
    calls = permission_calls(runtime, monkeypatch)
    _glob({"pattern": "*.txt", "path": str(path)}, context(runtime))
    assert calls[-1]["patterns"] == [path.as_posix() + "/*"]


def test_patch_asks_one_edit_for_sources_after_external_move_checks(runtime, monkeypatch):
    source = runtime.directory / "source.txt"
    source.write_text("original\n", encoding="utf-8")
    destination = runtime.directory.parent / "moved.txt"
    patch = ("*** Begin Patch\n*** Update File: source.txt\n"
             f"*** Move to: {destination.as_posix()}\n@@\n-original\n+changed\n"
             "*** Add File: added.txt\n+new\n*** End Patch")
    calls = permission_calls(runtime, monkeypatch)
    _apply_patch({"patchText": patch}, context(runtime))
    assert [(call["permission"], call["patterns"]) for call in calls] == [
        ("external_directory", [destination.parent.as_posix() + "/*"]),
        ("edit", ["source.txt", "added.txt"]),
    ]
    assert calls[-1]["always"] == ["*"]
    assert destination.read_bytes() == b"changed\n"


def test_patch_invalid_move_never_asks_destination_or_edit_permission(runtime, monkeypatch):
    source = runtime.directory / "source.txt"
    source.write_bytes(b"original\n")
    destination = runtime.directory.parent / "moved.txt"
    patch = ("*** Begin Patch\n*** Update File: source.txt\n"
             f"*** Move to: {destination.as_posix()}\n@@\n-missing\n+changed\n*** End Patch")
    calls = permission_calls(runtime, monkeypatch)
    with pytest.raises(ValueError, match="Failed to find expected lines"):
        _apply_patch({"patchText": patch}, context(runtime))
    assert calls == []
    assert source.read_bytes() == b"original\n" and not destination.exists()


def test_patch_relative_edit_deny_prevents_all_writes(runtime, monkeypatch):
    path = runtime.directory / "private.txt"
    path.write_bytes(b"original\n")
    ctx = context(runtime)
    ctx.agent.permission.append(Rule("edit", "private.txt", "deny"))
    patch = ("*** Begin Patch\n*** Add File: added.txt\n+new\n"
             "*** Update File: private.txt\n@@\n-original\n+changed\n*** End Patch")
    with pytest.raises(PermissionDenied, match="edit"):
        _apply_patch({"patchText": patch}, ctx)
    assert path.read_bytes() == b"original\n" and not (runtime.directory / "added.txt").exists()


def test_lsp_permission_is_wildcard_after_external_directory(runtime, monkeypatch):
    path = runtime.directory.parent / "source.py"
    calls = permission_calls(runtime, monkeypatch)
    ensure_access(context(runtime), path, "lsp")
    assert [(call["permission"], call["patterns"]) for call in calls] == [
        ("external_directory", [path.parent.as_posix() + "/*"]), ("lsp", ["*"]),
    ]
    assert calls[-1]["always"] == ["*"]


def rg_match(path="source.txt", text="needle\n", line=1):
    return {"type": "match", "data": {"path": {"text": path}, "lines": {"text": text},
            "line_number": line, "absolute_offset": 0, "submatches": [
                {"match": {"text": "needle"}, "start": 0, "end": 6}]}}


class FakeRipgrep:
    def __init__(self, output, code=0, error=b""):
        self.stdout = io.BytesIO(output)
        self.stderr = io.BytesIO(error)
        self.code = code
        self.returncode = None
        self.killed = False

    def poll(self):
        return self.returncode

    def wait(self):
        self.returncode = self.code
        return self.code

    def kill(self):
        self.killed = True
        self.returncode = -1


def fake_rg_process(monkeypatch, output, code=0, error=b""):
    process = FakeRipgrep(output, code, error)
    calls = []
    monkeypatch.setattr(file_module, "_ripgrep_binary", lambda **kwargs: "controlled-rg")
    monkeypatch.setattr(file_module.subprocess, "Popen", lambda *args, **kwargs: calls.append((args, kwargs)) or process)
    return process, calls


def test_grep_uses_core_arguments_json_rows_and_source_rendering(runtime, monkeypatch):
    root = runtime.directory
    (root / "requested.txt").write_text("file", encoding="utf-8")
    rows = [rg_match("./b.txt", line=4), rg_match("./a.txt", "needle twice needle\n", 8)]
    output = "\n".join(json.dumps(row) for row in [{"type": "begin"}, *rows]).encode()
    process, calls = fake_rg_process(monkeypatch, output)
    result = _grep({"pattern": "-needle", "path": "requested.txt", "include": "*.txt"}, context(runtime))
    assert calls[0][0][0] == ["controlled-rg", "--no-config", "--json", "--hidden", "--no-messages",
                              "--glob=*.txt", "--glob=!**/.git/**", "--", "-needle", "."]
    # grep.ts intentionally searches the containing directory when passed a file.
    assert calls[0][1]["cwd"] == root
    assert result.output == (f"Found 2 matches\n{root / 'b.txt'}:\n  Line 4: needle\n\n\n"
                             f"{root / 'a.txt'}:\n  Line 8: needle twice needle\n")
    assert result.metadata == {"matches": 2, "truncated": False}
    assert not process.killed


def test_grep_stops_after_101_rows_and_reports_100(runtime, monkeypatch):
    rows = [rg_match(text=f"needle {index}\n", line=index + 1) for index in range(120)]
    process, _ = fake_rg_process(monkeypatch, "\n".join(json.dumps(row) for row in rows).encode())
    result = _grep({"pattern": "needle"}, context(runtime))
    assert result.metadata == {"matches": 100, "truncated": True}
    assert "Found 100 matches (more matches available)" in result.output
    assert "Line 100: needle 99" in result.output and "Line 101" not in result.output
    assert process.killed


@pytest.mark.parametrize("code,error,raises", [(2, b"permission denied", None),
                                              (2, b"regex parse error: bad regex", ValueError),
                                              (3, b"search process failed", RuntimeError)])
def test_ripgrep_exit_semantics_follow_core(runtime, monkeypatch, code, error, raises):
    fake_rg_process(monkeypatch, json.dumps(rg_match()).encode(), code, error)
    if raises:
        with pytest.raises(raises, match=error.decode()):
            _grep({"pattern": "needle"}, context(runtime))
    else:
        # Core accepts code 2 partial rows; no local complete-search exception.
        assert _grep({"pattern": "needle"}, context(runtime)).metadata == {"matches": 1, "truncated": False}


@pytest.mark.parametrize("output,error", [(b"not-json", "Invalid ripgrep JSON output"),
    (json.dumps({"type": "match", "data": {}}).encode(), "Invalid ripgrep match output"),
    (b"x" * 65537, "Ripgrep JSON record exceeded 65536 bytes")], ids=["invalid-json", "invalid-match", "oversize"])
def test_ripgrep_malformed_records_fail_and_cleanup(runtime, monkeypatch, output, error):
    process, _ = fake_rg_process(monkeypatch, output)
    with pytest.raises(RuntimeError, match=error):
        _grep({"pattern": "needle"}, context(runtime))
    assert process.killed and process.stdout.closed and process.stderr.closed


@pytest.mark.parametrize("text,expected", [
    ("😀" * 1000, "😀" * 1000),
    ("😀" * 1000 + "\n", "😀" * 1000 + "..."),
    ("😀" * 1001, "😀" * 1000 + "..."),
    ("a" * 1999 + "😀", "a" * 1999 + "\ud83d..."),
], ids=["pair-boundary", "newline-overflow", "pair-overflow", "split-pair"])
def test_grep_long_text_is_capped_at_2000_utf16_units(runtime, monkeypatch, text, expected):
    fake_rg_process(monkeypatch, json.dumps(rg_match(text=text)).encode())
    result = _grep({"pattern": "needle"}, context(runtime))
    assert result.output.endswith("  Line 1: " + expected)


@pytest.mark.parametrize("name", ["read", "grep"])
def test_split_surrogate_tool_text_survives_saved_receipt_and_provider_json(runtime, monkeypatch, name):
    from opencode.loop import _save_tool_message
    from opencode.provider import ProviderInfo, openai_messages_from_history

    ctx = context(runtime)
    text = "a" * 1999 + "😀"
    if name == "read":
        path = runtime.directory / "unicode.txt"
        path.write_text(text, encoding="utf-8")
        arguments = {"filePath": str(path)}
        result = _read(arguments, ctx)
    else:
        fake_rg_process(monkeypatch, json.dumps(rg_match(text=text)).encode())
        arguments = {"pattern": "needle"}
        result = _grep(arguments, ctx)
    assert "\ud83d" in result.output
    assistant = runtime.store.add_message(ctx.session_id, "assistant", {
        "content": "", "tool_calls": [{"id": "unicode-call", "name": name, "arguments": arguments}],
    })
    _save_tool_message(runtime, ctx.session_id, assistant, {
        "tool_call_id": "unicode-call", "name": name, "content": result.output,
        "title": result.title, "metadata": result.metadata,
    })
    history = runtime.store.messages(ctx.session_id)
    assert history[-1]["content"] == result.output
    receipt_path = runtime.store.tool_history_path(ctx.session_id).parent / (history[-1]["id"] + ".json")
    assert json.loads(receipt_path.read_text(encoding="utf-8"))[-1]["content"] == result.output
    assert receipt_path.with_suffix(".txt").read_text(encoding="utf-8") == result.output.replace("\ud83d", "\ufffd")

    sent = []

    def capture_json(_url, _headers, body, _timeout, _abort):
        # JSON encoding at the HTTP boundary must succeed without changing the
        # database receipt; provider/transform.ts replaces lone surrogates here.
        sent.append(json.loads(json.dumps(body, ensure_ascii=False).encode("utf-8")))
        return SimpleNamespace(status_code=200, json=lambda: {
            "choices": [{"finish_reason": "stop", "message": {"content": ""}}],
        })

    monkeypatch.setattr("opencode.provider._post", capture_json)
    provider = ProviderInfo("test", "openai", "test", "https://invalid.example/v1", [], ["model"], "model")
    runtime.provider._openai(provider, "test-token", "model", "", openai_messages_from_history(history),
                             None, None, None)
    assert sent[0]["messages"][-1]["content"] == result.output.replace("\ud83d", "\ufffd")
    assert runtime.store.messages(ctx.session_id)[-1]["content"] == result.output


@pytest.mark.parametrize("count", [0, 99, 100, 101])
def test_glob_preserves_ripgrep_order_and_source_limit(runtime, monkeypatch, count):
    names = [f"z-{index:03}.txt" for index in reversed(range(count))]
    process, calls = fake_rg_process(monkeypatch, "\n".join(".\\" + name for name in names).encode(), 0 if count else 1)
    result = _glob({"pattern": "*.{txt,md}"}, context(runtime))
    assert calls[0][0][0] == ["controlled-rg", "--no-config", "--files", "--glob=*.{txt,md}", "--glob=!**/.git/**", "."]
    assert result.metadata == {"count": min(count, 100), "truncated": count >= 100}
    assert result.output.splitlines()[:min(count, 100)] == [str(runtime.directory / name) for name in names[:100]]
    if count == 0:
        assert result.output == "No files found"
    assert process.killed is (count > 100)


def test_ripgrep_obeys_gitignore_without_local_build_exclusions(runtime):
    if not shutil.which("rg"):
        pytest.skip("This integration check uses an existing rg; it never downloads one")
    root = runtime.directory
    (root / ".gitignore").write_text("ignored.txt\n", encoding="utf-8")
    for name in ("build/visible.txt", "node_modules/visible.txt", ".hidden.txt", "ignored.txt", ".git/private.txt"):
        path = root / name
        path.parent.mkdir(exist_ok=True)
        path.write_text("needle", encoding="utf-8")
    globbed = _glob({"pattern": "**/*"}, context(runtime)).output
    searched = _grep({"pattern": "needle"}, context(runtime)).output
    for output in (globbed, searched):
        assert str(root / "build" / "visible.txt") in output
        assert str(root / "node_modules" / "visible.txt") in output
        assert "private.txt" not in output
    # An explicit ripgrep --glob takes precedence over ignore/hidden defaults.
    assert "ignored.txt" in globbed and "ignored.txt" not in searched
    assert ".hidden.txt" in globbed and ".hidden.txt" in searched


@pytest.mark.parametrize("system,machine,triple,extension", [
    ("Windows", "AMD64", "x86_64-pc-windows-msvc", "zip"),
    ("Windows", "arm64", "aarch64-pc-windows-msvc", "zip"),
    ("Windows", "x86", "i686-pc-windows-msvc", "zip"),
    ("Darwin", "arm64", "aarch64-apple-darwin", "tar.gz"),
    ("Darwin", "x86_64", "x86_64-apple-darwin", "tar.gz"),
    ("Linux", "aarch64", "aarch64-unknown-linux-gnu", "tar.gz"),
    ("Linux", "x86_64", "x86_64-unknown-linux-musl", "tar.gz"),
])
def test_ripgrep_bootstrap_uses_pinned_source_archive(runtime, monkeypatch, system, machine, triple, extension):
    executable = "rg.exe" if system == "Windows" else "rg"
    buffer = io.BytesIO()
    member = f"ripgrep-15.1.0-{triple}/{executable}"
    if extension == "zip":
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr(member, b"controlled executable bytes")
    else:
        with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
            info = tarfile.TarInfo(member)
            info.size = len(b"controlled executable bytes")
            archive.addfile(info, io.BytesIO(b"controlled executable bytes"))
    urls = []

    class Client:
        def __init__(self, **kwargs):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
        def get(self, url):
            urls.append(url)
            return SimpleNamespace(content=buffer.getvalue(), raise_for_status=lambda: None)

    monkeypatch.setattr(file_module, "os", SimpleNamespace(name="nt" if system == "Windows" else "posix"))
    monkeypatch.setattr(file_module, "_which", lambda name: None)
    monkeypatch.setattr(file_module.platform, "system", lambda: system)
    monkeypatch.setattr(file_module.platform, "machine", lambda: machine)
    monkeypatch.setattr(file_module.httpx, "Client", Client)
    target = Path(file_module._ripgrep_binary())
    assert target == file_module.data_dir() / "bin" / executable
    assert target.read_bytes() == b"controlled executable bytes"
    assert file_module._ripgrep_binary() == str(target)
    assert urls == [f"https://github.com/BurntSushi/ripgrep/releases/download/15.1.0/ripgrep-15.1.0-{triple}.{extension}"]
    assert list(target.parent.iterdir()) == [target]


def test_ripgrep_prefers_system_binary_without_http(runtime, monkeypatch):
    path = runtime.directory / "rg"
    path.write_bytes(b"existing executable")
    monkeypatch.setattr(file_module, "_which", lambda name: str(path))
    monkeypatch.setattr(file_module.httpx, "Client", lambda **kwargs: pytest.fail("system binary must avoid HTTP"))
    assert file_module._ripgrep_binary() == str(path)


def test_ripgrep_abort_stops_process_blocked_on_stdout(runtime, monkeypatch):
    abort = threading.Event()
    started = threading.Event()
    processes, errors = [], []
    original = file_module.subprocess.Popen

    def spawn(*args, **kwargs):
        process = original(*args, **kwargs)
        processes.append(process)
        started.set()
        return process

    def run():
        try:
            file_module._ripgrep(runtime.directory, ["-c", "import time; time.sleep(60)"],
                                 lambda line: line, abort=abort)
        except Exception as error:
            errors.append(error)

    monkeypatch.setattr(file_module, "_ripgrep_binary", lambda **kwargs: sys.executable)
    monkeypatch.setattr(file_module.subprocess, "Popen", spawn)
    worker = threading.Thread(target=run)
    worker.start()
    try:
        assert started.wait(3)
        abort.set()
        worker.join(3)
        assert not worker.is_alive()
        assert len(errors) == 1 and isinstance(errors[0], PermissionRejected)
        assert processes[0].poll() is not None
        assert processes[0].stdout.closed and processes[0].stderr.closed
        assert not any(thread.name == "opencode-ripgrep-abort" for thread in threading.enumerate())
    finally:
        abort.set()
        for process in processes:
            if process.poll() is None:
                process.kill()
        worker.join(3)


def test_ripgrep_normal_completion_leaves_no_abort_watcher(runtime, monkeypatch):
    monkeypatch.setattr(file_module, "_ripgrep_binary", lambda **kwargs: sys.executable)
    assert file_module._ripgrep(runtime.directory, ["-c", "print('one')"], lambda line: line,
                                abort=threading.Event()) == ["one"]
    assert not any(thread.name == "opencode-ripgrep-abort" for thread in threading.enumerate())


@pytest.mark.parametrize("tool,pattern", [(_grep, "needle"), (_glob, "*.txt")])
def test_search_passes_current_session_abort_event(runtime, monkeypatch, tool, pattern):
    ctx = context(runtime)
    captured = []
    monkeypatch.setattr(file_module, "_ripgrep", lambda *args, **kwargs: captured.append(kwargs["abort"]) or [])
    tool({"pattern": pattern}, ctx)
    assert captured == [runtime.abort_event(ctx.session_id)]
