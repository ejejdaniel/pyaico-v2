"""Source-backed HTTP boundaries; MockTransport prevents network access."""

import json
import threading
from types import SimpleNamespace

import httpx
import pytest

from opencode.tools import web


@pytest.fixture(params=["legacy", "attempt"])
def ctx(monkeypatch, request):
    for name in ("OPENCODE_WEBSEARCH_PROVIDER", "OPENCODE_EXPERIMENTAL", "OPENCODE_ENABLE_EXA",
                 "OPENCODE_EXPERIMENTAL_EXA", "OPENCODE_ENABLE_PARALLEL", "OPENCODE_EXPERIMENTAL_PARALLEL",
                 "EXA_API_KEY", "PARALLEL_API_KEY"):
        monkeypatch.delenv(name, raising=False)
    calls = []
    return SimpleNamespace(session_id="ses_test", agent=SimpleNamespace(permission=[]),
                           abort=threading.Event() if request.param == "attempt" else None,
                           app=SimpleNamespace(permissions=SimpleNamespace(ask=lambda **kwargs: calls.append(kwargs))),
                           permission_calls=calls)


@pytest.fixture
def transport(monkeypatch):
    original = httpx.Client
    original_async = httpx.AsyncClient
    requests = []
    options = []
    def install(handler):
        def capture(request):
            requests.append(request)
            return handler(request)
        def client(**kwargs):
            options.append(kwargs)
            return original(transport=httpx.MockTransport(capture), **kwargs)
        def async_client(**kwargs):
            options.append(kwargs)
            return original_async(transport=httpx.MockTransport(capture), **kwargs)
        monkeypatch.setattr(web.httpx, "Client", client)
        monkeypatch.setattr(web.httpx, "AsyncClient", async_client)
        return requests, options
    return install


def test_fetch_preserves_http_url_headers_title_and_permission(ctx, transport):
    requests, options = transport(lambda req: httpx.Response(200, text="# already markdown", headers={"content-type": "text/markdown"}))
    result = web._webfetch({"url": "http://example.test/page"}, ctx)
    assert str(requests[0].url) == "http://example.test/page"
    assert requests[0].headers["accept"].startswith("text/markdown;q=1.0")
    assert requests[0].headers["accept-language"] == "en-US,en;q=0.9"
    assert "Chrome/143.0.0.0" in requests[0].headers["user-agent"]
    assert ctx.permission_calls[0]["patterns"] == ["http://example.test/page"]
    assert ctx.permission_calls[0]["metadata"] == {"url": "http://example.test/page"}
    assert options[0]["timeout"] == 30
    assert result.title == "http://example.test/page (text/markdown)"
    assert result.output == "# already markdown"
    assert result.metadata == {}


def test_html_markdown_preserves_structure_links_code_and_removes_script(ctx, transport):
    source = '<h1>Heading</h1><p><em>Emphasis</em> <a href="/path">link</a></p><ul><li>item</li></ul><hr><pre><code class="language-python">print(1)\n</code></pre><script>secret()</script><style>bad</style>'
    transport(lambda req: httpx.Response(200, text=source, headers={"content-type": "text/html; charset=utf-8"}))
    result = web._webfetch({"url": "https://example.test"}, ctx)
    for value in ("# Heading", "*Emphasis*", "[link](/path)", "- item", "---", "```python\nprint(1)\n```"):
        assert value in result.output
    assert "secret" not in result.output and "bad" not in result.output


def test_html_text_keeps_original_spacing_and_skips_embedded_content(ctx, transport):
    source = '<p>A <b>B</b></p><div>C &amp; D</div><iframe><p>secret<br>nested</p></iframe><object>hidden</object><embed src="x">E'
    transport(lambda req: httpx.Response(200, text=source, headers={"content-type": "text/html"}))
    assert web._webfetch({"url": "https://example.test", "format": "text"}, ctx).output == "A BC & DE"


def test_fetch_html_is_exact_and_utf8_decoder_ignores_declared_charset(ctx, transport):
    raw = b"\xef\xbb\xbf<p>caf\xc3\xa9</p>"
    transport(lambda req: httpx.Response(200, content=raw, headers={"content-type": "text/html; charset=iso-8859-1"}))
    assert web._webfetch({"url": "https://example.test", "format": "html"}, ctx).output == "<p>café</p>"


@pytest.mark.parametrize("mime, attachment", [("image/png", True), ("image/svg+xml", False),
                                              ("image/vnd.fastbidsheet", False), ("application/pdf", False)])
def test_only_source_image_types_become_attachments(ctx, transport, mime, attachment):
    transport(lambda req: httpx.Response(200, content=b"raw bytes", headers={"content-type": mime}))
    result = web._webfetch({"url": "https://example.test/file"}, ctx)
    assert bool(result.attachments) is attachment
    if attachment:
        assert result.output == "Image fetched successfully"
        assert result.attachments == [{"mime": mime, "url": "data:image/png;base64,cmF3IGJ5dGVz"}]
    else:
        assert result.output == "raw bytes"


def test_cloudflare_challenge_retries_once_with_honest_user_agent(ctx, transport):
    def handler(req):
        if req.headers["user-agent"] != "opencode":
            return httpx.Response(403, headers={"cf-mitigated": "challenge"})
        return httpx.Response(200, text="ok")
    requests, _ = transport(handler)
    assert web._webfetch({"url": "https://example.test"}, ctx).output == "ok"
    assert len(requests) == 2
    assert requests[1].headers["user-agent"] == "opencode"
    assert requests[0].headers["accept"] == requests[1].headers["accept"]


def test_plain_forbidden_response_is_not_retried(ctx, transport):
    requests, _ = transport(lambda req: httpx.Response(403))
    with pytest.raises(httpx.HTTPStatusError):
        web._webfetch({"url": "https://example.test"}, ctx)
    assert len(requests) == 1


def test_content_length_limit_is_checked_before_body_is_read(ctx, transport):
    class Unreadable(httpx.SyncByteStream, httpx.AsyncByteStream):
        def __iter__(self):
            raise AssertionError("oversized advertised body should not be read")
            yield b""
        async def __aiter__(self):
            raise AssertionError("oversized advertised body should not be read")
            yield b""
    transport(lambda req: httpx.Response(200, stream=Unreadable(), headers={"content-length": str(web.MAX_BYTES + 1)}))
    with pytest.raises(ValueError, match="exceeds 5MB limit"):
        web._webfetch({"url": "https://example.test"}, ctx)


def test_actual_body_limit_is_checked_without_content_length(ctx, transport, monkeypatch):
    monkeypatch.setattr(web, "MAX_BYTES", 3)
    transport(lambda req: httpx.Response(200, content=b"four", headers={"content-length": "invalid"}))
    with pytest.raises(ValueError, match="exceeds 5MB limit"):
        web._webfetch({"url": "https://example.test"}, ctx)


def test_timeout_cap_zero_and_timeout_error(ctx, transport):
    _, options = transport(lambda req: httpx.Response(200, text="ok"))
    web._webfetch({"url": "https://example.test", "timeout": 999}, ctx)
    web._webfetch({"url": "https://example.test", "timeout": 0}, ctx)
    assert [item["timeout"] for item in options] == [120, 0]
    transport(lambda req: (_ for _ in ()).throw(httpx.ReadTimeout("timeout")))
    with pytest.raises(RuntimeError, match="Request timed out"):
        web._webfetch({"url": "https://example.test"}, ctx)


def test_invalid_url_fails_before_permission(ctx):
    with pytest.raises(ValueError, match="URL must start"):
        web._webfetch({"url": "file:///private"}, ctx)
    assert not ctx.permission_calls


def test_search_provider_uses_override_flags_then_source_checksum(ctx, monkeypatch):
    assert web._search_provider("a") == "exa"
    assert web._search_provider("b") == "parallel"
    assert web._search_provider("") == "exa"
    monkeypatch.setenv("OPENCODE_EXPERIMENTAL", "true")
    assert web._search_provider("b") == "exa"
    monkeypatch.setenv("OPENCODE_ENABLE_PARALLEL", "1")
    assert web._search_provider("a") == "parallel"
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    assert web._search_provider("a") == "exa"


def search_result(text="source result"):
    return {"result": {"content": [{"type": "text", "text": text}]}}


def test_exa_jsonrpc_defaults_key_encoding_and_metadata(ctx, transport, monkeypatch):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    monkeypatch.setenv("EXA_API_KEY", "a b&=+")
    requests, options = transport(lambda req: httpx.Response(200, json=search_result()))
    result = web._websearch({"query": "actual question"}, ctx)
    request = requests[0]
    assert str(request.url) == "https://mcp.exa.ai/mcp?exaApiKey=a%20b%26%3D%2B"
    assert json.loads(request.content) == {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {
        "name": "web_search_exa", "arguments": {"query": "actual question", "type": "auto", "numResults": 8, "livecrawl": "fallback"}}}
    assert request.headers["accept"] == "application/json, text/event-stream"
    assert "authorization" not in request.headers and "x-api-key" not in request.headers
    assert options[0]["timeout"] == 25
    assert result.title == "Exa Web Search: actual question"
    assert result.output == "source result" and result.metadata == {"provider": "exa"}
    assert ctx.permission_calls[0]["metadata"] == {"query": "actual question", "provider": "exa"}


def test_exa_forwards_all_options_without_local_integer_conversion(ctx, transport, monkeypatch):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    requests, _ = transport(lambda req: httpx.Response(200, json=search_result()))
    args = {"query": "q", "numResults": 2.5, "type": "deep", "livecrawl": "preferred", "contextMaxCharacters": 1200.5}
    web._websearch(args, ctx)
    assert json.loads(requests[0].content)["params"]["arguments"] == args
    assert ctx.permission_calls[0]["metadata"] == {**args, "provider": "exa"}


def test_parallel_jsonrpc_auth_model_and_sse(ctx, transport, monkeypatch):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "parallel")
    monkeypatch.setenv("PARALLEL_API_KEY", "parallel-secret")
    ctx.message_id = "msg_current"
    ctx.app.store = SimpleNamespace(messages=lambda sid: [{"id": "msg_current", "model": "local/" + "x" * 110}])
    body = "event: message\ndata: " + json.dumps(search_result("SSE result")) + "\n\n"
    requests, _ = transport(lambda req: httpx.Response(200, text=body, headers={"content-type": "text/event-stream"}))
    result = web._websearch({"query": "q", "numResults": 25, "type": "deep"}, ctx)
    assert str(requests[0].url) == "https://search.parallel.ai/mcp"
    assert json.loads(requests[0].content)["params"] == {"name": "web_search", "arguments": {
        "objective": "q", "search_queries": ["q"], "session_id": ctx.session_id, "model_name": "x" * 100}}
    assert requests[0].headers["authorization"] == "Bearer parallel-secret"
    assert requests[0].headers["user-agent"] == "opencode/1.18.9"
    assert result.title == "Parallel Web Search: q" and result.output == "SSE result"


@pytest.mark.parametrize("body", ["", "event: ping\ndata: [DONE]\n", json.dumps(search_result(""))])
def test_empty_search_response_uses_source_message(ctx, transport, monkeypatch, body):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "parallel")
    requests, _ = transport(lambda req: httpx.Response(200, text=body))
    assert web._websearch({"query": "q"}, ctx).output == "No search results found. Please try a different query."
    assert "model_name" not in json.loads(requests[0].content)["params"]["arguments"]


@pytest.mark.parametrize("body", ['{"error": {"message": "bad"}}', '{"result":{"content":[{"type":"text"}]}}', '{bad'])
def test_malformed_search_response_fails_instead_of_becoming_empty(body):
    with pytest.raises(ValueError):
        web._parse_search_response(body)


def test_search_selects_first_nonempty_content_and_does_not_concatenate():
    body = json.dumps({"result": {"content": [{"type": "text", "text": ""}, {"type": "text", "text": "first"},
                                              {"type": "text", "text": "second"}]}})
    assert web._parse_search_response(body) == "first"


def test_search_timeout_fails_without_fallback(ctx, transport, monkeypatch):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    requests, _ = transport(lambda req: (_ for _ in ()).throw(httpx.ReadTimeout("timeout")))
    with pytest.raises(RuntimeError, match="web_search_exa request timed out"):
        web._websearch({"query": "q"}, ctx)
    assert len(requests) == 1


def test_only_approved_search_number_schema_is_expanded():
    fetch, search = web.web_tools()
    assert fetch.parameters["properties"]["timeout"]["type"] == "integer"
    assert search.parameters["properties"]["numResults"]["type"] == "number"
    assert search.parameters["properties"]["contextMaxCharacters"]["type"] == "number"
