"""The runner's own records and other runs read as missing to the agent's tools; no model/network calls."""

import json
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.config import validate_config
from opencode.hidden import Hidden
from opencode.permission import Broker, Rule
from opencode.store import Store
from opencode.tools import files as file_module, shell
from opencode.tools.files import _glob, _grep, _read, _write
from scripts.recording import hidden_paths

# v20 found the runner's records with `ls -la ..` and then read its own model request.
LISTING = """total 258
drwxr-xr-x 1 u 197121      0 Oct 27 20:10 .
-rw-r--r-- 1 u 197121   6474 Oct 27 20:10 cli-transcript.txt
-rw-r--r-- 1 u 197121 139383 Oct 27 20:10 request-001.json
-rw-r--r-- 1 u 197121   1828 Oct 27 20:10 settings.json
drwxr-xr-x 1 u 197121      0 Oct 27 20:10 state
drwxr-xr-x 1 u 197121      0 Oct 27 20:10 wire-001
drwxr-xr-x 1 u 197121      0 Oct 27 20:10 workspace"""


@pytest.fixture
def layout(tmp_path):
    runs = tmp_path / "outputs"
    run = runs / "lit_run_20261027_v20"
    workspace = run / "workspace"
    other = runs / "lit_run_20261026_v14"
    contents = {
        other / "workspace/report.md": "the known answer",
        run / "request-001.json": "{}", run / "response-001.json": "{}", run / "wire-001/request.body.json": "{}",
        run / "settings.json": "{}", run / "state/opencode/opencode.db": "db", run / "data/opencode/log/run.log": "log",
        run / "data/opencode/tool-output/tool_1": "saved long output", run / "temp/scratch.txt": "scratch",
        workspace / "notes.md": "notes", workspace / "request-ideas.md": "ideas",
        workspace / "docs/guide.md": "Read [the reference](../research-practice/ref.md).",
    }
    for path, text in contents.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    project = tmp_path / "project"
    project.mkdir()
    spec = hidden_paths([run, run], visible=[workspace, run / "temp", run / "data/opencode/plans",
                                             run / "data/opencode/tool-output"], keep=[project])
    return SimpleNamespace(runs=runs, run=run, workspace=workspace, other=other, project=project, spec=spec)


def test_the_runner_hides_its_records_and_the_runs_beside_it_but_not_what_the_agent_uses(layout):
    assert layout.spec["roots"] == [str(layout.run.resolve()), str(layout.runs.resolve())]
    assert "lit_run_20261026_v14" in layout.spec["names"] and "lit_run_20261027_v20" not in layout.spec["names"]
    hidden = Hidden(**layout.spec)
    for path in ("request-001.json", "settings.json", "state", "data/opencode/log/run.log", "wire-001"):
        assert hidden.hides(layout.run / path), path
    assert hidden.hides(layout.other) and hidden.hides(layout.other / "workspace/report.md")
    for path in (layout.run, layout.runs, layout.workspace / "notes.md", layout.run / "temp/scratch.txt",
                 layout.run / "data", layout.run / "data/opencode/tool-output/tool_1", layout.project):
        assert not hidden.hides(path), path
    # A folder that also holds what the agent uses (the project, its interpreter) is not hidden.
    inside = hidden_paths([layout.run], visible=[layout.workspace], keep=[layout.runs / "project"])
    assert inside["roots"] == [str(layout.run.resolve())]


@pytest.fixture
def app(layout, tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(tmp_path / "config"))
    for name in ("DATA", "CONFIG", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{name}_HOME", str(tmp_path / name.lower()))
    (layout.workspace / ".git").mkdir()
    app = App(layout.workspace, store=Store(tmp_path / "state.db"),
              config={"model": "local/parent", "hidden": layout.spec}, auto_approve=True)
    app.generate_titles = False
    yield app
    app.store.close()


def context(app):
    session = app.create_session(model="local/parent")["id"]
    return SimpleNamespace(app=app, session_id=session, agent=app.agents["build"], directory=app.directory,
                           worktree=app.worktree, depth=0, turn=1, read_files=set())


def test_the_file_tools_treat_host_records_as_missing(app, layout):
    ctx = context(app)
    for path in (layout.run / "request-001.json", layout.run / "settings.json", layout.other / "workspace/report.md"):
        with pytest.raises(FileNotFoundError, match="does not exist"):
            _read({"filePath": str(path)}, ctx)
    with pytest.raises(FileNotFoundError, match="does not exist"):
        _write({"filePath": str(layout.run / "settings.json"), "content": "{}"}, ctx)
    # The run folder lists only what the agent uses; a near miss suggests no hidden name.
    listing = _read({"filePath": str(layout.run)}, ctx).output
    assert "workspace/" in listing and "temp/" in listing and "data/" in listing
    assert "request-001.json" not in listing and "settings.json" not in listing and "state/" not in listing
    with pytest.raises(FileNotFoundError) as missing:
        _read({"filePath": str(layout.run / "request")}, ctx)
    assert "request-001.json" not in str(missing.value)
    assert "saved long output" in _read({"filePath": str(layout.run / "data/opencode/tool-output/tool_1")}, ctx).output
    assert "notes" in _read({"filePath": str(layout.workspace / "notes.md")}, ctx).output


def test_search_results_leave_out_host_records(app, layout, monkeypatch):
    ctx = context(app)

    def ripgrep(cwd, args, parse, **kwargs):
        if "--json" in args:
            lines = [json.dumps({"type": "match", "data": {
                "path": {"text": path}, "lines": {"text": "needle"}, "line_number": 1, "absolute_offset": 0,
                "submatches": []}}) for path in ("settings.json", "workspace/notes.md", "../lit_run_20261026_v14/x")]
        else:
            lines = ["request-001.json", "workspace/notes.md", "state/opencode/opencode.db"]
        return [row for row in map(parse, lines) if row is not None]

    monkeypatch.setattr(file_module, "_ripgrep", ripgrep)
    found = _grep({"pattern": "needle", "path": str(layout.run)}, ctx)
    assert found.metadata["matches"] == 1 and "notes.md" in found.output and "settings.json" not in found.output
    listed = _glob({"pattern": "**/*", "path": str(layout.run)}, ctx).output.splitlines()
    assert listed == [str((layout.run / "workspace/notes.md").resolve())]


@pytest.fixture
def ctx(layout, monkeypatch):
    abort = threading.Event()
    app = SimpleNamespace(config={"hidden": layout.spec}, permissions=Broker(auto=True), abort_event=lambda _: abort)
    monkeypatch.setattr(shell, "_shell_executable", lambda config=None: "bash")
    return SimpleNamespace(app=app, directory=layout.workspace, worktree=layout.workspace, session_id="hidden",
                           agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]))


def shell_output(monkeypatch, text):
    ran = []

    def run(command, cwd, env, timeout, abort, **kwargs):
        ran.append(command)
        kwargs["on_chunk"](text)
        return "", "", 0, ""

    monkeypatch.setattr(shell, "_run", run)
    return ran


@pytest.mark.parametrize("command,named", [
    ("cat ../request-001.json", "request-001.json"),
    ("cd .. && cat settings.json", "settings.json"),
    ("ls ../state", "../state"),
    ("python -c \"print(open('../settings.json').read())\"", "../settings.json"),
    ("cat ../../lit_run_20261026_v14/workspace/report.md", "lit_run_20261026_v14"),
    ("head ../*.json", "../*.json"),
])
def test_a_command_naming_a_host_record_is_answered_as_a_missing_file_without_running(ctx, monkeypatch, command, named):
    ran = shell_output(monkeypatch, "should not run")
    result = shell._bash({"command": command}, ctx)
    assert ran == []
    assert result.output.startswith(f"{named}: No such file or directory")
    assert result.metadata["exit"] == 1 and "Command exited with code 1." in result.output


def test_a_hidden_working_folder_reads_as_missing(ctx, layout, monkeypatch):
    ran = shell_output(monkeypatch, "should not run")
    result = shell._bash({"command": "ls", "workdir": str(layout.run / "state")}, ctx)
    assert ran == [] and "No such file or directory" in result.output


@pytest.mark.parametrize("command", ["cat notes.md", "ls -la ..", "cat ../temp/scratch.txt",
                                     "cat ../data/opencode/tool-output/tool_1", "cat request-ideas.md",
                                     "cat docs/guide.md"])
def test_ordinary_commands_run(ctx, monkeypatch, command):
    ran = shell_output(monkeypatch, "done")
    assert shell._bash({"command": command}, ctx).output == "done"
    assert ran == [command]


def test_output_lines_naming_host_records_are_dropped(ctx, layout, monkeypatch):
    shell_output(monkeypatch, LISTING)
    shown = shell._bash({"command": "ls -la .."}, ctx).output.splitlines()
    # v21 saw settings.json and state listed here and then could not open them: a listed entry that
    # reads as missing is left out of the listing too.
    assert [line.split()[-1] for line in shown[1:]] == [".", "workspace"]
    shell_output(monkeypatch, "data/\nsettings.json\nstate/\ntemp/\nworkspace/\n")
    assert shell._bash({"command": "cd .. && ls -p"}, ctx).output == "data/\ntemp/\nworkspace/\n"
    assert shell._bash({"command": "ls -p", "workdir": str(layout.run)}, ctx).output == "data/\ntemp/\nworkspace/\n"
    # A listing of the workspace keeps an entry that shares a name with a host record up there.
    (layout.workspace / "state").mkdir()
    shell_output(monkeypatch, "notes.md\nstate\n")
    assert shell._bash({"command": "ls"}, ctx).output == "notes.md\nstate\n"
    shell_output(monkeypatch, "lit_run_20261026_v14\nlit_run_20261027_v20\n")
    assert shell._bash({"command": "ls ../.."}, ctx).output == "lit_run_20261027_v20\n"
    # grep -rn over the parent: a line from a hidden file goes, one from the workspace stays.
    shell_output(monkeypatch, '../settings.json:1:{"config": 1}\n../workspace/notes.md:1:notes\n')
    assert shell._bash({"command": "grep -rn . .."}, ctx).output == "../workspace/notes.md:1:notes\n"
    # A document's relative link names nothing that exists up there, so the line stays.
    link = "Read [the reference](../research-practice/ref.md)."
    shell_output(monkeypatch, link)
    assert shell._bash({"command": "cat docs/guide.md"}, ctx).output == link


def test_the_saved_full_output_is_cleaned_too(ctx, monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    ctx.app.config["tool_output"] = {"max_lines": 3, "max_bytes": 200}
    shell_output(monkeypatch, "\n".join(f"request-{index:03}.json\nkept {index}" for index in range(1, 40)))
    result = shell._bash({"command": "ls -1 .."}, ctx)
    saved = Path(result.metadata["outputPath"]).read_text(encoding="utf-8")
    assert "kept 39" in saved and "request-" not in saved
    assert "request-" not in result.output and "request-" not in result.metadata["output"]


def test_a_command_with_no_hidden_lines_left_says_so(ctx, monkeypatch):
    shell_output(monkeypatch, "request-001.json\nresponse-001.json\n")
    assert shell._bash({"command": "ls -1 .. | grep json"}, ctx).output == "(no output)"


@pytest.mark.parametrize("spec,message", [
    ({"roots": "D:/runs"}, "hidden.roots must be a list"),
    ({"roots": ["runs"]}, "hidden.roots must list absolute paths"),
    ({"names": ["("]}, "hidden.names has an invalid pattern"),
    ({"paths": []}, "hidden must be an object with roots, visible and names"),
])
def test_a_malformed_hidden_setting_is_refused(spec, message):
    with pytest.raises(ValueError, match=message):
        validate_config({"hidden": spec})
