"""Approved PDF/input-capability parity at the actual HTTP request boundary.

All catalog and completion responses are fixtures; no real model or network is used.
"""

import base64
from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode import provider as module
from opencode.config import validate_config
from opencode.media import SYNTHETIC_ATTACHMENT_PROMPT, attachment_from_bytes
from opencode.provider import Client, ProviderError, openai_messages_from_history


PDF_BYTES = b"%PDF-1.7\n% isolated transport fixture\n\x00\xff\x80\n%%EOF\n"
IMAGE_BYTES = b"\x89PNG\r\n\x1a\n\x00\xff\x80fixture"
KINDS = ["text", "audio", "image", "video", "pdf"]
EMPTY_IMAGE_ERROR = "ERROR: Image file is empty or corrupted. Please provide a valid image."


@pytest.fixture(autouse=True)
def isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_temperature_catalog", None)
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(name, str(tmp_path / name))

    def forbidden(*args, **kwargs):
        raise AssertionError("This test must not open a real network connection")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


def client_for(definition=None, *, api="openai", provider_id="test", model="model"):
    config = {"provider": {provider_id: {"api": api, "options": {
        "baseURL": "https://invalid.example/v1", "apiKey": "fixture-token"},
        "models": {model: {} if definition is None else definition}}}}
    client = Client(SimpleNamespace(get=lambda _: None), config)
    provider, resolved = client.resolve(provider_id + "/" + model)
    return client, provider, resolved


def install_http(monkeypatch, api="openai", *, catalog=None, catalog_status=200, streaming=False):
    """Capture serialized bodies, keeping both synchronous and async paths offline."""
    sent, fetched = [], []

    def receive(request):
        if request.method == "GET":
            assert str(request.url) == "https://models.dev/api.json"
            fetched.append(request)
            assert catalog is not None or catalog_status != 200, "An explicit input capability must not fetch the catalog"
            return httpx.Response(catalog_status, json=catalog)
        assert request.method == "POST"
        assert str(request.url) == "https://invalid.example/v1/" + ("messages" if api == "anthropic" else "chat/completions")
        sent.append(json.loads(request.content))
        if api == "openai":
            data = {"choices": [{"message": {"content": "done"}, "finish_reason": "stop"}]}
            events = [{"choices": [{"delta": {"content": "done"}, "finish_reason": "stop"}]}]
        else:
            data = {"content": [{"type": "text", "text": "done"}], "stop_reason": "end_turn"}
            events = [{"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": "done"}},
                      {"type": "message_delta", "delta": {"stop_reason": "end_turn"}}, {"type": "message_stop"}]
        if streaming:
            return httpx.Response(200, text="".join("data: " + json.dumps(event) + "\n\n" for event in events))
        return httpx.Response(200, json=data)

    transport = httpx.MockTransport(receive)
    real_client, real_async_client = httpx.Client, httpx.AsyncClient
    monkeypatch.setattr(module.httpx, "Client", lambda **kwargs: real_client(transport=transport, **kwargs))
    monkeypatch.setattr(module.httpx, "AsyncClient", lambda **kwargs: real_async_client(transport=transport, **kwargs))
    return sent, fetched


def complete(client, provider, model, messages, *, direct=False, streaming=False):
    on_text = (lambda _: None) if streaming else None
    if direct:
        transport = client._anthropic if provider.api == "anthropic" else client._openai
        return transport(provider, "fixture-token", model, "System instruction", messages, [], 0.2, on_text)
    return client.complete(provider=provider, model=model, system="System instruction", messages=messages,
                           temperature=0.2, on_text=on_text)


def model_definition(modalities):
    return {"modalities": modalities, "temperature": True,
            "limit": {"output": 321}, "options": {"top_p": 0.8, "reasoningEffort": "high"}}


def pdf_messages():
    return openai_messages_from_history([{"role": "user", "content": "Inspect this file", "attachments": [
        attachment_from_bytes(PDF_BYTES, "application/pdf", filename="source.pdf")]}])


def media_parts(body, media_type):
    return [part for message in body["messages"] if isinstance(message.get("content"), list)
            for part in message["content"] if part.get("type") == media_type]


def error_for(filename="source.pdf", modality="pdf"):
    name = f'"{filename}"' if filename else modality
    return f"ERROR: Cannot read {name} (this model does not support {modality} input). Inform the user."


@pytest.mark.parametrize("definition", [
    {}, {"modalities": {}}, {"modalities": {"input": []}}, {"modalities": {"output": []}},
    {"modalities": {"input": KINDS}}, {"modalities": {"output": KINDS}},
    {"modalities": {"input": ["pdf", "pdf"], "output": ["text", "text"]}},
])
def test_optional_modalities_schema_accepts_source_values_without_mutation(definition):
    config = {"provider": {"p": {"models": {"m": definition}}}}
    before = deepcopy(config)
    validate_config(config)
    assert config == before


@pytest.mark.parametrize("modalities", [None, False, 0, "pdf", [], ["pdf"]])
def test_modalities_schema_rejects_nonobjects(modalities):
    with pytest.raises(ValueError, match=r"provider.p.models.m.modalities"):
        validate_config({"provider": {"p": {"models": {"m": {"modalities": modalities}}}}})


@pytest.mark.parametrize("direction", ["input", "output"])
@pytest.mark.parametrize("value", [None, "pdf", True, 0, {}, [None], [1], [True], ["PDF"], ["document"], ["text", "unknown"]])
def test_modalities_schema_rejects_nonarrays_and_invalid_members(direction, value):
    with pytest.raises(ValueError, match=rf"provider.p.models.m.modalities.{direction}"):
        validate_config({"provider": {"p": {"models": {"m": {"modalities": {direction: value}}}}}})


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("modalities", [None, [], {"input": None}, {"input": "pdf"}, {"input": ["document"]}])
def test_direct_client_rejects_invalid_capability_before_any_request(monkeypatch, api, modalities):
    client, provider, model = client_for(model_definition(modalities), api=api)
    sent, fetched = install_http(monkeypatch, api)
    with pytest.raises(ProviderError, match="modalities"):
        complete(client, provider, model, pdf_messages(), direct=True)
    assert not sent and not fetched


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("source", ["user", "tool"])
@pytest.mark.parametrize("supported", [False, True])
@pytest.mark.parametrize("streaming", [False, True])
def test_pdf_support_changes_only_wire_attachment_preserving_history_and_bytes(monkeypatch, api, source, supported, streaming):
    attachment = attachment_from_bytes(PDF_BYTES, "application/pdf", filename="results.pdf")
    if source == "user":
        history = [{"role": "user", "content": "Inspect this file", "attachments": [attachment]}]
        prompt = "Inspect this file"
    else:
        history = [{"role": "assistant", "content": "Read the generated artifact",
                    "tool_calls": [{"id": "call_1", "name": "read", "arguments": {"filePath": "/fixture/results.pdf"}}]},
                   {"role": "tool", "tool_call_id": "call_1", "content": "PDF read successfully", "attachments": [attachment]}]
        prompt = SYNTHETIC_ATTACHMENT_PROMPT
    history_before = deepcopy(history)
    messages = openai_messages_from_history(history)
    messages_before = deepcopy(messages)
    client, provider, model = client_for(model_definition({"input": ["text", "pdf"] if supported else ["text"]}), api=api)
    sent, fetched = install_http(monkeypatch, api, streaming=streaming)
    assert complete(client, provider, model, messages, streaming=streaming).text == "done"
    assert len(sent) == 1 and not fetched
    assert history == history_before and messages == messages_before
    body = sent[0]
    assert body["model"] == model and body["max_tokens"] == 321 and body["temperature"] == 0.2
    parts = body["messages"][-1]["content"]
    # Anthropic merges a tool result and its synthetic user message, preserving order.
    if source == "tool" and api == "anthropic":
        assert parts[0] == {"type": "tool_result", "tool_use_id": "call_1", "content": "PDF read successfully"}
        parts = parts[1:]
    assert parts[0] == {"type": "text", "text": prompt}
    assert len(parts) == 2
    if supported:
        if api == "openai":
            assert parts[1] == {"type": "file", "file": {"filename": "results.pdf", "file_data": attachment["url"]}}
            encoded = parts[1]["file"]["file_data"].split(",", 1)[1]
        else:
            assert parts[1]["type"] == "document"
            assert parts[1]["source"]["type"] == "base64"
            assert parts[1]["source"]["media_type"] == "application/pdf"
            encoded = parts[1]["source"]["data"]
        assert base64.b64decode(encoded) == PDF_BYTES
    else:
        assert parts[1] == {"type": "text", "text": error_for("results.pdf")}
    if api == "openai":
        assert body["top_p"] == 0.8 and body["reasoning_effort"] == "high"
        assert body["messages"][:-1] == [{"role": "system", "content": "System instruction"}, *messages_before[:-1]]
    else:
        assert body["system"] == "System instruction"


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_direct_transport_cannot_bypass_capability_and_preserves_mixed_part_order(monkeypatch, api):
    client, provider, model = client_for(model_definition({"input": ["image"]}), api=api)
    image = attachment_from_bytes(IMAGE_BYTES, "image/png")
    messages = [{"role": "user", "content": [
        {"type": "text", "text": "before"}, pdf_messages()[0]["content"][1],
        {"type": "text", "text": "middle"}, {"type": "image_url", "image_url": {"url": image["url"]}},
        {"type": "text", "text": "after"}]}]
    before = deepcopy(messages)
    sent, fetched = install_http(monkeypatch, api)
    complete(client, provider, model, messages, direct=True)
    assert messages == before and not fetched
    parts = sent[0]["messages"][-1]["content"]
    assert [part.get("text") for part in parts] == ["before", error_for(), "middle", None, "after"]
    if api == "openai":
        assert parts[3] == messages[0]["content"][3]
    else:
        assert base64.b64decode(parts[3]["source"]["data"]) == IMAGE_BYTES


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("input_kinds", [[], ["text"], ["image"]])
@pytest.mark.parametrize("empty", [False, True])
def test_image_input_uses_same_capability_and_prioritizes_empty_image_error(monkeypatch, api, input_kinds, empty):
    url = "data:image/png;base64," + ("" if empty else base64.b64encode(IMAGE_BYTES).decode())
    messages = [{"role": "user", "content": [{"type": "image_url", "image_url": {"url": url}}]}]
    client, provider, model = client_for(model_definition({"input": input_kinds}), api=api)
    sent, fetched = install_http(monkeypatch, api)
    complete(client, provider, model, messages)
    assert not fetched
    parts = sent[0]["messages"][-1]["content"]
    if empty or "image" not in input_kinds:
        assert parts == [{"type": "text", "text": EMPTY_IMAGE_ERROR if empty else error_for("", "image")}]
    elif api == "openai":
        assert parts == messages[0]["content"]
    else:
        assert base64.b64decode(parts[0]["source"]["data"]) == IMAGE_BYTES


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("modalities,supported", [({}, True), ({"output": []}, True), ({"input": []}, False),
                                                       ({"input": ["image"]}, False), ({"input": ["pdf"]}, True)])
def test_omitted_input_inherits_exact_catalog_and_explicit_array_replaces_it(monkeypatch, api, modalities, supported):
    client, provider, model = client_for(model_definition(modalities), api=api)
    catalog = {"test": {"models": {"model": {"modalities": {"input": ["text", "pdf"], "output": ["text"]}}}}}
    sent, fetched = install_http(monkeypatch, api, catalog=catalog)
    complete(client, provider, model, pdf_messages())
    assert len(fetched) == (0 if "input" in modalities else 1)
    assert bool(media_parts(sent[0], "file" if api == "openai" else "document")) is supported
    if not supported:
        assert sent[0]["messages"][-1]["content"][-1] == {"type": "text", "text": error_for()}


@pytest.mark.parametrize("provider_id,model,definition", [
    ("other", "model", {}), ("test", "MODEL", {}), ("test", "unknown-vision-pdf", {}),
    ("test", "alias", {"id": "model"}), ("test", "missing-modalities", {}),
])
def test_catalog_capability_never_leaks_across_provider_model_or_alias(monkeypatch, provider_id, model, definition):
    client, provider, actual_model = client_for({"temperature": False, **definition}, provider_id=provider_id, model=model)
    catalog = {"test": {"models": {"model": {"modalities": {"input": ["pdf"], "output": ["text"]}}, "missing-modalities": {}}}}
    sent, fetched = install_http(monkeypatch, catalog=catalog)
    complete(client, provider, actual_model, pdf_messages())
    assert len(fetched) == 1
    assert sent[0]["model"] == model
    assert not media_parts(sent[0], "file")
    assert sent[0]["messages"][-1]["content"][-1] == {"type": "text", "text": error_for()}


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_text_only_request_does_not_add_catalog_lookup(monkeypatch, api):
    client, provider, model = client_for({"temperature": True}, api=api)
    sent, fetched = install_http(monkeypatch, api)
    messages = [{"role": "user", "content": "No attachment"}]
    complete(client, provider, model, messages)
    assert len(sent) == 1 and not fetched
    assert sent[0]["messages"][-1] == messages[0]


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_catalog_failure_is_not_reported_as_unsupported_and_cannot_dispatch(monkeypatch, api):
    client, provider, model = client_for({"temperature": False}, api=api)
    sent, fetched = install_http(monkeypatch, api, catalog_status=401)
    messages = pdf_messages()
    before = deepcopy(messages)
    with pytest.raises(ProviderError, match="catalog"):
        complete(client, provider, model, messages)
    assert len(fetched) == 1 and not sent
    assert messages == before


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_transient_catalog_failure_has_three_fetches_and_never_enters_model_retry(monkeypatch, api):
    client, provider, model = client_for({"temperature": False}, api=api)
    sent, fetched = install_http(monkeypatch, api, catalog_status=503)

    async def no_delay(_):
        pass

    model_retry = Mock(side_effect=AssertionError("Catalog failure must not enter the model retry loop"))
    monkeypatch.setattr(module.asyncio, "sleep", no_delay)
    monkeypatch.setattr(module, "_retry_delay", model_retry)
    with pytest.raises(ProviderError, match="catalog"):
        complete(client, provider, model, pdf_messages())
    assert len(fetched) == 3 and not sent
    model_retry.assert_not_called()
    assert module._temperature_catalog is None


@pytest.mark.parametrize("modalities", [None, [], {"input": ["pdf"]}, {"input": None, "output": ["text"]},
                                           {"input": ["document"], "output": ["text"]}])
def test_invalid_catalog_modalities_cannot_silently_become_false_capabilities(monkeypatch, modalities):
    client, provider, model = client_for({"temperature": False})
    catalog = {"test": {"models": {"model": {"modalities": modalities}}}}
    sent, fetched = install_http(monkeypatch, catalog=catalog)
    with pytest.raises(ProviderError, match="catalog"):
        complete(client, provider, model, pdf_messages())
    assert len(fetched) == 1 and not sent
    assert module._temperature_catalog is None


@pytest.mark.parametrize("first", ["temperature", "pdf"])
def test_temperature_and_media_reuse_one_catalog_only_in_memory(monkeypatch, tmp_path, first):
    client, provider, model = client_for()
    catalog = {"test": {"models": {"model": {
        "temperature": True, "modalities": {"input": ["text", "pdf"], "output": ["text"]}}}}}
    sent, fetched = install_http(monkeypatch, catalog=catalog)
    before = set(tmp_path.rglob("*"))
    if first == "temperature":
        complete(client, provider, model, [{"role": "user", "content": "Text first"}])
        complete(client, provider, model, pdf_messages())
    else:
        # Direct scientific transport is a caller even without complete's temperature lookup.
        complete(client, provider, model, pdf_messages(), direct=True)
        complete(client, provider, model, [{"role": "user", "content": "Text next"}])
    assert len(sent) == 2 and len(fetched) == 1
    assert all(body["temperature"] == 0.2 for body in sent)
    assert any(media_parts(body, "file") for body in sent)
    assert set(tmp_path.rglob("*")) == before


@pytest.mark.parametrize("direction", ["input", "output"])
def test_each_direction_resolves_optional_explicit_array_independently(monkeypatch, direction):
    other = "output" if direction == "input" else "input"
    client, provider, model = client_for({"modalities": {direction: ["pdf", "pdf"]}})
    catalog = {"test": {"models": {"model": {"modalities": {
        "input": ["text", "image"], "output": ["text", "audio"]}}}}}
    _, fetched = install_http(monkeypatch, catalog=catalog)
    assert client._modalities(provider, model, direction) == {kind: kind == "pdf" for kind in KINDS}
    assert not fetched
    expected = {"text", "audio"} if other == "output" else {"text", "image"}
    assert client._modalities(provider, model, other) == {kind: kind in expected for kind in KINDS}
    assert len(fetched) == 1


@pytest.mark.parametrize("direction", ["input", "output"])
@pytest.mark.parametrize("known", [False, True])
def test_unknown_model_has_text_only_default_but_known_catalog_model_does_not(monkeypatch, direction, known):
    client, provider, model = client_for()
    catalog = {"test": {"models": {"model": {}} if known else {}}}
    _, fetched = install_http(monkeypatch, catalog=catalog)
    assert client._modalities(provider, model, direction) == {kind: (kind == "text" and not known) for kind in KINDS}
    assert len(fetched) == 1


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_empty_image_error_does_not_require_catalog_access(monkeypatch, api):
    client, provider, model = client_for({"temperature": False}, api=api)
    sent, fetched = install_http(monkeypatch, api)
    complete(client, provider, model, [{"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": "data:image/png;base64,"}}]}])
    assert not fetched
    assert sent[0]["messages"][-1]["content"] == [{"type": "text", "text": EMPTY_IMAGE_ERROR}]


