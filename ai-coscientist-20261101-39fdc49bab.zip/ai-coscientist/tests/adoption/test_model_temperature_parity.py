"""S21: source temperature capabilities and defaults, with no real network/model."""

import asyncio
from copy import deepcopy
import json
import math
import threading
import time
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode import provider as module
from opencode.config import validate_config
from opencode.provider import Client, Completion, ProviderError


@pytest.fixture(autouse=True)
def isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "_temperature_catalog", None)
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(name, str(tmp_path / name))

    def forbidden(*args, **kwargs):
        raise AssertionError("This test must not open a real network connection")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


def client_for(definition=None, *, api="openai", model="model"):
    config = {"provider": {"test": {"api": api, "options": {
        "baseURL": "https://invalid.example/v1", "apiKey": "fixture-token"},
        "models": {model: definition or {}},
    }}}
    client = Client(SimpleNamespace(get=lambda _: None), config)
    provider, resolved = client.resolve("test/" + model)
    return client, provider, resolved


@pytest.mark.parametrize("value", [None, 0, 1, "true", "false", [], {}])
def test_model_capability_schema_rejects_nonboolean(value):
    config = {"provider": {"p": {"models": {"m": {"temperature": value}}}}}
    with pytest.raises(ValueError, match=r"provider.p.models.m.temperature must be a boolean"):
        validate_config(config)


@pytest.mark.parametrize("value", [None, 1, "true"])
def test_direct_client_also_rejects_invalid_model_capability(monkeypatch, value):
    client, provider, model = client_for({"temperature": value})
    send = Mock()
    monkeypatch.setattr(client, "_openai", send)
    with pytest.raises(ProviderError, match="capability must be a boolean"):
        client.complete(provider=provider, model=model, system="", messages=[])
    send.assert_not_called()


@pytest.mark.parametrize("definition", [{}, {"temperature": True}, {"temperature": False}])
def test_model_capability_schema_accepts_optional_boolean_without_mutation(definition):
    config = {"provider": {"p": {"models": {"m": definition}}}}
    before = deepcopy(config)
    validate_config(config)
    assert config == before


@pytest.mark.parametrize("model,expected", [
    ("north-mini-code", 1.0), ("NORTH-MINI-CODE-qwen", 1.0), ("Qwen3", 0.55),
    ("claude-sonnet", None), ("gemini-2.5-pro", 1.0), ("gemini-2-5-flash", 1.0),
    ("gemini-3-flash-preview", 1.0), ("gemini-3-pro", 1.0),
    ("gemini-3.1-pro", 1.0), ("gemini-3-1-pro", 1.0),
    ("gemini-3.5-flash", 1.0), ("gemini-3-5-flash-preview", 1.0),
    ("gemini-3.5-flash-lite", None), ("gemini-3-flashlite", None),
    ("gemini-2.50-pro", None), ("gemini-2.0-flash", None),
    ("glm-4.6", 1.0), ("glm-4.7", 1.0), ("minimax-m2.5", 1.0),
    ("kimi-k2-thinking", 1.0), ("kimi-k2.5", 1.0), ("kimi-k2p5", 1.0),
    ("kimi-k2-5", 1.0), ("kimi-k2", 0.6), ("unknown-model", None),
])
def test_source_default_temperature_order_and_model_patterns(model, expected):
    assert module._default_temperature(model) == expected


@pytest.mark.parametrize("definition,value,model,expected", [
    ({"temperature": True}, 0, "qwen3", 0),
    ({"temperature": False}, 0, "qwen3", None),
    ({"temperature": True}, None, "qwen3", 0.55),
    ({"temperature": False}, None, "qwen3", None),
    ({"temperature": True}, 2.5, "claude", 2.5),
    ({"temperature": True}, -0.1, "other", -0.1),
    ({}, None, "other", None),
])
def test_explicit_capability_or_absent_candidate_never_loads_catalog(monkeypatch, definition, value, model, expected):
    lookup = Mock(side_effect=AssertionError("Catalog should not be needed"))
    monkeypatch.setattr(module, "_catalog_temperature", lookup)
    client, provider, model = client_for(definition, model=model)
    assert client._temperature(provider, model, value, None) == expected
    lookup.assert_not_called()


@pytest.mark.parametrize("capable", [False, True])
def test_omitted_capability_inherits_exact_catalog_entry(monkeypatch, capable):
    lookup = Mock(return_value=capable)
    monkeypatch.setattr(module, "_catalog_temperature", lookup)
    client, provider, model = client_for()
    abort = threading.Event()
    assert client._temperature(provider, model, 0, abort) == (0 if capable else None)
    lookup.assert_called_once_with("test", "model", abort)


@pytest.mark.parametrize("value", [True, "0", math.inf, -math.inf, math.nan, []])
def test_unusable_runtime_temperature_rejected_before_transport(monkeypatch, value):
    client, provider, model = client_for({"temperature": True})
    send = Mock(side_effect=AssertionError("No model request may be sent"))
    monkeypatch.setattr(client, "_openai", send)
    with pytest.raises(ProviderError, match="finite number"):
        client.complete(provider=provider, model=model, system="", messages=[], temperature=value)
    send.assert_not_called()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("streaming", [False, True])
@pytest.mark.parametrize("capable", [False, True])
def test_temperature_reaches_final_json_for_both_protocols(monkeypatch, api, streaming, capable):
    client, provider, model = client_for({"temperature": capable}, api=api)
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        if api == "openai":
            event = {"choices": [{"delta": {"content": "done"}, "finish_reason": "stop"}]}
            data = {"choices": [{"message": {"content": "done"}, "finish_reason": "stop"}]}
            events = [event]
        else:
            data = {"content": [{"type": "text", "text": "done"}], "stop_reason": "end_turn"}
            events = [{"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
                      {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "done"}},
                      {"type": "message_delta", "delta": {"stop_reason": "end_turn"}}, {"type": "message_stop"}]
        if streaming:
            return httpx.Response(200, text="".join("data: " + json.dumps(event) + "\n\n" for event in events))
        return httpx.Response(200, json=data)

    transport = httpx.MockTransport(receive)
    real_client = httpx.Client
    monkeypatch.setattr(module.httpx, "Client", lambda **kwargs: real_client(transport=transport, **kwargs))
    result = client.complete(provider=provider, model=model, system="", messages=[], temperature=0,
                             on_text=(lambda _: None) if streaming else None)
    assert result.text == "done"
    assert len(sent) == 1
    assert ("temperature" in sent[0]) is capable
    if capable:
        assert sent[0]["temperature"] == 0


def install_catalog_transport(monkeypatch, handler):
    original = httpx.AsyncClient
    monkeypatch.setattr(module.httpx, "AsyncClient", lambda **kwargs:
                        original(transport=httpx.MockTransport(handler), **kwargs))


def test_catalog_is_exact_scoped_and_reused_only_in_memory(monkeypatch, tmp_path):
    calls = []

    def receive(request):
        calls.append(request)
        return httpx.Response(200, json={"test": {"models": {
            "model": {"temperature": True}, "cold": {"temperature": False}, "missing": {}, "null": {"temperature": None}}}})

    install_catalog_transport(monkeypatch, receive)
    before = set(tmp_path.rglob("*"))
    assert module._catalog_temperature("test", "model", None) is True
    for key in [("test", "cold"), ("other", "model"), ("test", "absent"), ("test", "MODEL"), ("test", "missing"), ("test", "null")]:
        assert module._catalog_temperature(*key, None) is False
    assert len(calls) == 1
    assert calls[0].method == "GET"
    assert str(calls[0].url) == "https://models.dev/api.json"
    assert calls[0].extensions["timeout"] == {"connect": 10.0, "read": 10.0, "write": 10.0, "pool": 10.0}
    assert set(tmp_path.rglob("*")) == before


@pytest.mark.parametrize("data", [[], {"test": {}}, {"test": {"models": []}},
                                  {"test": {"models": {"m": []}}},
                                  {"test": {"models": {"m": {"temperature": "true"}}}}])
def test_bad_catalog_is_an_error_not_a_false_capability(monkeypatch, data):
    install_catalog_transport(monkeypatch, lambda _: httpx.Response(200, json=data))
    with pytest.raises(ProviderError, match="catalog"):
        module._catalog_temperature("test", "m", None)
    assert module._temperature_catalog is None


@pytest.mark.parametrize("status,expected_calls", [(401, 1), (404, 1), (429, 3), (503, 3)])
def test_catalog_http_error_is_bounded_and_prevents_model_dispatch(monkeypatch, status, expected_calls):
    calls = []

    def receive(request):
        calls.append(request)
        return httpx.Response(status)

    async def no_delay(_):
        pass

    install_catalog_transport(monkeypatch, receive)
    monkeypatch.setattr(module.asyncio, "sleep", no_delay)
    client, provider, model = client_for()
    send = Mock()
    monkeypatch.setattr(client, "_openai", send)
    with pytest.raises(ProviderError, match="Cannot load model temperature catalog"):
        client.complete(provider=provider, model=model, system="", messages=[], temperature=0)
    assert len(calls) == expected_calls
    send.assert_not_called()
    assert module._temperature_catalog is None


def test_catalog_invalid_json_is_not_cached_and_next_call_can_recover(monkeypatch):
    responses = iter([httpx.Response(200, text="not JSON"), httpx.Response(200, json={"test": {"models": {"m": {"temperature": True}}}})])
    install_catalog_transport(monkeypatch, lambda _: next(responses))
    with pytest.raises(ProviderError, match="Cannot load"):
        module._catalog_temperature("test", "m", None)
    assert module._temperature_catalog is None
    assert module._catalog_temperature("test", "m", None) is True


def test_catalog_transport_retries_are_bounded_and_can_recover(monkeypatch):
    calls = []

    def receive(request):
        calls.append(request)
        if len(calls) < 3:
            raise httpx.ConnectError("Temporary connection failure", request=request)
        return httpx.Response(200, json={"test": {"models": {"m": {"temperature": True}}}})

    async def no_delay(_):
        pass

    install_catalog_transport(monkeypatch, receive)
    monkeypatch.setattr(module.asyncio, "sleep", no_delay)
    assert module._catalog_temperature("test", "m", None) is True
    assert len(calls) == 3


@pytest.mark.parametrize("cancel", [False, True])
@pytest.mark.parametrize("stage", ["headers", "body"])
def test_catalog_deadline_or_cancel_joins_http_cleanup(monkeypatch, cancel, stage):
    entered, cleaned, abort = threading.Event(), threading.Event(), threading.Event()

    async def block():
        entered.set()
        try:
            await asyncio.Event().wait()
        finally:
            cleaned.set()

    class Body(httpx.AsyncByteStream):
        async def __aiter__(self):
            await block()
            yield b"{}"

    async def receive(_):
        if stage == "headers":
            await block()
        return httpx.Response(200, stream=Body())

    install_catalog_transport(monkeypatch, receive)
    if not cancel:
        monkeypatch.setattr(module, "_temperature_catalog_timeout", 0.05)
    outcome = []

    def run():
        try:
            module._catalog_temperature("test", "m", abort)
        except BaseException as error:
            outcome.append(error)

    worker = threading.Thread(target=run)
    worker.start()
    assert entered.wait(2)
    if cancel:
        abort.set()
    worker.join(2)
    assert not worker.is_alive()
    assert cleaned.is_set()
    assert len(outcome) == 1 and isinstance(outcome[0], ProviderError)
    assert ("aborted" if cancel else "deadline") in str(outcome[0])
    assert module._temperature_catalog is None


def test_preexisting_abort_prevents_catalog_http(monkeypatch):
    send = Mock(side_effect=AssertionError("No HTTP after cancellation"))
    monkeypatch.setattr(module, "_run_cancellable", send)
    abort = threading.Event()
    abort.set()
    with pytest.raises(ProviderError, match="aborted"):
        module._catalog_temperature("test", "m", abort)
    send.assert_not_called()


def test_cancelled_catalog_waiter_does_not_dispatch_or_block_cleanup():
    abort = threading.Event()
    module._temperature_catalog_lock.acquire()
    outcome = []

    def run():
        try:
            module._catalog_temperature("test", "m", abort)
        except ProviderError as error:
            outcome.append(error)

    worker = threading.Thread(target=run)
    try:
        worker.start()
        abort.set()
        worker.join(2)
        assert not worker.is_alive()
        assert len(outcome) == 1 and "aborted" in str(outcome[0])
    finally:
        module._temperature_catalog_lock.release()
        worker.join(2)


def observe_catalog_lock_wait(monkeypatch):
    waiting = threading.Event()
    lock = module._temperature_catalog_lock

    def acquire(**kwargs):
        acquired = lock.acquire(**kwargs)
        if not acquired:
            waiting.set()
        return acquired

    monkeypatch.setattr(module, "_temperature_catalog_lock",
                        SimpleNamespace(acquire=acquire, release=lock.release))
    return waiting


def test_cancelled_catalog_owner_hands_fetch_to_waiter_and_caches_result(monkeypatch):
    entered, cleaned = threading.Event(), threading.Event()
    owner_abort, waiter_abort = threading.Event(), threading.Event()
    waiting = observe_catalog_lock_wait(monkeypatch)
    calls, outcomes = [], {}

    async def receive(request):
        calls.append(request)
        if len(calls) == 1:
            entered.set()
            try:
                await asyncio.Event().wait()
            finally:
                cleaned.set()
        assert cleaned.is_set()
        return httpx.Response(200, json={"test": {"models": {"m": {"temperature": True}}}})

    def lookup(name, abort):
        try:
            outcomes[name] = module._catalog_temperature("test", "m", abort)
        except BaseException as error:
            outcomes[name] = error

    install_catalog_transport(monkeypatch, receive)
    owner = threading.Thread(target=lookup, args=("owner", owner_abort))
    waiter = threading.Thread(target=lookup, args=("waiter", waiter_abort))
    try:
        owner.start()
        assert entered.wait(2)
        waiter.start()
        assert waiting.wait(2)
        owner_abort.set()
        owner.join(2)
        waiter.join(2)
        assert not owner.is_alive() and not waiter.is_alive()
        assert isinstance(outcomes["owner"], ProviderError)
        assert "aborted" in str(outcomes["owner"])
        assert outcomes["waiter"] is True
        assert not waiter_abort.is_set()
        assert len(calls) == 2
        assert module._catalog_temperature("test", "m", None) is True
        assert len(calls) == 2
    finally:
        owner_abort.set()
        waiter_abort.set()
        for worker in (owner, waiter):
            if worker.ident is not None:
                worker.join(2)


def test_concurrent_first_catalog_lookups_share_one_fetch(monkeypatch):
    entered = threading.Event()
    owner_abort, waiter_abort = threading.Event(), threading.Event()
    waiting = observe_catalog_lock_wait(monkeypatch)
    calls, outcomes, response_gate = [], {}, []

    async def receive(request):
        calls.append(request)
        release = asyncio.Event()
        response_gate.append((asyncio.get_running_loop(), release))
        entered.set()
        await release.wait()
        return httpx.Response(200, json={"test": {"models": {"m": {"temperature": True}}}})

    def lookup(name, abort):
        try:
            outcomes[name] = module._catalog_temperature("test", "m", abort)
        except BaseException as error:
            outcomes[name] = error

    install_catalog_transport(monkeypatch, receive)
    owner = threading.Thread(target=lookup, args=("owner", owner_abort))
    waiter = threading.Thread(target=lookup, args=("waiter", waiter_abort))
    try:
        owner.start()
        assert entered.wait(2)
        waiter.start()
        assert waiting.wait(2)
        loop, release = response_gate[0]
        loop.call_soon_threadsafe(release.set)
        owner.join(2)
        waiter.join(2)
        assert not owner.is_alive() and not waiter.is_alive()
        assert outcomes == {"owner": True, "waiter": True}
        assert len(calls) == 1
    finally:
        owner_abort.set()
        waiter_abort.set()
        for worker in (owner, waiter):
            if worker.ident is not None:
                worker.join(2)


def test_normal_title_and_compaction_use_the_common_temperature_decision(monkeypatch, tmp_path):
    from opencode.app import App
    from opencode.compaction import compact
    from opencode.loop import _title
    from opencode.store import Store

    config = {"model": "test/model", "provider": {"test": {"options": {
        "baseURL": "https://invalid.example/v1", "apiKey": "fixture-token"},
        "models": {"model": {"temperature": False, "limit": {"context": 128, "output": 8}}}}},
        "agent": {"build": {"temperature": 0}, "title": {"temperature": 0.5}, "compaction": {"temperature": 0.2}},
        "compaction": {"tail_turns": 0}}
    store = Store(tmp_path / "session.db")
    app = App(tmp_path, store=store, config=config, auto_approve=True)
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)
    received = []

    def reply(provider, key, model, system, messages, tools, temperature, on_text, **kwargs):
        received.append(temperature)
        return Completion(text="saved result", finish_reason="stop")

    monkeypatch.setattr(app.provider, "_openai", reply)
    try:
        normal = app.create_session()["id"]
        assert app.prompt(normal, "Do the requested work")["status"] == "completed"
        titled = app.create_session()["id"]
        store.add_message(titled, "user", {"content": "Conversation"})
        provider, model = app.provider.resolve("test/model")
        _title(app, titled, "Conversation", provider, model)
        deadline = time.monotonic() + 2
        while not store.get_session(titled).get("title"):
            assert time.monotonic() < deadline
            threading.Event().wait(0.005)
        summarized = app.create_session()["id"]
        store.add_message(summarized, "user", {"content": "Objective " * 300})
        compact(app, summarized, store.context_messages(summarized), provider, model, force=True)
        assert received == [None, None, None]
    finally:
        store.close()
