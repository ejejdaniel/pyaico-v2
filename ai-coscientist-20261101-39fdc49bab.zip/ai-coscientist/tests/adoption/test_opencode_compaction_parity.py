"""Deterministic V1 compaction boundaries; no real model or research is run."""

from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.compaction import (
    CONTINUE_PROMPT, UNATTENDED_CONTINUE_PROMPT, _summary_messages, build_prompt, compact, estimate_tokens,
    exchanges, input_budget, retained_split, usable_budget, usage_overflow,
)
from opencode.context import working_context
from opencode.provider import Client, Completion, ProviderError, ToolCall, openai_messages_from_history
from opencode.store import Store, latest_human_message
from tests.prompt_view import host_facts


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    store = Store(tmp_path / "session.db")
    app = App(project, store=store, config={}, auto_approve=True)
    app.generate_titles = False
    sid = app.create_session()["id"]
    yield app, sid
    store.close()


def model(app, replies, context=32000, output=8000):
    calls = []
    provider = SimpleNamespace(id="test", context=context)
    responses = iter(replies)

    def complete(**kwargs):
        calls.append(kwargs)
        result = next(responses)
        if isinstance(result, Exception):
            raise result
        return result(kwargs) if callable(result) else result

    app.provider = SimpleNamespace(resolve=lambda target: (provider, target or "test"),
                                   output_limit=lambda p, m: output, complete=complete)
    return provider, calls


def add(app, sid, role, content="", **data):
    return app.store.add_message(sid, role, dict(content=content, **data))


def large_head(app, sid):
    human = add(app, sid, "user", "OLD_REQUEST_ONLY_IN_HISTORY")
    add(app, sid, "assistant", tool_calls=[{"id": "old", "name": "read", "arguments": {"filePath": "original.log"}}])
    result = add(app, sid, "tool", "ORIGINAL_RESULT " * 8000, tool_call_id="old", name="read")
    recent = add(app, sid, "user", "RECENT_REQUEST_MUST_STAY_VERBATIM")
    return human, result, recent


def test_estimate_matches_js_utf16_rounding_and_json_stringification():
    assert estimate_tokens("a") == 0
    assert estimate_tokens("ab") == 1
    assert estimate_tokens("中文") == 1
    assert estimate_tokens("😀😀") == 1
    assert estimate_tokens({"a": "中文"}) == 3  # {"a":"中文"}: ten UTF-16 units


def test_usable_budget_does_not_subtract_a_second_ten_percent_margin(case):
    app, sid = case
    provider, _ = model(app, [])
    assert usable_budget(app, provider, "test") == 24000
    assert input_budget(app, provider, "test", "system", []) == 24000 - estimate_tokens(["system", []])


def test_summary_prompt_uses_upstream_sections_and_updates_the_previous_anchor():
    first = build_prompt()
    updated = build_prompt("EXACT_PRIOR_STATE")
    headings = [line for line in first.splitlines() if line.startswith("## ")]
    assert headings == ["## Objective", "## Important Details", "## Work State", "## Next Move", "## Relevant Files"]
    assert "<previous-summary>\nEXACT_PRIOR_STATE\n</previous-summary>" in updated
    assert "Preserve still-true details, remove stale details" in updated
    assert "Do not propose a next" not in updated


def test_summary_media_and_long_tool_output_are_bounded_without_mutating_sources():
    history = [
        {"role": "user", "content": "Inspect", "attachments": [{"mime": "image/png", "filename": "image.png", "url": "data:image/png;base64,HUGE"}]},
        {"role": "assistant", "content": "working text", "reasoning_content": "protocol reasoning", "tool_calls": [{"id": "r", "name": "read", "arguments": {"filePath": "source"}}]},
        {"role": "tool", "tool_call_id": "r", "content": "x" * 2001,
         "attachments": [{"mime": "application/pdf", "url": "data:application/pdf;base64,HUGE"}]},
    ]
    before = deepcopy(history)
    messages = _summary_messages(history)
    assert messages[0]["content"] == "Inspect\n[Attached image/png: image.png]"
    assert messages[1]["content"] == "working text"
    assert messages[1]["reasoning_content"] == "protocol reasoning"
    assert messages[2]["content"] == "x" * 2000 + "\n[Tool output truncated for compaction: omitted 1 chars]"
    assert "base64" not in json.dumps(messages)
    assert history == before


def test_previous_summary_is_not_summarized_again_as_a_new_assistant_turn():
    history = [{"role": "assistant", "content": "old anchor", "compaction_through": "old", "finish_reason": "stop"},
               {"role": "assistant", "content": "new observation"}]
    result = _summary_messages(history, summary="old anchor")
    assert [m["content"] for m in result[:-1]] == ["new observation"]
    assert result[-1]["content"].count("old anchor") == 1


def test_different_summary_model_gets_reasoning_as_text_instead_of_native_protocol():
    original = {"role": "assistant", "model": "old/model", "content": "observation", "reasoning_content": "reasoning"}
    message = _summary_messages([original], model_ref="new/model")[0]
    assert "reasoning_content" not in message
    assert message["content"] == "reasoning\n\nobservation"
    assert original["reasoning_content"] == "reasoning"


def test_retention_can_keep_the_end_of_the_preceding_oversized_turn():
    history = [
        {"role": "user", "content": "older turn"},
        {"role": "assistant", "content": "x" * 10000},
        {"role": "assistant", "content": "KEEP_PRECEDING_SUFFIX"},
        {"role": "user", "content": "newest turn"},
        {"role": "assistant", "content": "newest answer"},
    ]
    groups = exchanges(history)
    assert retained_split(groups, 200) == 2


def test_retention_does_not_split_calls_from_results_and_limits_to_two_turns():
    history = []
    for index in range(4):
        history.extend([{"role": "user", "content": str(index)},
                        {"role": "assistant", "tool_calls": [{"id": str(index), "name": "read", "arguments": {}}]},
                        {"role": "tool", "tool_call_id": str(index), "content": "result"}])
    groups = exchanges(history)
    retained = [m for group in groups[retained_split(groups, 8000):] for m in group]
    assert retained == history[6:]


def test_if_everything_fits_recent_budget_the_whole_history_is_summarized():
    groups = exchanges([{"role": "user", "content": "one"}, {"role": "assistant", "content": "two"}])
    assert retained_split(groups, 8000) == len(groups)


def test_one_summary_call_excludes_tail_and_restart_only_reads_summary_and_tail(case):
    app, sid = case
    old, tool, recent = large_head(app, sid)
    before = deepcopy(app.store.messages(sid))
    provider, calls = model(app, [Completion(text="anchored state", finish_reason='stop')])
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert len(calls) == 1
    request = json.dumps(calls[0]["messages"])
    assert old["content"] in request and recent["content"] not in request
    assert calls[0]["tools"] is None
    assert "truncated for compaction" in request
    assert app.store.messages(sid)[:len(before)] == before
    restarted = Store(app.store.path)
    try:
        context = restarted.context_messages(sid)
        assert context[0]["compaction_through"] == tool["id"]
        assert context[1] == recent
        assert context[-1]["content"] == continue_prompt(app) and context[-1]["synthetic"]
        assert latest_human_message(restarted.messages(sid)) == recent
        assert old["content"] not in json.dumps(working_context(context, restarted, sid))
    finally:
        restarted.close()


@pytest.mark.parametrize("context,expected", [(4000, 2000), (24000, 4000), (128000, 8000)])
def test_recent_budget_is_usable_quarter_clamped_to_two_to_eight_thousand(case, context, expected):
    app, sid = case
    large_head(app, sid)
    provider, calls = model(app, [Completion(text="short state", finish_reason='stop')], context=context, output=min(context // 3, 8000))
    with patch("opencode.compaction.retained_split", wraps=retained_split) as select:
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert select.call_args.args[1] == expected


def test_compaction_agent_model_overrides_small_model(case):
    app, sid = case
    large_head(app, sid)
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    app.config["small_model"] = "unrelated-title-model"
    app.agents["compaction"].model = "configured-compaction-model"
    app.agents["compaction"].temperature = 0.2
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert calls[0]["model"] == "configured-compaction-model"
    assert calls[0]["temperature"] == 0.2


def test_summary_caps_the_saved_tool_body_rather_than_receipt_header(case):
    app, sid = case
    _, tool, _ = large_head(app, sid)
    projected = [dict(m, content="PRESENTATION_HEADER " * 400 + m["content"])
                 if m["id"] == tool["id"] else m for m in app.store.context_messages(sid)]
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    compact(app, sid, projected, provider, "test", force=True)
    body = next(m["content"] for m in calls[0]["messages"] if m["role"] == "tool")
    assert body.startswith("ORIGINAL_RESULT")
    assert "PRESENTATION_HEADER" not in body


@pytest.mark.parametrize("response", [Completion(finish_reason='stop'), Completion(text="partial", finish_reason="length")])
def test_finished_summary_is_accepted_without_local_text_or_length_gate(case, response):
    app, sid = case
    large_head(app, sid)
    before = deepcopy(app.store.messages(sid))
    provider, calls = model(app, [response])
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert len(calls) == 1
    assert app.store.messages(sid)[:len(before)] == before
    assert app.store.context_messages(sid)[0]["finish_reason"] == response.finish_reason


def test_transport_failed_summary_preserves_history_and_records_error(case):
    app, sid = case
    large_head(app, sid)
    before = deepcopy(app.store.messages(sid))
    provider, calls = model(app, [ProviderError("transport failure")])
    with pytest.raises(ProviderError, match="transport failure"):
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert app.store.messages(sid)[:len(before)] == before
    assert app.store.messages(sid)[-1]["error"] == "transport failure"
    assert app.store.context_messages(sid)[0]["id"] == before[0]["id"]


def test_oversized_single_message_is_not_split_into_repeated_summary_calls(case):
    app, sid = case
    add(app, sid, "user", "task")
    add(app, sid, "assistant", "x" * 200000)
    before = deepcopy(app.store.messages(sid))
    provider, calls = model(app, [ProviderError("context_length_exceeded")])
    with pytest.raises(ProviderError, match="Session too large to compact"):
        compact(app, sid, before, provider, "test", force=True)
    assert len(calls) == 1 and app.store.messages(sid)[:len(before)] == before
    assert app.store.messages(sid)[-1]["finish_reason"] == "error"


def test_actual_usage_triggers_compaction_and_old_usage_is_not_reused(case):
    app, sid = case
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    add(app, sid, "user", "short task")
    last = add(app, sid, "assistant", "short answer", tokens={"total_tokens": 24000})
    assert usage_overflow(app, sid, provider, "test")
    compact(app, sid, app.store.context_messages(sid), provider, "test")
    assert len(calls) == 1
    assert app.store.context_messages(sid)[0]["compaction_through"] == last["id"]
    assert not usage_overflow(app, sid, provider, "test")


def test_empty_new_usage_does_not_reuse_earlier_overflow(case):
    app, sid = case
    provider, _ = model(app, [])
    add(app, sid, "assistant", "old", tokens={"total_tokens": 24000})
    add(app, sid, "assistant", "new", tokens={})
    assert not usage_overflow(app, sid, provider, "test")


def test_tool_results_after_the_last_response_count_toward_the_next_request(case):
    # v41's response used 229,684 of 230,144 tokens, so nothing was compacted; its tool results took the next
    # prompt past the provider's limit.
    app, sid = case
    provider, _ = model(app, [])
    add(app, sid, "user", "task")
    add(app, sid, "assistant", tool_calls=[{"id": "c", "name": "read", "arguments": {}}],
        tokens={"total_tokens": 23900})
    assert not usage_overflow(app, sid, provider, "test")
    add(app, sid, "tool", "x" * 800, tool_call_id="c", name="read")
    assert usage_overflow(app, sid, provider, "test")


def facts_after_calls(app, calls):
    """An extension whose host facts say how many model calls came before they were read."""
    app.turn_extension_factory = lambda *args: SimpleNamespace(
        context=lambda: f"model calls before these facts: {len(calls)}", feedback=lambda: None,
        present=lambda text, status: text)


def test_host_facts_are_read_again_after_a_compaction(case):
    # v41's first request after its overflow compaction carried the facts read before it, skills included.
    app, sid = case
    provider, calls = model(app, [ProviderError("maximum context length"), Completion(text="state", finish_reason='stop'),
                                  Completion(text="answer", finish_reason='stop')])
    facts_after_calls(app, calls)
    app.prompt(sid, "first request")
    assert "model calls before these facts: 0" in host_facts(calls[0])
    assert "model calls before these facts: 2" in host_facts(calls[2])

    other = app.create_session()["id"]
    add(app, other, "user", "old task")
    add(app, other, "assistant", "old answer", tokens={"total_tokens": 24000})
    provider, calls = model(app, [Completion(text="state", finish_reason='stop'),
                                  Completion(text="answer", finish_reason='stop')])
    facts_after_calls(app, calls)
    app.prompt(other, "next request")
    assert calls[0]["tools"] is None and "model calls before these facts: 1" in host_facts(calls[1])


def test_loop_compacts_actual_usage_then_continues_in_the_same_turn(case):
    app, sid = case
    provider, calls = model(app, [
        Completion(tool_calls=[ToolCall("list", "glob", {"pattern": "*.txt"})], usage={"total_tokens": 24000}, finish_reason='tool-calls'),
        Completion(text="anchored state", finish_reason='stop'), Completion(text="final answer", finish_reason='stop'),
    ])
    result = app.prompt(sid, "Inspect the directory")
    assert result["text"] == "final answer" and result["status"] == "completed"
    assert len(calls) == 3 and calls[1]["tools"] is None
    assert calls[2]["messages"][-1]["content"] == continue_prompt(app)


def test_disabled_auto_compaction_does_not_call_summary_model(case):
    app, sid = case
    app.config["compaction"] = {"auto": False}
    add(app, sid, "user", "x" * 120000)
    provider, calls = model(app, [])
    compact(app, sid, app.store.context_messages(sid), provider, "test")
    assert not calls


@pytest.mark.parametrize("field,value", [("tail_turns", -1), ("tail_turns", True),
                                        ("preserve_recent_tokens", "2000"), ("reserved", -1), ("prune", "yes")])
def test_invalid_compaction_options_fail_before_a_model_call(case, field, value):
    app, sid = case
    app.config["compaction"] = {field: value}
    large_head(app, sid)
    provider, calls = model(app, [])
    with pytest.raises(ProviderError, match="compaction"):
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert not calls


def test_explicit_input_budget_uses_reserved_but_context_budget_does_not(case):
    app, sid = case
    provider, _ = model(app, [], context=50000, output=12000)
    app.provider._model_config = lambda p, m: {"limit": {"input": 20000}}
    assert usable_budget(app, provider, "test") == 8000
    app.config["compaction"] = {"reserved": 4000}
    assert usable_budget(app, provider, "test") == 16000
    app.provider._model_config = lambda p, m: {"limit": {"input": 0}}
    assert usable_budget(app, provider, "test") == 38000


def test_zero_tail_turns_summarizes_the_whole_conversation(case):
    app, sid = case
    _, _, recent = large_head(app, sid)
    app.config["compaction"] = {"tail_turns": 0}
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert recent["content"] in json.dumps(calls[0]["messages"])
    assert [m["role"] for m in app.store.context_messages(sid)] == ["assistant", "user"]


def test_explicit_recent_budget_and_summary_model_select_the_tail(case):
    app, sid = case
    large_head(app, sid)
    app.config["compaction"] = {"preserve_recent_tokens": 0, "tail_turns": 1}
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    with patch("opencode.compaction.retained_split", wraps=retained_split) as select:
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert select.call_args.args[1:] == (0, 1)


def test_compaction_model_limits_determine_default_recent_budget(case):
    app, sid = case
    large_head(app, sid)
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    app.agents["compaction"].model = "smaller"
    app.provider.resolve = lambda target: (SimpleNamespace(id="test", context=12000), "smaller")
    app.provider.output_limit = lambda p, m: 4000
    with patch("opencode.compaction.retained_split", wraps=retained_split) as select:
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert select.call_args.args[1] == 2000


def test_aborted_text_is_kept_but_unfinished_tool_calls_are_not_replayed():
    result = _summary_messages([{"role": "assistant", "content": "saved partial work", "error": "aborted",
                                 "reasoning_content": "unfinished reasoning", "incomplete_tool_calls": [{"id": "incomplete"}]}])
    assert result[0] == {"role": "assistant", "content": "saved partial work", "reasoning_content": "unfinished reasoning"}
    assert "incomplete" not in json.dumps(result)
    assert len(_summary_messages([{"role": "assistant", "content": "failed", "error": "HTTP 500"}])) == 1


def test_presented_tail_estimate_does_not_add_a_non_upstream_commit_gate(case):
    app, sid = case
    old = add(app, sid, "user", "old")
    add(app, sid, "assistant", "old answer")
    add(app, sid, "user", "new")
    add(app, sid, "assistant", tool_calls=[{"id": "r", "name": "read", "arguments": {}}])
    tool = add(app, sid, "tool", "small actual output", tool_call_id="r", name="read")
    original = deepcopy(app.store.messages(sid))
    presented = [dict(m, content="RECEIPT_HEADER " * 4000 + m["content"]) if m["id"] == tool["id"] else m for m in original]
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')], context=8000, output=1000)
    with patch("opencode.compaction.retained_split", return_value=2):
        compact(app, sid, presented, provider, "test", force=True)
    assert len(calls) == 1 and app.store.messages(sid)[:len(original)] == original
    assert app.store.context_messages(sid)[0]["content"] == "state"


def test_provider_overflow_replays_exact_user_text_and_restores_context_after_restart(case):
    app, sid = case
    add(app, sid, "user", "root request")
    add(app, sid, "assistant", "root answer")
    original = add(app, sid, "user", "inspect the attached result",
                   attachments=[{"mime": "image/png", "filename": "result.png", "url": "data:image/png;base64,LARGE"}])
    before = deepcopy(app.store.messages(sid))
    provider, calls = model(app, [ProviderError("context_length_exceeded"), Completion(text="state", finish_reason='stop'), Completion(text="answer", finish_reason='stop')])
    # This new followup is the exact turn the provider rejects and must replay.
    result = app.prompt(sid, "follow up on the result")
    assert result["text"] == "answer" and len(calls) == 3
    failed_user = latest_human_message(app.store.messages(sid))
    checkpoint = next(m for m in reversed(app.store.messages(sid)) if m.get("compaction_through"))
    assert checkpoint["compaction_replay_from"] == failed_user["id"]
    assert failed_user["content"] not in json.dumps(calls[1]["messages"])
    assert calls[2]["messages"][-1]["content"] == failed_user["content"]
    assert app.store.messages(sid)[:len(before)] == before
    restarted = Store(app.store.path)
    try:
        shown = restarted.context_messages(sid)
        assert failed_user["id"] not in [m.get("id") for m in shown]
        assert not any(m.get("error") for m in shown)
        assert shown[-1]["content"] == "answer"
    finally:
        restarted.close()


def test_overflow_media_replay_is_bound_to_the_original_user_id(case):
    app, sid = case
    add(app, sid, "user", "root")
    add(app, sid, "assistant", "previous answer")
    replay = add(app, sid, "user", "image question", attachments=[{
        "mime": "image/png", "filename": "sample.png", "url": "data:image/png;base64,LARGE"}])
    failed = add(app, sid, "assistant", error="context_length_exceeded")
    provider, calls = model(app, [Completion(text="state", finish_reason='stop')])
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True, overflow=True)
    shown = app.store.context_messages(sid)
    assert shown[0]["compaction_replay_from"] == replay["id"]
    assert shown[-1]["content"] == "image question\n[Attached image/png: sample.png]"
    assert "attachments" not in shown[-1]
    assert "image question" not in json.dumps(calls[0]["messages"])
    assert replay["id"] not in [m.get("id") for m in shown]
    assert failed["id"] not in [m.get("id") for m in shown]
    assert replay in app.store.messages(sid) and failed in app.store.messages(sid)


def test_overflow_with_no_earlier_turn_uses_the_upstream_size_warning(case):
    app, sid = case
    provider, calls = model(app, [ProviderError("maximum context length"), Completion(text="state", finish_reason='stop'), Completion(text="answer", finish_reason='stop')])
    app.prompt(sid, "first request")
    assert len(calls) == 3
    followup = calls[2]["messages"][-1]["content"]
    assert "previous request exceeded the provider's size limit" in followup
    assert continue_prompt(app) in followup
    checkpoint = app.store.context_messages(sid)[0]
    assert "compaction_replay_from" not in checkpoint
    # v41 had no attachments and was told media files were removed.
    assert "media" not in followup


def test_an_overflow_with_media_keeps_the_upstream_attachment_warning(case):
    app, sid = case
    provider, _ = model(app, [Completion(text="state", finish_reason='stop')])
    add(app, sid, "user", "image question", attachments=[{
        "mime": "image/png", "filename": "sample.png", "url": "data:image/png;base64,LARGE"}])
    add(app, sid, "assistant", error="context_length_exceeded")
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True, overflow=True)
    assert "due to large media attachments" in app.store.messages(sid)[-1]["content"]


@pytest.mark.parametrize("error,auto,expected_calls", [("HTTP 500", True, 1), ("context_length_exceeded", False, 1)])
def test_non_overflow_or_disabled_auto_does_not_start_recovery(case, error, auto, expected_calls):
    app, sid = case
    app.config["compaction"] = {"auto": auto}
    _, calls = model(app, [ProviderError(error)])
    with pytest.raises(ProviderError):
        app.prompt(sid, "task")
    assert len(calls) == expected_calls
    assert not any(m.get("compaction_through") for m in app.store.messages(sid))


def test_second_provider_overflow_can_compact_again_without_a_local_retry_limit(case):
    app, sid = case
    _, calls = model(app, [ProviderError("context_length_exceeded"), Completion(text="state", finish_reason='stop'),
                          ProviderError("context_length_exceeded"), Completion(text="smaller state", finish_reason='stop'),
                          Completion(text="answer", finish_reason='stop')])
    assert app.prompt(sid, "task")["text"] == "answer"
    assert len(calls) == 5
    assert sum(bool(m.get("compaction_through")) for m in app.store.messages(sid)) == 2


def test_checkpoint_and_continuation_roll_back_as_one_transaction(case):
    app, sid = case
    human = add(app, sid, "user", "task")
    before = deepcopy(app.store.messages(sid))
    app.store._conn.execute("CREATE TRIGGER reject_followup BEFORE INSERT ON message "
                            "WHEN instr(NEW.data, 'FAIL_CONTINUE') > 0 BEGIN SELECT RAISE(ABORT, 'reject'); END")
    with pytest.raises(Exception, match="reject"):
        app.store.commit_compaction(sid, human["id"], "state", continuation={
            "role": "user", "content": "FAIL_CONTINUE", "synthetic": True})
    assert app.store.messages(sid) == before


def test_replay_reference_must_name_a_later_user_in_the_same_session(case):
    app, sid = case
    first = add(app, sid, "user", "first")
    assistant = add(app, sid, "assistant", "answer")
    with pytest.raises(ValueError, match="later user"):
        app.store.commit_compaction(sid, first["id"], "state", replay_from=assistant["id"])
    with pytest.raises(ValueError, match="later user"):
        app.store.commit_compaction(sid, assistant["id"], "state", replay_from=first["id"])


def test_ordinary_recompaction_cannot_revive_a_previous_overflow_request(case):
    app, sid = case
    add(app, sid, "user", "root")
    root_answer = add(app, sid, "assistant", "root answer")
    add(app, sid, "user", "retained old turn")
    tail_answer = add(app, sid, "assistant", "old tail answer")
    original = add(app, sid, "user", "OVERFLOW_ORIGINAL", attachments=[{
        "mime": "image/png", "filename": "sample.png", "url": "data:image/png;base64,DO_NOT_REVIVE"}])
    failure = add(app, sid, "assistant", error="context_length_exceeded")
    provider, calls = model(app, [Completion(text="first state", finish_reason='stop'), Completion(text="second state", finish_reason='stop')])
    with patch("opencode.compaction.retained_split", return_value=2):
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True, overflow=True)
    replay = app.store.context_messages(sid)[-1]
    add(app, sid, "assistant", "replayed answer")
    add(app, sid, "user", "latest question")
    with patch("opencode.compaction.retained_split", return_value=2):
        compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    shown = app.store.context_messages(sid)
    assert shown[0]["compaction_through"] == tail_answer["id"]
    assert replay["id"] in [m.get("id") for m in shown]
    assert original["id"] not in [m.get("id") for m in shown]
    assert failure["id"] not in [m.get("id") for m in shown]
    assert "DO_NOT_REVIVE" not in json.dumps(shown)


@pytest.mark.parametrize("error", ["local 413: <html>Request Entity Too Large</html>", "413: request too large"])
def test_provider_http_413_formats_trigger_recovery(case, error):
    app, sid = case
    _, calls = model(app, [ProviderError(error), Completion(text="state", finish_reason='stop'), Completion(text="answer", finish_reason='stop')])
    assert app.prompt(sid, "task")["text"] == "answer"
    assert len(calls) == 3


def test_tool_serializer_respects_pruning_for_summary_and_tail_budget():
    tool = {"role": "tool", "tool_call_id": "r", "content": "x" * 100000,
            "metadata": {"compacted": 1}, "attachments": [{"mime": "image/png", "url": "data:image/png;base64,HUGE"}]}
    before = deepcopy(tool)
    wire = openai_messages_from_history([tool])
    assert wire == [{"role": "tool", "tool_call_id": "r", "content": "[Old tool result content cleared]"}]
    assert tool == before
    history = [{"role": "user", "content": "old"}, {"role": "assistant", "content": "answer"},
               {"role": "user", "content": "recent"},
               {"role": "assistant", "tool_calls": [{"id": "r", "name": "read", "arguments": {}}]}, tool,
               {"role": "user", "content": "newest"}]
    assert retained_split(exchanges(history), 2000) == 2


def test_explicit_model_output_limit_is_not_silently_reduced_to_context_quarter(case):
    app, sid = case
    client = Client(app.auth, {"provider": {"local": {"models": {
        "test": {"limit": {"context": 16000, "output": 12000}},
        "large": {"limit": {"context": 128000, "output": 64000}},
    }}}})
    provider, _ = client.resolve("local/test")
    assert client.output_limit(provider, "test") == 12000
    assert client.output_limit(provider, "large") == 32000


@pytest.mark.parametrize("timestamp", [-1, True, "123"])
def test_pruning_timestamp_cannot_expand_the_approved_integer_contract(case, timestamp):
    app, sid = case
    with pytest.raises(ValueError, match="timestamp"):
        app.store.mark_tools_compacted(sid, [], timestamp)


def test_checkpoint_model_projection_includes_upstream_compaction_request_without_new_human(case):
    app, sid = case
    human = add(app, sid, "user", "original request")
    app.store.commit_compaction(sid, human["id"], "state")
    wire = openai_messages_from_history(app.store.context_messages(sid))
    assert [m["role"] for m in wire] == ["user", "assistant"]
    assert wire[0]["content"] == "What did we do so far?"
    assert latest_human_message(app.store.messages(sid)) == human


def continue_prompt(app):
    """These fixtures auto-approve, which is how a run is marked unattended."""
    return UNATTENDED_CONTINUE_PROMPT if app.permissions.auto else CONTINUE_PROMPT


def test_attended_compaction_keeps_the_upstream_continue_prompt(case):
    app, sid = case
    app.permissions.auto = False
    large_head(app, sid)
    provider, _ = model(app, [Completion(text="anchored state", finish_reason='stop')])
    compact(app, sid, app.store.context_messages(sid), provider, "test", force=True)
    assert app.store.context_messages(sid)[-1]["content"] == CONTINUE_PROMPT
    app.permissions.auto = True
    compact(app, sid, app.store.context_messages(sid), model(app, [Completion(text="later", finish_reason='stop')])[0],
            "test", force=True)
    assert app.store.context_messages(sid)[-1]["content"] == UNATTENDED_CONTINUE_PROMPT
