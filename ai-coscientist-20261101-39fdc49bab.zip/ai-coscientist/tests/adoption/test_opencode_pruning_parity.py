"""Offline V1 pruning boundaries; no model calls or scientific judgments."""

from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from opencode.compaction import estimate_tokens, prune
from opencode.loop import _present_history
from opencode.store import Store


@pytest.fixture
def case(tmp_path):
    store = Store(tmp_path / "session.db")
    sid = store.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    app = SimpleNamespace(store=store, config={"compaction": {"prune": True}})
    yield app, sid
    store.close()


def user(app, sid, text="request", **fields):
    return app.store.add_message(sid, "user", {"content": text, **fields})


def tool(app, sid, tokens, *, name="read", **fields):
    call_id = f"call-{len(app.store.messages(sid))}"
    app.store.add_message(sid, "assistant", {"tool_calls": [
        {"id": call_id, "name": name, "arguments": {"filePath": "saved.txt"}},
    ]})
    content = "x" * (tokens * 4)
    assert estimate_tokens(content) == tokens
    return app.store.add_message(sid, "tool", {
        "tool_call_id": call_id, "name": name, "content": content, **fields,
    })


def protect_recent_turns(app, sid, *, synthetic=False):
    user(app, sid, "second latest request")
    second_latest = tool(app, sid, 80_000)
    user(app, sid, "latest request", synthetic=synthetic)
    latest = tool(app, sid, 80_000)
    return second_latest, latest


def messages(app, sid):
    return {message["id"]: message for message in app.store.messages(sid)}


def compacted(message):
    return (message.get("metadata") or {}).get("compacted")


def test_checkpoint_counts_the_upstream_compaction_request_for_recent_turns(case):
    app, sid = case
    user(app, sid)
    candidate = tool(app, sid, 20_001)
    protected = tool(app, sid, 40_000)
    app.store.commit_compaction(sid, candidate["id"], "state", continuation={
        "role": "user", "synthetic": True, "content": "Continue"})
    prune(app, sid)
    saved = messages(app, sid)
    assert compacted(saved[candidate["id"]])
    assert saved[protected["id"]] == protected


@pytest.mark.parametrize("config", [{}, {"compaction": {}}, {"compaction": {"prune": False}}])
def test_pruning_is_disabled_unless_explicitly_enabled(case, config):
    app, sid = case
    user(app, sid)
    tool(app, sid, 80_000)
    protect_recent_turns(app, sid)
    before = deepcopy(app.store.messages(sid))
    app.config = config
    with patch.object(app.store, "mark_tools_compacted", side_effect=AssertionError("unexpected write")):
        prune(app, sid)
    assert app.store.messages(sid) == before


@pytest.mark.parametrize(("tokens", "expected"), [(40_000, False), (40_001, True)])
def test_protection_boundary_counts_complete_tool_outputs(case, tokens, expected):
    app, sid = case
    user(app, sid)
    saved = tool(app, sid, tokens)
    protect_recent_turns(app, sid)
    prune(app, sid)
    assert bool(compacted(messages(app, sid)[saved["id"]])) is expected


@pytest.mark.parametrize(("candidate_tokens", "expected"), [(20_000, False), (20_001, True)])
def test_candidate_total_must_strictly_exceed_twenty_thousand(case, candidate_tokens, expected):
    app, sid = case
    user(app, sid)
    candidate = tool(app, sid, candidate_tokens)
    protected = tool(app, sid, 40_000)
    protect_recent_turns(app, sid)
    prune(app, sid)
    saved = messages(app, sid)
    assert bool(compacted(saved[candidate["id"]])) is expected
    assert not compacted(saved[protected["id"]])


def test_skill_and_explicit_error_do_not_count_or_get_marked(case):
    app, sid = case
    user(app, sid)
    candidate = tool(app, sid, 30_000)
    skill = tool(app, sid, 100_000, name="skill")
    failed = tool(app, sid, 100_000, metadata={"error": True})
    protected = tool(app, sid, 10_000)
    protect_recent_turns(app, sid)
    prune(app, sid)
    saved = messages(app, sid)
    assert saved[candidate["id"]] == candidate
    assert saved[skill["id"]] == skill
    assert saved[failed["id"]] == failed
    assert saved[protected["id"]] == protected


def test_candidate_sizes_accumulate_and_commit_in_one_batch(case):
    app, sid = case
    user(app, sid)
    first = tool(app, sid, 10_000)
    second = tool(app, sid, 10_001)
    tool(app, sid, 40_000)
    protect_recent_turns(app, sid)
    with patch.object(app.store, "mark_tools_compacted", wraps=app.store.mark_tools_compacted) as mark:
        prune(app, sid)
    assert mark.call_count == 1
    assert mark.call_args.args[1] == [second["id"], first["id"]]
    saved = messages(app, sid)
    assert compacted(saved[first["id"]]) == compacted(saved[second["id"]])
    assert isinstance(compacted(saved[first["id"]]), int)


@pytest.mark.parametrize("user_count", [0, 1])
def test_no_tool_is_eligible_before_crossing_two_user_markers(case, user_count):
    app, sid = case
    if user_count:
        user(app, sid)
    old = tool(app, sid, 80_000)
    before = deepcopy(app.store.messages(sid))
    prune(app, sid)
    assert app.store.messages(sid) == before
    assert not compacted(messages(app, sid)[old["id"]])


@pytest.mark.parametrize("synthetic", [False, True])
def test_last_two_user_markers_protect_their_tool_results(case, synthetic):
    app, sid = case
    user(app, sid, "old request")
    candidate = tool(app, sid, 20_001)
    tool(app, sid, 40_000)
    recent = protect_recent_turns(app, sid, synthetic=synthetic)
    prune(app, sid)
    saved = messages(app, sid)
    assert compacted(saved[candidate["id"]])
    assert all(saved[item["id"]] == item for item in recent)


def test_summary_stops_scanning_older_tool_outputs(case):
    app, sid = case
    user(app, sid, "archived request")
    older = tool(app, sid, 80_000)
    summary = app.store.commit_compaction(sid, older["id"], "Saved summary")
    candidate = tool(app, sid, 20_001)
    tool(app, sid, 40_000)
    protect_recent_turns(app, sid)
    prune(app, sid)
    saved = messages(app, sid)
    assert saved[older["id"]] == older
    assert saved[summary["id"]] == summary
    assert compacted(saved[candidate["id"]])


@pytest.mark.parametrize("timestamp", [0, 123])
def test_existing_compacted_tool_stops_scanning_without_rewriting_its_time(case, timestamp):
    app, sid = case
    user(app, sid)
    older = tool(app, sid, 80_000)
    boundary = tool(app, sid, 80_000, metadata={"compacted": timestamp})
    candidate = tool(app, sid, 20_001)
    tool(app, sid, 40_000)
    protect_recent_turns(app, sid)
    prune(app, sid)
    saved = messages(app, sid)
    assert saved[older["id"]] == older
    assert saved[boundary["id"]] == boundary
    assert compacted(saved[candidate["id"]])


def test_pruning_preserves_original_payload_and_restart_projection_clears_media(case):
    app, sid = case
    user(app, sid)
    candidate = tool(app, sid, 20_001, metadata={"exit": 0}, attachments=[
        {"mime": "image/png", "filename": "observation.png", "data": "recorded-media"},
    ])
    tool(app, sid, 40_000)
    protect_recent_turns(app, sid)
    before = deepcopy(app.store.messages(sid))
    with patch("time.time", return_value=1_730_000_000.125):
        prune(app, sid)
    saved = messages(app, sid)[candidate["id"]]
    assert saved == dict(candidate, metadata={"exit": 0, "compacted": 1_730_000_000_125})
    unchanged = [item for item in app.store.messages(sid) if item["id"] != candidate["id"]]
    assert unchanged == [item for item in before if item["id"] != candidate["id"]]
    reopened = Store(app.store.path)
    try:
        original = next(item for item in reopened.messages(sid) if item["id"] == candidate["id"])
        with patch.object(reopened, "tool_origin", side_effect=AssertionError("receipt origin must not be presented")):
            projected = _present_history([original], reopened, sid)
        assert projected[0]["content"] == "[Old tool result content cleared]"
        assert "attachments" not in projected[0]
        assert original == saved
        assert original["content"] == candidate["content"]
        assert original["attachments"] == candidate["attachments"]
    finally:
        reopened.close()


def test_marker_batch_rolls_back_if_one_update_fails(case):
    app, sid = case
    first = tool(app, sid, 1)
    second = tool(app, sid, 1)
    before = deepcopy(app.store.messages(sid))
    app.store._conn.execute(
        "CREATE TRIGGER reject_pruning BEFORE UPDATE ON message "
        f"WHEN NEW.id = '{second['id']}' BEGIN SELECT RAISE(ABORT, 'pruning rejected'); END"
    )
    with pytest.raises(Exception, match="pruning rejected"):
        app.store.mark_tools_compacted(sid, [first["id"], second["id"]], 123)
    assert app.store.messages(sid) == before


def test_marker_batch_cannot_update_another_sessions_tool(case):
    app, sid = case
    first = tool(app, sid, 1)
    other = app.store.create_session(directory="other", agent="build", model=None)["id"]
    foreign = tool(app, other, 1)
    before = deepcopy(app.store.messages(sid))
    with pytest.raises(ValueError, match="does not belong"):
        app.store.mark_tools_compacted(sid, [first["id"], foreign["id"]], 123)
    assert app.store.messages(sid) == before
    assert messages(app, other)[foreign["id"]] == foreign
