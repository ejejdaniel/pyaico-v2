"""A cancelled permission request cannot grant approval to later attempts."""

import threading

import pytest

from opencode.permission import Broker, PermissionRejected


def arguments():
    return dict(session_id="session", permission="bash", patterns=["git status"], ruleset=[], always=["git *"])


def test_callback_cancellation_between_completion_and_reply_does_not_grant_always(monkeypatch):
    attempt = threading.Event()
    broker = Broker(callback=lambda _: "always")
    original_reply = broker.reply

    def reply_after_cancel(*args, **kwargs):
        attempt.set()
        return original_reply(*args, **kwargs)

    monkeypatch.setattr(broker, "reply", reply_after_cancel)
    with pytest.raises(PermissionRejected, match="Execution stopped"):
        broker.ask(**arguments(), abort_event=attempt)
    assert broker.list_pending() == [] and broker._pending_aborts == {}
    monkeypatch.setattr(broker, "reply", original_reply)
    broker.callback = lambda _: "reject"
    with pytest.raises(PermissionRejected, match="user rejected"):
        broker.ask(**arguments(), abort_event=threading.Event())


def test_external_reply_after_cancel_cannot_approve_before_waiter_cleanup():
    attempt = threading.Event()
    broker = Broker()
    # Keep the callback in flight while an external reply races cancellation.
    registered, release = threading.Event(), threading.Event()
    original_pending = broker.list_pending
    outcome = []

    def callback(pending):
        registered.set()
        assert release.wait(3)
        return "reject"

    broker.callback = callback

    def ask():
        try:
            broker.ask(**arguments(), abort_event=attempt)
        except BaseException as error:
            outcome.append(error)

    thread = threading.Thread(target=ask)
    thread.start()
    try:
        assert registered.wait(2)
        request, = original_pending()
        attempt.set()
        assert broker.reply(request["id"], "always") is False
        release.set()
        thread.join(2)
        assert not thread.is_alive() and len(outcome) == 1
        assert isinstance(outcome[0], PermissionRejected)
        assert broker.list_pending() == [] and broker._pending_aborts == {}
        broker.callback = lambda _: "reject"
        with pytest.raises(PermissionRejected, match="user rejected"):
            broker.ask(**arguments(), abort_event=threading.Event())
    finally:
        release.set()
        attempt.set()
        thread.join(2)
