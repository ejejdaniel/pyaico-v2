"""Local socket evidence that stopping the provider cancels the HTTP request."""

import asyncio
import json
import socket
import threading
import time
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import patch

import httpx
import pytest

from opencode.provider import Client, Completion, ProviderError, ProviderInfo


def _client(api="openai"):
    return Client(SimpleNamespace(get=lambda _: None), {}), ProviderInfo(
        "local", api, "Local test", "", [], ["test"], "test", api_key="local-test"
    )


@contextmanager
def _server(mode, api="openai"):
    """Read one exact request, then observe EOF from the real client socket."""
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    listener.settimeout(5)
    ready = threading.Event()
    disconnected = threading.Event()
    state = {"requests": [], "ready": ready, "disconnected": disconnected}

    def worker():
        try:
            conn, _ = listener.accept()
            with conn:
                conn.settimeout(5)
                raw = b""
                while b"\r\n\r\n" not in raw:
                    raw += conn.recv(65536)
                head, body = raw.split(b"\r\n\r\n", 1)
                length = next(int(line.split(b":", 1)[1]) for line in head.split(b"\r\n")
                              if line.lower().startswith(b"content-length:"))
                while len(body) < length:
                    body += conn.recv(65536)
                state["requests"].append(json.loads(body))
                if mode == "stream":
                    if api == "openai":
                        events = [
                            {"choices": [{"delta": {"reasoning_content": "partial reasoning", "tool_calls": [
                                {"index": 0, "id": "tool-1", "function": {"name": "read", "arguments": '{"path":'}}
                            ]}}]},
                            {"choices": [{"delta": {"content": "partial text"}}]},
                        ]
                    else:
                        events = [
                            {"type": "message_start", "message": {"usage": {"input_tokens": 12}}},
                            {"type": "content_block_start", "index": 0, "content_block": {
                                "type": "tool_use", "id": "tool-1", "name": "read"}},
                            {"type": "content_block_delta", "index": 0, "delta": {
                                "type": "input_json_delta", "partial_json": '{"path":'}},
                            {"type": "content_block_delta", "index": 1, "delta": {
                                "type": "thinking_delta", "thinking": "partial reasoning"}},
                            {"type": "content_block_delta", "index": 2, "delta": {
                                "type": "text_delta", "text": "partial text"}},
                        ]
                    data = "".join("data: " + json.dumps(event) + "\n\n" for event in events).encode()
                    conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
                                 b"Content-Length: 1000000\r\n\r\n" + data)
                elif mode == "body":
                    conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n"
                                 b"Content-Length: 1000000\r\n\r\n{\"choices\":")
                elif mode == "rate":
                    data = b'{"error":"rate limit"}'
                    conn.sendall(b"HTTP/1.1 429 Too Many Requests\r\nContent-Length: "
                                 + str(len(data)).encode() + b"\r\n\r\n" + data)
                ready.set()
                try:
                    if conn.recv(1) == b"":
                        disconnected.set()
                except ConnectionResetError:
                    disconnected.set()
        except BaseException as exc:
            state["error"] = exc
            ready.set()

    thread = threading.Thread(target=worker, name="local-provider-test-server")
    thread.start()
    try:
        state["url"] = f"http://127.0.0.1:{listener.getsockname()[1]}/v1"
        yield state
    finally:
        listener.close()
        thread.join(6)
        assert not thread.is_alive(), "Local server did not terminate"
        if "error" in state:
            raise state["error"]


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("mode", ["headers", "body", "stream"])
def test_abort_closes_actual_http_and_joins_request(api, mode):
    client, provider = _client(api)
    abort = threading.Event()
    received = threading.Event()
    outcome = {}

    def call():
        try:
            outcome["result"] = client.complete(
                provider=provider, model="test", system="", messages=[],
                on_text=(lambda _: received.set()) if mode == "stream" else None,
                abort_event=abort,
            )
        except BaseException as exc:
            outcome["error"] = exc

    with _server(mode, api) as server:
        provider.base_url = server["url"]
        caller = threading.Thread(target=call, name="provider-test-caller")
        caller.start()
        try:
            assert server["ready"].wait(3), "Provider did not issue local HTTP request"
            if mode == "stream":
                assert received.wait(3), "First stream delta was not delivered"
            started = time.monotonic()
            abort.set()
            caller.join(2)
            elapsed = time.monotonic() - started
            assert not caller.is_alive(), "Stopping left the synchronous provider blocked"
            assert elapsed < 1, f"Cancellation latency was {elapsed:.3f}s"
            assert server["disconnected"].wait(1), "Caller returned with its real HTTP socket still open"
            assert not any(t.name == "opencode-provider-request" for t in threading.enumerate())
            assert "result" not in outcome
            error = outcome["error"]
            assert isinstance(error, ProviderError)
            assert "aborted" in str(error)
            assert len(server["requests"]) == 1
            assert "abort_event" not in server["requests"][0]
            if mode == "stream":
                assert isinstance(error.partial, Completion)
                assert error.partial.text == "partial text"
                assert error.partial.reasoning_content == "partial reasoning"
                assert error.partial.finish_reason is None
                assert error.partial.model == "test"
                assert [(c.id, c.name, c.arguments) for c in error.partial.tool_calls] == [
                    ("tool-1", "read", {"_raw": '{"path":'})
                ]
                if api == "anthropic":
                    assert error.partial.usage == {"input_tokens": 12}
            print(f"{api} {mode}: cancellation={elapsed:.3f}s; peer EOF; request thread joined")
        finally:
            abort.set()
            caller.join(6)


def test_retry_backoff_is_interruptible_without_second_http_request():
    client, provider = _client()
    backoff = threading.Event()

    class RetryEvent(threading.Event):
        def wait(self, timeout=None):
            if timeout is not None and timeout >= 1.5:
                backoff.set()
            return super().wait(timeout)

    abort = RetryEvent()
    outcome = {}

    def call():
        try:
            client.complete(provider=provider, model="test", system="", messages=[], abort_event=abort)
        except BaseException as exc:
            outcome["error"] = exc

    with _server("rate") as server:
        provider.base_url = server["url"]
        caller = threading.Thread(target=call)
        caller.start()
        try:
            assert server["ready"].wait(3)
            assert server["disconnected"].wait(3)
            assert backoff.wait(1), "Provider never reached retry backoff"
            started = time.monotonic()
            abort.set()
            caller.join(1)
            assert not caller.is_alive()
            assert time.monotonic() - started < 0.5
            assert isinstance(outcome["error"], ProviderError)
            assert "aborted" in str(outcome["error"])
            assert len(server["requests"]) == 1
        finally:
            abort.set()
            caller.join(6)


def test_already_aborted_event_prevents_transport():
    client, provider = _client()
    abort = threading.Event()
    abort.set()
    with patch("opencode.provider.httpx.AsyncClient") as transport:
        with pytest.raises(ProviderError, match="aborted"):
            client.complete(provider=provider, model="test", system="", messages=[], abort_event=abort)
        transport.assert_not_called()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_abort_capable_success_keeps_completion_and_works_inside_running_loop(api):
    client, provider = _client(api)
    sent = []

    async def respond(request):
        sent.append(json.loads(request.content))
        if api == "openai":
            data = {"choices": [{"finish_reason": "stop", "message": {"content": "answer"}}]}
        else:
            data = {"content": [{"type": "text", "text": "answer"}], "stop_reason": "end_turn"}
        return httpx.Response(200, json=data)

    transport_class = httpx.AsyncClient

    async def call():
        with patch("opencode.provider.httpx.AsyncClient", side_effect=lambda **kwargs: transport_class(
            **kwargs, transport=httpx.MockTransport(respond)
        )):
            result = client.complete(provider=provider, model="test", system="", messages=[],
                                     abort_event=threading.Event())
        assert result.text == "answer"
        assert result.finish_reason == "stop"
        assert len(sent) == 1
        assert "abort_event" not in sent[0]

    provider.base_url = "http://local.invalid/v1"
    asyncio.run(call())


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_abort_capable_stream_preserves_normal_completion(api):
    client, provider = _client(api)
    provider.base_url = "http://local.invalid/v1"
    if api == "openai":
        events = [
            {"choices": [{"delta": {"reasoning_content": "reasoning", "tool_calls": [
                {"index": 0, "id": "tool-1", "function": {"name": "read", "arguments": "{}"}}
            ]}}]},
            {"choices": [{"delta": {"content": "answer"}, "finish_reason": "tool_calls"}]},
            {"choices": [], "usage": {"total_tokens": 12}},
        ]
        expected_finish = "tool-calls"
        expected_usage = {"total_tokens": 12}
    else:
        events = [
            {"type": "message_start", "message": {"usage": {"input_tokens": 12}}},
            {"type": "content_block_start", "index": 0, "content_block": {
                "type": "tool_use", "id": "tool-1", "name": "read"}},
            {"type": "content_block_delta", "index": 0, "delta": {
                "type": "input_json_delta", "partial_json": "{}"}},
            {"type": "content_block_delta", "index": 1, "delta": {
                "type": "thinking_delta", "thinking": "reasoning"}},
            {"type": "content_block_delta", "index": 2, "delta": {
                "type": "text_delta", "text": "answer"}},
            {"type": "message_delta", "delta": {"stop_reason": "tool_use"}, "usage": {"output_tokens": 3}},
        ]
        expected_finish = "tool-calls"
        expected_usage = {"input_tokens": 12, "output_tokens": 3}
    stream = "".join("data: " + json.dumps(event) + "\n\n" for event in events)
    transport_class = httpx.AsyncClient

    async def respond(request):
        body = json.loads(request.content)
        assert body["stream"] is True
        assert "abort_event" not in body
        return httpx.Response(200, text=stream)

    visible = []
    with patch("opencode.provider.httpx.AsyncClient", side_effect=lambda **kwargs: transport_class(
        **kwargs, transport=httpx.MockTransport(respond)
    )):
        result = client.complete(provider=provider, model="test", system="", messages=[],
                                 on_text=visible.append, abort_event=threading.Event())
    assert result.text == "answer"
    assert result.reasoning_content == "reasoning"
    assert result.finish_reason == expected_finish
    assert result.usage == expected_usage
    assert [(call.id, call.name, call.arguments) for call in result.tool_calls] == [("tool-1", "read", {})]
    assert visible == ["answer"]
