"""Boundary checks for resuming an already returned tool call without a new prompt."""

from copy import deepcopy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from opencode.app import App
from opencode.provider import Completion, ToolCall
from scripts.continue_reasoning_replay import ResumeStore, saved_completion, without_reasoning


class ReasoningContinuation(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        env = patch.dict(os.environ, {key: str(self.root / name) for key, name in {
            "OPENCODE_TEST_HOME": "home", "OPENCODE_CONFIG_DIR": "config",
            "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache"}.items()})
        env.start()
        self.addCleanup(env.stop)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".git").mkdir()
        self.store = ResumeStore(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.app = App(self.workspace, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]

    def test_pending_read_executes_once_then_q2_is_the_only_new_user_message(self):
        (self.workspace / "timeline.md").write_text("Exact captured timeline.", encoding="utf-8")
        human = self.store.add_message(self.sid, "user", {"content": "Original Q1"})
        self.store.resume_human = human
        from types import SimpleNamespace
        calls = []

        class Provider:
            def resolve(self, model=None):
                return SimpleNamespace(id="local", context=131072), "test"

            def complete(self, **kwargs):
                calls.append(kwargs)
                if len(calls) == 1:
                    return Completion(tool_calls=[ToolCall("saved-call", "read", {"filePath": "timeline.md"})], finish_reason='tool-calls')
                return Completion(text="Q1 answer" if len(calls) == 2 else "Q2 answer", finish_reason='stop')

        self.app.provider = Provider()
        first = self.app.prompt(self.sid, "Original Q1")
        self.assertEqual(first["text"], "Q1 answer")
        second = self.app.prompt(self.sid, "Original Q2")
        self.assertEqual(second["text"], "Q2 answer")
        messages = self.store.messages(self.sid)
        self.assertEqual([m["content"] for m in messages if m["role"] == "user"], ["Original Q1", "Original Q2"])
        reads = [m for m in messages if m["role"] == "tool"]
        self.assertEqual(len(reads), 1)
        self.assertEqual(reads[0]["tool_call_id"], "saved-call")
        self.assertIn("Exact captured timeline.", reads[0]["content"])
        answer = next(m for m in calls[-1]["messages"] if (m.get("content") or "").endswith("Q1 answer"))
        self.assertEqual("Q1 answer", answer["content"])
        self.assertEqual(answer["role"], "assistant")
        self.assertTrue(any(m.get("content") == "Q1 answer" for m in messages))

    def test_different_resume_prompt_is_rejected_without_consuming_anchor(self):
        human = self.store.add_message(self.sid, "user", {"content": "Original Q1"})
        self.store.resume_human = human
        with self.assertRaisesRegex(ValueError, "exact original"):
            self.store.add_message(self.sid, "user", {"content": "Extra instruction"})
        self.assertEqual(self.store.resume_human, human)
        self.assertEqual(len(self.store.messages(self.sid)), 1)

    def test_reasoning_removed_only_from_presentation_not_saved_history(self):
        messages = [{"role": "user", "content": "Original question"},
                    {"role": "assistant", "content": "Working text", "reasoning_content": "private",
                     "tool_calls": [{"id": "r", "function": {"name": "read", "arguments": "{}"}}]},
                    {"role": "tool", "tool_call_id": "r", "content": "Exact receipt"}]
        before = deepcopy(messages)
        presented = without_reasoning(messages)
        self.assertEqual(messages, before)
        self.assertEqual(presented[0], before[0])
        self.assertEqual(presented[2], before[2])
        self.assertEqual(presented[1]["content"], "Working text")
        self.assertEqual(presented[1]["reasoning"], "")
        self.assertNotIn("reasoning_content", presented[1])

    def test_saved_response_reuses_call_identity_and_only_relocates_copy_path(self):
        old, new = self.root / "old", self.root / "new"
        response = {"model": "test", "usage": {"total_tokens": 12}, "choices": [{
            "finish_reason": "tool_calls", "message": {"content": "", "reasoning": "saved reasoning",
                "tool_calls": [{"id": "exact-call", "function": {"name": "read",
                    "arguments": json.dumps({"filePath": str(old / "workspace" / "timeline.md")})}}]}}]}
        before = deepcopy(response)
        restored = saved_completion(response, old, new)
        self.assertEqual(restored.tool_calls[0].id, "exact-call")
        self.assertEqual(restored.tool_calls[0].arguments, {"filePath": str(new / "workspace" / "timeline.md")})
        self.assertEqual(restored.reasoning_content, "saved reasoning")
        self.assertEqual(response, before)


if __name__ == "__main__":
    unittest.main()
