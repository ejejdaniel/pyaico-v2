"""Offline single-variable checks; no real model or research tools run."""

from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

import httpx

from scripts.compare_reasoning_replay import execute_pair, prepare_pair


class ReasoningReplay(unittest.TestCase):
    def request(self):
        return {"model": "recorded-model", "reasoning_effort": "medium", "temperature": 0,
                "max_tokens": 12000, "tools": [{"type": "function", "function": {"name": "read"}}],
                "messages": [
                    {"role": "system", "content": "Ordinary agent."},
                    {"role": "assistant", "content": "<previous-summary>\nFixed summary\n</previous-summary>",
                     "reasoning": ""},
                    {"role": "user", "content": "Original request."},
                    {"role": "assistant", "content": "Ordinary working explanation.",
                     "reasoning": "Older private judgment", "tool_calls": [{"id": "r", "type": "function",
                         "function": {"name": "read", "arguments": "{}"}}]},
                    {"role": "tool", "tool_call_id": "r", "content": "Exact evidence.\nLater line."},
                    {"role": "assistant", "content": None, "reasoning_content": "Another old judgment"},
                ]}

    def test_only_historical_reasoning_changes(self):
        original = self.request()
        before = deepcopy(original)
        retained, removed, checks = prepare_pair(original)
        self.assertEqual(original, before)
        self.assertEqual(retained, original)
        self.assertEqual(removed["messages"][3]["reasoning"], "")
        self.assertEqual(removed["messages"][5]["reasoning_content"], "")
        self.assertEqual(len(checks["changes"]), 2)
        for change in checks["changes"]:
            i, field = change["message_index"], change["field"]
            removed["messages"][i][field] = original["messages"][i][field]
        self.assertEqual(removed, original)
        self.assertEqual(checks["generation_controls"]["reasoning_effort"], "medium")
        self.assertNotIn("tool_choice", retained)

    def test_requires_frozen_summary_and_actual_difference(self):
        original = self.request()
        original["messages"][1]["content"] = "No summary marker"
        with self.assertRaisesRegex(ValueError, "one frozen summary"):
            prepare_pair(original)
        original = self.request()
        original["messages"][3]["reasoning"] = ""
        original["messages"][5]["reasoning_content"] = None
        with self.assertRaisesRegex(ValueError, "No historical reasoning"):
            prepare_pair(original)

    def test_two_sequential_calls_and_no_tool_execution(self):
        original = self.request()
        before = deepcopy(original)
        sent = []

        def respond(request):
            sent.append(json.loads(request.content))
            return httpx.Response(200, json={"choices": [{"finish_reason": "tool_calls", "message": {
                "content": "", "tool_calls": [{"id": "next", "function": {"name": "read", "arguments": "{}"}}]}}],
                "usage": {"total_tokens": 20}})

        with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
            result = execute_pair(client, "http://model.invalid/v1", original, directory)
            self.assertEqual(result["calls"], 2)
            self.assertEqual(result["tools_executed"], 0)
            self.assertEqual(sent, list(prepare_pair(original)[:2]))
            self.assertFalse(result["arms"]["removed"]["has_text_answer"])
            self.assertTrue((Path(directory) / "retained.response.bin").exists())
            self.assertTrue((Path(directory) / "removed.response.bin").exists())
        self.assertEqual(original, before)

    def test_failed_first_arm_stops_without_retry_or_second_call(self):
        for finish, text, status in (("length", "Partial", 200), ("stop", "", 200), ("stop", "", 503)):
            with self.subTest(finish=finish, text=text, status=status):
                sent = []

                def respond(request):
                    sent.append(request)
                    return httpx.Response(status, json={"choices": [{"finish_reason": finish,
                                                                     "message": {"content": text}}]})

                with tempfile.TemporaryDirectory() as directory, httpx.Client(transport=httpx.MockTransport(respond)) as client:
                    with self.assertRaises((RuntimeError, httpx.HTTPStatusError)):
                        execute_pair(client, "http://model.invalid/v1", self.request(), directory)
                    self.assertEqual(len(sent), 1)
                    self.assertTrue((Path(directory) / "retained.response.bin").exists())
                    self.assertFalse((Path(directory) / "removed.request.json").exists())


if __name__ == "__main__":
    unittest.main()
