"""Offline result transport boundaries, not scientific or real-model acceptance.

All cases exercise the real App, loop, Store, and Bus. Scripted providers and
turn extensions supply protocol fixtures only; no research output is loaded.
"""

from collections import Counter
import io
import json
from pathlib import Path
import queue
import threading
from types import SimpleNamespace

import pytest

import opencode.app as app_module
from opencode.app import App
from opencode.provider import Completion, ProviderError
from opencode.server import Server
from opencode.store import Store


TIMEOUT = 5
RESULT_KEYS = {"text", "sessionID", "status", "info", "messageID"}
EVENT_KEYS = {"resultID", "sessionID", "messageID", "text", "status"}


class DeliveryCase:
    def __init__(self, app, monkeypatch):
        self.app = app
        self.sid = app.create_session()["id"]
        self.box = app.bus.subscribe()
        self.recorded = []
        self.threads = []
        self.releases = []
        self.calls = []
        self.counts = Counter()
        self.lock = threading.Lock()
        original_thread = threading.Thread
        case = self

        class TrackedThread(original_thread):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                case.threads.append(self)

        monkeypatch.setattr(app_module.threading, "Thread", TrackedThread)

    def signal(self):
        event = threading.Event()
        self.releases.append(event)
        return event

    @staticmethod
    def wait(event):
        assert event.wait(TIMEOUT), "Timed out at a controlled delivery boundary"

    def model(self, handler):
        def complete(**kwargs):
            with self.app._execution_lock:
                sid = next(sid for sid, abort in self.app._aborts.items()
                           if abort is kwargs["abort_event"])
            with self.lock:
                number = self.counts[sid]
                self.counts[sid] += 1
                self.calls.append((sid, kwargs))
            return handler(sid, number, kwargs)

        self.app.provider = SimpleNamespace(
            resolve=lambda _: (SimpleNamespace(id="fixture", context=200000), "fixture"),
            complete=complete,
        )

    def extension(self, present):
        self.app.turn_extension_factory = lambda app, sid, human_id: SimpleNamespace(
            context=lambda: "", feedback=lambda: None,
            present=lambda text, status: present(sid, text, status),
        )

    def events(self, kind=None, sid=None):
        while True:
            try:
                self.recorded.append(self.box.get_nowait())
            except queue.Empty:
                break
        return [event for event in self.recorded
                if (kind is None or event["type"] == kind)
                and (sid is None or event["properties"].get("sessionID") == sid)]

    def start(self, operation):
        box = {}

        def run():
            try:
                box["result"] = operation()
            except BaseException as exc:
                box["error"] = exc

        thread = threading.Thread(target=run, name="test-result-delivery")
        thread.start()
        return box

    def join(self):
        # A child can start the parent's continuation while being joined.
        index = 0
        while index < len(self.threads):
            thread = self.threads[index]
            index += 1
            if thread.ident is not None:
                thread.join(TIMEOUT)
                assert not thread.is_alive(), f"Unfinished delivery thread: {thread.name}"

    def child(self):
        return self.app.store.create_session(directory=str(self.app.directory), agent="general",
                                             model=self.app.session_model(self.sid), parent_id=self.sid)["id"]

    def review(self):
        humans = [message for message in self.app.store.messages(self.sid)
                  if message["role"] == "user" and not message.get("synthetic")]
        return self.app.store.answer_review(self.sid, humans[-1]["id"])


@pytest.fixture
def case(tmp_path, monkeypatch):
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(name, str(tmp_path / name))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    store = Store(tmp_path / "sessions.db")
    app = App(project, store=store, auto_approve=True, config={
        "steps": 8,
        "skills": {"paths": [str(Path(__file__).resolve().parents[2] / "src/opencode/skill_assets")]},
    })
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)
    control = DeliveryCase(app, monkeypatch)
    try:
        yield control
    finally:
        for sid in list(app._running):
            app.abort(sid)
        for event in control.releases:
            event.set()
        try:
            control.join()
        finally:
            app.bus.unsubscribe(control.box)
            store.close()


def assert_result_event(case, result, *, count=1):
    assert set(result) == RESULT_KEYS
    events = case.events("session.result", result["sessionID"])
    assert len(events) == count
    event = events[-1]
    assert set(event) == {"type", "properties", "time"}
    properties = event["properties"]
    assert set(properties) == EVENT_KEYS
    assert isinstance(properties["resultID"], str) and properties["resultID"].startswith("res_")
    assert properties == {"resultID": properties["resultID"], **{
        key: result[key] for key in ("sessionID", "messageID", "text", "status")}}
    ordered = case.events(sid=result["sessionID"])
    result_index = ordered.index(event)
    assert ordered[result_index + 1]["type"] == "session.status"
    assert ordered[result_index + 1]["properties"] == {
        "sessionID": result["sessionID"], "status": "idle"}
    return properties


@pytest.mark.parametrize("reviewed", [False, True], ids=["ordinary", "reviewed"])
def test_result_points_to_exact_saved_answer_and_precedes_idle(case, monkeypatch, reviewed):
    c, app = case, case.app
    if reviewed:
        app.agents["build"].options["answer_review_skill"] = "investigate"
    observations = []
    original_publish = app.bus.publish

    def publish(kind, properties=None):
        if kind == "session.result":
            message = next(m for m in app.store.messages(c.sid) if m["id"] == properties["messageID"])
            observations.append((message, c.review()))
        original_publish(kind, properties)

    monkeypatch.setattr(app.bus, "publish", publish)

    def respond(sid, number, kwargs):
        text = "undelivered draft" if reviewed and number == 0 else "saved answer"
        kwargs["on_text"](text)
        assert not c.events("session.result", sid)
        return Completion(text=text, finish_reason="stop")

    c.model(respond)
    streamed = []
    result = app.prompt(c.sid, "Protocol delivery request", on_text=streamed.append)
    assert_result_event(c, result)
    saved, review = observations[0]
    assert saved["role"] == "assistant" and saved["content"] == result["text"] == "saved answer"
    assert saved["id"] == result["messageID"]
    if reviewed:
        assert saved["answer_review_role"] == "answer"
        assert review["phase"] == "delivered" and review["answer_message_id"] == saved["id"]
        assert "undelivered draft" not in "".join(streamed)
    else:
        assert streamed == ["saved answer"] and review is None


def test_presented_text_is_transmitted_verbatim_without_persisting_a_duplicate(case):
    c, app = case, case.app
    presented = "# 凍結正文測試\n\nExact whitespace:  \n\n模型工作說明：original answer\n"
    inputs = []

    def present(sid, text, status):
        inputs.append((sid, text, status))
        return presented

    c.extension(present)
    c.model(lambda *_: Completion(text="original answer", finish_reason="stop"))
    result = app.prompt(c.sid, "Exercise the installed presentation interface")
    assert_result_event(c, result)
    assert result["text"] == presented
    assert inputs == [(c.sid, "original answer", "completed")]
    saved = app.store.messages(c.sid)
    source = next(m for m in saved if m["id"] == result["messageID"])
    assert source["content"] == "original answer"
    assert all(m.get("content") != presented for m in saved)


def test_equal_answers_in_distinct_turns_have_distinct_result_and_source_ids(case):
    c, app = case, case.app
    c.model(lambda *_: Completion(text="same exact text", finish_reason="stop"))
    first = app.prompt(c.sid, "First request")
    first_event = assert_result_event(c, first)
    second = app.prompt(c.sid, "Second request")
    second_event = assert_result_event(c, second, count=2)
    assert first["text"] == second["text"]
    assert first["messageID"] != second["messageID"]
    assert first_event["resultID"] != second_event["resultID"]


def test_pending_handoff_reexecutes_real_loop_once_and_waiters_share_final_event(case, monkeypatch):
    c, app = case, case.app
    returned, release, queued = c.signal(), c.signal(), c.signal()
    real_loop, real_save = app_module.run_loop, app_module.save_prompt
    loop_results = []
    saves = []

    def loop(*args, **kwargs):
        result = real_loop(*args, **kwargs)
        loop_results.append(result)
        if len(loop_results) == 1:
            returned.set()
            c.wait(release)
        return result

    def save(*args, **kwargs):
        saved = real_save(*args, **kwargs)
        saves.append(saved)
        if len(saves) == 3:
            queued.set()
        return saved

    monkeypatch.setattr(app_module, "run_loop", loop)
    monkeypatch.setattr(app_module, "save_prompt", save)
    c.model(lambda sid, number, _: Completion(text="intermediate" if number == 0 else "final pending answer",
                                             finish_reason="stop"))
    owner = c.start(lambda: app.prompt(c.sid, "Original request"))
    c.wait(returned)
    waiters = [c.start(lambda text=text: app.prompt(c.sid, text))
               for text in ("Pending request one", "Pending request two")]
    c.wait(queued)
    with app._execution_lock:
        assert len(app._waiters[c.sid]) == 2
        assert len(app._pending_notifications[c.sid]) == 2
    assert not c.events("session.result")
    release.set()
    c.join()
    assert "error" not in owner and all("error" not in waiter for waiter in waiters)
    result = owner["result"]
    assert all(waiter["result"] is result for waiter in waiters)
    assert len(loop_results) == 2 and c.counts[c.sid] == 2
    assert loop_results[0]["messageID"] != result["messageID"]
    assert result["text"] == "final pending answer"
    assert not app._has_pending_notifications(c.sid)
    assert_result_event(c, result)


@pytest.mark.parametrize("raises", [False, True], ids=["loop-return", "provider-abort"])
def test_aborted_result_has_no_source_and_keeps_existing_stop_text(case, raises):
    c, app = case, case.app

    def respond(sid, number, kwargs):
        kwargs["on_text"]("partial saved text")
        app.abort(sid)
        if raises:
            raise ProviderError("aborted")
        return Completion(text="partial saved text", finish_reason="stop")

    c.model(respond)
    result = app.prompt(c.sid, "Cancel this controlled invocation")
    assert result["status"] == "aborted" and result["messageID"] is None
    assert result["text"] == "Stopped: aborted. Work is saved; no completion is claimed."
    assert_result_event(c, result)


def test_step_limit_result_has_no_draft_source(case):
    c, app = case, case.app
    app.agents["build"].options["answer_review_skill"] = "investigate"
    app.agents["build"].steps = 1
    c.model(lambda *_: Completion(text="unreviewed candidate", finish_reason="stop"))
    result = app.prompt(c.sid, "Review with no remaining verification step")
    assert result["status"] == "step_limit" and result["messageID"] is None
    assert result["text"] == "Stopped: step_limit. Work is saved; no completion is claimed."
    assert c.review()["answer_message_id"] is None
    assert_result_event(c, result)


def test_cancellation_after_present_does_not_publish_completed_or_commit_answer(case):
    c, app = case, case.app
    app.agents["build"].options["answer_review_skill"] = "investigate"
    presented = []

    def present(sid, text, status):
        presented.append((text, status))
        if status == "completed":
            assert not c.events("session.result")
            app.abort(sid)
        return "assembled: " + text

    c.extension(present)
    c.model(lambda sid, number, _: Completion(text="draft" if number == 0 else "checked candidate",
                                             finish_reason="stop"))
    result = app.prompt(c.sid, "Cancel between presentation and commit")
    assert [status for _, status in presented] == ["completed", "aborted"]
    assert result["status"] == "aborted" and result["messageID"] is None
    assert result["text"] == "assembled: Stopped: aborted. Work is saved; no completion is claimed."
    assert c.review()["phase"] == "checking" and c.review()["answer_message_id"] is None
    assert not any(m.get("answer_review_role") == "answer" for m in app.store.messages(c.sid))
    assert_result_event(c, result)


@pytest.mark.parametrize("failure_at", ["present", "commit", "export_after_commit"])
def test_review_failure_never_advertises_a_completed_result(case, monkeypatch, failure_at):
    c, app = case, case.app
    app.agents["build"].options["answer_review_skill"] = "investigate"
    assembled = []

    def present(sid, text, status):
        assert not c.events("session.result")
        assembled.append(text)
        if failure_at == "present":
            raise RuntimeError("controlled present failure")
        return "assembled document\n" + text

    c.extension(present)
    real_commit = app.store.commit_answer_review

    def commit(sid, human, assistant, notice=None):
        if notice is None and failure_at == "commit":
            raise RuntimeError("controlled commit failure")
        return real_commit(sid, human, assistant, notice)

    real_export = app.store.export_work_history

    def export(sid):
        if failure_at == "export_after_commit" and c.review() and c.review()["phase"] == "delivered":
            raise RuntimeError("controlled export_after_commit failure")
        return real_export(sid)

    monkeypatch.setattr(app.store, "commit_answer_review", commit)
    monkeypatch.setattr(app.store, "export_work_history", export)
    c.model(lambda sid, number, _: Completion(text="draft" if number == 0 else "checked candidate",
                                             finish_reason="stop"))
    with pytest.raises(RuntimeError, match=f"controlled {failure_at} failure"):
        app.prompt(c.sid, "Fail at the exact formal return boundary")
    assert assembled == ["checked candidate"]
    assert not c.events("session.result")
    assert not c.events("session.error"), "Foreground errors remain owned by their caller"
    assert c.events("session.status", c.sid)[-1]["properties"]["status"] == "idle"
    assert c.review()["phase"] == ("delivered" if failure_at == "export_after_commit" else "checking")
    if failure_at == "export_after_commit":
        answer = next(m for m in app.store.messages(c.sid) if m["id"] == c.review()["answer_message_id"])
        assert answer["answer_review_role"] == "answer" and answer["content"] == "checked candidate"


@pytest.mark.parametrize("error_type", [RuntimeError, KeyboardInterrupt])
def test_interrupted_stream_is_saved_without_a_formal_result(case, error_type):
    c, app = case, case.app

    def respond(sid, number, kwargs):
        kwargs["on_text"]("incomplete provider stream")
        raise error_type("controlled stream interruption")

    c.model(respond)
    with pytest.raises(error_type, match="controlled stream interruption"):
        app.prompt(c.sid, "Inspect interrupted transport")
    assert not c.events("session.result")
    assert not c.events("session.error")
    saved = [m for m in app.store.messages(c.sid) if m["role"] == "assistant"]
    assert saved[-1]["content"] == "incomplete provider stream" and saved[-1].get("error")
    assert c.events("session.status", c.sid)[-1]["properties"]["status"] == "idle"


def test_background_child_and_parent_publish_their_own_presented_results(case):
    c, app = case, case.app
    c.extension(lambda sid, text, status: f"document for {sid}\n\n{text}")
    c.model(lambda sid, number, _: Completion(
        text=("initial parent" if number == 0 else "parent incorporated child") if sid == c.sid else "child observation",
        finish_reason="stop"))
    first = app.prompt(c.sid, "Continue when the child returns")
    child = c.child()
    app.spawn_background(child, "Assigned input", "general", 1, c.sid)
    c.join()
    events = c.events("session.result")
    assert len(events) == 3
    assert [event["properties"]["sessionID"] for event in events] == [c.sid, child, c.sid]
    child_event, parent_event = [event["properties"] for event in events[1:]]
    assert child_event["text"] == f"document for {child}\n\nchild observation"
    assert parent_event["text"] == f"document for {c.sid}\n\nparent incorporated child"
    assert first["messageID"] != parent_event["messageID"]
    assert len({event["properties"]["resultID"] for event in events}) == 3
    for properties in (child_event, parent_event):
        sid = properties["sessionID"]
        result = {key: properties[key] for key in ("sessionID", "messageID", "text", "status")}
        result["info"] = app.store.get_session(sid)
        assert_result_event(c, result, count=2 if sid == c.sid else 1)
        source = next(m for m in app.store.messages(sid) if m["id"] == properties["messageID"])
        assert source["role"] == "assistant" and source["content"] != properties["text"]
        assert not any(m.get("content") == properties["text"] for m in app.store.messages(sid))
    notifications = [m for m in app.store.messages(c.sid) if m.get("synthetic") and m["role"] == "user"]
    assert len(notifications) == 1 and child_event["text"] in notifications[0]["content"]
    assert parent_event["text"] not in notifications[0]["content"]


def test_background_child_exception_notifies_original_session_and_waiter(case):
    c, app = case, case.app
    child = c.child()

    def fail(*_):
        raise RuntimeError("controlled child failure")

    c.model(fail)
    with pytest.raises(RuntimeError, match="controlled child failure"):
        app.spawn_background(child, "Assigned input", "general", 1, c.sid, _wait=True, _notify=False)
    c.join()
    assert not c.events("session.result")
    errors = c.events("session.error")
    assert len(errors) == 1 and errors[0]["properties"] == {
        "sessionID": child, "error": "controlled child failure"}
    assert not c.events("task.completed")


def test_background_parent_presentation_exception_notifies_parent_and_keeps_child_result(case):
    c, app = case, case.app

    def present(sid, text, status):
        if sid == c.sid and text == "parent continuation":
            raise RuntimeError("controlled parent presentation failure")
        return text

    c.extension(present)
    c.model(lambda sid, number, _: Completion(
        text=("initial parent" if number == 0 else "parent continuation") if sid == c.sid else "child observation",
        finish_reason="stop"))
    app.prompt(c.sid, "Continue after a child result")
    child = c.child()
    app.spawn_background(child, "Assigned input", "general", 1, c.sid)
    c.join()
    assert [event["properties"]["sessionID"] for event in c.events("session.result")] == [c.sid, child]
    assert [event["properties"] for event in c.events("session.error")] == [{
        "sessionID": c.sid, "error": "controlled parent presentation failure"}]
    assert len(c.events("task.completed", c.sid)) == 1
    assert c.events("session.status", c.sid)[-1]["properties"]["status"] == "idle"


def test_cancelled_parent_prevents_unstarted_child_from_creating_any_result(case):
    c, app = case, case.app
    child = c.child()
    c.model(lambda *_: pytest.fail("Cancelled child must not call the provider"))
    app.abort(c.sid)
    app.spawn_background(child, "Unstarted child input", "general", 1, c.sid)
    assert not c.threads and not c.calls
    assert not app.store.messages(child)
    assert not c.events("session.result") and not c.events("session.error")


def http_handler(app, path):
    """Exercise the actual HTTP routes/serialization without opening a socket."""
    server = Server.__new__(Server)
    server.app, server.password, server.cors = app, None, []
    handler_type = server._handler()
    handler = handler_type.__new__(handler_type)
    handler.path, handler.headers = path, {}
    handler.statuses, handler.response_headers = [], []
    handler.send_response = handler.statuses.append
    handler.send_header = lambda name, value: handler.response_headers.append((name, value))
    handler.end_headers = lambda: None
    handler.wfile = io.BytesIO()
    return handler


def test_http_sync_route_serializes_only_the_approved_added_result_key(case):
    c, app = case, case.app
    c.model(lambda *_: Completion(text="HTTP answer", finish_reason="stop"))
    handler = http_handler(app, f"/session/{c.sid}/message")
    body = json.dumps({"text": "HTTP protocol request"}).encode("utf-8")
    handler.headers["Content-Length"] = str(len(body))
    handler.rfile = io.BytesIO(body)
    handler.do_POST()
    assert handler.statuses == [200]
    result = json.loads(handler.wfile.getvalue())
    assert_result_event(c, result)
    assert result["messageID"] == app.store.messages(c.sid)[-1]["id"]
    assert "resultID" not in result


def test_http_event_route_serializes_the_original_bus_result_without_another_event(case, monkeypatch):
    c, app = case, case.app
    c.extension(lambda sid, text, status: "HTTP assembled document\n" + text)
    c.model(lambda *_: Completion(text="HTTP source answer", finish_reason="stop"))
    handler = http_handler(app, "/event")
    real_subscribe = app.bus.subscribe
    result_box = {}

    def subscribe():
        box = real_subscribe()
        result_box["result"] = app.prompt(c.sid, "Execute after SSE subscription")
        return box

    class EventStream(io.BytesIO):
        stopped = False

        def write(self, data):
            written = super().write(data)
            if data.startswith(b"data: "):
                event = json.loads(data[6:])
                self.stopped = event["type"] == "session.status" and event["properties"]["status"] == "idle"
            return written

        def flush(self):
            if self.stopped:
                raise BrokenPipeError("Controlled client disconnect after idle")
            super().flush()

    monkeypatch.setattr(app.bus, "subscribe", subscribe)
    handler.wfile = EventStream()
    handler.do_GET()
    assert handler.statuses == [200]
    assert ("Content-Type", "text/event-stream") in handler.response_headers
    sent = [json.loads(line[6:]) for line in handler.wfile.getvalue().splitlines() if line.startswith(b"data: ")]
    assert sent == c.events()
    assert_result_event(c, result_box["result"])
    assert len(app.bus._subs) == 1, "SSE disconnect must remove its own subscription"
