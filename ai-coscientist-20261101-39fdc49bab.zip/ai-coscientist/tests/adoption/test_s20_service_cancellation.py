"""Attempt cancellation over local MCP/LSP protocols; no external services."""

import json
from pathlib import Path
import queue
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

import pytest

from opencode.lsp import LspClient, LspError
from opencode.mcp import McpHub
from opencode.permission import Broker, PermissionRejected, Rule
from opencode.tools import lsp_tool
from opencode.tools.types import ToolResult


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    for name in ("CONFIG", "DATA", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{name}_HOME", str(tmp_path / name.lower()))
    for name in ("TEMP", "TMP", "OPENCODE_TEST_HOME"):
        folder = tmp_path / name.lower()
        folder.mkdir()
        monkeypatch.setenv(name, str(folder))
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_DIR", "OPENCODE_CONFIG_CONTENT", "OPENCODE_AUTH_CONTENT"):
        monkeypatch.delenv(name, raising=False)
    return tmp_path


def until(predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.01)
    assert predicate()


def background(action):
    result = queue.Queue()

    def run():
        try:
            result.put(action())
        except BaseException as exc:
            result.put(exc)

    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    return thread, result


def cancelled(thread, result, abort):
    abort.set()
    thread.join(3)
    assert not thread.is_alive(), "attempt waiter survived cancellation"
    error = result.get_nowait()
    assert isinstance(error, LspError), repr(error)
    assert str(error) == "aborted"


def context(root, abort, *, permission="allow"):
    session_abort = threading.Event()
    broker = Broker()
    broker.abort_event = lambda _: session_abort
    app = SimpleNamespace(permissions=broker, abort_event=lambda _: session_abort)
    ctx = SimpleNamespace(app=app, session_id="session", directory=root, worktree=root,
                          agent=SimpleNamespace(permission=[Rule("*", "*", permission)]))
    if abort != "missing":
        ctx.abort = abort
    return ctx, session_abort


MCP_SERVER = r'''
import json, sys
from pathlib import Path
log = Path(sys.argv[1])
held = None
def reply(request, result):
    print(json.dumps({"jsonrpc":"2.0","id":request["id"],"result":result}), flush=True)
for line in sys.stdin:
    request = json.loads(line)
    with log.open("a", encoding="utf-8") as target:
        target.write(json.dumps(request) + "\n")
    method = request.get("method")
    if method == "initialize": reply(request, {"capabilities":{"tools":{}}})
    elif method == "tools/list": reply(request, {"tools":[{"name":"work","inputSchema":{"type":"object"}}]})
    elif method == "tools/call":
        if request["params"]["arguments"].get("hold"):
            held = request
        else:
            if held:
                reply(held, {"content":[{"type":"text","text":"late old result"}]})
                held = None
            reply(request, {"content":[{"type":"text","text":"next result"}]})
'''


def mcp_client(root):
    script, log = root / "mcp.py", root / "mcp.jsonl"
    script.write_text(MCP_SERVER, encoding="utf-8")
    hub = McpHub({"mcp": {"local": {"command": [sys.executable, str(script), str(log)], "timeout": 5000}}}, root)
    hub.connect_all()
    server = hub.servers["local"]
    assert server.connected, server.error
    return hub, server, log


def messages(log):
    return [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()] if log.exists() else []


def test_mcp_attempt_cancel_releases_lock_and_ignores_late_result(isolated):
    hub, server, log = mcp_client(isolated)
    first, queued = threading.Event(), threading.Event()
    ctx, session_abort = context(isolated, first)
    try:
        tool = hub.tool_specs()[0]
        thread, result = background(lambda: tool.execute({"hold": True}, ctx))
        until(lambda: any(m.get("method") == "tools/call" for m in messages(log)))
        other, box = background(lambda: hub.call(server, "work", {"queued": True}, abort_event=queued))
        cancelled(other, box, queued)
        cancelled(thread, result, first)
        assert not session_abort.is_set()
        assert server.connected and server.process.poll() is None
        ctx.abort = threading.Event()
        assert tool.execute({}, ctx).output == "next result"
        calls = [m for m in messages(log) if m.get("method") == "tools/call"]
        assert [m["params"] for m in calls] == [{"name": "work", "arguments": {"hold": True}}, {"name": "work", "arguments": {}}]
        assert {m["method"] for m in messages(log)} == {"initialize", "notifications/initialized", "tools/list", "tools/call"}
    finally:
        first.set()
        queued.set()
        hub.close()


@pytest.mark.parametrize("kind", ["mcp", "lsp"])
@pytest.mark.parametrize("abort_kind", ["attempt", "missing", "none"])
def test_service_permission_wait_uses_attempt_or_legacy_fallback(isolated, kind, abort_kind):
    attempt = threading.Event() if abort_kind == "attempt" else (None if abort_kind == "none" else "missing")
    ctx, session_abort = context(isolated, attempt, permission="ask")
    actual_abort = attempt if abort_kind == "attempt" else session_abort
    dispatched = []
    if kind == "mcp":
        hub, server, log = mcp_client(isolated)
        execute = lambda: hub.tool_specs()[0].execute({}, ctx)
    else:
        target = isolated / "file.py"
        target.write_text("value = 1\n", encoding="utf-8")
        def operation(*args, abort_event=None):
            dispatched.append(abort_event)
            return ToolResult("next result")
        ctx.app.lsp_operation = operation
        execute = lambda: lsp_tool().execute({"operation": "hover", "filePath": str(target), "line": 1, "character": 1}, ctx)
    try:
        thread, result = background(execute)
        until(lambda: bool(ctx.app.permissions.list_pending()))
        actual_abort.set()
        thread.join(3)
        assert not thread.is_alive()
        assert isinstance(result.get_nowait(), PermissionRejected)
        assert ctx.app.permissions.list_pending() == []
        if abort_kind == "attempt":
            assert not session_abort.is_set()
        if kind == "mcp":
            assert not any(m.get("method") == "tools/call" for m in messages(log))
        else:
            assert dispatched == []
        ctx.abort = threading.Event()
        ctx.agent.permission = [Rule("*", "*", "allow")]
        assert execute().output == "next result"
        if kind == "lsp":
            assert dispatched == [ctx.abort]
    finally:
        actual_abort.set()
        if kind == "mcp":
            hub.close()


@pytest.mark.parametrize("legacy_sse", [False, True])
@pytest.mark.parametrize("waiting_for", ["post", "result"])
def test_remote_mcp_cancel_preserves_shared_stream(isolated, legacy_sse, waiting_for):
    events, requests = queue.Queue(), []
    received, release, stop = threading.Event(), threading.Event(), threading.Event()
    held = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def empty(self, status):
            self.send_response(status)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            if legacy_sse:
                self.wfile.write(b"event: endpoint\ndata: /messages\n\n")
                self.wfile.flush()
            try:
                while not stop.is_set():
                    try:
                        item = events.get(timeout=0.05)
                    except queue.Empty:
                        continue
                    self.wfile.write(b"data: " + json.dumps(item).encode() + b"\n\n")
                    self.wfile.flush()
            except (OSError, ValueError):
                pass

        def do_POST(self):
            payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            requests.append(payload)
            if legacy_sse and self.path == "/mcp":
                self.empty(405)
                return
            method = payload["method"]
            if "id" not in payload:
                self.empty(202)
                return
            result = {"content": [{"type": "text", "text": "next result"}]}
            if method == "initialize":
                result = {"capabilities": {"tools": {}}}
            elif method == "tools/list":
                result = {"tools": []}
            elif method == "tools/call" and payload["params"]["arguments"].get("hold"):
                held.append(payload["id"])
                received.set()
                if waiting_for == "post":
                    release.wait(5)
                elif not legacy_sse:
                    self.send_response(200)
                    self.send_header("Content-Type", "text/event-stream")
                    self.end_headers()
                    self.wfile.flush()
                    release.wait(5)
                    return
                if legacy_sse:
                    self.empty(202)
                    return
                result = {"content": [{"type": "text", "text": "late old result"}]}
            reply = {"jsonrpc": "2.0", "id": payload["id"], "result": result}
            if legacy_sse:
                self.empty(202)
                if method == "tools/call" and held:
                    events.put({"jsonrpc": "2.0", "id": held.pop(), "result": {"content": [{"type": "text", "text": "late old result"}]}})
                events.put(reply)
                return
            raw = json.dumps(reply).encode()
            try:
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            except OSError:
                pass

    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    worker = threading.Thread(target=httpd.serve_forever, daemon=True)
    worker.start()
    hub = McpHub({"mcp": {"remote": {"url": f"http://127.0.0.1:{httpd.server_port}/mcp", "oauth": False, "timeout": 5000}}}, isolated)
    abort = threading.Event()
    try:
        hub.connect_all()
        server = hub.servers["remote"]
        assert server.connected, server.error
        shared = server._sse_client if legacy_sse else server._notification_client
        thread, result = background(lambda: hub.call(server, "work", {"hold": True}, abort_event=abort))
        assert received.wait(3)
        cancelled(thread, result, abort)
        assert server._http_pending == server._http_clients == server._http_progress == {}
        assert server.connected and not shared.is_closed
        release.set()
        assert hub.call(server, "work", {}, abort_event=threading.Event()) == ("next result", [])
        calls = [item for item in requests if item["method"] == "tools/call"]
        assert [item["params"] for item in calls] == [{"name": "work", "arguments": {"hold": True}}, {"name": "work", "arguments": {}}]
        assert not any("cancel" in item["method"] for item in requests)
    finally:
        abort.set()
        release.set()
        stop.set()
        hub.close()
        httpd.shutdown()
        httpd.server_close()
        worker.join(2)


LSP_SERVER = r'''
import json, sys
from pathlib import Path
log, mode = Path(sys.argv[1]), sys.argv[2]
held = None
def read():
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line: raise EOFError()
        if line == b"\r\n": break
        key, value = line.decode().split(":", 1)
        headers[key.lower()] = value.strip()
    return json.loads(sys.stdin.buffer.read(int(headers["content-length"])))
def write(payload):
    raw = json.dumps(payload).encode()
    sys.stdout.buffer.write(f"Content-Length: {len(raw)}\r\n\r\n".encode() + raw)
    sys.stdout.buffer.flush()
def reply(request, result):
    write({"jsonrpc":"2.0","id":request["id"],"result":result})
while True:
    request = read()
    with log.open("a", encoding="utf-8") as target:
        target.write(json.dumps(request) + "\n")
    method = request["method"]
    if method == "initialize" and mode != "init": reply(request, {"capabilities":{}})
    elif method == "textDocument/didOpen" and mode != "diagnostics":
        write({"jsonrpc":"2.0","method":"textDocument/publishDiagnostics","params":{"uri":request["params"]["textDocument"]["uri"],"version":0,"diagnostics":[]}})
    elif method == "textDocument/hover":
        if request["params"]["position"]["line"] == 0:
            held = request
        else:
            if held:
                reply(held, {"contents":"late old result"})
                held = None
            reply(request, {"contents":"next result"})
'''


@pytest.mark.parametrize("stage", ["diagnostics", "response", "init"])
def test_lsp_cancel_cleans_attempt_and_preserves_shared_client(isolated, stage):
    script, log, path = isolated / "lsp.py", isolated / "lsp.jsonl", isolated / "file.py"
    script.write_text(LSP_SERVER, encoding="utf-8")
    path.write_text("value = 1\n", encoding="utf-8")
    client = LspClient([sys.executable, str(script), str(log), stage], isolated, timeout=5)
    abort = threading.Event()
    ctx, session_abort = context(isolated, abort)
    def operation(operation, path, line, character, query, *, abort_event=None):
        result = client.operation(operation, path, line, character, query, abort_event=abort_event)
        return ToolResult(json.dumps(result))
    ctx.app.lsp_operation = operation
    execute = lambda line: lsp_tool().execute({"operation": "hover", "filePath": str(path), "line": line, "character": 1}, ctx)
    try:
        if stage == "init":
            thread, result = background(lambda: client.start(abort_event=abort))
            until(lambda: any(m["method"] == "initialize" for m in messages(log)))
        else:
            client.start()
            thread, result = background(lambda: execute(1))
            target = "textDocument/didOpen" if stage == "diagnostics" else "textDocument/hover"
            until(lambda: any(m["method"] == target for m in messages(log)))
        cancelled(thread, result, abort)
        assert not session_abort.is_set()
        assert client._pending == {}
        if stage == "init":
            assert client.process.poll() is not None
            assert all(stream.closed for stream in (client.process.stdin, client.process.stdout))
            return
        assert client.process.poll() is None
        # A later push notification satisfies the next wait without running new RPCs.
        if stage == "diagnostics":
            client._publish_diagnostics({"uri": path.as_uri(), "version": 0, "diagnostics": []})
        ctx.abort = threading.Event()
        assert json.loads(execute(2).output) == {"contents": "next result"}
        assert client._pending == {}
        assert {m["method"] for m in messages(log)} <= {"initialize", "initialized", "textDocument/didOpen", "textDocument/hover"}
    finally:
        abort.set()
        client.stop()
