"""Long commands reach a POSIX shell on Windows whole (Git Bash cuts `bash -c` past about 8192 characters)."""

import json
import os
from pathlib import Path
import shutil

import pytest

from opencode.tools import shell

GIT_BASH = next((path for path in (r"C:\Program Files\Git\bin\bash.exe", shutil.which("bash") or "")
                 if os.name == "nt" and path and Path(path).is_file()), None)


def test_only_long_commands_for_a_posix_shell_on_windows_go_through_a_script(tmp_path, monkeypatch):
    monkeypatch.setattr(shell, "tmp_dir", lambda: tmp_path)
    monkeypatch.setattr(shell.os, "name", "nt")
    long = "echo " + "x" * shell.LONG_COMMAND
    assert shell._command_script("echo short", "bash") is None
    assert shell._command_script(long, "powershell") is None
    script = shell._command_script(long, r"C:\Program Files\Git\bin\bash.exe")
    assert script.parent == tmp_path and script.read_bytes() == long.encode("utf-8")
    assert shell._command_line(long, "bash", script) == ["bash", script.as_posix()]
    assert shell._command_line("printf ok", "bash") == ["bash", "-c", "printf ok"]  # unchanged otherwise
    monkeypatch.setattr(shell.os, "name", "posix")
    assert shell._command_script(long, "bash") is None


@pytest.mark.skipif(GIT_BASH is None, reason="needs Git Bash on Windows")
def test_a_long_command_and_a_long_heredoc_run_to_the_end_through_git_bash(tmp_path):
    out, _, code, reason = shell._run("echo START; : " + "x" * 20000 + "; echo END", tmp_path, dict(os.environ),
                                      30, None, executable=GIT_BASH)
    assert (out.split(), code, reason) == (["START", "END"], 0, "")
    body = json.dumps({"hypotheses": [{"id": f"H{i}", "statement": "酸擴散與淬滅劑" * 40} for i in range(30)]},
                      ensure_ascii=False)
    out, _, code, _ = shell._run("cat > hypotheses.json <<'EOF'\n" + body + "\nEOF\necho written", tmp_path,
                                 dict(os.environ), 30, None, executable=GIT_BASH)
    assert out.strip() == "written" and code == 0
    assert json.loads((tmp_path / "hypotheses.json").read_text(encoding="utf-8")) == json.loads(body)
    assert not list(shell.tmp_dir().glob("command-*.sh"))  # removed after the command finished
