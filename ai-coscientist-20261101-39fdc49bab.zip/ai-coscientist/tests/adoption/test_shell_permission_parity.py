"""Deterministic shell permission boundaries and real subprocess cancellation."""

import ctypes
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from opencode.permission import Broker, PermissionDenied, PermissionRejected, Rule
from opencode.tools import shell
from opencode.tools import shell_ast


class ShellPermissionParity(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        paths = patch.dict(os.environ, {"XDG_DATA_HOME": str(self.root / "data")})
        paths.start()
        self.addCleanup(paths.stop)
        self.project = self.root / "project"
        self.project.mkdir()
        self.abort = threading.Event()
        self.requests = []
        self.broker = Broker(callback=lambda request: self.requests.append(request) or "once")
        self.broker.abort_event = lambda _: self.abort
        self.ctx = SimpleNamespace(
            session_id="shell-test", directory=self.project, worktree=self.project,
            agent=SimpleNamespace(name="build", permission=[]),
            app=SimpleNamespace(permissions=self.broker, abort_event=lambda _: self.abort,
                                store=SimpleNamespace(get_session=lambda _: {})),
        )

    def scan(self, command, interpreter="bash"):
        return shell_ast.scan(command, self.project, self.project, interpreter)

    def test_arity_matches_upstream_cases_and_nested_overrides(self):
        for tokens, expected in [
            ([], []), (["unknown", "command", "subcommand"], ["unknown"]),
            (["touch", "file"], ["touch"]), (["git"], ["git"]),
            (["git", "checkout", "main"], ["git", "checkout"]),
            (["docker", "run", "nginx"], ["docker", "run"]),
            (["aws", "s3", "ls", "bucket"], ["aws", "s3", "ls"]),
            (["npm", "run", "dev", "script"], ["npm", "run", "dev"]),
            (["docker", "compose", "up", "service"], ["docker", "compose", "up"]),
            (["consul", "kv", "get", "config"], ["consul", "kv", "get"]),
            (["git", "remote", "add", "origin"], ["git", "remote", "add"]),
            (["Remove-Item", "-Recurse", "file"], ["Remove-Item"]),
        ]:
            with self.subTest(tokens=tokens):
                self.assertEqual(shell_ast.arity_prefix(tokens), expected)

    def test_bash_ast_handles_conditionals_pipeline_nested_and_quoted_separators(self):
        _, patterns, always = self.scan('echo "a; b"; git status | cat; if true; then echo $(pwd); fi')
        self.assertEqual(patterns, ['echo "a; b"', "git status", "cat", "true", "echo $(pwd)", "pwd"])
        self.assertEqual(always, ["echo *", "git status *", "cat *", "true *", "pwd *"])

    def test_redirect_is_in_command_pattern(self):
        self.assertEqual(self.scan("echo test > output.txt")[1:],
                         (["echo test > output.txt"], ["echo *"]))

    def test_powershell_ast_handles_conditional_and_cmdlet_arity(self):
        _, patterns, always = self.scan(
            'Write-Host "a; b"; if ($?) { Remove-Item -Recurse -Force -LiteralPath local.txt }', "powershell.exe")
        self.assertEqual(patterns, ['Write-Host "a; b"', "Remove-Item -Recurse -Force -LiteralPath local.txt"])
        self.assertEqual(always, ["Write-Host *", "Remove-Item *"])

    def test_command_patterns_enforce_deny_before_process_launch(self):
        self.ctx.agent.permission = [Rule("bash", "*", "allow"), Rule("bash", "git status", "deny")]
        with patch.object(shell, "_shell_executable", return_value="bash"), patch.object(shell, "_run") as run:
            with self.assertRaises(PermissionDenied):
                shell._bash({"command": "echo ok; git status"}, self.ctx)
        run.assert_not_called()

    def test_always_grants_only_upstream_command_prefix(self):
        self.broker.callback = lambda request: self.requests.append(request) or "always"
        with patch.object(shell, "_shell_executable", return_value="bash"), patch.object(shell, "_run", return_value=("", "", 0, "")):
            shell._bash({"command": "git status --short"}, self.ctx)
            shell._bash({"command": "git status --branch"}, self.ctx)
            shell._bash({"command": "git diff"}, self.ctx)
        self.assertEqual(len(self.requests), 2)
        self.assertEqual(self.requests[0].patterns, ["git status --short"])
        self.assertEqual(self.requests[0].always, ["git status *"])
        self.assertEqual(self.requests[1].always, ["git diff *"])
        self.assertNotIn("*", [rule.pattern for rule in self.broker._approved])

    def test_plan_uses_same_bash_permission_rules_as_upstream(self):
        self.ctx.agent.name = "plan"
        with patch.object(shell, "_shell_executable", return_value="bash"), patch.object(shell, "_run", return_value=("", "", 0, "")):
            shell._bash({"command": "echo ok; touch local.txt"}, self.ctx)
        self.assertEqual([request.permission for request in self.requests], ["bash"])
        self.assertEqual(self.requests[0].patterns, ["echo ok", "touch local.txt"])

    def test_external_workdir_and_file_argument_are_separate_from_bash_patterns(self):
        outside = self.root / "outside"
        outside.mkdir()
        target = outside / "file.txt"
        command = f'cat "{target}"'
        with patch.object(shell, "_shell_executable", return_value="bash"), patch.object(shell, "_run", return_value=("", "", 0, "")):
            shell._bash({"command": command, "workdir": str(outside)}, self.ctx)
        self.assertEqual([request.permission for request in self.requests], ["external_directory", "bash"])
        expected = str(outside / "*")
        self.assertEqual(self.requests[0].patterns, [expected])
        self.assertEqual(self.requests[0].always, [expected])
        self.assertEqual(self.requests[1].patterns, [command])
        self.assertEqual(self.requests[0].metadata, {"command": command, "directories": [str(outside)], "patterns": [expected]})
        self.assertEqual(self.requests[1].metadata, {"command": command})

    def test_powershell_explicit_path_flags_environment_provider_and_wildcards(self):
        outside = self.root / "outside"
        outside.mkdir()
        with patch.dict(os.environ, {"SHELL_PARITY_OUTSIDE": str(outside)}):
            directories, _, always = self.scan(
                'Remove-Item -Recurse -Force -LiteralPath "FileSystem::$env:SHELL_PARITY_OUTSIDE/*.txt"', "powershell")
        self.assertEqual(directories, [outside])
        self.assertEqual(always, ["Remove-Item *"])
        self.assertEqual(self.scan("Get-Content variable:thing", "powershell")[0], [])

    def test_cd_only_checks_external_directory(self):
        directories, patterns, always = self.scan(f'cd "{self.root}"')
        self.assertEqual(directories, [self.root])
        self.assertEqual((patterns, always), ([], []))

    def test_parse_failure_propagates_and_never_executes(self):
        with patch.object(shell_ast, "Parser") as parser, patch.object(shell, "_run") as run:
            parser.return_value.parse.return_value = None
            with self.assertRaisesRegex(RuntimeError, "Failed to parse command"):
                shell._bash({"command": "echo test"}, self.ctx)
        run.assert_not_called()

    @unittest.skipUnless(os.name == "nt", "Windows path normalization")
    def test_windows_posix_drive_forms_and_cygpath_are_resolved_before_authorization(self):
        slash = self.project.as_posix()
        drive, rest = slash.split(":", 1)
        for raw in [slash, f"/{drive}{rest}", f"/{drive}:{rest}", f"/cygdrive/{drive}{rest}", f"/mnt/{drive}{rest}"]:
            with self.subTest(raw=raw):
                self.assertEqual(shell_ast.resolve_shell_path(raw, self.root, "bash"), self.project)
        outside = self.root / "git-temp"
        outside.mkdir()
        with patch.object(shell_ast.subprocess, "run", return_value=SimpleNamespace(
                stdout=str(outside) + "\n", returncode=0)) as cygpath:
            with patch.object(shell, "_shell_executable", return_value="bash"), patch.object(shell, "_run", return_value=("", "", 0, "")):
                shell._bash({"command": 'cat "/tmp/file.txt"', "workdir": "/tmp"}, self.ctx)
        self.assertEqual(cygpath.call_count, 2)
        self.assertEqual(cygpath.call_args.args[0], ["bash", "-lc", 'cygpath -w -- "$1"', "_", "/tmp/file.txt"])
        self.assertEqual(self.requests[0].patterns, [str(outside / "*")])
        self.assertEqual(self.requests[1].patterns, ['cat "/tmp/file.txt"'])

    def test_negative_timeout_is_rejected_before_permissions_or_launch(self):
        with patch.object(shell, "_run") as run:
            with self.assertRaisesRegex(ValueError, "Invalid timeout value: -1"):
                shell._bash({"command": "echo test", "timeout": -1}, self.ctx)
        self.assertEqual(self.requests, [])
        run.assert_not_called()

    def test_zero_timeout_is_not_replaced_by_default(self):
        with patch.object(shell, "_run", return_value=("", "", None, "timeout")) as run:
            result = shell._bash({"command": "echo test", "timeout": 0}, self.ctx)
        self.assertEqual(run.call_args.args[3], 0.0)
        self.assertIn("exceeding timeout 0 ms", result.output)
        self.assertIsNone(result.metadata["exit"])

    def test_failed_process_launch_releases_windows_job(self):
        if os.name != "nt":
            self.skipTest("Windows job lifecycle")
        kernel = SimpleNamespace(CloseHandle=lambda handle: closed.append(handle))
        closed = []
        with patch.object(shell, "_windows_job", return_value=(kernel, 123)), patch.object(
                shell.subprocess, "Popen", side_effect=FileNotFoundError("missing shell")):
            with self.assertRaises(FileNotFoundError):
                shell._run("echo test", self.project, {}, 1, self.abort)
        self.assertEqual(closed, [123])

    @unittest.skipUnless(os.name == "nt", "Windows suspended process lifecycle")
    def test_failed_resume_terminates_suspended_shell_and_releases_job(self):
        launched = []
        original_popen = subprocess.Popen

        def capture(*args, **kwargs):
            self.assertTrue(kwargs["creationflags"] & 0x00000004)
            self.assertTrue(kwargs["creationflags"] & subprocess.CREATE_NO_WINDOW)
            process = original_popen(*args, **kwargs)
            launched.append(process)
            return process

        with patch.dict(os.environ, self.shell_environment()), patch.object(shell.subprocess, "Popen", side_effect=capture), patch.object(
                shell, "_resume_windows_process", side_effect=RuntimeError("resume failed")):
            with self.assertRaisesRegex(RuntimeError, "resume failed"):
                shell._run("echo MUST_NOT_RUN", self.project, os.environ.copy(), 1, self.abort)
        self.assertEqual(len(launched), 1)
        self.assertIsNotNone(launched[0].poll())

    @unittest.skipUnless(os.name == "nt", "Windows suspended process lifecycle")
    def test_failed_job_assignment_kills_suspended_shell_and_closes_handle(self):
        import ctypes
        launched, closed = [], []
        original_popen = subprocess.Popen
        def reject_assignment(*args):
            ctypes.set_last_error(5)
            return False
        def reject_termination(*args):
            self.fail("An unassigned job must not be used to terminate this process")
        kernel = SimpleNamespace(AssignProcessToJobObject=reject_assignment,
                                 TerminateJobObject=reject_termination,
                                 CloseHandle=lambda handle: closed.append(handle))

        def capture(*args, **kwargs):
            process = original_popen(*args, **kwargs)
            launched.append(process)
            return process

        with patch.dict(os.environ, self.shell_environment()), patch.object(shell.subprocess, "Popen", side_effect=capture), patch.object(
                shell, "_windows_job", return_value=(kernel, 123)), patch.object(shell, "_resume_windows_process") as resume:
            with self.assertRaises(OSError) as raised:
                shell._run("echo MUST_NOT_RUN", self.project, os.environ.copy(), 1, self.abort)
        resume.assert_not_called()
        self.assertEqual(len(launched), 1)
        self.assertIsNotNone(launched[0].poll())
        self.assertEqual(closed, [123])
        self.assertEqual(raised.exception.winerror, 5)
        self.assertEqual(getattr(raised.exception, "__notes__", []), [])

    def test_abort_before_launch_does_not_start_process(self):
        self.abort.set()
        with patch.object(shell, "_run") as run:
            with self.assertRaises(PermissionRejected):
                shell._bash({"command": "echo test"}, self.ctx)
        run.assert_not_called()

    def command(self, code):
        script = self.project / "command.py"
        script.write_text(code, encoding="utf-8")
        if os.name == "nt":
            return f"& '{sys.executable}' '{script}'; exit $LASTEXITCODE"
        import shlex
        return shlex.join([sys.executable, str(script)])

    def shell_environment(self):
        return {"SHELL": "powershell" if os.name == "nt" else "bash"}

    def test_real_process_preserves_complete_stdout_stderr_and_exit(self):
        self.broker.auto = True
        code = 'import sys; sys.stdout.write("S"*100000); sys.stderr.write("E"*100000); sys.exit(7)'
        with patch.dict(os.environ, self.shell_environment()):
            result = shell._bash({"command": self.command(code)}, self.ctx)
        saved = Path(result.metadata["outputPath"]).read_text(encoding="utf-8")
        self.assertIn("S" * 100000, saved, "saved stdout was incomplete")
        self.assertIn("E" * 100000, saved, "saved stderr was incomplete")
        body, _, notice = result.output.rpartition("\n\n<shell_metadata>\n")
        self.assertTrue(body.endswith("E" * 51200))
        self.assertEqual(notice, "Command exited with code 7.\n</shell_metadata>")
        self.assertEqual(result.metadata["exit"], 7)
        self.assertTrue(result.metadata["truncated"])
        self.assertEqual(result.metadata["output"], "...\n\n" + "E" * 30000)

    def test_real_timeout_retains_partial_stdout_and_stderr(self):
        self.broker.auto = True
        code = 'import sys,time; print("TIMEOUT_STDOUT",flush=True); print("TIMEOUT_STDERR",file=sys.stderr,flush=True); time.sleep(30)'
        with patch.dict(os.environ, self.shell_environment()):
            result = shell._bash({"command": self.command(code), "timeout": 2000}, self.ctx)
        self.assertIn("TIMEOUT_STDOUT", result.output)
        self.assertIn("TIMEOUT_STDERR", result.output)
        self.assertIn("exceeding timeout 2000 ms", result.output)
        self.assertIsNone(result.metadata["exit"])
        self.assertFalse(result.metadata["truncated"])

    def test_real_cancel_terminates_shell_and_descendant(self):
        self.broker.auto = True
        pid_file = self.project / "child.pid"
        child = ('import os,pathlib,time; pathlib.Path(' + repr(str(pid_file)) +
                 ').write_text(str(os.getpid())); print("CHILD_READY",flush=True); time.sleep(30)')
        parent = ('import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",' + repr(child) +
                  ']); print("PARENT_READY",flush=True); print("PARENT_STDERR",file=sys.stderr,flush=True); time.sleep(30)')
        outcomes, errors, launched = [], [], []
        original_popen = subprocess.Popen

        def capture_popen(*args, **kwargs):
            process = original_popen(*args, **kwargs)
            if args and args[0][0] != "taskkill":
                launched.append(process.pid)
            return process

        def execute():
            try:
                outcomes.append(shell._bash({"command": self.command(parent)}, self.ctx))
            except Exception as exc:
                errors.append(exc)

        with patch.dict(os.environ, self.shell_environment()), patch.object(shell.subprocess, "Popen", side_effect=capture_popen):
            thread = threading.Thread(target=execute, daemon=True)
            thread.start()
            deadline = time.monotonic() + 8
            while not pid_file.exists() and time.monotonic() < deadline:
                time.sleep(0.02)
            self.abort.set()
            thread.join(8)
        self.assertFalse(thread.is_alive(), "shell did not stop after cancellation")
        self.assertEqual(errors, [])
        self.assertTrue(pid_file.exists(), "descendant never started")
        child_pid = int(pid_file.read_text())
        self.assertIn("PARENT_READY", outcomes[0].output)
        self.assertIn("PARENT_STDERR", outcomes[0].output)
        self.assertIn("User aborted the command", outcomes[0].output)
        self.assertFalse(self.pid_alive(child_pid), "descendant survived cancellation")
        self.assertTrue(launched)
        self.assertFalse(self.pid_alive(launched[0]), "shell survived cancellation")

    @staticmethod
    def pid_alive(pid):
        if os.name == "nt":
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.OpenProcess.restype = ctypes.c_void_p
            kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
            kernel.CloseHandle.argtypes = [ctypes.c_void_p]
            handle = kernel.OpenProcess(0x00100000, False, pid)
            if not handle:
                return False
            try:
                return kernel.WaitForSingleObject(handle, 0) == 258
            finally:
                kernel.CloseHandle(handle)
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        return True


if __name__ == "__main__":
    unittest.main()
