"""Terminal encoding and lossless saved-output continuation, without a model."""

import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from opencode.app import App
from opencode.loop import ToolContext, _present_history
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from opencode.tools import shell
from opencode.tools.files import _read
from opencode.tools.util import truncate, truncate_output


def streamed(text, stderr="", exit=0, reason=""):
    def execute(*args, **kwargs):
        for item in (text, stderr):
            if item:
                kwargs["on_chunk"](item)
        return "", "", exit, reason
    return execute


class ShellReceipts(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        env = patch.dict(os.environ, {key: str(self.root / name) for key, name in {
            "OPENCODE_TEST_HOME": "home", "OPENCODE_CONFIG_DIR": "config",
            "XDG_CONFIG_HOME": "global-config", "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache"}.items()})
        env.start()
        self.addCleanup(env.stop)
        self.project = self.root / "project"
        self.project.mkdir()
        (self.project / ".git").mkdir()
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.app = App(self.project, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]

    def ctx(self):
        return ToolContext(self.app, self.sid, self.app.agents["build"], "m", "c", 0,
                           self.project, self.project, set(), 1)

    def test_truncation_saves_full_multiline_long_line_and_unicode(self):
        for text, byte_limit, line_limit in [
            ("first\n" + "line\n" * 100 + "END", 50, 2000),
            ("first\n" + "x" * 120000 + "END", 51, 2000),
            ("中文😀" * 30000 + "END", 53, 2000),
            ("a\r\nb\rc\n" * 100 + "END", 5000, 3),
        ]:
            with self.subTest(bytes=byte_limit, lines=line_limit):
                output, metadata = truncate_output(text, max_bytes=byte_limit, max_lines=line_limit)
                self.assertTrue(metadata["truncated"])
                self.assertEqual(Path(metadata["outputPath"]).read_bytes(), text.encode("utf-8"))
                self.assertIn("Full output saved to:", output)
                self.assertIn("offset/limit", output)
                self.assertNotIn("charOffset", output)

    def test_short_output_is_unchanged(self):
        self.assertEqual(truncate("exact\r\ntext"), "exact\r\ntext")

    def test_shell_tail_and_full_output_reference_survive_restart(self):
        text = ("中文 receipt\n" * 3000) + "TAIL_ONLY_HERE"
        calls = []
        owner = self
        class Provider:
            def resolve(self, model=None):
                return SimpleNamespace(id="test", context=131072), "test"
            def complete(self, **kwargs):
                calls.append(kwargs)
                if len(calls) == 1:
                    return Completion(tool_calls=[ToolCall("shell1", "bash", {"command": "fixture-command"})], finish_reason="tool_calls")
                wire = next(m["content"] for m in kwargs["messages"] if m["role"] == "tool")
                owner.assertIn("TAIL_ONLY_HERE", wire)
                owner.assertEqual(wire.count("output truncated"), 1)
                return Completion(text="Delivered after inspecting tail", finish_reason="stop")
        self.app.provider = Provider()
        with patch.object(shell, "_run", side_effect=streamed(text)) as execute:
            result = self.app.prompt(self.sid, "Inspect the command output")
        self.assertEqual(result["status"], "completed")
        execute.assert_called_once()
        saved = next(m for m in self.store.messages(self.sid) if m.get("name") == "bash")
        self.assertEqual(Path(saved["metadata"]["outputPath"]).read_bytes(), text.encode())
        reopened = Store(self.store.path)
        try:
            restored = next(m for m in reopened.messages(self.sid) if m.get("name") == "bash")
            presented = _present_history([restored], reopened, self.sid)[0]["content"]
            self.assertEqual(presented, saved["content"])
            self.assertIn("TAIL_ONLY_HERE", presented)
            self.assertEqual(Path(restored["metadata"]["outputPath"]).read_bytes(), text.encode())
        finally:
            reopened.close()

    def test_failed_command_preserves_full_output_and_states_the_exit_after_it(self):
        # Departure from upstream: the model must be able to tell a failed command from a quiet one.
        text = "x" * 100000
        with patch.object(shell, "_run", side_effect=streamed(text, "TAIL_ERROR", exit=7)):
            result = shell._bash({"command": "fixture-command"}, self.ctx())
        self.assertEqual(Path(result.metadata["outputPath"]).read_bytes(), (text + "TAIL_ERROR").encode())
        self.assertTrue(result.output.endswith("TAIL_ERROR\n\n<shell_metadata>\nCommand exited with code 7.\n"
                                               "</shell_metadata>"))
        self.assertEqual(result.metadata["exit"], 7)

    def test_timeout_preserves_partial_output_file_and_null_exit(self):
        text = "中文" * 30000
        with patch.object(shell, "_run", side_effect=streamed(text, "TAIL", exit=None, reason="timeout")):
            result = shell._bash({"command": "fixture-command", "timeout": 1000}, self.ctx())
        self.assertEqual(Path(result.metadata["outputPath"]).read_bytes(), (text + "TAIL").encode())
        self.assertIn("TAIL\n\n<shell_metadata>", result.output)
        self.assertIn("exceeding timeout 1000 ms", result.output)
        self.assertIsNone(result.metadata["exit"])

    def test_posix_shell_command_is_not_changed(self):
        self.assertEqual(shell._command_line("printf ok", "/bin/bash"), ["/bin/bash", "-c", "printf ok"])

    @unittest.skipUnless(shutil.which("powershell") or shutil.which("pwsh"), "PowerShell not installed")
    def test_real_powershell_respects_explicit_encoding_and_command_exit(self):
        self.app.config["shell"] = shutil.which("powershell") or shutil.which("pwsh")
        expected = "中文 UTF8 text"
        utf8 = self.project / "no-bom.txt"
        utf8.write_bytes(expected.encode("utf-8"))
        utf16 = self.project / "explicit.txt"
        utf16.write_bytes(expected.encode("utf-16-le"))
        command = ("[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); "
                   f"Get-Content '{utf8}' -Encoding UTF8; Get-Content '{utf16}' -Encoding Unicode; "
                   f"[Console]::Error.WriteLine('{expected}'); exit 7")
        result = shell._bash({"command": command}, self.ctx())
        self.assertEqual(result.output.splitlines().count(expected), 3)
        self.assertEqual(result.metadata["exit"], 7)


if __name__ == "__main__":
    unittest.main()
