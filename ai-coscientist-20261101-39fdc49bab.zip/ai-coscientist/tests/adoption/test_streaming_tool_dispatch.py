"""Locked AI SDK tool-call timing and processor cleanup; no model service."""

import json
import threading
import time

import pytest

from opencode.app import App
from opencode.permission import PermissionRejected
from opencode.provider import Completion, ProviderError, ToolCall, _RequestAbort
from opencode.store import Store
from opencode.tools.types import Tool, ToolResult


def wait_until(predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while not predicate():
        assert time.monotonic() < deadline, "Timed out at a controlled stream boundary"
        threading.Event().wait(0.005)


def send(consume, *, text=None, calls=None, finish=None):
    delta = {}
    if text is not None:
        delta["content"] = text
    if calls is not None:
        delta["tool_calls"] = calls
    consume("data: " + json.dumps({"choices": [{"delta": delta, "finish_reason": finish}]}))


def call(index, name="observe", raw="{}"):
    return {"index": index, "id": f"call-{index}", "function": {"name": name, "arguments": raw}}


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    for name in ("XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME", "OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR"):
        monkeypatch.setenv(name, str(tmp_path / name))
    app = App(tmp_path, store=Store(tmp_path / "state.db"), auto_approve=True, config={
        "model": "local/test", "provider": {"local": {
            "api": "openai", "options": {"baseURL": "http://model.invalid/v1", "apiKey": "fixture"},
            "models": {"test": {"limit": {"context": 64000, "output": 8000}}},
        }},
    })
    app.generate_titles = False
    sid = app.create_session()["id"]
    yield app, sid
    app.abort(sid)
    wait_until(lambda: sid not in app._running)
    app.store.close()


def install_tool(app, execute):
    app.extra_tools = [Tool("observe", "Exercise a controlled tool boundary.", {"type": "object"}, execute)]


def receipts(app, sid):
    return [message for message in app.store.messages(sid) if message["role"] == "tool"]


def run_thread(app, sid, **kwargs):
    outcome = {}

    def invoke():
        try:
            outcome["result"] = app.prompt(sid, "Exercise the controlled stream", **kwargs)
        except BaseException as error:
            outcome["error"] = error

    thread = threading.Thread(target=invoke)
    thread.start()
    return thread, outcome


def test_duplicate_tool_definition_matches_advertised_schema_and_execution(runtime, monkeypatch):
    app, sid = runtime
    executed, requests = [], []

    def old(args, ctx):
        executed.append("old")
        return ToolResult(output="Wrong implementation")

    def replacement(args, ctx):
        executed.append(("replacement", args))
        return ToolResult(output="Replacement received " + args["new"])

    old_schema = {"type": "object", "properties": {"old": {"type": "string"}}, "required": ["old"]}
    new_schema = {"type": "object", "properties": {"new": {"type": "string"}}, "required": ["new"]}
    app.extra_tools = [Tool("observe", "Old", old_schema, old),
                       Tool("observe", "Replacement", new_schema, replacement)]

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        offered = [item["function"] for item in body["tools"] if item["function"]["name"] == "observe"]
        assert offered == [{"name": "observe", "description": "Replacement", "parameters": new_schema}]
        if len(requests) == 1:
            send(consume, calls=[call(0, raw='{"new":"value"}')])
            send(consume, finish="tool_calls")
        else:
            assert any(message.get("role") == "tool" and message.get("content") == "Replacement received value"
                       for message in body["messages"])
            send(consume, text="Done", finish="stop")

    monkeypatch.setattr("opencode.provider._stream", stream)
    assert app.prompt(sid, "Exercise the duplicate tool record")["status"] == "completed"
    assert len(requests) == 2
    assert executed == [("replacement", {"new": "value"})]
    assert [message["content"] for message in receipts(app, sid)] == ["Replacement received value"]


def test_calls_start_before_finish_concurrently_and_finish_waits_for_results(runtime, monkeypatch):
    app, sid = runtime
    rendezvous = threading.Barrier(3, timeout=3)
    release, stream_finished = threading.Event(), threading.Event()
    executions, requests, signals = [], [], []

    def execute(args, ctx):
        signals.append(ctx.abort)
        executions.append(ctx.call_id)
        rendezvous.wait()
        assert release.wait(3)
        assert not ctx.abort.is_set(), "Normal completion cancelled a tool before it returned"
        return ToolResult(output="saved " + ctx.call_id)

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        if len(requests) > 1:
            send(consume, text="All observations received", finish="stop")
            return
        send(consume, calls=[call(0), call(1)])
        rendezvous.wait()  # Both workers must start while this stream is open.
        assistant = app.store.messages(sid)[-1]
        assert len(assistant["tool_calls"]) == 2
        assert assistant.get("finish_reason") is None
        send(consume, finish="tool_calls")
        stream_finished.set()

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    thread, outcome = run_thread(app, sid)
    try:
        assert stream_finished.wait(3)
        assert thread.is_alive()
        assert len(signals) == 2 and all(isinstance(signal, threading.Event) and not signal.is_set() for signal in signals)
        assert app.store.messages(sid)[-1].get("finish_reason") is None
        release.set()
        thread.join(3)
        assert not thread.is_alive() and "error" not in outcome
        assert outcome["result"]["text"] == "All observations received"
        assert sorted(executions) == ["call-0", "call-1"]
        assert len(receipts(app, sid)) == 2 and len(requests) == 2
        assert all(signal.is_set() for signal in signals)
    finally:
        release.set()
        app.abort(sid)
        thread.join(3)


def test_partial_json_waits_until_complete_and_s10_runs_before_dispatch(runtime, monkeypatch):
    app, sid = runtime
    executed, requests = [], []

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        if len(requests) > 1:
            send(consume, text="done", finish="stop")
            return
        send(consume, calls=[call(0, "OBSERVE", '{"value":')])
        assert not executed
        assert app.store.messages(sid)[-1]["incomplete_tool_calls"][0]["arguments"] == {"_raw": '{"value":'}
        send(consume, calls=[{"index": 0, "function": {"arguments": "1}"}}])
        wait_until(lambda: executed)
        assert executed == [{"value": 1}]
        assert app.store.messages(sid)[1]["tool_calls"][0]["name"] == "observe"
        send(consume, finish="tool_calls")

    install_tool(app, lambda args, ctx: executed.append(args) or ToolResult(output="observed"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    assert app.prompt(sid, "Inspect input")["text"] == "done"
    assert len(executed) == len(receipts(app, sid)) == 1


def test_stream_failure_keeps_side_effect_and_closes_partial_call_without_replay(runtime, monkeypatch):
    app, sid = runtime
    executed = []
    failed = False

    def stream(url, headers, body, timeout, consume, abort):
        nonlocal failed
        if failed:
            send(consume, text="resume acknowledged", finish="stop")
            return
        send(consume, calls=[call(0)])
        wait_until(lambda: receipts(app, sid))
        send(consume, calls=[call(1, raw='{"unfinished":')])
        failed = True
        raise ProviderError("Controlled stream failure")

    install_tool(app, lambda args, ctx: executed.append(ctx.call_id) or ToolResult(output="side effect saved"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    with pytest.raises(ProviderError, match="Controlled stream failure"):
        app.prompt(sid, "Inspect input")
    saved = receipts(app, sid)
    assert len(saved) == 2
    assert saved[0]["content"] == "side effect saved"
    assert "Tool execution aborted" in saved[1]["content"]
    assert saved[1]["metadata"]["error"] is True
    assistant = next(message for message in app.store.messages(sid) if message["role"] == "assistant")
    assert assistant["error"] == "Controlled stream failure"
    assert assistant["incomplete_tool_calls"][0]["id"] == "call-1"
    app.prompt(sid, "Resume using the saved receipts")
    assert executed == ["call-0"] and len(receipts(app, sid)) == 2


@pytest.mark.parametrize("continue_after_deny", [False, True])
def test_permission_rejection_is_saved_and_controls_the_next_model_turn(runtime, monkeypatch, continue_after_deny):
    app, sid = runtime
    app.config["experimental"] = {"continue_loop_on_deny": continue_after_deny}
    requests = []

    def execute(args, ctx):
        raise PermissionRejected("Controlled denial")

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        if len(requests) > 1:
            send(consume, text="denial acknowledged", finish="stop")
            return
        send(consume, calls=[call(0)], finish="tool_calls")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    app.prompt(sid, "Inspect input")
    assert len(requests) == (2 if continue_after_deny else 1)
    result, = receipts(app, sid)
    assert result["metadata"]["error"] is True and "Controlled denial" in result["content"]


def test_repeated_calls_use_current_assistant_doom_permission(runtime, monkeypatch):
    app, sid = runtime
    requests, asked, executed = [], [], []

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        if len(requests) > 1:
            send(consume, text="done", finish="stop")
            return
        send(consume, calls=[call(0), call(1), call(2)], finish="tool_calls")

    monkeypatch.setattr(app.permissions, "ask", lambda **kwargs: asked.append(kwargs))
    install_tool(app, lambda args, ctx: executed.append(ctx.call_id) or ToolResult(output="observed"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    app.prompt(sid, "Inspect input")
    assert len(executed) == 3
    assert len(asked) == 1 and asked[0]["permission"] == "doom_loop"
    assert asked[0]["metadata"] == {"tool": "observe", "input": {}}


def test_failed_stream_closes_uncooperative_tool_and_discards_its_late_result(runtime, monkeypatch):
    app, sid = runtime
    entered, release, ended = threading.Event(), threading.Event(), threading.Event()
    failed = False

    def execute(args, ctx):
        entered.set()
        assert release.wait(3)
        ended.set()
        return ToolResult(output="late result")

    def stream(url, headers, body, timeout, consume, abort):
        nonlocal failed
        if failed:
            send(consume, text="resume", finish="stop")
            return
        send(consume, calls=[call(0)])
        assert entered.wait(3)
        failed = True
        raise ProviderError("Controlled stream failure")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    try:
        with pytest.raises(ProviderError, match="Controlled stream failure"):
            app.prompt(sid, "Inspect input")
        result, = receipts(app, sid)
        assert "Tool execution aborted" in result["content"]
        release.set()
        assert ended.wait(3)
        app.prompt(sid, "Resume without replaying")
        assert receipts(app, sid) == [result]
    finally:
        release.set()


def test_abort_keeps_started_tool_receipt_and_never_starts_it_again(runtime, monkeypatch):
    app, sid = runtime
    entered = threading.Event()
    executed, requests = [], []

    def execute(args, ctx):
        executed.append(ctx.call_id)
        entered.set()
        assert ctx.abort is not app.abort_event(sid)
        assert ctx.abort.wait(3)
        return ToolResult(output="Completed side effect before cancellation was observed")

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        if len(requests) > 1:
            send(consume, text="resume", finish="stop")
            return
        send(consume, calls=[call(0)])
        assert entered.wait(3)
        app.abort(sid)
        raise ProviderError("Model request aborted")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    assert app.prompt(sid, "Inspect input")["status"] == "aborted"
    assert len(receipts(app, sid)) == 1
    assert "Completed side effect" in receipts(app, sid)[0]["content"]
    app.prompt(sid, "Resume using the receipt")
    assert executed == ["call-0"] and len(receipts(app, sid)) == 1


@pytest.mark.parametrize("callback", ["tool", "text"])
@pytest.mark.parametrize("failure_type", [ValueError, TimeoutError])
def test_observer_failure_keeps_receipt_and_cancels_only_the_request(runtime, monkeypatch, callback, failure_type):
    app, sid = runtime
    executed = []
    failed = False

    def observer(_):
        raise failure_type("Controlled observer failure")

    def stream(url, headers, body, timeout, consume, abort):
        nonlocal failed
        if failed:
            send(consume, text="resume", finish="stop")
            return
        send(consume, calls=[call(0)])
        wait_until(lambda: receipts(app, sid))
        failed = True
        if callback == "tool":
            assert abort.wait(3), "An asynchronous callback failure did not cancel the request"
            raise ProviderError("Model request aborted")
        send(consume, text="Partial answer")

    install_tool(app, lambda args, ctx: executed.append(ctx.call_id) or ToolResult(output="saved effect"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    with pytest.raises((ProviderError, failure_type), match="Controlled observer failure"):
        app.prompt(sid, "Inspect input", **{"on_tool_result" if callback == "tool" else "on_text": observer})
    assert not app.abort_event(sid).is_set()
    assert receipts(app, sid)[0]["content"] == "saved effect"
    app.prompt(sid, "Resume using the saved receipt")
    assert executed == ["call-0"] and len(receipts(app, sid)) == 1


def test_nonstream_client_observer_timeout_is_a_failure_not_an_unfinished_wait(runtime, monkeypatch):
    app, sid = runtime
    install_tool(app, lambda args, ctx: ToolResult(output="saved effect"))
    monkeypatch.setattr(app.provider, "complete", lambda **kwargs:
        Completion(tool_calls=[ToolCall("call-0", "observe", {})], finish_reason="tool-calls"))

    def observer(_):
        raise TimeoutError("Controlled observer timeout")

    thread, outcome = run_thread(app, sid, on_tool_result=observer)
    try:
        thread.join(3)
        assert not thread.is_alive(), "A completed Future exception was mistaken for a wait timeout"
        assert isinstance(outcome.get("error"), TimeoutError)
        assert str(outcome["error"]) == "Controlled observer timeout"
        assert receipts(app, sid)[0]["content"] == "saved effect"
    finally:
        app.abort(sid)
        thread.join(3)


def test_retryable_stream_failure_reissues_request_and_allows_new_call_id(runtime, monkeypatch):
    """processor.ts retries the whole stream; SDK dispatch has no cross-attempt action deduplication."""
    app, sid = runtime
    effects, requests = [], []

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        attempt = len(requests)
        if attempt <= 2:
            send(consume, calls=[call(attempt - 1, raw='{"value":"same action"}')])
            wait_until(lambda: len(receipts(app, sid)) == attempt)
            if attempt == 1:
                # The first action has completed before the provider reports a
                # retryable error. The retry receives the same original history.
                consume('data: {"error":{"message":"rate limit"}}')
            send(consume, finish="tool_calls")
            return
        send(consume, text="done", finish="stop")

    install_tool(app, lambda args, ctx:
        effects.append((ctx.call_id, args["value"])) or ToolResult(output="saved memory effect"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    assert app.prompt(sid, "Inspect input")["text"] == "done"
    assert len(requests) == 3
    assert requests[0]["messages"] == requests[1]["messages"]
    assert effects == [("call-0", "same action"), ("call-1", "same action")]
    assert [item["tool_call_id"] for item in receipts(app, sid)] == ["call-0", "call-1"]


def test_retry_reusing_completed_call_id_preserves_both_calls_and_exact_receipt_arguments(runtime, monkeypatch):
    app, sid = runtime
    effects, requests = [], []

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        attempt = len(requests)
        if attempt <= 2:
            send(consume, calls=[call(0, raw=json.dumps({"value": attempt}))])
            wait_until(lambda: len(receipts(app, sid)) == attempt)
            if attempt == 1:
                consume('data: {"error":{"message":"rate limit"}}')
            send(consume, finish="tool_calls")
            return
        send(consume, text="done", finish="stop")

    install_tool(app, lambda args, ctx:
        effects.append(args["value"]) or ToolResult(output=f"result {args['value']}"))
    monkeypatch.setattr("opencode.provider._stream", stream)
    assert app.prompt(sid, "Inspect input")["text"] == "done"
    assert effects == [1, 2]  # Each final Completion callback must remain deduplicated.
    assistant = next(m for m in app.store.messages(sid) if m.get("tool_calls"))
    assert [(c["id"], c["arguments"]) for c in assistant["tool_calls"]] == [
        ("call-0", {"value": 1}), ("call-0", {"value": 2}),
    ]
    shown = requests[-1]["messages"]
    assert [m["content"] for m in shown if m["role"] == "tool"] == ["result 1", "result 2"]
    shown_calls = next(m["tool_calls"] for m in shown if m.get("tool_calls"))
    assert [json.loads(c["function"]["arguments"]) for c in shown_calls] == [{"value": 1}, {"value": 2}]
    saved = receipts(app, sid)
    for index, receipt in enumerate(saved, 1):
        projected = json.loads((app.store.tool_history_path(sid).parent / f"{receipt['id']}.json").read_text(encoding="utf-8"))
        assert projected[0]["tool_calls"][0]["arguments"] == {"value": index}
    app.store.export_tool_history(sid)  # Restart/rebuild must preserve the same pairing.
    sources = app.store.source_receipts(sid, {"observe"})
    for index, receipt in enumerate(saved, 1):
        projected = json.loads((app.store.tool_history_path(sid).parent / f"{receipt['id']}.json").read_text(encoding="utf-8"))
        assert projected[0]["tool_calls"][0]["arguments"] == {"value": index}
        assert sources[receipt["id"]][0]["tool_calls"][0]["arguments"] == {"value": index}


@pytest.mark.parametrize("first_completed", [0, 1])
def test_retry_reusing_running_call_id_reuses_source_part_and_first_result_settles_it(runtime, monkeypatch, first_completed):
    app, sid = runtime
    entered = [threading.Event(), threading.Event()]
    release = [threading.Event(), threading.Event()]
    ended = [threading.Event(), threading.Event()]
    effects, requests = [], []

    def execute(args, ctx):
        index = args["value"]
        effects.append(index)
        entered[index].set()
        assert release[index].wait(6)
        ended[index].set()
        return ToolResult(output=f"result {index}")

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        attempt = len(requests)
        if attempt <= 2:
            send(consume, calls=[call(0, raw=json.dumps({"value": attempt - 1}))])
            assert entered[attempt - 1].wait(3)
            if attempt == 1:
                consume('data: {"error":{"message":"rate limit"}}')
            release[first_completed].set()
            wait_until(lambda: receipts(app, sid))
            release[1 - first_completed].set()
            assert ended[1 - first_completed].wait(3)
            send(consume, finish="tool_calls")
            return
        send(consume, text="done", finish="stop")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    try:
        assert app.prompt(sid, "Inspect input")["text"] == "done"
        assert effects == [0, 1]
        assistant = next(m for m in app.store.messages(sid) if m.get("tool_calls"))
        assert len(assistant["tool_calls"]) == 1
        assert assistant["tool_calls"][0]["arguments"] == {"value": 1}
        result, = receipts(app, sid)
        assert result["content"] == f"result {first_completed}"
        app.store.export_tool_history(sid)
        projected = json.loads((app.store.tool_history_path(sid).parent / f"{result['id']}.json").read_text(encoding="utf-8"))
        assert projected[0]["tool_calls"][0]["arguments"] == {"value": 1}
    finally:
        for event in release:
            event.set()


def test_restart_closes_only_unfinished_occurrence_of_reused_call_id(runtime, monkeypatch):
    app, sid = runtime
    app.store.add_message(sid, "assistant", {"content": "", "tool_calls": [
        {"id": "same", "name": "observe", "arguments": {"value": 1}},
        {"id": "same", "name": "observe", "arguments": {"value": 2}},
    ]})
    app.store.add_message(sid, "tool", {"tool_call_id": "same", "name": "observe", "content": "completed first"})
    monkeypatch.setattr(app.provider, "complete", lambda **kwargs: Completion(text="resumed", finish_reason="stop"))
    assert app.prompt(sid, "Continue from saved state")["text"] == "resumed"
    first, second = receipts(app, sid)
    assert first["content"] == "completed first"
    assert "not replayed" in second["content"]
    sources = app.store.source_receipts(sid, {"observe"})
    assert sources[first["id"]][0]["tool_calls"][0]["arguments"] == {"value": 1}
    assert sources[second["id"]][0]["tool_calls"][0]["arguments"] == {"value": 2}


def test_attempt_event_supports_event_type_and_unbounded_wait_without_stopping_session():
    session = threading.Event()
    attempt = _RequestAbort(session)
    assert isinstance(attempt, threading.Event)
    returned = threading.Event()
    waiter = threading.Thread(target=lambda: attempt.wait() and returned.set())
    waiter.start()
    try:
        assert not attempt.wait(0)
        attempt.set()
        assert returned.wait(3) and not session.is_set()
    finally:
        attempt.set()
        waiter.join(3)
    next_attempt = _RequestAbort(session)
    assert not next_attempt.is_set()
    session.set()
    assert next_attempt.wait(3)


def test_retry_cancels_old_attempt_before_backoff_and_new_attempt_has_fresh_tool_signal(runtime, monkeypatch):
    app, sid = runtime
    entered, stopped = threading.Event(), threading.Event()
    signals, requests, delays = [], [], []

    def execute(args, ctx):
        signals.append(ctx.abort)
        assert isinstance(ctx.abort, threading.Event)
        assert not ctx.abort.is_set()
        if args["value"] == 0:
            entered.set()
            assert ctx.abort.wait(3)
            stopped.set()
            raise PermissionRejected("Execution stopped")
        assert ctx.abort is not signals[0]
        return ToolResult(output="fresh attempt completed")

    def delay(error, attempt, provider_id):
        assert signals[0].is_set() and not app.abort_event(sid).is_set()
        assert stopped.wait(3)
        delays.append(attempt)
        return 0

    def stream(url, headers, body, timeout, consume, abort):
        requests.append(body)
        attempt = len(requests)
        if attempt <= 2:
            if attempt == 2:
                wait_until(lambda: len(receipts(app, sid)) == 1)
                assert signals[0].is_set() and not abort.is_set()
            send(consume, calls=[call(0, raw=json.dumps({"value": attempt - 1}))])
            if attempt == 1:
                assert entered.wait(3)
                raise ProviderError("rate limit")
            send(consume, finish="tool_calls")
            return
        send(consume, text="retry completed", finish="stop")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    monkeypatch.setattr("opencode.provider._retry_delay", delay)
    assert app.prompt(sid, "Inspect input")["text"] == "retry completed"
    assert len(signals) == 2 and all(signal.is_set() for signal in signals)
    assert delays == [1] and len(requests) == 3
    assert not app.abort_event(sid).is_set()
    assert [item["content"] for item in receipts(app, sid)] == ["Error: Execution stopped", "fresh attempt completed"]


def test_failed_attempt_cancels_cooperative_tool_before_final_cleanup(runtime, monkeypatch):
    app, sid = runtime
    entered = threading.Event()
    signals = []

    def execute(args, ctx):
        signals.append(ctx.abort)
        entered.set()
        assert ctx.abort.wait(3)
        return ToolResult(output="cooperative cleanup completed")

    def stream(url, headers, body, timeout, consume, abort):
        send(consume, calls=[call(0)])
        assert entered.wait(3)
        raise ProviderError("Controlled terminal failure")

    install_tool(app, execute)
    monkeypatch.setattr("opencode.provider._stream", stream)
    with pytest.raises(ProviderError, match="Controlled terminal failure"):
        app.prompt(sid, "Inspect input")
    assert signals[0].is_set() and not app.abort_event(sid).is_set()
    receipt, = receipts(app, sid)
    assert receipt["content"] == "cooperative cleanup completed"


def test_old_tool_context_construction_keeps_optional_abort_default(runtime):
    from opencode.loop import ToolContext
    app, sid = runtime
    ctx = ToolContext(app, sid, app.agents["build"], "message", "call", 0, app.directory, app.worktree, set(), 1)
    assert ctx.abort is None
