"""OpenCode system.ts / instruction.ts / llm/request.ts prompt boundaries."""
import datetime
import sys
from types import SimpleNamespace

import pytest

from opencode.agent import provider_prompt
from opencode.loop import LANGUAGE, _system
from opencode.prompts import load


@pytest.mark.parametrize("model,filename", [
    ("codex-preview", "default.txt"),
    ("gpt-codex", "codex.txt"),
    ("gpt-4-codex", "beast.txt"),
    ("GPT-4", "default.txt"),
    ("gemini", "default.txt"),
    ("gemini-preview", "gemini.txt"),
    ("CLAUDE", "default.txt"),
    ("MUSE-SPARK", "default.txt"),
    ("TRINITY", "trinity.txt"),
    ("KIMI", "kimi.txt"),
])
def test_source_model_prompt_selection_boundaries(model, filename):
    assert provider_prompt(model) == load(filename)


@pytest.mark.parametrize("agent_prompt", [None, "Explicit agent guidance"])
def test_source_system_block_order_and_separators(tmp_path, monkeypatch, agent_prompt):
    class FrozenDate(datetime.date):
        @classmethod
        def today(cls):
            return cls(2026, 10, 19)

    monkeypatch.setattr(datetime, "date", FrozenDate)
    monkeypatch.setattr("opencode.loop.render_skills", lambda *_: "Skill guidance")
    (tmp_path / ".git").mkdir()
    app = SimpleNamespace(
        directory=tmp_path, worktree=tmp_path,
        instructions=[("one.md", "First instruction"), ("empty.md", ""),
                      ("two.md", "Second instruction")],
        skills={}, mcp=SimpleNamespace(instructions=lambda: "MCP guidance"),
    )
    agent = SimpleNamespace(name="build", prompt=agent_prompt)
    expected = (agent_prompt or load("default.txt")) + "\n" + (
        "You are powered by the model named model. The exact model ID is test/model\n"
        "Here is some useful information about the environment you are running in:\n"
        f"<env>\n  Working directory: {tmp_path}\n  Workspace root folder: {tmp_path}\n"
        f"  Is directory a git repo: yes\n  Platform: {sys.platform}\n"
        "  Today's date: Mon Oct 19 2026\n</env>\n"
        # A deliberate addition (the project lead, 2026-10-31): every task replies in the person's language.
        + LANGUAGE + "\n"
        "Instructions from: one.md\nFirst instruction\n"
        "Instructions from: two.md\nSecond instruction\n"
        "MCP guidance\nSkill guidance"
    )
    assert _system(app, agent, "model", "test") == expected
