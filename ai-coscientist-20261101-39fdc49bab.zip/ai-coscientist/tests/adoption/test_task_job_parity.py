"""Tasks use the same ordered job registry in foreground and background."""
import threading
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.provider import Completion, ProviderError
from opencode.store import Store


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "OPENCODE_TEST_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    app = App(project, store=Store(tmp_path / "session.db"), config={}, auto_approve=True)
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)
    parent = app.create_session()["id"]
    child = app.store.create_session(directory=str(project), agent="general", model=None, parent_id=parent)["id"]
    yield app, parent, child
    app.abort(parent)
    app.store.close()


def test_foreground_task_can_be_extended_and_returns_last_ordered_result(case):
    app, parent, child = case
    entered, release = threading.Event(), threading.Event()
    inputs, results, failures = [], [], []
    def complete(**kwargs):
        inputs.append((kwargs["model"], kwargs["messages"]))
        if len(inputs) == 1:
            entered.set()
            assert release.wait(4)
        return Completion(text=f"result {len(inputs)}", finish_reason="stop")
    app.provider = SimpleNamespace(resolve=lambda ref: (SimpleNamespace(id="test", context=128000), (ref or "test/first").split("/")[-1]), complete=complete)
    def run():
        try:
            results.append(app.run_prompt(child, "first request", agent="general", model="test/first", _parent_id=parent))
        except BaseException as exc:
            failures.append(exc)
    thread = threading.Thread(target=run)
    thread.start()
    try:
        assert entered.wait(4)
        app.spawn_background(child, "second request", "general", 1, parent, model="test/second")
        assert [m["content"] for m in app.store.messages(child) if m["role"] == "user"] == ["first request"]
        assert len(inputs) == 1
    finally:
        release.set()
        thread.join(5)
    assert not thread.is_alive() and not failures
    assert results[0]["text"] == "result 2"
    assert [item[0] for item in inputs] == ["first", "second"]
    assert [m["content"] for m in app.store.messages(child) if m["role"] == "user"] == ["first request", "second request"]
    assert child not in app._background
    assert app.store.messages(parent) == []  # Foreground waiter owns delivery.


def test_parent_abort_stops_foreground_job_and_queued_extensions(case):
    app, parent, child = case
    entered = threading.Event()
    calls, failures = [], []
    def complete(**kwargs):
        calls.append(kwargs)
        entered.set()
        assert kwargs["abort_event"].wait(4)
        raise ProviderError("aborted")
    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=128000), "model"), complete=complete)
    def run():
        try:
            app.run_prompt(child, "first", _parent_id=parent)
        except BaseException as exc:
            failures.append(exc)
    thread = threading.Thread(target=run)
    thread.start()
    try:
        assert entered.wait(4)
        app.spawn_background(child, "queued", "general", 1, parent)
        app.abort(parent)
    finally:
        app.abort(parent)
        thread.join(5)
    assert not thread.is_alive()
    assert len(calls) == 1 and len(failures) == 1
    assert isinstance(failures[0], ProviderError)
    assert child not in app._background and child not in app._running
    assert [m["content"] for m in app.store.messages(child) if m["role"] == "user"] == ["first"]
