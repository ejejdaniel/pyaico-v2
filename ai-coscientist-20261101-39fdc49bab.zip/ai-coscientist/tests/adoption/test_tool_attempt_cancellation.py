"""S20 per-attempt tool cancellation; only local processes and HTTP are used."""

import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

from opencode.permission import Broker, PermissionRejected, Rule
from opencode.tools import files, shell, web
from opencode.tools.util import _abort_event, ensure_access


@pytest.fixture
def ctx(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    directory = tmp_path / "project"
    directory.mkdir()
    attempt, session = threading.Event(), threading.Event()
    broker = Broker(auto=True)
    broker.abort_event = lambda _: session
    app = SimpleNamespace(permissions=broker, abort_event=lambda _: session, config={"shell": sys.executable})
    return SimpleNamespace(app=app, session_id="same-session", abort=attempt, session_abort=session,
                           directory=directory, worktree=directory, read_files=set(), turn=1,
                           agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]))


def in_thread(function):
    results, errors = [], []

    def run():
        try:
            results.append(function())
        except BaseException as error:
            errors.append(error)

    worker = threading.Thread(target=run)
    worker.start()
    return worker, results, errors


def wait_until(predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        threading.Event().wait(.01)
    return False


def test_attempt_event_precedes_session_and_legacy_fallback(ctx):
    ctx.session_abort.set()
    assert _abort_event(ctx) is ctx.abort and not _abort_event(ctx).is_set()
    ctx.abort = None
    assert _abort_event(ctx) is ctx.session_abort
    del ctx.abort
    assert _abort_event(ctx) is ctx.session_abort


@pytest.mark.parametrize("external", [False, True])
def test_attempt_stop_releases_permission_wait_without_stopping_session(ctx, external):
    path = (ctx.directory.parent if external else ctx.directory) / "source.txt"
    path.write_text("source", encoding="utf-8")
    ctx.agent.permission = []
    ctx.app.permissions.auto = False
    worker, results, errors = in_thread(lambda: ensure_access(ctx, path, "read"))
    try:
        assert wait_until(ctx.app.permissions.list_pending)
        assert ctx.app.permissions.list_pending()[0]["permission"] == ("external_directory" if external else "read")
        ctx.abort.set()
        worker.join(3)
        assert not worker.is_alive() and not results
        assert len(errors) == 1 and isinstance(errors[0], PermissionRejected)
        assert not ctx.session_abort.is_set()
        assert ctx.app.permissions.list_pending() == []
        ctx.abort = threading.Event()
        ctx.app.permissions.auto = True
        ensure_access(ctx, path, "read")
    finally:
        ctx.abort.set()
        worker.join(3)


@pytest.mark.parametrize("execute,args", [
    (files._read, {"filePath": "source.txt"}),
    (files._write, {"filePath": "source.txt", "content": "changed"}),
    (files._edit, {"filePath": "source.txt", "oldString": "source", "newString": "changed"}),
    (files._grep, {"pattern": "source"}), (files._glob, {"pattern": "*.txt"}),
    (shell._bash, {"command": "print('must not run')"}),
    (web._webfetch, {"url": "https://never-contact.invalid"}),
    (web._websearch, {"query": "must not search"}),
])
def test_already_stopped_attempt_does_not_cross_permission_boundary(ctx, execute, args):
    path = ctx.directory / "source.txt"
    path.write_bytes(b"source")
    ctx.abort.set()
    with pytest.raises(PermissionRejected, match="Execution stopped"):
        execute(args, ctx)
    assert path.read_bytes() == b"source"
    assert not ctx.session_abort.is_set()


@pytest.mark.parametrize("execute,args", [(files._grep, {"pattern": "source"}),
                                          (files._glob, {"pattern": "*.txt"})])
def test_attempt_stop_kills_search_blocked_on_stdout(ctx, monkeypatch, execute, args):
    original = files.subprocess.Popen
    started, processes = threading.Event(), []

    def spawn(command, **kwargs):
        process = original([sys.executable, "-c", "import time; time.sleep(60)"], **kwargs)
        processes.append(process)
        started.set()
        return process

    monkeypatch.setattr(files, "_ripgrep_binary", lambda **kwargs: sys.executable)
    monkeypatch.setattr(files.subprocess, "Popen", spawn)
    worker, results, errors = in_thread(lambda: execute(args, ctx))
    try:
        assert started.wait(3)
        ctx.abort.set()
        worker.join(3)
        assert not worker.is_alive() and not results
        assert len(errors) == 1 and isinstance(errors[0], PermissionRejected)
        assert not ctx.session_abort.is_set()
        assert all(process.poll() is not None and process.stdout.closed and process.stderr.closed for process in processes)
        assert not any(thread.name == "opencode-ripgrep-abort" for thread in threading.enumerate())
    finally:
        ctx.abort.set()
        for process in processes:
            if process.poll() is None:
                process.kill()
        worker.join(3)


def test_attempt_stop_kills_shell_and_preserves_partial_receipt(ctx, monkeypatch):
    original = shell.subprocess.Popen
    started, processes = threading.Event(), []

    def spawn(*args, **kwargs):
        process = original(*args, **kwargs)
        processes.append(process)
        started.set()
        return process

    monkeypatch.setattr(shell.subprocess, "Popen", spawn)
    worker, results, errors = in_thread(lambda: shell._bash({"command": "import time; time.sleep(60)"}, ctx))
    try:
        assert started.wait(3)
        ctx.abort.set()
        worker.join(4)
        assert not worker.is_alive() and not errors
        assert results[0].metadata["exit"] is None
        assert "User aborted the command" in results[0].output
        assert not ctx.session_abort.is_set()
        assert all(process.poll() is not None and process.stdout.closed for process in processes)
    finally:
        ctx.abort.set()
        for process in processes:
            if process.poll() is None:
                process.kill()
        worker.join(3)


@pytest.fixture
def stalled_http():
    started, disconnected = threading.Event(), threading.Event()
    state = {"mode": "headers"}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def handle_request(self):
            self.rfile.read(int(self.headers.get("content-length", 0)))
            if state["mode"] == "body":
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", "100")
                self.end_headers()
                self.wfile.write(b"partial")
                self.wfile.flush()
            started.set()
            self.connection.settimeout(4)
            try:
                if self.connection.recv(1) == b"":
                    disconnected.set()
            except (ConnectionError, OSError) as error:
                if not isinstance(error, socket.timeout):
                    disconnected.set()

        do_GET = handle_request
        do_POST = handle_request

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    server.daemon_threads = True
    worker = threading.Thread(target=server.serve_forever)
    worker.start()
    yield f"http://127.0.0.1:{server.server_port}/", started, disconnected, state
    server.shutdown()
    server.server_close()
    worker.join(3)


@pytest.mark.parametrize("tool", ["webfetch", "websearch", "ripgrep-download"])
@pytest.mark.parametrize("mode", ["headers", "body"])
def test_attempt_stop_closes_http_before_headers_or_during_body(ctx, monkeypatch, stalled_http, tool, mode):
    url, started, disconnected, state = stalled_http
    state["mode"] = mode
    original = httpx.AsyncClient
    clients = []

    async def local_only(request):
        request.url = httpx.URL(url)

    def client(**kwargs):
        value = original(**kwargs, trust_env=False, event_hooks={"request": [local_only]})
        clients.append(value)
        return value

    monkeypatch.setattr(httpx, "AsyncClient", client)
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", "exa")
    if tool == "webfetch":
        execute = lambda: web._webfetch({"url": url}, ctx)
    elif tool == "websearch":
        execute = lambda: web._websearch({"query": "local cancellation"}, ctx)
    else:
        monkeypatch.setattr(files, "_which", lambda name: None)
        execute = lambda: files._ripgrep_binary(abort=ctx.abort)
    worker, results, errors = in_thread(execute)
    try:
        assert started.wait(3)
        ctx.abort.set()
        worker.join(3)
        assert not worker.is_alive() and not results
        assert len(errors) == 1 and isinstance(errors[0], PermissionRejected)
        assert disconnected.wait(3)
        assert all(client.is_closed for client in clients)
        assert not ctx.session_abort.is_set()
        assert not any(thread.name == "opencode-provider-request" for thread in threading.enumerate())
        if tool == "ripgrep-download":
            assert list((files.data_dir() / "bin").iterdir()) == []
    finally:
        ctx.abort.set()
        worker.join(5)


def test_fresh_http_attempt_succeeds_when_previous_attempt_is_stopped(ctx, monkeypatch):
    old_attempt = ctx.abort
    old_attempt.set()
    ctx.abort = threading.Event()
    original = httpx.AsyncClient
    clients = []

    def client(**kwargs):
        value = original(**kwargs, transport=httpx.MockTransport(lambda request: httpx.Response(200, text="fresh")))
        clients.append(value)
        return value

    monkeypatch.setattr(httpx, "AsyncClient", client)
    assert web._webfetch({"url": "http://test.invalid"}, ctx).output == "fresh"
    assert all(client.is_closed for client in clients)
    assert old_attempt.is_set() and not ctx.abort.is_set() and not ctx.session_abort.is_set()
    assert not any(thread.name == "opencode-provider-request" for thread in threading.enumerate())


def test_cancelled_attempt_does_not_wait_for_other_ripgrep_download(ctx, monkeypatch):
    monkeypatch.setattr(files, "_which", lambda name: None)
    files._ripgrep_lock.acquire()
    worker, results, errors = in_thread(lambda: files._ripgrep_binary(abort=ctx.abort))
    try:
        ctx.abort.set()
        worker.join(3)
        assert not worker.is_alive() and not results
        assert len(errors) == 1 and isinstance(errors[0], PermissionRejected)
        assert not ctx.session_abort.is_set()
    finally:
        files._ripgrep_lock.release()
        worker.join(3)
