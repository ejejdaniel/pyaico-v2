"""Offline checks for the existing websearch exposure controls."""

import json
import tempfile

import httpx
import pytest

from opencode.agent import Agent
from opencode.app import App
from opencode.permission import Rule
from opencode.store import Store
from opencode.tools import tools_for


SEARCH_FLAGS = (
    "OPENCODE_EXPERIMENTAL", "OPENCODE_ENABLE_EXA", "OPENCODE_EXPERIMENTAL_EXA",
    "OPENCODE_ENABLE_PARALLEL", "OPENCODE_EXPERIMENTAL_PARALLEL",
)


@pytest.fixture(autouse=True)
def isolated_environment(monkeypatch, tmp_path):
    for name in (*SEARCH_FLAGS, "OPENCODE_WEBSEARCH_PROVIDER"):
        monkeypatch.delenv(name, raising=False)
    for name in ("XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME",
                 "OPENCODE_TEST_HOME", "TEMP", "TMP", "TMPDIR"):
        path = tmp_path / name.lower()
        path.mkdir()
        monkeypatch.setenv(name, str(path))
    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path / "temp"))


def tool_names(*, provider_id=None, permission=None, agent_permission=None):
    agent = Agent(name="fixture", permission=agent_permission or [Rule("*", "*", "allow")])
    return [tool.name for tool in tools_for(agent, provider_id=provider_id, permission=permission)]


@pytest.mark.parametrize("provider_id,expected", [
    (None, False), ("local", False), ("opencode", True),
    ("opencode-go", False), ("opencode-other", False), ("OpenCode", False),
])
def test_provider_name_requires_exact_opencode(provider_id, expected):
    names = tool_names(provider_id=provider_id)
    assert ("websearch" in names) is expected
    assert "webfetch" in names
    assert "lsp" in names


@pytest.mark.parametrize("flag", SEARCH_FLAGS)
def test_each_existing_flag_exposes_search_for_other_provider(monkeypatch, flag):
    monkeypatch.setenv(flag, "true")
    assert "websearch" in tool_names(provider_id="local")


@pytest.mark.parametrize("value,expected", [
    ("TRUE", True), ("1", True), ("yes", True), ("on", True),
    ("false", False), ("0", False), ("no", False), ("off", False), ("", False),
])
def test_existing_boolean_spellings_are_preserved(monkeypatch, value, expected):
    monkeypatch.setenv("OPENCODE_ENABLE_EXA", value)
    assert ("websearch" in tool_names(provider_id="local")) is expected


def test_false_flags_do_not_override_opencode_or_another_enabled_flag(monkeypatch):
    for flag in SEARCH_FLAGS:
        monkeypatch.setenv(flag, "false")
    assert "websearch" in tool_names(provider_id="opencode")
    monkeypatch.setenv("OPENCODE_EXPERIMENTAL", "true")
    assert "websearch" in tool_names(provider_id="local")


@pytest.mark.parametrize("source", ["agent", "session"])
def test_enabled_search_still_obeys_permissions(monkeypatch, source):
    monkeypatch.setenv("OPENCODE_ENABLE_PARALLEL", "true")
    deny = Rule("websearch", "*", "deny")
    options = {"agent_permission": [Rule("*", "*", "allow"), deny]} if source == "agent" else {"permission": [deny]}
    names = tool_names(provider_id="opencode", **options)
    assert "websearch" not in names
    assert "webfetch" in names


@pytest.mark.parametrize("backend", ["exa", "parallel"])
def test_backend_override_does_not_enable_exposure(monkeypatch, backend):
    monkeypatch.setenv("OPENCODE_WEBSEARCH_PROVIDER", backend)
    assert "websearch" not in tool_names(provider_id="local")


@pytest.mark.parametrize("provider_id,flag,expected", [
    ("opencode", None, True), ("opencode-go", None, False),
    ("local", "OPENCODE_ENABLE_EXA", True),
])
def test_loop_passes_provider_identity_to_wire_catalog(monkeypatch, tmp_path, provider_id, flag, expected):
    if flag:
        monkeypatch.setenv(flag, "true")
    recorded = []

    def respond(request):
        body = json.loads(request.content)
        recorded.append(body)
        if body.get("stream"):
            chunk = {"choices": [{"delta": {"content": "Offline fixture complete."}, "finish_reason": "stop"}],
                     "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}}
            return httpx.Response(200, text="data: " + json.dumps(chunk) + "\n\ndata: [DONE]\n\n",
                                  headers={"content-type": "text/event-stream"})
        return httpx.Response(200, json={
            "choices": [{"message": {"content": "Offline fixture complete."}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        })

    real_client = httpx.Client
    real_async_client = httpx.AsyncClient
    monkeypatch.setattr(httpx, "Client", lambda *args, **kwargs: real_client(
        *args, transport=httpx.MockTransport(respond), **kwargs))
    monkeypatch.setattr(httpx, "AsyncClient", lambda *args, **kwargs: real_async_client(
        *args, transport=httpx.MockTransport(respond), **kwargs))
    project = tmp_path / "project"
    project.mkdir()
    store = Store(tmp_path / "session.db")
    config = {"model": f"{provider_id}/fixture", "provider": {provider_id: {
        "options": {"baseURL": "http://model.invalid/v1", "apiKey": "fixture"},
        "models": {"fixture": {"limit": {"context": 131072, "output": 1000}}},
    }}}
    try:
        app = App(project, store=store, config=config)
        app.generate_titles = False
        result = app.prompt(app.create_session()["id"], "Return the offline fixture response.")
        assert result["status"] == "completed"
        assert len(recorded) == 1
        names = {tool["function"]["name"] for tool in recorded[0]["tools"]}
        assert ("websearch" in names) is expected
        assert "webfetch" in names
    finally:
        store.close()
