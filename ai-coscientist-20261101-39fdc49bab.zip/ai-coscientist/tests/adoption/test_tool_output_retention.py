"""Seven-day Truncate lifecycle from tool/truncate.ts; no real clock waits."""

import os
import threading
from pathlib import Path
from types import SimpleNamespace

from opencode.tools import util


NOW = 1_800_000_000_000
WEEK = 7 * 24 * 60 * 60 * 1000


def output(directory, timestamp, text="saved output", suffix="00000001"):
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"tool_{timestamp:013d}{suffix}"
    path.write_text(text, encoding="utf-8")
    return path


def test_seven_day_boundary_uses_id_time_not_filesystem_mtime(tmp_path):
    expired = output(tmp_path, NOW - WEEK - 1)
    boundary = output(tmp_path, NOW - WEEK)
    recent = output(tmp_path, NOW)
    future = output(tmp_path, NOW + WEEK)
    os.utime(expired, (NOW / 1000, NOW / 1000))
    os.utime(recent, (0, 0))
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert not expired.exists()
    assert boundary.exists() and recent.exists() and future.exists()


def test_only_existing_generated_tool_file_names_are_removed(tmp_path):
    expired = output(tmp_path, NOW - WEEK - 1)
    others = [tmp_path / name for name in ("notes.txt", "tool_invalid", "tool_123", "msg_000000000000000000001")]
    for path in others:
        path.write_text("keep", encoding="utf-8")
    directory = tmp_path / f"tool_{NOW - WEEK - 2:013d}00000002"
    directory.mkdir()
    (directory / "child.txt").write_text("keep", encoding="utf-8")
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert not expired.exists()
    assert all(path.read_text() == "keep" for path in others)
    assert (directory / "child.txt").read_text() == "keep"


def test_missing_or_unreadable_directory_is_best_effort(tmp_path, monkeypatch):
    util._cleanup_output_files(tmp_path / "missing", now_ms=NOW)
    monkeypatch.setattr(Path, "iterdir", lambda self: (_ for _ in ()).throw(PermissionError("unreadable")))
    util._cleanup_output_files(tmp_path, now_ms=NOW)


def test_delete_failure_does_not_stop_other_expired_outputs(tmp_path, monkeypatch):
    denied = output(tmp_path, NOW - WEEK - 2)
    removable = output(tmp_path, NOW - WEEK - 1)
    unlink = Path.unlink
    def remove(path, *args, **kwargs):
        if path == denied:
            raise PermissionError("still open")
        return unlink(path, *args, **kwargs)
    monkeypatch.setattr(Path, "unlink", remove)
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert denied.exists() and not removable.exists()


def test_cancellation_before_cleanup_leaves_all_outputs(tmp_path):
    expired = output(tmp_path, NOW - WEEK - 1)
    stop = threading.Event()
    stop.set()
    util._cleanup_output_files(tmp_path, now_ms=NOW, stop=stop)
    assert expired.exists()


def test_cancellation_after_stat_stops_before_removal(tmp_path, monkeypatch):
    expired = output(tmp_path, NOW - WEEK - 1)
    stop = threading.Event()
    lstat = Path.lstat
    def inspect(path, *args, **kwargs):
        value = lstat(path, *args, **kwargs)
        if path == expired:
            stop.set()
        return value
    monkeypatch.setattr(Path, "lstat", inspect)
    util._cleanup_output_files(tmp_path, now_ms=NOW, stop=stop)
    assert expired.exists()


def test_new_output_created_during_scan_is_never_deleted(tmp_path, monkeypatch):
    expired = output(tmp_path, NOW - WEEK - 1)
    recent = tmp_path / f"tool_{NOW:013d}00000001"
    def scan(path):
        yield expired
        recent.write_text("new output", encoding="utf-8")
        yield recent
    monkeypatch.setattr(Path, "iterdir", scan)
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert not expired.exists()
    assert recent.read_text() == "new output"


def test_replaced_file_is_not_deleted_by_the_current_pass(tmp_path, monkeypatch):
    expired = output(tmp_path, NOW - WEEK - 1)
    lstat = Path.lstat
    reads = []
    def inspect(path, *args, **kwargs):
        if path == expired:
            reads.append(path)
            if len(reads) == 2:
                path.write_text("new replacement with different content", encoding="utf-8")
        return lstat(path, *args, **kwargs)
    monkeypatch.setattr(Path, "lstat", inspect)
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert expired.read_text() == "new replacement with different content"


def test_concurrent_removal_is_harmless(tmp_path, monkeypatch):
    expired = output(tmp_path, NOW - WEEK - 1)
    lstat = Path.lstat
    reads = []
    def inspect(path, *args, **kwargs):
        if path == expired:
            reads.append(path)
            if len(reads) == 2:
                path.unlink()
        return lstat(path, *args, **kwargs)
    monkeypatch.setattr(Path, "lstat", inspect)
    util._cleanup_output_files(tmp_path, now_ms=NOW)
    assert not expired.exists()


class FakeCondition:
    def __init__(self, now, on_wait=None):
        self.now = now
        self.on_wait = on_wait
        self.waits = []
        self.notifications = 0

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass

    def wait(self, timeout=None):
        self.waits.append(timeout)
        if self.on_wait:
            self.on_wait()
        else:
            assert timeout is not None
            self.now[0] += timeout

    def notify_all(self):
        self.notifications += 1


def test_one_minute_initial_delay_then_one_hour_after_pass_finishes(tmp_path, monkeypatch):
    service = util._OutputCleanup()
    now = [0.0]
    condition = FakeCondition(now)
    service._condition = condition
    service._directories[tmp_path] = 60
    monkeypatch.setattr(util.time, "monotonic", lambda: now[0])
    calls = []
    def cleanup(directory, *, stop):
        calls.append((directory, now[0]))
        now[0] += 10
        if len(calls) == 2:
            stop.set()
    monkeypatch.setattr(util, "_cleanup_output_files", cleanup)
    service._run()
    assert calls == [(tmp_path, 60.0), (tmp_path, 3670.0)]
    assert condition.waits == [60.0, 3600.0]


def test_cancelled_delay_never_runs_cleanup(tmp_path, monkeypatch):
    service = util._OutputCleanup()
    now = [0.0]
    service._condition = FakeCondition(now, on_wait=service._stop.set)
    service._directories[tmp_path] = 60
    monkeypatch.setattr(util.time, "monotonic", lambda: now[0])
    monkeypatch.setattr(util, "_cleanup_output_files", lambda *a, **kw: (_ for _ in ()).throw(AssertionError("cancelled")))
    service._run()
    assert service._condition.waits == [60.0]


def test_cleanup_failure_is_logged_and_next_hour_still_runs(tmp_path, monkeypatch, caplog):
    service = util._OutputCleanup()
    now = [0.0]
    service._condition = FakeCondition(now)
    service._directories[tmp_path] = 60
    monkeypatch.setattr(util.time, "monotonic", lambda: now[0])
    calls = []
    def cleanup(directory, *, stop):
        calls.append(now[0])
        if len(calls) == 1:
            raise RuntimeError("test filesystem failure")
        stop.set()
    monkeypatch.setattr(util, "_cleanup_output_files", cleanup)
    service._run()
    assert calls == [60.0, 3660.0]
    assert "Truncation cleanup failed" in caplog.text


def test_repeated_apps_share_worker_and_do_not_reset_directory_deadline(tmp_path, monkeypatch):
    service = util._OutputCleanup()
    threads = []
    now = [100.0]
    monkeypatch.setattr(util.time, "monotonic", lambda: now[0])
    def thread(**kwargs):
        item = SimpleNamespace(**kwargs, starts=0, joins=[])
        item.start = lambda: setattr(item, "starts", item.starts + 1)
        item.join = lambda timeout: item.joins.append(timeout)
        threads.append(item)
        return item
    monkeypatch.setattr(util.threading, "Thread", thread)
    service.start(tmp_path)
    now[0] = 120
    service.start(tmp_path)
    service.start(tmp_path / "other")
    assert len(threads) == 1 and threads[0].starts == 1 and threads[0].daemon is True
    assert service._directories == {tmp_path.resolve(): 160, (tmp_path / "other").resolve(): 180}
    service.close()
    service.start(tmp_path / "after-close")
    assert len(threads) == 1 and threads[0].joins == [1]
    assert service._stop.is_set()
    assert tmp_path / "after-close" not in service._directories


def test_start_registers_configured_output_directory_without_deleting_now(tmp_path, monkeypatch):
    directory = tmp_path / "tool-output"
    expired = output(directory, NOW - WEEK - 1)
    calls = []
    monkeypatch.setattr(util, "truncation_dir", lambda: directory)
    monkeypatch.setattr(util, "_output_cleanup", SimpleNamespace(start=calls.append))
    util.start_output_cleanup()
    assert calls == [directory] and expired.exists()


def test_failed_or_cancelled_old_pass_does_not_remove_new_truncation(tmp_path, monkeypatch):
    monkeypatch.setattr(util, "truncation_dir", lambda: tmp_path)
    text = "complete output " * 30
    _, metadata = util.truncate_output(text, max_bytes=5)
    fresh = Path(metadata["outputPath"])
    timestamp = util._output_timestamp(fresh.name)
    util._cleanup_output_files(tmp_path, now_ms=timestamp + WEEK)
    assert fresh.read_bytes() == text.encode("utf-8")
    stop = threading.Event()
    stop.set()
    util._cleanup_output_files(tmp_path, now_ms=timestamp + WEEK + 1, stop=stop)
    assert fresh.read_bytes() == text.encode("utf-8")
