"""Request tool order from the source-pinned Bun 1.3.14 (zh-TW locale)."""

from functools import cmp_to_key
import json
from types import SimpleNamespace

import httpx
import pytest

from opencode.collation import _Collator
from opencode.loop import _tool_payload
from opencode.provider import Client
from opencode.tools.types import Tool


NAMES = ["z", "A", "a", "_a", "a-b", "a_b", "é", "e", "e\u0301", "01",
         "10", "2", "0", "4294967295", "4294967294"]
# Object.keys(Object.fromEntries(Object.entries(record).toSorted(
#   ([a], [b]) => a.localeCompare(b))))
EXPECTED = ["0", "2", "10", "4294967294", "_a", "01", "4294967295", "a", "A",
            "a_b", "a-b", "é", "e\u0301", "e", "z"]


@pytest.fixture(autouse=True)
def oracle_locale(monkeypatch):
    collator = _Collator("zh_TW")
    monkeypatch.setattr("opencode.loop._locale_key", cmp_to_key(collator.compare))


def make_tools():
    return [Tool(name, f"Description {name}", {"type": "object", "properties": {}}, lambda: None)
            for name in NAMES]


def test_source_object_order_keeps_unicode_ties_and_numeric_index_rules():
    tools = make_tools()
    assert [item["name"] for item in _tool_payload(tools)] == EXPECTED
    assert [tool.name for tool in tools] == NAMES


def test_source_record_replacement_keeps_last_value_without_duplicate_names():
    tools = make_tools()
    tools.append(Tool("é", "Replacement", {"type": "object"}, lambda: None))
    payload = _tool_payload(tools)
    assert [item["name"] for item in payload] == EXPECTED
    assert next(item for item in payload if item["name"] == "é")["description"] == "Replacement"


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_sorted_tool_payload_reaches_both_http_protocols(monkeypatch, api):
    recorded = []

    def receive(request):
        recorded.append(json.loads(request.content))
        body = ({"choices": [{"message": {"content": "done"}, "finish_reason": "stop"}]}
                if api == "openai" else
                {"content": [{"type": "text", "text": "done"}], "stop_reason": "end_turn"})
        return httpx.Response(200, json=body)

    original = httpx.Client
    monkeypatch.setattr(httpx, "Client", lambda **kwargs:
                        original(transport=httpx.MockTransport(receive), **kwargs))
    client = Client(SimpleNamespace(get=lambda _: None), {"model": "fixture/model", "provider": {"fixture": {
        "api": api, "options": {"apiKey": "test", "baseURL": "https://model.invalid/v1"},
        "models": {"model": {"temperature": False}},
    }}})
    provider, model = client.resolve("fixture/model")
    assert client.complete(provider=provider, model=model, system="", messages=[],
                           tools=_tool_payload(make_tools())).text == "done"
    assert len(recorded) == 1
    wire = recorded[0]["tools"]
    names = [item["function"]["name"] if api == "openai" else item["name"] for item in wire]
    assert names == EXPECTED
