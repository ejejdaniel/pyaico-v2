"""Expected values from the canonical LLM config.

Tests check that the configured settings reach the composed config and the actual
request, not which values were chosen: changing the model, temperature or limits is
an experiment decision made in config/llm.opencode.json, not a test change.
"""

import json
from pathlib import Path

PATH = Path(__file__).resolve().parents[1] / "config/llm.opencode.json"


def load() -> dict:
    return json.loads(PATH.read_text(encoding="utf-8"))


def root_model() -> str:
    """The configured root model reference, e.g. local/<model>."""
    return load()["model"]


def model_name() -> str:
    return root_model().split("/", 1)[1]


def model_definition() -> dict:
    config = load()
    provider, model = root_model().split("/", 1)
    return config["provider"][provider]["models"][model]


def output_limit() -> int:
    return model_definition()["limit"]["output"]


def reasoning_effort() -> str:
    return model_definition()["options"]["reasoningEffort"]


def seed():
    """The configured seed option: None, "random" (a new seed for each request) or a fixed number."""
    return (model_definition().get("options") or {}).get("seed")


def agent_temperature(name: str):
    return load()["agent"][name]["temperature"]


def agent_temperatures() -> dict:
    return {name: agent.get("temperature") for name, agent in load()["agent"].items()}
