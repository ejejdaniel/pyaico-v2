"""Read the parts of an assembled request that the host adds for each step.

With an installed extension, per-step host facts travel as a <host-facts> block
after the history, and real human messages carry a <human id> header. These
helpers let tests check those parts, or compare the history without them.
"""

import re

_FACTS = re.compile(r"(?:\n\n)?<host-facts>\n(.*?)\n</host-facts>", re.S)
_HUMAN = re.compile(r'^<human id="[^"]+">\n(.*)\n</human>$', re.S)


def host_facts(call) -> str:
    """The host facts sent with one captured request (empty when none)."""
    return "\n".join(found for message in call["messages"] if isinstance(message.get("content"), str)
                     for found in _FACTS.findall(message["content"]))


def plain_messages(messages: list[dict]) -> list[dict]:
    """The history as stored: host facts removed and human headers unwrapped."""
    result = []
    for message in messages:
        content = message.get("content")
        if isinstance(content, str) and ("<host-facts>" in content or content.startswith("<human id=")):
            stripped = _FACTS.sub("", content)
            if message.get("role") == "user" and not stripped.strip():
                continue
            match = _HUMAN.match(stripped) if message.get("role") == "user" else None
            message = dict(message, content=match.group(1) if match else stripped)
        result.append(message)
    return result
