"""Shared offline fixture for an ordinary research_review invocation; no model calls."""

import json
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.agent import Agent
from opencode.permission import Broker, Rule
from opencode.provider import Completion
from opencode.store import Store
from researchkit import records, reviewer


def invocation_key(session_id, message_id, call_id):
    """The reviewer's own invocation identity for .research/review-runs/<key>."""
    identity = [session_id, message_id, call_id]
    return records.digest(json.dumps(identity, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Review boundary tests must not contact real transports")
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)


@pytest.fixture
def case(tmp_path, monkeypatch):
    messages = Store(tmp_path / "session.db")
    session = messages.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    human = messages.add_message(session, "user", {"content": "Inspect the exact evidence and its limits."})
    agent = Agent("build", permission=[Rule("*", "*", "allow")])
    ctx = SimpleNamespace(directory=tmp_path, worktree=tmp_path, session_id=session,
                          message_id="msg_review", call_id="call_review", abort=threading.Event(), agent=agent,
                          app=SimpleNamespace(store=messages, permissions=Broker(auto=True)))

    def publish(name, text):
        (tmp_path / name).write_text(text, encoding="utf-8")
        return records.publish(tmp_path, kind="notes", title=name, files=[name], depends_on=[])

    report = publish("report.txt", "A recorded interpretation.\n")
    source = publish("source.txt", "An observation with limited scope.\n")
    commission = publish("commission.txt", human["content"] + "\n")
    loc = lambda record, source: {"record_ref": record["record_path"], "source_path": source}
    args = {"scope": "Assess the selected claim against the selected evidence.",
            "reviewed_refs": [report["record_path"]],
            "files": [loc(report, "report.txt"), loc(source, "source.txt"), loc(commission, "commission.txt")],
            "commission_files": [loc(commission, "commission.txt")],
            "required_subjects": [{**loc(report, "report.txt"), "quote": "A recorded interpretation."}]}
    model_value = {"checks": [{"subject": {"required_subject": 1},
                              "evidence": [{"file_id": "F2", "start_line": 1, "end_line": 1}],
                              "decision": "conditional", "reason": "The supplied observation is limited."}]}
    model = Mock(return_value=Completion(text=json.dumps(model_value), finish_reason="stop"))
    monkeypatch.setattr(reviewer, "complete_once", model)
    key = invocation_key(ctx.session_id, ctx.message_id, ctx.call_id)
    yield SimpleNamespace(root=tmp_path, ctx=ctx, args=args, model=model, model_value=model_value,
                          messages=messages, human=human,
                          initial=tmp_path / ".research/review-runs" / key / "initial")
    messages.close()
