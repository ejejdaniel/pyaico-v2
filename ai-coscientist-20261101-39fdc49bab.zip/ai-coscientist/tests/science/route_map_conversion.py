"""Mechanical conversion of saved old-format mind maps into the route-family format.

The files under fixtures/mindmap_saved are byte-exact copies of real runs and stay
unchanged. Tests that need a map in the current format pass those saved maps
through `to_route_map`. The result is a deterministic reshaping of the saved
text for format, rendering and pipeline tests: it is not a model output, and
its directions are explicitly marked as not stated by the old format.
"""

from __future__ import annotations

from copy import deepcopy

_NOT_STATED = "舊格式未標明方向"


def _join(items, limit):
    return "、".join(items)[:limit]


def to_route_map(old: dict) -> dict:
    """Return a new-format copy; a value already in the new format is returned unchanged."""
    if "target_model" in old:
        return deepcopy(old)
    names = []
    for family in old["families"]:
        for item in family["mechanism_chain"]["target_observables"]:
            name = item[:200]
            if name not in names and len(names) < 12:
                names.append(name)
    target_model = {
        # The old format has no numbers; these placeholders are labelled as such and are not data.
        "observables": [{"id": f"O{number}", "name": name, "ranking_score": "舊格式未記錄", "unit": "未記錄",
                         "kind": "nominal",
                         "target_value": 0, "tolerance": 0,
                         "current_values": [{"label": "舊格式未記錄數值（轉寫占位）", "value": 0}],
                         "needed_change": "舊格式未記錄需要的變化"}
                        for number, name in enumerate(names, 1)],
        "governing_relation": "舊格式沒有共用的目標模型；以下路線由舊家族逐欄轉寫。",
        "governing_terms": [{"id": "G1", "quantity": "舊格式未記錄主導項", "effect_on_targets": "舊格式未記錄",
                             "uncovered_reason": "舊格式沒有主導項，無從對應路線"}],
        "couplings": [],
    }
    families = []
    for family in old["families"]:
        chain = family["mechanism_chain"]
        families.append({
            "family_id": family["family_id"],
            "title": family["title"],
            "summary": family["core_mechanism"][:1200],
            "principle": family["causal_role"],
            "scope_status": "in_task",
            "levers": list(chain["inputs_or_controls"]),
            "acts_on_terms": [],
            "steps": [
                {"change": _join(chain["inputs_or_controls"], 1600),
                 "quantity": _join(chain["intermediate_processes"], 300),
                 "effect": family["core_mechanism"][:1600], "evidence": "見核心機制原文"},
                {"change": _join(chain["intermediate_processes"], 1600),
                 "quantity": names[0] if names[0] in chain["target_observables"]
                 else _join(chain["target_observables"], 300),
                 "effect": family["interaction_motif"], "evidence": "見核心機制原文"},
            ],
            "target_effect": [{"observable_id": "O1", "direction": _NOT_STATED, "predicted_sign": "unknown",
                               "evidence_status": "untested",
                               "magnitude": "無法估計", "basis": "舊格式沒有對目標的方向與幅度欄位"}],
            "side_effects": [{"observable_id": f"O{number}", "effect": "舊格式未記錄對此觀測量的影響"}
                             for number in range(2, len(names) + 1)],
            "prerequisites": (family["key_prerequisites"] + "\n" + family["scope_mode"])[:1600],
            "early_check": family["tension_strategy"],
            "main_bottleneck": family["main_bottleneck"],
            "expected_failure_mode": family["expected_failure_mode"],
            "viability_band": family["viability_band"],
        })
    return {
        "title": old["title"],
        "landscape_summary": old["landscape_summary"],
        "target_model": target_model,
        "families": families,
        "supported_relationships": list(old["supported_relationships"]),
        "unresolved_gaps": list(old["unresolved_gaps"]),
        "evidence_boundary_summary": old["evidence_boundary_summary"],
    }
