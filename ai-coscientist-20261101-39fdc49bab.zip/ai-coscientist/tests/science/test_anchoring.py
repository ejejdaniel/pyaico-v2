"""Scale check and declared anchoring for proxies that predict a measured quantity; no model calls."""

import json

import pytest

from researchkit import anchoring, board, leaderboard, records

BASE, CANDS = ["h1", "h2"], ["s1", "s2"]
MEASURED = {"h1": 53.7, "h2": 47.9}
# A formula whose intercept sits at the target: right differences, wrong level.
RAW = {"h1": 41.2, "h2": 35.4, "s1": 33.0, "s2": 30.0}


def test_check_reports_offset_residuals_and_order_without_changing_values():
    values, check = anchoring.apply(RAW, MEASURED, BASE, CANDS)
    assert values == RAW and not check["anchored"]
    assert check["mean_offset"] == pytest.approx(-12.5)
    assert check["residual_spread"] == pytest.approx(0.0)
    assert check["order_agreement"] == "1/1" and "order_disagreements" not in check


def test_mean_offset_ranks_baselines_by_measurement_and_shifts_candidates():
    values, check = anchoring.apply(RAW, MEASURED, BASE, CANDS, "mean_offset")
    assert check["anchored"] and check["offset_applied"] == pytest.approx(-12.5)
    assert values["h1"] == 53.7 and values["h2"] == 47.9
    assert values["s1"] == pytest.approx(45.5) and values["s2"] == pytest.approx(42.5)
    assert "not validation" in check["note"]


def test_reference_sample_uses_that_sample_only():
    values, check = anchoring.apply(RAW, MEASURED, BASE, CANDS, {"reference_sample": "h2"})
    assert check["offset_applied"] == pytest.approx(35.4 - 47.9)
    assert values["s1"] == pytest.approx(33.0 + 12.5)


@pytest.mark.parametrize("measured, anchor, reason", [
    ({"h1": 53.7}, "mean_offset", "needs at least two measured baselines"),
    (MEASURED, {"reference_sample": "s1"}, "has no measured value"),
    ({}, "mean_offset", "cannot be checked"),
])
def test_anchoring_is_refused_when_its_conditions_fail(measured, anchor, reason):
    values, check = anchoring.apply(RAW, measured, BASE, CANDS, anchor)
    assert values == RAW and not check["anchored"] and reason in check["status"]


def test_order_disagreement_is_reported_because_an_offset_cannot_fix_it():
    raw = dict(RAW, h1=30.0)  # predicts h1 below h2, measured the other way round
    _, check = anchoring.apply(raw, MEASURED, BASE, CANDS)
    assert check["order_disagreements"] == [["h1", "h2"]] and check["order_agreement"] == "0/1"


def test_bad_anchor_declarations_are_rejected():
    for bad in ("offset", {"reference_sample": 3}, {"other": "h1"}):
        with pytest.raises(ValueError):
            anchoring.anchor_mode(bad)


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def _pool(root, formula_extra):
    hypotheses = save(root, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    data = save(root, "prepared_data", {"d/measured.json": {k: {"EOP_mJ": v} for k, v in MEASURED.items()}})
    formula = {"formula_id": "P1", "expression": "EOP", "hypothesis_ids": ["H1"], "direction": "target",
               "target_value": 40.0}
    formula.update({key: (dict(value, record_ref=data["record_path"]) if key == "measured" else value)
                    for key, value in formula_extra.items()})
    f1 = save(root, "proxy_formula", {"f/proxy_formula.json": formula}, [hypotheses])
    v1 = save(root, "implementation", {"v/values.json": RAW}, [f1])
    args = {"baseline_ids": BASE, "candidate_ids": CANDS,
            "sheets": [{"formula_ref": f1["record_path"],
                        "values": {"record_ref": v1["record_path"], "source_path": "v/values.json"}}]}
    return args, data


MEASURED_SELECTION = {"measured": {"source_path": "d/measured.json", "column": "EOP_mJ"}}


def test_leaderboard_records_the_scale_check_and_board_flags_off_scale_predictions(tmp_path):
    args, data = _pool(tmp_path, MEASURED_SELECTION)
    receipt = leaderboard.run(args, tmp_path, tmp_path / ".research/leaderboards/one")
    sheet = receipt["result"]["sheets"][0]
    assert sheet["scale_check"]["mean_offset"] == pytest.approx(-12.5) and not sheet["scale_check"]["anchored"]
    assert data["record_path"] in records.read_record(tmp_path, receipt["record"]["record_path"])["depends_on"]
    texts = [item["text"] for item in board.build(tmp_path)["notice_items"]]
    assert any("預測偏離量測" in text and "平均偏差 -12.5" in text for text in texts)


def test_declared_anchor_changes_the_ranking_and_keeps_raw_values(tmp_path):
    args, _ = _pool(tmp_path, dict(MEASURED_SELECTION, anchor="mean_offset"))
    sheet = leaderboard.run(args, tmp_path, tmp_path / ".research/leaderboards/two")["result"]["sheets"][0]
    assert sheet["values"]["h1"] == 53.7 and sheet["values"]["s2"] == pytest.approx(42.5)
    assert sheet["raw_values"]["s2"] == 30.0
    # Anchored: s2 (42.5) is closest to 40 and beats the best baseline h2 (47.9).
    assert sheet["candidate_status"]["s2"] == "better"
    texts = [item["text"] for item in board.build(tmp_path)["notice_items"]]
    assert not any("預測偏離量測" in text for text in texts)


def test_target_formula_without_measured_gets_a_notice_and_anchor_needs_measured(tmp_path):
    args, _ = _pool(tmp_path, {})
    leaderboard.run(args, tmp_path, tmp_path / ".research/leaderboards/three")
    assert any("沒有指明 measured" in item["text"] for item in board.build(tmp_path)["notice_items"])
    other = tmp_path / "other"
    other.mkdir()
    bad_args, _ = _pool(other, {"anchor": "mean_offset"})
    with pytest.raises(ValueError, match="anchor needs direction target and a measured selection"):
        leaderboard.run(bad_args, other, other / ".research/leaderboards/four")


def test_a_revision_with_measured_clears_the_notice_on_the_immutable_original(tmp_path):
    args, data = _pool(tmp_path, {})
    original = args["sheets"][0]["formula_ref"]
    texts = [item["text"] for item in board.build(tmp_path)["notice_items"] if "沒有指明 measured" in item["text"]]
    assert len(texts) == 1 and "另存一筆修訂版" in texts[0] and "revises" in texts[0]
    revised = {"formula_id": "P1", "expression": "EOP", "hypothesis_ids": ["H1"], "direction": "target",
               "target_value": 40.0, "measured": dict(MEASURED_SELECTION["measured"], record_ref=data["record_path"])}
    save(tmp_path, "proxy_formula", {"f2/proxy_formula.json": revised},
         [{"record_path": original}, data])
    assert not any("沒有指明 measured" in item["text"] for item in board.build(tmp_path)["notice_items"])


def test_a_delivery_without_a_final_lca_judgment_gets_an_action_notice(tmp_path):
    save(tmp_path, "task", {"task.md": "commission"})
    report = save(tmp_path, "report", {"report.md": "report"})

    def missing():
        return [item for item in board.build(tmp_path)["notice_items"] if "沒有 kind=final_lca" in item["text"]]

    notice, = missing()
    assert notice["level"] == "action" and "final-lca/SKILL.md" in notice["text"]
    save(tmp_path, "final_lca", {"lca.md": "released within the stated boundary"}, [report])
    assert missing() == []


def test_the_leaderboard_checks_an_anchored_formula_on_its_anchored_predictions(tmp_path):
    # v41's leaderboard ranked candidates on the anchored values but ordered the history on the raw ones,
    # about 48 below the target, and labelled the sheet history_reversed.
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    data = save(tmp_path, "prepared_data", {"d/measured.json": {k: {"EOP_mJ": v} for k, v in MEASURED.items()}})
    selection = {"record_ref": data["record_path"], "source_path": "d/measured.json", "column": "EOP_mJ"}
    formula = save(tmp_path, "proxy_formula", {"f/proxy_formula.json": {
        "formula_id": "P1", "expression": "ln k", "hypothesis_ids": ["H1"], "direction": "target",
        "target_value": 40.0, "measured": selection, "anchor": "mean_offset",
        "kpi": {**selection, "better": "target", "target_value": 40.0}}}, [hypotheses])
    values = save(tmp_path, "implementation",
                  {"v/values.json": {"h1": -6.534, "h2": -9.801, "s1": -16.66, "s2": -12.0}}, [formula])
    args = {"baseline_ids": BASE, "candidate_ids": CANDS,
            "sheets": [{"formula_ref": formula["record_path"],
                        "values": {"record_ref": values["record_path"], "source_path": "v/values.json"}}]}
    sheet = leaderboard.run(args, tmp_path, tmp_path / ".research/leaderboards/v41")["result"]["sheets"][0]
    assert sheet["history_order"]["agreement"] == "1/1" and not sheet["history_order"]["reversed"]
    assert sheet["raw_values"]["h1"] == -6.534 and sheet["scale_check"]["anchored"]
