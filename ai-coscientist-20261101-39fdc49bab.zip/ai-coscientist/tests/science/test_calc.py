"""calc: one-line conclusions for stats, sensitivity, interval and logic; no model calls."""

import json
import re

import pytest

from researchkit import board, calc, scoring
from researchkit.calc_expr import ExprError, parse
from test_delivery_acceptance import case  # noqa: F401  (fixture)


def test_two_samples_can_never_be_significant():
    result = calc.run("stats", {"x": [1, 2], "y": [3, 5]})
    assert result["permutation_p"]["smallest_possible_two_sided"] == 1.0
    assert "cannot distinguish" in result["conclusion"]
    assert scoring.compare({"a": 1, "b": 2}, {"a": 1, "b": 3}, "higher")["permutation_p"]["one_sided"] == 0.5


def test_exact_permutation_p_for_a_perfect_order_of_six():
    result = calc.run("stats", {"x": [1, 2, 3, 4, 5, 6], "y": [2, 4, 5, 7, 9, 12]})
    assert result["permutation_p"]["two_sided"] == pytest.approx(2 / 720)


def test_interval_bounds_and_where_they_occur():
    result = calc.run("interval", calc.EXAMPLES["interval"])
    assert result["exact"] and result["lower"]["attained"] == pytest.approx(10.5)
    assert result["lower"]["at"] == {"k": 1.5, "x": 3.0}
    # interval arithmetic alone would give [0, 9] for (x-2)^2 on [0, 3]... the minimum is found by splitting
    curve = calc.run("interval", {"expr": "(x - 2)^2 + 1", "ranges": {"x": [0, 3]}})
    assert curve["lower"]["guaranteed"] == pytest.approx(1, abs=1e-6) and curve["upper"]["attained"] == 5


def test_interval_distribution_gives_probability_of_a_condition():
    result = calc.run("interval", {"expr": "x > 0", "normal": {"x": [0, 1]}})
    assert result["probability_true"] == pytest.approx(0.5, abs=0.02)


def test_logic_proves_finds_counterexamples_and_names_conflicts():
    proved = calc.run("logic", calc.EXAMPLES["logic"])
    assert proved["verdict"] == "proved" and proved["premises_used"] == ["P1", "P2"]
    refuted = calc.run("logic", {"premises": [*calc.EXAMPLES["logic"]["premises"], "x >= 5"],
                                 "goal": "y >= 11"})
    assert refuted["verdict"] == "not_proved" and refuted["goal_possible"] is False
    clash = calc.run("logic", {"premises": [{"id": "low", "expr": "x < 2"}, {"id": "high", "expr": "x > 3"}]})
    assert clash["verdict"] == "premises_inconsistent" and clash["conflicting"] == ["high", "low"]


def test_sensitivity_reports_how_often_a_surpass_survives_noise():
    result = calc.run("sensitivity", {**calc.EXAMPLES["sensitivity"], "draws": 4000})
    share = result["candidates"]["s1"]["beats_best_baseline_on_primary"]
    assert 0.6 < share < 0.8  # 3.7 vs 3.5 with sd 0.3 on both: P(N(0.2, 0.42) > 0) ~ 0.68


def test_weight_sensitivity_gives_a_counterexample():
    result = calc.run("sensitivity", {"expr": "a*x + b*y", "rows": {"h1": {"x": 1, "y": 5}, "s1": {"x": 3, "y": 2}},
                                      "ranges": {"a": [0.5, 1.5], "b": [0.2, 1]}, "direction": "higher"})
    assert result["nominal_order"] == ["s1", "h1"] and result["counterexample"]["first"] == "h1"


@pytest.mark.parametrize("kind, data, message", [
    ("interval", {"expr": "a + b", "ranges": {"a": [0, 1]}}, "no value, range or distribution for b"),
    ("logic", {"premises": ["exp(x) > 1"], "goal": "x > 0"}, "cannot reason about exp"),
    ("stats", {"x": [1, 2, 3], "y": [1, 2]}, "same length"),
])
def test_errors_say_what_is_wrong_and_show_an_example(kind, data, message):
    with pytest.raises(calc.CalcError, match=message) as caught:
        calc.run(kind, data)
    assert "Example input:" in str(caught.value)


def test_a_logic_input_names_every_unreadable_part_at_once():
    # A run (2026-11-01) was refused four times in a row, each refusal naming the next unreadable part.
    with pytest.raises(calc.CalcError) as caught:
        calc.run("logic", {"premises": ["x1 = ln(0.6)", "e = pow(x1, 2)"], "goal": "there is a k with e > k"})
    text = str(caught.value)
    assert "3 problems, all of them listed" in text
    assert "'ln(0.6)' (write log, the natural logarithm)" in text and "(write a^b)" in text
    assert "goal: cannot read" in text
    assert text.count("Write numbers, names") == 1 and "Example input:" in text


def test_expressions_read_like_paper():
    assert parse("x^2 = y")[0] == "cmp"
    assert parse("x <= 3 -> y >= 10")[0] == "implies"
    with pytest.raises(ExprError):
        parse("__import__('os')")


def test_tool_draft_is_promoted_with_research_record_and_shown_on_the_board(case):
    from opencode.loop import ToolContext
    from researchkit.tools import _calc, _publish
    root, app, session = case
    ctx = ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)
    output = _calc({"kind": "logic", "input": calc.EXAMPLES["logic"]}, ctx).output
    assert output.startswith("Proved")
    draft = re.search(r"Draft saved at (\S+)\.", output).group(1)
    assert not (root / ".research/records").exists() or "calc" not in board.render(board.build(root))
    _publish({"kind": "calc", "title": "overshoot check", "files": [draft]}, ctx)
    assert "（logic）：Proved" in board.render(board.build(root))


def test_calc_tool_is_registered():
    from researchkit.tools import TOOLS
    tool = next(t for t in TOOLS if t.name == "calc")
    assert "logic" in tool.description and json.dumps(calc.EXAMPLES["logic"]["premises"][0])[1:-1] in tool.description


MODULE = '''
def score(text):
    table = {"A": 3.0, "B": 2.0, "C": 2.0}
    return table.get(text), {"note": "detail"}

def line(a, x):
    return a * x if x < 5 else a * x - 1

print("module output must not break the result")
'''


def test_properties_checks_the_authors_code_in_a_separate_process(tmp_path):
    (tmp_path / "work").mkdir()
    (tmp_path / "work/model.py").write_text(MODULE, encoding="utf-8")
    result = calc.run("properties", {"module": "work/model.py", "function": "score", "output": "0", "checks": [
        {"greater": [["A", "B"]], "why": "mechanism"}, {"finite": ["A", "D"]}, {"less": [["C", "B"]]}]},
        root=tmp_path)
    assert [c["passed"] for c in result["checks"]] == [True, False, False]
    assert "returned None" in result["checks"][1]["failures"][0] and result["checks"][0]["why"] == "mechanism"
    assert result["conclusion"].startswith("2 of 3 checks fail")
    sweep = calc.run("properties", {"module": "work/model.py", "function": "line", "call": "kwargs", "checks": [
        {"formula": "a*x", "inputs": [{"a": 2, "x": 1}, {"a": 2, "x": 7}]},
        {"increasing": "x", "base": {"a": 1}, "range": [0, 10]}]}, root=tmp_path)
    assert [c["passed"] for c in sweep["checks"]] == [False, False]
    assert "formula gives 14" in sweep["checks"][0]["failures"][0]


def test_property_check_formats_say_what_an_input_is_under_each_call(tmp_path):
    # A run (2026-11-01) spent a dozen calls finding the pair format and read equal as "f(a) equals b".
    from researchkit.calc_checks import plan_properties

    def fail(message):
        raise ValueError(message)

    base = {"module": "work/model.py", "function": "score"}
    with pytest.raises(ValueError, match=r"value must be a list of \[input, known output\] pairs.*f\(41.0\) = 0.0"):
        plan_properties({**base, "checks": [{"value": [[40.0]]}]}, fail)
    with pytest.raises(ValueError, match="with call kwargs an input is an object of named arguments"):
        plan_properties({**base, "call": "kwargs", "checks": [{"less": [[{"x": 1}]]}]}, fail)
    with pytest.raises(ValueError, match=r"call must be single, kwargs or args, not \{'x': 'arg'\}"):
        plan_properties({**base, "call": {"x": "arg"}, "checks": [{"value": [[1, 2]]}]}, fail)
    (tmp_path / "work").mkdir()
    (tmp_path / "work/model.py").write_text(MODULE, encoding="utf-8")
    result = calc.run("properties", {**base, "output": "0", "checks": [{"equal": [["A", "B"]]}]}, root=tmp_path)
    assert "a known output is checked with value" in result["checks"][0]["failures"][0]


def test_causal_names_what_moves_together_and_what_to_adjust_for():
    design = calc.run("causal", calc.EXAMPLES["causal"])
    assert design["entangled"] == {"T": ["catalyst"], "catalyst": ["T"]}
    assert "add a sample that changes catalyst while keeping T" in design["conclusion"]
    graph = calc.run("causal", {"edges": ["catalyst -> rate -> yield", "T -> rate", "batch -> catalyst",
                                          "batch -> T"], "treatment": "catalyst", "outcome": "yield",
                                "observed": ["catalyst", "T", "rate", "yield"]})
    assert graph["identifiable"] and graph["adjustment_set"] == ["T"] and graph["mediators"] == ["rate"]
    hidden = calc.run("causal", {"edges": ["a -> b", "a <-> b"], "treatment": "a", "outcome": "b"})
    assert hidden["identifiable"] is False


def test_constants_come_with_a_source_or_are_reported_missing():
    named = calc.run("constant", {"names": ["R", "pKa_water"]})
    assert named["constants"]["R"]["value"] == pytest.approx(8.314462618)
    assert named["not_found"] == ["pKa_water"] and "no value is given" in named["conclusion"]
    assert calc.run("constant", {"formula": "CuSO4·5H2O"})["molar_mass"] == pytest.approx(249.68, abs=0.01)
    assert calc.run("constant", {"smiles": "CCO"})["formula"] == "C2H6O"


def test_pubchem_values_carry_their_cited_source():
    view = {"Record": {"Reference": [{"ReferenceNumber": 7, "SourceName": "ChEMBL", "URL": "https://x"}],
                       "Section": [{"Information": [{"ReferenceNumber": 7,
                                                     "Value": {"StringWithMarkup": [{"String": "4.76"}]}}]}]}}

    def fetch(url, form=None):
        if "pug_view" in url:
            return 200, json.dumps(view)
        if "nothing" in url:
            return 404, "not found"
        return 200, json.dumps({"PropertyTable": {"Properties": [{"CID": 176, "MolecularFormula": "C2H4O2",
                                                                    "MolecularWeight": "60.05"}]}})

    found = calc.run("constant", {"compound": "acetic acid", "experimental": "pKa"}, fetch=fetch)
    assert found["experimental"]["values"][0] == {"value": "4.76", "source": "ChEMBL", "source_detail": None,
                                                 "url": "https://x"}
    assert calc.run("constant", {"compound": "nothing"}, fetch=fetch)["found"] is False
    with pytest.raises(calc.CalcError, match="needs the network"):
        calc.run("constant", {"compound": "acetic acid"})


def test_units_catch_mixed_scales_and_impossible_sums():
    mixed = calc.run("units", calc.EXAMPLES["units"])
    assert mixed["consistent"] and mixed["mixed_scale"] and mixed["si_factor"] == pytest.approx(1000)
    bad = calc.run("units", {"expr": "dose/thickness + E0",
                             "units": {"dose": "mJ/cm^2", "thickness": "nm", "E0": "mJ/cm^2"}})
    assert bad["consistent"] is False and "cannot combine" in bad["problem"]
    assert calc.run("units", {"expr": "log(c)", "units": {"c": "mol/L"}})["consistent"] is False
    assert calc.run("units", {"convert": "1 atm", "to": "kPa"})["value"] == pytest.approx(101.325)
    assert calc.run("units", {"convert": "25 degC", "to": "K"})["value"] == pytest.approx(298.15)
    rate = calc.run("units", {"expr": "A*exp(-Ea/(R*T))", "expect": "1/min",
                              "units": {"A": "s^-1", "Ea": "J/mol", "R": "J/(mol*K)", "T": "K"}})
    assert rate["multiply_by_to_get_expect"] == pytest.approx(60)


def test_design_picks_the_sample_that_separates_entangled_factors():
    result = calc.run("design", calc.EXAMPLES["design"])
    pick, = result["picks"]  # either candidate breaks the catalyst/T link
    assert pick["id"] in ("c1", "c2") and pick["adds_estimable_effect"]
    assert result["estimable_before"] == 1 and result["estimable_after"] == 2
    assert "every varying factor is then separable" in result["conclusion"]


def test_design_picks_the_measurement_that_tells_hypotheses_apart():
    result = calc.run("design", {"predictions": {"H1": {"c1": 1.0, "c2": 2.0}, "H2": {"c1": 1.1, "c2": 3.5}},
                                 "sd": 0.4})
    assert result["picks"] == ["c2"] and result["candidates"]["c1"]["mean_tell_apart"] < 0.6


def test_script_api_matches_the_tool_and_saves_a_board_readable_file(tmp_path):
    result = calc.logic(calc.EXAMPLES["logic"])
    assert str(result).startswith("Proved") and result == calc.run("logic", calc.EXAMPLES["logic"])
    saved = json.loads(result.save(tmp_path / "x/logic.json").read_text(encoding="utf-8"))
    assert saved["calc"]["kind"] == "logic" and saved["result"]["verdict"] == "proved"
    assert calc.interval(expr="x^2", ranges={"x": [-1, 2]})["upper"]["attained"] == 4
