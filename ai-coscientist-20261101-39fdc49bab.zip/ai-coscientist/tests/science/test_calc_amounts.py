"""calc kind=units, recipe form: moles and mole ratios from masses and shares; no model calls."""

import pytest

from researchkit import calc

ETHANOL_WATER = {"ethanol": "CCO", "water": "O"}


def test_shares_by_mass_and_by_mole_give_moles_from_each_structures_molar_mass():
    result = calc.units({"structures": ETHANOL_WATER, "ratio": ["ethanol", "water"],
                         "records": {"A": {"mix": {"g": 100, "wt": {"ethanol": 50, "water": 50}}},
                                     "B": {"mix": {"g": 100, "mol": {"ethanol": 1, "water": 1}}}}})
    mass = result["molar_mass_g_per_mol"]
    a, b = result["readings"]["as given"]["A"], result["readings"]["as given"]["B"]
    assert a["mmol"]["ethanol"] == pytest.approx(50 / mass["ethanol"] * 1000)
    assert a["ratios"]["ethanol:water"] == pytest.approx(mass["water"] / mass["ethanol"])
    assert b["ratios"]["ethanol:water"] == pytest.approx(1.0)
    assert b["mmol_per_g"]["ethanol"] == pytest.approx(1000 / (mass["ethanol"] + mass["water"]))
    assert str(result) == "Mole ratio ethanol:water: A 0.391, B 1 (A to B +156%)."


def test_readings_say_whether_a_change_holds_under_every_reading_of_an_unclear_basis():
    def record(salt_g, total):
        return {"resin": {"g": total - salt_g, "mol": {"X": 1}}, "salt": {"g": salt_g, "wt": {"Z": 1}}}

    same = calc.units({"molar_mass": {"X": 100, "Z": 200}, "ratio": ["Z", "X"],
                       "readings": {"of resin": {"A": record(10, 110), "B": record(8, 108)},
                                    "of all": {"A": record(10, 100), "B": record(8, 100)}}})
    assert "From A to B it falls under every reading" in str(same)
    assert "Its size depends on the reading" in str(same)
    split = calc.units({"molar_mass": {"X": 100, "Z": 200}, "ratio": ["Z", "X"],
                        "readings": {"one": {"A": record(10, 110), "B": record(12, 112)},
                                     "two": {"A": record(10, 110), "B": record(8, 108)}}})
    assert "its direction depends on the reading" in str(split) and "settle the basis" in str(split)


def test_a_composite_sums_its_parts_and_a_missing_molar_mass_is_refused_not_guessed():
    result = calc.units({"structures": {"Na": "[Na+]", "OAc": "CC(=O)[O-]", "unit": "*CC(*)c1ccccc1"},
                         "components": {"NaOAc": ["Na", "OAc"]},
                         "records": {"A": {"film": {"g": 10, "wt": {"NaOAc": 1, "unit": 9}}}}, "ratio": ["NaOAc", "unit"]})
    mass = result["molar_mass_g_per_mol"]
    assert mass["NaOAc"] == pytest.approx(82.03, abs=0.01)
    assert any("open bonds" in note for note in result["notes"])
    with pytest.raises(calc.CalcError, match="Q has no structure, components entry or molar_mass; a molar mass is "
                                              "not guessed"):
        calc.units({"structures": ETHANOL_WATER, "records": {"A": {"mix": {"g": 1, "wt": {"Q": 1}}}}})
    with pytest.raises(calc.CalcError, match="by \"mol\" or by \"wt\""):
        calc.units({"structures": ETHANOL_WATER, "records": {"A": {"mix": {"g": 1}}}})
    with pytest.raises(calc.CalcError, match="has no water for the ratio"):
        calc.units({"structures": ETHANOL_WATER, "ratio": ["ethanol", "water"],
                    "records": {"A": {"mix": {"g": 1, "wt": {"ethanol": 1}}}}})
