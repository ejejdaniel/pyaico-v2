"""Calculator messages that say how to fix the input; no model calls.

v34 spent about 20 minutes and 30 property checks rewriting functions around the call convention,
and wrote a benzoate pattern with the ring on the oxygen, then called the quencher a data gap.
"""

from researchkit import calc
from test_calc_roles import INPUT


def test_a_list_result_and_a_mismatched_call_say_how_to_call_the_function(tmp_path):
    (tmp_path / "work").mkdir()
    (tmp_path / "work" / "model.py").write_text(
        "def table(x):\n    return [x, 2 * x]\n\n"
        "def index(dose, quencher):\n    return dose - quencher\n", encoding="utf-8")
    listed = calc.properties({"module": "work/model.py", "function": "table",
                              "checks": [{"greater": [[2, 1]]}]}, root=tmp_path)
    assert 'returned a list of 2, not a number: name the number to check with "output"' in str(listed)
    assert str(calc.properties({"module": "work/model.py", "function": "table", "output": "1",
                                "checks": [{"greater": [[2, 1]]}]}, root=tmp_path)).startswith("All 1 checks pass")
    single = calc.properties({"module": "work/model.py", "function": "index",
                              "checks": [{"greater": [[{"dose": 2, "quencher": 1}, {"dose": 1, "quencher": 1}]]}]},
                             root=tmp_path)
    assert 'a function of several named inputs takes "call": "kwargs"' in str(single)
    named = calc.properties({"module": "work/model.py", "function": "index", "call": "kwargs",
                             "checks": [{"greater": [[{"dose": 2, "quencher": 1}, {"dose": 1, "quencher": 1}]]}]},
                            root=tmp_path)
    assert str(named).startswith("All 1 checks pass")


def test_a_feature_no_structure_matches_is_flagged_before_it_becomes_a_data_gap():
    wrong = {**INPUT, "features": {**INPUT["features"], "benzoate": "[#6](=[#8])[#8;X1-]-c1ccccc1"},
             "assigned": {"C13IB2": "quencher"}}
    result = calc.roles(wrong)
    assert result["unmatched_features"] == ["benzoate"]
    assert "No structure matches benzoate: check the SMARTS against the task's own fragment" in str(result)
    assert calc.roles(INPUT)["unmatched_features"] == []
