"""calc kind=roles: roles a task defines by structure, checked by substructure match; no model calls."""

import pytest

from researchkit import calc

# The LIT source's structures and its two structural role rules, as an agent would quote them.
STRUCTURES = {
    "C2": "FC1=CC(=CC(F)=C1)[S+](C1=CC=CC=C1)C1=CC(F)=CC(F)=C1",
    "AA2": "*CC(*)c1ccc(C(=O)Oc2c(I)cc(I)cc2C(=O)OCC(F)(F)S(=O)(=O)[O-])cc1",
    "C13": "FC1=CC=C(C=C1)[S+](C1=CC(F)=CC(F)=C1)C1=CC(F)=CC(F)=C1",
    "IB2": "O=C([O-])c1cc(I)cc(I)c1I",
}
INPUT = {"structures": STRUCTURES, "components": {"C2-AA2": ["C2", "AA2"], "C13IB2": ["C13", "IB2"]},
         "features": {"difluoromethylsulfonate": "OS(=O)(=O)C(F)(F)-*", "benzoate": "OC(=O)c1ccccc1"},
         "roles": {"PAG": {"requires": ["difluoromethylsulfonate"], "source": "PAG must contain OS(=O)(=O)C(F)(F)-*"},
                   "quencher": {"requires": ["benzoate"], "source": "quencher features OC(=O)c1ccccc1"}}}


def test_a_salt_whose_cation_looks_like_an_acid_generator_cannot_be_one_without_the_required_group():
    # v31 and v33 called C13IB2 the acid generator: its cation is a triarylsulfonium, but neither part
    # carries the group the task requires of the PAG.
    result = calc.roles({**INPUT, "assigned": {"C13IB2": "PAG"}})
    assert str(result).startswith("C13IB2 cannot be PAG: none of its parts (C13, IB2) carries "
                                  "difluoromethylsulfonate.")
    # v37 also read the aryl ester inside AA2 as a quencher motif and C13 as an acid generator's cation.
    assert "The benzoate match in AA2 (C2-AA2) is an ester with no acid or base site, unlike IB2 (C13IB2)."         in str(result)
    assert "IB2 (C13IB2) is a base toward the acid of AA2 (C2-AA2)" in str(result)
    assert "The cations C13, C2 carry no proton" in str(result)
    assert result["admissible_roles"] == {"C2-AA2": ["PAG", "quencher"], "C13IB2": ["quencher"]}
    assert result["features_found"]["C2-AA2"] == {"difluoromethylsulfonate": ["AA2"], "benzoate": ["AA2"]}
    held = calc.roles({**INPUT, "assigned": {"C2-AA2": "PAG", "C13IB2": "quencher"}})
    assert str(held).startswith("Every assignment has the features its role requires")
    assert [c["holds"] for c in held["assignment"]] == [True, True]


def test_a_role_no_component_can_take_is_reported_as_a_gap_and_bad_input_is_refused():
    gap = calc.roles({**INPUT, "roles": {**INPUT["roles"], "ALG": {"requires": ["acrylate"]}},
                      "features": {**INPUT["features"], "acrylate": "OC(=O)C=C"}})
    assert gap["unfilled_roles"] == ["ALG"] and "a data gap, not a guess" in str(gap)
    with pytest.raises(calc.CalcError, match="components name structures that are not in structures: X9"):
        calc.roles({**INPUT, "components": {"bad": ["X9"]}})
    with pytest.raises(calc.CalcError, match="RDKit cannot read the SMARTS"):
        calc.roles({**INPUT, "features": {"broken": "C(("}, "roles": {"r": {"requires": ["broken"]}}})
    with pytest.raises(calc.CalcError, match="requires features not defined"):
        calc.roles({**INPUT, "roles": {"r": {"requires": ["nothing"]}}})
    assert "roles" in calc.KINDS and str(calc.roles(calc.EXAMPLES["roles"])).startswith("Every assignment")


# Generic chemistry, not the LIT case: the same answers must come from any salts and neutral molecules.
TPS = "c1ccc(cc1)[S+](c1ccccc1)c1ccccc1"


def test_each_anion_gets_its_acids_class_and_the_weaker_acids_anion_is_a_base_toward_the_stronger():
    result = calc.roles({"structures": {"TPS": TPS, "OTf": "[O-]S(=O)(=O)C(F)(F)F", "OBz": "[O-]C(=O)c1ccccc1"},
                         "components": {"TPS-OTf": ["TPS", "OTf"], "TPS-OBz": ["TPS", "OBz"]},
                         "features": {"onium": "[S+]"}, "roles": {"photoactive": {"requires": ["onium"]}}})
    text = str(result)
    assert ("OTf in TPS-OTf: fluoroalkanesulfonic acid, pKa < -1.86 (below methanesulfonic acid); "
            "OBz in TPS-OBz: aromatic carboxylic acid, pKa ≈ 4.207 (benzoic acid)") in text
    assert "OBz (TPS-OBz) is a base toward the acid of OTf (TPS-OTf)." in text
    assert "The cations TPS carry no proton: each salt's acid-base behaviour comes from its anion." in text
    sites = {s["part"]: s for s in result["acid_base"]["TPS-OBz"]}
    assert sites["OBz"]["source"].startswith("ChEMBL via PubChem CID 243")
    assert sites["TPS"]["site"] == "cation with no proton"


def test_acids_close_in_strength_pass_a_proton_only_in_part_and_neutral_sites_are_classified():
    close = calc.roles({"structures": {"Na": "[Na+]", "OAc": "CC(=O)[O-]", "OBz": "[O-]C(=O)c1ccccc1"},
                        "components": {"NaOAc": ["Na", "OAc"], "NaOBz": ["Na", "OBz"]},
                        "features": {"carboxylate": "[O-]C=O"}, "roles": {"base": {"requires": ["carboxylate"]}}})
    assert "give acids within 2 pKa units: a proton passes between them only in part" in str(close)
    neutral = calc.roles({"structures": {"AcOH": "CC(=O)O", "Et3N": "CCN(CC)CC", "PhOH": "Oc1ccccc1"},
                          "features": {"oxygen": "[#8]"}, "roles": {"r": {"requires": ["oxygen"]}}})
    found = {c: [(s["site"], s["acid"]) for s in sites] for c, sites in neutral["acid_base"].items()}
    assert found == {"AcOH": [("acid", "aliphatic carboxylic acid")], "Et3N": [("base", "amine")],
                     "PhOH": [("acid", "phenol")]}
    assert "Acid each anion gives" not in str(neutral)


def test_a_feature_matched_by_an_ester_in_one_component_and_an_anion_in_another_is_told_apart():
    result = calc.roles({"structures": {"MeOBz": "COC(=O)c1ccccc1", "Na": "[Na+]", "OBz": "[O-]C(=O)c1ccccc1"},
                         "components": {"ester": ["MeOBz"], "salt": ["Na", "OBz"]},
                         "features": {"benzoate": "OC(=O)c1ccccc1"}, "roles": {"base": {"requires": ["benzoate"]}}})
    assert result["admissible_roles"] == {"ester": ["base"], "salt": ["base"]}
    assert result["feature_matches_without_acid_base_site"] == {
        "benzoate": [{"component": "ester", "part": "MeOBz", "is": "an ester"}]}
    assert "The benzoate match in MeOBz (ester) is an ester with no acid or base site, unlike OBz (salt)."         in str(result)


def test_every_problem_of_an_input_comes_in_one_refusal():
    # LIT (2026-10-31) sent a roles input three times and a sensitivity input twice; each refusal named one
    # new problem.
    bad_roles = {"structures": {"R12": "CC(=C)C(=O)O", "PS": None},
                 "features": {"vinyl": "C=C", "blank": ""},
                 "roles": {"PAG": {"requires": ["difluoromethylsulfonate"]}}}
    with pytest.raises(calc.CalcError) as refused:
        calc.roles(bad_roles)
    message = str(refused.value)
    assert "3 problems, all of them listed" in message
    assert "these have none: PS" in message and "these have none: blank" in message
    assert "roles.PAG requires features not defined in features: difluoromethylsulfonate" in message
    sheets = {"P1": {"values": {"h1": 1.0, "c1": 2.0}}, "P2": {"values": {"h1": 1.0}, "direction": "higher"}}
    with pytest.raises(calc.CalcError) as refused:
        calc.run("sensitivity", {"sheets": sheets, "baseline_ids": ["h1"], "candidate_ids": ["c1"]})
    message = str(refused.value)
    assert "4 problems" in message
    for line in ("sheet P1: direction must be higher or lower", "sheet P1: declare sd",
                 "sheet P2: no value for c1", "sheet P2: declare sd"):
        assert line in message
