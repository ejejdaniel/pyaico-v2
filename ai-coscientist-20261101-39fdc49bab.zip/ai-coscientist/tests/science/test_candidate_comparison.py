"""Same-method numeric arithmetic and frozen-source boundaries; no model calls.

The saved replay copies the six methods' existing numbers without running or
approving their original implementation. It does not prove scientific fidelity,
author revision, independent validation, or an end-to-end research workflow.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
import socket
import threading
from types import SimpleNamespace
from unittest.mock import patch

from jsonschema import ValidationError
import pytest

from opencode.permission import Broker, PermissionDenied, PermissionRejected, Rule
from researchkit import candidate_comparison as comparison, records
from researchkit.tools import TOOLS


TOOL = next(tool for tool in TOOLS if tool.name == "research_compare_candidates")
SOURCE = Path(__file__).resolve().parents[2] / "outputs/method_revision_real_20261023_v1/workspace/lit_research"


@pytest.fixture(autouse=True)
def no_model_or_network(monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("Candidate comparison tests must not call a model or network")
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr("researchkit.review_provider.complete_once", forbidden)


def context(root, *, rules=None, abort=None):
    return SimpleNamespace(directory=root, worktree=root, session_id="offline-candidate-comparison",
                           agent=SimpleNamespace(permission=rules if rules is not None else [Rule("*", "*", "allow")]),
                           app=SimpleNamespace(permissions=Broker(auto=True)), abort=abort)


def sources(root, *, values=None, raw=None, kind="implementation", indirect=False, method_kind="formula"):
    (root / "method.txt").write_text("Arithmetic boundary fixture only; no scientific claim.\n", encoding="utf-8")
    method = records.publish(root, kind=method_kind, title="Explicit test method",
                             files=["method.txt"], depends_on=[])
    dependencies = [method["record_path"]]
    if indirect:
        (root / "intermediate.txt").write_text("Declared dependency fixture", encoding="utf-8")
        intermediate = records.publish(root, kind="implementation", title="Dependency boundary fixture",
                                       files=["intermediate.txt"], depends_on=dependencies)
        dependencies = [intermediate["record_path"]]
    if raw is None:
        raw = records.encoded(values if values is not None else {"b1": 1, "b2": 3, "c1": 4, "c2": 2, "unused": 99})
    (root / "values.json").write_bytes(raw)
    saved = records.publish(root, kind=kind, title="Numeric boundary fixture",
                            files=["values.json"], depends_on=dependencies)
    args = {"method_ref": method["record_path"],
            "values": {"record_ref": saved["record_path"], "source_path": "values.json"},
            "baseline_ids": ["b1", "b2"], "candidate_ids": ["c1", "c2"], "direction": "higher"}
    return args, method, saved


@pytest.fixture
def request_data(tmp_path):
    args, method, values = sources(tmp_path)
    return tmp_path, args, method, values


def assert_unsaved(root):
    assert not (root / ".research/method_comparisons").exists()


def test_exact_schema_registration_result_and_frozen_record(request_data):
    root, args, method, source = request_data
    result = TOOL.execute(args, context(root))
    assert result.metadata == {} and result.attachments == []
    assert result.title == "research_compare_candidates"
    receipt = json.loads(result.output)
    assert set(receipt) == {"result", "record"}
    outcome, record = receipt["result"], receipt["record"]
    assert set(outcome) == {"method_ref", "values", "direction", "basis", "baselines", "candidates",
                            "best_baseline", "best_candidate", "delta", "comparison"}
    assert outcome == {
        "method_ref": method["record_path"],
        "values": {**args["values"], "sha256": records.digest((root / "values.json").read_bytes())},
        "direction": "higher", "basis": "this call",
        "baselines": [{"id": "b1", "value": 1.0}, {"id": "b2", "value": 3.0}],
        "candidates": [{"id": "c1", "value": 4.0}, {"id": "c2", "value": 2.0}],
        "best_baseline": {"ids": ["b2"], "value": 3.0},
        "best_candidate": {"ids": ["c1"], "value": 4.0}, "delta": 1.0, "comparison": "better",
    }
    assert set(record) == {"record_path", "kind", "title", "files", "depends_on"}
    assert record["kind"] == "implementation"
    assert record["depends_on"] == [method["record_path"], source["record_path"]]
    stored = records.read_record(root, record["record_path"])
    assert set(stored) == {"kind", "title", "files", "depends_on"}
    assert record == records.present(root, {"record_path": record["record_path"], **stored})
    item, = record["files"]
    assert set(item) == {"source_path", "snapshot", "sha256", "bytes"}
    path = Path(item["source_path"])
    assert path.parts[:2] == (".research", "method_comparisons")
    assert len(path.parts) == 4 and len(path.parts[2]) == 32 and path.name == "comparison.json"
    assert json.loads(Path(item["snapshot"]).read_bytes()) == outcome
    assert (root / item["source_path"]).read_bytes() == Path(item["snapshot"]).read_bytes()
    assert TOOL.parameters == comparison.INPUT_SCHEMA
    # direction may come from a formula's declaration instead; target_value goes with direction target.
    assert set(TOOL.parameters["properties"]) == set(args) | {"target_value"}
    assert set(TOOL.parameters["required"]) == set(args) - {"direction"}
    assert "column" in TOOL.parameters["properties"]["values"]["properties"]
    assert TOOL.parameters["additionalProperties"] is False


@pytest.mark.parametrize("direction,baseline,candidate,delta,decision", [
    ("higher", 3, 5, 2.0, "better"), ("higher", 3, 3, 0.0, "tie"), ("higher", 3, 1, -2.0, "worse"),
    ("lower", 3, 1, 2.0, "better"), ("lower", 3, 3, 0.0, "tie"), ("lower", 3, 5, -2.0, "worse"),
])
def test_directional_delta_and_exact_comparison(tmp_path, direction, baseline, candidate, delta, decision):
    args, _, _ = sources(tmp_path, values={"b1": baseline, "b2": baseline, "c1": candidate, "c2": candidate})
    args["direction"] = direction
    outcome = json.loads(TOOL.execute(args, context(tmp_path)).output)["result"]
    assert outcome["delta"] == delta and outcome["comparison"] == decision
    assert outcome["best_baseline"] == {"ids": ["b1", "b2"], "value": float(baseline)}
    assert outcome["best_candidate"] == {"ids": ["c1", "c2"], "value": float(candidate)}


@pytest.mark.parametrize("direction", ["higher", "lower"])
def test_all_best_ties_follow_input_order_and_ignore_other_ids(tmp_path, direction):
    other = -99 if direction == "higher" else 99
    unselected = 1000 if direction == "higher" else -1000
    args, _, _ = sources(tmp_path, values={"b1": 3, "b2": 3, "b3": other, "c1": 3, "c2": other,
                                          "c3": 3, "unselected": unselected})
    args.update(direction=direction, baseline_ids=["b3", "b2", "b1"], candidate_ids=["c3", "c2", "c1"])
    outcome = json.loads(TOOL.execute(args, context(tmp_path)).output)["result"]
    assert outcome["best_baseline"]["ids"] == ["b2", "b1"]
    assert outcome["best_candidate"]["ids"] == ["c3", "c1"]
    assert [row["id"] for row in outcome["baselines"]] == args["baseline_ids"]
    assert [row["id"] for row in outcome["candidates"]] == args["candidate_ids"]
    assert outcome["comparison"] == "tie" and outcome["delta"] == 0


def test_no_implicit_tolerance_or_rounding(tmp_path):
    args, _, _ = sources(tmp_path, values={"b1": 1.0, "b2": 1.0, "c1": math.nextafter(1.0, math.inf), "c2": 1.0})
    outcome = json.loads(TOOL.execute(args, context(tmp_path)).output)["result"]
    assert outcome["comparison"] == "better"
    assert outcome["delta"] == math.ulp(1.0)
    assert outcome["best_candidate"]["ids"] == ["c1"]


def test_tool_keeps_complete_large_json_result_without_adding_metadata(tmp_path):
    candidates = {f"candidate-{index:04d}": float(index) for index in range(2000)}
    args, _, _ = sources(tmp_path, values={"baseline": -1.0, **candidates})
    args.update(baseline_ids=["baseline"], candidate_ids=list(candidates))
    result = TOOL.execute(args, context(tmp_path))
    assert len(result.output.encode("utf-8")) > 50 * 1024
    receipt = json.loads(result.output)
    assert set(receipt) == {"result", "record"} and result.metadata == {}
    assert len(receipt["result"]["candidates"]) == 2000
    assert receipt["result"]["best_candidate"] == {"ids": ["candidate-1999"], "value": 1999.0}


@pytest.mark.parametrize("mutation", [
    lambda args: args.update(extra=True), lambda args: args.pop("method_ref"),
    lambda args: args.update(method_ref=None), lambda args: args.update(method_ref=""),
    lambda args: args.update(method_ref=".research/records/../record.json"),
    lambda args: args.update(values=None), lambda args: args["values"].update(extra=True),
    lambda args: args["values"].pop("source_path"), lambda args: args["values"].update(source_path=1),
    lambda args: args["values"].update(source_path=" "), lambda args: args["values"].update(record_ref=None),
    lambda args: args.update(direction="maximize"), lambda args: args.update(direction=None),
    lambda args: args.update(baseline_ids=[]), lambda args: args.update(candidate_ids=[]),
    lambda args: args.update(baseline_ids="b1"), lambda args: args.update(candidate_ids=None),
    lambda args: args.update(baseline_ids=["b1", "b1"]), lambda args: args.update(candidate_ids=["c1", "c1"]),
    lambda args: args.update(baseline_ids=[""]), lambda args: args.update(candidate_ids=[False]),
    lambda args: args.update(baseline_ids=[" "]), lambda args: args.update(candidate_ids=["b1", "c1"]),
])
def test_invalid_inputs_fail_without_publication(request_data, mutation):
    root, args, _, _ = request_data
    mutation(args)
    with pytest.raises((ValueError, ValidationError)):
        TOOL.execute(args, context(root))
    assert_unsaved(root)


@pytest.mark.parametrize("value", [None, [], 7, "{}"])
def test_root_input_must_be_object(value):
    with pytest.raises(ValidationError):
        comparison.validate_input(value)


@pytest.mark.parametrize("raw,match", [
    (b'{"b1":1,"b1":2,"b2":3,"c1":4,"c2":2}', "Duplicate JSON key"),
    (b'{"b1":NaN}', "Invalid JSON constant"), (b'{"b1":Infinity}', "Invalid JSON constant"),
    (b'{"b1":-Infinity}', "Invalid JSON constant"), (b'{"b1":1e400}', "finite float"),
    (b'{"b1":' + b'9' * 400 + b'}', "finite float"),
    (b'{"b1":true}', "JSON number"), (b'{"b1":"1"}', "JSON number"),
    (b'{"b1":null}', "JSON number"), (b'{"b1":[]}', "JSON number"),
    (b'{"b1":{}}', "JSON number"), (b'{" ":1}', "nonblank"),
    (b'{}', "nonempty"), (b'[]', "nonempty"), (b'null', "nonempty"),
    (b'{"b1":\xff}', "UTF-8"),
])
def test_invalid_values_json_fails_without_publication(tmp_path, raw, match):
    args, _, _ = sources(tmp_path, raw=raw)
    with pytest.raises(ValueError, match=match):
        TOOL.execute(args, context(tmp_path))
    assert_unsaved(tmp_path)


def test_unselected_values_still_must_be_valid_numbers(tmp_path):
    args, _, _ = sources(tmp_path, raw=b'{"b1":1,"b2":2,"c1":3,"c2":4,"ignored":false}')
    with pytest.raises(ValueError, match="JSON number"):
        TOOL.execute(args, context(tmp_path))
    assert_unsaved(tmp_path)


@pytest.mark.parametrize("direction", ["higher", "lower"])
def test_finite_input_subtraction_overflow_fails(tmp_path, direction):
    args, _, _ = sources(tmp_path, values={"b1": -1.7e308, "b2": -1.7e308, "c1": 1.7e308, "c2": 1.7e308})
    args["direction"] = direction
    with pytest.raises(ValueError, match="subtraction overflowed"):
        TOOL.execute(args, context(tmp_path))
    assert_unsaved(tmp_path)


@pytest.mark.parametrize("oversize", [False, True])
def test_values_byte_limit_includes_all_raw_bytes(tmp_path, oversize):
    raw = b'{"b1":1,"b2":2,"c1":3,"c2":4}'
    raw += b" " * (comparison.MAX_BYTES + int(oversize) - len(raw))
    args, _, _ = sources(tmp_path, raw=raw)
    if oversize:
        with pytest.raises(ValueError, match="262144"):
            TOOL.execute(args, context(tmp_path))
        assert_unsaved(tmp_path)
    else:
        receipt = json.loads(TOOL.execute(args, context(tmp_path)).output)
        assert receipt["result"]["values"]["sha256"] == records.digest(raw)


@pytest.mark.parametrize("indirect,method_kind", [(False, "formula"), (True, "formula"), (False, "implementation")])
def test_declared_dependency_chain_and_unrestricted_method_kind(tmp_path, indirect, method_kind):
    args, method, _ = sources(tmp_path, indirect=indirect, method_kind=method_kind)
    receipt = json.loads(TOOL.execute(args, context(tmp_path)).output)
    assert receipt["result"]["method_ref"] == method["record_path"]
    assert receipt["record"]["depends_on"][0] == method["record_path"]


@pytest.mark.parametrize("issue", ["kind", "wrong-method", "self-method", "missing-id", "wrong-source"])
def test_wrong_source_selection_fails(tmp_path, issue):
    args, _, source = sources(tmp_path, kind="formula" if issue == "kind" else "implementation")
    if issue == "wrong-method":
        (tmp_path / "other.txt").write_text("Different explicit method", encoding="utf-8")
        other = records.publish(tmp_path, kind="formula", title="Other method", files=["other.txt"], depends_on=[])
        args["method_ref"] = other["record_path"]
    elif issue == "self-method":
        args["method_ref"] = source["record_path"]
    elif issue == "missing-id":
        args["candidate_ids"] = ["missing"]
    elif issue == "wrong-source":
        args["values"]["source_path"] = "./values.json"
    with pytest.raises(ValueError):
        TOOL.execute(args, context(tmp_path))
    assert_unsaved(tmp_path)


@pytest.mark.parametrize("which", ["method-manifest", "method-snapshot", "values-manifest", "values-snapshot"])
def test_frozen_source_tampering_fails(request_data, which):
    root, args, method, values = request_data
    record = method if which.startswith("method") else values
    path = root / record["record_path"]
    if which.endswith("snapshot"):
        path = records.local_path(path.parent, record["files"][0]["snapshot"])
    path.write_bytes(path.read_bytes() + b"\n ")
    with pytest.raises(ValueError, match="content has changed"):
        TOOL.execute(args, context(root))
    assert_unsaved(root)


def test_changed_working_values_do_not_replace_frozen_source(request_data):
    root, args, _, _ = request_data
    before = (root / "values.json").read_bytes()
    (root / "values.json").write_text('{"b1":900}', encoding="utf-8")
    receipt = json.loads(TOOL.execute(args, context(root)).output)
    assert receipt["result"]["delta"] == 1.0
    assert receipt["result"]["values"]["sha256"] == records.digest(before)


@pytest.mark.parametrize("permission", ["research_compare_candidates", "read", "edit"])
def test_permission_denial_stops_before_any_comparison_write(request_data, permission):
    root, args, _, _ = request_data
    rules = [Rule("*", "*", "allow"), Rule(permission, "*", "deny")]
    with pytest.raises(PermissionDenied):
        TOOL.execute(args, context(root, rules=rules))
    assert_unsaved(root)


@pytest.mark.parametrize("when", ["before", "read", "publish"])
def test_parent_cancellation_never_returns_success(request_data, when):
    root, args, _, _ = request_data
    abort = threading.Event()
    if when == "before":
        abort.set()
    original_read = comparison.records._read_dependencies
    original_publish = comparison.records.publish

    def read_then_cancel(*positional, **keywords):
        value = original_read(*positional, **keywords)
        if when == "read":
            abort.set()
        return value

    def publish_then_cancel(*positional, **keywords):
        value = original_publish(*positional, **keywords)
        if when == "publish":
            abort.set()
        return value

    with patch.object(comparison.records, "_read_dependencies", side_effect=read_then_cancel), \
            patch.object(comparison.records, "publish", side_effect=publish_then_cancel):
        with pytest.raises(PermissionRejected):
            TOOL.execute(args, context(root, abort=abort))
    if when != "publish":
        assert_unsaved(root)
    else:
        assert len(list((root / ".research/method_comparisons").glob("*/comparison.json"))) == 1


def test_each_call_uses_new_folder_and_never_overwrites_existing_result(request_data):
    root, args, _, _ = request_data
    first = json.loads(TOOL.execute(args, context(root)).output)
    second = json.loads(TOOL.execute(args, context(root)).output)
    assert first["result"] == second["result"]
    assert first["record"]["record_path"] != second["record"]["record_path"]
    path = root / first["record"]["files"][0]["source_path"]
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        comparison.run(args, root, path.parent)
    assert path.read_bytes() == before


@pytest.mark.parametrize("mutation", ["working", "frozen"])
def test_publication_drift_is_not_returned_as_computed_result(request_data, mutation):
    root, args, _, _ = request_data
    original = comparison.records.publish

    def corrupt(*positional, **keywords):
        if mutation == "working":
            (root / keywords["files"][0]).write_text('{"changed":true}', encoding="utf-8")
        saved = original(*positional, **keywords)
        if mutation == "frozen":
            path = records.local_path((root / saved["record_path"]).parent, saved["files"][0]["snapshot"])
            path.write_text('{"changed":true}', encoding="utf-8")
        return saved

    with patch.object(comparison.records, "publish", side_effect=corrupt):
        with pytest.raises((ValueError, RuntimeError), match="hash or bytes|differ from"):
            TOOL.execute(args, context(root))


SAVED_METHODS = [
    ("proxy_values_A_original.json", ("A_original",), "alignment_proxy", 3.1324, "better", [0]),
    ("proxy_values_B_a0.0.json", ("B_mw_exponent", "0.0"), "alignment_proxy", 0.0, "tie", [0, 1, 2]),
    ("proxy_values_B_a0.6.json", ("B_mw_exponent", "0.6"), "alignment_proxy", 6.51, "better", [0]),
    ("proxy_values_C_step10.json", ("C_ea_step", "10.0"), "alignment_proxy", 5.5575, "better", [2]),
    ("proxy_values_C_step30.json", ("C_ea_step", "30.0"), "alignment_proxy", -1.3103, "worse", [1]),
    ("proxy_values_D_calibrated.json", ("D_calibration",), "alignment_calibrated", 4.1721, "better", [2]),
]


@pytest.mark.parametrize("filename,selection,value_field,expected_delta,decision,best_indices", SAVED_METHODS)
def test_saved_six_method_numbers_replayed_without_research_reexecution(
        tmp_path, filename, selection, value_field, expected_delta, decision, best_indices):
    paths = [SOURCE / "records/method_revision_notes.md", SOURCE / "outputs/method_revision_comparison.json",
             SOURCE / "outputs/method_revision_compare" / filename]
    try:
        originals = {path: path.read_bytes() for path in paths}
    except FileNotFoundError as exc:
        pytest.skip(f"Saved real numeric evidence unavailable; no synthetic replacement: {exc}")
    (tmp_path / "method_revision_notes.md").write_bytes(originals[paths[0]])
    (tmp_path / "saved_comparison.json").write_bytes(originals[paths[1]])
    (tmp_path / "saved_baselines.json").write_bytes(originals[paths[2]])
    method = records.publish(tmp_path, kind="formula", title="Saved method notes; offline arithmetic replay only",
                             files=["method_revision_notes.md"], depends_on=[])
    # Explicit test selection of already-saved values. No descriptor, formula or
    # baseline is re-evaluated, and old summary verdicts are not used as inputs.
    baselines = json.loads(originals[paths[2]].decode("utf-8-sig"))
    selected = json.loads(originals[paths[1]].decode("utf-8-sig"))
    for key in selection:
        selected = selected[key]
    candidates = {row["material"]: row[value_field] for row in selected["candidates"]}
    assert len(baselines) == 2 and len(candidates) == 4
    assert not set(baselines) & set(candidates)
    merged = {**baselines, **candidates}
    (tmp_path / "same_method_values.json").write_bytes(records.encoded(merged))
    values = records.publish(tmp_path, kind="implementation", title="Exact saved numeric projection: " + filename,
                             files=["same_method_values.json", "saved_comparison.json", "saved_baselines.json"],
                             depends_on=[method["record_path"]])
    args = {"method_ref": method["record_path"],
            "values": {"record_ref": values["record_path"], "source_path": "same_method_values.json"},
            "baseline_ids": list(baselines), "candidate_ids": list(candidates), "direction": "higher"}
    output = json.loads(TOOL.execute(args, context(tmp_path)).output)["result"]
    assert output["delta"] == pytest.approx(expected_delta, abs=1e-12)
    assert output["comparison"] == decision
    assert output["best_baseline"]["value"] == max(baselines.values())
    assert output["best_candidate"]["ids"] == [list(candidates)[index] for index in best_indices]
    assert output["baselines"] == [{"id": key, "value": value} for key, value in baselines.items()]
    assert output["candidates"] == [{"id": key, "value": value} for key, value in candidates.items()]
    assert {path: path.read_bytes() for path in originals} == originals
