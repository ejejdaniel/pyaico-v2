"""Coefficients set by the measurements and the mechanisms' signs; comparisons under every consistent set."""

import math

import pytest

from researchkit import coefficients as co


def test_enough_samples_set_every_coefficient_and_predictions_are_exact():
    # A yield that rises with temperature: three runs on the line y = 2 + 3 T.
    history = {"r1": {"T": 1.0}, "r2": {"T": 2.0}, "r3": {"T": 4.0}}
    measured = {"r1": 5.0, "r2": 8.0, "r3": 14.0}
    model = co.fit(["T"], {"T": 1}, history, measured)
    bounds = co.coefficients(model)
    assert model.feasible and model.strict
    assert bounds["T"]["determined"] and bounds["T"]["low"] == pytest.approx(3.0)
    assert bounds["offset"]["low"] == pytest.approx(2.0)
    assert co.prediction(model, {"T": 3.0}) == pytest.approx((11.0, 11.0))
    assert co.relation(model, {"T": 3.0}, {"T": 2.0}, "higher") == "better"


def test_signs_the_history_contradicts_leave_no_coefficients_and_the_error_that_would_fit():
    model = co.fit(["dose"], {"dose": 1}, {"a": {"dose": 1.0}, "b": {"dose": 2.0}}, {"a": 5.0, "b": 3.0})
    assert not model.feasible
    assert model.min_noise == pytest.approx(1.0)


def test_declared_noise_turns_a_set_value_into_a_range():
    history = {"r1": {"T": 1.0}, "r2": {"T": 2.0}, "r3": {"T": 4.0}}
    measured = {"r1": 5.0, "r2": 8.0, "r3": 14.0}
    bounds = co.coefficients(co.fit(["T"], {"T": 1}, history, measured, noise=0.5))
    assert not bounds["T"]["determined"]
    assert bounds["T"]["low"] < 3.0 < bounds["T"]["high"]


def test_two_samples_that_changed_two_quantities_bound_one_coefficient_through_the_other_sign():
    # Two batches: more catalyst (raises the rate) and a colder bath (lowers it); the rate fell by 6.
    history = {"b1": {"cat": 1.0, "cold": 0.0}, "b2": {"cat": 1.5, "cold": 2.0}}
    model = co.fit(["cat", "cold"], {"cat": 1, "cold": -1}, history, {"b1": 20.0, "b2": 14.0})
    bounds = co.coefficients(model)
    # The catalyst can only have pushed up, so the cold must explain at least the 6 lost: c_cold <= -3.
    assert bounds["cold"]["high"] == pytest.approx(-3.0)
    assert bounds["cold"]["low"] == -math.inf and bounds["cat"]["high"] == math.inf
    assert bounds["cat"]["low"] == pytest.approx(0.0)
    # More catalyst alone is surely faster, whatever the sizes: the mechanism says its coefficient is positive.
    more = {"cat": 2.0, "cold": 2.0}
    assert co.relation(model, more, history["b2"], "higher") == "better"
    assert co.setting_measurements(model, history, {"more": more}, bounds) == {"cat": ["more"]}


def test_distance_to_a_target_is_compared_under_every_set_and_bands_say_what_is_sure():
    history = {"b1": {"cat": 1.0, "cold": 0.0}, "b2": {"cat": 1.5, "cold": 2.0}}
    model = co.fit(["cat", "cold"], {"cat": 1, "cold": -1}, history, {"b1": 20.0, "b2": 14.0})
    colder = {"cat": 1.5, "cold": 3.5}       # rate <= 9.5
    coldest = {"cat": 1.5, "cold": 6.0}      # rate <= 2
    low, high = co.prediction(model, coldest)
    assert high == pytest.approx(2.0) and low == -math.inf
    assert co.band(low, high, 12.0, 1.0) == "surely_below"
    assert co.band(*co.prediction(model, colder), 12.0, 1.0) == "surely_below"
    assert co.band(*co.prediction(model, {"cat": 1.5, "cold": 2.5}), 12.0, 1.0) == "possibly_in"
    # Toward a target of 12, the smaller step is surely closer than the larger one; b2 itself is 14.
    assert co.relation(model, colder, coldest, "target", 12.0) == "better"
    assert co.relation(model, coldest, colder, "target", 12.0) == "worse"
    assert co.relation(model, history["b2"], {"cat": 1.5, "cold": 2.5}, "target", 12.0) == "undecided"


def test_a_coefficient_the_history_forces_to_zero_is_reported():
    # The KPI did not move although the quantity rose: a positive coefficient has no room.
    model = co.fit(["q"], {"q": 1}, {"a": {"q": 1.0}, "b": {"q": 2.0}}, {"a": 4.0, "b": 4.0})
    assert model.feasible and not model.strict and model.pinned == ["q"]


def test_bad_inputs_are_refused():
    with pytest.raises(co.ModelError, match="every term needs a sign"):
        co.fit(["q"], {"q": 2}, {"a": {"q": 1.0}}, {"a": 1.0})
    with pytest.raises(co.ModelError, match="b has no number for q"):
        co.fit(["q"], {"q": 1}, {"a": {"q": 1.0}, "b": {}}, {"a": 1.0, "b": 2.0})
    with pytest.raises(co.ModelError, match="a has no measured value"):
        co.fit(["q"], {"q": 1}, {"a": {"q": 1.0}}, {})


def test_a_term_whose_mechanism_gives_no_sign_is_bounded_by_the_history_alone():
    # A sign the history contradicts leaves no coefficients; with no sign the history sets the slope.
    history, measured = {"a": {"dose": 1.0}, "b": {"dose": 2.0}}, {"a": 5.0, "b": 3.0}
    assert not co.fit(["dose"], {"dose": 1}, history, measured).feasible
    model = co.fit(["dose"], {"dose": 0}, history, measured)
    assert model.feasible and model.strict and model.pinned == []
    assert co.coefficients(model)["dose"]["low"] == pytest.approx(-2.0)
    # Beside a signed term, the history and that sign bound it on one side only: c_mw = -3 - c_cat / 4.
    two = co.fit(["cat", "mw"], {"cat": 1, "mw": 0}, {"b1": {"cat": 1.0, "mw": 7.0}, "b2": {"cat": 1.5, "mw": 9.0}},
                 {"b1": 20.0, "b2": 14.0})
    bounds = co.coefficients(two)
    assert math.isinf(bounds["mw"]["low"]) and bounds["mw"]["high"] == pytest.approx(-3.0)
    assert bounds["cat"]["low"] == pytest.approx(0.0) and math.isinf(bounds["cat"]["high"])
