"""The model option `seed`, through config loading and offline HTTP encoding.

The local server reuses one fixed seed when none is sent, so a retry of the same input
returned the same reply (LIT v21: four mind-map commissions and their repairs gave one
byte-identical architecture). `"seed": "random"` sends a new seed with every request.
"""

import json
from pathlib import Path
import threading
from types import SimpleNamespace

import httpx
import pytest

from opencode import config as config_module
from opencode import provider as provider_module
from opencode.agent import build_agents
from opencode.config import load_config
from opencode.provider import Client
from researchkit import mindmap

from scripts.llm_configuration import saved_llm_config
from tests import canonical_config as canonical

MODEL = canonical.model_name()
BASE_URL = "https://decoding-seed.invalid/v1"
PROJECT = Path(__file__).resolve().parents[2]


@pytest.fixture
def load(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Seed tests must not use network, catalog, or saved credentials")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(provider_module, "_catalog_temperature", forbidden)
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_PERMISSION",
                 "OPENCODE_DISABLE_PROJECT_CONFIG", "OPENCODE_MODEL"):
        monkeypatch.delenv(name, raising=False)
    global_config, home = tmp_path / "global-config", tmp_path / "home"
    global_config.mkdir()
    home.mkdir()
    monkeypatch.setattr(config_module, "config_dir", lambda: global_config)
    monkeypatch.setattr(config_module, "home", lambda: home)
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(global_config))
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(home))
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-seed-key")
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()  # Stop project config lookup before the real checkout.
    sent = []

    async def receive(transport, request):
        sent.append(json.loads(request.content))
        event = {"choices": [{"delta": {"content": "offline reply"}, "finish_reason": "stop"}]}
        return httpx.Response(200, headers={"content-type": "text/event-stream"},
                              content="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n")

    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", receive)

    def configured(seed):
        config = saved_llm_config(BASE_URL, MODEL)
        options = config["provider"]["local"]["models"][MODEL].setdefault("options", {})
        if seed is None:
            options.pop("seed", None)
        else:
            options["seed"] = seed
        (root / "opencode.json").write_text(json.dumps(config), encoding="utf-8")
        loaded = load_config(root)
        return loaded, Client(SimpleNamespace(get=forbidden), loaded)

    return configured, sent


def _stage_twice(config, client):
    agent = build_agents(config, worktree=Path("."))["build"]
    signal = threading.Event()
    app = SimpleNamespace(provider=client, store=SimpleNamespace(get_session=lambda _: {"model": config["model"]}),
                          abort_event=lambda _: signal)
    ctx = SimpleNamespace(app=app, session_id="offline-session", agent=agent)
    for _ in range(2):
        mindmap._stage(ctx, "architecture", "Offline input.", "Offline instructions.", lambda text: text, frozen={})


def test_random_seed_is_new_for_every_request_of_the_same_input(load):
    configured, sent = load
    _stage_twice(*configured("random"))
    seeds = [body["seed"] for body in sent]
    assert len(seeds) == 2 and all(type(seed) is int and 0 <= seed < 2**31 for seed in seeds)
    assert seeds[0] != seeds[1]
    assert sent[0]["messages"] == sent[1]["messages"]


def test_fixed_seed_is_sent_unchanged_and_no_seed_sends_none(load):
    configured, sent = load
    _stage_twice(*configured(7))
    assert [body["seed"] for body in sent] == [7, 7]
    sent.clear()
    _stage_twice(*configured(None))
    assert all("seed" not in body for body in sent)


def test_the_default_config_runs_at_temperature_one_with_a_new_seed_per_request():
    # The project lead's decision (2026-10-25, made the default 2026-10-31): at temperature 0 a repeated
    # call was the model's only choice (v9; Q1 through the entry sent one command five times).
    config = json.loads((PROJECT / "config/llm.opencode.json").read_text(encoding="utf-8"))
    assert {name: config["agent"][name]["temperature"] for name in ("build", "plan", "general", "explore")} == {
        "build": 1.0, "plan": 1.0, "general": 1.0, "explore": 1.0}
    provider, model = config["model"].split("/", 1)
    assert config["provider"][provider]["models"][model]["options"]["seed"] == "random"
