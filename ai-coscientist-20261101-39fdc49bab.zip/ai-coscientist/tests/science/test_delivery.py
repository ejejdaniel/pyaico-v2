"""research_deliver and the host's report checks: one review of the draft, answers instead of a second review; no model calls."""

from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import board, delivery, records, report_checks
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install

CLOCK = [1_700_000_000]


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    saved = records.publish(root, kind=kind, title=kind, files=list(files),
                            depends_on=[ref["record_path"] for ref in depends_on])
    CLOCK[0] += 1
    os.utime(root / saved["record_path"], (CLOCK[0], CLOCK[0]))
    return saved


def check(report, quote, decision, reason, source):
    return {"subject": {"record_ref": report["record_path"], "source_path": "draft/report.md", "quote": quote},
            "evidence": [{"record_ref": source["record_path"], "source_path": "source.txt",
                          "quote": "The observation."}],
            "decision": decision, "reason": reason}


@pytest.fixture
def study(tmp_path):
    source = save(tmp_path, "notes", {"source.txt": "The observation.\n"})
    draft = save(tmp_path, "report", {"draft/report.md": "The claim.\nE3 is a robust surpass.\n"}, [source])
    review = save(tmp_path, "review", {"r/review.json": {"reviewed_refs": [draft["record_path"]], "checks": [
        check(draft, "The claim.", "supported", "Matches the observation.", source),
        check(draft, "E3 is a robust surpass.", "unsupported", "Under the declared noise it is conditional.", source),
    ]}}, [draft, source])
    delivered = save(tmp_path, "report", {"final/report.md": "The claim.\nE3 is a conditional surpass under noise.\n",
                                          "final/report.html": "<p>rendered</p>"}, [draft])
    return tmp_path, source, draft, review, delivered


def args(delivered, review, answers=()):
    return {"report_ref": delivered["record_path"], "review_refs": [review["record_path"]], "decision": "released",
            "scope": "A proxy study; no new formulation was measured.", "answers": list(answers)}


def test_the_plain_notes_copy_goes_with_the_delivery_and_never_stops_it(study):
    # The person asked (2026-11-01) for plain-spoken notes on the delivered report: a reading copy beside it.
    root, _, _, review, delivered = study
    answer = {"review_ref": review["record_path"], "check": 2, "action": "revised", "note": "Now conditional.",
              "quote": "E3 is a conditional surpass under noise."}
    seen = []

    def annotate(markdown, folder, avoid):
        seen.append(markdown)
        assert avoid == []  # the unsupported claim was revised out of the delivered report
        (folder / "notes").mkdir()
        for name in ("report.html", "report.pdf"):
            (folder / "notes" / name).write_text("copy", encoding="utf-8")
        return {"asked": 2, "placed": 1, "unplaced": 1, "dropped_for_numbers": 0,
                "html_path": str(folder / "notes" / "report.html"), "pdf_path": str(folder / "notes" / "report.pdf")}

    out = delivery.deliver(args(delivered, review, [answer]), root, root / ".research/deliveries/p", annotate=annotate)
    assert [text.splitlines() for text in seen] == [["The claim.", "E3 is a conditional surpass under noise."]]
    assert out["delivery_issues"] == []
    assert out["plain_notes"]["html_path"] == ".research/deliveries/p/notes/report.html"
    user = records.read_record(root, out["user_report"]["record_path"])
    assert [item["source_path"] for item in user["files"]] == [
        ".research/deliveries/p/delivery.md", ".research/deliveries/p/notes/report.html",
        ".research/deliveries/p/notes/report.pdf"]
    text = (root / ".research/deliveries/p/delivery.md").read_text(encoding="utf-8")
    assert "- 白話註記版：`.research/deliveries/p/notes/report.html`" in text and "1 則註記" in text
    # A failed copy is named, and the delivery stands without it.
    out = delivery.deliver(args(delivered, review, [answer]), root, root / ".research/deliveries/q",
                           annotate=lambda markdown, folder, avoid: {"error": "ProviderError: no model"})
    user = records.read_record(root, out["user_report"]["record_path"])
    assert out["delivery_issues"] == [] and len(user["files"]) == 1
    assert "- 白話註記版：未產生（ProviderError: no model）" in (
        root / ".research/deliveries/q/delivery.md").read_text(encoding="utf-8")


def test_a_revised_report_is_delivered_on_its_draft_review_by_answering_what_was_not_supported(study):
    root, _, draft, review, delivered = study
    with pytest.raises(ValueError, match=r"check 2 \(unsupported\) is unanswered: E3 is a robust surpass\.") as refused:
        delivery.deliver(args(delivered, review), root, root / ".research/deliveries/a")
    assert "nothing was saved" in str(refused.value) and not (root / ".research/deliveries/a").exists()
    answer = {"review_ref": review["record_path"], "check": 2, "action": "revised", "note": "Now conditional."}
    with pytest.raises(ValueError, match="is not in final/report.md of the delivered report") as refused:
        delivery.deliver(args(delivered, review, [{**answer, "quote": "E3 is a robust surpass."}]), root,
                         root / ".research/deliveries/b")
    # Each refusal says what the check is about, so the passage can be found without opening the review.
    assert "the check is about: E3 is a robust surpass." in str(refused.value)
    with pytest.raises(ValueError, match=r"needs quote: .* \(the check is about: E3 is a robust surpass\.\)"):
        delivery.deliver(args(delivered, review, [answer]), root, root / ".research/deliveries/b")
    out = delivery.deliver(args(delivered, review, [{**answer, "quote": "E3 is a conditional surpass under noise."}]),
                           root, root / ".research/deliveries/c")
    assert out["delivery_issues"] == [] and out["report_revised_after_review"] and out["supported_checks"] == 1
    # v38 kept working for eight minutes after a clean delivery; the receipt now says it is done.
    assert out["next"].startswith("The delivery is complete.")
    lca = records.read_record(root, out["final_lca"]["record_path"])
    assert lca["depends_on"] == [delivered["record_path"], review["record_path"]]
    user = records.read_record(root, out["user_report"]["record_path"])
    assert user["depends_on"] == [delivered["record_path"], out["final_lca"]["record_path"]]
    value = json.loads((root / ".research/deliveries/c/final_lca.json").read_text(encoding="utf-8"))
    item, = value["items"]
    assert item["check"] == 2 and item["decision"] == "unsupported" and item["action"] == "revised"
    assert value["reviews"][0]["reviewed_report"] == draft["record_path"]
    # No board notice asks for a second review or a Final-LCA of a reviewed version.
    texts = [entry["text"] for entry in board.open_actions(board.build(root))]
    assert not any("審查" in text or "final_lca" in text for text in texts)


def test_a_review_of_another_report_does_not_cover_the_delivery(study):
    root, source, _, review, _ = study
    other = save(root, "report", {"other/report.md": "Something else.\n"}, [source])
    with pytest.raises(ValueError, match="neither report .* nor an earlier report record it depends on"):
        delivery.deliver(args(other, review), root, root / ".research/deliveries/x")


def test_a_hand_written_final_lca_still_needs_the_review_of_its_own_version(study):
    root, _, _, review, delivered = study
    lca = save(root, "final_lca", {"lca/final_lca.md": "released"}, [delivered, review])
    user = save(root, "user_report", {"u/delivery.md": "delivered"}, [delivered, lca])
    assert any("lacks a saved review" in issue for issue in records.delivery_issues(root, user["record_path"]))


def test_the_delivery_selected_by_research_deliver_is_the_session_delivery():
    receipt = {"final_lca": {"record_path": ".research/records/" + "a" * 64 + "/record.json", "kind": "final_lca"},
               "user_report": {"record_path": ".research/records/" + "b" * 64 + "/record.json", "kind": "user_report"}}
    history = [{"role": "assistant", "tool_calls": [{"id": "d1", "name": "research_deliver", "arguments": {}}]},
               {"role": "tool", "name": "research_deliver", "tool_call_id": "d1",
                "content": json.dumps(receipt) + "\n\nHost note: resolved a reference."}]
    assert records.selected_delivery(history) == receipt["user_report"]["record_path"]


@pytest.fixture
def pool(tmp_path):
    save(tmp_path, "leaderboard", {"lb/leaderboard.json": {
        "sheets": [{"values": {"S1": 48.674, "E1": 41.951, "E3": 41.951}},
                   {"values": {"S1": 4.649, "E1": 4.66, "E3": 4.532}}],
        "candidates": [{"id": "E3", "verdict": "robust_surpass", "margins": {"P1": {"better_by": 6.723}}},
                       {"id": "E1", "verdict": "tradeoff_surpass", "margins": {}}]}})
    save(tmp_path, "calc", {"calc/noise.json": {"calc": {"kind": "sensitivity"}, "result": {"candidates": {
        "E3": {"verdicts": {"conditional_surpass": 1.0}}}}}})
    return tmp_path


def test_report_verdicts_and_table_numbers_are_compared_with_the_records(pool):
    # v23 called E3 a robust surpass; its own noise check gave that verdict 0% of the draws.
    text = "\n".join([
        "E3 為 `robust_surpass`。",           # 1: the noise check disagrees
        "E1 是穩健超越。",                      # 2: the leaderboard says tradeoff
        "E1 為 tradeoff_surpass。",             # 3: agrees
        "| E3 | 41.951 | 6.723 | 40.123 |",     # 4: 40.123 is none of E3's values or margins
        "| S1 | 53.7 | 48.674 |",               # 5: a historical row; measured values are left alone
        "| E1 | 41.951 | 4.66 |",               # 6: agrees
    ])
    found = report_checks.check(pool, text)
    assert [item["line"] for item in found] == [1, 2, 4]
    assert "只有 0% 的抽樣是 robust_surpass" in found[0]["text"]
    assert "E1 寫成 robust_surpass，排行榜" in found[1]["text"] and "判定是 tradeoff_surpass" in found[1]["text"]
    assert "40.123" in found[2]["text"] and "41.951" not in found[2]["text"]
    assert [item["id"] for item in found] == ["host#1", "host#2", "host#3"]


def test_ranks_in_prose_and_a_mechanism_chapter_without_relations_are_found(tmp_path):
    # A reviewer without the leaderboards called a run's ranks unassessed and the run reviewed five more times
    # (2026-11-01); another wrote its mechanism chapter in words only. The host compares and counts instead.
    save(tmp_path, "leaderboard", {"lb/leaderboard.json": {
        "sheets": [{"values": {"S1": 48.674, "E3": 41.951}, "ranks": {"S1": 2, "E3": 1}},
                   {"values": {"S1": 4.649, "E3": 4.532}, "ranks": {"S1": 2.5, "E3": 1}}],
        "candidates": [{"id": "E3", "verdict": "tradeoff_surpass", "mean_rank": 1.125}]}})
    text = "\n".join([
        "## 2. 機制：從輸入到指標",
        "酸越多，劑量越低。",
        "## 3. 證據",
        "E3 的平均名次 1.125，第二張表名次為 1。",   # 4: agrees
        "E3 的平均名次 9.375。",                    # 5: none of E3's ranks
        "S1 與 E3 的名次為 2。",                     # 6: two samples named: not judged
        "| E3 | 41.951 | 1.125 |",                  # 7: a mean rank in a table is one of its values
    ])
    found = report_checks.check(tmp_path, text)
    assert [item["line"] for item in found] == [1, 5]
    assert "機制章沒有任何關係式" in found[0]["text"]
    assert "E3 的名次寫成 9.375" in found[1]["text"] and "平均名次是 1.125" in found[1]["text"]
    # One equation in the chapter is enough; a report without the reader layout is not asked for one.
    with_relation = text.replace("酸越多，劑量越低。", "$E \\propto 1/Y$：酸越多，劑量越低。")
    assert [item["line"] for item in report_checks.check(tmp_path, with_relation)] == [5]
    assert [item["line"] for item in report_checks.check(tmp_path, text.replace("## 2. 機制", "## 2. 背景"))] == [5]


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def test_saving_a_report_shows_the_host_checks_and_delivery_asks_for_their_answers(ctx):
    root = ctx.directory
    save(root, "calc", {"calc/noise.json": {"calc": {"kind": "sensitivity"}, "result": {"candidates": {
        "E3": {"verdicts": {"conditional_surpass": 1.0}}}}}})
    save(root, "leaderboard", {"lb/leaderboard.json": {"sheets": [{"values": {"S1": 48.7, "E3": 41.951}}],
                                                       "candidates": [{"id": "E3", "verdict": "robust_surpass"}]}})
    source = save(root, "notes", {"source.txt": "The observation.\n"})
    (root / "report.md").write_text("The claim.\nE3 為 robust_surpass。\n", encoding="utf-8")
    tool = {t.name: t for t in TOOLS}
    receipt = json.loads(tool["research_record"].execute({"kind": "report", "title": "draft", "files": ["report.md"],
                                                          "depends_on": [source["record_path"]]}, ctx).output)
    assert len(receipt["report_checks"]) == 1 and "report.md: 第 2 行把 E3 寫成 robust_surpass" in receipt["report_checks"][0]
    review = save(root, "review", {"r/review.json": {"reviewed_refs": [receipt["record_path"]], "checks": [{
        "subject": {"record_ref": receipt["record_path"], "source_path": "report.md", "quote": "The claim."},
        "evidence": [{"record_ref": source["record_path"], "source_path": "source.txt", "quote": "The observation."}],
        "decision": "supported", "reason": "Matches."}]}}, [{"record_path": receipt["record_path"]}, source])
    request = {"report_ref": receipt["record_path"], "review_refs": [review["record_path"]],
               "decision": "bounded-reject", "scope": "Proxy only."}
    # v30 ranked candidates on five leaderboards and delivered without saying what its rounds were.
    with pytest.raises(ValueError, match="no sample_evolution record declares the rounds"):
        tool["research_deliver"].execute(request, ctx)
    save(root, "sample_evolution", {"evo/evolution.json": {"rounds": [{"round": 1, "candidate_ids": ["E3"]}]}})
    with pytest.raises(ValueError, match="host check 1 is unanswered"):
        tool["research_deliver"].execute(request, ctx)
    answer = {"host": 1, "action": "disputed", "note": "Kept as the nominal verdict; the noise result is stated."}
    out = json.loads(tool["research_deliver"].execute({**request, "answers": [answer]}, ctx).output)
    assert out["delivery_issues"] == [] and out["answered"] == 1


def test_the_review_summary_lists_the_checks_to_answer_and_the_next_step():
    # v25's full reviews (about 35 KB) were cut by the output limit together with the note on how to deliver.
    from researchkit import reviewer
    subject = {"record_ref": "r", "source_path": "docs/report.md", "quote": "E3 is a robust surpass."}
    review = {"reviewed_refs": ["r"], "checks": [
        {"subject": subject, "evidence": [], "decision": "supported", "reason": "fine"},
        {"subject": subject, "evidence": [], "decision": "contradicted", "reason": "Noise gives 0%."},
        {"subject": subject, "evidence": [], "decision": "unassessed", "reason": "The leaderboard was not selected."}]}
    meta = {"review_record": ".research/records/" + "c" * 64 + "/record.json", "review_file": "runs/x/final/review.json"}
    text = reviewer.summary(json.dumps(review), meta)
    assert text.startswith(f"Review saved as review record {meta['review_record']}; the full review")
    assert "3 checks: supported 1, contradicted 1, unassessed 1." in text
    assert '- check 2 (contradicted) on docs/report.md: "E3 is a robust surpass."' in text and "check 1 (" not in text
    assert "unassessed means the reviewer lacked the evidence" in text
    assert "A revised report needs no second review" in text
    clean = reviewer.summary(json.dumps({**review, "checks": review["checks"][:1]}), meta)
    assert "Every check is supported" in clean and "Checks to answer" not in clean


def test_a_wrong_file_in_a_review_lists_the_record_files(ctx):
    root = ctx.directory
    (root / "docs").mkdir()
    (root / "docs/report.md").write_text("The claim.\n", encoding="utf-8")
    report = save(root, "report", {"docs/report.md": "The claim.\n"})
    tool = {t.name: t for t in TOOLS}["research_review"]
    with pytest.raises(ValueError, match=r"That record's files: docs/report\.md"):
        tool.execute({"scope": "Check the claim.", "reviewed_refs": [report["record_path"]],
                      "files": [{"record_ref": report["record_path"], "source_path": "report.md"}]}, ctx)


def test_a_review_names_every_wrong_file_and_quote_at_once(ctx):
    # LIT (2026-11-01): 5 of 15 files named the wrong record and each refusal named one. A quote added to the
    # report after it was saved was refused twice without saying which quote or why.
    root = ctx.directory
    report = save(root, "report", {"docs/report.md": "The claim.\n"})
    notes = save(root, "notes", {"docs/notes.md": "A note.\n"})
    (root / "docs/report.md").write_text("The claim.\nAdded after saving.\n", encoding="utf-8")
    tool = {t.name: t for t in TOOLS}["research_review"]
    with pytest.raises(ValueError) as refused:
        tool.execute({"scope": "Check the claim.", "reviewed_refs": [report["record_path"], notes["record_path"]],
                      "files": [{"record_ref": report["record_path"], "source_path": "docs/report.md"},
                                {"record_ref": report["record_path"], "source_path": "report.md"},
                                {"record_ref": notes["record_path"], "source_path": "notes.md"}],
                      "required_subjects": [{"record_ref": report["record_path"], "source_path": "docs/report.md",
                                             "quote": "Added after saving."}]}, ctx)
    text = str(refused.value)
    assert text.startswith("3 problems, all of them listed so one revision fixes them:")
    assert "That record's files: docs/report.md" in text and "That record's files: docs/notes.md" in text
    assert '"Added after saving."' in text
    assert "The working file docs/report.md has it, but this record's saved copy does not" in text


def test_a_review_request_names_every_problem_at_once(ctx):
    # Runs (2026-11-01) were refused once per problem, two or three times in a row.
    root = ctx.directory
    report = save(root, "report", {"docs/report.md": "The claim.\n"})
    notes = save(root, "notes", {"docs/notes.md": "A note.\n"})
    tool = {t.name: t for t in TOOLS}["research_review"]
    with pytest.raises(ValueError) as refused:
        tool.execute({"scope": "Check the claim.",
                      "reviewed_refs": [report["record_path"], notes["record_path"], "../report.md"],
                      "files": [{"record_ref": report["record_path"], "source_path": "docs/report.md"}],
                      "commission_files": [{"record_ref": notes["record_path"], "source_path": "docs/notes.md"}]}, ctx)
    text = str(refused.value)
    assert text.startswith("3 problems, all of them listed so one revision fixes them:")
    assert "'../report.md': Expected an exact relative" in text and "save it with research_record" in text
    assert f"none is selected for {notes['record_path']}" in text
    assert "commission_files must refer to a selected file" in text


def test_a_review_of_no_report_says_to_review_the_report(study):
    # A run (2026-11-01) reviewed its records before writing the report, then made the report depend on them.
    root, source, _, _, delivered = study
    observed = {"record_ref": source["record_path"], "source_path": "source.txt", "quote": "The observation."}
    review = save(root, "review", {"r2/review.json": {"reviewed_refs": [source["record_path"]], "checks": [
        {"subject": observed, "evidence": [observed], "decision": "supported", "reason": "It is stated."}]}},
                  [source])
    with pytest.raises(ValueError, match=r"reviewed no report: it reviewed notes .*run research_review on this report"):
        delivery.deliver(args(delivered, review), root, root / ".research/deliveries/n")


def test_answers_numbered_from_zero_are_refused_with_what_each_number_names(study):
    # LIT (2026-11-01) counted review.json's checks from 0, so every answer named the check before the one it
    # was written for; the answers that landed on other unsupported checks were delivered.
    root, _, _, review, delivered = study
    ref = review["record_path"]
    shifted = [{"review_ref": ref, "check": 0, "action": "disputed", "note": "Written for the first check."},
               {"review_ref": ref, "check": 1, "action": "revised", "note": "Written for the second check.",
                "quote": "E3 is a conditional surpass under noise."}]
    with pytest.raises(ValueError) as refused:
        delivery.deliver(args(delivered, review, shifted), root, root / ".research/deliveries/a")
    text = str(refused.value)
    # Every problem in the one refusal, and the rule once at the end.
    assert "has checks 1 to 2, not 0" in text
    assert "check 1 is supported and needs no answer; it is about: The claim." in text
    assert "check 2 (unsupported) is unanswered" in text
    assert text.endswith(delivery.NUMBERING + ".") and text.count(delivery.NUMBERING) == 1
    assert not (root / ".research/deliveries/a").exists()
    # A refusal with nothing misnumbered does not carry the rule.
    with pytest.raises(ValueError) as refused:
        delivery.deliver(args(delivered, review), root, root / ".research/deliveries/a")
    assert delivery.NUMBERING not in str(refused.value)


def test_a_report_record_with_notes_beside_the_report_delivers_its_report_markdown(study):
    root, _, draft, review, _ = study
    # v38's report record also held its literature notes, and the first delivery asked which Markdown it was.
    delivered = save(root, "report", {"final/report.md": "The claim.\nE3 is a conditional surpass under noise.\n",
                                      "final/literature.md": "Notes on sources.\n",
                                      "final/report.html": "<p>rendered</p>"}, [draft])
    answer = {"review_ref": review["record_path"], "check": 2, "action": "revised", "note": "Now conditional.",
              "quote": "E3 is a conditional surpass under noise."}
    out = delivery.deliver(args(delivered, review, [answer]), root, root / ".research/deliveries/notes")
    assert out["delivery_issues"] == []
    lca = json.loads((root / ".research/deliveries/notes/final_lca.json").read_text(encoding="utf-8"))
    assert lca["markdown"] == "final/report.md"
