"""Delivery boundaries, not simulated proof of scientific judgment quality."""

import json
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from researchkit import records
from scripts.setup_research_workspace import install
from tests.prompt_view import host_facts, plain_messages


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()
    install(root)
    store = Store(tmp_path / "session.db")
    app = App(root, store=store, auto_approve=True, config={})
    app.generate_titles = False
    session = app.create_session()["id"]
    yield root, app, session
    store.close()


def record(root, kind, name, text, deps=()):
    (root / name).write_text(text, encoding="utf-8")
    return records.publish(root, kind=kind, title=name, files=[name], depends_on=list(deps))


def review_file(root, report, *, evidence=(), decision="unassessed"):
    source = report["files"][0]["source_path"]
    quote = (root / report["record_path"]).parent.joinpath(report["files"][0]["snapshot"]).read_text(encoding="utf-8")
    value = {"reviewed_refs": [report["record_path"]], "checks": [{
        "subject": {"record_ref": report["record_path"], "source_path": source, "quote": quote},
        "evidence": list(evidence), "decision": decision,
        "reason": "Numerical identity does not establish changed source support; this claim remains unassessed.",
    }]}
    (root / "review.json").write_bytes(records.encoded(value))
    return value


def chain(root):
    old = record(root, "report", "old.md", "Value 1. Interpretation supported by source A.")
    review_file(root, old)
    review = records.publish(root, kind="review", title="Old review", files=["review.json"], depends_on=[old["record_path"]])
    lca = record(root, "final_lca", "old-lca.md", "Old limited release.", [old["record_path"], review["record_path"]])
    new = record(root, "report", "new.md", "Value 1. Interpretation supported by source B.")
    user = record(root, "user_report", "old-user.md", "Delivery of revised report.", [new["record_path"], lca["record_path"]])
    return old, review, lca, new, user


def select(app, session, saved, call_id="selected"):
    app.store.add_message(session, "assistant", {"tool_calls": [{
        "id": call_id, "name": "research_record", "arguments": {"kind": saved["kind"]}}]})
    app.store.add_message(session, "tool", {
        "tool_call_id": call_id, "name": "research_record", "content": json.dumps(saved)})


def mock_model(app, handler):
    calls = []

    def complete(**kwargs):
        calls.append(kwargs)
        return handler(len(calls), kwargs)

    app.provider = SimpleNamespace(
        resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"), complete=complete)
    return calls


def repaired(root, old_review, new):
    review_file(root, new)
    review = records.publish(root, kind="review", title="New bounded review", files=["review.json"],
                             depends_on=[new["record_path"], old_review["record_path"]])
    lca = record(root, "final_lca", "new-lca.md", "Numerical result retained; interpretation remains unassessed.",
                 [new["record_path"], review["record_path"]])
    user = record(root, "user_report", "new-user.md", "Bounded study delivered; source support unresolved.",
                  [new["record_path"], lca["record_path"]])
    return review, lca, user


def test_saved_scope_not_prose_or_dependency_presence(case):
    root, _, _ = case
    old, old_review, _, new, user = chain(root)
    assert records.delivery_issues(root, user["record_path"])
    review_file(root, old)
    wrong = records.publish(root, kind="review", title="Has new dependency but reviews old", files=["review.json"],
                            depends_on=[old["record_path"], new["record_path"]])
    lca = record(root, "final_lca", "wrong-lca.md", "All complete.", [new["record_path"], wrong["record_path"]])
    delivery = record(root, "user_report", "wrong-user.md", "All complete.", [new["record_path"], lca["record_path"]])
    assert any("reviewed_refs" in item for item in records.delivery_issues(root, delivery["record_path"]))
    before = {p: p.read_bytes() for p in (root / ".research").rglob("*") if p.is_file()}
    _, _, fixed = repaired(root, old_review, new)
    assert records.delivery_issues(root, fixed["record_path"]) == []
    assert all(p.read_bytes() == contents for p, contents in before.items())
    assert records.delivery_issues(root, user["record_path"])


def test_each_delivered_report_needs_its_own_coverage(case):
    root, _, _ = case
    _, review, _, new, _ = chain(root)
    _, lca, _ = repaired(root, review, new)
    another = record(root, "report", "another.md", "Another claim.")
    delivery = record(root, "user_report", "many.md", "Deliver both.",
                      [new["record_path"], another["record_path"], lca["record_path"]])
    issues = records.delivery_issues(root, delivery["record_path"])
    assert any(another["record_path"] in item for item in issues)


def test_selected_lca_cannot_silently_use_a_different_report(case):
    root, _, _ = case
    _, review, old_lca, new, _ = chain(root)
    _, lca, _ = repaired(root, review, new)
    mixed = record(root, "user_report", "mixed.md", "Deliver.",
                   [new["record_path"], old_lca["record_path"], lca["record_path"]])
    assert any(old_lca["record_path"] in issue for issue in records.delivery_issues(root, mixed["record_path"]))


def test_failed_calls_and_other_sessions_do_not_select_a_delivery(case):
    root, app, session = case
    _, review, _, new, old_user = chain(root)
    select(app, session, old_user)
    _, _, fixed = repaired(root, review, new)
    app.store.add_message(session, "assistant", {"tool_calls": [{
        "id": "failed", "name": "research_record", "arguments": {"kind": "user_report"}}]})
    app.store.add_message(session, "tool", {"tool_call_id": "failed", "name": "research_record", "content": "Error: rejected"})
    app.store.add_message(session, "assistant", {"content": "I select " + fixed["record_path"]})
    other = app.create_session()["id"]
    select(app, other, fixed)
    assert records.selected_delivery(app.store.messages(session)) == old_user["record_path"]
    assert records.selected_delivery(app.store.messages(other)) == fixed["record_path"]
    reloaded = Store(app.store.path)
    try:
        assert records.selected_delivery(reloaded.messages(session)) == old_user["record_path"]
    finally:
        reloaded.close()


def test_no_progress_after_notice_does_not_loop_or_claim_saved_review(case):
    root, app, session = case
    _, _, _, _, user = chain(root)
    select(app, session, user)

    def answer(n, _):
        if n == 1:
            select(app, session, user, "current-delivery")
        return Completion(text="All complete; I judged compatibility.", finish_reason='stop')

    calls = mock_model(app, answer)
    result = app.prompt(session, "Continue the commissioned study.")
    assert len(calls) == 2
    assert all(call["tools"] for call in calls)
    assert "科研交付尚未接妥" in result["text"]
    assert len(records.inventory(root)) == 5


def test_same_agent_saves_review_lca_delivery_and_then_exits(case):
    root, app, session = case
    _, old_review, _, new, user = chain(root)
    select(app, session, user)
    before = {p: p.read_bytes() for p in (root / ".research").rglob("*") if p.is_file()}
    review_file(root, new)
    (root / "new-lca.md").write_text("Changed interpretation unassessed; numeric evidence retained.", encoding="utf-8")
    (root / "new-user.md").write_text("Deliver the bounded review, not unsupported certainty.", encoding="utf-8")

    def answer(n, kwargs):
        if n == 1:
            select(app, session, user, "current-delivery")
            return Completion(text="Finished the assessment.", finish_reason='stop')
        if n == 2:
            notice = plain_messages(kwargs["messages"])[-1]["content"]
            assert "final-lca/SKILL.md" in notice  # Conditional guidance, not a fixed re-publication sequence.
            assert new["record_path"] in notice
            assert "用 research_record 保存新 review，再保存" not in notice
            args = {"kind": "review", "title": "Revised review", "files": ["review.json"],
                    "depends_on": [new["record_path"], old_review["record_path"]]}
        elif n == 3:
            reviewed = json.loads(plain_messages(kwargs["messages"])[-1]["content"].split("Returned content:\n", 1)[-1])
            args = {"kind": "final_lca", "title": "Revised judgment", "files": ["new-lca.md"],
                    "depends_on": [new["record_path"], reviewed["record_path"]]}
        elif n == 4:
            judged = json.loads(plain_messages(kwargs["messages"])[-1]["content"].split("Returned content:\n", 1)[-1])
            args = {"kind": "user_report", "title": "Revised delivery", "files": ["new-user.md"],
                    "depends_on": [new["record_path"], judged["record_path"]]}
        else:
            assert n == 5
            return Completion(text="Saved and delivered, with stated limitations.", finish_reason='stop')
        return Completion(tool_calls=[ToolCall(f"call-{n}", "research_record", args)], finish_reason='tool-calls')

    calls = mock_model(app, answer)
    result = app.prompt(session, "Continue the commissioned study.")
    assert len(calls) == 5
    assert all(call["tools"] for call in calls)
    assert "科研交付尚未接妥" not in result["text"]
    selected = records.selected_delivery(app.store.messages(session))
    assert selected != user["record_path"]
    assert records.delivery_issues(root, selected) == []
    assert len(records.inventory(root)) == 8
    assert all(p.read_bytes() == data for p, data in before.items())
    calls = mock_model(app, lambda *_: Completion(text="The saved bounded review is available.", finish_reason='stop'))
    app.prompt(session, "Where is the saved review?")
    assert len(calls) == 1  # Old mismatches are still on disk, not reopened.


@pytest.mark.parametrize("mode", ["aborted", "last_step"])
def test_abort_or_model_obeying_maxsteps_adds_no_repair_call(case, mode):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)
    app.agents["build"].steps = 1

    def answer(_, kwargs):
        # Upstream prompt.ts adds MAX_STEPS; it does not force a step_limit exit.
        assert "MAXIMUM STEPS REACHED" in plain_messages(kwargs["messages"])[-1]["content"]
        if mode == "aborted":
            app.abort_event(session).set()
        return Completion(text="Done.", finish_reason='stop')

    calls = mock_model(app, answer)
    result = app.prompt(session, "Continue.")
    assert len(calls) == 1
    assert ("科研交付尚未接妥" if mode == "last_step" else "本輪已停止") in result["text"]
    if mode != "last_step":
        assert result["status"] == mode
    else:
        assert result["status"] == "completed"


def test_no_selected_delivery_does_not_turn_ordinary_chat_into_research(case):
    root, app, session = case
    chain(root)
    calls = mock_model(app, lambda *_: Completion(text="Hello.", finish_reason='stop'))
    result = app.prompt(session, "Hello.")
    assert len(calls) == 1
    assert "科研交付尚未接妥" not in result["text"]


def test_corrupt_saved_chain_cannot_be_accepted(case):
    root, _, _ = case
    _, review, _, new, _ = chain(root)
    fixed_review, _, user = repaired(root, review, new)
    snapshot = (root / fixed_review["record_path"]).parent / fixed_review["files"][0]["snapshot"]
    snapshot.write_text("tampered", encoding="utf-8")
    assert any("Cannot verify" in issue for issue in records.delivery_issues(root, user["record_path"]))


def test_saved_review_and_lca_need_only_delivery_correction(case):
    root, app, session = case
    _, old_review, _, new, user = chain(root)
    select(app, session, user)
    review, lca, _ = repaired(root, old_review, new)
    select(app, session, review, "saved-review")
    select(app, session, lca, "saved-lca")
    wrong_kind = records.publish(root, kind="report", title="Delivery saved with wrong kind",
                                 files=["new-user.md"], depends_on=[new["record_path"], lca["record_path"]])
    select(app, session, wrong_kind, "wrong-kind")
    assert records.selected_delivery(app.store.messages(session)) == user["record_path"]
    before = {p: p.read_bytes() for p in (root / ".research").rglob("*") if p.is_file()}
    publications = []

    def answer(n, kwargs):
        if n == 1:
            assert review["record_path"] in host_facts(kwargs)
            assert lca["record_path"] in host_facts(kwargs)
            tool = next(t for t in kwargs["tools"] if t["name"] == "research_record")
            assert "Only a successful kind=user_report" in tool["description"]
            select(app, session, user, "current-delivery")
            return Completion(text="Everything has been saved.", finish_reason='stop')
        if n == 2:
            notice = plain_messages(kwargs["messages"])[-1]["content"]
            assert review["record_path"] in host_facts(kwargs) and lca["record_path"] in host_facts(kwargs)
            assert f"report `{wrong_kind['record_path']}`" in host_facts(kwargs)
            assert wrong_kind["record_path"] not in notice  # No second copy of the progress index.
            assert "用 research_record 保存新 review，再保存" not in notice
            args = {"kind": "user_report", "title": "Correct delivery binding", "files": ["new-user.md"],
                    "depends_on": [new["record_path"], lca["record_path"]]}
            publications.append(args)
            return Completion(tool_calls=[ToolCall("delivery-only", "research_record", args)], finish_reason='tool-calls')
        assert n == 3
        selected = records.selected_delivery(app.store.messages(session))
        assert selected != user["record_path"] and selected in host_facts(kwargs)
        return Completion(text="The existing review and judgment are now attached to the delivery.", finish_reason='stop')

    calls = mock_model(app, answer)
    result = app.prompt(session, "Continue the original study, preserving completed work.")
    assert len(calls) == 3 and [p["kind"] for p in publications] == ["user_report"]
    assert "科研交付尚未接妥" not in result["text"]
    assert all(p.read_bytes() == data for p, data in before.items())
    assert len(records.inventory(root)) == 10


def test_progress_rebuilt_after_restart_does_not_trust_summary_or_other_sessions(case):
    root, app, session = case
    _, old_review, _, new, user = chain(root)
    select(app, session, user)
    review, lca, other_delivery = repaired(root, old_review, new)
    select(app, session, review, "review")
    select(app, session, lca, "lca")
    other = app.create_session()["id"]
    select(app, other, other_delivery, "other")
    app.store.add_message(session, "assistant", {"content": "Everything is complete. " + other_delivery["record_path"]})
    app.store.add_message(session, "assistant", {"tool_calls": [{
        "id": "failed-new", "name": "research_record", "arguments": {"kind": "user_report"}}]})
    app.store.add_message(session, "tool", {"name": "research_record", "tool_call_id": "failed-new", "content": "Error: failed"})
    last = app.store.messages(session)[-1]
    app.store.commit_compaction(session, last["id"], "The previous account says everything is complete.")
    reloaded = Store(app.store.path)
    try:
        context = reloaded.context_messages(session)
        assert review["record_path"] not in json.dumps(context)
        progress = records.delivery_progress(root, reloaded.messages(session))
        assert review["record_path"] in progress and lca["record_path"] in progress
        assert other_delivery["record_path"] not in progress
        assert user["record_path"] in progress
        assert "review.json.reviewed_refs" in progress
    finally:
        reloaded.close()

    def answer(n, kwargs):
        assert review["record_path"] in host_facts(kwargs) and lca["record_path"] in host_facts(kwargs)
        # message-v2.ts emits the saved summary as ordinary assistant content.
        assert {"role": "assistant", "content": "The previous account says everything is complete."} in kwargs["messages"]
        if n == 1:
            select(app, session, user, "current-delivery")
        return Completion(text="Still working on delivery.", finish_reason='stop')

    calls = mock_model(app, answer)
    result = app.prompt(session, "Continue.")
    assert len(calls) == 2
    assert "科研交付尚未接妥" in result["text"]  # Facts do not silently accept an old selection.


def test_progress_lists_multiple_candidates_without_selecting_or_completing_them(case):
    root, app, session = case
    old, old_review, _, new, user = chain(root)
    select(app, session, user)
    review, lca, _ = repaired(root, old_review, new)
    select(app, session, review, "review")
    select(app, session, lca, "lca")
    review_file(root, old)
    wrong_scope = records.publish(root, kind="review", title="References new report, reviews old report",
                                  files=["review.json"], depends_on=[old["record_path"], new["record_path"]])
    select(app, session, wrong_scope, "wrong-scope")
    progress = records.delivery_progress(root, app.store.messages(session))
    assert review["record_path"] in progress and wrong_scope["record_path"] in progress
    assert "review.json.reviewed_refs（作者宣告）: `" + old["record_path"] in progress
    assert records.selected_delivery(app.store.messages(session)) == user["record_path"]
    assert records.delivery_issues(root, user["record_path"])
    damaged = (root / review["record_path"]).parent / review["files"][0]["snapshot"]
    damaged.write_bytes(b"changed")
    progress = records.delivery_progress(root, app.store.messages(session))
    assert "目前無法讀回，不作為可沿用的證明" in progress
    assert wrong_scope["record_path"] in progress


def test_progress_bounds_only_its_index_and_preserves_full_receipts(case):
    root, app, session = case
    *_, new, user = chain(root)
    select(app, session, user)
    saved = []
    for i in range(70):
        item = record(root, "final_lca", f"judgment-{i}.md", f"Candidate judgment {i}", [new["record_path"]])
        saved.append(item)
        select(app, session, item, f"judgment-{i}")
    history = app.store.messages(session)
    before = json.dumps(history, sort_keys=True)
    progress = records.delivery_progress(root, history)
    assert len(progress) < 12500
    assert "筆紀錄未展開" in progress
    assert saved[-1]["record_path"] in progress
    assert user["record_path"] in progress
    assert records.selected_delivery(history) == user["record_path"]
    assert json.dumps(app.store.messages(session), sort_keys=True) == before
    assert all(item["record_path"] in before for item in saved)


def test_local_quote_edit_preserves_the_other_checks_and_reuses_work(case):
    root, app, session = case
    report = record(root, "report", "report.md", "Value 1.\n  condition A.")
    value = review_file(root, report)
    value["checks"].append(json.loads(json.dumps(value["checks"][0])))
    correct = value["checks"][0]["subject"]["quote"]
    broken = correct.replace("\n  ", "\n   ")
    value["checks"][0]["subject"]["quote"] = broken
    original = records.encoded(value)
    (root / "review.json").write_bytes(original)
    before = {p: p.read_bytes() for p in (root / ".research").rglob("*") if p.is_file()}

    def answer(n, kwargs):
        if n in (1, 4):
            return Completion(tool_calls=[ToolCall(f"publish-{n}", "research_record", {
                "kind": "review", "title": "Review", "files": ["review.json"], "depends_on": [report["record_path"]]})], finish_reason='tool-calls')
        if n == 2:
            error = plain_messages(kwargs["messages"])[-1]["content"]
            assert "/checks/0/subject/quote" in error and "read frozen source=" in error
            assert "/checks/1/subject/quote" not in error
            assert (root / "review.json").read_bytes() == original
            return Completion(tool_calls=[ToolCall("read-candidate", "read", {"filePath": str(root / "review.json")})], finish_reason='tool-calls')
        if n == 3:
            return Completion(tool_calls=[ToolCall("local-edit", "edit", {
                "filePath": str(root / "review.json"), "oldString": json.dumps(broken), "newString": json.dumps(correct)})], finish_reason='tool-calls')
        assert n == 5
        return Completion(text="Corrected the one citation and saved the review.", finish_reason='stop')

    calls = mock_model(app, answer)
    app.prompt(session, "Save the already prepared review; fix any format defects locally.")
    assert len(calls) == 5
    fixed = json.loads((root / "review.json").read_bytes())
    value["checks"][0]["subject"]["quote"] = correct
    assert fixed == value
    assert all(p.read_bytes() == data for p, data in before.items())
    assert len(records.inventory(root)) == 2


def test_unsupported_review_is_consumed_without_automatic_release_or_decision_gate(case):
    root, app, session = case
    source = record(root, "notes", "source.md", "One observation under condition A.")
    report = record(root, "report", "report.md", "A claim requiring support.", [source["record_path"]])
    evidence = [{"record_ref": source["record_path"], "source_path": "source.md",
                 "quote": "One observation under condition A."}]
    value = review_file(root, report, evidence=evidence, decision="unsupported")
    value["checks"][0]["reason"] = "The selected observation does not establish this claim's scope."
    raw = records.encoded(value)
    (root / "review.json").write_bytes(raw)
    saved = records.publish(root, kind="review", title="Bounded review", files=["review.json"],
                            depends_on=[report["record_path"], source["record_path"]])
    select(app, session, saved, "review")
    assert records.read_record(root, saved["record_path"])["kind"] == "review"
    assert records.selected_delivery(app.store.messages(session)) is None
    assert {item["kind"] for item in records.inventory(root)} == {"notes", "report", "review"}
    snapshot = (root / saved["record_path"]).parent / saved["files"][0]["snapshot"]
    assert snapshot.read_bytes() == raw
    # Explicit test-authored downstream records exercise the existing structural
    # consumer. This is not a scientific release decision made by the runtime.
    lca = record(root, "final_lca", "lca.md", "The assessed claim lacks sufficient support.",
                 [report["record_path"], saved["record_path"]])
    delivery = record(root, "user_report", "delivery.md", "Deliver the bounded assessment with its limitation.",
                      [report["record_path"], lca["record_path"]])
    assert records.delivery_issues(root, delivery["record_path"]) == []
    assert snapshot.read_bytes() == raw
