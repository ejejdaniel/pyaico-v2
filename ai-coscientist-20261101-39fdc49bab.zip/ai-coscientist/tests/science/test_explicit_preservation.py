"""File selection is explicit; Markdown syntax is not an attachment contract."""

from unittest.mock import patch

import pytest

from researchkit import records
from researchkit.tools import _publish
from opencode.loop import ToolContext
from test_delivery_acceptance import case


@pytest.mark.parametrize("body", [
    b"[S+](C1=CC=CC=C1)\r\nunchanged source table\n",
    b"[document](missing.txt)\n![image](../outside.png)\n",
    b'<a href="file:///missing.txt">source</a><img src="missing.png">',
    b"[network](https://example.invalid/file)\n[index](sources/index.md)",
    b"[space](<raw data/file.txt>)\n[escape](../../outside)\n",
    b"\xff\xfeinvalid UTF-8, preserved as bytes",
])
def test_markup_is_not_an_implicit_file_read(case, body):
    root, app, session = case
    path = root / "input.md"
    path.write_bytes(body)
    ctx = ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)
    import json
    saved = json.loads(_publish({"kind": "source", "title": "Original", "files": ["input.md"]}, ctx).output)
    assert [f["source_path"] for f in saved["files"]] == ["input.md"]
    assert records.local_path(root, saved["files"][0]["snapshot"]).read_bytes() == body
    assert path.read_bytes() == body


def test_link_to_existing_group_does_not_claim_group_was_preserved(case):
    root, _, _ = case
    (root / "index.md").write_text("[source](data.txt)", encoding="utf-8")
    (root / "data.txt").write_text("Actual source", encoding="utf-8")
    saved = records.publish(root, kind="source", title="Index only", files=["index.md"], depends_on=[])
    assert [f["source_path"] for f in saved["files"]] == ["index.md"]
    (root / "data.txt").write_text("Changed source", encoding="utf-8")
    assert records.publish(root, kind="source", title="Index only", files=["index.md"], depends_on=[]) == saved
    with pytest.raises(ValueError, match="Duplicate file"):
        records.publish(root, kind="source", title="Duplicate", files=["index.md", "./index.md"], depends_on=[])


def test_existing_manifest_remains_authority_without_reparsing_links(case):
    root, _, _ = case
    folder = root / ".research/records"
    contents = {"old.md": b"[source](data.txt)", "data.txt": b"old linked data"}
    # A pre-change manifest containing an implicitly discovered attachment.
    manifest = {"kind": "literature", "title": "Old", "depends_on": [], "files": [
        {"source_path": name, "snapshot": "files/" + name, "bytes": len(raw), "sha256": records.digest(raw)}
        for name, raw in contents.items()]}
    raw = records.encoded(manifest)
    destination = folder / records.digest(raw)
    (destination / "files").mkdir(parents=True)
    for name, data in contents.items():
        (destination / "files" / name).write_bytes(data)
    (destination / "record.json").write_bytes(raw)
    ref = (destination / "record.json").relative_to(root).as_posix()
    with patch("researchkit.records._markdown_references", side_effect=AssertionError("Never parse old records")):
        assert records.read_record(root, ref) == manifest
    assert (destination / "record.json").read_bytes() == raw
    (destination / "files/data.txt").write_bytes(b"tampered")
    with pytest.raises(ValueError, match="content has changed"):
        records.read_record(root, ref)
