"""Checking proxy formulas on the historical records before candidates are generated; no model calls."""

import json

import pytest

from researchkit import board, history_check, records
from researchkit.tools import TOOLS

BASE = ["h1", "h2"]
MEASURED = {"h1": 53.7, "h2": 47.9}
TARGET = {"direction": "target", "target_value": 40.0}


def check(predicted, measured=MEASURED, **template):
    return history_check.check_sheet({**TARGET, **template}, predicted, BASE, measured)


def test_an_offset_beyond_the_residual_spread_is_off_scale():
    row = check({"h1": 41.2, "h2": 35.4})  # the right differences at the wrong level, as P1 in v14
    assert row["flags"] == ["off_scale"]
    assert row["scale_check"]["mean_offset"] == pytest.approx(-12.5) and row["spread_ratio"] == pytest.approx(1.0)


def test_a_reversed_order_and_a_compressed_spread_are_both_reported():
    row = check({"h1": 38.0, "h2": 39.0})
    assert row["flags"] == ["order_reversed", "off_scale", "spread_mismatch"]
    assert "these samples separate it from the other formulas checked here: either the history contradicts the " \
           "hypothesis as stated or the formula misstates its mechanism" in row["findings"][0]
    assert row["spread_ratio"] == pytest.approx(1 / 5.8)


def test_equal_predictions_cannot_be_checked_by_the_history():
    row = check({"h1": 40.0, "h2": 40.0})
    assert "equal_on_history" in row["flags"] and "spread_mismatch" not in row["flags"]


def test_a_declared_anchor_removes_the_offset_but_not_a_slope_error():
    row = check({"h1": 41.2, "h2": 35.4}, anchor="mean_offset")
    assert row["flags"] == [] and row["scale_check"]["anchored"]
    assert "No finding" in row["findings"][-1] and "not validation" in row["findings"][-1]
    assert "spread_mismatch" in check({"h1": 41.0, "h2": 40.0}, anchor="mean_offset")["flags"]


def test_without_kpi_or_measured_the_order_is_reported_as_unchecked():
    row = check({"h1": 1.0, "h2": 2.0}, measured=None)
    assert row["flags"] == ["order_unchecked"] and not row["order_checked"]
    assert "declares neither kpi" in row["findings"][0]


EOP_KPI = {"record_ref": "r", "source_path": "d/measured.json", "column": "EOP_mJ", "better": "target", "target_value": 40.0}
INDEX = {"direction": "lower", "target_value": None, "kpi": EOP_KPI}  # a dose index, lower is better


def test_an_index_that_prefers_the_worse_historical_sample_is_reversed():
    # v16: H1 (53.7 mJ) is further from 40 than H2 (47.9), but the index rates H1 lower, i.e. better.
    row = history_check.check_sheet(INDEX, {"h1": 12.57, "h2": 15.95}, BASE, None, MEASURED)
    assert row["flags"] == ["order_reversed"] and row["order_checked"]
    assert row["history_order"]["better_by_kpi"] == "h2" and row["history_order"]["kendall_tau_b"] == -1.0
    assert "opposite order to the measured KPI EOP_mJ (better: target 40)" in row["findings"][0]
    agreeing = history_check.check_sheet(INDEX, {"h1": 15.95, "h2": 12.57}, BASE, None, MEASURED)
    assert agreeing["flags"] == [] and "orders the historical samples as the KPI does" in agreeing["findings"][-1]


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def formula_with_values(root, name, predicted, depends_on, **extra):
    data = save(root, "prepared_data", {"d/measured.json": {k: {"EOP_mJ": v} for k, v in MEASURED.items()}})
    template = {"formula_id": "P1", "expression": "EOP", "hypothesis_ids": ["H1"], **TARGET,
                "measured": {"record_ref": data["record_path"], "source_path": "d/measured.json", "column": "EOP_mJ"},
                **extra}
    formula = save(root, "proxy_formula", {f"{name}/proxy_formula.json": template}, depends_on)
    values = save(root, "implementation", {f"{name}/values.json": predicted}, [formula])
    return formula, values


def notices(root):
    return {item["text"]: item["level"] for item in board.build(root)["notice_items"]}


def test_the_board_asks_for_a_check_then_shows_its_findings_until_a_revision_replaces_the_formula(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    formula, values = formula_with_values(tmp_path, "v1", {"h1": 41.2, "h2": 35.4}, [hypotheses])
    missing = [text for text, level in notices(tmp_path).items() if "還沒有歷史檢查" in text]
    assert len(missing) == 1 and notices(tmp_path)[missing[0]] == "action"

    args = {"baseline_ids": BASE, "sheets": [{"formula_ref": formula["record_path"],
                                              "values": {"record_ref": values["record_path"], "source_path": "v1/values.json"}}]}
    receipt = history_check.run(args, tmp_path, tmp_path / ".research/history-checks/one")
    saved = records.read_record(tmp_path, receipt["record"]["record_path"])
    assert saved["kind"] == "history_check" and formula["record_path"] in saved["depends_on"]
    found = notices(tmp_path)
    assert not any("還沒有歷史檢查" in text for text in found)
    off = [text for text in found if "平均偏離量測 -12.5" in text]
    assert len(off) == 1 and found[off[0]] == "action"
    assert "歷史檢查 off_scale" in board.render(board.build(tmp_path))

    revised, revised_values = formula_with_values(tmp_path, "v2", {"h1": 53.0, "h2": 48.0}, [hypotheses, formula])
    found = notices(tmp_path)
    assert not any("平均偏離量測" in text for text in found)  # the replaced formula's finding is gone
    assert any("還沒有歷史檢查" in text and revised["record_path"].split("/")[2][:8] in text for text in found)
    history_check.run({"baseline_ids": BASE, "sheets": [{"formula_ref": revised["record_path"], "values": {
        "record_ref": revised_values["record_path"], "source_path": "v2/values.json"}}]},
        tmp_path, tmp_path / ".research/history-checks/two")
    assert "歷史檢查 順序與實測一致" in board.render(board.build(tmp_path))


def test_without_measurements_a_formula_is_not_missing_a_history_check(tmp_path):
    # A design task with nothing measured (the room-acoustics case): no formula ranks measured values, so
    # there is no history to check and the board must not keep asking for one.
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    template = {"formula_id": "P1", "expression": "0.161 * V / A", "hypothesis_ids": ["H1"], **TARGET}
    formula = save(tmp_path, "proxy_formula", {"p/proxy_formula.json": template}, [hypotheses])
    save(tmp_path, "implementation", {"p/values.json": {"baseline": 5.1}}, [formula])
    assert not any("還沒有歷史檢查" in text for text in notices(tmp_path))
    assert "沒有量測可檢查，只有機制依據" in board.render(board.build(tmp_path))
    # Once a formula ranks measured values (LIT), every unchecked formula is asked for its check again.
    formula_with_values(tmp_path, "m", {"h1": 41.2, "h2": 35.4}, [hypotheses])
    assert sum("還沒有歷史檢查" in text for text in notices(tmp_path)) == 2


def index_pool(root, kpi=True):
    """v16's situation: three dose indices, lower is better, each preferring the worse historical sample."""
    hypotheses = save(root, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": f"H{i}", "statement": f"mechanism {i}"} for i in (1, 2)]}})
    data = save(root, "prepared_data", {"d/measured.json": {k: {"EOP_mJ": v} for k, v in MEASURED.items()}})
    sheets = []
    for number, values in ((1, {"h1": 12.6, "h2": 16.0, "c1": 11.0}), (2, {"h1": 4.3, "h2": 6.1, "c1": 3.9})):
        template = {"formula_id": f"P{number}", "expression": "index", "hypothesis_ids": [f"H{number}"],
                    "direction": "lower"}
        if kpi:
            template["kpi"] = {**EOP_KPI, "record_ref": data["record_path"]}
        formula = save(root, "proxy_formula", {f"p{number}/proxy_formula.json": template}, [hypotheses])
        implementation = save(root, "implementation", {f"p{number}/values.json": values}, [formula])
        sheets.append({"formula_ref": formula["record_path"],
                       "values": {"record_ref": implementation["record_path"], "source_path": f"p{number}/values.json"}})
    return sheets


def test_the_leaderboard_does_not_count_a_reversed_sheet_as_history_evidence(tmp_path):
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)
    result = leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": sheets},
                             tmp_path, tmp_path / ".research/leaderboards/one")["result"]
    assert [s["evidence"] for s in result["sheets"]] == ["history_reversed", "history_reversed"]
    assert result["sheets"][0]["history_order"]["better_by_kpi"] == "h2"
    candidate, = result["candidates"]
    assert candidate["verdict"] == "conditional_surpass"  # v16 called this a robust surpass
    found = notices(tmp_path)
    reversed_sheets = [text for text in found if "對歷史樣本的偏好與實測 KPI 相反" in text and "不算歷史證據" in text]
    assert len(reversed_sheets) == 2 and all(found[text] == "action" for text in reversed_sheets)


def test_a_formula_without_kpi_or_measured_is_flagged_when_saved(tmp_path):
    index_pool(tmp_path, kpi=False)
    missing = [text for text, level in notices(tmp_path).items() if "沒有宣告它排序的 KPI" in text]
    assert len(missing) == 2 and all(notices(tmp_path)[text] == "action" for text in missing)
    other = tmp_path / "with-kpi"
    other.mkdir()
    index_pool(other)
    assert not any("沒有宣告它排序的 KPI" in text for text in notices(other))


def test_the_board_says_when_the_order_was_not_checked(tmp_path):
    sheets = index_pool(tmp_path, kpi=False)
    history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path, tmp_path / ".research/history-checks/one")
    rendered = board.render(board.build(tmp_path))
    assert "歷史檢查：順序未檢查（未宣告 kpi 或 measured）" in rendered and "無異常" not in rendered


def test_a_malformed_kpi_is_refused_when_saved():
    from researchkit.tools import check_proxy_formula
    with pytest.raises(ValueError, match="kpi.better must be higher, lower or target, not 'closer'"):
        check_proxy_formula({"direction": "lower", "kpi": {**EOP_KPI, "better": "closer"}})
    check_proxy_formula({"direction": "lower", "kpi": EOP_KPI})


def test_a_formula_that_predicts_the_kpi_needs_no_mechanism_field():
    # Every LIT run declared kpi_falls for a formula predicting the KPI; told to declare kpi_rises, one
    # (2026-11-01) negated two expressions against their own rationale.
    from researchkit.tools import check_proxy_formula
    measured = {key: EOP_KPI[key] for key in ("record_ref", "source_path", "column")}
    check_proxy_formula({"direction": "target", "target_value": 40.0, "kpi": EOP_KPI, "measured": measured})
    with pytest.raises(ValueError, match="leave out mechanism_predicts.*plus sign.*Do not flip the whole expression"):
        check_proxy_formula({"direction": "target", "target_value": 40.0, "kpi": EOP_KPI, "measured": measured,
                             "mechanism_predicts": "kpi_falls"})
    # Left out, it still fixes the direction of a higher- or lower-is-better KPI: the prediction rises with it.
    higher = {**{key: value for key, value in EOP_KPI.items() if key != "target_value"}, "better": "higher"}
    with pytest.raises(ValueError, match="direction lower contradicts mechanism_predicts kpi_rises"):
        check_proxy_formula({"direction": "lower", "kpi": higher, "measured": measured})
    check_proxy_formula({"direction": "higher", "kpi": higher, "measured": measured})


def test_a_target_value_where_it_does_not_belong_says_so_when_saved():
    # A run (2026-11-01) read a general kpi message as "add a target_value" and added one to a lower kpi, three
    # times; a target_value on a higher formula was saved and refused only by the ranking tools.
    from researchkit.tools import check_proxy_formula
    lower = {key: value for key, value in EOP_KPI.items() if key != "target_value"}
    with pytest.raises(ValueError, match="kpi.target_value is only used with kpi.better target"):
        check_proxy_formula({"direction": "lower", "kpi": {**lower, "better": "lower", "target_value": 4.5}})
    with pytest.raises(ValueError, match="target_value is only used with direction target: leave it out"):
        check_proxy_formula({"direction": "higher", "target_value": 40.0, "kpi": EOP_KPI})


def test_values_must_cover_every_historical_sample_and_the_tool_is_installed(tmp_path):
    formula, values = formula_with_values(tmp_path, "v1", {"h1": 41.2}, [])
    with pytest.raises(ValueError, match="no prediction for: \\['h2'\\]"):
        history_check.run({"baseline_ids": BASE, "sheets": [{"formula_ref": formula["record_path"], "values": {
            "record_ref": values["record_path"], "source_path": "v1/values.json"}}]},
            tmp_path, tmp_path / ".research/history-checks/one")
    assert "research_history_check" in {tool.name for tool in TOOLS}


def test_an_unchecked_order_says_which_of_its_causes_applies():
    one = history_check.check_sheet(INDEX, {"h2": 15.95}, ["h2"], None, MEASURED)
    assert one["order_unchecked_reason"] == "one_sample" and "pass every historical sample" in one["findings"][0]
    lacking = history_check.check_sheet(INDEX, {"h1": 12.57, "h2": 15.95}, BASE, None, {"h2": 47.9})
    assert lacking["order_unchecked_reason"] == "one_sample" and "Only h2 of the historical samples" in lacking["findings"][0]
    ties = history_check.check_sheet(INDEX, {"h1": 12.57, "h2": 15.95}, BASE, None, {"h1": 47.9, "h2": 47.9})
    assert ties["order_unchecked_reason"] == "kpi_ties" and "is the same for h1, h2" in ties["findings"][0]
    other = history_check.check_sheet(INDEX, {"h1": 12.57, "h2": 15.95}, BASE, None, {"S1": 53.7, "S2": 47.9})
    assert other["order_unchecked_reason"] == "no_overlap"
    assert "does not separate" not in " ".join(row for r in (one, lacking, ties, other) for row in r["findings"])
    partial = history_check.check_sheet(INDEX, {"h1": 12.57, "h2": 15.95, "h3": 14.0}, ["h1", "h2", "h3"], None,
                                        MEASURED)
    assert partial["order_checked"] and "has no value for h3; the order was checked on h1, h2 only" in partial["findings"][-1]


def test_kpi_values_keyed_by_other_sample_ids_are_refused_with_both_id_sets(tmp_path):
    # v22: the kpi CSV was keyed by formulation strings, the predictions by HIST1/HIST2.
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)
    data = save(tmp_path, "prepared_data", {"d/other.json": {"PHS/R12, Mw=7k": {"EOP_mJ": 53.7},
                                                              "PHS/R17, Mw=9k": {"EOP_mJ": 47.9}}})
    template = {"formula_id": "P9", "expression": "index", "hypothesis_ids": ["H1"], "direction": "lower",
                "kpi": {**EOP_KPI, "record_ref": data["record_path"], "source_path": "d/other.json"}}
    formula = save(tmp_path, "proxy_formula", {"p9/proxy_formula.json": template})
    values = save(tmp_path, "implementation", {"p9/values.json": {"h1": 12.6, "h2": 16.0, "c1": 11.0}}, [formula])
    sheet = {"formula_ref": formula["record_path"], "values": {"record_ref": values["record_path"],
                                                                "source_path": "p9/values.json"}}
    message = r"no entry for the historical samples h1, h2; that file's sample IDs are PHS/R12, Mw=7k, PHS/R17, Mw=9k"
    with pytest.raises(ValueError, match=message) as refused:
        history_check.run({"baseline_ids": BASE, "sheets": [sheet]}, tmp_path, tmp_path / ".research/history-checks/x")
    with pytest.raises(ValueError, match=message):
        leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": [sheet, *sheets]},
                        tmp_path, tmp_path / ".research/leaderboards/x")
    # v32 was told to "select, or save" a table keyed by its IDs and saved nine of them in 25 minutes.
    text = str(refused.value)
    assert "P9's kpi selection is part of its saved proxy_formula.json, which does not change, so saving another kpi "            "table alone changes nothing" in text
    assert "(1) use the file's IDs for the historical samples" in text
    assert "(2) save a revised formula (research_record with revises) whose kpi selects values keyed by h1, h2" in text


def test_the_board_names_why_the_order_was_not_checked(tmp_path):
    formula, values = formula_with_values(tmp_path, "v1", {"h1": 53.0, "h2": 48.0}, [])
    history_check.run({"baseline_ids": ["h2"], "sheets": [{"formula_ref": formula["record_path"], "values": {
        "record_ref": values["record_path"], "source_path": "v1/values.json"}}]},
        tmp_path, tmp_path / ".research/history-checks/one")
    rendered = board.render(board.build(tmp_path))
    assert "歷史檢查：順序未檢查（只比到一筆歷史樣本）" in rendered and "未宣告 kpi" not in rendered


def test_agreement_with_the_samples_a_formula_was_fitted_to_is_not_history_evidence(tmp_path):
    # v23 took P2's and P3's slopes from its two measured rows; the leaderboard then called E3 a robust surpass.
    from researchkit import leaderboard
    exact = check({"h1": 53.7, "h2": 47.9})
    assert exact["flags"] == [] and exact["findings"] == [
        "The prediction equals the measured value exactly for h1 (53.7), h2 (47.9), which fitted_on does not list. "
        "If any constant of the formula was set from these samples, list it in fitted_on in a revised formula "
        "(revises): agreement with the samples a formula was fitted to is not a check of it."
        + history_check.TERMS_INSTEAD]
    differences = check({"h1": 55.0, "h2": 49.2})  # the measured gap at another level, and on scale
    assert any("reproduce the measured differences" in text for text in differences["findings"])
    assert not any("No finding" in text for text in differences["findings"])
    fitted = check({"h1": 53.7, "h2": 47.9}, fitted_on=["h1", "h2"])
    assert "fitted_history" in fitted["flags"] and "how it was made, not a check" in fitted["findings"][-1]
    # v40 fitted its target formula by minimum-norm least squares: one of the sets a model with terms gives.
    assert fitted["findings"][-1].endswith(history_check.TERMS_INSTEAD)
    assert not any("fitted_on does not list" in text for text in fitted["findings"])
    partly = check({"h1": 53.7, "h2": 47.9}, fitted_on=["h1"])
    assert "fitted_history" not in partly["flags"]
    assert any("exactly for h2 (47.9), which fitted_on does not list" in text for text in partly["findings"])
    # v28's PC listed only TV1, whose value it hit; an inexact prediction elsewhere leaves nothing to point at.
    declared = check({"h1": 68.952, "h2": 47.9}, fitted_on=["h2"])
    assert not any("fitted_on" in text for text in declared["findings"])

    sheets = [{"formula_ref": f"P{n}", "formula_id": f"P{n}", "hypothesis_ids": [f"H{n}"], "direction": "lower",
               "values": {"h1": 53.7, "h2": 47.9, "c1": 41.0}} for n in (1, 2)]
    assert leaderboard.compute(sheets, BASE, ["c1"])["candidates"][0]["verdict"] == "robust_surpass"
    result = leaderboard.compute([{**sheet, "fitted_on": BASE} for sheet in sheets], BASE, ["c1"])
    assert [sheet["evidence"] for sheet in result["sheets"]] == ["history_fitted", "history_fitted"]
    assert result["candidates"][0]["verdict"] == "conditional_surpass"


def test_fitted_on_must_name_distinct_samples_and_its_sheet_is_noted_on_the_board(tmp_path):
    from researchkit import leaderboard
    from researchkit.tools import check_proxy_formula
    with pytest.raises(ValueError, match="fitted_on must list the distinct historical sample IDs"):
        check_proxy_formula({"direction": "lower", "fitted_on": "h1"})
    with pytest.raises(ValueError, match="fitted_on must list"):
        check_proxy_formula({"direction": "lower", "fitted_on": ["h1", "h1"]})
    check_proxy_formula({"direction": "lower", "fitted_on": ["h1", "h2"]})
    fitted = save(tmp_path, "proxy_formula", {"pf/proxy_formula.json": {
        "formula_id": "P9", "expression": "x", "hypothesis_ids": ["H1"], "direction": "lower",
        "fitted_on": ["h1", "h2"]}})
    values = save(tmp_path, "implementation", {"pf/values.json": {"h1": 2.0, "h2": 1.0, "c1": 0.5}}, [fitted])
    leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": [
        {"formula_ref": fitted["record_path"], "values": {"record_ref": values["record_path"],
                                                           "source_path": "pf/values.json"}}]},
        tmp_path, tmp_path / ".research/leaderboards/fitted")
    assert any("的常數取自 h1、h2（fitted_on）" in text for text in notices(tmp_path))


def test_a_sheet_without_the_historical_samples_says_where_they_belong(tmp_path):
    # v24 split its values into one table per formula and left out S1 and S2.
    from researchkit import leaderboard
    formula = save(tmp_path, "proxy_formula", {"p/proxy_formula.json": {
        "formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "lower"}})
    values = save(tmp_path, "implementation", {"p/values.json": {"c1": 1.0}}, [formula])
    with pytest.raises(ValueError, match="historical samples belong in the same values table as the candidates"):
        leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": [{"formula_ref": formula["record_path"],
                         "values": {"record_ref": values["record_path"], "source_path": "p/values.json"}}]},
                        tmp_path, tmp_path / ".research/leaderboards/x")


def test_the_direction_must_be_the_one_the_mechanism_predicts():
    from researchkit.tools import check_proxy_formula
    kpi = {"record_ref": "r", "source_path": "d/measured.json", "column": "EOP_mJ", "better": "lower"}
    with pytest.raises(ValueError, match="mechanism_predicts is required when kpi.better is higher or lower"):
        check_proxy_formula({"direction": "higher", "kpi": kpi})
    # v30's P1: its rationale said the index rises with the dose, yet it declared higher better.
    with pytest.raises(ValueError, match="direction higher contradicts mechanism_predicts kpi_rises with kpi.better "
                                         "lower: .* makes lower formula values better, so direction is lower"):
        check_proxy_formula({"direction": "higher", "mechanism_predicts": "kpi_rises", "kpi": kpi})
    check_proxy_formula({"direction": "lower", "mechanism_predicts": "kpi_rises", "kpi": kpi})
    check_proxy_formula({"direction": "higher", "mechanism_predicts": "kpi_falls", "kpi": kpi})
    check_proxy_formula({"direction": "higher", "mechanism_predicts": "kpi_rises", "kpi": {**kpi, "better": "higher"}})
    with pytest.raises(ValueError, match="mechanism_predicts must be kpi_rises or kpi_falls, not 'up'"):
        check_proxy_formula({"direction": "lower", "mechanism_predicts": "up", "kpi": kpi})
    check_proxy_formula({"direction": "lower", "kpi": EOP_KPI})  # a target KPI: the mechanism fixes no side


def test_a_formula_saved_after_its_hypothesis_was_found_reversed_counts_as_fitted(tmp_path):
    # v30 flipped P3 three times and P4 once after their history checks came back reversed; the checks then
    # agreed and the leaderboard counted the flips as history evidence.
    import time
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)
    first = history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path,
                              tmp_path / ".research/history-checks/one")
    assert [s["flags"] for s in first["result"]["sheets"]] == [["order_reversed"], ["order_reversed"]]
    time.sleep(0.05)
    old = sheets[0]["formula_ref"]
    template = json.loads((tmp_path / "p1/proxy_formula.json").read_text(encoding="utf-8"))
    flipped = save(tmp_path, "proxy_formula", {"p1b/proxy_formula.json": {**template, "direction": "higher"}},
                   [{"record_path": old}])
    values = save(tmp_path, "implementation", {"p1b/values.json": {"h1": 12.6, "h2": 16.0, "c1": 17.0}}, [flipped])
    # Another formula for the same hypothesis was also written knowing the result; one for another was not.
    other = save(tmp_path, "proxy_formula", {"p9/proxy_formula.json": {**template, "formula_id": "P9",
                                                                       "direction": "higher"}}, [{"record_path": old}])
    unrelated = save(tmp_path, "proxy_formula", {"p8/proxy_formula.json": {
        **template, "formula_id": "P8", "hypothesis_ids": ["H3"], "direction": "higher"}}, [{"record_path": old}])

    def pick(formula, implementation, name):
        return {"formula_ref": formula["record_path"], "values": {"record_ref": implementation["record_path"],
                                                                  "source_path": name}}
    others = [save(tmp_path, "implementation", {f"{n}/values.json": {"h1": 12.6, "h2": 16.0}}, [f])
              for n, f in (("p9", other), ("p8", unrelated))]
    second = history_check.run({"baseline_ids": BASE, "sheets": [
        pick(flipped, values, "p1b/values.json"), pick(other, others[0], "p9/values.json"),
        pick(unrelated, others[1], "p8/values.json")]}, tmp_path, tmp_path / ".research/history-checks/two")["result"]
    rows = second["sheets"]
    assert [r["flags"] for r in rows] == [["fitted_history"], ["fitted_history"], []]
    assert rows[0]["revised_after"][0]["history_check"] == first["record"]["record_path"]
    assert rows[0]["revised_after"][0]["samples"] == BASE and "revised_after" not in rows[2]
    assert "saved after a history check found a formula of its hypothesis ordering these samples against the KPI "            "(P1 in" in rows[0]["findings"][0]
    assert any("是在歷史檢查判定同一假說與歷史相反之後才存的" in text for text in notices(tmp_path))
    result = leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": [
        pick(flipped, values, "p1b/values.json"), sheets[1]]}, tmp_path, tmp_path / ".research/leaderboards/one")
    sheet = result["result"]["sheets"][0]
    assert sheet["evidence"] == "history_fitted" and sheet["revised_after"][0]["formula_id"] == "P1"
    assert result["result"]["candidates"][0]["verdict"] == "conditional_surpass"


def test_only_the_newest_leaderboard_of_a_set_of_formulas_keeps_its_notices(tmp_path):
    # v30 kept two "order reversed" action notices on each of three leaderboards later ones replaced.
    import time
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)

    def run(name):
        return leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": sheets},
                               tmp_path, tmp_path / f".research/leaderboards/{name}")["record"]
    one = run("one")
    time.sleep(0.05)
    two = run("two")
    texts = [text for text in notices(tmp_path)
             if "對歷史樣本的偏好與實測 KPI 相反" in text and text.startswith("leaderboard")]
    assert len(texts) == 2 and all(two["record_path"].split("/")[2][:8] in text for text in texts)
    assert not any(one["record_path"].split("/")[2][:8] in text for text in texts)


def test_a_round_computed_before_the_previous_round_was_ranked_is_flagged(tmp_path):
    # v30 declared three rounds; rounds 2 and 3 were computed five minutes before the first leaderboard.
    import time
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)
    early = [save(tmp_path, "implementation", {f"r2/p{n}.json": {"h1": 12.6 * n, "h2": 16.0 * n, "c2": 10.0}},
                  [{"record_path": sheets[n - 1]["formula_ref"]}]) for n in (1, 2)]
    time.sleep(0.05)

    def run(name, chosen, candidates):
        return leaderboard.run({"baseline_ids": BASE, "candidate_ids": candidates, "sheets": chosen},
                               tmp_path, tmp_path / f".research/leaderboards/{name}")["record"]
    one = run("one", sheets, ["c1"])
    time.sleep(0.05)
    two = run("two", [{"formula_ref": s["formula_ref"], "values": {"record_ref": e["record_path"],
                                                                     "source_path": f"r2/p{n}.json"}}
                      for n, (s, e) in enumerate(zip(sheets, early), 1)], ["c2"])
    rounds = [{"round": 1, "leaderboard_ref": one["record_path"]}, {"round": 2, "leaderboard_ref": two["record_path"]}]
    save(tmp_path, "sample_evolution", {"evo/evolution.json": {"rounds": rounds}}, [one, two])
    flagged = [text for text in notices(tmp_path) if "沒有用到上一輪的結果" in text]
    assert len(flagged) == 1 and "第 2 輪" in flagged[0] and one["record_path"].split("/")[2][:8] in flagged[0]


def test_a_reversed_order_on_samples_that_differ_on_other_formulas_is_not_called_a_refutation(tmp_path):
    # v31: TV0 and TV1 differed in ester, Mw and quencher loading at once; all three formulas came out
    # reversed and the agent was told the history contradicted three hypotheses. Two of the reversals
    # were a quencher read as an acid generator and a stabilising group added to a barrier.
    from researchkit import leaderboard
    sheets = index_pool(tmp_path)
    rows = history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path,
                             tmp_path / ".research/history-checks/one")["result"]["sheets"]
    assert [r["confounded_with"] for r in rows] == [["P2"], ["P1"]]
    finding = rows[0]["findings"][0]
    assert "These samples also differ on P2: the measured difference is the net of several changes" in finding
    assert "neither refutes nor supports" in finding and "contradicts" not in finding
    assert "(1) each component or input it uses has the role and meaning the task defines for it" in finding
    assert "never change a sign the mechanism gives" in finding
    found = notices(tmp_path)
    assert any("這些樣本在 P2 上也不同" in text and "用到的每個成分或輸入是否符合題目定義的角色與意義" in text
               for text in found)
    assert not any("歷史資料反駁" in text for text in found)
    alone = history_check.run({"baseline_ids": BASE, "sheets": sheets[:1]}, tmp_path,
                              tmp_path / ".research/history-checks/two")["result"]["sheets"][0]
    assert "confounded_with" not in alone
    assert "these samples separate it from the other formulas checked here: either the history contradicts" \
           in alone["findings"][0]
    board_result = leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["c1"], "sheets": sheets}, tmp_path,
                                   tmp_path / ".research/leaderboards/one")["result"]
    assert [s["confounded_with"] for s in board_result["sheets"]] == [["P2"], ["P1"]]


def test_with_enough_samples_a_reversed_order_is_confounded_only_with_a_formula_ordered_the_same_way():
    # Fields with many samples must keep a reversed order as evidence against the hypothesis: only formulas
    # the samples cannot separate are named, not every formula that varies.
    samples = ["s1", "s2", "s3", "s4", "s5", "s6"]
    a = dict(zip(samples, [1, 2, 3, 4, 5, 6]))
    b = dict(zip(samples, [3, 1, 6, 2, 5, 4]))  # varies independently of a
    mirror = dict(zip(samples, [12, 10, 8, 6, 4, 2]))  # a reversed exactly
    found = history_check.confounding([("A", ["H1"], a), ("B", ["H2"], b), ("M", ["H3"], mirror)], samples)
    assert found == {"A": ["M"], "B": [], "M": ["A"]}
    two = history_check.confounding([("A", ["H1"], a), ("B", ["H2"], b)], samples[:2])
    assert two == {"A": ["B"], "B": ["A"]}  # two samples, two varying formulas: one difference cannot split them
    same = history_check.confounding([("A", ["H1"], a), ("A2", ["H1"], b)], samples[:2])
    assert same == {"A": [], "A2": []}  # formulas of one hypothesis are not confounders of each other


def test_a_correction_names_its_error_and_basis_and_still_counts_as_fitted(tmp_path):
    import time
    from researchkit.tools import check_proxy_formula
    with pytest.raises(ValueError, match="correction must be"):
        check_proxy_formula({"direction": "lower", "correction": {"error": "flipped", "what": "x", "basis": "y"}})
    with pytest.raises(ValueError, match="correction must be"):
        check_proxy_formula({"direction": "lower", "correction": {"error": "role", "what": "x"}})
    sheets = index_pool(tmp_path)
    history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path, tmp_path / ".research/history-checks/one")
    time.sleep(0.05)
    template = json.loads((tmp_path / "p1/proxy_formula.json").read_text(encoding="utf-8"))
    correction = {"error": "role", "what": "the loading used as the generator is the quencher's",
                  "basis": "the task defines the quencher by its carboxylate motif"}
    fixed = save(tmp_path, "proxy_formula", {"p1c/proxy_formula.json": {**template, "correction": correction}},
                 [{"record_path": sheets[0]["formula_ref"]}])
    values = save(tmp_path, "implementation", {"p1c/values.json": {"h1": 16.0, "h2": 12.6}}, [fixed])
    row = history_check.run({"baseline_ids": BASE, "sheets": [{"formula_ref": fixed["record_path"], "values": {
        "record_ref": values["record_path"], "source_path": "p1c/values.json"}}]}, tmp_path,
        tmp_path / ".research/history-checks/two")["result"]["sheets"][0]
    assert row["flags"] == ["fitted_history"] and row["correction"] == correction
    assert "It declares a correction (role: the loading used as the generator is the quencher's" in row["findings"][0]
    assert any("它宣告了修正（role" in text for text in notices(tmp_path))


MODEL = {"formula_id": "PM", "expression": "EOP = offset + c1*quencher + c2*mw", "hypothesis_ids": ["H1", "H2"],
         "direction": "target", "target_value": 40.0, "tolerance": 1.0,
         "measured": {"record_ref": "r", "source_path": "d/measured.json", "column": "EOP_mJ"},
         "terms": [{"hypothesis_id": "H1", "lever": "quencher_wt", "quantity": "quencher",
                    "mechanism_predicts": "kpi_rises"},
                   {"hypothesis_id": "H2", "lever": "mw_kda", "quantity": "mw", "mechanism_predicts": "kpi_rises"}]}


def test_a_quantitative_model_declares_quantities_and_signs_not_coefficients():
    from researchkit.tools import check_proxy_formula
    check_proxy_formula(MODEL)
    sized = {**MODEL, "terms": [{**MODEL["terms"][0], "coefficient": 1.1, "basis": "assumed"}, MODEL["terms"][1]]}
    with pytest.raises(ValueError, match=r"terms\[1\]: coefficients are not declared; research_history_check sets "
                                         "them"):
        check_proxy_formula(sized)
    with pytest.raises(ValueError, match="terms has no term for H2"):
        check_proxy_formula({**MODEL, "terms": MODEL["terms"][:1]})
    with pytest.raises(ValueError, match="predicts the KPI itself: declare direction target"):
        check_proxy_formula({**MODEL, "direction": "lower", "target_value": None, "tolerance": None})
    with pytest.raises(ValueError, match="quantity quencher is already another term's"):
        check_proxy_formula({**MODEL, "terms": [MODEL["terms"][0], {**MODEL["terms"][1], "quantity": "quencher"}]})
    with pytest.raises(ValueError, match="noise must be"):
        check_proxy_formula({**MODEL, "noise": {"sd": -1, "source": "repeat runs"}})
    with pytest.raises(ValueError, match="has no anchor"):
        check_proxy_formula({**MODEL, "anchor": "mean_offset"})
    # v40 put its terms inside "model"; the formula was saved without them and fitted by hand.
    nested = {key: value for key, value in MODEL.items() if key != "terms"}
    with pytest.raises(ValueError, match="terms belongs at the top level of the template, not inside model"):
        check_proxy_formula({**nested, "model": {"offset": True, "terms": MODEL["terms"]}})
    # v42's Mw term had competing effects and no sign; unknown says so, but a model needs one signed term.
    check_proxy_formula({**MODEL, "terms": [MODEL["terms"][0], {**MODEL["terms"][1], "mechanism_predicts": "unknown"}]})
    with pytest.raises(ValueError, match="a fit to the history, not a mechanism"):
        check_proxy_formula({**MODEL, "terms": [{**term, "mechanism_predicts": "unknown"} for term in MODEL["terms"]]})
    with pytest.raises(ValueError, match="kpi_rises|kpi_falls|unknown"):
        check_proxy_formula({**MODEL, "terms": [MODEL["terms"][0], {**MODEL["terms"][1], "mechanism_predicts": "none"}]})


def test_a_target_kpi_asks_for_a_quantitative_model_until_one_is_saved(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": f"H{i}", "statement": f"mechanism {i}"} for i in (1, 2)]}})
    data = save(tmp_path, "prepared_data", {"d/measured.json": {k: {"EOP_mJ": v} for k, v in MEASURED.items()}})
    for number in (1, 2):
        save(tmp_path, "proxy_formula", {f"p{number}/proxy_formula.json": {
            "formula_id": f"P{number}", "expression": "index", "hypothesis_ids": [f"H{number}"],
            "direction": "lower", "kpi": {**EOP_KPI, "record_ref": data["record_path"]}}}, [hypotheses])
    assert any("還沒有量化模型" in text for text in notices(tmp_path))
    save(tmp_path, "proxy_formula", {"pm/proxy_formula.json": {
        **MODEL, "measured": {**MODEL["measured"], "record_ref": data["record_path"]}}}, [hypotheses])
    found = notices(tmp_path)
    assert not any("還沒有量化模型" in text for text in found)
    assert not any("同時代表 2 個假說" in text for text in found)  # the model combines hypotheses by design


def test_a_fitted_formula_that_still_ranks_the_history_backwards_is_not_called_fitted():
    # v25: fitted on both samples, yet it preferred the worse one; "agreeing is how it was made" contradicted that.
    row = history_check.check_sheet({**INDEX, "fitted_on": BASE}, {"h1": 12.57, "h2": 15.95}, BASE, None, MEASURED)
    assert "order_reversed" in row["flags"] and "fitted_history" not in row["flags"]


def test_an_anchored_target_formula_is_ordered_by_its_anchored_predictions():
    # v41's P1 sat about 48 below its target of 40 before its anchor. On the raw values h1 looked nearer the
    # target and the history reversed; anchored (52.4 and 49.2), the formula orders it as the KPI does.
    v41 = {"h1": -6.534, "h2": -9.801}
    anchored = history_check.check_sheet({**TARGET, "kpi": EOP_KPI, "anchor": "mean_offset"}, v41, BASE, MEASURED,
                                         MEASURED)
    assert anchored["flags"] == [] and anchored["history_order"]["agreement"] == "1/1"
    assert anchored["predicted"] == v41
    raw = history_check.check_sheet({**TARGET, "kpi": EOP_KPI}, v41, BASE, MEASURED, MEASURED)
    assert raw["flags"] == ["order_reversed", "off_scale"]
