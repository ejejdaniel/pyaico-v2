"""Regression boundaries for reverting age-based tool-result reduction."""

import copy
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from opencode.app import App
from opencode.context import working_context
from opencode.loop import _present_history
from opencode.store import Store


class HistoryPresentationRollbackTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"),
            "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_DATA_HOME": str(self.root / "data"),
            "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        env.start()
        self.addCleanup(env.stop)
        workspace = self.root / "workspace"
        workspace.mkdir()
        self.store = Store(self.root / "state.db")
        self.addCleanup(self.store.close)
        self.app = App(workspace, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]

    def add(self, role, **values):
        return self.store.add_message(self.sid, role, values)

    def exchange(self, text, name="read"):
        call_id = f"call-{len(self.store.messages(self.sid))}"
        self.add("assistant", content="Still checking the evidence.", tool_calls=[{
            "id": call_id, "name": name, "arguments": {"filePath": "source.txt"}}])
        return self.add("tool", name=name, tool_call_id=call_id, content=text)

    def view(self):
        self.store.export_tool_history(self.sid)
        return _present_history(self.store.context_messages(self.sid), self.store, self.sid)

    def test_old_result_middle_stays_visible_after_more_tool_exchanges(self):
        self.add("user", content="Original commission; finish the outstanding review.")
        original = "head " * 1200 + "EXACT_REFERENCE_AND_UNFINISHED_CHECK" + " tail" * 1200
        old = self.exchange(original)
        for _ in range(4):
            self.exchange("New observation")
        todo = [{"id": "review", "content": "Outstanding review", "status": "pending", "priority": "medium"}]
        self.store.set_todos(self.sid, todo)
        before = copy.deepcopy(self.store.messages(self.sid))
        shown = self.view()
        self.assertIn(original, next(m["content"] for m in shown if m.get("id") == old["id"]))
        for original_message, presented in zip(before, shown):
            if original_message["role"] != "tool":
                self.assertEqual(original_message, presented)
        self.assertEqual(working_context(shown, self.store, self.sid), shown)
        self.assertEqual(self.store.todos(self.sid), todo)
        self.assertEqual(before, self.store.messages(self.sid))
        self.assertEqual(self.store.tool_output_path(self.sid, old["id"]).read_text(encoding="utf-8"), original)
        reopened = Store(self.store.path)
        try:
            reopened.export_tool_history(self.sid)
            self.assertEqual(shown, _present_history(reopened.context_messages(self.sid), reopened, self.sid))
        finally:
            reopened.close()

    def test_dependency_paths_are_not_replaced_by_a_projection(self):
        value = {"record_path": "exact-record", "depends_on": ["exact-input"],
                 "dependency_notice": "Notice\nDependency paths (one witness per selected root and differing ancestor):\n"
                 + "exact-record -> exact-input\n" * 100}
        original = json.dumps(value)
        reply = self.exchange(original, "research_record")
        self.exchange("Next result")
        self.exchange("Later result")
        shown = next(m["content"] for m in self.view() if m.get("id") == reply["id"])
        self.assertIn(original, shown)
        self.assertNotIn("Display-only projection", shown)

    def test_history_does_not_retruncate_saved_tool_body(self):
        original = "head " * 20000 + "EXACT_TAIL"
        reply = self.exchange(original)
        shown = next(m["content"] for m in self.view() if m.get("id") == reply["id"])
        path = self.store.tool_output_path(self.sid, reply["id"])
        self.assertEqual(shown, original)
        self.assertEqual(path.read_text(encoding="utf-8"), original)

    def test_actual_usage_compaction_receives_authoritative_history(self):
        self.add("user", content="Original unfinished task")
        original = "head " * 1200 + "EXACT_REFERENCE_AND_UNFINISHED_CHECK" + " tail" * 1200
        self.exchange(original)
        self.exchange("Next result")
        self.exchange("Later result")
        self.add("assistant", content="Long working account " * 10000,
                 finish_reason="stop", tokens={"total_tokens": 8000})
        self.app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=8000), "test"))

        class Captured(Exception):
            pass

        def capture(app, sid, history, *args, **kwargs):
            self.assertEqual(history, _present_history(app.store.context_messages(sid), app.store, sid))
            self.assertIn(original, "\n".join(m.get("content", "") for m in history if m["role"] == "tool"))
            raise Captured()

        with patch("opencode.loop._maybe_compact", side_effect=capture):
            with self.assertRaises(Captured):
                self.app.prompt(self.sid, "Continue")


if __name__ == "__main__":
    unittest.main()
