"""Host-source reading is counted and answered with where formats are documented."""

from pathlib import Path

import researchkit
from researchkit import host_source

HOST = Path(researchkit.__file__).resolve().parent


def call(name, **arguments):
    return {"name": name, "arguments": arguments}


def test_introspection_and_paths_into_the_host_are_host_reads():
    assert host_source.is_host_read(call("bash", command='python -c "import researchkit.records as r, inspect; '
                                                         'print(inspect.getsource(r))"'))
    assert host_source.is_host_read(call("read", filePath=str(HOST / "board.py")))
    assert host_source.is_host_read(call("bash", command=f'ls "{HOST}"'))


def test_research_use_of_the_host_is_not_a_host_read():
    assert not host_source.is_host_read(call("bash", command='python -c "from researchkit import calc; '
                                                             'print(calc.stats(x=[1, 2], y=[1, 3]))"'))
    assert not host_source.is_host_read(call("read", filePath=str(HOST / "skills/sample/SKILL.md")))
    assert not host_source.is_host_read(call("read", filePath="work/inspect_notes.md"))


def test_notice_appears_after_repeated_reads_only():
    read = {"role": "assistant", "tool_calls": [call("read", filePath=str(HOST / "records.py"))]}
    assert host_source.notice([read]) == ""
    text = host_source.notice([read, read])
    assert "2 次" in text and "from researchkit import calc" in text


def test_a_self_improvement_commission_gets_no_notice():
    read = {"role": "assistant", "tool_calls": [call("read", filePath=str(HOST / "records.py"))]}
    assert host_source.notice([read, read, read], self_improvement=True) == ""
    assert "文件缺口：" in host_source.notice([read, read, read])


def test_documentation_gaps_are_listed_apart_from_science_questions(tmp_path):
    from researchkit import board, graph
    graph.GraphStore(tmp_path).update({"expected_revision": None, "reason": "gap", "nodes": [
        {"id": "Q1", "type": "question", "status": "open", "reason": "r",
         "text": "文件缺口：report-delivery 沒有說明完整版型需要哪些標題"},
        {"id": "Q2", "type": "question", "status": "open", "reason": "r", "text": "Does Mw change the dose?"}]})
    text = board.render(board.build(tmp_path))
    gap_line = next(line for line in text.splitlines() if "文件缺口（給框架維護者" in line)
    assert "Q1" in gap_line and "Q2" not in gap_line and "question Q2" in text and "question Q1" not in text
