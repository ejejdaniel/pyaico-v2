"""Active and deferred hypotheses, the hypothesis budget, and host-computed lever facts; no model calls."""

import json

import pytest

from researchkit import board, records


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def hypotheses(*items, **extra):
    return {"hypotheses": [{"id": f"H{i}", "statement": f"mechanism {i}", **item} for i, item in enumerate(items, 1)],
            **extra}


def texts(root, **kwargs):
    return [item["text"] for item in board.build(root, **kwargs)["notice_items"]]


def test_a_hypothesis_queued_by_the_budget_needs_no_formula_yet_and_is_listed(tmp_path):
    queued = {"proxy_status": {"status": "deferred", "basis": "budget", "reason": "rank 4 of 4"}}
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses({}, queued)})
    found = texts(tmp_path)
    missing = next(t for t in found if "沒有對應公式的假說" in t)
    assert "H1" in missing and "H2" not in missing
    assert any("因預算排隊的假說：H2（rank 4 of 4）" in t and "不是無法檢驗" in t for t in found)
    assert not any("沒有標示" in t for t in found)


def actions(root):
    return [item["text"] for item in board.build(root)["notice_items"] if item["level"] == "action"]


@pytest.mark.parametrize("status", [
    {"status": "deferred", "reason": "lever constant on both records"},       # v16: history cannot test it
    {"status": "deferred", "basis": "scope", "reason": "PEB is not in the data"},  # the design space may grow
    {"status": "deferred"},                                                     # no reason at all
])
def test_holding_back_a_hypothesis_for_anything_but_the_budget_is_flagged(tmp_path, status):
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses({}, {"proxy_status": status})})
    flagged = [t for t in actions(tmp_path) if "沒有標示" in t]
    assert len(flagged) == 1 and "H2" in flagged[0] and "延後只能是預算排隊" in flagged[0]
    assert not any("沒有對應公式的假說：H1、H2" in t for t in texts(tmp_path))  # still not counted as active


def test_not_computable_names_what_is_missing(tmp_path):
    # N3 of v34 invented a split of a salt rather than say what it lacked; "not computable" is an honest
    # status when it names the measurement or tool that would settle the sign.
    bare = {"proxy_status": {"status": "not_computable", "reason": "needs DFT"}}
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses({}, bare)})
    flagged = [t for t in actions(tmp_path) if "沒有寫 missing" in t]
    assert len(flagged) == 1 and "H2" in flagged[0] and "最後手段" not in flagged[0]
    for name, status in (("missing", {"missing": "segregation profile by XPS depth scan"}),
                         ("tried", {"tried": [{"proxy": "group contribution", "why_not": "no fragment values"}]})):
        other = tmp_path / name
        other.mkdir()
        save(other, "hypothesis", {"h/hypotheses.json": hypotheses(
            {}, {"proxy_status": {"status": "not_computable", "reason": "needs DFT", **status}})})
        assert not any("沒有寫 missing" in t for t in actions(other))


def test_a_merged_hypothesis_needs_no_formula_and_must_name_a_sibling(tmp_path):
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses(
        {}, {"proxy_status": {"status": "merged", "into": "H1"}}, {"proxy_status": {"status": "merged", "into": "H9"}})})
    found = texts(tmp_path)
    missing = next(t for t in found if "沒有對應公式的假說" in t)
    assert "H1" in missing and "H2" not in missing and "H3" not in missing
    assert any("H3 標為 merged" in t and "H9" in t for t in found)
    assert "主動 1、排隊 0、無法計算 0、合併 2" in board.render(board.build(tmp_path))


def test_more_active_hypotheses_than_the_budget_gets_a_notice(tmp_path):
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses({}, {}, {}, {},
                                                                    {"proxy_status": {"status": "deferred",
                                                                                      "reason": "later"}})})
    assert any("4 個主動假說，超過預算 3" in t for t in texts(tmp_path))
    assert not any("超過預算" in t for t in texts(tmp_path, hypothesis_budget=4))
    assert board.configured_budget({"research": {"hypothesis_budget": 5}}) == 5
    assert board.configured_budget({}) is None


def test_lever_facts_from_a_csv_table(tmp_path):
    table = save(tmp_path, "prepared_data", {"d/history.csv": "id,mw,pag_gain\nH1,7,0.30\nH2,9,0.300\n"})
    selection = {"record_ref": table["record_path"], "source_path": "d/history.csv"}
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses(
        {"levers": ["mw"]}, {"levers": ["pag_gain", "quencher"]}, lever_table=selection)})
    items = board.build(tmp_path)["hypotheses"][0]["items"]
    assert items[0]["lever_facts"] == {"mw": "varies"}
    assert items[1]["lever_facts"] == {"pag_gain": "constant", "quencher": "missing"}  # 0.30 == 0.300
    rendered = board.render(board.build(tmp_path))
    assert "槓桿 mw（歷史有變化）" in rendered and "pag_gain（歷史相同）" in rendered


def test_lever_facts_from_json_rows_with_nested_descriptors(tmp_path):
    rows = {"H1": {"descriptors": {"ester_index": 0.74, "pag_gain": 0.3}},
            "H2": {"descriptors": {"ester_index": 0.91, "pag_gain": 0.3}}}
    table = save(tmp_path, "implementation", {"v/values_historical.json": rows})
    selection = {"record_ref": table["record_path"], "source_path": "v/values_historical.json"}
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses(
        {"levers": ["descriptors.ester_index", "descriptors.pag_gain"]}, lever_table=selection)})
    facts = board.build(tmp_path)["hypotheses"][0]["items"][0]["lever_facts"]
    assert facts == {"descriptors.ester_index": "varies", "descriptors.pag_gain": "constant"}


def test_a_malformed_lever_table_is_reported_not_guessed(tmp_path):
    save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses({"levers": ["mw"]}, lever_table="d/history.csv")})
    assert any("lever_table 需為" in t for t in texts(tmp_path))
    assert board.build(tmp_path)["hypotheses"][0]["items"][0]["lever_facts"] is None
