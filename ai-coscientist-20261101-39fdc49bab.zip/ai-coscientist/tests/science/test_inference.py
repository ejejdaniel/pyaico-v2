"""Deterministic source, process and publication boundaries; no model calls."""

from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import threading
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

from researchkit import inference, records
from researchkit.tools import TOOLS


@pytest.fixture
def syntax_problem():
    # Schema/parser-only tests need no filesystem publication. This reference is
    # never read or used as a substitute for evidence in an execution test.
    cite = lambda line, quote: {"record_ref": ".research/records/" + "0" * 64 + "/record.json", "source_path": "source.txt",
                               "start_line": line, "end_line": line, "quote": quote}
    problem = {"scope": "Test formal implication, not scientific support",
               "goal": {"source": cite(3, "Claim: x is positive."), "expr": "(> x 0)",
                        "interpretation": "The test's claimed positive variable"},
               "variables": [{"name": "x", "sort": "Real", "meaning": "Formal test quantity", "unit": "1"}],
               "premises": [{"id": "p1", "origin": "source", "expr": "(>= x 1)",
                            "sources": [cite(2, "Premise: x is at least one.")],
                            "interpretation": "The cited lower bound"}]}
    return problem


@pytest.fixture
def source_problem(tmp_path, syntax_problem):
    source = tmp_path / "source.txt"
    source.write_bytes(b"Formal test fixture only.\r\nPremise: x is at least one.\r\nClaim: x is positive.\r\n")
    record = records.publish(tmp_path, kind="implementation", title="Boundary test input",
                             files=["source.txt"], depends_on=[])
    problem = deepcopy(syntax_problem)
    for citation in inference._citations(problem):
        citation["record_ref"] = record["record_path"]
    return tmp_path, problem, record


def result_from(root, receipt):
    file = next(f for f in receipt["files"] if f["source_path"].endswith("/result.json"))
    return json.loads(Path(file["snapshot"]).read_text(encoding="utf-8"))


def test_frozen_sources_not_working_files_and_normalized_quote(source_problem):
    root, problem, record = source_problem
    (root / "source.txt").write_text("Changed working text", encoding="utf-8")
    problem["goal"]["source"].update(start_line=2, quote="Premise: x is at least one.\nClaim: x is positive.")
    assert inference.validate_sources(root, inference.validate_input(problem)) == [record["record_path"]]


@pytest.mark.parametrize("mutation", [
    lambda c: c.update(start_line=True), lambda c: c.update(start_line=3, end_line=2),
    lambda c: c.update(end_line=4), lambda c: c.update(quote="Claim:  x is positive."),
    lambda c: c.update(start_line=2, end_line=2), lambda c: c.update(source_path="missing.txt"),
])
def test_locator_rejects_bad_range_or_nonliteral_quote(source_problem, mutation):
    root, problem, _ = source_problem
    mutation(problem["goal"]["source"])
    with pytest.raises(Exception):
        problem = inference.validate_input(problem)
        inference.validate_sources(root, problem)


def test_tampered_snapshot_stops_before_computation(source_problem):
    root, problem, record = source_problem
    frozen = root / Path(record["record_path"]).parent / record["files"][0]["snapshot"]
    frozen.write_bytes(b"changed snapshot")
    with patch.object(inference, "_compute", side_effect=AssertionError("must not compute")):
        with pytest.raises(ValueError, match="hash or bytes"):
            inference.run(problem, root, root / "run")
    assert not (root / "run").exists()


@pytest.mark.parametrize("mutation", [
    lambda p: p.update(unapproved=True),
    lambda p: p["variables"][0].update(unit=None),
    lambda p: p["variables"][0].update(sort="Bool", unit="1"),
    lambda p: p["premises"][0].update(sources=[]),
    lambda p: p["goal"].update(interpretation=" "),
    lambda p: p["premises"][0].update(expr="( > x 0 )"),
    lambda p: p["premises"][0].update(expr="(and true (and (> x 0) true))"),
])
def test_invalid_input_and_direct_conclusion_are_rejected(syntax_problem, mutation):
    problem = syntax_problem
    mutation(problem)
    with pytest.raises(Exception):
        inference.validate_input(problem)


def test_raw_json_duplicate_keys_nonfinite_and_size_rejected(syntax_problem):
    problem = syntax_problem
    raw = json.dumps(problem)
    duplicate = raw.replace('"scope":', '"scope": "first", "scope":', 1)
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        inference.validate_input(duplicate)
    with pytest.raises(ValueError, match="Invalid JSON constant"):
        inference.parse_json('{"x":NaN}')
    problem["scope"] = "x" * inference.MAX_BYTES
    with pytest.raises(ValueError, match="262144"):
        inference.validate_input(problem)


def test_parsed_common_argument_cannot_recover_discarded_duplicate_keys(syntax_problem):
    from opencode.provider import _parse_args
    raw = json.dumps(syntax_problem).replace('"scope":', '"scope": "discarded", "scope":', 1)
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        inference.validate_input(raw)
    # Document the unchanged upstream boundary, not a claimed end-to-end guard.
    parsed = _parse_args(raw)
    assert parsed == syntax_problem
    assert inference.validate_input(parsed) == syntax_problem


def test_actual_solver_freezes_input_result_and_dependency_without_verdict(source_problem):
    pytest.importorskip("z3")
    root, problem, record = source_problem
    with patch("researchkit.review_provider.complete_once", side_effect=AssertionError("No model")):
        saved = inference.run(problem, root, root / "run")
    result = result_from(root, saved)
    assert [q["status"] for q in result["queries"]] == ["sat", "unsat", "not_run", "not_run"]
    assert result["solver_version"] == "4.15.4"
    assert set(result) == {"input_sha256", "solver_version", "elapsed_ms", "queries"}
    assert result["input_sha256"] == records.digest((root / "run/input.json").read_bytes())
    assert saved["kind"] == "implementation" and saved["depends_on"] == [record["record_path"]]
    assert records.read_record(root, saved["record_path"])["kind"] == "implementation"
    assert not list(root.rglob("review.json"))
    assert json.loads((root / "run/input.json").read_text(encoding="utf-8")) == problem


@pytest.mark.parametrize("drift", [None, "working", "frozen"])
def test_tool_returns_verified_frozen_result_and_keeps_manifest_format(source_problem, drift):
    from opencode.permission import Broker, Rule
    pytest.importorskip("z3")
    root, problem, source = source_problem
    ctx = SimpleNamespace(directory=root, worktree=root, session_id="offline-tool-result",
                          agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
                          app=SimpleNamespace(permissions=Broker(auto=True)))
    original = inference.run
    captured = {}

    def saved_run(*args, **kwargs):
        saved = original(*args, **kwargs)
        entry, = [item for item in saved["files"] if item["source_path"].endswith("/result.json")]
        captured["result"] = json.loads(Path(entry["snapshot"]).read_text(encoding="utf-8"))
        captured["record_path"] = saved["record_path"]
        if drift:
            target = root / entry["source_path"] if drift == "working" else Path(entry["snapshot"])
            target.write_text('{"not_a_solver_result": true}', encoding="utf-8")
        return saved

    tool = next(t for t in TOOLS if t.name == "check_inference")
    with patch.object(inference, "run", side_effect=saved_run):
        if drift == "frozen":
            with pytest.raises(ValueError, match="hash or bytes"):
                tool.execute(problem, ctx)
            return
        receipt = json.loads(tool.execute(problem, ctx).output)
    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on", "result"}
    assert receipt["result"] == captured["result"]
    assert receipt["depends_on"] == [source["record_path"]]
    stored = records.read_record(root, captured["record_path"])
    assert set(stored) == {"kind", "title", "files", "depends_on"}
    assert "result" not in stored
    assert [query["status"] for query in receipt["result"]["queries"]] == [
        "sat", "unsat", "not_run", "not_run"]


def test_source_permissions_and_preflight_dependency_failure_do_not_spawn(source_problem):
    root, problem, _ = source_problem
    def deny(path):
        raise PermissionError("no read")
    with patch.object(inference.subprocess, "Popen", side_effect=AssertionError("must not spawn")):
        with pytest.raises(PermissionError):
            inference.run(problem, root, root / "denied", check_read=deny)
    assert not (root / "denied").exists()
    with patch.object(inference.records, "_read_dependencies", side_effect=ValueError("missing dependency")):
        with pytest.raises(ValueError, match="missing dependency"):
            inference.run(problem, root, root / "missing")
    assert not (root / "missing").exists()


def test_tool_permission_failure_occurs_before_writes_or_solver(source_problem):
    root, problem, _ = source_problem
    tool = next(t for t in TOOLS if t.name == "check_inference")
    ctx = SimpleNamespace(directory=root, session_id="test", agent=SimpleNamespace(permission=[]),
                          app=SimpleNamespace(permissions=SimpleNamespace(ask=Mock())))
    with patch.object(inference, "ensure_access", side_effect=PermissionError("edit denied")):
        with patch.object(inference, "run", side_effect=AssertionError("must not run")):
            with pytest.raises(PermissionError):
                tool.execute(problem, ctx)
    assert not (root / ".research/inference-runs").exists()


def test_named_permission_denial_stops_tool_before_file_access(source_problem):
    from opencode.permission import Broker, Rule, PermissionDenied
    root, problem, _ = source_problem
    ctx = SimpleNamespace(directory=root, session_id="test", agent=SimpleNamespace(permission=[
        Rule("*", "*", "allow"), Rule("check_inference", "*", "deny")]),
        app=SimpleNamespace(permissions=Broker(auto=True)))
    with patch.object(inference, "ensure_access", side_effect=AssertionError("must not access files")):
        with pytest.raises(PermissionDenied):
            inference.execute(problem, ctx)
    assert not (root / ".research/inference-runs").exists()


def slow_worker_with_committed_query(folder, problem):
    # A process-lifetime fixture, explicitly not a solver result in a real flow.
    first = {"name": "base_consistency", "status": "sat", "reason": None,
             "elapsed_ms": 1, "values": {"x": "1.0"}, "core_ids": None}
    for suffix, contents in (("json", json.dumps(first)), ("smt2", "(check-sat)"), ("txt", "sat")):
        (folder / f"base_consistency.{suffix}").write_text(contents, encoding="utf-8")
    (folder / "base_counterexample.smt2").write_text("; active query fixture", encoding="utf-8")


@pytest.mark.parametrize("cancel", [False, True])
def test_process_termination_preserves_completed_query_and_stops_following(source_problem, cancel):
    root, problem, _ = source_problem
    folder = root / "process-test"
    folder.mkdir()
    (folder / "input.json").write_bytes(records.encoded(problem))
    abort = threading.Event()
    children = []
    real_popen = subprocess.Popen
    def launch(command, **kwargs):
        slow_worker_with_committed_query(folder, problem)
        process = real_popen([sys.executable, "-c", "import time; print('fixture-version',flush=True); time.sleep(20)"], **kwargs)
        children.append(process)
        if cancel:
            abort.set()
        return process
    with patch.object(inference.subprocess, "Popen", side_effect=launch), patch.object(inference, "COMPUTE_SECONDS", 0.15):
        outcome = inference._compute(problem, folder, abort)
    assert children[0].poll() is not None
    assert [q["status"] for q in outcome["queries"]] == [
        "sat", "cancelled" if cancel else "timeout", "not_run", "not_run"]
    assert outcome["queries"][0]["values"] == {"x": "1.0"}
    assert outcome["queries"][1]["values"] is None
    assert (folder / "base_consistency.json").exists()
    assert not (folder / "full_consistency.smt2").exists()
    for query in outcome["queries"]:
        assert json.loads((folder / f"{query['name']}.json").read_text(encoding="utf-8")) == query


def test_execution_error_is_frozen_but_not_returned_as_success(source_problem):
    root, problem, _ = source_problem
    def failed_run(problem, folder, abort):
        (folder / "stderr.txt").write_text("dependency missing", encoding="utf-8")
        outcome = {"input_sha256": records.digest((folder / "input.json").read_bytes()),
                "solver_version": None, "elapsed_ms": 1,
                "queries": [inference._query(name, "error" if i == 0 else "not_run", "dependency missing")
                            for i, name in enumerate(inference.QUERY_NAMES)]}
        for query in outcome["queries"]:
            (folder / f"{query['name']}.json").write_bytes(records.encoded(query))
        return outcome
    with patch.object(inference, "_compute", side_effect=failed_run):
        with pytest.raises(RuntimeError, match="preserved implementation record"):
            inference.run(problem, root, root / "failed")
    result = json.loads((root / "failed/result.json").read_text(encoding="utf-8"))
    assert result["queries"][0]["status"] == "error"
    assert len(records.inventory(root)) == 2


def test_input_drift_during_execution_cannot_be_published(source_problem):
    root, problem, _ = source_problem
    def changed(problem, folder, abort):
        (folder / "input.json").write_text("{}", encoding="utf-8")
        return {}
    with patch.object(inference, "_compute", side_effect=changed):
        with pytest.raises(RuntimeError, match="input changed"):
            inference.run(problem, root, root / "drift")
    assert len(records.inventory(root)) == 1


@pytest.mark.parametrize("changed_file", ["input.json", "result.json", "base_consistency.json", "base_consistency.smt2"])
def test_publish_sampling_race_rejected_after_frozen_readback(source_problem, changed_file):
    pytest.importorskip("z3")
    root, problem, _ = source_problem
    original = records.publish
    def change_then_publish(*args, **kwargs):
        selected = next(name for name in kwargs["files"] if Path(name).name == changed_file)
        with (root / selected).open("ab") as stream:
            stream.write(b"\n ")
        return original(*args, **kwargs)
    with patch.object(inference.records, "publish", side_effect=change_then_publish):
        with pytest.raises(RuntimeError, match="Published inference bytes differ"):
            inference.run(problem, root, root / "publish-race")
    # A failed attempt is preserved, never silently repaired or returned as valid.
    assert (root / "publish-race" / changed_file).exists()


def test_worker_exit_does_not_bypass_shared_deadline(source_problem):
    root, problem, _ = source_problem
    folder = root / "late-exit"
    folder.mkdir()
    (folder / "input.json").write_bytes(records.encoded(problem))
    def complete_ledger(command, **kwargs):
        slow_worker_with_committed_query(folder, problem)
        for name in inference.QUERY_NAMES[1:]:
            (folder / f"{name}.json").write_bytes(records.encoded(inference._query(name, reason="Fixture completed ledger")))
        return SimpleNamespace(poll=lambda: 0, returncode=0)
    # inference's own clock, not the shared time module: another thread of the test process would read it too.
    clock = SimpleNamespace(monotonic=Mock(side_effect=[0.0, 31.0, 31.0]), sleep=inference.time.sleep)
    with patch.object(inference.subprocess, "Popen", side_effect=complete_ledger), \
            patch.object(inference, "time", clock):
        with pytest.raises(RuntimeError, match="deadline expired before worker completion"):
            inference._compute(problem, folder)
    assert (folder / "base_consistency.json").exists()
    assert not (folder / "result.json").exists()
