"""Exact citation location and canonical-byte boundaries; no model calls."""
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

import pytest

from researchkit import inference, records


def problem_at(root, text, quote):
    (root / "source.txt").write_bytes(text)
    saved = records.publish(root, kind="implementation", title="Literal location fixture",
                            files=["source.txt"], depends_on=[])
    return {"scope": "Exercise literal location only", "goal": {
        "source": {"record_ref": saved["record_path"], "source_path": "source.txt", "quote": quote},
        "expr": "true", "interpretation": "Boolean fixture"}, "variables": [], "premises": []}


@pytest.mark.parametrize("raw,quote,expected", [
    (b"first\r\nclaim\r\nlast\r\n", "claim", (2, 2)),
    (b"first\rclaim\rlast\r", "claim\r\nlast", (2, 3)),
    (b"first\nclaim\nlast\n", "claim\n", (2, 3)),
    (b"\xef\xbb\xbffirst\nclaim\n", "claim", (2, 2)),
    ("前\n主張😀\n後\n".encode(), "主張😀", (2, 2)),
    ("前\u2028主張\n後".encode(), "主張", (1, 1)),
    (b"\n\n  claim  \n", "  claim  ", (3, 3)),
])
def test_unique_location_preserves_quote_and_caller(tmp_path, raw, quote, expected):
    args = problem_at(tmp_path, raw, quote)
    before = deepcopy(args)
    value = inference.validate_input(args)
    inference.validate_sources(tmp_path, value)
    cite = value["goal"]["source"]
    assert (cite["start_line"], cite["end_line"]) == expected
    assert cite["quote"] == quote and args == before
    assert inference.validate_sources(tmp_path, value)


@pytest.mark.parametrize("text,quote", [
    (b"aaa", "aa"), (b"claim\nclaim", "claim"), (b"claim", "Claim"),
    (b"claim\n", "claim\n"), (b"two  words", "two words"),
])
def test_ambiguous_missing_or_changed_text_rejected(tmp_path, text, quote):
    value = inference.validate_input(problem_at(tmp_path, text, quote))
    with pytest.raises(ValueError):
        inference.validate_sources(tmp_path, value)


@pytest.mark.parametrize("fields", [{"start_line": 1}, {"end_line": 1},
                                    {"start_line": None, "end_line": None},
                                    {"start_line": True, "end_line": 2}])
def test_line_pair_invalid_types(tmp_path, fields):
    args = problem_at(tmp_path, b"first\nclaim\n", "claim")
    args["goal"]["source"].update(fields)
    with pytest.raises(Exception):
        value = inference.validate_input(args)
        inference.validate_sources(tmp_path, value)


def test_explicit_wrong_lines_do_not_move(tmp_path):
    args = problem_at(tmp_path, b"first\nclaim\n", "claim")
    args["goal"]["source"].update(start_line=1, end_line=1)
    with pytest.raises(ValueError, match="contiguous"):
        inference.validate_sources(tmp_path, inference.validate_input(args))


def test_explicit_range_can_disambiguate(tmp_path):
    args = problem_at(tmp_path, b"claim\nclaim", "claim")
    args["goal"]["source"].update(start_line=2, end_line=2)
    assert inference.validate_sources(tmp_path, inference.validate_input(args))


def test_size_rechecked_after_line_insertion(tmp_path):
    args = problem_at(tmp_path, b"first\nclaim", "claim")
    with patch.object(inference, "MAX_BYTES", len(records.encoded(args))):
        value = inference.validate_input(args)
        with pytest.raises(ValueError, match="after citation location"):
            inference.validate_sources(tmp_path, value)


def test_expected_input_and_bad_dependencies_fail_before_compute(tmp_path):
    args = problem_at(tmp_path, b"claim", "claim")
    with patch.object(inference, "_compute", side_effect=AssertionError("must not compute")):
        with pytest.raises(ValueError, match="frozen bytes"):
            inference.run(args, tmp_path, tmp_path / "run", expected_input=b"wrong")
        canonical = inference.validate_input(args)
        inference.validate_sources(tmp_path, canonical)
        with pytest.raises(Exception):
            inference.run(args, tmp_path, tmp_path / "run", expected_input=records.encoded(canonical),
                          extra_dependencies=(".research/records/" + "0" * 64 + "/record.json",))
    assert not (tmp_path / "run").exists()
