from __future__ import annotations

import pytest

from researchkit.inference_expr import InferenceExpressionError, validate_expressions


def problem(goal="(> x 0)", premises=(), variables=None):
    citation = {"record_ref": "source:1", "source_path": "source.txt", "start_line": 1, "end_line": 1, "quote": "Claim"}
    return {
        "scope": "Formal entailment within these explicitly supplied statements",
        "goal": {"source": citation, "expr": goal, "interpretation": "Target statement"},
        "variables": variables if variables is not None else [
            {"name": "x", "sort": "Real", "meaning": "A declared quantity", "unit": None},
            {"name": "flag", "sort": "Bool", "meaning": "A declared proposition", "unit": None},
        ],
        "premises": [
            {"id": f"p{index}", "origin": "source", "expr": expression, "sources": [citation], "interpretation": "A supplied statement"}
            for index, expression in enumerate(premises)
        ],
    }


@pytest.mark.parametrize("expression", [
    "(> (+ x 1) (* x x))", "(<= (- x 2 3) (/ (- 1) 3))",
    "(= (/ 1 (- 2)) (- (/ 1 2)))", "(= flag (not false))",
    "(=> flag (> x 0) (or true false))", "(< 0 x 3)",
    "(and (> x 0) (< x 3))", "(= x 1 2)",
])
def test_accepts_typed_polynomial_and_boolean_expressions(expression):
    variables, goal, premises = validate_expressions(problem(expression))
    assert variables == {"x": "Real", "flag": "Bool"}
    assert goal[0] == "call"
    assert premises == {}


@pytest.mark.parametrize("expression", [
    "(> x 0.1)", "(> x -1)", "(> x 1e2)", "(> x 01)",
    "(> (/ x 2) 0)", "(> (/ 1 x) 0)", "(> (/ (+ 1 1) 2) 0)",
    "(> (/ 1 0) 0)", "(> (/ 1 (- 0)) 0)", "(> (^ x 2) 0)",
    "(forall ((y Real)) (> y 0))", "(exists ((y Real)) (> y 0))",
    "(ite flag true false)", "(let ((y x)) (> y 0))", "(f x)",
    "(> y 0)", "(> |x| 0)", "(> x #x10)", "(> x 0); comment",
    "(> flag 0)", "(and flag x)", "(= flag 1)", "(+ x 1)",
    "(> x 0) true", "(> x 0", "", "()", "(and)", "(not true false)",
])
def test_rejects_unsupported_syntax_and_wrong_types(expression):
    with pytest.raises(InferenceExpressionError):
        validate_expressions(problem(expression))


@pytest.mark.parametrize("name", ["and", "Real", "let", "1x", "_x", "x-y", "變數", "a" * 65])
def test_rejects_invalid_or_reserved_identifiers(name):
    request = problem("true", variables=[{"name": name, "sort": "Real"}])
    with pytest.raises(InferenceExpressionError, match="identifier"):
        validate_expressions(request)


def test_identifiers_are_unique_across_variables_and_premises():
    request = problem(premises=["(< x 0)"])
    request["premises"][0]["id"] = "x"
    with pytest.raises(InferenceExpressionError, match="duplicate"):
        validate_expressions(request)
    request = problem()
    request["variables"].append(dict(request["variables"][0]))
    with pytest.raises(InferenceExpressionError, match="duplicate"):
        validate_expressions(request)


def test_rejects_count_and_expression_size_limits():
    request = problem("true", variables=[{"name": f"x{i}", "sort": "Real"} for i in range(33)])
    with pytest.raises(InferenceExpressionError, match="at most 32"):
        validate_expressions(request)
    with pytest.raises(InferenceExpressionError, match="at most 64"):
        validate_expressions(problem(premises=["true"] * 65))
    with pytest.raises(InferenceExpressionError, match="8192"):
        validate_expressions(problem("true" + " " * 8192))


def test_depth_limit_and_large_exact_integer_do_not_use_python_eval():
    validate_expressions(problem("(not " * 63 + "true" + ")" * 63))
    with pytest.raises(InferenceExpressionError, match="depth 64"):
        validate_expressions(problem("(not " * 64 + "true" + ")" * 64))
    validate_expressions(problem("(> x " + "9" * 5000 + ")"))


@pytest.mark.parametrize("premise", [
    "(> x 0)", "(and flag (> x 0))", "(and flag (and true (> x 0)))",
])
def test_rejects_goal_as_premise_or_top_level_conjunct(premise):
    with pytest.raises(InferenceExpressionError, match="goal is used directly"):
        validate_expressions(problem(premises=[premise]))


def test_direct_goal_detection_is_syntactic_not_scientific_or_semantic():
    validate_expressions(problem(premises=["(> (+ x 0) 0)", "(or flag (> x 0))", "(=> flag (> x 0))"]))
    validate_expressions(problem("(= x (/ 1 2))", ["(= x (/ 2 4))"]))
    with pytest.raises(InferenceExpressionError, match="goal is used directly"):
        validate_expressions(problem("(and flag (> x 0))", ["(and true (and flag (> x 0)))"]))


def test_scientific_descriptions_do_not_change_formal_parsing():
    request = problem(premises=["(>= x 1)"])
    original = validate_expressions(request)
    request["scope"] = "Unrelated wording"
    request["variables"][0]["meaning"] = "negative low weak unsupported"
    request["goal"]["interpretation"] = "positive high strong supported"
    request["premises"][0]["interpretation"] = "A contradictory scientific narrative"
    assert validate_expressions(request) == original
