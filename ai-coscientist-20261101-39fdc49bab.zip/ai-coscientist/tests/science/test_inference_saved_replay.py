"""Real saved evidence only: local solver and citation handoff, without a model."""

from copy import deepcopy
from unittest.mock import patch

import pytest

from researchkit import records, review
from researchkit.tools import TOOLS
from scripts import replay_check_inference as replay


@pytest.fixture(scope="module")
def saved_result(tmp_path_factory):
    required = [replay.SOURCE / replay.REPORT_REF,
                replay.REVIEW_SOURCE / "live/arguments.json",
                replay.REVIEW_SOURCE / "live/final-answer-002.txt",
                replay.REVIEW_SOURCE / "live/review.json"]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        pytest.skip("Saved real evidence unavailable; no synthetic replacement: " + ", ".join(missing))
    try:
        replay._closure_files(replay.SOURCE)
        sparse_paths = replay._selected_frozen_paths(
            replay.REVIEW_SOURCE / "workspace", replay._json(replay.REVIEW_SOURCE / "live/arguments.json"))
        missing = [str(path) for path in sparse_paths if not path.is_file()]
        if missing:
            pytest.skip("Saved review snapshots unavailable; no synthetic replacement: " + ", ".join(missing))
    except FileNotFoundError as exc:
        pytest.skip(f"Saved real evidence closure unavailable; no synthetic replacement: {exc}")
    pytest.importorskip("z3")
    output = tmp_path_factory.mktemp("saved-inference-parent") / "replay"
    tool, = [tool for tool in TOOLS if tool.name == "check_inference"]
    with patch.object(tool, "execute", wraps=tool.execute) as execute:
        summary = replay.replay(output)
    assert execute.call_count == 1
    return output, summary


def test_saved_case_uses_formal_tool_and_independent_exact_countermodels(saved_result):
    output, summary = saved_result
    assert summary["source_record_count"] == 13
    assert summary["source_snapshot_count"] == 45
    assert summary["original_evidence_unchanged"]
    assert summary["copied_original_evidence_unchanged"]
    assert summary["query_statuses"] == {
        name: "sat" for name in ("base_consistency", "base_counterexample",
                                "full_consistency", "full_counterexample")
    }
    assert summary["independent_exact_rational_witness_checks"]
    assert summary["blocked_network_attempts"] == []
    assert summary["live_model_calls"] == 0
    assert not summary["scientific_acceptance"]
    assert not summary["full_end_to_end_passed"]
    assert replay._json(output / "source-hashes-before.json") == replay._json(output / "source-hashes-after.json")
    root = output / "workspace"
    receipt = replay._json(output / "tool-receipt.json")
    committed = records.read_record(root, receipt["record_path"])
    assert committed["kind"] == "implementation"
    assert committed["depends_on"] == [replay.REPORT_REF, replay.FORMULA_REF]
    complete = records._read_dependencies(root, [receipt["record_path"]])
    assert len(complete) == summary["source_record_count"] + 1
    assert not (root / "reports/formal_report.md").exists(), "Must copy frozen evidence, not mutable working files"
    witness = replay._json(output / "independent-rational-witness-checks.json")["full_counterexample"]
    assert witness["source_ordering_holds"] and witness["added_assumptions_hold"]
    assert not witness["equal_product_goal_holds"]
    # Check relations, not a hand-selected expected numerical model.
    e1, e2, r1, r2 = (replay.Fraction(witness["exact_rational_values"][name])
                      for name in ("E1", "E2", "r1", "r2"))
    assert 0 < e1 < e2 and 0 < r2 < r1 and e1 * r1 != e2 * r2


def test_new_evidence_reaches_review_without_rewriting_historical_judgments(saved_result):
    output, summary = saved_result
    boundary = summary["review_boundary"]
    assert boundary["original_selected_file_count"] == 12
    assert boundary["appended_selected_file_count"] == 4
    assert boundary["historical_checks"] == 11
    assert boundary["historical_review_bytes_unchanged"]
    assert boundary["historical_line_138_still_unassessed"]
    assert not boundary["new_review_published"] and not boundary["request_sent"]
    original = replay._json(replay.REVIEW_SOURCE / "live/arguments.json")
    expanded = replay._json(output / "review-arguments-not-sent.json")
    assert expanded["files"][:12] == original["files"]
    assert expanded["reviewed_refs"] == original["reviewed_refs"]
    assert (output / "historical-review-reassembled.json").read_bytes() == (
        replay.REVIEW_SOURCE / "live/review.json").read_bytes()
    packet = replay._json(output / "review-request-not-sent.json")
    receipt = replay._json(output / "tool-receipt.json")
    assert "NOT sent" in packet["offline_note"]
    assert receipt["record_path"] in packet["messages"][1]["content"]
    probe = replay._json(output / "structural-probe-unassessed.json")
    check, = probe["checks"]
    assert check["decision"] == "unassessed"
    assert check["subject"]["quote"] == replay.GOAL_QUOTE
    assert check["subject"]["record_ref"] == replay.REPORT_REF
    assert {entry["record_ref"] for entry in check["evidence"]} == {receipt["record_path"], replay.FORMULA_REF}
    assert any(entry["source_path"].endswith("/result.json") for entry in check["evidence"])
    assert all(record["kind"] != "review" for record in records.inventory(output / "workspace"))


def test_validator_reads_new_result_citation_and_rejects_modified_quote(saved_result):
    output, _ = saved_result
    root = output / "workspace"
    probe = replay._json(output / "structural-probe-unassessed.json")
    args = replay._json(output / "review-arguments-not-sent.json")
    dependencies = list(dict.fromkeys(item["record_ref"] for item in args["files"]))
    verified = records._read_dependencies(root, dependencies)
    review.validate(root, records.encoded(probe), dependencies, verified)
    changed = deepcopy(probe)
    citation, = [entry for entry in changed["checks"][0]["evidence"]
                 if entry["source_path"].endswith("/result.json")]
    citation["quote"] += "\nOFFLINE_TEST_UNRECORDED_QUOTE_MUST_BE_REJECTED"
    with pytest.raises(ValueError, match="literal quote not found"):
        review.validate(root, records.encoded(changed), dependencies, verified)


def test_missing_saved_evidence_fails_without_creating_demo(tmp_path):
    output = tmp_path / "output"
    with pytest.raises(FileNotFoundError):
        replay.replay(output, source=tmp_path / "unavailable-source")
    assert not output.exists()
