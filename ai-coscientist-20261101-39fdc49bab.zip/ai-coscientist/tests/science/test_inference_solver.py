from __future__ import annotations

import builtins
import json
import subprocess
import sys
import time
from types import SimpleNamespace

import pytest

from researchkit import inference_worker as worker


def problem(goal="(> x 0)", source=(), assumptions=(), variables=None):
    citation = {"record_ref": "source:1", "source_path": "source.txt", "start_line": 1, "end_line": 1, "quote": "Claim"}
    request = {
        "scope": "Formal inference only; source adequacy and scientific validity require review",
        "goal": {"source": citation, "expr": goal, "interpretation": "Target statement"},
        "variables": variables if variables is not None else [
            {"name": "x", "sort": "Real", "meaning": "A declared quantity", "unit": None},
        ],
        "premises": [],
    }
    for origin, expressions in (("source", source), ("assumption", assumptions)):
        for index, expression in enumerate(expressions):
            request["premises"].append({
                "id": f"{origin}{index}", "origin": origin, "expr": expression,
                "sources": [citation] if origin == "source" else [], "interpretation": "Supplied statement",
            })
    return request


@pytest.fixture
def z3():
    return pytest.importorskip("z3", reason="The explicitly installed inference extra is required")


def run(request, tmp_path, z3):
    return worker.run_worker(request, tmp_path, time.monotonic() + 30, z3)


def test_consistent_source_proves_only_formal_entailment(tmp_path, z3):
    results = run(problem(source=["(>= x 1)"]), tmp_path, z3)
    assert [query["status"] for query in results] == ["sat", "unsat", "not_run", "not_run"]
    assert set(results[1]["core_ids"]) == {"source0", "__negated_goal"}
    for query in results:
        assert set(query) == {"name", "status", "reason", "elapsed_ms", "values", "core_ids"}
        assert query == json.loads((tmp_path / f"{query['name']}.json").read_text(encoding="utf-8"))
        if query["status"] in {"sat", "unsat"}:
            assert query["reason"] is None
            assert (tmp_path / f"{query['name']}.smt2").exists()
            assert (tmp_path / f"{query['name']}.txt").exists()
        else:
            assert query["reason"]
    # A solver status carries no automatic scientific approval or release flag.
    assert "scientifically_valid" not in results[1]
    assert "released" not in results[1]


def test_inconsistent_sources_skip_later_queries_and_saved_smt_is_faithful(tmp_path, z3):
    results = run(problem(source=["(= x 0)", "(= x 1)"]), tmp_path, z3)
    assert [query["status"] for query in results] == ["unsat", "not_run", "not_run", "not_run"]
    assert set(results[0]["core_ids"]) == {"source0", "source1"}
    script = (tmp_path / "base_consistency.smt2").read_text(encoding="utf-8")
    assert "(check-sat-assuming (source0 source1))" in script
    context = z3.Context()
    replay = z3.Z3_eval_smtlib2_string(context.ref(), script)
    assert replay.strip() == "unsat"
    assert not (tmp_path / "base_counterexample.smt2").exists()


def test_added_assumptions_change_formal_conclusion_explicitly(tmp_path, z3):
    results = run(problem(source=["(>= x 0)"], assumptions=["(>= x 1)"]), tmp_path, z3)
    assert [query["status"] for query in results] == ["sat", "sat", "sat", "unsat"]
    assert results[1]["values"] == {"x": "0.0"}
    assert "assumption0" in results[3]["core_ids"]
    assert "__negated_goal" in results[3]["core_ids"]
    assert results[3]["values"] is None


def test_inconsistent_added_assumptions_are_not_treated_as_proof(tmp_path, z3):
    results = run(problem(source=["(= x 0)"], assumptions=["(= x 1)"]), tmp_path, z3)
    assert [query["status"] for query in results] == ["sat", "sat", "unsat", "not_run"]
    assert set(results[2]["core_ids"]) == {"source0", "assumption0"}


def test_all_declared_values_include_exact_rationals_and_unconstrained_variables(tmp_path, z3):
    request = problem(source=["(= x (/ 1 3))"], variables=[
        {"name": "x", "sort": "Real", "meaning": "Quantity", "unit": None},
        {"name": "unused", "sort": "Real", "meaning": "Unconstrained quantity", "unit": None},
        {"name": "flag", "sort": "Bool", "meaning": "Unconstrained proposition", "unit": None},
    ])
    results = run(request, tmp_path, z3)
    assert results[0]["values"] == {"x": "(/ 1.0 3.0)", "unused": "0.0", "flag": "false"}
    assert results[1]["status"] == "unsat"
    assert "(/ 1.0 3.0)" in (tmp_path / "base_consistency.txt").read_text(encoding="utf-8")


def test_negative_denominator_and_polynomial_arithmetic(tmp_path, z3):
    results = run(problem("(< x 0)", source=["(= x (/ 1 (- 2)))"]), tmp_path, z3)
    assert [query["status"] for query in results[:2]] == ["sat", "unsat"]
    assert results[0]["values"]["x"] == "(- (/ 1.0 2.0))"


def test_algebraic_model_values_remain_exact_root_objects(tmp_path, z3):
    results = run(problem("(> x 1)", source=["(= (* x x) 2)", "(> x 0)"]), tmp_path, z3)
    assert [query["status"] for query in results[:2]] == ["sat", "unsat"]
    assert "root-obj" in results[0]["values"]["x"]
    assert "?" not in results[0]["values"]["x"]


def test_boolean_and_chained_comparison_translation(tmp_path, z3):
    request = problem("(and flag (< x 3))", source=["(< 0 x 2)", "(= flag true)"], variables=[
        {"name": "x", "sort": "Real", "meaning": "Quantity", "unit": None},
        {"name": "flag", "sort": "Bool", "meaning": "Proposition", "unit": None},
    ])
    results = run(request, tmp_path, z3)
    assert [query["status"] for query in results[:2]] == ["sat", "unsat"]


@pytest.mark.parametrize("first_status,expected_calls", [
    ("unknown", ["base_consistency", "full_consistency", "full_counterexample"]),
    ("error", ["base_consistency"]), ("timeout", ["base_consistency"]),
    ("cancelled", ["base_consistency"]),
])
def test_unknown_is_not_retried_and_terminal_failures_stop_queries(tmp_path, z3, monkeypatch, first_status, expected_calls):
    calls = []

    def fake_query(name, *args):
        calls.append(name)
        status = first_status if len(calls) == 1 else "sat"
        return worker._query_record(name, status, "Injected solver outcome" if status != "sat" else None,
                                    values={"x": "1.0"} if status == "sat" else None)

    monkeypatch.setattr(worker, "_query", fake_query)
    results = run(problem(source=["(>= x 0)"], assumptions=["(>= x 1)"]), tmp_path, z3)
    assert calls == expected_calls
    assert results[1]["status"] == "not_run"


def test_shared_expired_deadline_does_not_start_solver_query(tmp_path, z3):
    results = worker.run_worker(problem(source=["(>= x 1)"]), tmp_path, time.monotonic() - 1, z3)
    assert [query["status"] for query in results] == ["timeout", "not_run", "not_run", "not_run"]
    assert not list(tmp_path.glob("*.smt2"))


def test_solver_timeout_uses_remaining_shared_budget_and_query_is_saved_first(tmp_path, z3, monkeypatch):
    real_solver = z3.Solver
    context = z3.Context()
    x = z3.Real("x", ctx=context)
    settings = []
    calls = []

    class TimeoutSolver:
        def __init__(self, **kwargs):
            self.actual = real_solver(**kwargs)

        def __getattr__(self, name):
            return getattr(self.actual, name)

        def set(self, **kwargs):
            settings.append(kwargs)

        def check(self):
            assert (tmp_path / "base_consistency.smt2").read_text(encoding="utf-8")
            assert not (tmp_path / "base_consistency.json").exists()
            calls.append("check")
            return z3.unknown

        def reason_unknown(self):
            return "timeout"

    timestamps = iter([100.0, 100.25, 100.75])
    # The worker's own clock only: patching the shared time module also fed these three readings to other
    # threads still running in the test process (the tool-output cleanup scheduler), which used them up.
    monkeypatch.setattr(worker, "time", SimpleNamespace(monotonic=lambda: next(timestamps)))
    monkeypatch.setattr(z3, "Solver", TimeoutSolver)
    record = worker._query("base_consistency", [("p0", x > 0)], None, {"x": x}, tmp_path, 101.0, z3, context)
    assert settings == [{"timeout": 750}]
    assert calls == ["check"]
    assert record == {"name": "base_consistency", "status": "timeout", "reason": "timeout", "elapsed_ms": 750,
                      "values": None, "core_ids": None}
    assert (tmp_path / "base_consistency.txt").read_text(encoding="utf-8") == "unknown\ntimeout\n"


def test_unavailable_unsat_core_is_explicit_null(tmp_path, z3, monkeypatch):
    real_solver = z3.Solver

    class NoCoreSolver:
        def __init__(self, **kwargs):
            self.actual = real_solver(**kwargs)

        def __getattr__(self, name):
            return getattr(self.actual, name)

        def unsat_core(self):
            raise z3.Z3Exception("core unavailable for this query")

    monkeypatch.setattr(z3, "Solver", NoCoreSolver)
    results = run(problem(source=["(= x 0)", "(= x 1)"]), tmp_path, z3)
    assert results[0]["status"] == "unsat"
    assert results[0]["reason"] is None
    assert results[0]["core_ids"] is None
    assert "Unsat core unavailable" in (tmp_path / "base_consistency.txt").read_text(encoding="utf-8")


@pytest.mark.parametrize("result_status", ["sat", "unsat"])
def test_model_or_core_extraction_crossing_deadline_cannot_publish_success(tmp_path, z3, monkeypatch, result_status):
    real_solver = z3.Solver
    clock = [100.0]
    context = z3.Context()
    x = z3.Real("x", ctx=context)

    class SlowExtractionSolver:
        def __init__(self, **kwargs):
            self.actual = real_solver(**kwargs)

        def __getattr__(self, name):
            return getattr(self.actual, name)

        def model(self):
            model = self.actual.model()
            clock[0] = 101.25
            return model

        def unsat_core(self):
            core = self.actual.unsat_core()
            clock[0] = 101.25
            return core

    monkeypatch.setattr(worker, "time", SimpleNamespace(monotonic=lambda: clock[0]))
    monkeypatch.setattr(z3, "Solver", SlowExtractionSolver)
    constraints = [("p0", x == 1)]
    if result_status == "unsat":
        constraints.append(("p1", x == 0))
    record = worker._query("base_consistency", constraints, None, {"x": x}, tmp_path, 101.0, z3, context)
    assert record["status"] == "timeout"
    assert record["values"] is None
    assert record["core_ids"] is None
    assert record["elapsed_ms"] == 1250
    assert "deadline" in record["reason"]
    raw = (tmp_path / "base_consistency.txt").read_text(encoding="utf-8")
    assert raw.splitlines()[0] == result_status
    assert json.loads((tmp_path / "base_consistency.json").read_text(encoding="utf-8"))["status"] == "timeout"


@pytest.mark.parametrize("outcomes,expected_calls", [
    (["sat", "unknown", "sat", "unsat"], list(worker.QUERY_NAMES)),
    (["sat", "error"], ["base_consistency", "base_counterexample"]),
    (["sat", "timeout"], ["base_consistency", "base_counterexample"]),
    (["sat", "sat", "unknown"], ["base_consistency", "base_counterexample", "full_consistency"]),
])
def test_later_query_statuses_preserve_bounded_schedule(tmp_path, z3, monkeypatch, outcomes, expected_calls):
    calls = []

    def fake_query(name, *args):
        status = outcomes[len(calls)]
        calls.append(name)
        return worker._query_record(name, status, None if status in {"sat", "unsat"} else "Injected outcome",
                                    values={"x": "1.0"} if status == "sat" else None,
                                    core_ids=[] if status == "unsat" else None)

    monkeypatch.setattr(worker, "_query", fake_query)
    run(problem(source=["(>= x 0)"], assumptions=["(>= x 1)"]), tmp_path, z3)
    assert calls == expected_calls


def test_cli_runs_in_separate_process_and_reports_plain_version(tmp_path, z3):
    input_path = tmp_path / "input.json"
    input_path.write_text(json.dumps(problem(source=["(>= x 1)"])), encoding="utf-8")
    folder = tmp_path / "run"
    result = subprocess.run(
        [sys.executable, "-m", "researchkit.inference_worker", str(input_path), str(folder), str(time.monotonic() + 30)],
        capture_output=True, text=True, timeout=35, check=False,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == z3.get_version_string()
    assert json.loads((folder / "base_counterexample.json").read_text(encoding="utf-8"))["status"] == "unsat"


def test_missing_z3_fails_explicitly_without_auto_install(monkeypatch, capsys):
    original_import = builtins.__import__

    def no_z3(name, *args, **kwargs):
        if name == "z3":
            raise ImportError("deliberately unavailable")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", no_z3)
    assert worker.main(["input.json", "output", "123"]) == 2
    assert "z3-solver dependency; it is not installed" in capsys.readouterr().err


@pytest.mark.parametrize("content,diagnostic", [
    ('{"scope":"first","scope":"second"}', "Duplicate JSON key"),
    ('{"goal":{"expr":"true","expr":"false"}}', "Duplicate JSON key"),
    ('{"scope":NaN}', "Nonstandard JSON constant"),
    ('{"scope":Infinity}', "Nonstandard JSON constant"),
])
def test_cli_rejects_ambiguous_or_nonstandard_json(tmp_path, z3, capsys, content, diagnostic):
    input_path = tmp_path / "input.json"
    input_path.write_text(content, encoding="utf-8")
    folder = tmp_path / "run"
    assert worker.main([str(input_path), str(folder), str(time.monotonic() + 30)]) == 1
    assert diagnostic in capsys.readouterr().err
    assert not folder.exists()
