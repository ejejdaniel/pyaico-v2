"""research_record writes template files itself, so the model never names or moves them."""

import json
from pathlib import Path

import pytest

from opencode.loop import ToolContext
from researchkit import board, records
from researchkit.tools import _publish
from test_delivery_acceptance import case  # noqa: F401  (fixture)


def ctx_for(case):
    root, app, session = case
    return root, ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)


def save(ctx, **args):
    return json.loads(_publish(args, ctx).output)


def test_one_formula_per_hypothesis_needs_no_file_handling(case):
    root, ctx = ctx_for(case)
    hypotheses = save(ctx, kind="hypothesis", title="five mechanisms",
                      template={"hypotheses": [{"id": f"H{n}", "statement": f"m{n}"} for n in range(1, 6)]})
    for n in range(1, 6):
        save(ctx, kind="proxy_formula", title=f"P{n}", depends_on=[hypotheses["record_path"]],
             template={"formula_id": f"P{n}", "expression": f"x{n}", "hypothesis_ids": [f"H{n}"],
                       "direction": "higher"})
    value = board.build(root)
    assert sorted(f["template"]["formula_id"] for f in value["proxy_formulas"]) == [f"P{n}" for n in range(1, 6)]
    assert not any("沒有對應公式的假說" in i["text"] for i in value["notice_items"])
    saved = [r for r in records.inventory(root) if r["kind"] == "proxy_formula"]
    assert all(Path(f["source_path"]).name == "proxy_formula.json" for r in saved for f in r["files"])
    assert not list(root.glob("work/*")) and not list(root.glob("notes/*"))  # nothing for the model to tidy


@pytest.mark.parametrize("args, message", [
    ({"kind": "report", "title": "r", "template": {"a": 1}}, "takes files only"),
    ({"kind": "proxy_formula", "title": "p", "template": ["not", "an", "object"]}, "JSON object"),
    ({"kind": "proxy_formula", "title": "p", "files": ["x/proxy_formula.json"], "template": {}}, "not both"),
    ({"kind": "note", "title": "n"}, "at least one file"),
])
def test_misuse_says_how_to_fix_it(case, args, message):
    root, ctx = ctx_for(case)
    (root / "x").mkdir()
    (root / "x/proxy_formula.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match=message):
        _publish(args, ctx)


def test_a_file_in_the_way_of_template_is_named(case):
    root, ctx = ctx_for(case)
    (root / "data").mkdir()
    (root / "data/evolution.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match=r"files include data/evolution\.json.*give it another name"):
        _publish({"kind": "sample_evolution", "title": "e", "files": ["data/evolution.json"],
                  "template": {"rounds": [{"round": 1}]}}, ctx)


def test_a_file_listed_but_absent_is_named(case):
    # A run (2026-11-01) renamed a file in files without renaming it on disk and got the system's "[Errno 2]".
    root, ctx = ctx_for(case)
    with pytest.raises(ValueError, match="files lists work/absent.json, which is not a file in the workspace"):
        save(ctx, kind="notes", title="n", files=["work/absent.json"])


def _texts(root):
    return [item["text"] for item in board.build(root)["notice_items"]]


def _short(saved):
    return saved["record_path"].split("/")[2][:8]


def test_only_an_evolution_record_declares_an_evolution(case):
    # v22 kept its results in data/evolution.json inside implementation records; the board read that as the
    # declaration and raised notices that no later record could answer.
    root, ctx = ctx_for(case)
    formula = save(ctx, kind="proxy_formula", title="P1",
                   template={"formula_id": "P1", "expression": "x", "direction": "higher"})
    (root / "data").mkdir()
    (root / "data/evolution.json").write_text(json.dumps({"rounds": [{"round": 1}]}), encoding="utf-8")
    save(ctx, kind="implementation", title="results", files=["data/evolution.json"],
         depends_on=[formula["record_path"]])
    assert not any("evolution.json" in text or "proxy_formula_ref" in text for text in _texts(root))
    # research_record refuses an evolution record whose declaration the host cannot check ...
    with pytest.raises(ValueError, match="evolution.json: "):
        save(ctx, kind="sample_evolution", title="rounds", files=["data/evolution.json"],
             depends_on=[formula["record_path"]])
    # ... and the board still says what an evolution record saved before that check lacks.
    evolution = records.publish(root, kind="sample_evolution", title="rounds", files=["data/evolution.json"],
                                depends_on=[formula["record_path"]])
    named = [text for text in _texts(root) if text.startswith(f"sample_evolution {_short(evolution)}")]
    assert len(named) == 1 and "宣告檔 data/evolution.json 沒有 proxy_formula_ref" in named[0]
    assert "template" in named[0] and "不要叫 evolution.json" in named[0]


def test_a_notice_about_a_replaced_record_goes_with_it(case):
    root, ctx = ctx_for(case)
    missing = {"record_ref": ".research/records/" + "0" * 64 + "/record.json", "source_path": "levers.csv"}
    first = save(ctx, kind="hypothesis", title="v1",
                 template={"hypotheses": [{"id": "H1", "statement": "m"}], "lever_table": missing})
    assert any(f"hypothesis {_short(first)} 的 lever_table 無法讀取" in text for text in _texts(root))
    save(ctx, kind="hypothesis", title="v2", revises=first["record_path"],
         template={"hypotheses": [{"id": "H1", "statement": "m"}]})
    assert not any("lever_table" in text for text in _texts(root))
    # An evolution record built on an earlier one replaces it too.
    formula = save(ctx, kind="proxy_formula", title="P1",
                   template={"formula_id": "P1", "expression": "x", "direction": "higher"})
    # Saved as records were before research_record checked evolution declarations.
    old = _published(root, "old", {"rounds": [{"round": 1}]}, [formula["record_path"]])
    assert any(text.startswith(f"sample_evolution {_short(old)}") for text in _texts(root))
    new = _published(root, "new", {"proxy_formula_ref": formula["record_path"], "rounds": [{"round": 1}]},
                     [formula["record_path"], old["record_path"]])
    assert not any(_short(old) in text or _short(new) in text for text in _texts(root))


def _published(root, name, declaration, depends_on=()):
    """An evolution record saved without research_record's checks."""
    path = root / "declared" / name / "evolution.json"
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps(declaration), encoding="utf-8")
    return records.publish(root, kind="sample_evolution", title=name, files=[path.relative_to(root).as_posix()],
                           depends_on=list(depends_on))


def _leaderboard(root, name, verdicts):
    """A leaderboard record as the board reads it, with these candidates' verdicts."""
    path = root / "lb" / name / "leaderboard.json"
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({
        "sheets": [{"formula_ref": "f", "formula_id": "P1", "direction": "higher", "evidence": "history",
                    "values": {"S1": 1.0, **{c: 2.0 for c in verdicts}}, "tied_best_candidates": [],
                    "outside_baseline_range": []}],
        "baseline_ids": ["S1"], "candidate_ids": list(verdicts), "most_disputed": [],
        "candidates": [{"id": c, "verdict": v} for c, v in verdicts.items()], "pareto_front": []}), encoding="utf-8")
    return records.publish(root, kind="leaderboard", title=name, files=[path.relative_to(root).as_posix()],
                           depends_on=[])


def _declared(ref, ids, claims):
    return {"ranking_rule": "the leaderboard verdict against the best baseline",
            "stop_reason": "the round limit, or a candidate ahead of the best baseline", "claims_surpass": claims,
            "rounds": [{"round": 1, "candidate_ids": ids, "leaderboard_ref": ref, "strategy": "explore",
                        "levers": ["x"], "reason": "a first sweep of the lever"}]}


def test_an_evolution_declaration_names_everything_it_lacks_at_once(case):
    # A run declared its rounds with fields of its own: no surpass claim, no stop reason, no round reasons.
    root, ctx = ctx_for(case)
    with pytest.raises(ValueError) as refused:
        save(ctx, kind="sample_evolution", title="rounds", template={"rounds": [{"round": 2}]})
    text = str(refused.value)
    assert text.startswith("evolution.json: ") and "problems, all of them listed" in text
    for part in ("rounds[1] has round 2", "candidate_ids", "leaderboard_ref", "strategy explore or exploit",
                 "needs reason", "ranking_rule is missing", "stop_reason is missing", "claims_surpass must be"):
        assert part in text
    assert "Nothing was saved" in text and not records.inventory(root)


def test_a_surpass_claim_needs_a_cited_comparison_that_shows_one_of_its_candidates_ahead(case):
    # A run stopped after one round on a surpass its leaderboard did not show.
    root, ctx = ctx_for(case)
    level = _leaderboard(root, "level", {"C1": "no_surpass"})
    ahead = _leaderboard(root, "ahead", {"C2": "surpass_one_sheet"})
    for ref, ids in ((level["record_path"], ["C1"]), (ahead["record_path"], ["C1"])):
        with pytest.raises(ValueError, match="claims_surpass is true, but no comparison the rounds cite shows"):
            save(ctx, kind="sample_evolution", title="e", template=_declared(ref, ids, True))
    assert save(ctx, kind="sample_evolution", title="e", template=_declared(ahead["record_path"], ["C2"], True))
    # Without a claim, the same level leaderboard is a round like any other.
    assert save(ctx, kind="sample_evolution", title="f", template=_declared(level["record_path"], ["C1"], False))
    with pytest.raises(ValueError, match="which is not a host comparison"):
        save(ctx, kind="sample_evolution", title="g",
             template=_declared(".research/records/" + "0" * 64 + "/record.json", ["C1"], False))


def test_a_hypothesis_set_the_board_cannot_read_is_refused_naming_the_key(case):
    # v23 wrote hypothesis_id for id; the board said only "missing id" and the set was saved five more times.
    root, ctx = ctx_for(case)
    with pytest.raises(ValueError, match=r"item 1 has no id \(it has hypothesis_id; the key must be id\)"):
        _publish({"kind": "hypothesis", "title": "h", "template": {"hypotheses": [
            {"hypothesis_id": "H1", "statement": "a"}]}}, ctx)
    with pytest.raises(ValueError, match="item 1 has no statement text; its keys are claim, id"):
        _publish({"kind": "hypothesis", "title": "h", "template": {"hypotheses": [{"id": "H1", "claim": "a"}]}}, ctx)
    (root / "h").mkdir()
    (root / "h/hypotheses.json").write_text(json.dumps({"hypotheses": [{"hypothesis_id": "H1", "statement": "a"}]}),
                                            encoding="utf-8")
    saved = records.publish(root, kind="hypothesis", title="h", files=["h/hypotheses.json"], depends_on=[])
    assert any("hypothesis_id; the key must be id" in text and _short(saved) in text for text in _texts(root))


def test_a_reworded_hypothesis_keeps_its_formula_and_says_so(case):
    # v23 added a comma to H3's statement and the board reported H3 as having no formula.
    root, ctx = ctx_for(case)
    first = save(ctx, kind="hypothesis", title="v1", template={"hypotheses": [
        {"id": "H1", "statement": "Mw raises Scum risk"}, {"id": "H2", "statement": "acid strength"}]})
    for number in (1, 2):
        save(ctx, kind="proxy_formula", title=f"P{number}", depends_on=[first["record_path"]],
             template={"formula_id": f"P{number}", "expression": "x", "hypothesis_ids": [f"H{number}"],
                       "direction": "higher"})
    second = save(ctx, kind="hypothesis", title="v2", revises=first["record_path"], template={"hypotheses": [
        {"id": "H1", "statement": "Mw raises Scum risk, and EOP"}, {"id": "H2", "statement": "acid strength"}]})
    texts = _texts(root)
    assert not any("沒有對應公式的假說" in text for text in texts)
    assert any(f"hypothesis {_short(second)} 改寫了 H1 的敘述，沿用為舊版敘述建立的公式 P1" in text for text in texts)
    assert not any("改寫了 H2" in text for text in texts)


def test_a_parallel_hypothesis_set_is_told_to_revise_the_one_its_formulas_use(case):
    root, ctx = ctx_for(case)
    first = save(ctx, kind="hypothesis", title="v1", template={"hypotheses": [{"id": "H1", "statement": "a"}]})
    save(ctx, kind="proxy_formula", title="P1", depends_on=[first["record_path"]],
         template={"formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "higher"})
    parallel = save(ctx, kind="hypothesis", title="again", template={"hypotheses": [{"id": "H1", "statement": "a"}]})
    flagged = [text for text in _texts(root) if text.startswith(f"hypothesis {_short(parallel)} 中沒有對應公式的假說")]
    assert len(flagged) == 1 and f"另一份假說紀錄 {_short(first)}" in flagged[0] and "revises" in flagged[0]


def test_a_wrong_source_path_lists_the_files_the_record_holds(case):
    from researchkit.report_evidence import resolve
    root, ctx = ctx_for(case)
    (root / ".research/history-checks/a").mkdir(parents=True)
    (root / ".research/history-checks/a/history_check.json").write_text("{}", encoding="utf-8")
    saved = records.publish(root, kind="history_check", title="h", files=[".research/history-checks/a/history_check.json"],
                            depends_on=[])
    with pytest.raises(ValueError, match=r"That record's files: \.research/history-checks/a/history_check\.json"):
        resolve(root, [{"record_ref": saved["record_path"], "source_path": ".research/history_checks/a/history_check.json"}])


def test_a_new_version_that_drops_a_budget_queue_status_is_refused(case):
    # v24 regenerated its set to fix one sign, lost H4-H6's deferred status and built three formulas for them.
    root, ctx = ctx_for(case)
    queued = {"status": "deferred", "basis": "budget", "reason": "rank 2"}
    first = save(ctx, kind="hypothesis", title="v1", template={"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b", "proxy_status": queued}]})
    with pytest.raises(ValueError, match=r"H2 were queued by the budget .* Nothing was saved"):
        _publish({"kind": "hypothesis", "title": "v2", "revises": first["record_path"], "template": {"hypotheses": [
            {"id": "H1", "statement": "a, revised"}, {"id": "H2", "statement": "b"}]}}, ctx)
    kept = save(ctx, kind="hypothesis", title="v2", revises=first["record_path"], template={"hypotheses": [
        {"id": "H1", "statement": "a, revised"}, {"id": "H2", "statement": "b", "proxy_status": queued}]})
    started = save(ctx, kind="hypothesis", title="v3", revises=kept["record_path"], template={"hypotheses": [
        {"id": "H1", "statement": "a, revised"},
        {"id": "H2", "statement": "b", "proxy_status": {"status": "active", "reason": "after the first delivery"}}]})
    assert started["record_path"]


def test_the_board_names_a_lost_budget_status_instead_of_asking_for_formulas(case):
    root, _ = ctx_for(case)
    (root / "h1").mkdir()
    (root / "h2").mkdir()
    (root / "h1/hypotheses.json").write_text(json.dumps({"hypotheses": [
        {"id": "H1", "statement": "a"},
        {"id": "H2", "statement": "b", "proxy_status": {"status": "deferred", "basis": "budget", "reason": "r"}}]}),
        encoding="utf-8")
    first = records.publish(root, kind="hypothesis", title="v1", files=["h1/hypotheses.json"], depends_on=[])
    (root / "h2/hypotheses.json").write_text(json.dumps({"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"}]}), encoding="utf-8")
    second = records.publish(root, kind="hypothesis", title="v2", files=["h2/hypotheses.json"],
                             depends_on=[first["record_path"]])
    texts = _texts(root)
    assert any(f"hypothesis {_short(second)} 的 H2 在前一版標為預算排隊" in text for text in texts)
    assert not any("沒有對應公式的假說：H1、H2" in text or "沒有對應公式的假說：H2" in text for text in texts)


def test_a_revised_hypothesis_set_lists_the_formulas_it_keeps(case):
    # v24 saved all three formulas again after revising one hypothesis, so each went back through values and checks.
    root, ctx = ctx_for(case)
    first = save(ctx, kind="hypothesis", title="v1", template={"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"}]})
    for number in (1, 2):
        save(ctx, kind="proxy_formula", title=f"P{number}", depends_on=[first["record_path"]],
             template={"formula_id": f"P{number}", "expression": "x", "hypothesis_ids": [f"H{number}"],
                       "direction": "higher"})
    receipt = save(ctx, kind="hypothesis", title="v2", revises=first["record_path"], template={"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b with the corrected sign"}]})
    assert receipt["formulas_carried_over"] == {"H1": ["P1"], "H2": ["P2"]}
    assert "do not save them again" in receipt["formulas_note"]
    first_set = save(ctx, kind="hypothesis", title="fresh", template={"hypotheses": [{"id": "H9", "statement": "c"}]})
    assert "formulas_carried_over" not in first_set


def test_value_errors_say_what_the_value_is_and_what_to_do():
    from researchkit import values_table
    with pytest.raises(ValueError, match=r"Value for 'S1' is null \(no value\), not a JSON number\. .*leave its sheet out"):
        values_table.column_values(json.dumps({"S1": {"P3": None}, "c1": {"P3": 1.0}}), "P3")
    with pytest.raises(ValueError, match=r"Value for 'S1' is the text 'undefined'"):
        values_table.column_values(json.dumps({"S1": {"P3": "undefined"}}), "P3")
