"""Host-computed facts for tool-less model calls: correct when given, silent when unsure, capped."""

import pytest

from researchkit import knowledge
from researchkit.knowledge import chemistry, numbers, tables

TABLE = {"source_path": "data/records.csv",
         "text": "﻿Sample,Yield,Purity,Batch\nA1,53.7,4.78,K\nA2,47.9,4.87,K\n"}
PROSE = {"source_path": "notes.md", "text": "\n".join([
    "Background prose without numbers.",
    "(3) Yield: 48.9",          # near 47.9 but not equal: a likely inconsistency
    "(4) Purity: 4.81",         # near both 4.78 and 4.87
    "Yield: 53.7",              # exact match: not reported
    "Yield target: < 50.5",     # a requirement, not a measurement
    "Purity 40 ± 1",            # a specification with ±
    "Yield 12.0",               # far from every value: not reported
])}


def test_table_facts_list_rows_and_what_varies():
    lines = tables.facts([TABLE])
    text = "\n".join(lines)
    assert "data/records.csv: 2 rows × 4 columns (Sample, Yield, Purity, Batch)" in text
    assert "columns that differ between rows: Sample, Yield, Purity" in text
    assert "columns identical in every row: Batch = K" in text
    assert "Yield: min 47.9, max 53.7, range 5.8" in text
    assert "row 'A2': Yield 47.9; Purity 4.87; Batch K" in text


def test_table_facts_skip_non_tables_and_ragged_rows():
    assert tables.facts([PROSE]) == []
    assert tables.facts([{"source_path": "bad.csv", "text": "a,b\n1,2,3\n"}]) == []


def test_number_mismatches_report_near_values_and_skip_specifications():
    lines = numbers.facts([TABLE, PROSE])
    assert len(lines) == 2
    assert lines[0].startswith("- notes.md line 2 states Yield 48.9; no table value matches it exactly.")
    assert "53.7 (row 'A1'); 47.9 (row 'A2')" in lines[0]
    assert lines[1].startswith("- notes.md line 3 states Purity 4.81")


def test_chemistry_facts_state_rings_groups_and_the_ester_side():
    pytest.importorskip("rdkit")
    assert "tertiary carbon in a 5-membered ring" in chemistry.describe("CC(=O)OC1(C)CCCC1")
    assert "benzylic" in chemistry.describe("CC(=O)OC(C)(C)c1ccccc1")
    assert "aryl ester" in chemistry.describe("CC(=O)Oc1ccccc1")
    ester = chemistry.describe("CC(=O)OCC")
    assert "ester ×1" in ester and "ether" not in ester
    lines = chemistry.facts([{"source_path": "s.md", "text": "- A1: `CC(=O)OC1(C)CCCC1`\nA1 again CC(=O)OC1(C)CCCC1"}])
    assert len(lines) == 1 and lines[0].startswith("- A1: `CC(=O)OC1(C)CCCC1`")
    assert chemistry.facts([{"source_path": "s.md", "text": "plain prose (with brackets) = 12.5 mJ"}]) == []


def test_block_is_capped_labelled_and_survives_a_failing_provider():
    def broken(sources):
        raise RuntimeError("boom")

    def many(sources):
        return [f"- fact {index} " + "x" * 50 for index in range(100)]

    providers = (knowledge.Provider("broken", "fails", broken), knowledge.Provider("many", "lots", many))
    block = knowledge.facts_block([TABLE], cap=1000, providers=providers)
    assert block.startswith("Host-computed facts")
    assert "(provider failed and reported nothing: RuntimeError)" in block
    assert len(block) < 1400
    assert "further fact lines omitted by the 1000-character cap" in block
    assert knowledge.facts_block([{"source_path": "x.md", "text": "nothing to compute"}]) == ""
