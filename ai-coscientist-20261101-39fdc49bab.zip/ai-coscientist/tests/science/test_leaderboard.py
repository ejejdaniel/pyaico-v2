"""Multi-sheet leaderboard: ranks, Pareto front, verdicts and board signals; no model calls."""

import json

import jsonschema
import pytest

from researchkit import board, leaderboard, records


def sheet(ref, direction, values, hypotheses=("H1",)):
    return {"formula_ref": ref, "formula_id": ref, "hypothesis_ids": list(hypotheses), "direction": direction,
            "values": values}


BASE = ["h1", "h2"]
CANDS = ["s1", "s2", "s3"]
P1 = sheet("P1", "higher", {"h1": 2, "h2": 3.5, "s1": 4, "s2": 4, "s3": 4})
P2 = sheet("P2", "lower", {"h1": 7, "h2": 9, "s1": 9, "s2": 8, "s3": 10}, ("H2",))


def test_ranks_average_ties_and_status_follow_each_sheet_direction():
    result = leaderboard.compute([P1, P2], BASE, CANDS, "P1")
    p1, p2 = result["sheets"]
    assert p1["ranks"] == {"s1": 2.0, "s2": 2.0, "s3": 2.0, "h2": 4.0, "h1": 5.0}
    assert p1["tied_best_candidates"] == ["s1", "s2", "s3"]
    assert p2["best_baselines"] == ["h1"] and p2["candidate_status"] == {"s1": "worse", "s2": "worse", "s3": "worse"}
    assert p1["outside_baseline_range"] == CANDS and p2["outside_baseline_range"] == ["s3"]


def test_pareto_front_includes_history_and_verdicts_need_no_weights():
    result = leaderboard.compute([P1, P2], BASE, CANDS, "P1")
    assert result["pareto_front"] == ["h1", "s2"]
    rows = {row["id"]: row for row in result["candidates"]}
    assert rows["s2"]["verdict"] == "tradeoff_surpass" and rows["s2"]["worse_on"] == ["P2"]
    assert rows["s3"]["dominated_by"] == ["s1", "s2"] and not rows["s3"]["on_front"]
    assert [row["id"] for row in result["candidates"]] == ["s2", "s1", "s3"]  # display order by mean rank
    assert "not a score" in result["note"] and "total" not in json.dumps(result)
    assert result["sheet_agreement"][0]["kendall_tau_b"] < 0 and result["most_disputed"][0] == "s3"


def test_robust_surpass_and_dominated_by_history():
    a = sheet("A", "higher", {"h": 1, "g": 0.5, "good": 3, "bad": 0})
    b = sheet("B", "higher", {"h": 1, "g": 0.5, "good": 2, "bad": 0})
    result = leaderboard.compute([a, b], ["h", "g"], ["good", "bad"], "A")
    rows = {row["id"]: row for row in result["candidates"]}
    assert rows["good"]["verdict"] == "robust_surpass" and result["history_sheets"] == ["A", "B"]
    assert rows["bad"]["verdict"] == "no_surpass" and rows["bad"]["dominated_by_history"] == ["h", "g"]
    assert result["all_sheets_agree"] and result["pareto_front"] == ["good"]


def test_one_history_sheet_cannot_make_a_robust_surpass():
    only = sheet("A", "higher", {"h": 1, "g": 0.5, "best": 3, "next": 2})
    rows = {r["id"]: r for r in leaderboard.compute([only], ["h", "g"], ["best", "next"])["candidates"]}
    # "next" is beaten by "best", which is not a trade-off against history
    assert rows["best"]["verdict"] == rows["next"]["verdict"] == "surpass_one_sheet"


def test_a_sheet_where_history_ties_gives_only_a_conditional_surpass():
    measured = sheet("A", "higher", {"h": 1, "g": 0.5, "c": 0.8})
    untested = sheet("B", "higher", {"h": 2, "g": 2, "c": 5}, ("H4",))
    judged = {**sheet("J", "higher", {"h": 1, "g": 2, "c": 3}, ("H5",)), "evidence": "llm_judge"}
    result = leaderboard.compute([measured, untested, judged], ["h", "g"], ["c"])
    row, = result["candidates"]
    assert [s["evidence"] for s in result["sheets"]] == ["history", "mechanism_only", "llm_judge"]
    assert row["verdict"] == "conditional_surpass"
    assert row["conditional_on"] == [{"sheet": "B", "hypothesis_ids": ["H4"], "evidence": "mechanism_only"},
                                     {"sheet": "J", "hypothesis_ids": ["H5"], "evidence": "llm_judge"}]


def test_front_too_large_when_every_sample_wins_somewhere():
    a = sheet("A", "higher", {"h": 0, "x": 1, "y": 2, "z": 3})
    b = sheet("B", "higher", {"h": 3, "x": 2, "y": 1, "z": 0})
    result = leaderboard.compute([a, b], ["h"], ["x", "y", "z"], "A")
    assert result["front_ratio"] == 1.0 and result["front_too_large"]


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


@pytest.fixture
def pool(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"}]}})
    f1 = save(tmp_path, "proxy_formula", {"f1/proxy_formula.json": {
        "formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "higher"}}, [hypotheses])
    f2 = save(tmp_path, "proxy_formula", {"f2/proxy_formula.json": {
        "formula_id": "P2", "expression": "y", "hypothesis_ids": ["H2"], "direction": "lower"}}, [hypotheses])
    v1 = save(tmp_path, "implementation", {"v1/values.json": P1["values"]}, [f1])
    v2 = save(tmp_path, "implementation", {"v2/values.json": P2["values"]}, [f2])
    args = {"baseline_ids": BASE, "candidate_ids": CANDS, "primary_formula_ref": f1["record_path"],
            "sheets": [{"formula_ref": f1["record_path"], "values": {"record_ref": v1["record_path"],
                                                                      "source_path": "v1/values.json"}},
                       {"formula_ref": f2["record_path"], "values": {"record_ref": v2["record_path"],
                                                                      "source_path": "v2/values.json"}}]}
    return tmp_path, args, f1, f2, v1, v2


def test_run_freezes_a_leaderboard_record_from_frozen_values(pool):
    root, args, f1, f2, v1, v2 = pool
    receipt = leaderboard.run(args, root, root / ".research/leaderboards/one")
    record = records.read_record(root, receipt["record"]["record_path"])
    assert record["kind"] == "leaderboard"
    assert record["depends_on"] == [f1["record_path"], v1["record_path"], f2["record_path"], v2["record_path"]]
    assert receipt["result"]["pareto_front"] == ["h1", "s2"]
    assert [s["formula_id"] for s in receipt["result"]["sheets"]] == ["P1", "P2"]


@pytest.mark.parametrize("change, message", [
    (lambda a, f1, f2, v1, v2: a.update(primary_formula_ref="elsewhere"), "primary_formula_ref"),
    (lambda a, f1, f2, v1, v2: a.update(candidate_ids=["h1"]), "overlap"),
    (lambda a, f1, f2, v1, v2: a["sheets"][1].update(values={"record_ref": v1["record_path"],
                                                             "source_path": "v1/values.json"}), "depend"),
    (lambda a, f1, f2, v1, v2: a.update(candidate_ids=["s1", "missing"]), "no values for"),
])
def test_run_rejects_unsound_inputs_without_saving(pool, change, message):
    root, args, f1, f2, v1, v2 = pool
    change(args, f1, f2, v1, v2)
    with pytest.raises(ValueError, match=message):
        leaderboard.run(args, root, root / ".research/leaderboards/bad")
    assert not (root / ".research/leaderboards/bad").exists()


def test_formula_without_direction_cannot_be_a_sheet(pool):
    root, args, f1, f2, v1, v2 = pool
    loose = save(root, "proxy_formula", {"f3/proxy_formula.json": {"expression": "z", "hypothesis_ids": ["H1"]}})
    v3 = save(root, "implementation", {"v3/values.json": P1["values"]}, [loose])
    args["sheets"].append({"formula_ref": loose["record_path"],
                           "values": {"record_ref": v3["record_path"], "source_path": "v3/values.json"}})
    with pytest.raises(ValueError, match="direction"):
        leaderboard.run(args, root, root / ".research/leaderboards/three")


def test_one_values_file_can_feed_every_sheet_by_column(pool):
    root, args, f1, f2, v1, v2 = pool
    table = {s: {"P1": P1["values"][s], "P2": P2["values"][s]} for s in P1["values"]}
    both = save(root, "implementation", {"v3/values.json": table}, [f1, f2])
    args.pop("primary_formula_ref")
    args["sheets"] = [{"formula_ref": f["record_path"], "values": {"record_ref": both["record_path"],
                                                                   "source_path": "v3/values.json", "column": c}}
                      for f, c in ((f1, "P1"), (f2, "P2"))]
    result = leaderboard.run(args, root, root / ".research/leaderboards/columns")["result"]
    assert result["primary_formula_ref"] is None and result["history_sheets"] == ["P1", "P2"]
    assert {r["id"]: r["verdict"] for r in result["candidates"]}["s2"] == "tradeoff_surpass"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate({"baseline_ids": ["h"], "candidate_ids": ["c"], "sheets": []}, leaderboard.INPUT_SCHEMA)


def test_every_problem_of_a_leaderboard_request_is_named_at_once(pool):
    # A run (2026-11-01) was refused fourteen times, each refusal naming one problem.
    root, args, f1, f2, v1, v2 = pool
    args["primary_formula_ref"] = "elsewhere"
    args["candidate_ids"] = [*args["candidate_ids"], "missing"]
    with pytest.raises(ValueError) as refused:
        leaderboard.run(args, root, root / ".research/leaderboards/bad")
    text = str(refused.value)
    assert text.startswith("3 problems, all of them listed so one revision fixes them:")
    assert "primary_formula_ref" in text and text.count("has no values for: ['missing']") == 2
    assert not (root / ".research/leaderboards/bad").exists()


def test_a_column_only_in_the_working_file_says_the_saved_copy_is_read(tmp_path):
    # A run (2026-11-01) rewrote a values file three times; the tools kept reading the record's saved copy.
    from researchkit import values_table
    saved = save(tmp_path, "implementation", {"v/values.json": {"h1": {"P1i": 1.0}, "h2": {"P1i": 2.0}}})
    (tmp_path / "v/values.json").write_text(json.dumps({"h1": {"P1": 1.0}, "h2": {"P1": 2.0}}), encoding="utf-8")
    selection = {"record_ref": saved["record_path"], "source_path": "v/values.json", "column": "P1"}
    with pytest.raises(ValueError, match="the working file v/values.json has changed since: save the current file"):
        values_table.read(tmp_path, selection, None)
    (tmp_path / "v/values.json").write_text(json.dumps({"h1": {"P1i": 1.0}, "h2": {"P1i": 2.0}}), encoding="utf-8")
    with pytest.raises(ValueError) as unchanged:
        values_table.read(tmp_path, {**selection, "source_path": "v/values.json"}, None)
    assert "working file" not in str(unchanged.value)


def test_repeating_a_formula_explains_how_to_split_it(pool):
    root, args, f1, f2, v1, v2 = pool
    args["sheets"][1]["formula_ref"] = f1["record_path"]
    with pytest.raises(ValueError, match="save every formula as its own kind=proxy_formula record"):
        leaderboard.run(args, root, root / ".research/leaderboards/dup")


def test_board_shows_leaderboard_signals_and_robustness_notices(pool):
    root, args, f1, f2, v1, v2 = pool
    first = leaderboard.run(args, root, root / ".research/leaderboards/r1")["record"]
    second = leaderboard.run(args, root, root / ".research/leaderboards/r2")["record"]
    third = leaderboard.run(args, root, root / ".research/leaderboards/r3")["record"]
    rounds = [{"round": 1, "leaderboard_ref": first["record_path"], "strategy": "exploit", "levers": ["ALG ester"]},
              {"round": 2, "leaderboard_ref": second["record_path"], "strategy": "exploit", "levers": ["ALG ester"]},
              {"round": 3, "leaderboard_ref": third["record_path"], "strategy": "exploit", "levers": ["ALG ester"]}]
    evo = save(root, "sample_evolution", {"e/evolution.json": {
        "primary_formula_ref": f1["record_path"], "claims_surpass": True, "tie_break": "report ties",
        "rounds": rounds}}, [first and {"record_path": first["record_path"]},
                             {"record_path": second["record_path"]}, {"record_path": third["record_path"]}])
    value = board.build(root)
    short = evo["record_path"].split("/")[2][:8]
    texts = {i["text"]: i["level"] for i in value["notice_items"]}
    assert not any("超越未經宿主核對" in t for t in texts)
    assert not any("未指向它所依賴的公式紀錄" in t for t in texts)  # primary_formula_ref alone is enough
    assert any(f"{short} 第 2 輪停滯後，第 3 輪仍宣告 exploit" in t and lvl == "info" for t, lvl in texts.items())
    assert any("超越並不穩健" in t for t in texts) and any("屬於外推" in t for t in texts)
    signals = value["evolutions"][0]["signals"]
    assert signals["stalled_rounds"] == [2, 3] and signals["goal_met"] and signals["tied_best"] == CANDS
    text = board.render(value)
    assert "★主" in text and "有取捨的超越：s2（落後於 P2）" in text and "探索／收斂訊號" in text
    report = save(root, "report", {"r/report.md": "text"}, [evo])
    digest = board.delivery_digest(root, board.build(root), report["record_path"])
    assert any("前緣 h1、s2" in line for line in digest) and any("探索／收斂訊號" in line for line in digest)


def test_calibration_against_history_is_an_action_notice(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    formula = save(tmp_path, "proxy_formula", {"f/proxy_formula.json": {
        "formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "higher"}}, [hypotheses])
    save(tmp_path, "calibration", {".research/calibrations/c.json": {
        "kendall_tau_b": -1.0, "direction_adjusted_kendall_tau_b": -1.0, "spearman_rho": -1.0,
        "sample_count": 3, "direction": "higher"}}, [formula])
    actions = [i["text"] for i in board.open_actions(board.build(tmp_path))]
    assert any("依宣告方向的排序與歷史資料相反" in t for t in actions)


def test_tool_is_registered():
    from researchkit.tools import TOOLS
    assert "research_leaderboard" in {tool.name for tool in TOOLS}


def test_the_tool_reply_is_a_short_summary_that_points_to_the_saved_result():
    candidates = [f"s{i}" for i in range(35)]
    values = {"h1": 1, "h2": 2, **{c: 3 + i for i, c in enumerate(candidates)}}
    result = leaderboard.compute([sheet("P1", "higher", values), sheet("P2", "lower", values, ("H2",))],
                                 BASE, candidates, "P1")
    receipt = {"result": result, "record": {"record_path": "r", "files": [{"snapshot": "/saved/leaderboard.json"}]}}
    value = leaderboard.summary(receipt)
    assert value["leaderboard_json"] == "/saved/leaderboard.json" and value["candidates_total"] == 35
    assert len(value["candidates"]) == leaderboard.CANDIDATE_ROWS
    assert "margins" not in value["candidates"][0] and "statuses" not in value["candidates"][0]
    assert not {"values", "ranks", "candidate_status"} & set(value["sheets"][0])
    text = leaderboard._lines(value)
    assert json.loads(text) == value and len(text) < len(json.dumps(receipt, indent=2)) / 3
