"""A2A literature agent client against the mock agent (synthetic data); no real service or model."""

import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

import mock_literature_agent as mock  # noqa: E402
from researchkit import literature_agent as agent  # noqa: E402
from test_delivery_acceptance import case  # noqa: E402,F401  (fixture)


@pytest.fixture
def served():
    server, url = mock.serve()
    yield url
    server.shutdown()


def client(url):
    return agent.Client(url, poll_s=0.01)


def test_a_question_is_decomposed_answered_with_references_and_polled(served):
    c = client(served)
    result = c.ask("How does temperature change electrolyte conductivity, and does salt concentration matter?")
    assert result["state"] == "completed"
    assert result["sub_questions"] == ["How does temperature change electrolyte conductivity",
                                       "does salt concentration matter"]
    assert {r["id"] for r in result["references"]} == {"MOCK-DOC-001", "MOCK-DOC-002"}
    assert result["summary"].startswith("[MOCK SYNTHESIS")
    assert [e["request"]["method"] for e in c.exchanges] == ["message/send", "tasks/get", "tasks/get"]
    text = agent.render(result, c.card(), "saved.json")
    assert "another agent's synthesis" in text and "MOCK-DOC-002" in text


def test_the_agent_can_ask_for_more_input_and_the_answer_continues_the_task(served):
    c = client(served)
    first = c.ask("Summarise corrosion results [mock:clarify]")
    assert first["state"] == "input-required" and "which material system" in first["agent_message"]
    assert "task_id=" + first["task_id"] in agent.render(first, c.card(), "x")
    second = c.ask("Steel with an inhibitor in a test loop", context_id=first["context_id"], task_id=first["task_id"])
    assert second["state"] == "completed" and second["references"][0]["id"] == "MOCK-DOC-005"


def test_failures_direct_answers_and_timeouts(served, monkeypatch):
    c = client(served)
    assert c.ask("anything [mock:fail]")["state"] == "failed"
    direct = c.ask("catalyst coke deactivation [mock:direct]")
    assert direct["state"] == "completed" and direct["references"][0]["id"] == "MOCK-DOC-003"
    with pytest.raises(agent.AgentError, match="did not finish"):
        c.ask("anything [mock:slow]", timeout_s=0.05)
    assert c.exchanges[-1]["request"]["method"] == "tasks/cancel"
    assert c.exchanges[-1]["response"]["result"]["status"]["state"] == "canceled"


def test_tool_saves_the_exchange_without_the_token(case, served, monkeypatch):
    from opencode.loop import ToolContext
    from researchkit.tools import _literature_agent
    root, app, session = case
    monkeypatch.setenv("RESEARCH_LITERATURE_AGENT_URL", served)
    monkeypatch.setenv("RESEARCH_LITERATURE_AGENT_TOKEN", "token-secret-never-saved")
    monkeypatch.setattr(agent, "POLL_S", 0.01)
    ctx = ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)
    output = _literature_agent({"query": "adhesive cure humidity"}, ctx).output
    assert "MOCK-DOC-004" in output and "Complete exchange and agent card:" in output
    saved_path = Path(output.rsplit("Complete exchange and agent card: ", 1)[1].strip())
    saved = json.loads(saved_path.read_text(encoding="utf-8"))
    assert saved["agent_card"]["name"].endswith("(MOCK)") and saved["result"]["state"] == "completed"
    assert "token-secret-never-saved" not in saved_path.read_text(encoding="utf-8")


def test_the_tool_is_offered_only_when_an_agent_is_configured():
    code = "from researchkit.tools import TOOLS; print('literature_agent' in {t.name for t in TOOLS})"
    run = lambda env: subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd=ROOT,
                                     env={**env, "PYTHONPATH": str(ROOT / "src")}).stdout.strip()
    import os
    base = {k: v for k, v in os.environ.items() if k != "RESEARCH_LITERATURE_AGENT_URL"}
    assert run(base) == "False"
    assert run({**base, "RESEARCH_LITERATURE_AGENT_URL": "http://127.0.0.1:9"}) == "True"
