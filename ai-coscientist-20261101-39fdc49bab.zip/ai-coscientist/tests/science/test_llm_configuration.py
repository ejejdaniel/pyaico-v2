"""Offline selection, authoritative composition, and request-boundary checks."""

from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import httpx
import pytest

from opencode import provider as provider_module
from opencode.agent import build_agents, default_agent_name
from opencode.provider import Client
from scripts.llm_configuration import (
    compose_llm_configuration, explicit_root_model, select_llm_configuration,
    public_endpoint_url, validate_llm_fragment,
)


PROJECT = Path(__file__).resolve().parents[2]
DEFAULT = PROJECT / "config/llm.opencode.json"
from tests import canonical_config as canonical  # noqa: E402


@pytest.fixture
def baseline():
    return json.loads(DEFAULT.read_text(encoding="utf-8"))


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Configuration tests must not contact a network or read saved credentials")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(provider_module, "_catalog_temperature", forbidden)
    monkeypatch.setattr(provider_module, "_catalog_model", lambda *args: None)
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-secret")
    return forbidden


def write_config(path, config):
    path.write_text(json.dumps(config), encoding="utf-8")
    return path


def test_module_import_does_not_import_common():
    result = subprocess.run(
        [sys.executable, "-c", "import sys; import scripts.llm_configuration; "
         "assert not any(n == 'opencode' or n.startswith('opencode.') for n in sys.modules)"],
        cwd=PROJECT, capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr


def test_fresh_baseline_reaches_the_composed_config_and_delays_environment_resolution(monkeypatch):
    selection = select_llm_configuration(DEFAULT)
    assert selection.config["provider"]["local"]["options"]["apiKey"] == "{env:LOCAL_OPENAI_API_KEY}"
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "key-after-selection")
    result = compose_llm_configuration({}, selection)
    model = result.config["provider"]["local"]["models"][canonical.model_name()]
    assert model == canonical.model_definition()
    assert result.config["provider"]["local"]["options"]["apiKey"] == "key-after-selection"
    assert result.saved_config["provider"]["local"]["options"]["apiKey"] == "{env:LOCAL_OPENAI_API_KEY}"
    assert {name: a["temperature"] for name, a in result.config["agent"].items()} == canonical.agent_temperatures()
    assert explicit_root_model(result.config, selection, "build") == canonical.root_model()
    assert result.source == str(DEFAULT.resolve())
    assert "key-after-selection" not in "\n".join(result.messages)


def test_authoritative_composition_removes_hidden_models_but_preserves_other_agent_properties(baseline):
    workspace = {
        "model": "old/stale", "provider": {"old": {"options": {"apiKey": "workspace-secret"}, "models": {"stale": {}}}},
        "enabled_providers": ["old"], "disabled_providers": ["local"],
        "agent": {"build": {"temperature": 0.4, "model": "old/stale", "prompt": "Keep prompt", "steps": 12},
                  "custom": {"temperature": 0.7, "model": "old/stale", "mode": "subagent", "permission": {"edit": "deny"}}},
        "permission": {"bash": "ask"}, "skills": {"paths": ["keep-skills"]}, "mcp": {"keep": {"type": "local"}},
    }
    original = deepcopy(workspace)
    selected = select_llm_configuration(DEFAULT)
    result = compose_llm_configuration(workspace, selected)
    assert workspace == original
    assert selected.config == baseline
    assert result.config["provider"].keys() == {"local"}
    assert "enabled_providers" not in result.config
    assert "disabled_providers" not in result.config
    assert result.config["agent"]["build"] == {"temperature": canonical.agent_temperature("build"),
                                               "prompt": "Keep prompt", "steps": 12}
    assert result.config["agent"]["custom"] == {"mode": "subagent", "permission": {"edit": "deny"}}
    for key in ("permission", "skills", "mcp"):
        assert result.config[key] == workspace[key]
    messages = "\n".join(result.messages)
    for key in ("agent.custom.model", "agent.custom.temperature", "provider.old.options.apiKey", "disabled_providers"):
        assert key in messages
    assert "agent.custom.temperature：未指定" in messages
    assert "workspace-secret" not in messages


@pytest.mark.parametrize("mutation,match", [
    (lambda c: c.update(permission={}), "Unsupported LLM"),
    (lambda c: c.pop("model"), "requires model"),
    (lambda c: c.update(model="local/absent"), "explicit provider model definition"),
    (lambda c: c["agent"]["build"].update(prompt="not allowed"), "Unsupported agent"),
    (lambda c: c["agent"]["build"].update(temperature=True), "finite number"),
    (lambda c: c.update(disabled_providers=["local"]), "disabled provider"),
    (lambda c: c.update(enabled_providers=["other"]), "outside enabled_providers"),
    (lambda c: c["provider"]["local"].update(models=[]), "must be an object"),
])
def test_fragment_rejects_invalid_shapes_and_unresolvable_models(baseline, mutation, match):
    mutation(baseline)
    with pytest.raises(ValueError, match=match):
        validate_llm_fragment(baseline)


@pytest.mark.parametrize("field,value,match", [
    ("temperature", 0, "temperature must be a boolean"),
    ("limit", {"context": -1}, "context limit"),
    ("limit", {"output": "wrong"}, "output limit"),
])
def test_common_validation_reused_before_app_creation(tmp_path, baseline, field, value, match):
    baseline["provider"]["local"]["models"]["deepseek-v4.1-flash"][field] = value
    selected = select_llm_configuration(write_config(tmp_path / "llm.json", baseline))
    with pytest.raises((ValueError, provider_module.ProviderError), match=match):
        compose_llm_configuration({}, selected)


def test_bad_json_or_missing_file_never_falls_back(tmp_path):
    with pytest.raises(ValueError, match="Unable to read UTF-8 JSON"):
        select_llm_configuration(tmp_path / "missing.json")
    invalid = tmp_path / "invalid.json"
    invalid.write_text("{broken", encoding="utf-8")
    with pytest.raises(ValueError, match="Unable to read UTF-8 JSON"):
        select_llm_configuration(DEFAULT, llm_config=invalid)


@pytest.mark.parametrize("kwargs", [{"model": "deepseek-v4.1-flash"}, {"base_url": "https://example.invalid"}])
def test_explicit_file_conflicts_with_either_legacy_flag(kwargs):
    with pytest.raises(ValueError, match="conflicts"):
        select_llm_configuration(DEFAULT, llm_config=DEFAULT, **kwargs)


def test_resume_uses_saved_authority_even_if_default_file_is_missing(tmp_path, baseline):
    baseline["provider"]["local"]["models"]["deepseek-v4.1-flash"]["options"]["reasoningEffort"] = "medium"
    selected = select_llm_configuration(tmp_path / "missing-default.json", resume=True,
                                        saved_config=baseline, saved_source=tmp_path / "settings.json")
    result = compose_llm_configuration({}, selected)
    assert result.config["provider"]["local"]["models"]["deepseek-v4.1-flash"]["options"]["reasoningEffort"] == "medium"
    assert explicit_root_model(result.config, selected, "build") is None
    assert selected.source == str(tmp_path / "settings.json")


def test_missing_saved_config_requires_explicit_file_even_with_legacy_override(tmp_path):
    with pytest.raises(ValueError, match="explicitly provide --llm-config"):
        select_llm_configuration(DEFAULT, resume=True, model="deepseek-v4.1-flash")
    selected = select_llm_configuration(tmp_path / "unused.json", resume=True, llm_config=DEFAULT)
    assert selected.switch_model
    assert any("無法由該檔證實" in message for message in selected.messages)


def test_resume_explicit_config_switches_root_role_model_and_logs_saved_changes(tmp_path, baseline):
    old = deepcopy(baseline)
    baseline["provider"]["local"]["models"]["role-model"] = {"temperature": False, "limit": {"output": 111}}
    baseline["agent"]["build"]["model"] = "local/role-model"
    path = write_config(tmp_path / "switch.json", baseline)
    selected = select_llm_configuration(DEFAULT, llm_config=path, resume=True, saved_config=old,
                                        saved_source="prior/settings.json.config")
    result = compose_llm_configuration({}, selected)
    assert explicit_root_model(result.config, selected, "build") == "local/role-model"
    assert any("prior/settings.json.config" in message and "agent.build.model" in message for message in result.messages)


def test_legacy_override_requires_declared_exact_api_name_and_never_copies_capabilities(tmp_path, baseline):
    with pytest.raises(ValueError, match="explicit provider model definition"):
        select_llm_configuration(DEFAULT, model="unknown")
    baseline["provider"]["local"]["models"]["vendor/model-name"] = {"temperature": False, "limit": {"output": 73}}
    baseline["agent"]["build"]["model"] = "local/deepseek-v4.1-flash"
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline, model="vendor/model-name")
    result = compose_llm_configuration({}, selected)
    assert explicit_root_model(result.config, selected, "build") == "local/vendor/model-name"
    definition = result.config["provider"]["local"]["models"]["vendor/model-name"]
    assert definition == {"temperature": False, "limit": {"output": 73}}


def test_base_url_only_resume_preserves_session_selection_and_logs_shared_provider(baseline):
    baseline["agent"]["general"]["model"] = "local/deepseek-v4.1-flash"
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline,
                                        base_url="https://replacement.invalid/v1")
    result = compose_llm_configuration({}, selected)
    assert explicit_root_model(result.config, selected, "build") is None
    assert result.config["provider"]["local"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert any("同 provider" in message and "general" in message for message in result.messages)


def add_other_provider(baseline):
    baseline["provider"]["other"] = {
        "options": {"baseURL": "https://other.invalid/v1", "apiKey": "{env:LOCAL_OPENAI_API_KEY}"},
        "models": {"other-model": {"temperature": False, "limit": {"context": 8192, "output": 1000}}},
    }


@pytest.mark.parametrize("root_agent", [None, "researcher"])
def test_fresh_base_url_targets_actual_root_role_provider(tmp_path, baseline, root_agent):
    add_other_provider(baseline)
    baseline["agent"]["researcher"] = {"model": "other/other-model", "temperature": 0.3}
    source = write_config(tmp_path / "llm.json", baseline)
    selected = select_llm_configuration(source, base_url="https://replacement.invalid/v1")
    workspace = {"default_agent": "researcher", "agent": {"researcher": {"mode": "primary"}}}
    result = compose_llm_configuration(workspace, selected, root_agent=root_agent)
    assert result.config["provider"]["other"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert result.saved_config["provider"]["other"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert result.config["provider"]["local"]["options"]["baseURL"] == baseline["provider"]["local"]["options"]["baseURL"]
    assert selected.config == baseline
    assert any("researcher" in message and "other/other-model" in message for message in result.messages)
    assert explicit_root_model(result.config, selected, "researcher") == "other/other-model"


def test_resumed_base_url_uses_saved_session_provider_instead_of_config_default(baseline):
    add_other_provider(baseline)
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline,
                                        base_url="https://replacement.invalid/v1")
    result = compose_llm_configuration({}, selected, root_agent="build", session_model="other/other-model")
    assert result.config["provider"]["other"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert result.config["provider"]["local"]["options"]["baseURL"] == baseline["provider"]["local"]["options"]["baseURL"]
    assert explicit_root_model(result.config, selected, "build") is None


def test_resumed_base_url_role_override_precedes_saved_session_model(baseline):
    add_other_provider(baseline)
    baseline["agent"]["build"]["model"] = "other/other-model"
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline,
                                        base_url="https://replacement.invalid/v1")
    result = compose_llm_configuration({}, selected, root_agent="build", session_model="local/deepseek-v4.1-flash")
    assert result.config["provider"]["other"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert result.config["provider"]["local"]["options"]["baseURL"] == baseline["provider"]["local"]["options"]["baseURL"]


def test_legacy_model_and_base_url_select_local_over_role_and_saved_session(baseline):
    add_other_provider(baseline)
    baseline["agent"]["build"]["model"] = "other/other-model"
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline,
                                        model="deepseek-v4.1-flash", base_url="https://replacement.invalid/v1")
    result = compose_llm_configuration({}, selected, root_agent="build", session_model="other/other-model")
    assert result.config["provider"]["local"]["options"]["baseURL"] == "https://replacement.invalid/v1"
    assert result.config["provider"]["other"]["options"]["baseURL"] == "https://other.invalid/v1"
    assert explicit_root_model(result.config, selected, "build") == "local/deepseek-v4.1-flash"


def test_base_url_requires_existing_endpoint_on_actual_selected_provider(baseline):
    add_other_provider(baseline)
    del baseline["provider"]["other"]["options"]["baseURL"]
    selected = select_llm_configuration(DEFAULT, resume=True, saved_config=baseline,
                                        base_url="https://replacement.invalid/v1")
    with pytest.raises(ValueError, match=r"requires existing provider.other.options.baseURL"):
        compose_llm_configuration({}, selected, root_agent="build", session_model="other/other-model")


def test_literal_key_is_runtime_only_and_file_key_survives_resume(tmp_path, baseline):
    baseline["provider"]["local"]["options"]["apiKey"] = "literal-secret"
    path = write_config(tmp_path / "literal.json", baseline)
    result = compose_llm_configuration({}, select_llm_configuration(path))
    assert result.config["provider"]["local"]["options"]["apiKey"] == "literal-secret"
    assert "apiKey" not in result.saved_config["provider"]["local"]["options"]
    assert "literal-secret" not in "\n".join(result.messages)
    assert any("明文憑證未保存" in message for message in result.messages)
    (tmp_path / "secret.txt").write_text("file-secret", encoding="utf-8")
    baseline["provider"]["local"]["options"]["apiKey"] = "{file:secret.txt}"
    path = write_config(tmp_path / "file.json", baseline)
    (tmp_path / "different").mkdir()  # a run's output folder exists; Linux cannot open different/../secret.txt otherwise
    first = compose_llm_configuration({}, select_llm_configuration(path), saved_directory=tmp_path / "different")
    saved_key = first.saved_config["provider"]["local"]["options"]["apiKey"]
    assert saved_key == "{file:" + str(Path("..") / "secret.txt") + "}"
    resumed = select_llm_configuration(DEFAULT, resume=True, saved_config=first.saved_config,
                                        saved_source=tmp_path / "different" / "settings.json")
    second = compose_llm_configuration({}, resumed)
    assert second.config["provider"]["local"]["options"]["apiKey"] == "file-secret"


def test_sensitive_literal_endpoint_is_runtime_only(tmp_path, baseline):
    private_url = "https://private-user:private-password@service.invalid:8443/v1?key=private-query#private-fragment"
    baseline["provider"]["local"]["options"]["baseURL"] = private_url
    result = compose_llm_configuration({}, select_llm_configuration(write_config(tmp_path / "llm.json", baseline)))
    public_url = "https://service.invalid:8443/v1"
    assert result.config["provider"]["local"]["options"]["baseURL"] == private_url
    assert result.saved_config["provider"]["local"]["options"]["baseURL"] == public_url
    assert public_endpoint_url(private_url) == public_url
    recorded = json.dumps(result.saved_config) + "\n".join(result.messages)
    assert all(secret not in recorded for secret in ("private-user", "private-password", "private-query", "private-fragment"))
    assert any("原網址" in message and "未保存" in message for message in result.messages)


def test_sensitive_endpoint_placeholder_survives_without_exposing_resolved_value(tmp_path, baseline, monkeypatch):
    private_url = "https://hidden-user:hidden-password@service.invalid/v1?key=hidden-query#hidden-fragment"
    monkeypatch.setenv("PRIVATE_TEST_ENDPOINT", private_url)
    baseline["provider"]["local"]["options"]["baseURL"] = "{env:PRIVATE_TEST_ENDPOINT}"
    result = compose_llm_configuration({}, select_llm_configuration(write_config(tmp_path / "llm.json", baseline)))
    assert result.config["provider"]["local"]["options"]["baseURL"] == private_url
    assert result.saved_config["provider"]["local"]["options"]["baseURL"] == "{env:PRIVATE_TEST_ENDPOINT}"
    assert public_endpoint_url(private_url) == "https://service.invalid/v1"
    recorded = json.dumps(result.saved_config) + "\n".join(result.messages)
    assert all(secret not in recorded for secret in ("hidden-user", "hidden-password", "hidden-query", "hidden-fragment"))


def test_actual_request_carries_the_configured_settings_with_explicit_root_model(tmp_path, monkeypatch, offline):
    selected = select_llm_configuration(DEFAULT)
    result = compose_llm_configuration({}, selected)
    agents = build_agents(result.config, worktree=tmp_path)
    root_agent = default_agent_name(result.config, agents)
    monkeypatch.setenv("OPENCODE_MODEL", "unrelated/ignored")
    client = Client(SimpleNamespace(get=offline), result.config)
    provider, model = client.resolve(explicit_root_model(result.config, selected, root_agent))
    sent = []

    def receive(transport, request):
        sent.append(json.loads(request.content))
        return httpx.Response(200, json={"choices": [{"message": {"content": "offline reply"}, "finish_reason": "stop"}]})

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", receive)
    response = client.complete(provider=provider, model=model, system="offline", messages=[], tools=[],
                               temperature=agents[root_agent].temperature)
    assert response.text == "offline reply"
    expected = {"model": canonical.model_name(), "messages": [{"role": "system", "content": "offline"}],
                "max_tokens": canonical.output_limit(), "reasoning_effort": canonical.reasoning_effort(),
                "temperature": canonical.agent_temperature(root_agent)}
    if canonical.seed() == "random":
        assert isinstance(sent[0].pop("seed"), int)  # a new seed for each request, as configured
    elif canonical.seed() is not None:
        expected["seed"] = canonical.seed()
    assert sent == [expected]
    assert {name: agents[name].temperature for name in result.config["agent"]} == canonical.agent_temperatures()
