"""Exercise the one entry's recorded runs and their continuation through offline HTTP transport."""
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
from unittest.mock import patch

import httpx
import pytest

from scripts import recording, run_tui
from scripts.llm_configuration import select_llm_configuration
from tests import canonical_config as canonical

PROJECT = Path(__file__).resolve().parents[2]


@pytest.fixture
def offline(tmp_path, monkeypatch):
    environment = patch.dict(os.environ)
    environment.start()
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_PERMISSION",
                 "OPENCODE_MODEL", "OPENCODE_PURE"):
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("OPENCODE_MODEL", "unexpected/ambient-model")
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-secret-never-log")
    monkeypatch.setattr(sys, "path", list(sys.path))
    monkeypatch.setattr(sys, "dont_write_bytecode", sys.dont_write_bytecode)
    monkeypatch.setattr(tempfile, "tempdir", tempfile.tempdir)
    # Recorded runs isolate their own paths; prevent all actual socket connections.
    connect = socket.socket.connect
    def blocked(sock, address):
        # Windows asyncio creates a loopback self-pipe through socketpair().
        if isinstance(address, tuple) and address[0] in ("127.0.0.1", "::1"):
            return connect(sock, address)
        raise AssertionError("Offline entrypoint test attempted a network connection")
    monkeypatch.setattr(socket.socket, "connect", blocked)
    bodies = []

    async def receive(transport, request):
        body = json.loads(request.content)
        bodies.append(body)
        if body.get("stream"):
            event = {"choices": [{"delta": {"content": "Offline transport boundary exercised."},
                                  "finish_reason": "stop"}]}
            return httpx.Response(200, headers={"content-type": "text/event-stream"},
                                  content="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n")
        return httpx.Response(200, json={"choices": [{"message": {"content": "Offline answer."},
                                                     "finish_reason": "stop"}]})
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", receive)
    try:
        yield bodies
    finally:
        environment.stop()


def invoke(args):
    assert run_tui.main([*map(str, args)]) == 0


def assert_wire(output, temperature=None):
    """Requests carry the canonical settings (or the temperature a test changed to)."""
    temperature = canonical.agent_temperature("build") if temperature is None else temperature
    requests = sorted(output.glob("wire-*/request.body.json"))
    assert requests
    for path in requests:
        body = json.loads(path.read_text(encoding="utf-8"))
        assert (body["model"], body["reasoning_effort"], body["temperature"], body["max_tokens"]) == (
            canonical.model_name(), canonical.reasoning_effort(), temperature, canonical.output_limit())
        assert (path.parent / "response.raw.bin").read_bytes().endswith(b"data: [DONE]\n\n")
    assert "offline-secret-never-log" not in (output / "settings.json").read_text(encoding="utf-8")


def test_a_recorded_task_and_its_continuations_use_the_saved_config(tmp_path, offline):
    source = tmp_path / "source"
    source.mkdir()
    (source / "input.txt").write_text("Offline protocol fixture, not research evidence.", encoding="utf-8")
    prompt = tmp_path / "prompt.txt"
    prompt.write_text("Exercise the configuration boundary only.", encoding="utf-8")
    first = tmp_path / "first"
    invoke(["--record", first, "--from", source, "--prompt", prompt, "--deep"])
    assert_wire(first)
    # With deep research on, the reviewer makes its own calls on the same model: the verification plan before
    # the first step and the review at the round's end. The offline reply is not JSON, so each gets its one
    # repair and is recorded as failed; the later rounds turn both off.
    plan = json.loads((first / "verification-plan.json").read_text(encoding="utf-8"))
    assert plan["status"] == "failed" and "failed its one repair" in plan["error"]
    review = json.loads((first / "round-review.json").read_text(encoding="utf-8"))
    assert review["status"] == "failed" and "failed its one repair" in review["error"]
    assert len(offline) == 5 and {body["model"] for body in offline} == {canonical.model_name()}
    saved_history = (first / "sessions.json").read_bytes()
    saved_result = (first / "result.json").read_bytes()
    sid = json.loads(saved_result)["result"]["sessionID"]
    changed = select_llm_configuration(PROJECT / "config/llm.opencode.json").config
    changed["agent"]["build"]["temperature"] = 0.9
    changed["provider"]["local"]["models"][canonical.model_name()]["options"]["reasoningEffort"] = "medium"
    (first / "workspace/opencode.json").write_text(json.dumps(changed), encoding="utf-8")
    second = tmp_path / "second"
    invoke([first, "--continue", "--record", second, "--prompt", prompt, "--no-review"])
    assert_wire(second)
    assert json.loads((second / "result.json").read_text())["result"]["sessionID"] == sid
    assert (first / "sessions.json").read_bytes() == saved_history
    assert (first / "result.json").read_bytes() == saved_result
    changed["agent"]["build"]["temperature"] = 0.25
    changed["provider"]["local"]["models"][canonical.model_name()]["options"]["reasoningEffort"] = "none"
    chosen = tmp_path / "explicit.json"
    chosen.write_text(json.dumps(changed), encoding="utf-8")
    third = tmp_path / "third"
    # Latest trace selects settings, while its existing previous_run link locates
    # the original in-place workspace/state. No history is migrated.
    invoke([second, "--continue", "--record", third, "--prompt", prompt, "--llm-config", chosen, "--no-review"])
    assert_wire(third, 0.25)
    assert json.loads((third / "result.json").read_text())["result"]["sessionID"] == sid
    fourth = tmp_path / "fourth"
    invoke([third, "--continue", "--record", fourth, "--prompt", prompt, "--no-review"])
    assert_wire(fourth, 0.25)
    assert json.loads((fourth / "result.json").read_text())["result"]["sessionID"] == sid
    assert recording.state_run(fourth) == first
    assert len(offline) == 8


def test_two_questions_in_one_recorded_round(tmp_path, offline):
    source = tmp_path / "source"
    source.mkdir()
    first, second = tmp_path / "q1.txt", tmp_path / "q2.txt"
    first.write_text("Offline boundary question one.", encoding="utf-8")
    second.write_text("Offline boundary question two.", encoding="utf-8")
    output = tmp_path / "investigation"
    invoke(["--record", output, "--from", source, "--prompt", first, "--prompt", second])
    assert_wire(output)  # the canonical model, reasoning effort, temperature and output limit
    # Without deep research the questions get the general agent: no research tools, no verification plan and
    # no round review, so the two questions' own calls are the only ones (opencode/deep.py).
    assert len(offline) == 2
    assert not any(tool["function"]["name"].startswith(("research_", "planning_"))
                   for body in offline for tool in body.get("tools") or [])
    result = json.loads((output / "result.json").read_text(encoding="utf-8"))
    assert result["round_review"] == "skipped" and "verification_plan" not in result
    assert [turn["status"] for turn in result["turns"]] == ["completed", "completed"]
    assert (output / "answer-1.md").is_file() and (output / "answer-2.md").is_file()


def test_missing_saved_config_rejected_before_mutation(tmp_path, monkeypatch, offline):
    # Pure selection boundary: legacy settings cannot silently acquire new defaults.
    with pytest.raises(ValueError, match="(?i)saved|保存|llm-config"):
        select_llm_configuration(PROJECT / "config/llm.opencode.json", resume=True,
                                 saved_config=None, saved_source="missing/settings.json")
    assert not offline
