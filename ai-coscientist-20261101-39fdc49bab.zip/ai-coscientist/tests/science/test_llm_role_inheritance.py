"""Offline managed configuration through real parent and task-child requests."""

import json
from pathlib import Path

import httpx
import pytest

from opencode.app import App
from opencode.store import Store
from scripts.llm_configuration import (
    compose_llm_configuration, explicit_root_model, select_llm_configuration,
)
from test_review_provider import install_transport, sse_event, wire_response
from tests import canonical_config as canonical


DEFAULT_LLM_CONFIG = Path(__file__).resolve().parents[2] / "config/llm.opencode.json"


# None: the canonical config as it is; 0.4: an explicit parent temperature that differs from the child's.
@pytest.mark.parametrize("outer_temperature", [None, 0.4])
def test_managed_parent_and_task_child_send_their_own_role_temperature(
        monkeypatch, tmp_path, outer_temperature):
    def forbidden(*args, **kwargs):
        pytest.fail("Role inheritance tests must not open real network connections")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    for name in ("XDG_DATA_HOME", "XDG_CONFIG_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(name, str(tmp_path / name.lower()))
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-role-test-key")
    monkeypatch.setenv("OPENCODE_MODEL", "unselected/model-must-not-win")
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_DIR", "OPENCODE_AUTH_CONTENT"):
        monkeypatch.delenv(name, raising=False)

    selected_path = DEFAULT_LLM_CONFIG
    if outer_temperature is not None:
        fragment = json.loads(DEFAULT_LLM_CONFIG.read_text(encoding="utf-8"))
        fragment["agent"]["build"]["temperature"] = outer_temperature
        selected_path = tmp_path / "explicit-parent-temperature.json"
        selected_path.write_text(json.dumps(fragment), encoding="utf-8")
    selection = select_llm_configuration(selected_path)
    effective = compose_llm_configuration({
        "agent": {
            "build": {"prompt": "OUTER_ROLE_ONLY", "temperature": 0.9},
            "general": {"prompt": "CHILD_ROLE_ONLY", "temperature": 0.8},
        },
    }, selection)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    # Bound guidance discovery to this empty test workspace.
    (workspace / ".git").mkdir()
    task_arguments = {
        "description": "Offline child transport check",
        "prompt": "CHILD_MISSION_ONLY: return the synthetic transport receipt.",
        "subagent_type": "general",
    }
    requests = []

    def receive(request):
        body = json.loads(request.content)
        requests.append(body)
        assert request.method == "POST"
        assert request.url.path == "/v1/chat/completions"
        assert request.headers["authorization"] == "Bearer offline-role-test-key"
        system = body["messages"][0]["content"]
        if "CHILD_ROLE_ONLY" in system:
            return wire_response("openai", text="Child offline receipt.")
        assert "OUTER_ROLE_ONLY" in system
        if any(message["role"] == "tool" for message in body["messages"]):
            return wire_response("openai", text="Parent offline receipt.")
        return httpx.Response(
            200, headers={"content-type": "text/event-stream"},
            content=sse_event({"tool_calls": [{
                "index": 0, "id": "offline-role-child", "type": "function",
                "function": {"name": "task", "arguments": json.dumps(task_arguments)},
            }]}, reason="tool_calls") + b"data: [DONE]\n\n",
        )

    install_transport(monkeypatch, receive)
    store = Store(tmp_path / "sessions.sqlite3")
    try:
        app = App(directory=workspace, store=store, auto_approve=True, config=effective.config)
        # This boundary test covers parent/task generation, not auxiliary titles.
        app.generate_titles = False
        model = explicit_root_model(effective.config, selection, "build")
        session = app.create_session(agent="build", model=model, title="Offline role boundary")
        result = app.prompt(session["id"], "OUTER_HISTORY_PRIVATE: delegate the explicit child mission.",
                            agent="build", model=model)
        assert result["status"] == "completed"
        assert result["text"] == "Parent offline receipt."
        children = store.children(session["id"])
        assert len(children) == 1
        assert children[0]["agent"] == "general"
        assert children[0]["model"] == model == canonical.root_model()
    finally:
        store.close()

    assert len(requests) == 3
    outer = canonical.agent_temperature("build") if outer_temperature is None else outer_temperature
    assert [body["temperature"] for body in requests] == [outer, canonical.agent_temperature("general"), outer]
    for body in requests:
        assert body["model"] == canonical.model_name()
        assert body["reasoning_effort"] == canonical.reasoning_effort()
        assert body["max_tokens"] == canonical.output_limit()
    child = requests[1]
    assert "CHILD_MISSION_ONLY" in json.dumps(child["messages"])
    assert "OUTER_HISTORY_PRIVATE" not in json.dumps(child["messages"])
    assert "OUTER_ROLE_ONLY" not in child["messages"][0]["content"]
