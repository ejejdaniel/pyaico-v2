"""Offline wire observation tests; no network or model calls are permitted."""
from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import gzip
import json
from pathlib import Path
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]

import httpx

from scripts.llm_wire import WireRecorder, model_endpoints

ENDPOINT = "https://offline.invalid/v1/chat/completions"
RAW = b'data: {"choices":[{"delta":{"content":"one"}}]}\r\n\r\ndata: [DONE]\r\n\r\n'


class SyncChunks(httpx.SyncByteStream):
    def __init__(self, chunks=(), failure=None, close_failure=None):
        self.chunks = chunks
        self.failure, self.close_failure = failure, close_failure
        self.closed = False
        self.reads = 0

    def __iter__(self):
        for chunk in self.chunks:
            self.reads += 1
            yield chunk
        if self.failure is not None:
            raise self.failure

    def close(self):
        self.closed = True
        if self.close_failure is not None:
            raise self.close_failure


class AsyncChunks(httpx.AsyncByteStream):
    def __init__(self, chunks=(), failure=None, close_failure=None):
        self.chunks = chunks
        self.failure, self.close_failure = failure, close_failure
        self.closed = False
        self.reads = 0

    async def __aiter__(self):
        for chunk in self.chunks:
            self.reads += 1
            yield chunk
        if self.failure is not None:
            raise self.failure

    async def aclose(self):
        self.closed = True
        if self.close_failure is not None:
            raise self.close_failure


class WireTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix="llm-wire-")
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.guard = ExitStack()
        self.addCleanup(self.guard.close)
        # MockTransport is the only allowed transport in these tests. A missed
        # injection must fail before opening a real connection.
        for cls, name in ((httpx.HTTPTransport, "handle_request"),
                          (httpx.AsyncHTTPTransport, "handle_async_request")):
            self.guard.enter_context(patch.object(cls, name, side_effect=AssertionError("Network forbidden")))

    def record(self, index=1):
        return self.root / f"wire-{index:03}"

    def state(self, index=1):
        return json.loads((self.record(index) / "response-stream.json").read_bytes())

    def test_sync_stream_preserves_chunks_and_request_without_reading_ahead(self):
        chunks = [RAW[:9], RAW[9:]]
        source = SyncChunks(chunks)
        body = '{ "message": "中文字", "temperature": 0 }\r\n'.encode()
        received = []

        def respond(request):
            received.append(request)
            return httpx.Response(200, stream=source)

        with WireRecorder(self.root, endpoints=[ENDPOINT]) as recorder:
            with httpx.Client(transport=httpx.MockTransport(respond), timeout=17) as client:
                with client.stream("POST", ENDPOINT, content=body) as response:
                    self.assertEqual(source.reads, 0)
                    iterator = response.iter_raw()
                    self.assertEqual(next(iterator), chunks[0])
                    self.assertEqual((self.record() / "response.raw.bin").read_bytes(), chunks[0])
                    self.assertEqual(source.reads, 1)
                    self.assertEqual(list(iterator), chunks[1:])
            self.assertEqual(recorder.count, 1)
        self.assertEqual(received[0].content, body)
        self.assertEqual(received[0].extensions["timeout"]["read"], 17)
        self.assertEqual((self.record() / "request.body.json").read_bytes(), body)
        self.assertTrue(source.closed)
        self.assertEqual(self.state(), {"complete": True, "closed": True, "raw_bytes": len(RAW)})

    def test_raw_compressed_bytes_and_buffered_mock_responses(self):
        decoded = b'{"value": "unchanged"}\r\n'
        encoded = gzip.compress(decoded)
        for buffered in (False, True):
            with self.subTest(buffered=buffered):
                def respond(request):
                    kwargs = {"content": encoded} if buffered else {"stream": SyncChunks([encoded[:8], encoded[8:]])}
                    return httpx.Response(200, headers={"content-encoding": "gzip"}, **kwargs)

                with WireRecorder(self.root, endpoints=[ENDPOINT]):
                    with httpx.Client(transport=httpx.MockTransport(respond)) as client:
                        self.assertEqual(client.post(ENDPOINT, content=b"{}").content, decoded)
                folder = self.record(2 if buffered else 1)
                self.assertEqual((folder / "response.raw.bin").read_bytes(), encoded)

    def test_secret_headers_url_and_exception_messages_are_not_saved(self):
        endpoint = "https://alice:password-secret@offline.invalid/v1/chat/completions?api_key=query-secret#fragment-secret"
        headers = {"Authorization": "Bearer auth-secret", "X-Api-Key": "key-secret", "Cookie": "cookie-secret",
                   "Proxy-Authorization": "proxy-secret", "Content-Type": "application/json"}
        response_headers = {"Set-Cookie": "cookie-secret", "Authorization": "auth-secret", "X-Api-Key": "key-secret",
                            "Location": "https://x.invalid/?key=location-secret", "X-Custom-Credential": "custom-secret",
                            "content-type": "application/json"}
        with WireRecorder(self.root, endpoints=[ENDPOINT]):
            with httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=b"{}", headers=response_headers))) as client:
                client.post(endpoint, content=b"{}", headers=headers)
            failure = httpx.ConnectError("authorization auth-secret " + endpoint)
            def broken(request):
                raise failure
            with httpx.Client(transport=httpx.MockTransport(broken)) as client:
                with self.assertRaises(httpx.ConnectError) as caught:
                    client.post(endpoint, content=b"{}", headers=headers)
            self.assertIs(caught.exception, failure)
        artifacts = b"\n".join(p.read_bytes() for p in self.root.rglob("*") if p.is_file())
        self.assertNotIn(b"secret", artifacts)
        self.assertNotIn(b"alice", artifacts)
        self.assertEqual(json.loads((self.record() / "request-http.json").read_bytes())["url"], ENDPOINT)
        self.assertEqual((self.record(2) / "error.txt").read_text().strip(), "ConnectError")
        self.assertEqual((self.record(2) / "response.raw.bin").read_bytes(), b"")
        self.assertFalse((self.record(2) / "response-http.json").exists())

    def test_os_error_codes_and_timing_are_kept_without_messages(self):
        import httpcore
        root_cause = OSError(10060, "secret-in-system-text")
        root_cause.winerror = 10060
        root_cause.errno = 10060
        try:
            try:
                raise root_cause
            except OSError as exc:
                raise httpcore.ConnectError("auth-secret") from exc
        except httpcore.ConnectError as exc:
            middle = exc
        failure = httpx.ConnectError("Bearer token-secret")
        failure.__cause__ = middle

        def broken(request):
            raise failure

        def stalled(request):
            return httpx.Response(200, stream=SyncChunks([], failure=httpx.ReadTimeout("secret")))

        with WireRecorder(self.root, endpoints=[ENDPOINT]):
            with httpx.Client(transport=httpx.MockTransport(broken)) as client:
                with self.assertRaises(httpx.ConnectError):
                    client.post(ENDPOINT, content=b"{}")
            with httpx.Client(transport=httpx.MockTransport(stalled)) as client:
                with self.assertRaises(httpx.ReadTimeout):
                    with client.stream("POST", ENDPOINT, content=b"{}") as response:
                        response.read()
        entry, = json.loads((self.record() / "error.json").read_text(encoding="utf-8"))
        # Python picks the subclass for the errno: TimeoutError for 10060 on Windows, plain OSError elsewhere.
        self.assertEqual(entry["chain"], ["ConnectError", "ConnectError", type(root_cause).__name__])
        self.assertEqual(entry["phase"], "request")
        self.assertEqual(entry["os_error"]["winerror"], 10060)
        self.assertEqual(entry["os_error"]["winerror_name"], "WSAETIMEDOUT")
        self.assertIsInstance(entry["elapsed_s"], float)
        stall, = json.loads((self.record(2) / "error.json").read_text(encoding="utf-8"))
        self.assertEqual((stall["phase"], stall["raw_bytes_before_error"], stall["os_error"]), ("stream", 0, None))
        timing = json.loads((self.record(2) / "timing.json").read_text(encoding="utf-8"))
        self.assertIsNotNone(timing["response_headers_after_s"])
        self.assertIsNone(timing["first_chunk_after_s"])  # headers arrived, no data: the v7 pattern
        artifacts = b"\n".join(p.read_bytes() for p in self.root.rglob("*") if p.is_file())
        self.assertNotIn(b"secret", artifacts)

    def test_endpoint_filter_ignores_mcp_web_and_other_methods(self):
        calls = []
        def respond(request):
            calls.append(request.url)
            return httpx.Response(200, content=b"body")
        with WireRecorder(self.root, endpoints=[ENDPOINT]) as recorder:
            with httpx.Client(transport=httpx.MockTransport(respond)) as client:
                client.get(ENDPOINT)
                client.post("https://web.invalid/v1/chat/completions", content=b"{}")
                client.post("https://offline.invalid/mcp", content=b"{}")
                client.post("https://offline.invalid/v1/models", content=b"{}")
            self.assertEqual(recorder.count, 0)
        self.assertEqual(len(calls), 4)
        self.assertEqual(list(self.root.glob("wire-*")), [])

    def test_unconsumed_empty_and_early_closed_responses_are_distinct(self):
        sources = [SyncChunks([RAW]), SyncChunks([]), SyncChunks([RAW[:9], RAW[9:]])]
        with WireRecorder(self.root, endpoints=[ENDPOINT]):
            with httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, stream=sources.pop(0)))) as client:
                with client.stream("POST", ENDPOINT, content=b"{}"):
                    pass
                client.post(ENDPOINT, content=b"{}")
                with client.stream("POST", ENDPOINT, content=b"{}") as response:
                    iterator = response.iter_raw()
                    self.assertEqual(next(iterator), RAW[:9])
                    iterator.close()
        self.assertEqual(self.state(1), {"complete": False, "closed": True, "raw_bytes": 0})
        self.assertEqual(self.state(2), {"complete": True, "closed": True, "raw_bytes": 0})
        self.assertEqual(self.state(3), {"complete": False, "closed": True, "raw_bytes": 9})
        self.assertFalse((self.record(3) / "error.txt").exists())

    def test_partial_read_failure_and_close_failure_propagate_unchanged(self):
        failure = httpx.ReadError("do not repeat key-secret")
        source = SyncChunks([RAW[:9]], failure=failure)
        with WireRecorder(self.root, endpoints=[ENDPOINT]):
            with httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, stream=source))) as client:
                with self.assertRaises(httpx.ReadError) as caught:
                    client.post(ENDPOINT, content=b"{}")
        self.assertIs(caught.exception, failure)
        self.assertTrue(source.closed)
        self.assertEqual((self.record() / "response.raw.bin").read_bytes(), RAW[:9])
        self.assertEqual(self.state(), {"complete": False, "closed": True, "raw_bytes": 9})
        close_failure = RuntimeError("close secret")
        source = SyncChunks(close_failure=close_failure)
        with WireRecorder(self.root, endpoints=[ENDPOINT]):
            with httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, stream=source))) as client:
                with self.assertRaises(RuntimeError) as caught:
                    with client.stream("POST", ENDPOINT, content=b"{}"):
                        pass
        self.assertIs(caught.exception, close_failure)
        self.assertEqual(self.state(2), {"complete": False, "closed": True, "raw_bytes": 0})

    def test_http_failure_does_not_retry_or_block_later_request(self):
        calls = []
        def respond(request):
            calls.append(request)
            return httpx.Response(503 if len(calls) == 1 else 200, content=b"same body")
        with WireRecorder(self.root, endpoints=[ENDPOINT]) as recorder:
            with httpx.Client(transport=httpx.MockTransport(respond)) as client:
                self.assertEqual(client.post(ENDPOINT, content=b"{}").status_code, 503)
                self.assertEqual(client.post(ENDPOINT, content=b"{}").status_code, 200)
            self.assertEqual(recorder.count, 2)
        self.assertEqual(len(calls), 2)
        self.assertEqual((self.record() / "response.raw.bin").read_bytes(), b"same body")

    def test_async_stream_and_cancellation_preserve_partial_bytes_and_close(self):
        async def check():
            failure = asyncio.CancelledError("secret")
            sources = [AsyncChunks([RAW[:9], RAW[9:]]), AsyncChunks([RAW[:9]], failure=failure), AsyncChunks([RAW])]
            pending = list(sources)
            with WireRecorder(self.root, endpoints=[ENDPOINT]) as recorder:
                async with httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(200, stream=pending.pop(0)))) as client:
                    async with client.stream("POST", ENDPOINT, content=b'{ "stream": true }\n') as response:
                        self.assertEqual(sources[0].reads, 0)
                        iterator = response.aiter_raw()
                        self.assertEqual(await anext(iterator), RAW[:9])
                        self.assertEqual((self.record() / "response.raw.bin").read_bytes(), RAW[:9])
                        self.assertEqual(b"".join([part async for part in iterator]), RAW[9:])
                    with self.assertRaises(asyncio.CancelledError) as caught:
                        await client.post(ENDPOINT, content=b"{}")
                    self.assertIs(caught.exception, failure)
                    async with client.stream("POST", ENDPOINT, content=b"{}"):
                        pass
                self.assertEqual(recorder.count, 3)
            self.assertTrue(all(s.closed for s in sources))
        asyncio.run(check())
        self.assertEqual(self.state(1), {"complete": True, "closed": True, "raw_bytes": len(RAW)})
        self.assertEqual(self.state(2), {"complete": False, "closed": True, "raw_bytes": 9})
        self.assertEqual(self.state(3), {"complete": False, "closed": True, "raw_bytes": 0})
        self.assertEqual((self.record(2) / "error.txt").read_text().strip(), "CancelledError")

    def test_concurrent_numbering_keeps_existing_artifacts(self):
        self.record().mkdir()
        (self.record() / "keep.txt").write_text("old")
        bodies = [json.dumps({"index": i}).encode() for i in range(24)]
        def send(body):
            with httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=r.content))) as client:
                self.assertEqual(client.post(ENDPOINT, content=body).content, body)
        with WireRecorder(self.root, endpoints=[ENDPOINT]) as recorder:
            with ThreadPoolExecutor(max_workers=8) as pool:
                list(pool.map(send, bodies))
            self.assertEqual(recorder.count, 24)
        self.assertEqual((self.record() / "keep.txt").read_text(), "old")
        captured = []
        for folder in sorted(self.root.glob("wire-*"))[1:]:
            body = (folder / "request.body.json").read_bytes()
            captured.append(body)
            self.assertEqual((folder / "response.raw.bin").read_bytes(), body)
        self.assertCountEqual(captured, bodies)

    def test_context_restores_httpx_even_after_failure(self):
        original = httpx.Client._transport_for_url, httpx.AsyncClient._transport_for_url
        with self.assertRaisesRegex(ValueError, "scope failed"):
            with WireRecorder(self.root, endpoints=[ENDPOINT]):
                raise ValueError("scope failed")
        self.assertEqual(original, (httpx.Client._transport_for_url, httpx.AsyncClient._transport_for_url))

    def test_real_provider_stream_abort_cancels_and_closes_without_reading_ahead(self):
        from opencode.provider import Client, ProviderError
        provider = Client(SimpleNamespace(get=lambda key: None), {
            "enabled_providers": ["local"], "provider": {
                "local": {"options": {"baseURL": "https://offline.invalid/v1"},
                          "models": {"test-model": {"limit": {"output": 20}}}},
            }})
        abort = threading.Event()
        partial = b'data: {"choices":[{"delta":{"content":"partial"}}]}\n'

        class WaitingStream(httpx.AsyncByteStream):
            closed = False
            async def __aiter__(self):
                yield partial
                # Common's existing abort watcher must cancel this wait. The
                # bound also makes a broken cancellation implementation fail
                # this offline test instead of leaving a blocked test thread.
                await asyncio.wait_for(asyncio.Event().wait(), timeout=2)
            async def aclose(self):
                self.closed = True

        source = WaitingStream()
        transport = httpx.MockTransport(lambda request: httpx.Response(200, stream=source))
        def on_text(text):
            self.assertEqual(text, "partial")
            abort.set()
        with patch.object(httpx.AsyncClient, "_transport_for_url", lambda client, url: transport):
            with WireRecorder(self.root, endpoints=model_endpoints(provider)):
                with self.assertRaisesRegex(ProviderError, "Model request aborted") as caught:
                    provider._openai(provider.providers["local"], "secret", "test-model", "",
                                     [{"role": "user", "content": "offline fixture"}], [], 0, on_text,
                                     abort_event=abort)
        self.assertEqual(caught.exception.partial.text, "partial")
        self.assertTrue(source.closed)
        self.assertEqual((self.record() / "response.raw.bin").read_bytes(), partial)
        self.assertEqual(self.state(), {"complete": False, "closed": True, "raw_bytes": len(partial)})
        self.assertIn("CancelledError", (self.record() / "error.txt").read_text())

    def test_real_provider_assembly_and_async_openai_path(self):
        from opencode.provider import Client
        config = {"model": "local/test-model", "enabled_providers": ["local", "claude"], "provider": {
            "local": {"options": {"baseURL": "https://offline.invalid/v1/", "apiKey": "key-secret"},
                      "models": {"test-model": {"temperature": True, "limit": {"output": 32000},
                                                  "options": {"reasoningEffort": "none"}}}},
            "claude": {"api": "anthropic", "options": {"baseURL": "https://claude.invalid/v1"}},
        }}
        provider = Client(SimpleNamespace(get=lambda key: None), config)
        self.assertEqual(model_endpoints(provider), {ENDPOINT, "https://claude.invalid/v1/messages"})
        seen = []
        result_bytes = b'{"choices":[{"message":{"content":"offline answer"},"finish_reason":"stop"}]}'
        def respond(request):
            seen.append(request)
            return httpx.Response(200, stream=AsyncChunks([result_bytes[:8], result_bytes[8:]]))
        transport = httpx.MockTransport(respond)
        # The real provider constructs its own AsyncClient for abortable calls.
        # Replace only the network transport selected by that client.
        with patch.object(httpx.AsyncClient, "_transport_for_url", lambda client, url: transport):
            with WireRecorder(self.root, endpoints=model_endpoints(provider)) as recorder:
                response = provider._openai(provider.providers["local"], "key-secret", "test-model", "",
                                            [{"role": "user", "content": "offline fixture"}], [], 0, None,
                                            abort_event=threading.Event())
                self.assertEqual(recorder.count, 1)
        self.assertEqual(response.text, "offline answer")
        self.assertEqual((self.record() / "response.raw.bin").read_bytes(), result_bytes)
        self.assertEqual((self.record() / "request.body.json").read_bytes(), seen[0].content)
        payload = json.loads(seen[0].content)
        self.assertEqual((payload["temperature"], payload["reasoning_effort"], payload["max_tokens"]), (0, "none", 32000))


if __name__ == "__main__":
    unittest.main()
