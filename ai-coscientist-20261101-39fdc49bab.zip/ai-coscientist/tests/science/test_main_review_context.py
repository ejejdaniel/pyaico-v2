"""Read-only review context boundaries, without model or scientific-quality claims."""

from copy import deepcopy
import json
from pathlib import Path
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Rule
from opencode.agent import Agent
from opencode.store import Store
from opencode.tools.types import Tool
from researchkit import records, reviewer, review_context_details as details
from researchkit.source_provenance import NativeSources
from researchkit.tools import _publish
import test_research_review as review_cases


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Review context tests must not call a model or the network")
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)


@pytest.fixture
def case():
    value = review_cases.ResearchReview(methodName="runTest")
    value.setUp()
    store = Store(value.root / "history.db")
    value.addCleanup(store.close)
    value.store = store
    value.ctx.app.store = store
    value.ctx.session_id = store.create_session(directory=str(value.workspace), agent="build", model=None)["id"]
    value.human = store.add_message(value.ctx.session_id, "user", {"content": "Inspect the frozen observation."})
    value.args["required_subjects"] = [deepcopy(value.value["checks"][0]["subject"])]
    value.args["commission_files"] = [deepcopy(value.args["files"][1])]
    value.model_value["checks"][0]["subject"] = {"required_subject": 1}
    value.ctx.app.permissions.ask = Mock(side_effect=AssertionError("Context must not ask the Broker"))
    try:
        yield value
    finally:
        value.doCleanups()


def save_call(case, *, arguments=None, result=None, metadata=None, error=None, reply=True):
    args = deepcopy(case.args if arguments is None else arguments)
    call = {"id": "review-call", "name": "research_review", "arguments": args}
    message = case.store.add_message(case.ctx.session_id, "assistant", {"tool_calls": [call]})
    result = case.value if result is None else result
    returned = None
    if reply:
        body = {"name": "research_review", "tool_call_id": call["id"],
                "content": result if isinstance(result, str) else json.dumps(result)}
        if metadata is not None:
            body["metadata"] = metadata
        if error:
            body["error"] = error
        returned = case.store.add_message(case.ctx.session_id, "tool", body)
    history = case.store.messages(case.ctx.session_id)
    position = next(index for index, item in enumerate(history) if item["id"] == message["id"])
    case.ctx.message_id, case.ctx.call_id = message["id"], call["id"]
    return {"position": position, "message_id": message["id"], "call": call, "reply": returned,
            "reply_position": len(history) - 1 if returned else None}, history


def initial_path(case, call):
    key = records.digest(details._q([case.ctx.session_id, call["message_id"], call["call"]["id"]]).encode())
    return case.workspace / ".research/review-runs" / key / "initial"


def save_initial(case, call, history):
    args = call["call"]["arguments"]
    reader = details._Reader(case.ctx, history)
    reader.selected(args)
    raw = reviewer._assemble(case.model_value["checks"], args, reader.selection)
    folder = initial_path(case, call)
    folder.mkdir(parents=True)
    (folder / "arguments.json").write_bytes((details._q(args) + "\n").encode())
    (folder / "response.txt").write_text(json.dumps(case.model_value), encoding="utf-8")
    (folder / "review.json").write_bytes(raw.encode())
    return folder


def text(items):
    return "\n".join(item[1] for item in items)


def test_plain_return_exact_scope_subjects_and_now_origin_without_judgment_copy(case, monkeypatch):
    call, history = save_call(case, metadata={"truncated": False})
    folder = save_initial(case, call, history)
    before = {path: path.read_bytes() for path in folder.iterdir()}
    monkeypatch.setattr(case.store, "messages", Mock(side_effect=AssertionError("History must be reused")))
    with case.reads() as opened:
        items = details.describe(case.ctx, call, history)
    actual = text(items)
    assert "初審三檔\":\"可讀回核對" in actual
    assert "審查工具保存返回正文：可讀回核對" in actual and "原生返回完整性：完整返回" in actual
    assert details.ORIGIN_NOTICE in actual and '"status":"snapshot_only"' in actual
    assert '"commission_files":1' in actual and '"required_subjects":1' in actual
    assert '"JSON位置":"/checks/0/subject"' in actual
    assert case.value["checks"][0]["subject"]["quote"] in actual
    assert '"decision"' not in actual and case.value["checks"][0]["reason"] not in actual
    assert not any("unselected" in str(path) or path == case.snapshot(case.ancestor, "ancestor.txt") for path in opened)
    assert before == {path: path.read_bytes() for path in folder.iterdir()}
    case.store.messages.assert_not_called()
    case.ctx.app.permissions.ask.assert_not_called()


@pytest.mark.parametrize("metadata,expected", [(None, "保存正文相符，完整性未知"),
    ({"truncated": True, "outputPath": "PRIVATE_OUTPUT_PATH"}, "已標截斷"),
    ({"truncated": False, "error": "PRIVATE_ERROR"}, "原生返回攜帶 error")])
def test_native_return_completeness_and_failure_are_independent(case, metadata, expected):
    call, history = save_call(case, metadata=metadata)
    actual = text(details.describe(case.ctx, call, history))
    assert expected in actual
    assert "PRIVATE_OUTPUT_PATH" not in actual and "PRIVATE_ERROR" not in actual
    if not metadata or metadata.get("truncated") is True:
        assert "原生返回完整性：完整返回" not in actual


@pytest.mark.parametrize("change", ["unselected", "different_version", "required"])
def test_public_validity_does_not_substitute_for_original_files_and_required_subjects(case, change):
    value = deepcopy(case.value)
    if change == "unselected":
        value["checks"][0]["evidence"] = [{**case.locator(case.source, "unselected.txt"), "quote": "UNSELECTED_PRIVATE_CONTENT"}]
    elif change == "different_version":
        different = case.save({"source.txt": "A different frozen version."})
        value["checks"][0]["evidence"] = [{**case.locator(different, "source.txt"), "quote": "A different frozen version."}]
    else:
        value["checks"][0]["subject"]["quote"] = "Conditional interpretation"
    call, history = save_call(case, result=value)
    actual = text(details.describe(case.ctx, call, history))
    assert "審查工具保存返回正文：內容不符" in actual
    assert "與原生返回相符的主張所在檔" not in actual


def test_initial_raw_response_must_reassemble_exact_saved_review(case):
    call, history = save_call(case, reply=False)
    folder = save_initial(case, call, history)
    value = deepcopy(case.model_value)
    value["checks"][0]["reason"] = "A different model explanation."
    (folder / "response.txt").write_text(json.dumps(value), encoding="utf-8")
    actual = text(details.describe(case.ctx, call, history))
    assert '"初審三檔":"內容不符"' in actual
    assert "目前未找到配對回條" in actual and "主張：" not in actual
    assert details.ORIGIN_NOTICE in actual


def test_current_origin_uses_exact_snapshot_and_failed_origin_does_not_erase_saved_initial(case, monkeypatch):
    path = f".opencode/history/{case.ctx.session_id}/conversation/{case.human['id']}.json"
    source = case.save({path: json.dumps(case.human)})
    case.args["files"].append(case.locator(source, path))
    call, history = save_call(case, reply=False)
    save_initial(case, call, history)
    monkeypatch.setattr(case.store, "messages", Mock(side_effect=AssertionError("Snapshot only")))
    actual = text(details.describe(case.ctx, call, history))
    assert '"status":"message_match"' in actual and details.ORIGIN_NOTICE in actual
    changed = deepcopy(history)
    changed[0]["content"] = "The present Store snapshot differs."
    actual = text(details.describe(case.ctx, call, changed))
    assert "來源重新核對未完成：內容不符" in actual
    assert '"status":"message_match"' not in actual and details.ORIGIN_NOTICE not in actual
    assert '"初審三檔":"可讀回核對"' in actual
    case.store.messages.assert_not_called()


def test_native_optional_history_is_frozen_and_empty_is_not_missing(case, monkeypatch):
    history = case.store.messages(case.ctx.session_id)
    reader = NativeSources(case.ctx, history=history)
    history[0]["content"] = "Changed after constructor"
    monkeypatch.setattr(case.store, "messages", Mock(side_effect=AssertionError("Never reload")))
    assert reader._message(case.human["id"])["content"] == case.human["content"]
    with pytest.raises(ValueError, match="no message"):
        NativeSources(case.ctx, history=[])._message(case.human["id"])
    case.store.messages.assert_not_called()


def test_denied_selected_locator_has_no_path_or_exception_leak(case):
    private = "private-snapshot-location.txt"
    source = case.save({private: "PRIVATE BODY"})
    case.args["files"].append(case.locator(source, private))
    case.ctx.agent.permission.append(Rule("read", private, "deny"))
    call, history = save_call(case)
    actual = text(details.describe(case.ctx, call, history))
    assert "明選快照：目前無權讀取" in actual
    assert private not in actual and "PRIVATE BODY" not in actual
    assert details.ORIGIN_NOTICE not in actual
    case.ctx.app.permissions.ask.assert_not_called()


def test_lone_surrogate_in_original_scope_is_json_escaped(case):
    case.args["scope"] = "Literal input " + chr(0xd800) + "\nsecond line"
    call, history = save_call(case)
    actual = text(details.describe(case.ctx, call, history))
    assert "\\ud800\\nsecond line" in actual
    actual.encode("utf-8")


def test_raw_read_limits_and_mid_read_changes_never_keep_success(case, monkeypatch):
    call, history = save_call(case, reply=False)
    folder = save_initial(case, call, history)
    (folder / "response.txt").write_bytes(b"x" * (details.MAX_BYTES + 1))
    actual = text(details.describe(case.ctx, call, history))
    assert '"初審三檔":"超過讀回容量"' in actual
    original = details._Reader.recheck
    def change(self):
        case.snapshot(case.report, "report.md").write_bytes(b"changed")
        return original(self)
    monkeypatch.setattr(details._Reader, "recheck", change)
    actual = text(details.describe(case.ctx, call, history))
    assert "本次詳情尚未核對" in actual
    assert "可讀回核對" not in actual and details.ORIGIN_NOTICE not in actual


def test_selected_manifest_and_snapshot_bytes_share_the_original_cap(case, monkeypatch):
    large = case.save({"selected-large.txt": "x" * details.MAX_BYTES})
    case.args["files"].append(case.locator(large, "selected-large.txt"))
    call, history = save_call(case)
    origins = Mock(side_effect=AssertionError("Do not authenticate a partial selection"))
    monkeypatch.setattr(NativeSources, "origins", origins)
    actual = text(details.describe(case.ctx, call, history))
    assert "明選快照：超過讀回容量" in actual
    assert "來源重新核對未完成：尚未核對" in actual
    assert details.ORIGIN_NOTICE not in actual
    origins.assert_not_called()


def test_wrong_call_identity_is_not_a_review_scope(case):
    call, history = save_call(case)
    call["call"] = deepcopy(call["call"])
    call["call"]["arguments"]["scope"] = "Invented scope"
    actual = text(details.describe(case.ctx, call, history))
    assert actual == "最近審查詳情：尚未核對"
    assert "Invented scope" not in actual


def test_actual_root_context_capacity_keeps_a_whole_subject_and_source(case, monkeypatch):
    from researchkit.research_context import context
    call, history = save_call(case, metadata={"truncated": False})
    save_initial(case, call, history)
    app = case.ctx.app
    app.directory = app.worktree = case.workspace
    app.default_agent = "build"
    app.agents = {"build": Agent("build", permission=[Rule("*", "*", "allow")])}
    app.extra_tools = [Tool("research_record", "", {}, lambda *_: None)]
    app.config = {}
    messages = Mock(wraps=case.store.messages)
    monkeypatch.setattr(case.store, "messages", messages)
    actual = context(app, case.ctx.session_id, case.human["id"])
    assert len(actual.encode()) <= 4096
    assert "與原生返回相符的主張所在檔" in actual and "\n主張：" in actual, actual
    assert "本次來源核對：" in actual, actual
    assert details.ORIGIN_NOTICE in actual
    assert case.value["checks"][0]["subject"]["quote"] in actual
    messages.assert_called_once_with(case.ctx.session_id)


def test_ordinary_publication_and_only_successful_direct_dependents(case):
    call, _ = save_call(case, metadata={"truncated": False})
    ask = case.ctx.app.permissions.ask
    case.ctx.app.permissions.ask = Mock(return_value=None)
    def publish(name, *, kind="notes", depends=(), metadata_error=False):
        case.file(name, details._q(case.value) if kind == "review" else "Saved later note.")
        args = {"kind": kind, "title": name, "files": [name], "depends_on": list(depends)}
        case.store.add_message(case.ctx.session_id, "assistant", {"tool_calls": [
            {"id": name, "name": "research_record", "arguments": args}]})
        result = _publish(args, case.ctx)
        value = json.loads(result.output)
        metadata = {**result.metadata, **({"error": "PRIVATE FAILURE"} if metadata_error else {})}
        case.store.add_message(case.ctx.session_id, "tool", {"name": "research_record", "tool_call_id": name,
            "content": result.output, "metadata": metadata})
        return value["record_path"]
    try:
        published = publish("review.json", kind="review", depends=[item["record_ref"] for item in case.args["files"]])
        direct = publish("direct.txt", depends=[published])
        indirect = publish("indirect.txt", depends=[direct])
        failure = publish("failed.txt", depends=[published], metadata_error=True)
    finally:
        case.ctx.app.permissions.ask = ask
    history = case.store.messages(case.ctx.session_id)
    actual = text(details.describe(case.ctx, call, history))
    assert "與原生返回正文相符的已發布普通 review" in actual and published in actual
    assert direct in actual and indirect not in actual and failure not in actual
    assert "PRIVATE FAILURE" not in actual
    ask.assert_not_called()
