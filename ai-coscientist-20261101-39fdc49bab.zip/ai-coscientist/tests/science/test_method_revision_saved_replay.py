"""Replay the saved baseline comparison, not a scientific method revision.

Only original frozen records are inputs. This proves their dependency transport
and numerical rank-comparison reproducibility; it does not recompute molecular
descriptors, approve the old formula, or validate a new method or full workflow.
"""

from __future__ import annotations

import json
from pathlib import Path, PureWindowsPath
import socket

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import records, report_evidence
from researchkit.tools import TOOLS


SOURCE = Path(__file__).resolve().parents[2] / "outputs/lit_current_e2e_20261020_v1/workspace"
TASK_REF = ".research/records/a955fbb02f158b80f5463053f08f5a5e713369173238e67e09492683a7984278/record.json"
LITERATURE_REF = ".research/records/ec85e22d01f583fba3974c3cf1e4ae9d65630a898f8eec23b6a14deada036313/record.json"
MINDMAP_REF = ".research/records/2b41539ef3e36e74aba66565b8a7c3f529649f36fba5b9f608ac9d5050b0d25b/record.json"
HYPOTHESIS_REF = ".research/records/55f32674e286cd58bc73de3b1fe35fb2379bdb3fbf909013a8af5d889dca88b5/record.json"
FORMULA_REF = ".research/records/398c19585a05f6ce18c71c303d7dcf5ff715ad6b8725ef3ab2eb6d3b81265f91/record.json"
IMPLEMENTATION_REF = ".research/records/2020c0028abab0bc65be5719401d59e325595b4a2f156d0b898bb596e362e5f6/record.json"
SAMPLE_REF = ".research/records/872dea42043a3e231fdffd2e00f48f0778332428d21affbccfa31a44e0f710a8/record.json"
PROXY_PATH = "lit_research/outputs/proxy_values.json"
TARGET_PATH = "lit_research/outputs/target_values.json"
CALIBRATION_PATH = ".research/calibrations/7cd4e355b51f145bcc06f2ab3c248c4c89d0c13c916c763ed5605bac3e2c5d7f.json"


def _snapshot(root, ref, source_path):
    """Select a file inside its exact dependency record, never by latest path."""
    manifest = records.read_record(root, ref)
    entry, = [item for item in manifest["files"] if item["source_path"] == source_path]
    return records.local_path((root / ref).parent, entry["snapshot"]), entry


@pytest.fixture(scope="module")
def saved_closure():
    try:
        closure = records._read_dependencies(SOURCE, [SAMPLE_REF])
        contents = {}
        for ref, manifest in closure.items():
            raw = (SOURCE / ref).read_bytes()
            assert records.digest(raw) == Path(ref).parent.name
            contents[ref] = raw
            for item in manifest["files"]:
                path = records.local_path((SOURCE / ref).parent, item["snapshot"])
                raw = path.read_bytes()
                assert records.digest(raw) == item["sha256"]
                assert len(raw) == item["bytes"]
                contents[path.relative_to(SOURCE).as_posix()] = raw
    except FileNotFoundError as exc:
        pytest.skip(f"Saved real method evidence unavailable; no synthetic replacement: {exc}")
    # Corrupt or changed evidence must fail, not be treated as absent evidence.
    assert len(closure) == 7
    assert sum(len(item["files"]) for item in closure.values()) == 21
    assert len(contents) == 28
    yield closure, contents
    assert {name: (SOURCE / name).read_bytes() for name in contents} == contents


@pytest.fixture
def copied_closure(saved_closure, tmp_path):
    closure, contents = saved_closure
    root = tmp_path / "workspace"
    for name, raw in contents.items():
        destination = root / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    assert records._read_dependencies(root, [SAMPLE_REF]) == closure
    yield root, closure
    assert {name: (root / name).read_bytes() for name in contents} == contents
    assert {item["record_path"] for item in records.inventory(root)} == set(closure)


@pytest.fixture
def offline_tools(copied_closure, tmp_path, monkeypatch):
    root, _ = copied_closure
    attempts = []

    def forbidden_network(*args, **kwargs):
        attempts.append("network")
        pytest.fail("Saved baseline replay must not access the network")

    def forbidden_model(*args, **kwargs):
        attempts.append("model")
        pytest.fail("Saved baseline replay must not call a model")

    monkeypatch.setattr(socket.socket, "connect", forbidden_network)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden_network)
    monkeypatch.setattr(socket, "create_connection", forbidden_network)
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    (root / ".git").mkdir()
    store = Store(tmp_path / "session.db")
    try:
        app = App(root, store=store, auto_approve=True, config={})
        app.generate_titles = False
        monkeypatch.setattr(app.provider, "complete", forbidden_model)
        session = app.create_session()["id"]
        ctx = ToolContext(app, session, app.agents["build"], "saved-replay", "local", 0,
                          root, root, set(), 1)
        yield {tool.name: tool for tool in TOOLS}, ctx
        assert attempts == []
    finally:
        store.close()


def test_saved_original_formula_implementation_and_sample_dependencies(copied_closure):
    root, closure = copied_closure
    assert {ref: (item["kind"], item["depends_on"]) for ref, item in closure.items()} == {
        TASK_REF: ("task", []),
        LITERATURE_REF: ("literature", [TASK_REF]),
        MINDMAP_REF: ("mindmap", [TASK_REF, LITERATURE_REF]),
        HYPOTHESIS_REF: ("hypothesis", [TASK_REF, LITERATURE_REF, MINDMAP_REF]),
        FORMULA_REF: ("formula", [TASK_REF, LITERATURE_REF, MINDMAP_REF, HYPOTHESIS_REF]),
        IMPLEMENTATION_REF: ("implementation", [TASK_REF, FORMULA_REF]),
        SAMPLE_REF: ("sample_evolution", [TASK_REF, FORMULA_REF, IMPLEMENTATION_REF]),
    }
    # Only immutable evidence is copied. A mutable source_path cannot substitute
    # for a different version of the same file in another record.
    for ref, manifest in closure.items():
        for entry in manifest["files"]:
            assert not (root / entry["source_path"]).exists()
            path, selected = _snapshot(root, ref, entry["source_path"])
            assert selected == entry
            assert records.digest(path.read_bytes()) == entry["sha256"]
    selected = report_evidence.resolve(root, [
        {"record_ref": FORMULA_REF, "source_path": "lit_research/records/proxy_formula.md"},
        {"record_ref": IMPLEMENTATION_REF, "source_path": "lit_research/code/proxy.py"},
        {"record_ref": SAMPLE_REF, "source_path": "lit_research/code/candidates.py"},
    ])
    assert [item["record_ref"] for item in selected] == [FORMULA_REF, IMPLEMENTATION_REF, SAMPLE_REF]
    assert [item["kind"] for item in selected] == ["formula", "implementation", "sample_evolution"]


def test_saved_baseline_comparison_replays_with_exact_input_hashes(copied_closure, offline_tools):
    root, _ = copied_closure
    tools, ctx = offline_tools
    original_path, _ = _snapshot(root, IMPLEMENTATION_REF, CALIBRATION_PATH)
    original = json.loads(original_path.read_bytes())
    proxy, proxy_entry = _snapshot(root, IMPLEMENTATION_REF, PROXY_PATH)
    target, target_entry = _snapshot(root, IMPLEMENTATION_REF, TARGET_PATH)
    expected_hashes = [proxy_entry["sha256"], target_entry["sha256"]]
    assert [item["sha256"] for item in original["input_files"]] == expected_hashes
    # The historical calibration names Windows working paths. Preserve those
    # bytes, and replay against their exact frozen versions in the copy.
    for item, source_path in zip(original["input_files"], [PROXY_PATH, TARGET_PATH]):
        assert PureWindowsPath(item["path"]).parts[-len(Path(source_path).parts):] == Path(source_path).parts
    arguments = {"proxy_path": proxy.relative_to(root).as_posix(),
                 "target_path": target.relative_to(root).as_posix(),
                 "direction": original["direction"]}
    receipt = json.loads(tools["research_compare"].execute(arguments, ctx).output)
    result_path = Path(receipt.pop("result_path"))
    assert result_path.is_relative_to(root / ".research/calibrations")
    assert result_path.stem == records.digest(result_path.read_bytes())
    assert json.loads(result_path.read_bytes()) == receipt
    assert receipt["input_files"] == [
        {"path": arguments["proxy_path"], "sha256": expected_hashes[0]},
        {"path": arguments["target_path"], "sha256": expected_hashes[1]},
    ]
    # The saved calibration predates permutation_p and its limitation line; every older field must replay exactly.
    assert {key: value for key, value in receipt.items() if key in original and key not in ("input_files", "limitations")} == {
        key: value for key, value in original.items() if key not in ("input_files", "limitations")
    }
    assert receipt["limitations"][:len(original["limitations"])] == original["limitations"]
    assert receipt["permutation_p"]["smallest_possible_two_sided"] == 1.0
    assert receipt["sample_count"] == 2
    assert receipt["limitations"][0] == "A two-sample ordering cannot establish generalization."
    assert "not independent validation" in receipt["interpretation"]


def test_research_list_traces_the_saved_method_downstream(copied_closure, offline_tools):
    root, closure = copied_closure
    tools, ctx = offline_tools
    listed = json.loads(tools["research_list"].execute({}, ctx).output)
    by_ref = {item["record_path"]: item for item in listed}
    assert set(by_ref) == set(closure)
    for ref, manifest in closure.items():
        assert by_ref[ref]["depends_on"] == manifest["depends_on"]
        assert by_ref[ref]["depended_on_by"] == sorted(
            [{"record_path": parent_ref, "kind": parent["kind"]}
             for parent_ref, parent in closure.items() if ref in parent["depends_on"]],
            key=lambda item: item["record_path"],
        )
        for entry in by_ref[ref]["files"]:
            path, original_entry = _snapshot(root, ref, entry["source_path"])
            assert Path(entry["snapshot"]) == path
            assert entry["sha256"] == original_entry["sha256"]
    assert {item["record_path"] for item in by_ref[FORMULA_REF]["depended_on_by"]} == {
        IMPLEMENTATION_REF, SAMPLE_REF,
    }
    assert by_ref[IMPLEMENTATION_REF]["depended_on_by"] == [
        {"record_path": SAMPLE_REF, "kind": "sample_evolution"},
    ]
    assert by_ref[SAMPLE_REF]["depended_on_by"] == []
    # No revised scientific record, review or delivery is manufactured by replay.
    assert records.selected_delivery(ctx.app.store.messages(ctx.session_id)) is None
