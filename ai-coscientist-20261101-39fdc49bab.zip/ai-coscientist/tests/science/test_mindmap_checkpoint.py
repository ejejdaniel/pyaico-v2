"""S25 deterministic checkpoint boundaries; no new model or scientific result.

Successful outputs come from the existing saved-reply fixture. Modified records
are explicitly synthetic rejection cases, never imported as real research.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import uuid
from unittest.mock import Mock

import pytest

from opencode.permission import PermissionDenied, Rule
from opencode.provider import ProviderError
from researchkit import mindmap, mindmap_schema, records, report_evidence
from researchkit.tools import TOOLS
from test_mindmap_generation import (
    SKILL_PATH, SOURCE_NAMES, assert_preserved_prefix, checkpoint_records,
    completion, install_replies, locator, offline, packet, saved_replies,
    save, snapshot,
)


STAGES = ("observation", "architecture", "deepening")
LIMIT = 262144


def checkpoints(packet):
    found = []
    for record in checkpoint_records(packet.root):
        entry = next(item for item in record["files"] if Path(item["source_path"]).name == "checkpoint.json")
        selection = locator(record, entry["source_path"])
        value = json.loads(report_evidence.resolve(packet.root, [selection])[0]["text"])
        found.append(SimpleNamespace(record=record, value=value, locator=selection))
    return sorted(found, key=lambda item: sum(stage in item.value for stage in STAGES))


def resumed(packet, selected):
    return {**deepcopy(packet.args), "resume_from": deepcopy(selected.locator)}


def publish_checkpoint(packet, value, *, dependencies, kind="mindmap_checkpoint",
                       names=("checkpoint.json",), attachments=None):
    folder = f".research/mindmaps/synthetic-boundary-{uuid.uuid4().hex}"
    contents = {f"{folder}/{name}": mindmap._json(value).encode("utf-8") for name in names}
    contents.update({f"{folder}/{name}": text for name, text in (attachments or {}).items()})
    saved = save(packet.root, contents, kind=kind, dependencies=dependencies)
    selected = locator(saved, f"{folder}/{names[0]}")
    return SimpleNamespace(record=saved, value=value, locator=selected)


def copy_checkpoint(packet, selected, *, mutate=None, dependencies=None, **kwargs):
    value = deepcopy(selected.value)
    if mutate:
        mutate(value)
    return publish_checkpoint(
        packet, value,
        dependencies=selected.record["depends_on"] if dependencies is None else dependencies,
        **kwargs,
    )


@pytest.fixture
def completed(monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, saved_replies)
    receipt = json.loads(mindmap.execute(packet.args, packet.ctx).output)
    saved = checkpoints(packet)
    assert len(saved) == 3
    return SimpleNamespace(checkpoints=saved, receipt=receipt, calls=list(model.call_args_list))


def assert_rejected_before_model(monkeypatch, packet, args, *, errors=(ValueError, OSError, PermissionDenied)):
    model = install_replies(monkeypatch, [])
    with pytest.raises(errors):
        mindmap.execute(args, packet.ctx)
    model.assert_not_called()


def install_guidance(packet):
    folder = packet.root / ".opencode/skills/mindmap-builder"
    (folder / "references").mkdir(parents=True, exist_ok=True)
    (folder / "SKILL.md").write_bytes(SKILL_PATH.read_bytes())
    for stage in STAGES:
        (folder / "references" / f"{stage}.md").write_bytes(
            (SKILL_PATH.parent / "references" / f"{stage}.md").read_bytes())
    packet.ctx.app.skills["mindmap-builder"].location = folder / "SKILL.md"
    return folder


def test_tool_schema_has_only_the_approved_optional_resume_and_handoff_fields():
    tool = next(tool for tool in TOOLS if tool.name == "research_mindmap")
    assert set(tool.parameters["properties"]) == {
        "scope", "task_ref", "files", "resume_from", "pause_after", "additional_evidence"}
    assert set(tool.parameters["required"]) == {"scope", "task_ref", "files"}
    assert tool.parameters["additionalProperties"] is False
    selected = tool.parameters["properties"]["resume_from"]
    assert set(selected["properties"]) == set(selected["required"]) == {"record_ref", "source_path"}
    assert selected["additionalProperties"] is False


def test_stage_two_timeout_preserves_first_stage_and_resume_skips_it(monkeypatch, packet, saved_replies):
    partial = completion(saved_replies[0])
    timeout = ProviderError("600-second local deadline", partial=partial)
    cause = TimeoutError("saved transport cause")
    timeout.__cause__ = cause
    model = install_replies(monkeypatch, [saved_replies[0], timeout])
    with pytest.raises(ProviderError, match="600-second") as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert failure.value is timeout
    assert failure.value.partial is partial
    assert failure.value.__cause__ is cause
    assert model.call_count == 2
    assert_preserved_prefix(packet.root, saved_replies[:1])
    selected = checkpoints(packet)[0]
    assert selected.locator["record_ref"] in str(failure.value)
    assert selected.locator["source_path"] in str(failure.value)
    assert selected.value["observation"] == saved_replies[0]

    before = snapshot(packet.root, selected.record, selected.locator["source_path"]).read_bytes()
    model = install_replies(monkeypatch, saved_replies[1:])
    result = mindmap.execute(resumed(packet, selected), packet.ctx)
    assert model.call_count == 2
    assert model.call_args_list[0].kwargs["messages"][0]["content"].find(
        mindmap._json(saved_replies[0])) >= 0
    assert snapshot(packet.root, selected.record, selected.locator["source_path"]).read_bytes() == before
    assert json.loads(result.output)["kind"] == "mindmap"
    assert len(checkpoints(packet)) == 3


def test_stage_three_failure_only_repeats_stage_three(monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, saved_replies[:2] + [ProviderError("deepening transport failed")])
    with pytest.raises(ProviderError) as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 3
    assert_preserved_prefix(packet.root, saved_replies[:2])
    selected = checkpoints(packet)[1]
    assert selected.locator["record_ref"] in str(failure.value)
    model = install_replies(monkeypatch, saved_replies[2:])
    mindmap.execute(resumed(packet, selected), packet.ctx)
    assert model.call_count == 1
    assert "Complete earlier architecture draft" in model.call_args.kwargs["messages"][0]["content"]


def test_final_publication_failure_resumes_with_zero_model_calls(monkeypatch, packet, saved_replies):
    publish = records.publish
    failed_path = str(packet.root / "unavailable-record")
    original_failure = OSError(13, "final publication unavailable", failed_path)

    def fail_final(*args, **kwargs):
        if kwargs["kind"] == "mindmap":
            raise original_failure
        return publish(*args, **kwargs)

    monkeypatch.setattr(records, "publish", fail_final)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(OSError, match="final publication unavailable") as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert failure.value is original_failure
    assert failure.value.errno == 13
    assert failure.value.filename == failed_path
    assert model.call_count == 3
    assert_preserved_prefix(packet.root, saved_replies)
    selected = checkpoints(packet)[2]
    assert selected.locator["record_ref"] in str(failure.value)
    assert selected.locator["source_path"] in str(failure.value)
    monkeypatch.setattr(records, "publish", publish)
    model = install_replies(monkeypatch, [])
    result = mindmap.execute(resumed(packet, selected), packet.ctx)
    model.assert_not_called()
    receipt = json.loads(result.output)
    assert receipt["depends_on"] == [
        packet.task["record_path"], packet.evidence["record_path"], selected.locator["record_ref"],
    ]
    assert len(checkpoints(packet)) == 3
    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on"}
    assert result.metadata == {} and result.attachments == []


def test_checkpoint_envelope_and_chain_preserve_exact_successful_prefix(packet, saved_replies, completed):
    dependencies = list(dict.fromkeys(item["record_ref"] for item in packet.args["files"]))
    previous = None
    for index, selected in enumerate(completed.checkpoints):
        value = selected.value
        assert set(value) == {"scope", "task_ref", "files", "system_sha256", *STAGES[:index + 1]}
        assert {key: value[key] for key in ("scope", "task_ref", "files")} == packet.args
        assert [value[stage] for stage in STAGES[:index + 1]] == saved_replies[:index + 1]
        assert value["system_sha256"] == {
            stage: hashlib.sha256(completed.calls[number].kwargs["system"].encode("utf-8")).hexdigest()
            for number, stage in enumerate(STAGES)
        }
        assert selected.record["depends_on"] == dependencies + ([previous] if previous else [])
        assert len(selected.record["files"]) == 1
        assert selected.locator["source_path"].startswith(".research/mindmaps/")
        previous = selected.locator["record_ref"]
    assert completed.receipt["depends_on"] == dependencies + [previous]


def test_resume_reuses_identical_full_sources_and_guidance_without_new_prompt(
        monkeypatch, packet, saved_replies, completed):
    selected = completed.checkpoints[0]
    # Mutable files cannot replace selected frozen sources on resume.
    (packet.root / SOURCE_NAMES[1]).write_text("NEW_WORKING_COPY_PRIVATE", encoding="utf-8")
    model = install_replies(monkeypatch, saved_replies[1:])
    mindmap.execute(resumed(packet, selected), packet.ctx)
    assert model.call_args_list == completed.calls[1:]
    for call in model.call_args_list:
        whole = call.kwargs["system"] + call.kwargs["messages"][0]["content"]
        for secret in ("PARENT_HISTORY_PRIVATE", "UNSELECTED_ANCESTOR_PRIVATE",
                       "UNSELECTED_SIBLING_PRIVATE", "NEW_WORKING_COPY_PRIVATE"):
            assert secret not in whole
        assert selected.locator["record_ref"] not in whole


def test_all_system_texts_are_frozen_before_the_first_model_call(monkeypatch, packet, saved_replies):
    folder = install_guidance(packet)
    replies = iter(saved_replies)
    calls = []

    def reply(ctx, **kwargs):
        calls.append(kwargs)
        if len(calls) == 1:
            for stage in STAGES:
                path = folder / "references" / f"{stage}.md"
                path.write_text(path.read_text(encoding="utf-8") + "\nMID_CALL_CHANGED_GUIDANCE",
                                encoding="utf-8")
        return completion(next(replies))

    monkeypatch.setattr(mindmap, "complete_once", reply)
    mindmap.execute(packet.args, packet.ctx)
    assert len(calls) == 3
    assert all("MID_CALL_CHANGED_GUIDANCE" not in call["system"] for call in calls)
    assert checkpoints(packet)[2].value["system_sha256"] == {
        stage: hashlib.sha256(calls[index]["system"].encode("utf-8")).hexdigest()
        for index, stage in enumerate(STAGES)
    }


@pytest.mark.parametrize("change", [
    lambda args: args.update(scope=args["scope"] + " revised"),
    lambda args: args["files"].reverse(),
    lambda args: args["files"].pop(),
    lambda args: args["files"][1].update(source_path="unselected.txt"),
])
def test_changed_commission_or_selection_rejected_before_resume(
        monkeypatch, packet, completed, change):
    args = resumed(packet, completed.checkpoints[0])
    change(args)
    assert_rejected_before_model(monkeypatch, packet, args)


def test_changed_commission_error_names_the_difference_and_the_way_forward(monkeypatch, packet, completed):
    # LIT v21: nine bare "files does not match" errors led the author to rewrite checkpoint.json by hand.
    args = resumed(packet, completed.checkpoints[0])
    dropped = args["files"].pop()
    model = install_replies(monkeypatch, [])
    with pytest.raises(ValueError) as error:
        mindmap.execute(args, packet.ctx)
    model.assert_not_called()
    message = str(error.value)
    assert f"the checkpoint also selected {dropped['record_ref']}: {dropped['source_path']}" in message
    assert "start a new commission without resume_from" in message
    assert "editing files under .research/mindmaps does not change it" in message

    args = resumed(packet, completed.checkpoints[0])
    args["scope"] += " revised"
    with pytest.raises(ValueError, match=r"scope does not match this commission: the checkpoint has '.*', "
                                         r"this call has '.* revised'"):
        mindmap.execute(args, packet.ctx)


def test_new_task_record_with_identical_content_is_not_the_same_authority(
        monkeypatch, packet, completed):
    replacement = save(packet.root, {"another-task.md": (packet.root / SOURCE_NAMES[0]).read_bytes()}, kind="task")
    args = resumed(packet, completed.checkpoints[0])
    args["task_ref"] = replacement["record_path"]
    args["files"][0] = locator(replacement, "another-task.md")
    assert_rejected_before_model(monkeypatch, packet, args)


@pytest.mark.parametrize("stage", STAGES)
@pytest.mark.parametrize("change", ["guidance", "schema"])
def test_changed_system_guidance_or_closed_schema_rejected_before_resume(
        monkeypatch, packet, completed, stage, change):
    if change == "guidance":
        folder = install_guidance(packet)
        path = folder / "references" / f"{stage}.md"
        path.write_text(path.read_text(encoding="utf-8") + "\nChanged instruction", encoding="utf-8")
    else:
        name = {"observation": "OBSERVATION_SCHEMA", "architecture": "MAP_SCHEMA", "deepening": "EDITS_SCHEMA"}[stage]
        schema = deepcopy(getattr(mindmap, name))
        schema["description"] = "Synthetic schema version change"
        monkeypatch.setattr(mindmap, name, schema)
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, completed.checkpoints[0]))


@pytest.mark.parametrize("invalid", [
    None, "", {}, {"record_ref": "x"}, {"source_path": "checkpoint.json"},
    {"record_ref": "x", "source_path": "checkpoint.json"},
    {"record_ref": ".research/records/" + "A" * 64 + "/record.json", "source_path": "checkpoint.json"},
    {"record_ref": ".research/records/" + "a" * 64 + "/record.json", "source_path": " "},
    {"record_ref": ".research/records/" + "a" * 64 + "/record.json", "source_path": None},
])
def test_resume_locator_is_exact_closed_and_nonnullable(monkeypatch, packet, invalid):
    assert_rejected_before_model(monkeypatch, packet, {**packet.args, "resume_from": invalid})


def test_resume_locator_rejects_extra_fields(monkeypatch, packet, completed):
    args = resumed(packet, completed.checkpoints[0])
    args["resume_from"]["stage"] = "architecture"
    assert_rejected_before_model(monkeypatch, packet, args)


@pytest.mark.parametrize("change", [
    lambda value: value.update(extra=True),
    lambda value: value.pop("observation"),
    lambda value: value.update(observation=None),
    lambda value: value.update(architecture=None),
    lambda value: value.update(deepening=None),
    lambda value: value.update(architecture={}),
    lambda value: value.update(deepening={}),
    lambda value: value.update(system_sha256=None),
    lambda value: value["system_sha256"].update(extra="a" * 64),
    lambda value: value["system_sha256"].pop("deepening"),
    lambda value: value["system_sha256"].update(observation="A" * 64),
    lambda value: value["system_sha256"].update(observation="0" * 64),
    lambda value: value["observation"].update(extra=[]),
    lambda value: value["observation"].update(evidence_gaps=None),
    lambda value: value["files"][0].update(extra=True),
])
def test_checkpoint_payload_rejects_unapproved_incomplete_or_null_fields(
        monkeypatch, packet, completed, change):
    selected = copy_checkpoint(packet, completed.checkpoints[0], mutate=change)
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, selected))


def test_deepening_cannot_exist_without_architecture(monkeypatch, packet, completed):
    selected = copy_checkpoint(packet, completed.checkpoints[2], mutate=lambda value: value.pop("architecture"))
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, selected))


@pytest.mark.parametrize("case", [
    "missing_source", "reordered_sources", "extra_source", "observation_predecessor",
    "missing_predecessor", "wrong_kind_predecessor", "same_stage_predecessor",
    "skipped_stage", "two_predecessors", "changed_observation", "changed_architecture",
    "different_predecessor_scope", "different_predecessor_system",
])
def test_checkpoint_chain_rejects_broken_dependencies_and_changed_prefix(
        monkeypatch, packet, completed, case):
    first, second, third = completed.checkpoints
    source_refs = [packet.task["record_path"], packet.evidence["record_path"]]
    target = second
    dependencies = list(second.record["depends_on"])
    mutate = None
    if case == "missing_source":
        dependencies.pop(0)
    elif case == "reordered_sources":
        dependencies[:2] = list(reversed(source_refs))
    elif case == "extra_source":
        dependencies.insert(2, packet.ancestor["record_path"])
    elif case == "observation_predecessor":
        target = first
        dependencies = source_refs + [first.locator["record_ref"]]
    elif case == "missing_predecessor":
        dependencies = source_refs
    elif case == "wrong_kind_predecessor":
        dependencies[-1] = packet.ancestor["record_path"]
    elif case == "same_stage_predecessor":
        dependencies[-1] = second.locator["record_ref"]
    elif case == "skipped_stage":
        target = third
        dependencies = source_refs + [first.locator["record_ref"]]
    elif case == "two_predecessors":
        target = third
        dependencies = source_refs + [first.locator["record_ref"], second.locator["record_ref"]]
    elif case == "changed_observation":
        mutate = lambda value: value["observation"]["source_observations"].append("Synthetic changed prefix")
    elif case == "changed_architecture":
        target = third
        dependencies = list(third.record["depends_on"])
        mutate = lambda value: value["architecture"].update(title="Synthetic changed prefix")
    elif case in {"different_predecessor_scope", "different_predecessor_system"}:
        def mutate_prior(value):
            if case == "different_predecessor_scope":
                value["scope"] += " changed"
            else:
                value["system_sha256"]["deepening"] = "0" * 64
        predecessor = copy_checkpoint(packet, first, mutate=mutate_prior)
        dependencies[-1] = predecessor.locator["record_ref"]
    selected = copy_checkpoint(packet, target, mutate=mutate, dependencies=dependencies)
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, selected))


@pytest.mark.parametrize("case", ["wrong_kind", "wrong_name", "two_checkpoints", "selected_attachment"])
def test_resume_selects_exactly_one_checkpoint_json_and_correct_kind(
        monkeypatch, packet, completed, case):
    first = completed.checkpoints[0]
    kwargs = {}
    if case == "wrong_kind":
        kwargs["kind"] = "mindmap"
    elif case == "wrong_name":
        kwargs["names"] = ("another.json",)
    elif case == "two_checkpoints":
        kwargs["names"] = ("checkpoint.json", "nested/checkpoint.json")
    else:
        kwargs["attachments"] = {"trace.txt": "SYNTHETIC_TRACE_NOT_A_CHECKPOINT"}
    selected = copy_checkpoint(packet, first, **kwargs)
    if case == "selected_attachment":
        selected.locator["source_path"] = selected.locator["source_path"].replace("checkpoint.json", "trace.txt")
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, selected))


def test_migration_attachments_do_not_enter_resumed_model_messages(monkeypatch, packet, completed, saved_replies):
    selected = copy_checkpoint(packet, completed.checkpoints[0],
                               attachments={"request.body.json": "PRIVATE_DIAGNOSTIC_ATTACHMENT",
                                            "response.raw.bin": "PRIVATE_DIAGNOSTIC_RESPONSE"})
    model = install_replies(monkeypatch, saved_replies[1:])
    mindmap.execute(resumed(packet, selected), packet.ctx)
    assert model.call_args_list == completed.calls[1:]


@pytest.mark.parametrize("target", ["checkpoint_manifest", "checkpoint_snapshot", "predecessor",
                                   "source", "checkpoint_edit", "record_edit", "tool"])
def test_resume_rechecks_all_required_permissions_before_model(
        monkeypatch, packet, completed, target):
    first, second, _ = completed.checkpoints
    if target == "checkpoint_manifest":
        permission, pattern = "read", second.locator["record_ref"]
    elif target == "checkpoint_snapshot":
        permission, pattern = "read", snapshot(
            packet.root, second.record, second.locator["source_path"]).relative_to(packet.root).as_posix()
    elif target == "predecessor":
        permission, pattern = "read", first.locator["record_ref"]
    elif target == "source":
        permission, pattern = "read", snapshot(
            packet.root, packet.evidence, SOURCE_NAMES[1]).relative_to(packet.root).as_posix()
    elif target == "checkpoint_edit":
        permission, pattern = "edit", ".research/mindmaps*"
    elif target == "record_edit":
        permission, pattern = "edit", ".research/records*"
    else:
        permission, pattern = "research_mindmap", "*"
    packet.ctx.agent.permission.append(Rule(permission, pattern, "deny"))
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, second), errors=(PermissionDenied,))


@pytest.mark.parametrize("target", ["checkpoint", "predecessor", "source", "manifest"])
def test_tampered_frozen_content_is_rejected_before_resume(monkeypatch, packet, completed, target):
    selected = completed.checkpoints[1]
    if target == "source":
        path = snapshot(packet.root, packet.evidence, SOURCE_NAMES[1])
    elif target == "manifest":
        path = packet.root / selected.locator["record_ref"]
    else:
        damaged = selected if target == "checkpoint" else completed.checkpoints[0]
        path = snapshot(packet.root, damaged.record, damaged.locator["source_path"])
    path.write_bytes(path.read_bytes() + b" ")
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, selected))


@pytest.mark.parametrize("raw", [
    b"\xff",
    b'{"observation": {}, "observation": {}}',
    b'{"observation": NaN}',
    b'{} trailing text',
])
def test_checkpoint_requires_strict_utf8_json(monkeypatch, packet, completed, raw):
    first = completed.checkpoints[0]
    source = f".research/mindmaps/synthetic-json-{uuid.uuid4().hex}/checkpoint.json"
    record = save(packet.root, {source: raw}, kind="mindmap_checkpoint",
                  dependencies=first.record["depends_on"])
    args = {**packet.args, "resume_from": locator(record, source)}
    assert_rejected_before_model(monkeypatch, packet, args)


def test_checkpoint_byte_limit_rejects_even_valid_json_before_model(monkeypatch, packet, completed):
    first = completed.checkpoints[0]
    raw = records.encoded(first.value)
    assert len(raw) < LIMIT
    raw += b" " * (LIMIT + 1 - len(raw))
    source = f".research/mindmaps/synthetic-oversize-{uuid.uuid4().hex}/checkpoint.json"
    record = save(packet.root, {source: raw}, kind="mindmap_checkpoint",
                  dependencies=first.record["depends_on"])
    assert_rejected_before_model(
        monkeypatch, packet, {**packet.args, "resume_from": locator(record, source)})


def test_resumed_request_limit_still_counts_complete_sources_and_prior_outputs(
        monkeypatch, packet, completed):
    first = completed.checkpoints[0]
    call = completed.calls[1]
    size = len(call.kwargs["system"].encode("utf-8")) + len(
        call.kwargs["messages"][0]["content"].encode("utf-8"))
    monkeypatch.setattr(mindmap, "MAX_BYTES", size - 1)
    assert_rejected_before_model(monkeypatch, packet, resumed(packet, first))


@pytest.mark.parametrize("completed_stages", [0, 1, 2])
def test_checkpoint_publication_failure_stops_before_next_model(
        monkeypatch, packet, saved_replies, completed_stages):
    publish = records.publish
    attempts = 0

    def fail_checkpoint(*args, **kwargs):
        nonlocal attempts
        if kwargs["kind"] == "mindmap_checkpoint":
            attempts += 1
            if attempts == completed_stages + 1:
                raise OSError("checkpoint publication unavailable")
        return publish(*args, **kwargs)

    monkeypatch.setattr(records, "publish", fail_checkpoint)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(OSError, match="checkpoint publication unavailable") as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == completed_stages + 1
    assert_preserved_prefix(packet.root, saved_replies[:completed_stages])
    if completed_stages:
        selected = checkpoints(packet)[-1]
        assert selected.locator["record_ref"] in str(failure.value)
        assert selected.locator["source_path"] in str(failure.value)


def test_checkpoint_readback_failure_stops_before_next_model(monkeypatch, packet, saved_replies):
    publish = records.publish

    def corrupt_checkpoint(*args, **kwargs):
        saved = publish(*args, **kwargs)
        if kwargs["kind"] == "mindmap_checkpoint":
            snapshot(packet.root, saved, saved["files"][0]["source_path"]).write_bytes(b"corrupt")
        return saved

    monkeypatch.setattr(records, "publish", corrupt_checkpoint)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(ValueError):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 1


def test_publish_internal_readback_failure_keeps_committed_unverified_locator(
        monkeypatch, packet, saved_replies):
    ensure_access = mindmap.ensure_access
    failure = PermissionDenied("read", "checkpoint manifest after commit")
    denied = []

    def fail_after_commit(ctx, path, permission):
        if permission == "read" and path.name == "record.json" and path.is_file():
            manifest = json.loads(path.read_bytes())
            if manifest["kind"] == "mindmap_checkpoint":
                denied.append(path)
                raise failure
        return ensure_access(ctx, path, permission)

    monkeypatch.setattr(mindmap, "ensure_access", fail_after_commit)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(PermissionDenied) as raised:
        mindmap.execute(packet.args, packet.ctx)
    assert raised.value is failure
    assert failure.permission == "read"
    assert failure.pattern == "checkpoint manifest after commit"
    assert model.call_count == 1
    assert len(denied) == 1
    selected = checkpoints(packet)[0]
    assert denied[0] == packet.root / selected.locator["record_ref"]
    assert selected.locator["record_ref"] in str(failure)
    assert selected.locator["source_path"] in str(failure)
    assert "not verified" in str(failure)
    assert_preserved_prefix(packet.root, saved_replies[:1])


def test_checkpoint_write_limit_stops_before_next_stage(monkeypatch, packet, saved_replies):
    monkeypatch.setattr(mindmap, "CHECKPOINT_MAX_BYTES", 1)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(ValueError, match="checkpoint exceeds"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 1
    assert_preserved_prefix(packet.root, [])


def test_parent_cancellation_after_saved_prefix_keeps_locator_and_does_not_retry(
        monkeypatch, packet, saved_replies):
    calls = 0

    def reply(ctx, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 2:
            ctx.abort.set()
        return completion(saved_replies[calls - 1])

    monkeypatch.setattr(mindmap, "complete_once", reply)
    with pytest.raises(ProviderError, match="aborted") as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert calls == 2
    selected = checkpoints(packet)[0]
    assert selected.locator["record_ref"] in str(failure.value)
    assert_preserved_prefix(packet.root, saved_replies[:1])


def test_checkpoint_cannot_be_consumed_as_a_formal_map(monkeypatch, packet, completed):
    tool = next(tool for tool in TOOLS if tool.name == "render_report")
    (packet.root / "report.md").write_text("# Offline boundary\n", encoding="utf-8")
    render = Mock(side_effect=AssertionError("Checkpoint must fail before rendering"))
    monkeypatch.setattr("researchkit.report.render", render)
    with pytest.raises(ValueError):
        tool.execute({"markdown_path": "report.md",
                      "mindmap_files": [completed.checkpoints[2].locator]}, packet.ctx)
    render.assert_not_called()
