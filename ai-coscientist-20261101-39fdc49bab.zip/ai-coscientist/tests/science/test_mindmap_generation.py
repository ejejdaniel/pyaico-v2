"""S24 saved-reply replay and structural boundaries; no live model calls.

The three replies and source files are copied from the recorded real execution.
This tests the new procedure and preservation, not a new scientific result or
the quality of model reasoning. Boundary mutations are explicitly synthetic.
"""

from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace
import threading
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Broker, PermissionDenied, Rule
from opencode.provider import Completion, ProviderError, ToolCall
from researchkit import mindmap, mindmap_schema, records, report_evidence, review_provider
from route_map_conversion import to_route_map


FIXTURE = Path(__file__).parent / "fixtures/mindmap_saved"
SKILL_PATH = Path(__file__).resolve().parents[2] / "src/researchkit/skills/mindmap-builder/SKILL.md"
SOURCE_NAMES = ("authoritative_goal.md", "Case_Photolithography.md", "litho_historical_data.csv")
SCOPED_TRANSPORT = mindmap.complete_once


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("Mind-map replay must never use a real model or network transport")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(mindmap, "complete_once", forbidden)


@pytest.fixture
def saved_replies():
    events = [json.loads(line) for line in (FIXTURE / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [event["event_sequence"] for event in events] == [359, 366, 373]
    replies = [deepcopy(next(call["arguments"] for call in event["tool_calls"]
                             if call["name"] == "return_skill_stage_result")) for event in events]
    # The saved architecture and deepening maps predate the route-family format.
    return [replies[0], *(to_route_map(reply) for reply in replies[1:])]


def completion(value):
    return Completion(text=json.dumps(value, ensure_ascii=False), finish_reason="stop")


def save(root, contents, *, kind="notes", dependencies=()):
    for name, content in contents.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content if isinstance(content, bytes) else content.encode("utf-8"))
    return records.publish(root, kind=kind, title="Saved replay source",
                           files=list(contents), depends_on=list(dependencies))


def locator(saved, source):
    return {"record_ref": saved["record_path"], "source_path": source}


def snapshot(root, saved, source):
    entry = next(item for item in saved["files"] if item["source_path"] == source)
    return root / Path(saved["record_path"]).parent / entry["snapshot"]


@pytest.fixture
def packet(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    ancestor = save(root, {"unselected-ancestor.txt": "UNSELECTED_ANCESTOR_PRIVATE"})
    task = save(root, {SOURCE_NAMES[0]: (FIXTURE / SOURCE_NAMES[0]).read_bytes()}, kind="task")
    evidence = save(root, {
        SOURCE_NAMES[1]: (FIXTURE / SOURCE_NAMES[1]).read_bytes(),
        SOURCE_NAMES[2]: (FIXTURE / SOURCE_NAMES[2]).read_bytes(),
        "unselected.txt": "UNSELECTED_SIBLING_PRIVATE",
    }, dependencies=[ancestor["record_path"]])
    ctx = SimpleNamespace(
        directory=root, worktree=root, session_id="saved-mindmap-replay",
        abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")], prompt="PARENT_PROMPT_PRIVATE"),
        app=SimpleNamespace(
            permissions=Broker(auto=True),
            skills={"mindmap-builder": SimpleNamespace(location=SKILL_PATH)},
            store=SimpleNamespace(
                messages=Mock(side_effect=AssertionError("No parent history")),
                todos=Mock(side_effect=AssertionError("No parent plan")),
                source_receipts=Mock(side_effect=AssertionError("No implicit sources"))),
            system="PARENT_SYSTEM_PRIVATE", history=[{"role": "user", "content": "PARENT_HISTORY_PRIVATE"}]),
    )
    args = {
        "scope": "離線回放既存來源與原樣保存回覆，只驗證程序及資料傳遞，不宣稱新科學結論。",
        "task_ref": task["record_path"],
        "files": [locator(task, SOURCE_NAMES[0]), locator(evidence, SOURCE_NAMES[1]),
                  locator(evidence, SOURCE_NAMES[2])],
    }
    return SimpleNamespace(root=root, ctx=ctx, args=args, task=task, evidence=evidence, ancestor=ancestor)


def install_replies(monkeypatch, replies):
    model = Mock(side_effect=[item if isinstance(item, (Completion, Exception)) else completion(item)
                              for item in replies])
    monkeypatch.setattr(mindmap, "complete_once", model)
    return model


def checkpoint_records(root):
    return [record for record in records.inventory(root) if record["kind"] == "mindmap_checkpoint"]


def assert_preserved_prefix(root, replies):
    checkpoints = checkpoint_records(root)
    assert len(checkpoints) == len(replies)
    assert not any(record["kind"] == "mindmap" for record in records.inventory(root))
    stages = ("observation", "architecture", "deepening")
    for record in checkpoints:
        selected = [item for item in record["files"] if Path(item["source_path"]).name == "checkpoint.json"]
        assert len(selected) == 1
        value = json.loads(snapshot(root, record, selected[0]["source_path"]).read_text(encoding="utf-8"))
        present = [stage for stage in stages if stage in value]
        assert present == list(stages[:len(present)])
        assert [value[stage] for stage in present] == replies[:len(present)]


def test_saved_three_stage_generation_publication_and_exact_readback(monkeypatch, packet, saved_replies):
    before = {name: (FIXTURE / name).read_bytes() for name in (*SOURCE_NAMES, "events.jsonl")}
    model = install_replies(monkeypatch, saved_replies)
    result = mindmap.execute(packet.args, packet.ctx)
    receipt = json.loads(result.output)
    assert result.title == "research_mindmap"
    assert result.metadata == {} and result.attachments == []
    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on"}
    assert receipt["kind"] == "mindmap"
    assert receipt["depends_on"][:2] == [packet.task["record_path"], packet.evidence["record_path"]]
    assert len(receipt["depends_on"]) == 3
    final_checkpoint = records.read_record(packet.root, receipt["depends_on"][2])
    assert final_checkpoint["kind"] == "mindmap_checkpoint"
    assert len(checkpoint_records(packet.root)) == 3
    assert len(receipt["files"]) == 2
    assert [Path(item["source_path"]).name for item in receipt["files"]] == ["mindmap.json", "mindmap.md"]
    assert all(item["source_path"].startswith(".research/mindmaps/") for item in receipt["files"])
    raw_json, raw_markdown = [Path(item["snapshot"]).read_bytes() for item in receipt["files"]]
    assert mindmap_schema.parse_map(raw_json.decode("utf-8")) == saved_replies[2]
    markdown = raw_markdown.decode("utf-8")

    def strings(value):
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            for child in value.values():
                yield from strings(child)
        elif isinstance(value, list):
            for child in value:
                yield from strings(child)

    assert all(text in markdown for value in (saved_replies[0], saved_replies[2]) for text in strings(value))
    assert len(saved_replies[2]["families"]) == 5
    assert len(saved_replies[2]["supported_relationships"]) == 7
    assert sum("<->" in text for text in saved_replies[2]["supported_relationships"]) == 2
    positions = [markdown.index(f"## {family['family_id']}:") for family in saved_replies[2]["families"]]
    assert positions == sorted(positions)
    for choice in packet.args["files"]:
        source = report_evidence.resolve(packet.root, [choice])[0]
        assert source["record_ref"] in markdown and source["source_path"] in markdown
        assert source["sha256"] in markdown
    assert all((FIXTURE / name).read_bytes() == content for name, content in before.items())
    assert model.call_count == 3


def test_each_stage_retains_full_selected_sources_and_no_parent_or_unselected_text(monkeypatch, packet, saved_replies):
    # Changing a mutable working copy must not replace the selected frozen data.
    (packet.root / SOURCE_NAMES[1]).write_text("NEW_WORKING_COPY_PRIVATE", encoding="utf-8")
    model = install_replies(monkeypatch, saved_replies)
    mindmap.execute(packet.args, packet.ctx)
    expected = report_evidence.resolve(packet.root, packet.args["files"])
    for index, call in enumerate(model.call_args_list):
        assert call.args == (packet.ctx,)
        assert set(call.kwargs) == {"system", "messages", "frozen", "response_schema"}
        system, messages = call.kwargs["system"], call.kwargs["messages"]
        stage = ("observation", "architecture", "deepening")[index]
        guidance = (SKILL_PATH.parent / "references" / f"{stage}.md").read_text(encoding="utf-8")
        assert system.startswith(guidance + "\n\n")
        # The audit (deepening) replies with corrections to the draft.
        schema = (mindmap_schema.OBSERVATION_SCHEMA, mindmap_schema.MAP_SCHEMA, mindmap_schema.EDITS_SCHEMA)[index]
        assert mindmap._json(schema) in system
        # The same stage schema constrains generation, without length limits.
        assert call.kwargs["response_schema"] == ("mindmap_" + stage, review_provider.generation_schema(schema))
        assert len(messages) == 1 and messages[0]["role"] == "user"
        text = messages[0]["content"]
        for source in expected:
            assert mindmap._json(source["text"]) in text
            assert source["record_ref"] in text and source["sha256"] in text
        for secret in ("UNSELECTED_ANCESTOR_PRIVATE", "UNSELECTED_SIBLING_PRIVATE",
                       "PARENT_PROMPT_PRIVATE", "PARENT_SYSTEM_PRIVATE", "PARENT_HISTORY_PRIVATE",
                       "NEW_WORKING_COPY_PRIVATE"):
            assert secret not in system + text
        assert packet.args["scope"] in text
        assert "not measured evidence" in text
        if index:
            assert mindmap._json(saved_replies[0]) in text
            assert "fallible, not original evidence" in text
        if index == 2:
            assert mindmap._json(saved_replies[1]) in text
            assert "fallible model output" in text
    packet.ctx.app.store.messages.assert_not_called()
    packet.ctx.app.store.todos.assert_not_called()
    packet.ctx.app.store.source_receipts.assert_not_called()


def test_working_source_files_are_not_opened_during_generation(monkeypatch, packet, saved_replies):
    forbidden = {packet.root / name for name in SOURCE_NAMES}
    opened = []
    original_open = Path.open

    def observe(path, mode="r", *args, **kwargs):
        if "r" in mode:
            opened.append(path.resolve())
        return original_open(path, mode, *args, **kwargs)

    replies = iter(saved_replies)

    def reply(*args, **kwargs):
        assert not forbidden.intersection(opened)
        return completion(next(replies))

    monkeypatch.setattr(Path, "open", observe)
    model = Mock(side_effect=reply)
    monkeypatch.setattr(mindmap, "complete_once", model)
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 3
    # Checkpoint publication and its permission preflight verify dependencies.
    # That storage validation does not grant model visibility (checked above).
    assert packet.root / packet.ancestor["record_path"] in opened


@pytest.mark.parametrize("stage", [0, 1, 2])
def test_one_structural_repair_keeps_complete_rejected_result_and_same_sources(monkeypatch, packet, saved_replies, stage):
    rejected = deepcopy(saved_replies[stage])
    rejected["unapproved_field"] = "STRUCTURAL_MUTATION"
    replies = saved_replies[:stage] + [rejected, saved_replies[stage]] + saved_replies[stage + 1:]
    model = install_replies(monkeypatch, replies)
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 4
    original, repair = model.call_args_list[stage:stage + 2]
    assert original.kwargs["system"] == repair.kwargs["system"]
    assert repair.kwargs["messages"][0]["content"].startswith(original.kwargs["messages"][0]["content"])
    assert mindmap._json(completion(rejected).text) in repair.kwargs["messages"][0]["content"]
    assert "Additional properties" in repair.kwargs["messages"][0]["content"]


def test_repair_asks_for_a_change_and_an_unchanged_repair_is_named(monkeypatch, packet, saved_replies):
    # LIT v21: four architecture repairs returned the rejected result byte for byte.
    rejected = deepcopy(saved_replies[0])
    rejected["unapproved_field"] = "STRUCTURAL_MUTATION"
    model = install_replies(monkeypatch, [rejected, deepcopy(rejected)])
    with pytest.raises(ValueError, match="one structural repair: .*the repair returned the rejected result unchanged"):
        mindmap.execute(packet.args, packet.ctx)
    repair = model.call_args_list[1].kwargs["messages"][0]["content"]
    assert "the same result returned unchanged fails the same check again" in repair
    assert "such as a route or a written reason, take the one the sources support" in repair


def test_a_changed_but_still_rejected_repair_is_not_called_unchanged(monkeypatch, packet, saved_replies):
    first, second = deepcopy(saved_replies[0]), deepcopy(saved_replies[0])
    first["unapproved_field"], second["other_field"] = "A", "B"
    install_replies(monkeypatch, [first, second])
    with pytest.raises(ValueError, match="one structural repair") as error:
        mindmap.execute(packet.args, packet.ctx)
    assert "unchanged" not in str(error.value)


def test_at_most_six_calls_when_each_stage_needs_one_repair(monkeypatch, packet, saved_replies):
    replies = []
    for value in saved_replies:
        rejected = deepcopy(value)
        rejected["extra"] = True
        replies.extend([rejected, value])
    model = install_replies(monkeypatch, replies)
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 6


@pytest.mark.parametrize("newline", ["\n", "\r\n"])
def test_complete_json_fence_reply_is_accepted_without_repair(monkeypatch, packet, saved_replies, newline):
    # LIT 20261024: complete fenced replies were rejected and both deepening generations were wasted.
    replies = [Completion(text=f"```json{newline}{json.dumps(value, ensure_ascii=False)}{newline}```",
                          finish_reason="stop") for value in saved_replies]
    model = install_replies(monkeypatch, replies)
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 3
    final = next(record for record in records.inventory(packet.root) if record["kind"] == "mindmap")
    saved = report_evidence.resolve(packet.root, [{"record_ref": final["record_path"],
                                                   "source_path": final["files"][0]["source_path"]}])
    assert mindmap_schema.parse_map(saved[0]["text"]) == saved_replies[2]


@pytest.mark.parametrize("text", ["```JSON\n{}\n```", "```json\n{}", "note\n```json\n{}\n```"])
def test_partial_or_prefixed_fence_still_uses_structural_repair(monkeypatch, packet, saved_replies, text):
    model = install_replies(monkeypatch, [Completion(text=text, finish_reason="stop"), *saved_replies])
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 4
    assert "One local structural repair" in model.call_args_list[1].kwargs["messages"][0]["content"]


@pytest.mark.parametrize("stage", [0, 1, 2])
def test_repeated_structural_failure_stops_that_stage_without_restart(monkeypatch, packet, saved_replies, stage):
    model = install_replies(monkeypatch, saved_replies[:stage] + [{}, {}])
    with pytest.raises(ValueError, match="one structural repair"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == stage + 2
    assert_preserved_prefix(packet.root, saved_replies[:stage])


@pytest.mark.parametrize("failure", [
    Completion(text="", finish_reason="stop"),
    Completion(text=" \n ", finish_reason="stop"),
    Completion(text="{}", finish_reason="length"),
    Completion(text="{}", finish_reason="stop", tool_calls=[ToolCall("unexpected", "read", {})]),
    ProviderError("transport failure"),
    ProviderError("600-second local deadline"),
])
@pytest.mark.parametrize("stage", [0, 1, 2])
def test_nonstructural_failure_never_repairs_or_restarts(monkeypatch, packet, saved_replies, stage, failure):
    model = install_replies(monkeypatch, saved_replies[:stage] + [failure])
    with pytest.raises((ValueError, ProviderError)):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == stage + 1
    assert_preserved_prefix(packet.root, saved_replies[:stage])


def test_cancellation_after_model_return_stops_before_next_stage(monkeypatch, packet, saved_replies):
    def cancel(ctx, **kwargs):
        assert ctx is packet.ctx
        ctx.abort.set()
        return completion(saved_replies[0])

    model = Mock(side_effect=cancel)
    monkeypatch.setattr(mindmap, "complete_once", model)
    with pytest.raises(ProviderError, match="aborted"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 1
    assert not (packet.root / ".research/mindmaps").exists()


def test_existing_transport_is_used_without_modifying_review():
    assert mindmap.MAX_BYTES == 262144
    assert review_provider._DEADLINE_SECONDS == 600
    assert SCOPED_TRANSPORT is review_provider.complete_once


def test_installed_guidance_is_current_file_backed_source(monkeypatch, packet, saved_replies):
    installed = packet.root / ".opencode/skills/mindmap-builder"
    (installed / "references").mkdir(parents=True)
    (installed / "SKILL.md").write_bytes(SKILL_PATH.read_bytes())
    for name in ("observation", "architecture", "deepening"):
        (installed / "references" / f"{name}.md").write_bytes(
            (SKILL_PATH.parent / "references" / f"{name}.md").read_bytes())
    packet.ctx.app.skills["mindmap-builder"].location = installed / "SKILL.md"
    revised = installed / "references/architecture.md"
    original = revised.read_text(encoding="utf-8")
    revised.write_text(original + "\nINSTALLED_GUIDANCE_REVISION\n", encoding="utf-8")
    model = install_replies(monkeypatch, saved_replies)
    mindmap.execute(packet.args, packet.ctx)
    assert "INSTALLED_GUIDANCE_REVISION" in model.call_args_list[1].kwargs["system"]
    assert "INSTALLED_GUIDANCE_REVISION" not in model.call_args_list[0].kwargs["system"]
    assert "INSTALLED_GUIDANCE_REVISION" not in model.call_args_list[2].kwargs["system"]


@pytest.mark.parametrize("failure", ["missing_skill", "missing_file", "blank", "denied"])
def test_guidance_failure_never_falls_back_to_packaged_copy(monkeypatch, packet, failure):
    installed = packet.root / ".opencode/skills/mindmap-builder"
    references = installed / "references"
    references.mkdir(parents=True)
    path = references / "observation.md"
    path.write_text(" \n" if failure == "blank" else "Test instruction boundary", encoding="utf-8")
    packet.ctx.app.skills["mindmap-builder"].location = installed / "SKILL.md"
    if failure == "missing_skill":
        packet.ctx.app.skills.clear()
    elif failure == "missing_file":
        path.unlink()
    elif failure == "denied":
        packet.ctx.agent.permission.append(Rule("read", path.relative_to(packet.root).as_posix(), "deny"))
    model = install_replies(monkeypatch, [])
    with pytest.raises((ValueError, FileNotFoundError, PermissionDenied)):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("change", [
    lambda args: args.update(scope="  "),
    lambda args: args.update(unapproved=True),
    lambda args: args.update(files=[]),
    lambda args: args["files"].append(deepcopy(args["files"][0])),
    lambda args: args.update(task_ref="task.md"),
    lambda args: args["files"].pop(0),
    lambda args: args["files"][0].update(source_path=" "),
    lambda args: args["files"][0].update(unapproved=True),
])
def test_invalid_selection_fails_before_any_model_call(monkeypatch, packet, change):
    args = deepcopy(packet.args)
    change(args)
    model = install_replies(monkeypatch, [])
    with pytest.raises(ValueError):
        mindmap.execute(args, packet.ctx)
    model.assert_not_called()


def test_tool_permission_denial_prevents_model_requests(monkeypatch, packet):
    packet.ctx.agent.permission.append(Rule("research_mindmap", "*", "deny"))
    model = install_replies(monkeypatch, [])
    with pytest.raises(PermissionDenied):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert not (packet.root / ".research/mindmaps").exists()


def test_task_kind_is_authoritative_not_filename(monkeypatch, packet):
    wrong = save(packet.root, {SOURCE_NAMES[0]: (FIXTURE / SOURCE_NAMES[0]).read_bytes()}, kind="notes")
    packet.args["task_ref"] = wrong["record_path"]
    packet.args["files"][0] = locator(wrong, SOURCE_NAMES[0])
    model = install_replies(monkeypatch, [])
    with pytest.raises(ValueError, match="kind=task"):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("corruption", ["hash", "missing", "denied"])
def test_selected_snapshot_failure_is_not_replaced_by_working_file(monkeypatch, packet, corruption):
    path = snapshot(packet.root, packet.evidence, SOURCE_NAMES[1])
    if corruption == "hash":
        path.write_bytes(b"tampered frozen source")
    elif corruption == "missing":
        path.unlink()
    else:
        packet.ctx.agent.permission.append(Rule("read", path.relative_to(packet.root).as_posix(), "deny"))
    model = install_replies(monkeypatch, [])
    with pytest.raises((ValueError, FileNotFoundError, PermissionDenied)):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_complete_request_limit_counts_utf8_schema_sources_and_prior_outputs(monkeypatch, packet, saved_replies):
    sources = report_evidence.resolve(packet.root, packet.args["files"])
    source = mindmap._source_message_with_facts(packet.args, sources)
    observation_system = (SKILL_PATH.parent / "references/observation.md").read_text(encoding="utf-8")
    observation_size = len((observation_system + "\n\nExact closed output JSON schema:\n"
                            + mindmap._json(mindmap_schema.OBSERVATION_SCHEMA) + source).encode("utf-8"))
    # One-byte-above the observation request allows the first call, but the full
    # map schema plus complete earlier observation must exceed this limit.
    monkeypatch.setattr(mindmap, "MAX_BYTES", observation_size + 1)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(ValueError, match="architecture request exceeds"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 1
    assert_preserved_prefix(packet.root, saved_replies[:1])


def test_oversized_scope_or_repair_fails_without_truncation(monkeypatch, packet, saved_replies):
    packet.args["scope"] = "界" * (mindmap.MAX_BYTES // 3 + 1)
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(ValueError, match="request exceeds"):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()
    packet.args["scope"] = "Boundary replay"
    huge_rejection = Completion(text="X" * mindmap.MAX_BYTES, finish_reason="stop")
    model = install_replies(monkeypatch, [huge_rejection])
    with pytest.raises(ValueError, match="request exceeds"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 1


def test_publication_checks_edit_permission_before_writing(monkeypatch, packet, saved_replies):
    packet.ctx.agent.permission.append(Rule("edit", "*", "deny"))
    model = install_replies(monkeypatch, saved_replies)
    with pytest.raises(PermissionDenied):
        mindmap.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert not (packet.root / ".research/mindmaps").exists()


def test_corrupt_saved_result_cannot_return_success(monkeypatch, packet, saved_replies):
    publish = records.publish

    def corrupt(*args, **kwargs):
        saved = publish(*args, **kwargs)
        if kwargs["kind"] == "mindmap":
            snapshot(packet.root, saved, saved["files"][1]["source_path"]).write_bytes(b"changed after publication")
        return saved

    monkeypatch.setattr(records, "publish", corrupt)
    install_replies(monkeypatch, saved_replies)
    with pytest.raises(ValueError, match="Recorded file content has changed"):
        mindmap.execute(packet.args, packet.ctx)


@pytest.mark.parametrize("change", [
    lambda value: value.update(extra=True),
    lambda value: value.pop("evidence_boundary_summary"),
    lambda value: value.update(title="x" * 241),
    lambda value: value.update(landscape_summary="x" * 2601),
    lambda value: value.update(evidence_boundary_summary="x" * 1601),
    lambda value: value.update(families=[]),
    lambda value: value["families"][0].update(family_id=" "),
    lambda value: value["families"][1].update(family_id=value["families"][0]["family_id"]),
    lambda value: value["families"][0].pop("steps"),
    lambda value: value["families"][0].update(steps=value["families"][0]["steps"][:1]),
    lambda value: value["families"][0]["steps"][0].update(extra="x"),
    lambda value: value["families"][0].update(summary="x" * 1201),
    lambda value: value["families"][0].update(scope_status="maybe"),
    lambda value: value["families"][0].update(levers=[]),
    lambda value: value.pop("target_model"),
    lambda value: value["target_model"].update(observables=[]),
    lambda value: value["target_model"]["observables"].append(dict(value["target_model"]["observables"][0])),
    # Effects use known observable ids; an in_task route accounts for each observable exactly once.
    lambda value: value["families"][0]["target_effect"][0].update(observable_id="O99"),
    lambda value: value["families"][0]["side_effects"].append({"observable_id": "O99", "effect": "x"}),
    lambda value: value["families"][0].update(side_effects=value["families"][0]["side_effects"][1:]),
    lambda value: value["families"][0]["target_effect"].append(dict(value["families"][0]["target_effect"][0])),
    lambda value: value["families"][0]["side_effects"].append({"observable_id": "O1", "effect": "x"}),
    lambda value: value["families"][0]["target_effect"][0].update(predicted_sign="closer"),
    lambda value: value["target_model"]["observables"][0].update(kind="lower"),
    # An empty current_values is allowed: a design task may have nothing measured yet (test_nominal_targets).
    lambda value: value["target_model"]["observables"][0].update(current_values=[{"label": "S1"}]),
    lambda value: value["target_model"]["observables"][0].update(tolerance=-1),
    lambda value: value["target_model"]["observables"][0].update(target_value="40"),
    lambda value: value["target_model"]["observables"][0].pop("unit"),
    lambda value: value["target_model"]["observables"][0].update(id="has space"),
    lambda value: value.update(supported_relationships=["missing -> unknown: explanation"]),
    lambda value: value.update(supported_relationships=[
        f"{value['families'][0]['family_id']} -> {value['families'][0]['family_id']}: self"]),
    lambda value: value.update(supported_relationships=[
        f"{value['families'][0]['family_id']} -> {value['families'][1]['family_id']}:  \n "]),
    lambda value: value.update(supported_relationships=["Implicit relation with no endpoints"]),
])
def test_strict_map_structure_rejects_boundary_mutations(saved_replies, change):
    value = deepcopy(saved_replies[2])
    change(value)
    with pytest.raises(ValueError):
        mindmap_schema.validate_map(value)


@pytest.mark.parametrize("change", [
    lambda value: value.update(extra=[]),
    lambda value: value.pop("variation_patterns"),
    lambda value: value.update(source_observations=[]),
    lambda value: value.update(variation_patterns=["x"] * 17),
    lambda value: value.update(explicit_scientific_meanings=["x" * 1601]),
    lambda value: value.update(evidence_gaps="text"),
])
def test_strict_observation_structure_rejects_boundary_mutations(saved_replies, change):
    value = deepcopy(saved_replies[0])
    change(value)
    with pytest.raises(ValueError):
        mindmap_schema.validate_observation(value)


@pytest.mark.parametrize("text", [
    '{"title": "a", "title": "b"}',
    '{"title": NaN}',
    '{"title": Infinity}',
    '```json\n{}\n```',
    '{} trailing prose',
])
def test_strict_json_parser_rejects_non_json_or_ambiguous_text(text):
    with pytest.raises(ValueError):
        mindmap_schema.parse_map(text)


def test_unreferenced_identifiers_and_scientific_text_are_not_keyword_scored(saved_replies):
    value = deepcopy(saved_replies[2])
    value["families"][0]["family_id"] = "方法甲 / no extra endpoint restriction"
    value["families"][0]["summary"] = "科學上可能有誤的敘述由作者核對；程式不判斷其真假。"
    value["supported_relationships"] = []
    assert mindmap_schema.validate_map(value) is value
    observation = deepcopy(saved_replies[0])
    observation["evidence_gaps"] = []
    assert mindmap_schema.validate_observation(observation) is observation


def test_every_route_problem_is_reported_at_once_for_a_single_repair(saved_replies):
    # One repair is allowed per stage, so the error must list all problems, not the first.
    value = deepcopy(saved_replies[2])
    for family in value["families"][:2]:
        family["side_effects"] = family["side_effects"][1:]
    with pytest.raises(ValueError) as error:
        mindmap_schema.validate_map(value)
    message = str(error.value)
    assert message.startswith("2 structural problem(s):")
    for family in value["families"][:2]:
        assert f"mindmap.families[{family['family_id']}]" in message


def test_the_audit_may_reply_with_its_corrections_only(monkeypatch, packet, saved_replies):
    # v43's audit wrote the whole map again, 24,000 characters in eleven to thirteen minutes, mostly rewording.
    observation, architecture, deepening = saved_replies
    edits = mindmap_schema.edits_between(architecture, deepening)
    model = install_replies(monkeypatch, [observation, architecture, edits])
    receipt = json.loads(mindmap.execute(packet.args, packet.ctx).output)
    raw_json = Path(receipt["files"][0]["snapshot"]).read_bytes().decode("utf-8")
    assert mindmap_schema.parse_map(raw_json) == deepening
    assert model.call_args_list[2].kwargs["response_schema"] == (
        "mindmap_deepening", review_provider.generation_schema(mindmap_schema.EDITS_SCHEMA))
    assert mindmap._json(mindmap_schema.EDITS_SCHEMA) in model.call_args_list[2].kwargs["system"]


def test_audit_edits_replace_whole_fields_and_keep_the_rest(saved_replies):
    draft = saved_replies[1]
    empty = {"map_fields": {}, "family_fields": [], "added_families": [], "removed_families": []}
    assert mindmap_schema.edits_between(draft, draft) == empty
    assert mindmap_schema.apply_edits(draft, empty) == draft
    first = draft["families"][0]
    edited = mindmap_schema.apply_edits(draft, {**empty, "map_fields": {"target_model": {"couplings": []}},
                                                "family_fields": [{"family_id": first["family_id"],
                                                                   "early_check": "改用單一變數對照。"}]})
    assert edited["target_model"] == {**draft["target_model"], "couplings": []}
    assert edited["families"][0] == {**first, "early_check": "改用單一變數對照。"}
    assert edited["families"][1:] == draft["families"][1:]
    # A renamed route is removed and added, with the relationships' endpoints given anew.
    old, new = first["family_id"], first["family_id"] + "_renamed"
    renamed = mindmap_schema.apply_edits(draft, {
        **empty, "removed_families": [old], "added_families": [{**first, "family_id": new}],
        "map_fields": {"supported_relationships": [text.replace(old, new)
                                                   for text in draft["supported_relationships"]]}})
    assert [family["family_id"] for family in renamed["families"]][-1] == new
    # Relationships still naming the removed route fail the whole-map check.
    with pytest.raises(ValueError, match="structural problem"):
        mindmap_schema.apply_edits(draft, {**empty, "removed_families": [old],
                                           "added_families": [{**first, "family_id": new}]})
    # A reply that is still the whole map is read as before.
    assert mindmap_schema.parse_audit(json.dumps(saved_replies[2], ensure_ascii=False), draft) == saved_replies[2]


@pytest.mark.parametrize("change, message", [
    ({"family_fields": [{"family_id": "F_missing", "summary": "x"}]}, "F_missing is not a route of the draft"),
    ({"removed_families": ["F_missing"]}, "F_missing is not a route of the draft"),
    ({"map_fields": {"families": []}}, "mindmap edits"),
])
def test_audit_edits_that_do_not_fit_the_draft_are_refused(saved_replies, change, message):
    empty = {"map_fields": {}, "family_fields": [], "added_families": [], "removed_families": []}
    with pytest.raises(ValueError, match=message):
        mindmap_schema.apply_edits(saved_replies[1], {**empty, **change})
    first = saved_replies[1]["families"][0]
    with pytest.raises(ValueError, match="is already a route"):
        mindmap_schema.apply_edits(saved_replies[1], {**empty, "added_families": [first]})
