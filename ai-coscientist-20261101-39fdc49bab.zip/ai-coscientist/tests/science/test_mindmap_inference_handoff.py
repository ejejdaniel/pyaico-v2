"""Offline B-C boundary replay; saved replies do not prove new scientific quality."""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from opencode.permission import PermissionDenied, Rule
from opencode.provider import ProviderError
from researchkit import mindmap, records, report_evidence
from test_mindmap_generation import (
    SOURCE_NAMES, install_replies, locator, offline, packet, save, saved_replies, snapshot,
)
from test_mindmap_checkpoint import checkpoints, copy_checkpoint, resumed


@pytest.fixture
def paused(monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, saved_replies[:2])
    receipt = json.loads(mindmap.execute({**packet.args, "pause_after": "architecture"}, packet.ctx).output)
    assert model.call_count == 2
    selected = checkpoints(packet)[1]
    assert receipt["record_path"] == selected.locator["record_ref"]
    return selected


@pytest.fixture
def supplemental(packet):
    saved = save(packet.root, {
        "inference/result.md": "COMPLETE_SUPPLEMENT_BEGIN\nEvidence with limits: α → β.\nCOMPLETE_SUPPLEMENT_END",
        "inference/second.md": "SECOND_EXPLICIT_SUPPLEMENT",
        "inference/private.md": "UNSELECTED_SUPPLEMENT_PRIVATE",
    })
    return saved, [locator(saved, "inference/result.md"), locator(saved, "inference/second.md")]


def frozen(packet, selected):
    return snapshot(packet.root, selected.record, selected.locator["source_path"]).read_bytes()


def reject(monkeypatch, packet, args, *, match=None, errors=(ValueError, OSError, PermissionDenied)):
    model = install_replies(monkeypatch, [])
    with pytest.raises(errors, match=match):
        mindmap.execute(args, packet.ctx)
    model.assert_not_called()


def complete_supplemented(monkeypatch, packet, paused, supplemental, saved_replies):
    args = {**resumed(packet, paused), "additional_evidence": deepcopy(supplemental[1])}
    model = install_replies(monkeypatch, saved_replies[2:])
    receipt = json.loads(mindmap.execute(args, packet.ctx).output)
    assert model.call_count == 1
    return checkpoints(packet)[2], receipt, model


def test_pause_publishes_only_observation_and_architecture(packet, paused, saved_replies):
    saved = checkpoints(packet)
    assert len(saved) == 2
    assert saved[0].value["observation"] == saved_replies[0]
    assert paused.value["architecture"] == saved_replies[1]
    assert "deepening" not in paused.value and "additional_evidence" not in paused.value
    assert set(paused.value["system_sha256"]) == {"observation", "architecture", "deepening"}
    assert not any(record["kind"] == "mindmap" for record in records.inventory(packet.root))


def test_observation_resume_pauses_after_exactly_one_architecture_call(
        monkeypatch, packet, paused, saved_replies):
    first = checkpoints(packet)[0]
    before = frozen(packet, first)
    model = install_replies(monkeypatch, saved_replies[1:2])
    receipt = json.loads(mindmap.execute(
        {**resumed(packet, first), "pause_after": "architecture", "additional_evidence": []}, packet.ctx).output)
    assert model.call_count == 1 and receipt["kind"] == "mindmap_checkpoint"
    new = next(item for item in checkpoints(packet) if item.locator["record_ref"] == receipt["record_path"])
    assert new.record["depends_on"][-1] == first.locator["record_ref"]
    assert new.value["observation"] == first.value["observation"]
    assert frozen(packet, first) == before


def test_architecture_pause_is_read_only_idempotent(monkeypatch, packet, paused):
    before = frozen(packet, paused)
    packet.ctx.agent.permission.extend([Rule("edit", ".research/mindmaps*", "deny"),
                                        Rule("edit", ".research/records*", "deny")])
    model = install_replies(monkeypatch, [])
    receipt = json.loads(mindmap.execute(
        {**resumed(packet, paused), "pause_after": "architecture", "additional_evidence": []}, packet.ctx).output)
    model.assert_not_called()
    assert receipt["kind"] == "mindmap_checkpoint"
    assert receipt["record_path"] == paused.locator["record_ref"]
    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on"}
    assert len(checkpoints(packet)) == 2 and frozen(packet, paused) == before


@pytest.mark.parametrize("invalid", [None, "observation", "deepening", "", [], True])
def test_pause_schema_allows_only_architecture(monkeypatch, packet, invalid):
    reject(monkeypatch, packet, {**packet.args, "pause_after": invalid})


@pytest.mark.parametrize("origin", ["fresh", "fresh_pause", "observation", "architecture_pause"])
def test_new_nonempty_supplements_require_unpaused_explicit_architecture_resume(
        monkeypatch, packet, paused, supplemental, origin):
    args = deepcopy(packet.args)
    if origin == "observation":
        args["resume_from"] = checkpoints(packet)[0].locator
    elif origin == "architecture_pause":
        args["resume_from"] = paused.locator
    if origin.endswith("pause"):
        args["pause_after"] = "architecture"
    args["additional_evidence"] = supplemental[1]
    reject(monkeypatch, packet, args, match="explicit architecture resume")
    assert len(checkpoints(packet)) == 2


@pytest.mark.parametrize("invalid", [None, "", {}, [None], [{}], [{"record_ref": "x"}],
                                    [{"record_ref": "x", "source_path": "y"}]])
def test_invalid_supplement_shape_rejected_before_models(monkeypatch, packet, invalid):
    reject(monkeypatch, packet, {**packet.args, "additional_evidence": invalid})


@pytest.mark.parametrize("case", ["blank_record", "blank_source", "extra", "duplicate", "overlap"])
def test_supplement_selection_is_closed_nonblank_unique_and_disjoint(
        monkeypatch, packet, paused, supplemental, case):
    selection = deepcopy(supplemental[1])
    if case == "blank_record":
        selection[0]["record_ref"] = " "
    elif case == "blank_source":
        selection[0]["source_path"] = " "
    elif case == "extra":
        selection[0]["extra"] = True
    elif case == "duplicate":
        selection.append(deepcopy(selection[0]))
    else:
        selection.append(deepcopy(packet.args["files"][0]))
    reject(monkeypatch, packet, {**resumed(packet, paused), "additional_evidence": selection})


def test_empty_selection_preserves_original_full_flow(monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, saved_replies)
    receipt = json.loads(mindmap.execute({**packet.args, "additional_evidence": []}, packet.ctx).output)
    assert model.call_count == 3 and receipt["kind"] == "mindmap"
    assert len(checkpoints(packet)) == 3
    assert all("additional_evidence" not in selected.value for selected in checkpoints(packet))
    assert all("Supplemental frozen evidence" not in call.kwargs["messages"][0]["content"]
               for call in model.call_args_list)


def test_supplemented_deepening_keeps_sources_prefix_hashes_and_exact_dependencies(
        monkeypatch, packet, paused, supplemental, saved_replies):
    prior = [(item, frozen(packet, item)) for item in checkpoints(packet)]
    saved, choices = supplemental
    (packet.root / "inference/result.md").write_text("MUTABLE_SUPPLEMENT_PRIVATE", encoding="utf-8")
    (packet.root / SOURCE_NAMES[1]).write_text("MUTABLE_ORIGINAL_PRIVATE", encoding="utf-8")
    completed, receipt, model = complete_supplemented(
        monkeypatch, packet, paused, supplemental, saved_replies)
    message = model.call_args.kwargs["messages"][0]["content"]
    assert "Supplemental frozen evidence selected only for deepening:" in message
    original = report_evidence.resolve(packet.root, packet.args["files"])
    extra = report_evidence.resolve(packet.root, choices)
    assert message.startswith(mindmap._source_message(packet.args, original))
    for source in [*original, *extra]:
        assert mindmap._json(source["text"]) in message
        assert source["sha256"] in message and source["source_path"] in message
    assert mindmap._json(paused.value["observation"]) in message
    assert mindmap._json(paused.value["architecture"]) in message
    for forbidden in ("MUTABLE_SUPPLEMENT_PRIVATE", "MUTABLE_ORIGINAL_PRIVATE", "UNSELECTED_SUPPLEMENT_PRIVATE"):
        assert forbidden not in message
    for item, raw in prior:
        assert frozen(packet, item) == raw
        assert "additional_evidence" not in item.value
    assert completed.value["additional_evidence"] == choices
    for key in ("scope", "task_ref", "files", "system_sha256", "observation", "architecture"):
        assert mindmap._json(completed.value[key]) == mindmap._json(paused.value[key])
    refs = [packet.task["record_path"], packet.evidence["record_path"], saved["record_path"]]
    assert completed.record["depends_on"] == refs + [paused.locator["record_ref"]]
    assert receipt["depends_on"] == refs + [completed.locator["record_ref"]]
    assert json.loads(Path(receipt["files"][0]["snapshot"]).read_text(encoding="utf-8")) == saved_replies[2]
    markdown = Path(receipt["files"][1]["snapshot"]).read_text(encoding="utf-8")
    assert all(source["source_path"] in markdown and source["sha256"] in markdown for source in extra)
    assert "UNSELECTED_SUPPLEMENT_PRIVATE" not in markdown


def test_checkpoint_supplements_and_shared_record_refs_dedupe_with_predecessor_last(
        monkeypatch, packet, paused, supplemental, saved_replies):
    first = checkpoints(packet)[0]
    choices = [deepcopy(paused.locator), supplemental[1][0],
               locator(packet.evidence, "unselected.txt"), deepcopy(first.locator)]
    model = install_replies(monkeypatch, saved_replies[2:])
    receipt = json.loads(mindmap.execute(
        {**resumed(packet, paused), "additional_evidence": choices}, packet.ctx).output)
    assert model.call_count == 1
    final = checkpoints(packet)[2]
    assert final.record["depends_on"] == [
        packet.task["record_path"], packet.evidence["record_path"], supplemental[0]["record_path"],
        first.locator["record_ref"], paused.locator["record_ref"],
    ]
    assert receipt["depends_on"] == [
        packet.task["record_path"], packet.evidence["record_path"], paused.locator["record_ref"],
        supplemental[0]["record_path"], first.locator["record_ref"], final.locator["record_ref"],
    ]
    model = install_replies(monkeypatch, [])
    mindmap.execute(resumed(packet, final), packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("explicit", [False, True])
def test_deepening_republication_inherits_or_exactly_matches_saved_evidence_without_models(
        monkeypatch, packet, paused, supplemental, saved_replies, explicit):
    completed, prior_receipt, _ = complete_supplemented(
        monkeypatch, packet, paused, supplemental, saved_replies)
    before = [(item, frozen(packet, item)) for item in checkpoints(packet)]
    args = resumed(packet, completed)
    if explicit:
        args["additional_evidence"] = deepcopy(supplemental[1])
    model = install_replies(monkeypatch, [])
    receipt = json.loads(mindmap.execute(args, packet.ctx).output)
    model.assert_not_called()
    assert receipt["depends_on"] == prior_receipt["depends_on"]
    assert len(checkpoints(packet)) == 3
    assert all(frozen(packet, item) == raw for item, raw in before)


@pytest.mark.parametrize("change", ["empty", "reverse", "remove", "pause"])
def test_completed_deepening_cannot_replace_supplements_or_roll_back(
        monkeypatch, packet, paused, supplemental, saved_replies, change):
    completed, _, _ = complete_supplemented(monkeypatch, packet, paused, supplemental, saved_replies)
    args = resumed(packet, completed)
    if change == "pause":
        args["pause_after"] = "architecture"
    else:
        args["additional_evidence"] = deepcopy(supplemental[1])
        if change == "empty":
            args["additional_evidence"] = []
        elif change == "reverse":
            args["additional_evidence"].reverse()
        else:
            args["additional_evidence"].pop()
    reject(monkeypatch, packet, args)
    assert len(checkpoints(packet)) == 3


def test_old_deepening_checkpoint_without_supplements_accepts_empty_republication(
        monkeypatch, packet, saved_replies):
    install_replies(monkeypatch, saved_replies)
    mindmap.execute(packet.args, packet.ctx)
    final = checkpoints(packet)[2]
    assert "additional_evidence" not in final.value
    model = install_replies(monkeypatch, [])
    mindmap.execute({**resumed(packet, final), "additional_evidence": []}, packet.ctx)
    model.assert_not_called()
    assert len(checkpoints(packet)) == 3


@pytest.mark.parametrize("target", ["manifest", "snapshot", "tool"])
@pytest.mark.parametrize("inherit", [False, True])
def test_supplement_permissions_rechecked_before_call_or_republication(
        monkeypatch, packet, paused, supplemental, saved_replies, target, inherit):
    saved, choices = supplemental
    selected = paused
    if inherit:
        selected, _, _ = complete_supplemented(monkeypatch, packet, paused, supplemental, saved_replies)
    path = saved["record_path"]
    permission = "research_mindmap" if target == "tool" else "read"
    if target == "snapshot":
        path = snapshot(packet.root, saved, choices[0]["source_path"]).relative_to(packet.root).as_posix()
    packet.ctx.agent.permission.append(Rule(permission, path, "deny"))
    args = resumed(packet, selected)
    if not inherit:
        args["additional_evidence"] = choices
    reject(monkeypatch, packet, args, errors=(PermissionDenied,))


@pytest.mark.parametrize("target", ["snapshot", "manifest"])
def test_supplement_frozen_tampering_rejected_before_model(monkeypatch, packet, paused, supplemental, target):
    saved, choices = supplemental
    path = (packet.root / saved["record_path"] if target == "manifest" else
            snapshot(packet.root, saved, choices[0]["source_path"]))
    path.write_bytes(path.read_bytes() + b"tampered")
    reject(monkeypatch, packet, {**resumed(packet, paused), "additional_evidence": choices})


@pytest.mark.parametrize("raw", [b"\xff", b"bad\x00text"])
def test_supplement_must_be_complete_utf8_text(monkeypatch, packet, paused, raw):
    saved = save(packet.root, {"bad-evidence.bin": raw})
    reject(monkeypatch, packet, {**resumed(packet, paused),
                               "additional_evidence": [locator(saved, "bad-evidence.bin")]})


def test_combined_deepening_request_budget_counts_complete_supplement_and_preserves_prior_work(
        monkeypatch, packet, paused, supplemental, saved_replies):
    _, _, model = complete_supplemented(monkeypatch, packet, paused, supplemental, saved_replies)
    kwargs = model.call_args.kwargs
    size = len(kwargs["system"].encode("utf-8")) + len(kwargs["messages"][0]["content"].encode("utf-8"))
    monkeypatch.setattr(mindmap, "MAX_BYTES", size - 1)
    before = frozen(packet, paused)
    reject(monkeypatch, packet, {**resumed(packet, paused), "additional_evidence": supplemental[1]},
           match="request exceeds")
    assert frozen(packet, paused) == before and len(checkpoints(packet)) == 3


def test_oversized_supplement_is_rejected_without_truncation_or_rerunning_first_stages(
        monkeypatch, packet, paused):
    content = "BEGIN" + "x" * 262144 + "END"
    saved = save(packet.root, {"large-evidence.txt": content})
    reject(monkeypatch, packet, {**resumed(packet, paused),
                               "additional_evidence": [locator(saved, "large-evidence.txt")]},
           match="request exceeds")
    assert len(checkpoints(packet)) == 2
    assert snapshot(packet.root, saved, "large-evidence.txt").read_text(encoding="utf-8") == content


@pytest.mark.parametrize("stage", [0, 1])
def test_supplement_field_not_allowed_before_deepening(monkeypatch, packet, paused, stage):
    target = checkpoints(packet)[stage]
    selected = copy_checkpoint(packet, target, mutate=lambda value: value.update(additional_evidence=[]))
    reject(monkeypatch, packet, resumed(packet, selected))


@pytest.mark.parametrize("change", ["missing", "reorder", "predecessor_not_last"])
def test_deepening_dependency_chain_binds_its_own_supplements(
        monkeypatch, packet, paused, supplemental, saved_replies, change):
    final, _, _ = complete_supplemented(monkeypatch, packet, paused, supplemental, saved_replies)
    dependencies = list(final.record["depends_on"])
    if change == "missing":
        dependencies.pop(2)
    elif change == "reorder":
        dependencies[0], dependencies[2] = dependencies[2], dependencies[0]
    else:
        dependencies[2], dependencies[3] = dependencies[3], dependencies[2]
    selected = copy_checkpoint(packet, final, dependencies=dependencies)
    reject(monkeypatch, packet, resumed(packet, selected))


def test_deepening_failure_keeps_original_checkpoints_and_saved_solver_evidence(
        monkeypatch, packet, paused, supplemental):
    saved, choices = supplemental
    prior = [(item, frozen(packet, item)) for item in checkpoints(packet)]
    solver_before = [snapshot(packet.root, saved, item["source_path"]).read_bytes() for item in choices]
    error = ProviderError("supplemented deepening transport failed")
    model = install_replies(monkeypatch, [error])
    with pytest.raises(ProviderError) as failure:
        mindmap.execute({**resumed(packet, paused), "additional_evidence": choices}, packet.ctx)
    assert failure.value is error and paused.locator["record_ref"] in str(error)
    assert model.call_count == 1 and len(checkpoints(packet)) == 2
    assert all(frozen(packet, item) == raw for item, raw in prior)
    assert [snapshot(packet.root, saved, item["source_path"]).read_bytes() for item in choices] == solver_before


def test_final_failure_keeps_consumed_evidence_and_republishes_without_a_fourth_checkpoint(
        monkeypatch, packet, paused, supplemental, saved_replies):
    publish = records.publish

    def fail_final(*args, **kwargs):
        if kwargs["kind"] == "mindmap":
            raise OSError("final publication unavailable")
        return publish(*args, **kwargs)

    monkeypatch.setattr(records, "publish", fail_final)
    model = install_replies(monkeypatch, saved_replies[2:])
    with pytest.raises(OSError, match="final publication unavailable"):
        mindmap.execute({**resumed(packet, paused), "additional_evidence": supplemental[1]}, packet.ctx)
    assert model.call_count == 1
    final = checkpoints(packet)[2]
    assert final.value["additional_evidence"] == supplemental[1]
    monkeypatch.setattr(records, "publish", publish)
    model = install_replies(monkeypatch, [])
    receipt = json.loads(mindmap.execute(resumed(packet, final), packet.ctx).output)
    model.assert_not_called()
    assert len(checkpoints(packet)) == 3
    assert supplemental[0]["record_path"] in receipt["depends_on"]
