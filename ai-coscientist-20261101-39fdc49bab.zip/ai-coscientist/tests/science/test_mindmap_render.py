"""Saved-map projection checks, including the local Chromium report path."""
from __future__ import annotations

import copy
import hashlib
from html.parser import HTMLParser
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import urlsplit
from urllib.request import url2pathname
from xml.etree import ElementTree

from researchkit.mindmap_render import (
    _display_width, _wrap_svg_lines, render_html, render_section, render_svg,
)
from researchkit.report import render
from researchkit import report_pdf
from researchkit.report_mindmap import render_mindmap
from route_map_conversion import to_route_map


ROOT = Path(__file__).resolve().parents[2]
FIXTURE = Path(__file__).with_name("fixtures") / "mindmap_saved" / "events.jsonl"
NS = {"s": "http://www.w3.org/2000/svg"}


def saved_map() -> dict:
    event = json.loads(FIXTURE.read_text(encoding="utf-8").splitlines()[2])
    # The saved map predates the route-family format; see route_map_conversion.
    return to_route_map(next(item["arguments"] for item in event["tool_calls"]
                             if item["name"] == "return_skill_stage_result"))


def provenance(value) -> dict:
    return {
        "record_ref": ".research/records/" + "1" * 64 + "/record.json",
        "source_path": ".research/mindmaps/saved-response/mindmap.json",
        "sha256": hashlib.sha256(json.dumps(value, ensure_ascii=False).encode()).hexdigest(),
        "title": value["title"], "kind": "mindmap",
    }


class ProjectionHTML(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.ids, self.family_ids, self.tags, self.text, self.images = [], [], [], [], []
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if "data-family-id" in attrs:
            self.family_ids.append(attrs["data-family-id"])
        if tag == "img":
            self.images.append(attrs["src"])

    def handle_data(self, data):
        self.text.append(data)


class MindmapProjectionTests(unittest.TestCase):
    def setUp(self):
        self.value = saved_map()

    def test_saved_map_graph_preserves_all_families_stages_risks_and_explicit_relations(self):
        svg = render_svg(self.value, namespace="saved-map")
        tree = ElementTree.fromstring(svg)
        expected = [item["family_id"] for item in self.value["families"]]
        actual = [node.get("data-map-family-id") for node in tree.iter()
                  if "data-map-family-id" in node.attrib]
        self.assertEqual(actual, expected)
        self.assertEqual(len(expected), 5)
        risks = [node.get("data-map-risk-family-id") for node in tree.iter()
                 if "data-map-risk-family-id" in node.attrib]
        self.assertEqual(risks, expected)
        relations = [node for node in tree.iter()
                     if node.get("class") == "map-relation-annotation"]
        self.assertEqual(len(relations), 7)
        self.assertEqual(sum(len(node.findall("s:polygon", NS)) == 2 for node in relations), 2)
        for relation, declared in zip(relations, self.value["supported_relationships"]):
            self.assertEqual(relation.find("s:title", NS).text, declared)
            path = relation.find("s:path", NS)
            source, operator, target = re.match(
                r"([A-Za-z0-9_.:-]+)\s*(<->|->)\s*([A-Za-z0-9_.:-]+)\s*:", declared,
            ).groups()
            self.assertEqual(path.get("data-map-source-id"), source)
            self.assertEqual(path.get("data-map-target-id"), target)
            self.assertEqual(len(relation.findall("s:polygon", NS)), 2 if operator == "<->" else 1)
        for label in ("可調整的槓桿", "逐步機轉", "對目標的作用"):
            self.assertEqual("".join(tree.itertext()).count(label), 5)
        self.assertNotIn("var(", svg)
        self.assertNotIn('fill="url(', svg)
        self.assertNotIn('marker-start="', svg)
        self.assertNotIn('marker-end="', svg)

    def test_full_fields_and_original_order_survive_escaped_html(self):
        self.value["families"][0]["summary"] += '\n<script>alert("science")</script> & <source>'
        rendered = render_section(self.value, provenance(self.value), namespace="full")
        parsed = ProjectionHTML(rendered)
        self.assertEqual(parsed.family_ids, [item["family_id"] for item in self.value["families"]])
        self.assertNotIn("script", parsed.tags)
        text = "".join(parsed.text)
        for family in self.value["families"]:
            for key, value in family.items():
                if isinstance(value, list):
                    for item in value:
                        for part in (item.values() if isinstance(item, dict) else [item]):
                            self.assertIn(part, text)
                else:
                    self.assertIn(value, text)
        for item in self.value["target_model"]["observables"]:
            for key in ("id", "name", "ranking_score", "unit", "kind", "needed_change"):
                self.assertIn(item[key], text)
            self.assertIn(f"{item['target_value']:g}", text)
            for entry in item["current_values"]:
                self.assertIn(entry["label"], text)
                self.assertIn(f"{entry['value']:g}", text)
        self.assertIn(self.value["target_model"]["governing_relation"], text)
        for field in ("title", "landscape_summary", "evidence_boundary_summary"):
            self.assertIn(self.value[field], text)
        for gap in self.value["unresolved_gaps"]:
            self.assertIn(gap, text)
        for relationship in self.value["supported_relationships"]:
            self.assertIn(relationship.split(": ", 1)[1], text)
        for item in provenance(self.value).values():
            self.assertIn(item, text)

    def test_every_existing_lane_route_connects_to_collector_including_one_and_last(self):
        for count in (1, 5):
            with self.subTest(families=count):
                value = copy.deepcopy(self.value)
                value["families"] = value["families"][:count]
                if count == 1:
                    value["supported_relationships"] = []
                tree = ElementTree.fromstring(render_svg(value))
                collectors = []
                for node in tree.findall("s:path", NS):
                    if node.get("class") == "map-edge map-edge-shared":
                        match = re.fullmatch(r"M([\d.]+) ([\d.]+) H([\d.]+)", node.get("d", ""))
                        if match:
                            collectors.append(tuple(map(float, match.groups())))
                routes = []
                for group in tree.findall("s:g", NS):
                    if "data-map-family-id" not in group.attrib:
                        continue
                    for node in group.findall("s:path", NS):
                        match = re.fullmatch(
                            r"M[\d.]+ [\d.]+ V[\d.]+ H([\d.]+) V([\d.]+)", node.get("d", ""),
                        )
                        if match:
                            routes.append(tuple(map(float, match.groups())))
                self.assertEqual(len(routes), count)
                for x, y in routes:
                    self.assertTrue(any(start <= x <= end and height == y
                                        for start, height, end in collectors))

    def test_multiple_maps_have_independent_svg_resources_and_all_eight_families(self):
        value = copy.deepcopy(self.value)
        for number in range(5, 8):
            family = copy.deepcopy(value["families"][0])
            family["family_id"] = f"test_family_{number}"
            value["families"].append(family)
        parts = [render_section(value, provenance(value), namespace=name)
                 for name in ("map-one", "map-two")]
        parsed = ProjectionHTML("".join(parts))
        self.assertEqual(len(parsed.family_ids), 16)
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        for part, name in zip(parts, ("map-one", "map-two")):
            ids = set(ProjectionHTML(part).ids)
            for reference in re.findall(r"url\(#([^)]*)\)", part):
                self.assertIn(reference, ids)
                self.assertTrue(reference.startswith(name + "-"))

    def test_missing_structure_and_markdown_are_rejected_without_fallback(self):
        value = copy.deepcopy(self.value)
        del value["families"][0]["steps"]
        for malformed in (value, "# Legacy markdown map", {"machine_payload": self.value}):
            with self.subTest(type=type(malformed).__name__), self.assertRaises(ValueError):
                render_svg(malformed)
        with self.assertRaises(ValueError):
            render_svg(self.value, namespace='bad"><script>')

    def test_chinese_svg_line_wrap_obeys_display_width(self):
        lines = _wrap_svg_lines("這是一段需要依照實際顯示寬度換行的繁體中文內容", width=12)
        self.assertGreater(len(lines), 1)
        self.assertTrue(all(_display_width(line) <= 12 for line in lines))

    def test_a_full_width_colon_may_introduce_the_explanation(self):
        # v32 wrote all eight relationships as "A -> B：..." and the whole architecture was refused.
        from researchkit.mindmap_schema import RELATIONSHIP_PATTERN
        self.assertEqual(RELATIONSHIP_PATTERN.fullmatch("F1_acid -> F2_base：酸鹼中和").groups(),
                         ("F1_acid", "->", "F2_base", "酸鹼中和"))
        self.assertEqual(RELATIONSHIP_PATTERN.fullmatch("a.b:c <-> d: x").groups(), ("a.b:c", "<->", "d", "x"))

    def test_multiline_explicit_relationship_keeps_arrow_and_complete_explanation(self):
        self.value["supported_relationships"][0] += "\n作者補充的第二行關係解釋。"
        svg = ElementTree.fromstring(render_svg(self.value))
        relations = [node for node in svg.iter() if node.get("class") == "map-relation-annotation"]
        self.assertEqual(len(relations), 7)
        self.assertEqual(relations[0].find("s:title", NS).text, self.value["supported_relationships"][0])
        section = render_section(self.value, provenance(self.value), namespace="multiline")
        self.assertIn("作者補充的第二行關係解釋。", "".join(ProjectionHTML(section).text))

    def test_standalone_script_uses_shared_projection_and_exact_file_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "selected-map.json"
            raw = json.dumps(self.value, ensure_ascii=False, indent=2).encode("utf-8")
            source.write_bytes(raw)
            for extension in ("svg", "html"):
                destination = root / ("map." + extension)
                subprocess.run([sys.executable, str(ROOT / "scripts/render_mindmap_artifact.py"),
                                "--input", str(source), "--output", str(destination)],
                               check=True, capture_output=True, cwd=ROOT)
                rendered = destination.read_text(encoding="utf-8")
                if extension == "svg":
                    self.assertEqual(rendered, render_svg(self.value, namespace="standalone-mindmap"))
                else:
                    self.assertIn(hashlib.sha256(raw).hexdigest(), rendered)
                    self.assertIn(str(source), rendered)
                    self.assertIn(render_svg(self.value, namespace="standalone-mindmap"), rendered)
            self.assertEqual(source.read_bytes(), raw)

    @unittest.skipUnless(
        all(importlib.util.find_spec(name) for name in ("pymupdf", "markdown")),
        "Optional report dependencies absent",
    )
    def test_saved_six_family_fields_and_original_prefix_reach_same_html_pdf(self):
        import pymupdf

        # Keep the exact frozen six-family map and saved report prefix. The
        # formal renderer now accepts authored Markdown, escaping raw HTML;
        # preserve the prefix's literal text as Markdown paragraphs here.
        # This is a production-path content replay, not a Story offset test.
        map_raw = FIXTURE.with_name("six_family_map.json").read_bytes()
        prefix_raw = FIXTURE.with_name("six_family_report_prefix.html").read_bytes()
        self.assertEqual(hashlib.sha256(map_raw).hexdigest(),
                         "701ff5f7d0b05aef84f3d4f48bc61ff47f6e02f36ddc1caad1454be3b7424e05")
        self.assertEqual(hashlib.sha256(prefix_raw).hexdigest(),
                         "72844c0ab6aad26d217f6595a529fd8550341b49819067c2325fa983f4253a59")
        value = to_route_map(json.loads(map_raw))
        self.assertEqual(len(value["families"]), 6)
        source = {
            "record_ref": ".research/records/"
                          "6fb181e15c3ac0cdd0c7f94bcdc1733b0f457e2490b433a789d5d889f91ed5a9/record.json",
            "source_path": ".research/mindmaps/c2699a63b1994b84ab9ecddcf3b13d98/mindmap.json",
            "sha256": hashlib.sha256(map_raw).hexdigest(),
            "title": value["title"], "kind": "mindmap",
        }

        def normalized(text):
            # The fixed print footer is presentation chrome outside the
            # authored text. Remove its complete line before whitespace;
            # otherwise a next-page leading digit can merge with page count.
            text = re.sub(r"(?m)^RESEARCH REPORT[ \t]*·[ \t]*\d+[ \t]*/[ \t]*\d+[ \t]*$", "", text)
            return re.sub(r"\s|\u200b", "", text)

        self.assertEqual(normalized("RESEARCH REPORT · 5 / 14\n4. 定量代理\n"), "4.定量代理")

        prefix_parts = [part.strip() for part in ProjectionHTML(prefix_raw.decode("utf-8")).text
                        if part.strip()]
        prefix_markdown = "\n\n".join(re.sub(r"([\\`*_{}\[\]()#+\-.!>|])", r"\\\1", part)
                                      for part in prefix_parts)
        projected = render_mindmap(value, source, "report-map-1")
        projected_text = normalized("".join(ProjectionHTML(projected).text))
        expected = []
        for family in value["families"]:
            for key, item in family.items():
                values = item if isinstance(item, list) else [item]
                # Steps and effects are objects; every authored string in them must appear.
                values = [part for value in values
                          for part in (value.values() if isinstance(value, dict) else [value])]
                expected.extend((f"{family['family_id']}.{key}", original) for original in values)
        for key in ("title", "landscape_summary", "evidence_boundary_summary"):
            expected.append((key, value[key]))
        expected.extend(("unresolved_gaps", original) for original in value["unresolved_gaps"])
        for relationship in value["supported_relationships"]:
            source_id, operator, target_id, explanation = re.fullmatch(
                r"([A-Za-z0-9_.:-]+)\s*(<->|->)\s*([A-Za-z0-9_.:-]+)\s*:\s*(.+)",
                relationship, re.DOTALL,
            ).groups()
            expected.extend(("supported_relationships", original) for original in (
                source_id + operator + target_id, explanation,
            ))
        for key, original in expected:
            self.assertIn(normalized(original), projected_text, key)

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            markdown_path = root / "report.md"
            markdown_path.write_text(prefix_markdown, encoding="utf-8")
            original_markdown = markdown_path.read_bytes()
            destination = root / "rendered"
            snapshots = []
            real_print = report_pdf._print_with_browser

            def capture_snapshot(executable, args):
                snapshot = Path(url2pathname(urlsplit(args[-1]).path))
                snapshots.append(snapshot.read_bytes())
                self.assertEqual(snapshot.parent, destination)
                self.assertEqual(snapshots[-1], (destination / "report.html").read_bytes())
                real_print(executable, args)

            with patch.object(report_pdf, "_print_with_browser", side_effect=capture_snapshot) as printer:
                result = render(markdown_path, destination, mindmaps=[{**source, "content": value}])
            printer.assert_called_once()
            html_bytes = Path(result["html_path"]).read_bytes()
            self.assertEqual(snapshots, [html_bytes])
            self.assertIn(hashlib.sha256(html_bytes).hexdigest(), result["note"])
            self.assertEqual(markdown_path.read_bytes(), original_markdown)
            self.assertEqual(FIXTURE.with_name("six_family_map.json").read_bytes(), map_raw)
            parsed = ProjectionHTML(html_bytes.decode("utf-8"))
            self.assertIn("svg", parsed.tags)
            self.assertEqual(parsed.family_ids, [family["family_id"] for family in value["families"]] * 2)
            html_text = normalized("".join(parsed.text))
            with pymupdf.open(result["pdf_path"]) as pdf:
                self.assertGreater(len(pdf), 1)
                self.assertGreater(sum(len(page.get_drawings()) for page in pdf), 0)
                full_text = normalized("".join(page.get_text(
                    flags=pymupdf.TEXTFLAGS_TEXT & ~pymupdf.TEXT_PRESERVE_LIGATURES,
                ) for page in pdf))
                for page in pdf:
                    for word in page.get_text("words"):
                        self.assertGreaterEqual(word[0], 0)
                        self.assertLessEqual(word[2], page.rect.width)
                        self.assertGreaterEqual(word[1], 0)
                        self.assertLessEqual(word[3], page.rect.height)
            # All original prefix text must still be visible in both outputs.
            for original in prefix_parts:
                self.assertTrue(normalized(original) in html_text, ("HTML prefix", original))
                self.assertTrue(normalized(original) in full_text, ("PDF prefix", original))
            # The saved source metadata precedes the complete family cards.
            # Restrict field checks to that latter area so an earlier prefix
            # or graph label cannot hide a missing original field.
            self.assertEqual(full_text.count(source["sha256"]), 1)
            details = full_text.split(source["sha256"], 1)[1]
            family_fields = [item for item in expected if any(
                item[0].startswith(family["family_id"] + ".") for family in value["families"]
            )]
            for key, original in expected:
                self.assertTrue(normalized(original) in html_text, ("HTML", key, original))
                self.assertTrue(normalized(original) in full_text, ("PDF", key, original))
            for key, original in family_fields:
                self.assertTrue(normalized(original) in details, ("Family definition", key, original))
            for key in ("record_ref", "source_path", "sha256"):
                self.assertIn(source[key], html_text)
                self.assertIn(source[key], full_text)

if __name__ == "__main__":
    unittest.main()
