"""Saved-event identity must survive the offline transport adapter."""

import json
from pathlib import Path
import tempfile
import unittest

from scripts.replay_mindmap_pipeline import _saved_events


SOURCE = Path(__file__).parent / "fixtures/mindmap_saved/events.jsonl"


class SavedMindmapReplay(unittest.TestCase):
    def test_original_events_are_preserved(self):
        lines, replies = _saved_events(SOURCE)
        self.assertEqual(b"".join(lines), SOURCE.read_bytes())
        self.assertEqual(len(replies), 3)
        self.assertEqual(replies[1], replies[2])  # observed limitation, not inferred improvement

    def test_swapping_identical_scientific_results_still_rejects_wrong_stage_order(self):
        lines = SOURCE.read_bytes().splitlines(keepends=True)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "events.jsonl"
            path.write_bytes(lines[0] + lines[2] + lines[1])
            with self.assertRaisesRegex(ValueError, "execution order"):
                _saved_events(path)

    def test_wrong_skill_or_nonincreasing_sequence_cannot_be_relabelled(self):
        events = [json.loads(line) for line in SOURCE.read_bytes().splitlines()]
        for key, value in (("skill_id", "another-skill"), ("event_sequence", 1)):
            with self.subTest(key=key), tempfile.TemporaryDirectory() as folder:
                copied = [dict(event) for event in events]
                copied[1][key] = value
                path = Path(folder) / "events.jsonl"
                path.write_text("\n".join(json.dumps(event) for event in copied), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "execution order"):
                    _saved_events(path)
