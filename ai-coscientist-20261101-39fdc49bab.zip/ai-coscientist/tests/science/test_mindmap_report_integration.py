"""Approved S24's exact frozen-map/report boundary, without any model request."""

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch

from opencode.permission import Broker, Rule
from researchkit import records
from researchkit.tools import TOOLS
from route_map_conversion import to_route_map


FIXTURES = Path(__file__).parent / "fixtures/mindmap_saved"


def saved_map():
    event = json.loads((FIXTURES / "events.jsonl").read_text(encoding="utf-8").splitlines()[2])
    # The saved map predates the route-family format; see route_map_conversion.
    return to_route_map(next(call["arguments"] for call in event["tool_calls"]
                             if call["name"] == "return_skill_stage_result"))


class MindmapReportIntegration(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.ctx = SimpleNamespace(
            directory=self.root, worktree=self.root, session_id="offline-map-report",
            abort=threading.Event(), read_files=set(),
            agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
            app=SimpleNamespace(permissions=Broker(auto=True)),
        )
        self.tool = next(tool for tool in TOOLS if tool.name == "render_report")
        (self.root / "report.md").write_text("# 保存心智圖的離線回放\n", encoding="utf-8")

    def save(self, content, *, source="formal.json", kind="mindmap"):
        (self.root / source).write_text(content, encoding="utf-8")
        receipt = records.publish(self.root, kind=kind, title="Saved map", files=[source], depends_on=[])
        return {"record_ref": receipt["record_path"], "source_path": source}

    def render_stub(self):
        return {"html_path": str(self.root / "rendered/report.html"),
                "pdf_path": str(self.root / "rendered/report.pdf"), "pages": 1,
                "renderer": "offline boundary", "note": "No actual rendering in this test."}

    def test_same_file_in_two_selections_is_read_once_and_preserves_exact_content(self):
        raw = json.dumps(saved_map(), ensure_ascii=False)
        locator = self.save(raw)
        opened = []
        original = Path.read_bytes

        def read(path):
            opened.append(path)
            return original(path)

        with patch.object(Path, "read_bytes", read), patch(
                "researchkit.report.render", return_value=self.render_stub()) as render:
            self.tool.execute({"markdown_path": "report.md", "evidence_files": [locator],
                               "mindmap_files": [locator]}, self.ctx)
        selected = render.call_args.kwargs
        self.assertEqual(selected["evidence"][0]["text"], raw)
        self.assertEqual(selected["mindmaps"][0]["text"], raw)
        self.assertEqual(selected["mindmaps"][0]["content"], saved_map())
        self.assertEqual(len(opened), 2)  # one manifest and one snapshot
        self.assertEqual(len(set(opened)), 2)

    def test_historical_markdown_still_appends_but_cannot_claim_to_be_a_diagram(self):
        locator = self.save("# Historical prose map\n", source="mindmap.md")
        with patch("researchkit.report.render", return_value=self.render_stub()) as render:
            self.tool.execute({"markdown_path": "report.md", "evidence_files": [locator]}, self.ctx)
            self.assertNotIn("mindmaps", render.call_args.kwargs)
        with patch("researchkit.report.render") as render, self.assertRaises(ValueError):
            self.tool.execute({"markdown_path": "report.md", "mindmap_files": [locator]}, self.ctx)
        render.assert_not_called()
        self.assertFalse((self.root / ".research/reports").exists())

    def test_wrong_kind_and_unapproved_wrappers_fail_before_render(self):
        examples = [
            (json.dumps(saved_map()), "notes"),
            (json.dumps(saved_map()), "mindmap_checkpoint"),
            (json.dumps({"machine_payload": {"mechanism_landscape": saved_map()}}), "mindmap"),
            ('{"title":"x","title":"y"}', "mindmap"),
        ]
        for raw, kind in examples:
            locator = self.save(raw, kind=kind)
            with self.subTest(kind=kind), patch("researchkit.report.render") as render:
                with self.assertRaises(ValueError):
                    self.tool.execute({"markdown_path": "report.md", "mindmap_files": [locator]}, self.ctx)
                render.assert_not_called()

    def test_duplicate_selection_fails_but_separate_selections_may_overlap(self):
        locator = self.save(json.dumps(saved_map()))
        for key in ("evidence_files", "mindmap_files"):
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "Duplicate"):
                self.tool.execute({"markdown_path": "report.md", key: [locator, locator]}, self.ctx)

    def test_frozen_version_is_used_after_working_file_changes(self):
        original = saved_map()
        locator = self.save(json.dumps(original, ensure_ascii=False))
        (self.root / locator["source_path"]).write_text("NOT THE SAVED VERSION", encoding="utf-8")
        with patch("researchkit.report.render", return_value=self.render_stub()) as render:
            self.tool.execute({"markdown_path": "report.md", "mindmap_files": [locator]}, self.ctx)
        self.assertEqual(render.call_args.kwargs["mindmaps"][0]["content"], original)

    def test_map_schema_exposes_only_approved_selector(self):
        schema = self.tool.parameters["properties"]["mindmap_files"]
        self.assertEqual(set(schema["items"]["properties"]), {"record_ref", "source_path"})
        self.assertEqual(set(schema["items"]["required"]), {"record_ref", "source_path"})
        self.assertFalse(schema["items"]["additionalProperties"])
        self.assertNotIn("mindmap_files", self.tool.parameters["required"])


if __name__ == "__main__":
    unittest.main()
