"""Mind-map invocation settings at the actual offline HTTP encoding boundary.

Accepted outputs replay saved model replies. Invalid and empty replies exercise
transport/format boundaries only; no network or new scientific claim is used.
"""

from copy import deepcopy
import json

import pytest

from opencode.provider import ProviderError
from researchkit import mindmap
from test_mindmap_generation import (
    SCOPED_TRANSPORT, assert_preserved_prefix, offline, packet, saved_replies,
)
from test_review_provider import assert_joined, context, install_transport, wire_response


def configure(packet, *, capable=True, temperature=0):
    transport_ctx, _ = context(capable=capable, temperature=temperature)
    packet.ctx.app.provider = transport_ctx.app.provider
    packet.ctx.app.store.get_session = transport_ctx.app.store.get_session
    packet.ctx.agent.temperature = temperature
    definition = packet.ctx.app.provider.config["provider"]["review"]["models"]["current-model"]
    definition["limit"]["output"] = 32000
    definition["options"]["reasoningEffort"] = "none"
    return packet.ctx.app.provider


def mutate_live_settings(packet):
    live = packet.ctx.app.provider
    models = live.config["provider"]["review"]["models"]
    models["current-model"]["limit"]["output"] = 23
    models["current-model"]["options"].update(
        top_p=0.9, reasoningEffort="high", include_stream_usage=False)
    models["current-model"]["temperature"] = False
    models["new-model"] = {
        "temperature": True, "limit": {"output": 99},
        "options": {"top_p": 0.8, "reasoningEffort": "high", "include_stream_usage": False},
    }
    live.providers["review"].base_url = "https://new-review.invalid/v2"
    live.providers["review"].api_key = "new-test-key"
    packet.ctx.app.store.get_session.return_value = {"model": "review/new-model"}
    packet.ctx.agent.temperature = 0.3


@pytest.mark.parametrize("recovery", ["none", "structure", "temperature"])
def test_one_invocation_freezes_actual_settings_but_keeps_new_stage_and_repair_messages(
        monkeypatch, packet, saved_replies, recovery):
    live = configure(packet)
    initial_config = deepcopy(live.config)
    texts = [json.dumps(reply, ensure_ascii=False) for reply in saved_replies]
    if recovery != "none":
        texts.insert(0, "{}" if recovery == "structure" else "")
    # A separate invocation must acquire the now-current settings afresh.
    texts.extend(json.dumps(reply, ensure_ascii=False) for reply in saved_replies)
    replies = iter(texts)
    sent = []

    def receive(request):
        sent.append(request)
        if len(sent) == 1:
            mutate_live_settings(packet)
        return wire_response("openai", text=next(replies))

    install_transport(monkeypatch, receive)
    monkeypatch.setattr(mindmap, "complete_once", SCOPED_TRANSPORT)
    result = mindmap.execute(packet.args, packet.ctx)
    assert json.loads(result.output)["kind"] == "mindmap"
    count = 3 if recovery == "none" else 4
    assert len(sent) == count
    bodies = [json.loads(request.content) for request in sent]
    expected_parameters = {
        "model": "current-model", "max_tokens": 32000, "temperature": 0,
        "top_p": 0.7, "reasoning_effort": "none", "stream": True,
        "stream_options": {"include_usage": True},
    }
    for index, (request, body) in enumerate(zip(sent, bodies)):
        expected = dict(expected_parameters)
        if recovery == "temperature" and index == 1:
            expected["temperature"] = 0.6
        assert {key: value for key, value in body.items()
                if key not in ("messages", "response_format")} == expected
        # Every stage, including repairs, asks for the stage's strict JSON schema.
        assert body["response_format"]["type"] == "json_schema"
        assert body["response_format"]["json_schema"]["strict"] is True
        assert body["response_format"]["json_schema"]["name"].startswith("mindmap_")
        assert str(request.url) == "https://review.invalid/v1/chat/completions"
        assert request.headers["authorization"] == "Bearer test-key"
        assert "private reasoning" not in json.dumps(body)

    if recovery == "temperature":
        assert bodies[1] == {**bodies[0], "temperature": 0.6}
    elif recovery == "structure":
        original, repair = [body["messages"] for body in bodies[:2]]
        assert repair[0] == original[0]
        assert repair[1]["content"].startswith(original[1]["content"] + "\n\n")
        assert "One local structural repair" in repair[1]["content"]
        assert 'Complete rejected result (literal JSON string):\n\n"{}"' in repair[1]["content"]
        with pytest.raises(ValueError) as invalid:
            mindmap.parse_observation("{}")
        assert str(invalid.value) in repair[1]["content"]

    architecture, deepening = bodies[-2:]
    assert len({bodies[0]["messages"][0]["content"],
                architecture["messages"][0]["content"],
                deepening["messages"][0]["content"]}) == 3
    for body in (architecture, deepening):
        assert mindmap._json(saved_replies[0]) in body["messages"][1]["content"]
        assert "One local structural repair" not in body["messages"][1]["content"]
    assert mindmap._json(saved_replies[1]) in deepening["messages"][1]["content"]
    packet.ctx.app.store.get_session.assert_called_once_with(packet.ctx.session_id)
    changed_config = deepcopy(live.config)
    assert changed_config != initial_config

    mindmap.execute(packet.args, packet.ctx)
    assert len(sent) == count + 3
    for request in sent[count:]:
        body = json.loads(request.content)
        assert str(request.url) == "https://new-review.invalid/v2/chat/completions"
        assert request.headers["authorization"] == "Bearer new-test-key"
        assert {key: value for key, value in body.items() if key not in ("messages", "response_format")} == {
            "model": "new-model", "max_tokens": 99, "temperature": 0.3,
            "top_p": 0.8, "reasoning_effort": "high", "stream": True,
        }
    assert packet.ctx.app.store.get_session.call_count == 2
    assert live.config == changed_config
    assert_joined()


@pytest.mark.parametrize("capable,temperature", [(False, 0), (True, 0.6)])
def test_frozen_capability_or_same_temperature_prevents_recovery_dispatch(
        monkeypatch, packet, capable, temperature):
    configure(packet, capable=capable, temperature=temperature)
    sent = []

    def receive(request):
        sent.append(request)
        # A later mutable setting cannot make the original recovery eligible.
        mutate_live_settings(packet)
        return wire_response("openai", text="")

    install_transport(monkeypatch, receive)
    monkeypatch.setattr(mindmap, "complete_once", SCOPED_TRANSPORT)
    with pytest.raises(ProviderError, match="temperature"):
        mindmap.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    body = json.loads(sent[0].content)
    assert ("temperature" in body) is capable
    if capable:
        assert body["temperature"] == 0.6
    assert_preserved_prefix(packet.root, [])
    assert_joined()


def test_length_reasoning_only_still_stops_after_one_actual_dispatch(monkeypatch, packet):
    configure(packet)
    sent = []

    def receive(request):
        sent.append(request)
        return wire_response("openai", text="", reason="length")

    install_transport(monkeypatch, receive)
    monkeypatch.setattr(mindmap, "complete_once", SCOPED_TRANSPORT)
    with pytest.raises(ValueError, match="complete nonempty"):
        mindmap.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert_preserved_prefix(packet.root, [])
    assert_joined()
