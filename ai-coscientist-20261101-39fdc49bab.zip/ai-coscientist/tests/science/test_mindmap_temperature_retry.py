"""Offline boundaries for the one shared mind-map stage recovery allowance.

Accepted scientific outputs reuse saved replies. Empty/invalid completions below
are synthetic transport boundaries and never represent new research evidence.
"""

from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from opencode.permission import PermissionRejected
from opencode.provider import Completion, ProviderError, ToolCall
from researchkit import mindmap, records, reviewer
from test_mindmap_checkpoint import checkpoints, resumed
from test_mindmap_generation import (
    assert_preserved_prefix, completion, install_replies, offline, packet,
    saved_replies, snapshot,
)


PRIVATE_REASONING = "PRIVATE_REASONING_MUST_NOT_BECOME_AN_ANSWER_OR_PROMPT"


def reasoning_only(*, text="", reasoning=PRIVATE_REASONING, reason="stop", tools=()):
    return Completion(text=text, reasoning_content=reasoning, finish_reason=reason,
                      tool_calls=list(tools))


@pytest.mark.parametrize("stage", [0, 1, 2])
@pytest.mark.parametrize("text", ["", " \t\n "])
def test_reasoning_only_retry_changes_only_call_temperature(
        monkeypatch, packet, saved_replies, stage, text):
    replies = saved_replies[:stage] + [reasoning_only(text=text), saved_replies[stage]]
    replies += saved_replies[stage + 1:]
    model = install_replies(monkeypatch, replies)

    receipt = json.loads(mindmap.execute(packet.args, packet.ctx).output)

    assert receipt["kind"] == "mindmap"
    assert model.call_count == 4
    original, recovery = model.call_args_list[stage:stage + 2]
    assert original.args == recovery.args == (packet.ctx,)
    assert set(original.kwargs) == {"system", "messages", "frozen", "response_schema"}
    assert recovery.kwargs == {**original.kwargs, "recovery_temperature": 0.6}
    for index, call in enumerate(model.call_args_list):
        assert PRIVATE_REASONING not in json.dumps(call.kwargs)
        if index != stage + 1:
            assert set(call.kwargs) == {"system", "messages", "frozen", "response_schema"}
    saved = checkpoints(packet)
    assert len(saved) == 3
    assert [saved[-1].value[name] for name in ("observation", "architecture", "deepening")] == saved_replies
    for record in records.inventory(packet.root):
        for entry in record["files"]:
            assert PRIVATE_REASONING.encode() not in snapshot(packet.root, record, entry["source_path"]).read_bytes()


@pytest.mark.parametrize("failure", [
    reasoning_only(reason="length"),
    reasoning_only(reason="unknown"),
    reasoning_only(reason=None),
    reasoning_only(reason="tool_calls"),
    reasoning_only(tools=[ToolCall("unexpected", "read", {})]),
    reasoning_only(reasoning=None),
    reasoning_only(reasoning=""),
    reasoning_only(reasoning=" \n\t "),
    reasoning_only(reasoning=17),
    reasoning_only(reasoning=["private"]),
    reasoning_only(text=None),
    reasoning_only(text=[]),
    reasoning_only(text={}),
    ProviderError("transport failure", partial=reasoning_only()),
    ProviderError("local deadline", partial=reasoning_only()),
], ids=[
    "length", "unknown-finish", "missing-finish", "tool-finish", "tool-calls",
    "missing-reasoning", "empty-reasoning", "blank-reasoning", "numeric-reasoning",
    "list-reasoning", "missing-text", "list-text", "object-text", "transport", "deadline",
])
def test_ineligible_completion_never_uses_temperature_recovery(
        monkeypatch, packet, saved_replies, failure):
    model = install_replies(monkeypatch, [saved_replies[0], failure])
    with pytest.raises((ValueError, ProviderError)):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    assert all(set(call.kwargs) == {"system", "messages", "frozen", "response_schema"} for call in model.call_args_list)
    assert_preserved_prefix(packet.root, saved_replies[:1])


@pytest.mark.parametrize("stage", [0, 1, 2])
@pytest.mark.parametrize("order", ["empty-then-invalid", "invalid-then-empty", "empty-twice"])
def test_temperature_and_structure_share_two_generation_limit(
        monkeypatch, packet, saved_replies, stage, order):
    empty = reasoning_only()
    failed = {
        "empty-then-invalid": [empty, {}],
        "invalid-then-empty": [{}, empty],
        "empty-twice": [empty, reasoning_only()],
    }[order]
    # A third valid reply would expose an accidental third generation or publish.
    model = install_replies(monkeypatch, saved_replies[:stage] + failed + saved_replies[stage:])
    with pytest.raises(ValueError):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == stage + 2
    first, second = model.call_args_list[stage:stage + 2]
    assert set(first.kwargs) == {"system", "messages", "frozen", "response_schema"}
    if order.startswith("empty"):
        assert second.kwargs == {**first.kwargs, "recovery_temperature": 0.6}
    else:
        assert set(second.kwargs) == {"system", "messages", "frozen", "response_schema"}
        assert "One local structural repair" in second.kwargs["messages"][0]["content"]
    assert_preserved_prefix(packet.root, saved_replies[:stage])


@pytest.mark.parametrize("failure", [
    reasoning_only(reason="length"),
    reasoning_only(tools=[ToolCall("unexpected", "read", {})]),
    ProviderError("recovery transport failed", partial=reasoning_only()),
])
def test_failed_recovery_is_terminal_without_a_third_call(monkeypatch, packet, saved_replies, failure):
    model = install_replies(monkeypatch, [reasoning_only(), failure, saved_replies[0]])
    with pytest.raises((ValueError, ProviderError)):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    assert_preserved_prefix(packet.root, [])


def test_reasoning_that_looks_like_valid_json_is_never_used_as_final_answer(
        monkeypatch, packet, saved_replies):
    private_answer = completion(saved_replies[0]).text
    model = install_replies(monkeypatch, [reasoning_only(reasoning=private_answer), {}])
    with pytest.raises(ValueError):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    assert model.call_args_list[1].kwargs == {
        **model.call_args_list[0].kwargs, "recovery_temperature": 0.6,
    }
    assert private_answer not in model.call_args.kwargs["messages"][0]["content"]
    assert_preserved_prefix(packet.root, [])


def test_nonempty_json_uses_existing_structural_repair_without_temperature_override(
        monkeypatch, packet, saved_replies):
    invalid = Completion(text="{}", reasoning_content=PRIVATE_REASONING, finish_reason="stop")
    model = install_replies(monkeypatch, [invalid, *saved_replies])
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 4
    assert all(set(call.kwargs) == {"system", "messages", "frozen", "response_schema"} for call in model.call_args_list)
    assert PRIVATE_REASONING not in json.dumps(model.call_args_list[1].kwargs)


@pytest.mark.parametrize("cancel_after", [0, 1])
def test_cancellation_before_or_after_reasoning_only_result_never_retries(
        monkeypatch, packet, cancel_after):
    if not cancel_after:
        packet.ctx.abort.set()

    def cancel(ctx, **kwargs):
        ctx.abort.set()
        return reasoning_only()

    model = Mock(side_effect=cancel)
    monkeypatch.setattr(mindmap, "complete_once", model)
    expected = ProviderError if cancel_after else PermissionRejected
    with pytest.raises(expected, match="aborted" if cancel_after else "Execution stopped"):
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == cancel_after
    assert_preserved_prefix(packet.root, [])


def test_each_stage_has_one_recovery_and_temperature_does_not_leak_to_next_stage(
        monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, [item for reply in saved_replies for item in (reasoning_only(), reply)])
    mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 6
    for index in range(0, 6, 2):
        first, second = model.call_args_list[index:index + 2]
        assert set(first.kwargs) == {"system", "messages", "frozen", "response_schema"}
        assert second.kwargs == {**first.kwargs, "recovery_temperature": 0.6}


def test_failed_recovery_preserves_checkpoint_and_resume_skips_completed_stage(
        monkeypatch, packet, saved_replies):
    model = install_replies(monkeypatch, [saved_replies[0], reasoning_only(), reasoning_only()])
    with pytest.raises(ValueError) as failure:
        mindmap.execute(packet.args, packet.ctx)
    assert model.call_count == 3
    assert_preserved_prefix(packet.root, saved_replies[:1])
    selected = checkpoints(packet)[0]
    assert selected.locator["record_ref"] in str(failure.value)
    failed_stage_call = deepcopy(model.call_args_list[1].kwargs)
    before = snapshot(packet.root, selected.record, selected.locator["source_path"]).read_bytes()

    model = install_replies(monkeypatch, [reasoning_only(), *saved_replies[1:]])
    receipt = json.loads(mindmap.execute(resumed(packet, selected), packet.ctx).output)
    assert model.call_count == 3
    assert model.call_args_list[0].kwargs == failed_stage_call
    assert model.call_args_list[1].kwargs == {**failed_stage_call, "recovery_temperature": 0.6}
    assert model.call_args_list[2].kwargs["system"] != failed_stage_call["system"]
    assert snapshot(packet.root, selected.record, selected.locator["source_path"]).read_bytes() == before
    assert receipt["kind"] == "mindmap"
    assert len(checkpoints(packet)) == 3


def test_anthropic_reviewer_reasoning_only_still_stops_after_one_completion(monkeypatch, packet):
    packet.ctx.message_id = "mindmap-offline-review-message"
    packet.ctx.call_id = "mindmap-offline-review-call"

    def complete(ctx, **kwargs):
        kwargs["prepared"]["provider"] = SimpleNamespace(api="anthropic")
        return reasoning_only()

    model = Mock(side_effect=complete)
    monkeypatch.setattr(reviewer, "complete_once", model)
    args = {"scope": packet.args["scope"], "reviewed_refs": [packet.task["record_path"]],
            "files": packet.args["files"]}
    with pytest.raises(ValueError, match="complete nonempty final answer"):
        reviewer.execute(args, packet.ctx)
    model.assert_called_once()
    assert set(model.call_args.kwargs) == {"system", "messages", "prepared", "frozen", "response_schema"}
    assert not any(record["kind"] == "review" for record in records.inventory(packet.root))
