"""Targets with a set best value (nominal-the-best): direction is computed, never guessed.

The mind map records measured quantities with numbers; the host works out which way each
must move and whether a route's physical effect moves it toward the target. Proxies may
predict the quantity itself and declare direction target, ranked by distance to it.
"""

import pytest

from researchkit import board, leaderboard, scoring
from researchkit.mindmap_schema import computed_directions, needed_direction, relation


def observable(kind, values, target=10.0, tolerance=1.0):
    return {"id": "O1", "name": "quantity", "ranking_score": "none", "unit": "u", "kind": kind, "target_value": target,
            "tolerance": tolerance, "current_values": [{"label": f"S{i}", "value": v} for i, v in enumerate(values)],
            "needed_change": "why"}


@pytest.mark.parametrize("kind, values, expected", [
    ("nominal", [14.0, 12.5], "decrease"),      # all above the band
    ("nominal", [6.0, 8.5], "increase"),        # all below the band
    ("nominal", [9.5, 10.8], "keep"),           # all inside the band
    ("nominal", [7.0, 13.0], "per_sample"),     # one each side: no single direction
    ("larger_better", [1.0, 2.0], "increase"),
    ("smaller_better", [1.0, 2.0], "decrease"),
    ("nominal", [], "unknown"),                 # nothing measured yet: no number to compare with the band
    ("smaller_better", [], "decrease"),         # the kind alone fixes the direction
])
def test_needed_direction_follows_the_numbers(kind, values, expected):
    assert needed_direction(observable(kind, values)) == expected


@pytest.mark.parametrize("sign, needed, expected", [
    ("increases", "decrease", "away"),
    ("decreases", "decrease", "toward"),
    ("increases", "increase", "toward"),
    ("decreases", "keep", "may_leave_band"),
    ("increases", "per_sample", "per_sample"),
    ("mixed", "decrease", "unknown"),
    ("unknown", "increase", "unknown"),
    ("decreases", "unknown", "unknown"),
])
def test_relation_compares_a_physical_sign_with_the_needed_direction(sign, needed, expected):
    assert relation(sign, needed) == expected


def test_deepening_sees_which_route_runs_against_the_target():
    value = {"target_model": {"observables": [observable("nominal", [14.0, 12.5])]},
             "families": [{"family_id": "R1", "target_effect": [{"observable_id": "O1", "predicted_sign": "increases"}]},
                          {"family_id": "R2", "target_effect": [{"observable_id": "O1", "predicted_sign": "decreases"}]}]}
    text = computed_directions(value)
    assert "R1 on O1: increases -> away" in text
    assert "R2 on O1: decreases -> toward" in text
    assert "S0 +4 u" in text and "S1 +2.5 u" in text  # signed gaps, not -abs


def test_target_direction_ranks_by_distance_and_keeps_the_sign():
    scoring.check_direction("target", 10.0)
    for bad in (("target", None), ("target", "10"), ("higher", 10.0), ("sideways", None)):
        with pytest.raises(ValueError):
            scoring.check_direction(*bad)
    assert scoring.orient(12.0, "target", 10.0) == scoring.orient(8.0, "target", 10.0) == -2.0
    sheet = {"formula_ref": "f", "formula_id": "P1", "hypothesis_ids": ["H1"], "direction": "target",
             "target_value": 10.0, "values": {"B1": 14.0, "B2": 12.5, "C1": 10.5, "C2": 5.0}}
    result = leaderboard.compute([sheet], ["B1", "B2"], ["C1", "C2"])
    row = result["sheets"][0]
    assert row["target_value"] == 10.0
    assert row["best_baselines"] == ["B2"]                      # 2.5 away beats 4 away
    assert row["candidate_status"] == {"C1": "better", "C2": "worse"}  # 0.5 away vs 5 away (overshoot)
    assert row["values"]["C2"] == 5.0                           # the predicted quantity itself is kept


def test_compare_with_a_target_uses_distance_against_target_satisfaction():
    # Target satisfaction is -abs(y - 10); the proxy predicts y itself.
    proxies = {"A": 13.0, "B": 7.5, "C": 10.2}
    targets = {"A": -3.1, "B": -2.4, "C": -0.1}
    result = scoring.compare(proxies, targets, "target", 10.0)
    assert result["kendall_tau_b"] == 1.0


def test_board_accepts_a_target_declaration_and_rejects_one_without_a_value():
    record = {"record_path": ".research/records/" + "a" * 64 + "/record.json"}
    notices = []
    good = board._proxy_template({"expression": "y", "hypothesis_ids": ["H1"], "direction": "target",
                                  "target_value": 40.0}, record, notices)
    assert good["direction"] == "target" and good["target_value"] == 40.0 and not notices
    bad = board._proxy_template({"expression": "y", "hypothesis_ids": ["H1"], "direction": "target"}, record, notices)
    assert bad["direction"] is None and notices


def _route_map(observable_fields, relationships=()):
    effect = {"observable_id": "O1", "direction": "d", "predicted_sign": "increases",
              "evidence_status": "untested", "magnitude": "m", "basis": "b"}
    family = {"family_id": "R1", "title": "t", "summary": "s", "principle": "p", "scope_status": "in_task",
              "levers": ["l"], "acts_on_terms": ["G1"],
              "steps": [{"change": "c", "quantity": "q", "effect": "e", "evidence": "v"}] * 2,
              "target_effect": [effect], "side_effects": [], "prerequisites": "p", "early_check": "e",
              "main_bottleneck": "b", "expected_failure_mode": "f", "viability_band": "v"}
    return {"title": "t", "landscape_summary": "s",
            "target_model": {"observables": [observable_fields], "governing_relation": "g", "couplings": [],
                             "governing_terms": [{"id": "G1", "quantity": "q", "effect_on_targets": "e",
                                                  "uncovered_reason": ""}]},
            "families": [family, dict(family, family_id="R2")], "supported_relationships": list(relationships),
            "unresolved_gaps": [], "evidence_boundary_summary": "e"}


def test_a_distance_score_listed_as_the_observable_is_sent_back_with_the_fix():
    from researchkit.mindmap_schema import validate_map
    score = observable("larger_better", [-13.7, -7.9], target=0.0, tolerance=0.0)
    with pytest.raises(ValueError, match="looks like a distance score"):
        validate_map(_route_map(score))
    validate_map(_route_map(observable("nominal", [53.7, 47.9], target=40.0)))


def test_a_target_nothing_has_measured_yet_keeps_no_values_and_no_computed_direction():
    # A design that does not exist yet (the room-acoustics case) has no measured value of its targets. The map
    # takes the target without values instead of an estimate, and the host computes no direction for a set
    # target; the distance-score check does not fire on an empty list.
    from researchkit.mindmap_schema import validate_map
    unmeasured = observable("nominal", [], target=0.25, tolerance=0.05)
    validate_map(_route_map(unmeasured))
    validate_map(_route_map(observable("larger_better", [], target=0.0, tolerance=0.0)))
    text = computed_directions({"target_model": {"observables": [unmeasured]}, "families": [
        {"family_id": "R1", "target_effect": [{"observable_id": "O1", "predicted_sign": "decreases"}]}]})
    assert "目前 無量測值" in text and "沒有量測值，無法依數值計算" in text and "與目標的差距" not in text
    assert "R1 on O1: decreases -> unknown" in text


def test_every_relationship_problem_is_listed_and_points_effects_to_target_effect():
    from researchkit.mindmap_schema import validate_map
    value = _route_map(observable("nominal", [53.7, 47.9], target=40.0),
                       ["R1 -> O1: effect on a target", "R2 -> O1: another", "R1 <-> R2: fine"])
    with pytest.raises(ValueError) as error:
        validate_map(value)
    message = str(error.value)
    assert message.startswith("2 structural problem(s):")
    assert "relationships connect two family_id values only" in message


def test_a_governing_term_without_a_route_or_a_reason_is_a_missing_route():
    from researchkit.mindmap_schema import validate_map
    value = _route_map(observable("nominal", [53.7, 47.9], target=40.0))
    value["target_model"]["governing_terms"].append(
        {"id": "G2", "quantity": "photons absorbed per dose", "effect_on_targets": "e", "uncovered_reason": ""})
    with pytest.raises(ValueError, match="no in_task route acts on 'photons absorbed per dose'"):
        validate_map(value)
    value["target_model"]["governing_terms"][1]["uncovered_reason"] = "fixed by the task"
    validate_map(value)
    value["families"][0]["acts_on_terms"] = ["G9"]
    with pytest.raises(ValueError, match="'G9' is not one of"):
        validate_map(value)
