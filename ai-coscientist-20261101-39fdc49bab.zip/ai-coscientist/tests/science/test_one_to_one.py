"""One formula per hypothesis: a formula names its own lever, and a leaderboard has every active hypothesis once.

LIT v28 relabeled a formula combining three hypotheses as H2's and ranked candidates on it alone; no model calls.
"""

import json

import pytest

from opencode.loop import ToolContext
from researchkit import leaderboard, records
from researchkit.tools import _publish
from test_delivery_acceptance import case  # noqa: F401  (fixture)

BASE, CANDIDATES = ["TV0", "TV1"], ["c1"]
V28 = {"hypotheses": [
    {"id": "H1", "statement": "R17 ester moves EOP toward 40 mJ", "levers": ["alg_2"]},
    {"id": "H2", "statement": "lower Mw lowers EOP", "levers": ["mw_kda"]},
    {"id": "H3", "statement": "more additive raises EOP", "levers": ["pdb_wt"]}]}


def ctx_for(case):
    root, app, session = case
    return root, ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)


def save(ctx, **args):
    return json.loads(_publish(args, ctx).output)


def formula(ctx, hypotheses, formula_id, ids, equation, **extra):
    return save(ctx, kind="proxy_formula", title=formula_id, depends_on=[hypotheses["record_path"]], template={
        "formula_id": formula_id, "expression": f"{formula_id.lower()}(row)", "equation": equation,
        "hypothesis_ids": ids, "direction": "higher", **extra})


def test_a_formula_must_name_a_lever_of_its_own_hypothesis(case):
    root, ctx = ctx_for(case)
    hypotheses = save(ctx, kind="hypothesis", title="v28 set", template=V28)
    with pytest.raises(ValueError) as refused:
        formula(ctx, hypotheses, "P1", ["H1"], "47.9 + 182.7*(1/mw_kda - 1/9) + 1.2*alg_2_flag")
    message = str(refused.value)
    assert "P1 is declared for H1 but its expression, equation and inputs name none of the levers the hypothesis " \
           "set gives it (H1: alg_2)" in message and message.endswith("Nothing was saved")
    assert not [r for r in records.inventory(root) if r["kind"] == "proxy_formula"]
    # v28's P1 and P3 added H2's Mw term to their own lever; other terms are free.
    formula(ctx, hypotheses, "P1", ["H1"], "47.9 + 15*[R12] + 182.7*(1/mw_kda - 1/9)", inputs=["ALG_2", "mw_kda"])
    formula(ctx, hypotheses, "P3", ["H3"], "47.9 + 1.2*(pdb_wt - 30.23) + 182.7*(1/mw_kda - 1/9)")
    # v24 wrote its levers as symbols; listing the lever in inputs names it.
    formula(ctx, hypotheses, "P2", ["H2"], "a + b/M", inputs=["mw_kda"])
    # v30 wrote inputs as one sentence; objects name the lever too.
    formula(ctx, hypotheses, "P2", ["H2"], "a + b/M", inputs="mw_kda (M in the equation), from the source table")
    formula(ctx, hypotheses, "P2", ["H2"], "a + b/M", inputs={"M": "mw_kda"})
    unlevered = save(ctx, kind="hypothesis", title="no levers", template={"hypotheses": [
        {"id": "H9", "statement": "a mechanism without declared levers"}]})
    formula(ctx, unlevered, "P9", ["H9"], "anything")


def sheet(ctx, saved, values):
    name = f"values/{saved['record_path'].split('/')[2][:8]}.json"
    (ctx.directory / name).parent.mkdir(parents=True, exist_ok=True)
    (ctx.directory / name).write_text(json.dumps(values), encoding="utf-8")
    implementation = save(ctx, kind="implementation", title="values", files=[name], depends_on=[saved["record_path"]])
    return {"formula_ref": saved["record_path"], "values": {"record_ref": implementation["record_path"],
                                                            "source_path": name}}


def run(root, sheets, name):
    return leaderboard.run({"baseline_ids": BASE, "candidate_ids": CANDIDATES, "sheets": sheets},
                           root, root / f".research/leaderboards/{name}")


def values(n):
    return {"TV0": 1.0 + n, "TV1": 2.0 + n, "c1": 3.0 + 2 * n}


def test_a_leaderboard_needs_a_sheet_of_its_own_for_every_active_hypothesis(case):
    root, ctx = ctx_for(case)
    hypotheses = save(ctx, kind="hypothesis", title="v28 set", template={"hypotheses": [
        *V28["hypotheses"], {"id": "H4", "statement": "later", "levers": ["bake"],
                             "proxy_status": {"status": "deferred", "basis": "budget", "reason": "rank 4"}}]})
    combined = formula(ctx, hypotheses, "PC", ["H2", "H1", "H3"], "mw_kda + alg_2 + pdb_wt")
    p1 = formula(ctx, hypotheses, "P1", ["H1"], "alg_2")
    p2 = formula(ctx, hypotheses, "P2", ["H2"], "mw_kda")
    sheets = {name: sheet(ctx, saved, values(n)) for n, (name, saved) in enumerate(
        (("PC", combined), ("P1", p1), ("P2", p2)))}

    with pytest.raises(ValueError) as refused:
        run(root, [sheets["PC"], sheets["P1"]], "one")
    message = str(refused.value)
    assert "Missing: H2 (its formula P2 " + p2["record_path"] + " has no sheet here); H3 (no formula of its own yet)" \
           in message
    assert "PC names H2, H1, H3 together" in message and "H4" not in message
    assert not (root / ".research/leaderboards/one").exists()

    p3 = formula(ctx, hypotheses, "P3", ["H3"], "pdb_wt")
    receipt = run(root, [sheets["P1"], sheets["P2"], sheet(ctx, p3, values(3)), sheets["PC"]], "two")
    assert [s["formula_id"] for s in receipt["result"]["sheets"]] == ["P1", "P2", "P3", "PC"]


def test_a_leaderboard_follows_the_newest_version_of_the_hypothesis_set(case):
    root, ctx = ctx_for(case)
    first = save(ctx, kind="hypothesis", title="v1", template={"hypotheses": V28["hypotheses"][:2]})
    p1 = formula(ctx, first, "P1", ["H1"], "alg_2")
    p2 = formula(ctx, first, "P2", ["H2"], "mw_kda")
    sheets = [sheet(ctx, p1, values(1)), sheet(ctx, p2, values(2))]
    run(root, sheets, "one")
    save(ctx, kind="hypothesis", title="v2", revises=first["record_path"], template=V28)
    with pytest.raises(ValueError, match=r"Missing: H3 \(no formula of its own yet\)"):
        run(root, sheets, "two")


def test_one_formula_saved_under_each_hypothesis_is_refused(case):
    # The cheapest way past the coverage check: PC saved three times, once per hypothesis, all naming their levers.
    root, ctx = ctx_for(case)
    hypotheses = save(ctx, kind="hypothesis", title="v28 set", template=V28)
    equation = "47.9 + 182.7*(1/mw_kda - 1/9) + 9*alg_2 + 1.2*(pdb_wt - 30.23)"
    copies = [formula(ctx, hypotheses, f"PC{n}", [f"H{n}"], equation) for n in (1, 2, 3)]
    sheets = [sheet(ctx, saved, {"TV0": 68.952, "TV1": 47.9, "c1": 41.0}) for saved in copies]
    with pytest.raises(ValueError) as refused:
        run(root, sheets, "copies")
    message = str(refused.value)
    assert f"PC1 {copies[0]['record_path']} and PC2 {copies[1]['record_path']}" in message
    assert "give the same value for every baseline and candidate" in message and message.endswith("Nothing was saved")
    assert not (root / ".research/leaderboards/copies").exists()
