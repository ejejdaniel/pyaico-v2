"""Replay two saved completions into validation, without HTTP or new science.

The public validator retains historical citation errors; the current reviewer
separately rejects the historical model schema. This proves neither native HTTP
replay, current selector assembly nor model improvement.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import socket
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Broker, Rule
from opencode.provider import Completion
from researchkit import records, review, reviewer


ROOT = Path(__file__).resolve().parents[2]
PYTHON_RUN = ROOT / "tmp/review_neutral_scope_live_20261020"
NATIVE_RUN = ROOT / "tmp/native_general_review_repaired_20261020"
WORKSPACES = (
    PYTHON_RUN / "workspace",
    ROOT / "tmp/native_general_review_20261020/workspace",
)
ARGUMENTS = (PYTHON_RUN / "arguments.json", NATIVE_RUN / "arguments.json")
REQUESTS = (PYTHON_RUN / "request.body.json", NATIVE_RUN / "run/model-request.raw.json")
ANSWERS = (PYTHON_RUN / "final-text.txt", NATIVE_RUN / "run/final-text.txt")
CONTRACT = NATIVE_RUN / "output-contract.txt"


def _require_files(paths):
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        pytest.skip("Saved real-review evidence is unavailable; no demo substitute: "
                    + ", ".join(missing))


def _json(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _hashes(paths):
    return {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def _selected_paths(workspace, arguments):
    """Select only the commissioned snapshots and their record manifests."""
    manifests = {workspace / item["record_ref"] for item in arguments["files"]}
    _require_files(manifests)
    selected = set(manifests)
    for locator in arguments["files"]:
        manifest = workspace / locator["record_ref"]
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == locator["source_path"]]
        snapshot = records.local_path(manifest.parent, entry["snapshot"])
        _require_files([snapshot])
        raw = snapshot.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
        assert len(raw) == entry["bytes"]
        selected.add(snapshot)
    assert len(arguments["files"]) == 8
    assert len(selected) == len(manifests) + 8
    return selected


@pytest.mark.parametrize(
    ("case", "expected_errors"),
    [
        pytest.param(0, (
            ("checks/2/subject/quote", "literal quote not found in the selected snapshot"),
            ("checks/2/evidence/0/quote", "literal quote not found in the selected snapshot"),
            ("checks/4/subject/quote", "literal quote not found in the selected snapshot"),
            ("reviewed_refs/1", "no check.subject refers to this record"),
        ), id="python-saved-completion"),
        pytest.param(1, (
            ("checks/0/evidence/1/quote", "literal quote not found in the selected snapshot"),
            ("checks/4/subject/quote", "literal quote not found in the selected snapshot"),
            ("checks/4/evidence/1/quote", "literal quote not found in the selected snapshot"),
        ), id="native-saved-completion"),
    ],
)
def test_paired_saved_completions_retain_exact_rejections(
        case, expected_errors, tmp_path, monkeypatch):
    def forbidden_network(*args, **kwargs):
        pytest.fail("Saved-completion replay must never use a real network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden_network)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden_network)
    monkeypatch.setattr(socket, "create_connection", forbidden_network)
    monkeypatch.setattr(socket.socket, "connect", forbidden_network)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden_network)

    capture_paths = {*ARGUMENTS, *REQUESTS, *ANSWERS, CONTRACT}
    _require_files(capture_paths)
    saved_arguments = [_json(path) for path in ARGUMENTS]
    assert saved_arguments[0] == saved_arguments[1]
    arguments = deepcopy(saved_arguments[case])
    selected = [_selected_paths(workspace, arguments) for workspace in WORKSPACES]
    source_paths = capture_paths | selected[0] | selected[1]
    source_before = _hashes(source_paths)
    frozen_hashes = [
        {path.relative_to(workspace): source_before[path] for path in paths}
        for workspace, paths in zip(WORKSPACES, selected)
    ]
    assert frozen_hashes[0] == frozen_hashes[1]

    historical_requests = [_json(path) for path in REQUESTS]
    for request in historical_requests:
        assert [message["role"] for message in request["messages"]] == ["system", "user"]
    historical_user = historical_requests[0]["messages"][1]["content"]
    historical_contract = CONTRACT.read_bytes().decode("utf-8")
    assert historical_contract.rstrip("\n") in historical_requests[0]["messages"][0]["content"]
    assert historical_requests[1]["messages"][1]["content"] == (
        historical_user + "\n\nExisting output contract (unchanged):\n" + historical_contract
    )

    workspace = (tmp_path / "workspace").resolve()
    for origin in selected[case]:
        destination = workspace / origin.relative_to(WORKSPACES[case])
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)

    def workspace_hashes():
        return {path.relative_to(workspace): digest for path, digest in
                _hashes(path for path in workspace.rglob("*") if path.is_file()).items()}

    copied_before = workspace_hashes()
    assert copied_before == frozen_hashes[case]
    ctx = SimpleNamespace(
        directory=workspace, worktree=workspace, session_id="saved-completion-replay",
        message_id="saved-message", call_id="saved-call",
        agent=SimpleNamespace(permission=[
            Rule("*", "*", "deny"),
            Rule("read", "*", "allow"),
            Rule("research_review", "*", "allow"),
            Rule("edit", ".research/review-runs/**", "allow"),
            Rule("edit", ".research/review-runs", "allow"),
        ]),
        app=SimpleNamespace(permissions=Broker(auto=True)),
    )
    final_bytes = ANSWERS[case].read_bytes()
    completion = Completion(text=final_bytes.decode("utf-8"), finish_reason="stop")
    model = Mock(return_value=completion)
    publish = Mock(side_effect=AssertionError("Replay must not publish any record"))
    monkeypatch.setattr(reviewer, "complete_once", model)
    monkeypatch.setattr(records, "publish", publish)

    try:
        # The saved public artifacts still have their original contract. Preserve
        # their exact original defects without feeding them through a compatibility
        # path in the new selector-only model interface.
        verified = {ref: _json(workspace / ref) for ref in
                    {item["record_ref"] for item in arguments["files"]}}
        with pytest.raises(ValueError) as rejected:
            review.validate(workspace, final_bytes, arguments["reviewed_refs"], verified)
        # Ignore only the diagnostic's submitted quote and temporary file path.
        # Check the complete ordered list, so missing or extra failures fail.
        assert [line.split("; ", 1)[0] for line in str(rejected.value).splitlines()] == [
            f"review.json/{path}: {message}" for path, message in expected_errors
        ]
        expected_system = "\n\n".join(path.read_text(encoding="utf-8") for path in (
            reviewer.SYSTEM_PATH, reviewer.FORMAT_PATH, reviewer.VERIFICATION_PATH))
        with pytest.raises(ValueError, match="expected exactly checks"):
            reviewer.execute(arguments, ctx)
        _, current_user, _, _, selection = reviewer._input(arguments, ctx)
        assert current_user != historical_user
        assert list(selection) == [f"F{i}" for i in range(1, len(arguments["files"]) + 1)]
        model.assert_called_once_with(
            ctx, system=expected_system,
            messages=[{"role": "user", "content": current_user}],
            prepared={}, frozen={},
            response_schema=("review_checks", reviewer.output_schema(arguments, selection)),
        )
        assert completion.text.encode("utf-8") == final_bytes
        assert arguments == saved_arguments[0] == saved_arguments[1]
        publish.assert_not_called()
    finally:
        assert _hashes(source_paths) == source_before
        after = workspace_hashes()
        # The only addition is the complete rejected reply, kept for diagnosis.
        added = {path for path in after if path not in copied_before}
        assert {path.name for path in added} == {"rejected-initial.txt"}
        assert (workspace / next(iter(added))).read_bytes() == final_bytes
        assert {path: digest for path, digest in after.items() if path not in added} == copied_before
