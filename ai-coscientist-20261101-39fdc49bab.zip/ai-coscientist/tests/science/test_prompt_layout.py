"""Static system prompt, host facts on real messages, human ID headers; no model calls."""

import json
import re

from opencode import loop
from opencode.provider import Completion, ToolCall
from tests.prompt_view import host_facts, plain_messages
from test_delivery_acceptance import case, mock_model


def two_steps(app, session, root):
    (root / "note.md").write_text("A saved note", encoding="utf-8")

    def answer(n, kw):
        if n == 1:
            return Completion(tool_calls=[ToolCall("save", "research_record", {
                "kind": "notes", "title": "Note", "files": ["note.md"]})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    calls = mock_model(app, answer)
    assert app.prompt(session, "Record the note")["text"] == "done"
    return calls


def sections(message):
    return [part for block in re.findall(r"<host-facts>\n(.*?)\n</host-facts>", str(message.get("content")), re.S)
            for part in block.split("\n\n")]


def test_facts_ride_on_real_messages_and_unchanged_sections_stay_put(case):
    root, app, session = case
    first, second = two_steps(app, session, root)
    assert first["system"] == second["system"]
    assert "## Context labels" in first["system"]
    assert "<host-facts>\n" not in first["system"] and "研究看板" not in first["system"]
    # No extra trailing turn: the facts are a suffix of the last real message.
    assert first["messages"][-1]["role"] == "user" and first["messages"][-1]["content"].startswith("<human id=")
    assert second["messages"][-1]["role"] == "tool" and "\n\n<host-facts>\n" in second["messages"][-1]["content"]
    # The history itself is unchanged; host facts are only suffixes.
    assert second["messages"][:len(first["messages"]) - 1] == first["messages"][:-1]
    assert plain_messages(second["messages"])[:len(first["messages"])] == plain_messages(first["messages"])
    # Each section appears once. Unchanged ones stay on the human message; changed ones move to the tool result.
    human = len(first["messages"]) - 1
    every = [part for message in second["messages"] for part in sections(message)]
    assert len(every) == len(set(every))
    assert set(sections(second["messages"][human])) <= set(sections(first["messages"][-1]))
    assert any(part.startswith("本工作階段使用的 Python") for part in sections(second["messages"][human]))
    assert "研究看板" in host_facts(second) and "研究看板" not in host_facts(first)
    assert "研究看板" in "".join(sections(second["messages"][-1]))


def test_a_section_is_sent_when_it_changes_and_stays_put_otherwise():
    loop._FACT_PINS.pop("pins", None)
    human = [{"role": "user", "content": "<human>q</human>"}]
    one = loop._with_host_facts(human, "Count 1\n\nPlan x", "pins")
    assert one[-1]["content"] == "<human>q</human>\n\n<host-facts>\nCount 1\n\nPlan x\n</host-facts>"
    step = human + [{"role": "assistant", "content": ""}, {"role": "tool", "tool_call_id": "t1", "content": "r1"}]
    two = loop._with_host_facts(step, "Count 2\n\nPlan x", "pins")
    assert two[0]["content"] == "<human>q</human>\n\n<host-facts>\nPlan x\n</host-facts>"
    assert two[-1]["content"] == "r1\n\n<host-facts>\nCount 2\n</host-facts>"
    # Nothing changed: nothing new is sent, and the earlier request is an exact prefix.
    later = step + [{"role": "assistant", "content": ""}, {"role": "tool", "tool_call_id": "t2", "content": "r2"}]
    three = loop._with_host_facts(later, "Count 2\n\nPlan x", "pins")
    assert three[:3] == two and three[-1]["content"] == "r2"
    # A compaction dropped the messages that carried them: everything is sent again.
    compacted = [{"role": "user", "content": "summary"}, {"role": "tool", "tool_call_id": "t3", "content": "r3"}]
    four = loop._with_host_facts(compacted, "Count 2\n\nPlan x", "pins")
    assert four[-1]["content"] == "r3\n\n<host-facts>\nCount 2\n\nPlan x\n</host-facts>"
    assert four[0]["content"] == "summary"
    # Without a session every section rides on the last message, as for a one-off request.
    assert loop._with_host_facts(step, "Count 2\n\nPlan x")[-1]["content"].endswith("Count 2\n\nPlan x\n</host-facts>")


def test_host_facts_are_never_saved_and_humans_carry_their_id(case):
    root, app, session = case
    first, second = two_steps(app, session, root)
    stored = app.store.messages(session)
    assert not any("<host-facts>" in json.dumps(m, ensure_ascii=False) for m in stored)
    human = next(m for m in stored if m["role"] == "user")
    assert human["content"] == "Record the note"
    shown = [re.sub(r"\n\n<host-facts>\n.*?\n</host-facts>", "", m["content"], flags=re.S)
             for m in second["messages"] if m["role"] == "user"]
    assert shown == [f'<human id="{human["id"]}">\nRecord the note\n</human>']
    receipt = next(m for m in plain_messages(second["messages"]) if m.get("tool_call_id") == "save")
    saved = next(m for m in stored if m.get("tool_call_id") == "save")
    assert receipt["content"] == saved["content"]


def test_compaction_budget_counts_the_host_facts(case, monkeypatch):
    root, app, session = case
    seen = {}
    monkeypatch.setattr(loop, "usage_overflow", lambda *args: not seen)
    monkeypatch.setattr(loop, "_maybe_compact", lambda *args, **kwargs: seen.setdefault("system", kwargs["system"]))
    calls = mock_model(app, lambda *_: Completion(text="done", finish_reason="stop"))
    assert app.prompt(session, "Hello")["text"] == "done"
    facts = host_facts(calls[0])
    assert facts and facts in seen["system"] and calls[0]["system"] in seen["system"]
    assert len(seen["system"]) > len(calls[0]["system"])


def test_identical_call_repeated_across_steps_is_handed_back_when_unattended(case):
    root, app, session = case
    (root / "same.txt").write_text("unchanged", encoding="utf-8")

    def answer(n, kw):
        if n <= 3:
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(root / "same.txt")})],
                              finish_reason="tool-calls")
        return Completion(text="changed approach", finish_reason="stop")

    calls = mock_model(app, answer)
    assert app.permissions.auto
    assert app.prompt(session, "Inspect")["text"] == "changed approach"
    receipts = {m["tool_call_id"]: m for m in app.store.messages(session) if m["role"] == "tool"}
    assert "unchanged" in receipts["r1"]["content"] and "unchanged" in receipts["r2"]["content"]
    # The second identical step runs, and says so: the third would be refused (Q1, 2026-10-31).
    assert loop.REPEAT_AGAIN in receipts["r2"]["content"] and loop.REPEAT_AGAIN not in receipts["r1"]["content"]
    assert "identical arguments three times in a row" in receipts["r3"]["content"]
    assert len(calls) == 4


def test_the_same_pair_of_calls_in_three_steps_is_handed_back(case):
    # v6: each step read the same two files; the calls alternated, so no single call ran three in a row.
    root, app, session = case
    for name in ("a.txt", "b.txt"):
        (root / name).write_text("unchanged", encoding="utf-8")

    def answer(n, kw):
        if n <= 3:
            return Completion(tool_calls=[ToolCall(f"a{n}", "read", {"filePath": str(root / "a.txt")}),
                                          ToolCall(f"b{n}", "read", {"filePath": str(root / "b.txt")})],
                              finish_reason="tool-calls")
        return Completion(text="changed approach", finish_reason="stop")

    mock_model(app, answer)
    assert app.prompt(session, "Inspect")["text"] == "changed approach"
    receipts = {m["tool_call_id"]: m for m in app.store.messages(session) if m["role"] == "tool"}
    assert "unchanged" in receipts["a3"]["content"] and "unchanged" in receipts["b2"]["content"]
    assert "repeats the previous two steps" in receipts["b3"]["content"]


def test_different_calls_refused_for_the_same_schema_error_are_not_repeats(case):
    # LIT (2026-11-01): three different deliveries failed the same schema check and became one "invalid" call;
    # the third was refused as identical, after a note that said the arguments were the same.
    root, app, session = case

    def answer(n, kw):
        if n <= 3:
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"wrong": f"attempt {n}"})],
                              finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    mock_model(app, answer)
    assert app.prompt(session, "Inspect")["text"] == "done"
    receipts = {m["tool_call_id"]: m["content"] for m in app.store.messages(session) if m["role"] == "tool"}
    assert all("are invalid" in receipts[f"r{n}"] for n in (1, 2, 3))
    assert not any("three times in a row" in receipts[f"r{n}"] or loop.REPEAT_AGAIN in receipts[f"r{n}"]
                   for n in (1, 2, 3))


def test_the_same_invalid_call_three_times_is_refused_under_its_own_name(case):
    root, app, session = case

    def answer(n, kw):
        if n <= 3:
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"wrong": "same"})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    mock_model(app, answer)
    assert app.prompt(session, "Inspect")["text"] == "done"
    receipts = {m["tool_call_id"]: m["content"] for m in app.store.messages(session) if m["role"] == "tool"}
    assert loop.REPEAT_AGAIN in receipts["r2"]
    assert "read was called with identical arguments three times in a row" in receipts["r3"]


def test_rerunning_the_same_check_after_each_edit_is_not_a_loop(case):
    root, app, session = case
    (root / "notes.txt").write_text("v0", encoding="utf-8")

    def answer(n, kw):
        if n <= 3:
            return Completion(tool_calls=[
                ToolCall(f"w{n}", "write", {"filePath": str(root / "notes.txt"), "content": f"v{n}"}),
                ToolCall(f"r{n}", "read", {"filePath": str(root / "notes.txt")})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    mock_model(app, answer)
    assert app.prompt(session, "Iterate")["text"] == "done"
    receipts = {m["tool_call_id"]: m for m in app.store.messages(session) if m["role"] == "tool"}
    assert not any("three times in a row" in receipts[f"r{n}"]["content"] for n in (1, 2, 3))


def test_a_model_that_keeps_repeating_after_refusals_ends_the_turn(case):
    # v9: the refusal came back ~80 times and the model sent the same call again each time.
    root, app, session = case
    (root / "same.txt").write_text("unchanged", encoding="utf-8")

    def answer(n, kw):
        if n <= 5:
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(root / "same.txt")})],
                              finish_reason="tool-calls")
        # The report step offers no tools; a call named anyway is not run.
        return Completion(text="same.txt says unchanged; the cause is not found yet.",
                          tool_calls=[ToolCall("r6", "read", {"filePath": str(root / "same.txt")})],
                          finish_reason="stop")

    calls = mock_model(app, answer)
    result = app.prompt(session, "Inspect")
    assert result["status"] == "repeat_limit" and "no completion is claimed" in result["text"]
    assert len(calls) == 6  # two runs, three refusals, then the report of what was found
    # Q1 (2026-10-31) read for 38 calls and ended with nothing of it: the report comes after the notice.
    assert result["text"].endswith("\n\nsame.txt says unchanged; the cause is not found yet.")
    assert calls[5]["tools"] is None and loop.STOP_REPORT in str(calls[5]["messages"])
    assert not any(m.get("tool_call_id") == "r6" for m in app.store.messages(session))


def test_changing_course_after_a_refusal_keeps_the_turn_going(case):
    root, app, session = case
    (root / "same.txt").write_text("unchanged", encoding="utf-8")
    (root / "other.txt").write_text("other", encoding="utf-8")

    def answer(n, kw):
        name = "other.txt" if n in (4, 8) else "same.txt"
        if n <= 10:
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(root / name)})],
                              finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    mock_model(app, answer)
    assert app.prompt(session, "Inspect")["status"] == "completed"
