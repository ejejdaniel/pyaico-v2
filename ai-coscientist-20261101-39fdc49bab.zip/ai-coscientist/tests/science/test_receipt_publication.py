"""Source -> immutable record -> isolated consumer, without a model or network."""

import json
import os
import re
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from opencode.tools.files import _read
from opencode.tools.types import external_source_names
from opencode.tools import builtin_tools
from researchkit import records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install


class ReceiptPublication(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".git").mkdir()
        env = patch.dict(os.environ, {"OPENCODE_TEST_HOME": str(self.root / "home"),
                                     "OPENCODE_CONFIG_DIR": str(self.root / "config"),
                                     "XDG_CONFIG_HOME": str(self.root / "global-config"),
                                     "XDG_DATA_HOME": str(self.root / "data"),
                                     "XDG_STATE_HOME": str(self.root / "state"),
                                     "XDG_CACHE_HOME": str(self.root / "cache")})
        env.start()
        self.addCleanup(env.stop)
        install(self.workspace)
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.app = App(self.workspace, store=self.store, auto_approve=True, config={})
        self.sid = self.app.create_session()["id"]
        self.ctx = ToolContext(self.app, self.sid, self.app.agents["build"], "m", "c", 0,
                               self.workspace, self.workspace, set(), 1)

    def exchange(self, name="websearch", text="provider reply", sid=None, **fields):
        sid = sid or self.sid
        call = self.store.add_message(sid, "assistant", {"reasoning_content": "PRIVATE_REASONING",
            "tool_calls": [{"id": "c-" + str(len(self.store.messages(sid))), "name": name,
                            "arguments": {"query": "actual question"}}]})
        reply = self.store.add_message(sid, "tool", {"name": name, "content": text,
            "tool_call_id": call["tool_calls"][0]["id"], **fields})
        return call, reply

    def publish(self, text):
        (self.workspace / "synthesis.md").write_text(text, encoding="utf-8")
        tool = next(t for t in TOOLS if t.name == "research_record")
        return json.loads(tool.execute({"kind": "literature", "title": "source handoff",
            "files": ["synthesis.md"], "depends_on": []}, self.ctx).output)

    def test_inline_reference_freezes_complete_call_reply_attachment_after_restart_and_compaction(self):
        text = "long source\n" * 10000 + "EXACT_TAIL"
        call, reply = self.exchange(text=text, attachments=[{"type": "image", "data": "FULL_ATTACHMENT"}])
        self.store.commit_compaction(self.sid, reply["id"], "Wrong old claim: no sources")
        self.store.export_tool_history(self.sid, source_tools=external_source_names([*builtin_tools(), *TOOLS]))
        source = self.store.source_index_path(self.sid).parent
        (source / (reply["id"] + ".json")).write_text("TAMPERED", encoding="utf-8")
        (source / (reply["id"] + ".txt")).unlink()
        reopened = Store(self.store.path)
        self.addCleanup(reopened.close)
        self.app.store = reopened
        saved = self.publish(f"Traceable to `{reply['id']}`.\n")
        self.assertEqual(len(saved["files"]), 3)
        for item in saved["files"]:
            self.assertTrue(Path(item["snapshot"]).is_absolute())
        source_json = next(f for f in saved["files"] if f["source_path"].endswith(".json"))
        frozen = json.loads(Path(source_json["snapshot"]).read_text(encoding="utf-8"))
        self.assertEqual(frozen[0]["tool_calls"], call["tool_calls"])
        self.assertEqual(frozen[-1], reply)
        self.assertNotIn("PRIVATE_REASONING", json.dumps(frozen))
        self.assertNotIn("Wrong old claim", json.dumps(frozen))
        raw = records.read_record(self.workspace, saved["record_path"])
        self.assertEqual(set(raw), {"kind", "title", "files", "depends_on"})
        self.assertTrue(all(not Path(f["snapshot"]).is_absolute() for f in raw["files"]))

        # Only the frozen record travels; the source DB and projections do not.
        isolated = self.root / "consumer"
        target = isolated / Path(saved["record_path"]).parent
        shutil.copytree(self.workspace / Path(saved["record_path"]).parent, target)
        presented = records.present(isolated, {"record_path": saved["record_path"],
                                               **records.read_record(isolated, saved["record_path"])})
        content = next(f for f in presented["files"] if f["source_path"].endswith(".txt"))
        self.assertEqual(Path(content["snapshot"]).read_bytes(), text.encode())
        self.ctx.directory = self.ctx.worktree = isolated
        page = _read({"filePath": content["snapshot"], "limit": 2000}, self.ctx)
        restored = [page.output]
        while continuation := re.search(r"Use offset=(\d+) to continue", page.output):
            page = _read({"filePath": content["snapshot"], "limit": 2000,
                          "offset": int(continuation.group(1))}, self.ctx)
            restored.append(page.output)
        lines = [line for output in restored for line in re.findall(r"^(\d+): (.*)$", output, re.M)]
        self.assertEqual([int(number) for number, _ in lines], list(range(1, 10002)))
        self.assertEqual("\n".join(value for _, value in lines), text)
        self.assertGreater(len(restored), 1)
        self.assertIn("EXACT_TAIL", "".join(restored))
        self.assertFalse((isolated / ".opencode").exists())

    def test_exact_current_session_tool_ids_resolve_without_inferred_sources(self):
        _, source = self.exchange()
        _, local = self.exchange("read", "not an external source")
        other = self.app.create_session()["id"]
        _, foreign = self.exchange(sid=other, text="OTHER_SESSION")
        _, unused = self.exchange(text="unselected source")
        self.store.add_message(self.sid, "tool", {"name": "websearch", "content": "ORPHAN_REPLY"})
        text = (f"`{source['id']}`\n`{source['id']}`\n`{local['id']}`\n"
                f"```\n{unused['id']}\n```\n`prefix {unused['id']}`\n"
                "https://example.org\nDOI 10.0000/not-inferred\n")
        saved = self.publish(text)
        self.assertEqual(len(saved["files"]), 5)
        combined = "\n".join(Path(f["snapshot"]).read_text(encoding="utf-8") for f in saved["files"][1:])
        self.assertNotIn("OTHER_SESSION", combined)
        self.assertNotIn("unselected source", combined)
        self.assertNotIn("ORPHAN_REPLY", combined)
        self.assertIn("not an external source", combined)
        # Approved A6: an explicit unresolved ID must not silently disappear.
        before = records.inventory(self.workspace)
        for unresolved in (foreign["id"], "msg_missing"):
            with self.subTest(reference=unresolved), self.assertRaises(ValueError):
                self.publish(f"`{unresolved}`")
            self.assertEqual(records.inventory(self.workspace), before)

    def test_read_permission_denial_prevents_publication(self):
        _, source = self.exchange()
        from researchkit import tools
        actual = tools.ensure_access
        def authorized(ctx, path, permission):
            if ".opencode/sources/" in path.as_posix():
                raise PermissionError("source read denied")
            return actual(ctx, path, permission)
        with patch.object(tools, "ensure_access", side_effect=authorized):
            with self.assertRaisesRegex(PermissionError, "source read denied"):
                self.publish(f"`{source['id']}`")
        self.assertEqual(records.inventory(self.workspace), [])

    def test_old_records_and_calculations_unchanged_new_record_read_paths_and_hash_validation(self):
        _, source = self.exchange(text="reply with\nexact newline")
        (self.workspace / "synthesis.md").write_text(f"`{source['id']}`", encoding="utf-8")
        (self.workspace / "values.json").write_text('{"sample": 2.3}', encoding="utf-8")
        old = records.publish(self.workspace, kind="literature", title="old", files=["synthesis.md"], depends_on=[])
        numeric = records.publish(self.workspace, kind="implementation", title="calculation", files=["values.json"], depends_on=[])
        baseline = {p: p.read_bytes() for p in (self.workspace / ".research/records").rglob("*") if p.is_file()}
        self.store.export_tool_history(self.sid, source_tools=external_source_names([*builtin_tools(), *TOOLS]))
        saved = self.publish(f"`{source['id']}`")
        self.assertEqual(baseline, {p: p.read_bytes() for p in baseline})
        self.assertNotEqual(saved["record_path"], old["record_path"])
        self.assertEqual(records.workspace_differences(self.workspace, [saved["record_path"]]), [])
        tool = next(t for t in TOOLS if t.name == "research_list")
        listed = json.loads(tool.execute({}, self.ctx).output)
        self.assertEqual(len(listed), 3)
        for record in listed:
            for item in record["files"]:
                self.assertTrue(Path(item["snapshot"]).is_file())
        self.assertEqual(records.read_record(self.workspace, numeric["record_path"])["files"], numeric["files"])
        Path(saved["files"][1]["snapshot"]).write_text("TAMPERED", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
            records.read_record(self.workspace, saved["record_path"])


if __name__ == "__main__":
    unittest.main()
