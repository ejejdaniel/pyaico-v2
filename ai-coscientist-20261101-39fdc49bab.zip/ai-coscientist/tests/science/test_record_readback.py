"""Publication verifies stored bytes and exact dependencies, not model claims."""

import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from researchkit import records


class RecordReadback(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()

    def file(self, name, content):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def publish(self, name="source.txt", dependencies=(), **kwargs):
        return records.publish(self.root, kind="notes", title=name, files=[name],
                               depends_on=list(dependencies), **kwargs)

    def snapshot(self, saved):
        return self.root / Path(saved["record_path"]).parent / saved["files"][0]["snapshot"]

    def test_silent_short_write_is_detected_before_record_is_exposed(self):
        original = b"begin\n" + b"body\n" * 30000 + b"REQUIRED_TAIL"
        source = self.file("source.txt", original)
        write = Path.write_bytes

        def short_write(path, data):
            if any(p.startswith(".staging-") for p in path.parts) and path.name == "source.txt":
                return write(path, data[:-len(b"REQUIRED_TAIL")])
            return write(path, data)

        with patch.object(Path, "write_bytes", short_write):
            with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
                self.publish()
        self.assertEqual(source.read_bytes(), original)
        self.assertEqual(list((self.root / ".research/records").iterdir()), [])

    def test_manifest_write_corruption_is_detected_before_record_is_exposed(self):
        self.file("source.txt", b"original")
        write = Path.write_bytes

        def corrupt_manifest(path, data):
            if path.name == "record.json" and any(p.startswith(".staging-") for p in path.parts):
                data += b" "
            return write(path, data)

        with patch.object(Path, "write_bytes", corrupt_manifest):
            with self.assertRaisesRegex(ValueError, "Record content has changed"):
                self.publish()
        self.assertEqual(list((self.root / ".research/records").iterdir()), [])

    def test_post_commit_failure_never_returns_success_or_silently_replaces_record(self):
        self.file("source.txt", b"complete value")
        rename = Path.rename

        def damage_after_commit(path, target):
            result = rename(path, target)
            (target / "files/source.txt").write_bytes(b"damaged")
            return result

        with patch.object(Path, "rename", damage_after_commit):
            with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
                self.publish()
        snapshots = list((self.root / ".research/records").glob("*/files/source.txt"))
        self.assertEqual(len(snapshots), 1)
        with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
            self.publish()
        self.assertEqual(snapshots[0].read_bytes(), b"damaged")

    def test_indirect_corrupt_or_missing_source_prevents_downstream_publication(self):
        self.file("source.txt", b"original")
        source = self.publish()
        self.file("literature.md", b"interpretation")
        literature = self.publish("literature.md", [source["record_path"]])
        self.file("report.md", b"downstream result")
        source_file = self.snapshot(source)
        for failure in ("changed", "missing"):
            with self.subTest(failure=failure):
                if failure == "changed":
                    source_file.write_bytes(b"tampered")
                else:
                    source_file.unlink()
                with self.assertRaises((ValueError, FileNotFoundError)):
                    self.publish("report.md", [literature["record_path"]])
                self.assertEqual(len(list((self.root / ".research/records").glob("*/record.json"))), 2)
        self.assertEqual(records.read_record(self.root, literature["record_path"])["depends_on"],
                         [source["record_path"]])

    def test_dependency_is_rechecked_after_publication_not_reused_from_precheck(self):
        self.file("source.txt", b"original")
        source = self.publish()
        self.file("report.md", b"interpretation")
        rename = Path.rename

        def change_dependency(path, target):
            result = rename(path, target)
            self.snapshot(source).write_bytes(b"changed during publication")
            return result

        with patch.object(Path, "rename", change_dependency):
            with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
                self.publish("report.md", [source["record_path"]])
        self.assertEqual(len(list((self.root / ".research/records").glob("*/record.json"))), 2)

    def test_exact_old_dependency_is_retained_when_working_source_has_changed_or_gone(self):
        working = self.file("source.txt", b"version one")
        old = self.publish()
        working.write_bytes(b"version two")
        new = self.publish()
        working.unlink()
        self.file("report.md", b"uses the selected version one")
        old_bytes = (self.root / old["record_path"]).read_bytes()
        saved = self.publish("report.md", [old["record_path"]])
        self.assertEqual(saved["depends_on"], [old["record_path"]])
        self.assertNotIn(new["record_path"], saved["depends_on"])
        self.assertEqual((self.root / old["record_path"]).read_bytes(), old_bytes)
        self.assertEqual(self.snapshot(old).read_bytes(), b"version one")
        self.assertEqual(self.publish("report.md", [old["record_path"]]), saved)
        self.assertEqual(set(saved), {"record_path", "kind", "title", "files", "depends_on"})

    def test_indirect_snapshot_permission_is_checked_before_its_bytes_are_read(self):
        self.file("source.txt", b"private source")
        source = self.publish()
        self.file("literature.md", b"interpretation")
        literature = self.publish("literature.md", [source["record_path"]])
        self.file("report.md", b"result")
        forbidden = self.snapshot(source)
        reads = []
        read = Path.read_bytes

        def observe(path):
            reads.append(path)
            return read(path)

        def authorize(path):
            if path == forbidden:
                raise PermissionError("snapshot read denied")

        with patch.object(Path, "read_bytes", observe):
            with self.assertRaisesRegex(PermissionError, "snapshot read denied"):
                self.publish("report.md", [literature["record_path"]], check_read=authorize)
        self.assertNotIn(forbidden, reads)
        self.assertEqual(len(list((self.root / ".research/records").glob("*/record.json"))), 2)

    def test_shared_dependency_is_read_once_per_validation_pass(self):
        self.file("source.txt", b"shared source")
        source = self.publish()
        parents = []
        for name in ("left.md", "right.md"):
            self.file(name, b"interpretation")
            parents.append(self.publish(name, [source["record_path"]])["record_path"])
        self.file("report.md", b"result")
        watched = self.snapshot(source)
        read = Path.read_bytes
        reads = []

        def observe(path):
            if path == watched:
                reads.append(path)
            return read(path)

        with patch.object(Path, "read_bytes", observe):
            saved = self.publish("report.md", parents)
        self.assertEqual(saved["depends_on"], parents)
        self.assertEqual(len(reads), 2)  # Before writing and after commit, not once per DAG path.

    def test_existing_byte_count_is_verified_without_new_manifest_fields(self):
        self.file("source.txt", b"complete")
        saved = self.publish()
        manifest = records.read_record(self.root, saved["record_path"])
        manifest["files"][0]["bytes"] += 1
        raw = records.encoded(manifest)
        folder = self.root / ".research/records" / records.digest(raw)
        (folder / "files").mkdir(parents=True)
        (folder / "files/source.txt").write_bytes(b"complete")
        (folder / "record.json").write_bytes(raw)
        with self.assertRaisesRegex(ValueError, "Recorded file byte count"):
            records.read_record(self.root, (folder / "record.json").relative_to(self.root).as_posix())

    def test_success_comes_from_final_disk_readback_not_the_in_memory_manifest(self):
        self.file("source.txt", b"complete")
        original = records.read_record
        observed = []

        def readback(root, ref, **kwargs):
            observed.append(ref)
            return original(root, ref, **kwargs)

        with patch.object(records, "read_record", side_effect=readback):
            saved = self.publish()
        self.assertEqual(observed, [saved["record_path"]])
        self.assertEqual({k: v for k, v in saved.items() if k != "record_path"},
                         json.loads((self.root / saved["record_path"]).read_bytes()))

    def test_concurrent_existing_target_is_verified_before_reuse(self):
        self.file("source.txt", b"complete")
        for damaged in (False, True):
            with self.subTest(damaged=damaged):
                name = "damaged.txt" if damaged else "valid.txt"
                self.file(name, b"concurrent value")

                def raced_rename(path, target):
                    shutil.copytree(path, target)
                    if damaged:
                        (target / "files" / name).write_bytes(b"corrupt concurrent write")
                    raise FileExistsError("another publisher created the destination")

                with patch.object(Path, "rename", raced_rename):
                    if damaged:
                        with self.assertRaisesRegex(ValueError, "Recorded file content has changed"):
                            self.publish(name)
                    else:
                        saved = self.publish(name)
                        self.assertEqual(self.snapshot(saved).read_bytes(), b"concurrent value")
        self.assertFalse(list((self.root / ".research/records").glob(".staging-*")))


if __name__ == "__main__":
    unittest.main()
