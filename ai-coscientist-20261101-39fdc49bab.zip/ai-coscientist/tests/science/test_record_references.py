"""Host help with record references, dependency notices and formula declarations; no model calls."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.compaction import UNATTENDED_CONTINUE_PROMPT
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def tool(ctx, name, args):
    return next(t for t in TOOLS if t.name == name).execute(args, ctx)


def saved(ctx, name, text="x\n"):
    (ctx.directory / name).write_text(text, encoding="utf-8")
    return records.publish(ctx.directory, kind="notes", title=name, files=[name], depends_on=[])["record_path"]


def test_a_garbled_or_short_reference_resolves_to_the_one_record_it_starts_like(ctx):
    ref = saved(ctx, "a.md")
    full = ref.split("/")[2]
    garbled = f".research/records/{full[:12]}{'e1' * 26}/record.json"
    value, notes = records.resolve_references(
        {"depends_on": [garbled], "files": [{"record_ref": full[:8], "source_path": "a.md"}],
         "title": full[:8], "source_path": garbled}, ctx.directory)
    assert value["depends_on"] == [ref] and value["files"][0]["record_ref"] == ref
    assert value["title"] == full[:8]  # not a reference field: left alone
    assert value["source_path"] == ref  # a record.json path anywhere is a reference
    assert len(notes) == 3


def test_existing_ambiguous_or_unmatched_references_are_left_for_the_tool_to_judge(ctx):
    ref = saved(ctx, "a.md")
    folder = ctx.directory / ".research/records"
    twin = folder / (ref.split("/")[2][:10] + "0" * 54)
    twin.mkdir()  # shares the first 10 characters with the saved record
    ambiguous = ref.split("/")[2][:10]
    value, notes = records.resolve_references(
        {"a_ref": ref, "b_ref": ambiguous, "c_ref": "deadbeef", "d_ref": "1234567"}, ctx.directory)
    assert value == {"a_ref": ref, "b_ref": ambiguous, "c_ref": "deadbeef", "d_ref": "1234567"} and notes == []


def test_a_tool_call_with_a_garbled_dependency_saves_the_exact_one_and_says_so(ctx):
    ref = saved(ctx, "a.md")
    (ctx.directory / "b.md").write_text("b\n", encoding="utf-8")
    garbled = f".research/records/{ref.split('/')[2][:8]}{'0f' * 28}/record.json"
    result = tool(ctx, "research_record", {"kind": "notes", "title": "B", "files": ["b.md"],
                                           "depends_on": [garbled]})
    body, _, note = result.output.partition("\n\nHost note: ")
    receipt = json.loads(body)
    assert records.read_record(ctx.directory, receipt["record_path"])["depends_on"] == [ref]
    assert f"{garbled} -> {ref}" in note


def test_the_dependency_notice_lists_a_few_paths_and_points_to_research_list(ctx):
    (ctx.directory / "c.md").write_text("c\n", encoding="utf-8")
    differences = [{"record_path": f"r{i}", "source_path": f"p{i}", "status": "changed",
                    "snapshot_path": f"s{i}", "recorded_sha256": "a", "working_sha256": "b"} for i in range(8)]

    def fake(root, refs, paths=None, check_read=None):
        paths.extend(f"notes (r{i}) -> file{i}" for i in range(8))
        return differences

    with patch.object(records, "workspace_differences", side_effect=fake):
        receipt = json.loads(tool(ctx, "research_record", {"kind": "notes", "title": "C", "files": ["c.md"]}).output)
    assert receipt["workspace_differences"] == [{"record_path": f"r{i}", "source_path": f"p{i}", "status": "changed"}
                                             for i in range(5)]
    assert receipt["workspace_differences_total"] == 8
    assert "first 5 of 8" in receipt["dependency_notice"] and "3 more." in receipt["dependency_notice"]
    assert "research_list shows each record's workspace_differences in full" in receipt["dependency_notice"]
    assert "file4" in receipt["dependency_notice"] and "file5" not in receipt["dependency_notice"]


@pytest.mark.parametrize("change, message", [
    ({"measured": "EOP_mJ"}, "measured must be an object"),
    ({"anchor": -0.3158}, "do not write the number"),
    ({"anchor": "mean_offset -0.3158"}, "do not write the number"),
    ({"target_value": None}, "numeric target_value"),
    ({"direction": "closer"}, "direction must be one of"),
    # v23 left direction out twice, taking kpi.better for it; the history check refused it only later.
    ({"direction": None}, "direction is required: higher or lower .* kpi.better says which values of the measured KPI"),
])
def test_a_misshapen_formula_declaration_is_refused_when_saved(ctx, change, message):
    data = saved(ctx, "measured.json", '{"h1": {"EOP_mJ": 53.7}}')
    template = {"formula_id": "P1", "expression": "EOP", "hypothesis_ids": ["H1"], "direction": "target",
                "target_value": 40.0,
                "measured": {"record_ref": data, "source_path": "measured.json", "column": "EOP_mJ"}}
    template.update(change)
    with pytest.raises(ValueError, match=message):
        tool(ctx, "research_record", {"kind": "proxy_formula", "title": "P1", "template": template})
    if change.get("anchor") == -0.3158:  # the same declaration with the literal anchor is accepted
        template["anchor"] = "mean_offset"
        assert "record_path" in tool(ctx, "research_record", {"kind": "proxy_formula", "title": "P1",
                                                              "template": template}).output


@pytest.mark.parametrize("kpi, message", [
    ({"source_path": "prepared.csv", "column": "EOP"}, "kpi cannot be read: Column 'EOP' is not in prepared.csv"),
    ({"source_path": "notes.md"}, "kpi cannot be read: The kpi file notes.md is not JSON"),
    ({"source_path": "missing.csv", "column": "EOP_mJ"}, "kpi cannot be read: source_path must exactly select"),
])
def test_a_kpi_the_ranking_tools_cannot_read_is_refused_before_the_formula_is_saved(ctx, kpi, message):
    # v21 pointed kpi at the prepared CSV and learned only at research_history_check that it could not be read.
    (ctx.directory / "prepared.csv").write_text("sample,EOP_mJ\nh1,53.7\nh2,47.9\n", encoding="utf-8")
    (ctx.directory / "notes.md").write_text("EOP is lower for h2\n", encoding="utf-8")
    data = records.publish(ctx.directory, kind="prepared_data", title="data", files=["prepared.csv", "notes.md"],
                           depends_on=[])["record_path"]
    template = {"formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "lower",
                "mechanism_predicts": "kpi_rises", "kpi": {"record_ref": data, **kpi, "better": "lower"}}
    with pytest.raises(ValueError, match=message):
        tool(ctx, "research_record", {"kind": "proxy_formula", "title": "P1", "template": template})
    assert "the formula was not saved" in str(pytest.raises(ValueError, tool, ctx, "research_record", {
        "kind": "proxy_formula", "title": "P1", "template": template}).value)
    template["kpi"] = {"record_ref": data, "source_path": "prepared.csv", "column": "EOP_mJ", "better": "lower"}
    receipt = json.loads(tool(ctx, "research_record", {"kind": "proxy_formula", "title": "P1",
                                                       "template": template}).output)
    # v32's predictions used other IDs than its KPI file; the receipt now names the file's IDs up front.
    assert "Its kpi reads values for h1, h2: key the historical samples' rows" in receipt["history_check_hint"]


def test_the_unattended_continue_prompt_lets_delivered_work_finish_after_one_check():
    assert "already delivered" in UNATTENDED_CONTINUE_PROMPT and "give your final answer" in UNATTENDED_CONTINUE_PROMPT
    assert "once" in UNATTENDED_CONTINUE_PROMPT


@pytest.mark.parametrize("kind", ["mindmap", "mindmap_checkpoint"])
def test_a_mind_map_is_made_by_research_mindmap_not_saved_by_hand(ctx, kind):
    # v35 wrote its mind map with its own script and saved it with research_record, skipping the tool's checks.
    (ctx.directory / "map.json").write_text("{}", encoding="utf-8")
    with pytest.raises(ValueError, match=f"kind {kind} is the research route landscape that research_mindmap builds"
                                         ".*A mind map for another purpose .* is an ordinary file"):
        tool(ctx, "research_record", {"kind": kind, "title": "map", "files": ["map.json"]})
    assert not (ctx.directory / ".research" / "records").exists() or not any(
        (ctx.directory / ".research" / "records").glob("*/record.json"))


def test_a_formula_that_predicts_the_kpi_cannot_declare_that_the_kpi_falls_as_it_rises(ctx):
    # v41's P1 predicted EOP itself (measured and kpi on one column) and declared kpi_falls; its expression rose
    # with the deprotection rate its rationale said lowers EOP, and nothing compared the two.
    data = saved(ctx, "measured.json", '{"h1": {"EOP_mJ": 53.7}, "h2": {"EOP_mJ": 47.9}}')
    copy = saved(ctx, "copy.json", '{"h1": {"dose": 53.7}, "h2": {"dose": 47.9}}')
    other = saved(ctx, "other.json", '{"h1": {"angle": 71.0}, "h2": {"angle": 64.0}}')
    selection = {"record_ref": data, "source_path": "measured.json", "column": "EOP_mJ"}
    template = {"formula_id": "P1", "expression": "EOP", "hypothesis_ids": ["H1"], "direction": "target",
                "target_value": 40.0, "mechanism_predicts": "kpi_falls", "measured": selection,
                "kpi": {**selection, "better": "target", "target_value": 40.0}}

    def save():
        return tool(ctx, "research_record", {"kind": "proxy_formula", "title": "P1", "template": template})

    # Measured and kpi on one column: refused before anything is read, saying to leave the field out.
    with pytest.raises(ValueError, match="leave out mechanism_predicts.*minus sign") as refused:
        save()
    # v42's P1 was an index, 1/Q_eff: the second way out keeps its kpi_falls and drops measured.
    assert ("If it is instead an index whose rise lowers the KPI, it does not predict the KPI: keep kpi_falls and "
            "leave out measured") in str(refused.value)
    # The same values from another file are the same quantity.
    template["measured"] = {"record_ref": copy, "source_path": "copy.json", "column": "dose"}
    with pytest.raises(ValueError, match="contradicts measured"):
        save()
    # A formula may predict another measured quantity that falls as the KPI rises.
    template["measured"] = {"record_ref": other, "source_path": "other.json", "column": "angle"}
    assert "record_path" in save().output
    template["measured"], template["mechanism_predicts"] = selection, "kpi_rises"
    assert "record_path" in save().output
