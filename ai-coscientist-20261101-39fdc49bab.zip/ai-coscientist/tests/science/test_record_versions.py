"""Record versions: research_record revises, and a board that shows only current versions; no model calls."""

from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import board, records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def hypotheses(count, deferred=(), statement="mechanism {}"):
    return {"hypotheses": [{"id": f"H{i}", "statement": statement.format(i),
                            **({"proxy_status": {"status": "deferred", "basis": "budget", "reason": "later"}}
                               if i in deferred else {})}
                           for i in range(1, count + 1)]}


def formula(fid, hypothesis_id, direction="higher", expression="x"):
    return {"proxy_formula.json": {"formula_id": fid, "expression": expression, "hypothesis_ids": [hypothesis_id],
                                   "direction": direction}}


def texts(root):
    return [item["text"] for item in board.build(root)["notice_items"]]


def test_a_revised_hypothesis_set_replaces_the_old_one_on_the_board(tmp_path):
    first = save(tmp_path, "hypothesis", {"h1/hypotheses.json": hypotheses(9)})
    second = save(tmp_path, "hypothesis", {"h2/hypotheses.json": hypotheses(9, deferred=range(4, 10))}, [first])
    found = texts(tmp_path)
    old, new = first["record_path"].split("/")[2][:8], second["record_path"].split("/")[2][:8]
    assert not any(old in t for t in found)  # no budget or uncovered notice for the replaced version
    assert any(new in t and "沒有對應公式" in t for t in found)
    value = board.build(tmp_path)
    assert value["hypotheses"][[r["ref"] for r in value["hypotheses"]].index(first["record_path"])][
        "superseded_by"] == [second["record_path"]]
    rendered = board.render(value)
    assert rendered.index("現行版本") < rendered.index("委託與任務")
    assert f"假說紀錄 {new}：主動 3、排隊 6、無法計算 0" in rendered
    assert f"hypothesis {old}" not in rendered and "假說紀錄 1、公式 0" in rendered


def test_a_record_that_only_adds_hypotheses_leaves_the_earlier_set_current(tmp_path):
    first = save(tmp_path, "hypothesis", {"h1/hypotheses.json": hypotheses(2)})
    added = save(tmp_path, "hypothesis", {"h2/hypotheses.json": {"hypotheses": [
        {"id": "H3", "statement": "a new mechanism"}]}}, [first])
    rows = {row["ref"]: row for row in board.build(tmp_path)["hypotheses"]}
    assert rows[first["record_path"]]["superseded_by"] == [] and rows[added["record_path"]]["superseded_by"] == []


def test_a_formula_built_for_a_hypothesis_still_covers_it_after_the_set_is_revised(tmp_path):
    first = save(tmp_path, "hypothesis", {"h1/hypotheses.json": hypotheses(2)})
    save(tmp_path, "proxy_formula", formula("P1", "H1"), [first])
    save(tmp_path, "proxy_formula", formula("P2", "H2"), [first])
    same = save(tmp_path, "hypothesis", {"h2/hypotheses.json": hypotheses(2)}, [first])
    assert not any("沒有對應公式" in t or "改寫了" in t for t in texts(tmp_path))
    # A reworded statement keeps the formula and says so (v23 lost H3's formula over a comma).
    changed = save(tmp_path, "hypothesis", {"h3/hypotheses.json": hypotheses(2, statement="revised {}")}, [same])
    assert not any("沒有對應公式" in t for t in texts(tmp_path))
    short = changed["record_path"].split("/")[2][:8]
    assert {t for t in texts(tmp_path) if "改寫了" in t} == {
        f"hypothesis {short} 改寫了 H{n} 的敘述，沿用為舊版敘述建立的公式 P{n}。公式仍對應新敘述就不必處理；"
        "不再對應時，另存修訂版公式（revises 指向舊公式）。" for n in (1, 2)}


def test_a_formula_revision_with_the_same_id_replaces_the_old_one_and_its_notices(tmp_path):
    h = save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses(1)})
    old = save(tmp_path, "proxy_formula", formula("P1", "H1", "lower", "-abs(x - 3)"), [h])
    assert any("-abs(...)" in t for t in texts(tmp_path))
    new = save(tmp_path, "proxy_formula", formula("P1", "H1", "higher", "-abs(x - 3)"), [h, old])
    other = save(tmp_path, "proxy_formula", formula("P9", "H1"), [new])  # builds on P1, is not a version of it
    assert not any("-abs(...)" in t for t in texts(tmp_path))
    rows = {row["ref"]: row for row in board.build(tmp_path)["proxy_formulas"]}
    assert rows[old["record_path"]]["superseded_by"] == [new["record_path"]]
    assert rows[new["record_path"]]["superseded_by"] == [] and rows[other["record_path"]]["superseded_by"] == []
    rendered = board.render(board.build(tmp_path))
    assert f"proxy_formula {old['record_path'].split('/')[2][:8]}" not in rendered
    assert "P1（H1），方向 higher" in rendered and "公式 1" in rendered


def test_two_revisions_of_one_formula_are_both_current_and_flagged_as_a_fork(tmp_path):
    h = save(tmp_path, "hypothesis", {"h/hypotheses.json": hypotheses(1)})
    root = save(tmp_path, "proxy_formula", formula("P1", "H1"), [h])
    left = save(tmp_path, "proxy_formula", formula("P1", "H1", expression="x + 1"), [root])
    right = save(tmp_path, "proxy_formula", formula("P1", "H1", expression="x + 2"), [root])
    fork = [t for t in texts(tmp_path) if "份現行版本" in t]
    assert len(fork) == 1 and "P1 有 2 份現行版本" in fork[0]
    save(tmp_path, "proxy_formula", formula("P1", "H1", expression="x + 3"), [left, right])
    assert not any("份現行版本" in t for t in texts(tmp_path))
    assert sum(not row["superseded_by"] for row in board.build(tmp_path)["proxy_formulas"]) == 1


def test_the_newest_delivery_is_named_by_save_time_not_by_hash(tmp_path):
    reports = [save(tmp_path, "report", {f"r{i}/report.md": f"report {i}\n"}) for i in range(3)]
    reports.sort(key=lambda ref: ref["record_path"], reverse=True)  # saved in the reverse of hash order
    for seconds, ref in enumerate(reports, 1_700_000_000):
        os.utime(tmp_path / ref["record_path"], (seconds, seconds))
    value = board.build(tmp_path)
    assert value["deliveries"]["report"] == [r["record_path"] for r in reports]
    newest = reports[-1]["record_path"].split("/")[2][:8]
    assert f"report {newest}（共 3 份）；final_lca 無；user_report 無" in board.render(value)
    assert any(f"最新 {newest}" in t for t in texts(tmp_path))


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def record(ctx, args):
    return json.loads(next(t for t in TOOLS if t.name == "research_record").execute(args, ctx).output.split("\n\nHost note")[0])


def test_revises_adds_the_dependency_and_accepts_a_hash_prefix(ctx):
    first = record(ctx, {"kind": "hypothesis", "title": "v1", "template": hypotheses(4)})
    prefix = first["record_path"].split("/")[2][:10]
    second = record(ctx, {"kind": "hypothesis", "title": "v2", "template": hypotheses(4, deferred=[4]),
                          "revises": prefix})
    assert second["depends_on"] == [first["record_path"]] and second["revises"] == first["record_path"]
    assert "current version" in second["revision_notice"]


def test_revises_refuses_a_hypotheses_set_that_drops_an_earlier_id(ctx):
    first = record(ctx, {"kind": "hypothesis", "title": "v1", "template": hypotheses(3)})
    with pytest.raises(ValueError, match="H3 is missing.*deferred or not_computable"):
        record(ctx, {"kind": "hypothesis", "title": "v2", "template": hypotheses(2),
                     "revises": first["record_path"]})


def test_revises_refuses_another_kind_or_another_formula_id(ctx):
    h = record(ctx, {"kind": "hypothesis", "title": "h", "template": hypotheses(1)})
    p1 = record(ctx, {"kind": "proxy_formula", "title": "P1", "depends_on": [h["record_path"]],
                      "template": formula("P1", "H1")["proxy_formula.json"]})
    with pytest.raises(ValueError, match="same kind|list it in depends_on"):
        record(ctx, {"kind": "proxy_formula", "title": "P1b", "revises": h["record_path"],
                     "template": formula("P1", "H1")["proxy_formula.json"]})
    with pytest.raises(ValueError, match="Keep formula_id 'P1'"):
        record(ctx, {"kind": "proxy_formula", "title": "P2", "revises": p1["record_path"],
                     "template": formula("P2", "H1")["proxy_formula.json"]})
    revised = record(ctx, {"kind": "proxy_formula", "title": "P1 v2", "revises": p1["record_path"],
                           "depends_on": [h["record_path"]], "template": formula("P1", "H1", "lower")["proxy_formula.json"]})
    assert revised["depends_on"] == [h["record_path"], p1["record_path"]]
