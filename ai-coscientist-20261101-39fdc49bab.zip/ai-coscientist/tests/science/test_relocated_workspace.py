"""Upstream file paths stay literal after a session directory changes."""

import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from opencode.app import App
from opencode.loop import ToolContext, _present_history, _relocate
from opencode.provider import Completion
from opencode.store import Store
from opencode.tools.files import _read
from opencode.tools.util import relocate_text
from types import SimpleNamespace


class RelocatedWorkspaceTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.old = self.root / "old-workspace"
        self.new = self.root / "new-workspace"
        for folder in (self.old, self.new):
            (folder / "report").mkdir(parents=True)
            (folder / ".git").mkdir()
        (self.old / "report" / "value.txt").write_text("OLD", encoding="utf-8")
        (self.new / "report" / "value.txt").write_text("NEW", encoding="utf-8")
        env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"),
            "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_CONFIG_HOME": str(self.root / "global-config"),
            "XDG_DATA_HOME": str(self.root / "data"),
            "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        env.start()
        self.addCleanup(env.stop)
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.app = App(self.old, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]
        self.app.directory = self.new
        self.app.worktree = self.new
        self.store.update_session(self.sid, directory=str(self.new))

    def context(self):
        return ToolContext(self.app, self.sid, self.app.agents["build"], "m", "c", 0,
                           self.new, self.new, set(), 1)

    def test_directory_move_does_not_invent_history_or_rewrite_messages(self):
        original = str(self.old / "report" / "value.txt")
        saved = self.store.add_message(self.sid, "assistant", {
            "content": f"Deliver {original}",
            "tool_calls": [{"id": "read-old", "name": "read", "arguments": {"filePath": original}}],
        })
        meta = self.store.get_session(self.sid)["meta"]
        self.assertNotIn("former_directories", meta)
        # Existing historical metadata remains readable; changing directories
        # does not create or extend it.
        self.store.update_session(self.sid, meta={**meta, "turn": 3, "former_directories": ["legacy"]})
        self.store.update_session(self.sid, directory=str(self.old))
        self.assertEqual(self.store.get_session(self.sid)["meta"]["turn"], 3)
        self.assertEqual(self.store.get_session(self.sid)["meta"]["former_directories"], ["legacy"])
        self.assertEqual(self.store.messages(self.sid)[-1]["content"], saved["content"])

    def test_explicit_former_path_is_read_literally(self):
        original = str(self.old / "report" / "value.txt")
        result = _read({"filePath": original}, self.context())
        # read.ts resolves relative paths; it never substitutes historical roots.
        self.assertIn("OLD", result.output)
        self.assertNotIn("NEW", result.output)
        self.assertEqual((self.old / "report" / "value.txt").read_text(encoding="utf-8"), "OLD")
        self.assertIn(str(self.old), result.output)

    def test_relative_path_uses_current_directory_without_former_fallback(self):
        only_old = self.old / "report" / "only-old.txt"
        only_old.write_text("SECRET", encoding="utf-8")
        with self.assertRaises(FileNotFoundError) as raised:
            _read({"filePath": "report/only-old.txt"}, self.context())
        self.assertIn(str(self.new), str(raised.exception))
        self.assertNotIn("SECRET", str(raised.exception))
        self.assertEqual(only_old.read_text(encoding="utf-8"), "SECRET")

    def test_presented_history_keeps_original_paths_and_arguments(self):
        original = str(self.old / "report" / "value.txt")
        message = self.store.add_message(self.sid, "assistant", {
            "content": original,
            "tool_calls": [{"id": "c", "name": "bash", "arguments": {"command": f'Get-Content "{original}"'}}],
        })
        presented = _relocate(self.app, self.sid, _present_history(self.store.messages(self.sid), self.store, self.sid))
        shown = next(item for item in presented if item["id"] == message["id"])
        # message-v2.ts projects saved message content without path rewriting.
        self.assertEqual(shown["content"], original)
        self.assertIn(str(self.old), shown["tool_calls"][0]["arguments"]["command"])
        self.assertNotIn(str(self.new), shown["tool_calls"][0]["arguments"]["command"])
        self.assertEqual(self.store.messages(self.sid)[-1]["tool_calls"][0]["arguments"]["command"], f'Get-Content "{original}"')

    def test_shell_text_replacement_stops_at_a_longer_directory_name(self):
        formers = [self.old]
        command = relocate_text(f'echo {self.old}-backup', self.new, formers)
        self.assertIn(f"{self.old}-backup", command)
        self.assertNotIn(str(self.new), command.replace(str(self.old), ""))

    def test_model_call_keeps_the_former_path_as_saved(self):
        original = str(self.old / "report" / "value.txt")
        self.store.add_message(self.sid, "assistant", {"content": f"Saved at {original}"})
        captured = []
        self.app.provider = SimpleNamespace(
            resolve=lambda _model: (SimpleNamespace(id="test", context=131072), "test"),
            complete=lambda **kwargs: captured.append(kwargs) or Completion(text="done", finish_reason='stop'),
        )
        self.app.prompt(self.sid, "Continue")
        wire = captured[0]["messages"]
        self.assertTrue(any(original in (message.get("content") or "") for message in wire))
        self.assertFalse(any(str(self.new) in (message.get("content") or "") for message in wire))
        self.assertIn(original, self.store.messages(self.sid)[0]["content"])
