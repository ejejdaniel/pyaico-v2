"""Evidence projection tests; scientific interpretation remains with the author."""

from html.parser import HTMLParser
from pathlib import Path
import hashlib
import tempfile
import unittest

import pymupdf

from researchkit.report import render


class RawEvidence(HTMLParser):
    def __init__(self):
        super().__init__()
        self.raw = []
        self.ids = []
        self.links = []
        self.tags = []
        self.evidence_ids = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if tag in ("article", "li") and {"evidence", "evidence-ref"} & set(attrs.get("class", "").split()):
            self.evidence_ids.append(attrs.get("id"))
        if tag == "a":
            self.links.append(attrs.get("href", ""))
        if tag == "pre":
            self.current = []

    def handle_data(self, data):
        if self.current is not None:
            self.current.append(data)

    def handle_endtag(self, tag):
        if tag == "pre" and self.current is not None:
            self.raw.append("".join(self.current))
            self.current = None


class ReportAppendix(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def evidence(self, text, name="source.py"):
        raw = text.encode("utf-8")
        return {
            "record_ref": ".research/records/" + "a" * 64 + "/record.json",
            "source_path": name,
            "kind": "implementation", "title": "Explicit source <version 1>",
            "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "text": text,
        }

    def render(self, source, entries, *, report=False):
        """(receipt, HTML, parsed HTML) of the separate evidence file, or of the report when asked."""
        path = self.root / "report.md"
        path.write_text(source, encoding="utf-8")
        result = render(path, self.root / "rendered", evidence=entries)
        key = "html_path" if report or not entries else "evidence_html_path"
        document = Path(result[key]).read_bytes().decode("utf-8")
        parsed = RawEvidence()
        parsed.feed(document)
        return result, document, parsed

    def test_the_report_keeps_an_index_and_the_originals_go_to_a_separate_file(self):
        entries = [self.evidence("ORIGINAL_ONLY_IN_EVIDENCE_FILE\n")]
        result, report, parsed = self.render("## 摘要\n\nBrief.[1](#evidence-1)\n", entries, report=True)
        self.assertEqual(parsed.raw, [])
        self.assertIn("evidence.html#evidence-1", parsed.links)
        self.assertIn(entries[0]["sha256"], report)
        with pymupdf.open(result["pdf_path"]) as pdf:
            self.assertNotIn("ORIGINAL_ONLY_IN_EVIDENCE_FILE", "".join(page.get_text() for page in pdf))
        with pymupdf.open(result["evidence_pdf_path"]) as pdf:
            self.assertIn("ORIGINAL_ONLY_IN_EVIDENCE_FILE", "".join(page.get_text() for page in pdf))

    def test_complete_literal_text_in_order_and_escaped_markup(self):
        entries = [
            self.evidence("if a < b:\n    print('&value')\n<script>DO_NOT_EXECUTE</script>\n"),
            self.evidence("# 第二份\n\n機制名稱保持原文。\n", "mechanisms.md"),
        ]
        result, document, parsed = self.render("# A bounded report\n\nNo scientific verdict.\n", entries)
        self.assertEqual(parsed.raw, [item["text"] for item in entries])
        self.assertEqual(parsed.tags.count("script"), 0)  # the evidence page has no script; evidence is escaped.
        for item in entries:
            self.assertIn(item["sha256"], document)
            self.assertIn(item["record_ref"], document)
        self.assertEqual(set(result), {"html_path", "pdf_path", "pages", "renderer", "note", "layout", "layout_note",
                                       "style", "citations", "evidence_html_path", "evidence_pdf_path", "evidence_pages"})
        self.assertIn("explicitly selected", result["note"])
        with pymupdf.open(result["evidence_pdf_path"]) as pdf:
            content = "".join(page.get_text() for page in pdf)
            self.assertIn("DO_NOT_EXECUTE", content)
            self.assertIn("機制名稱保持原文", content)
            self.assertLess(content.index("DO_NOT_EXECUTE"), content.index("機制名稱保持原文"))

    def test_appendix_links_resolve_once_even_with_authored_id_collisions(self):
        _, _, parsed = self.render(
            '## evidence-1\n\n### section-0\n',
            [self.evidence("Saved text")], report=True,
        )
        self.assertEqual(len(parsed.ids), len(set(parsed.ids)))
        self.assertIn("evidence-1", parsed.ids)
        self.assertEqual(len(parsed.evidence_ids), 1)
        self.assertNotEqual(parsed.evidence_ids[0], "evidence-1")
        for href in parsed.links:
            if href.startswith("#"):
                self.assertEqual(parsed.ids.count(href[1:]), 1)

    def test_pdf_contains_all_lines_beyond_collapsed_browser_view(self):
        raw = "\n".join(f"ROW_{i:04d}: value_{i:04d}" for i in range(220)) + "\nFINAL_EVIDENCE_LINE\n"
        result, _, parsed = self.render("Brief scope.\n", [self.evidence(raw)])
        self.assertEqual(parsed.raw, [raw])
        with pymupdf.open(result["evidence_pdf_path"]) as pdf:
            self.assertGreater(len(pdf), 2)
            content = "\n".join(page.get_text() for page in pdf)
            self.assertIn("FINAL_EVIDENCE_LINE", content)
            for i in range(220):
                self.assertEqual(content.count(f"ROW_{i:04d}"), 1)
            for page in pdf:
                for word in page.get_text("words"):
                    self.assertLessEqual(word[2], page.rect.width)
                    self.assertLessEqual(word[3], page.rect.height)

    def test_empty_selection_leaves_document_without_evidence_section(self):
        result, _, parsed = self.render("Only the commissioned short answer.\n", [])
        self.assertFalse(parsed.evidence_ids)
        self.assertIn("same saved HTML", result["note"])
        self.assertIn(hashlib.sha256(Path(result["html_path"]).read_bytes()).hexdigest(), result["note"])

    def test_original_line_endings_are_preserved_in_html_bytes(self):
        raw = "FIRST\r\nSECOND\r\n\nTHIRD\n"
        result, _, parsed = self.render("Source line endings.\n", [self.evidence(raw)])
        self.assertEqual(parsed.raw, [raw])
        self.assertIn(raw.encode("utf-8"), Path(result["evidence_html_path"]).read_bytes())

    def test_pdf_index_and_metadata_keep_long_paths_and_titles(self):
        path = "SOURCE_" + "a" * 180 + "_END.py"
        title = "TITLE_" + "b" * 180 + "_END"
        entry = self.evidence("Short body.\n", path)
        entry["title"] = title
        result, _, _ = self.render("Long metadata.\n", [entry])
        with pymupdf.open(result["evidence_pdf_path"]) as pdf:
            content = "".join("".join(page.get_text().split()) for page in pdf).replace("\u200b", "")
            # Formal evidence cards show one original source_path and one
            # authored title; their complete values must survive wrapping.
            self.assertEqual(content.count(path), 1)
            self.assertEqual(content.count(title), 1)

    def test_many_mixed_length_evidence_files_keep_every_line(self):
        entries = [
            self.evidence("\n".join(f"SOURCE_{i}_LINE_{j:04d}" for j in range(count)),
                          f"source-{i}.txt")
            for i, count in enumerate((85, 30, 2, 86, 9, 95))
        ]
        result, _, parsed = self.render("# Evidence delivery\n\nSelected files follow.\n", entries)
        self.assertEqual(parsed.raw, [item["text"] for item in entries])
        with pymupdf.open(result["evidence_pdf_path"]) as pdf:
            content = "\n".join(page.get_text() for page in pdf)
        for item in entries:
            for line in item["text"].splitlines():
                self.assertEqual(content.count(line), 1)


if __name__ == "__main__":
    unittest.main()
