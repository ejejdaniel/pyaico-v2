"""S23's frozen-file/render boundary, not publication; no model or network."""

from contextlib import contextmanager
from copy import deepcopy
import html
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch

from opencode.permission import Broker, PermissionDenied, Rule
from researchkit import records, report_evidence
from researchkit.tools import TOOLS


class ReportEvidence(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        self.ancestor = self.save({"ancestor.txt": "ANCESTOR_PRIVATE_CONTENT"})
        self.saved = self.save({"source.txt": "Original frozen observation.\n",
                                "unselected.txt": "UNSELECTED_PRIVATE_CONTENT"},
                               [self.ancestor["record_path"]])
        self.choice = self.locator(self.saved, "source.txt")
        self.ctx = SimpleNamespace(
            directory=self.workspace, worktree=self.workspace, session_id="report-session",
            abort=threading.Event(), read_files=set(),
            agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
            app=SimpleNamespace(permissions=Broker(auto=True)),
        )
        self.tool = next(tool for tool in TOOLS if tool.name == "render_report")

    def file(self, name, content):
        path = self.workspace / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content.encode("utf-8") if isinstance(content, str) else content)
        return path

    def save(self, contents, dependencies=(), *, title="Selected research", kind="notes"):
        """Build existing-format fixtures directly; publication has separate tests."""
        files = []
        snapshots = []
        for name, content in contents.items():
            path = self.file(name, content)
            source = path.relative_to(self.workspace).as_posix()
            raw = path.read_bytes()
            files.append({"source_path": source, "snapshot": "files/" + source,
                          "sha256": records.digest(raw), "bytes": len(raw)})
            snapshots.append(raw)
        manifest = {"kind": kind, "title": title, "files": files, "depends_on": list(dependencies)}
        raw = records.encoded(manifest)
        folder = self.workspace / ".research/records" / records.digest(raw)
        folder.mkdir(parents=True, exist_ok=True)
        for item, content in zip(files, snapshots):
            snapshot = folder / item["snapshot"]
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes(content)
        (folder / "record.json").write_bytes(raw)
        return {"record_path": (folder / "record.json").relative_to(self.workspace).as_posix(), **manifest}

    @staticmethod
    def locator(saved, source):
        return {"record_ref": saved["record_path"], "source_path": source}

    def snapshot(self, saved, source):
        item = next(item for item in saved["files"] if item["source_path"] == source)
        return self.workspace / Path(saved["record_path"]).parent / item["snapshot"]

    def rekey(self, saved, mutate):
        """Change test manifest fields while retaining their real content address."""
        manifest = {key: deepcopy(value) for key, value in saved.items() if key != "record_path"}
        mutate(manifest)
        raw = records.encoded(manifest)
        folder = self.workspace / ".research/records" / records.digest(raw)
        folder.mkdir(exist_ok=True)
        # Copy only original, safe snapshot paths, never a malformed test locator.
        for item in saved["files"]:
            path = folder / item["snapshot"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(self.snapshot(saved, item["source_path"]).read_bytes())
        (folder / "record.json").write_bytes(raw)
        return {"record_path": (folder / "record.json").relative_to(self.workspace).as_posix(), **manifest}

    @contextmanager
    def reads(self):
        opened = []
        original = Path.read_bytes

        def observe(path):
            opened.append(path.resolve())
            return original(path)

        with patch.object(Path, "read_bytes", observe):
            yield opened

    def resolve(self, choices=None, **kwargs):
        return report_evidence.resolve(self.workspace, [self.choice] if choices is None else choices, **kwargs)

    def render_stub(self):
        return {"html_path": str(self.workspace / "rendered/report.html"),
                "pdf_path": str(self.workspace / "rendered/report.pdf"), "pages": 2,
                "renderer": "offline boundary test", "note": "Authored body plus exact selected evidence."}

    def test_exact_version_and_source_collision_preserve_selection_order(self):
        newer = self.save({"source.txt": "Later frozen observation.\n"}, title="Revised research")
        self.file("source.txt", "Unsaved working replacement.")
        choices = [self.locator(newer, "source.txt"), self.choice]
        resolved = self.resolve(choices)
        self.assertEqual([item["text"] for item in resolved],
                         ["Later frozen observation.\n", "Original frozen observation.\n"])
        self.assertEqual([item["record_ref"] for item in resolved],
                         [newer["record_path"], self.saved["record_path"]])
        self.assertEqual([item["title"] for item in resolved], ["Revised research", "Selected research"])
        self.assertEqual(choices, [self.locator(newer, "source.txt"), self.choice])
        (self.workspace / "source.txt").unlink()
        self.assertEqual(self.resolve(), [resolved[1]])

    def test_unicode_bom_crlf_and_full_large_content_keep_original_byte_identity(self):
        text = "完整科研原文\tΔ = 3\r\n" + "沒有裁切的文字。\n" * 20000
        raw = b"\xef\xbb\xbf" + text.encode("utf-8")
        saved = self.save({"資料/原文.txt": raw}, title="中文標題", kind="evidence")
        resolved = self.resolve([self.locator(saved, "資料/原文.txt")])
        self.assertEqual(resolved, [{
            "record_ref": saved["record_path"], "source_path": "資料/原文.txt",
            "title": "中文標題", "kind": "evidence", "sha256": records.digest(raw),
            "bytes": len(raw), "text": text,
        }])

    def test_only_selected_manifest_and_snapshot_are_read(self):
        unselected = self.snapshot(self.saved, "unselected.txt")
        ancestor_manifest = self.workspace / self.ancestor["record_path"]
        unselected.unlink()
        ancestor_manifest.write_bytes(b"broken ancestor manifest")
        expected = {self.workspace / self.saved["record_path"], self.snapshot(self.saved, "source.txt")}
        authorized = []

        def check(path):
            authorized.append(path)
            if path not in expected:
                raise PermissionError("unselected input must remain private")

        with self.reads() as opened, patch.object(
                records, "read_record", side_effect=AssertionError("Must not read every frozen file")):
            resolved = self.resolve(check_read=check)
        self.assertEqual(set(opened), expected)
        self.assertEqual(set(authorized), expected)
        self.assertNotIn("PRIVATE_CONTENT", str(resolved))

    def test_links_and_inline_record_names_do_not_select_dependencies(self):
        content = ("[related](unselected.txt)\n"
                   f"`{self.ancestor['record_path']}`\n"
                   "<img src='unselected.txt'>\n<script>source text only</script>")
        saved = self.save({"linked.md": content}, [self.ancestor["record_path"]])
        ancestor_manifest = self.workspace / self.ancestor["record_path"]
        ancestor_manifest.unlink()
        with self.reads() as opened:
            resolved = self.resolve([self.locator(saved, "linked.md")])
        self.assertEqual(resolved[0]["text"], content)
        self.assertEqual(set(opened), {self.workspace / saved["record_path"],
                                      self.snapshot(saved, "linked.md")})

    def test_empty_selection_does_not_read_or_require_record_storage(self):
        empty = self.root / "empty"
        empty.mkdir()
        with self.reads() as opened:
            self.assertEqual(report_evidence.resolve(empty, []), [])
        self.assertEqual(opened, [])

    def test_invalid_selection_is_rejected_before_any_file_read(self):
        bad_values = [None, {}, (), "source.txt", 5, [None], ["source.txt"], [{}],
                      [{"record_ref": self.choice["record_ref"]}],
                      [{**self.choice, "extra": "not approved"}],
                      [{**self.choice, "record_ref": None}],
                      [{**self.choice, "source_path": 1}],
                      [{**self.choice, "source_path": " \t"}],
                      [{**self.choice, "record_ref": ""}],
                      [self.choice, dict(self.choice)]]
        for choices in bad_values:
            with self.subTest(choices=choices), self.reads() as opened, self.assertRaises(ValueError):
                report_evidence.resolve(self.workspace, choices)
            self.assertEqual(opened, [])

    def test_record_reference_requires_exact_relative_content_address(self):
        ref = self.choice["record_ref"]
        bad_refs = ["../" + ref, str(self.workspace / ref), ref.replace("/", "\\"),
                    ref.replace("/record.json", "/files/source.txt"),
                    ".research/records/latest/record.json", ref.upper(), "./" + ref]
        for bad in bad_refs:
            with self.subTest(ref=bad), self.reads() as opened, self.assertRaises(ValueError):
                self.resolve([{**self.choice, "record_ref": bad}])
            self.assertEqual(opened, [])

    def test_permission_precedes_each_selected_read(self):
        targets = [self.workspace / self.saved["record_path"], self.snapshot(self.saved, "source.txt")]
        for target in targets:
            def check(path):
                if path == target:
                    raise PermissionError("selected read denied")
            with self.subTest(path=target), self.reads() as opened, self.assertRaises(PermissionError):
                self.resolve(check_read=check)
            self.assertNotIn(target, opened)

    def test_missing_manifest_or_snapshot_fails_without_fallback(self):
        for target in [self.workspace / self.saved["record_path"], self.snapshot(self.saved, "source.txt")]:
            original = target.read_bytes()
            target.unlink()
            try:
                with self.subTest(path=target), self.assertRaises(FileNotFoundError):
                    self.resolve()
            finally:
                target.write_bytes(original)

    def test_changed_manifest_bytes_fail_before_snapshot_read(self):
        path = self.workspace / self.saved["record_path"]
        path.write_bytes(path.read_bytes() + b"\n")
        with self.reads() as opened, self.assertRaisesRegex(ValueError, "Record content has changed"):
            self.resolve()
        self.assertEqual(opened, [path])

    def test_changed_snapshot_bytes_fail(self):
        self.snapshot(self.saved, "source.txt").write_bytes(b"changed frozen content")
        with self.assertRaisesRegex(ValueError, "hash or bytes changed"):
            self.resolve()

    def test_snapshot_digest_and_integer_byte_count_are_checked_independently(self):
        for field, value in (("sha256", "0" * 64), ("bytes", 1), ("bytes", True), ("bytes", "29")):
            with self.subTest(field=field, value=value):
                saved = self.rekey(self.saved, lambda manifest: manifest["files"][0].update({field: value}))
                with self.assertRaisesRegex(ValueError, "hash or bytes changed"):
                    self.resolve([self.locator(saved, "source.txt")])

    def test_source_path_must_match_exactly_once(self):
        for source in ("missing.txt", "SOURCE.TXT", "./source.txt"):
            with self.subTest(source=source), self.assertRaisesRegex(ValueError, "exactly select one"):
                self.resolve([{**self.choice, "source_path": source}])
        saved = self.rekey(self.saved, lambda manifest: manifest["files"].append(deepcopy(manifest["files"][0])))
        with self.assertRaisesRegex(ValueError, "exactly select one"):
            self.resolve([self.locator(saved, "source.txt")])

    def test_snapshot_path_cannot_escape_record_folder_or_workspace(self):
        outside = self.root / "outside.txt"
        outside.write_bytes(b"outside workspace")
        inside = self.file("outside-record.txt", "outside record")
        paths = ["../outside.txt", "../../../../outside.txt", str(inside), str(outside)]
        for name in paths:
            saved = self.rekey(self.saved, lambda manifest: manifest["files"][0].update(snapshot=name))
            with self.subTest(snapshot=name), self.reads() as opened, self.assertRaisesRegex(ValueError, "outside"):
                self.resolve([self.locator(saved, "source.txt")])
            self.assertEqual(opened, [self.workspace / saved["record_path"]])

    def test_binary_or_invalid_utf8_is_not_replaced_or_ignored(self):
        for index, raw in enumerate((b"\xff\xfeinvalid", b"UTF-8 prefix\x00binary", b"binary\x01control")):
            saved = self.save({f"binary-{index}.bin": raw})
            with self.subTest(raw=raw), self.assertRaisesRegex(ValueError, "UTF-8|binary"):
                self.resolve([self.locator(saved, f"binary-{index}.bin")])

    def test_missing_manifest_metadata_or_malformed_snapshot_fields_fail(self):
        mutations = [lambda m: m.update(files=None), lambda m: m.update(title=None),
                     lambda m: m.update(kind=" "), lambda m: m["files"][0].update(snapshot=None)]
        for mutate in mutations:
            saved = self.rekey(self.saved, mutate)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                self.resolve([self.locator(saved, "source.txt")])

    def test_duplicate_json_keys_are_rejected_even_with_matching_manifest_hash(self):
        raw = records.encoded({key: value for key, value in self.saved.items() if key != "record_path"})
        raw = raw[:-1] + b', "title": "duplicate"}'
        folder = self.workspace / ".research/records" / records.digest(raw)
        folder.mkdir()
        (folder / "record.json").write_bytes(raw)
        ref = (folder / "record.json").relative_to(self.workspace).as_posix()
        with self.assertRaisesRegex(ValueError, "Duplicate record key"):
            self.resolve([{"record_ref": ref, "source_path": "source.txt"}])

    def test_tool_schema_adds_only_the_approved_optional_selection(self):
        schema = self.tool.parameters
        self.assertEqual(set(schema["properties"]), {"markdown_path", "evidence_files", "mindmap_files"})
        self.assertEqual(schema["required"], ["markdown_path"])
        self.assertFalse(schema["additionalProperties"])
        selection = schema["properties"]["evidence_files"]
        self.assertEqual(selection["type"], "array")
        self.assertTrue(selection["uniqueItems"])
        self.assertNotIn("minItems", selection)
        item = selection["items"]
        self.assertEqual(set(item["properties"]), {"record_ref", "source_path"})
        self.assertEqual(set(item["required"]), {"record_ref", "source_path"})
        self.assertFalse(item["additionalProperties"])
        for field in item["properties"].values():
            self.assertEqual(field["type"], "string")
            self.assertEqual(field["minLength"], 1)

    def test_tool_passes_resolved_evidence_and_preserves_receipt_contract(self):
        source = self.file("report.md", "# Authored report\n")
        stub = self.render_stub()
        with patch("researchkit.report.render", return_value=stub) as render:
            receipt = self.tool.execute({"markdown_path": "report.md", "evidence_files": [self.choice]}, self.ctx)
        self.assertEqual(render.call_args.args[0], source)
        self.assertEqual(render.call_args.kwargs, {"evidence": self.resolve(), "saved_literature": set()})
        self.assertEqual(json.loads(receipt.output), stub)
        self.assertEqual(set(json.loads(receipt.output)), {"html_path", "pdf_path", "pages", "renderer", "note"})
        self.assertEqual(receipt.metadata, {"files": [stub["html_path"], stub["pdf_path"]]})

    @unittest.skipUnless(all(importlib.util.find_spec(name) for name in ("markdown", "pymupdf")),
                         "Optional report dependencies absent")
    def test_real_tool_render_includes_full_selected_snapshot_and_preserves_return_fields(self):
        frozen = ("BEGIN_FROZEN_FILE\n<script>literal source, never executed</script>\n"
                  + "".join(f"保存原文 ROW{index:04d}: value < {index + 1} & unchanged.\n"
                            for index in range(80))
                  + "END_FROZEN_FILE\n")
        saved = self.save({"source.txt": frozen, "unselected.txt": "UNSELECTED_PRIVATE_CONTENT"})
        self.file("source.txt", "UNSAVED_WORKING_REPLACEMENT")
        self.file("report.md", "# Authored report\n\nBody remains the author's text.\n")
        receipt = self.tool.execute({
            "markdown_path": "report.md", "evidence_files": [self.locator(saved, "source.txt")],
        }, self.ctx)
        rendered = json.loads(receipt.output)
        self.assertEqual(set(rendered), {"html_path", "pdf_path", "pages", "renderer", "note", "layout", "layout_note",
                                         "style", "citations", "evidence_html_path", "evidence_pdf_path", "evidence_pages"})
        self.assertEqual(receipt.metadata, {"files": [rendered["html_path"], rendered["pdf_path"],
                                                      rendered["evidence_html_path"], rendered["evidence_pdf_path"]]})
        self.assertGreater(rendered["pages"], 0)
        self.assertTrue(Path(rendered["pdf_path"]).is_file())
        originals = Path(rendered["evidence_html_path"]).read_text(encoding="utf-8")
        self.assertIn(html.escape(frozen), originals)
        self.assertNotIn("UNSELECTED_PRIVATE_CONTENT", originals)
        self.assertNotIn("UNSAVED_WORKING_REPLACEMENT", originals)
        document = Path(rendered["html_path"]).read_text(encoding="utf-8")
        self.assertNotIn(html.escape(frozen), document)  # the report keeps only the index
        self.assertIn(saved["record_path"], document)
        self.assertIn(records.digest(frozen.encode("utf-8")), document)
        self.assertNotIn("UNSELECTED_PRIVATE_CONTENT", document)
        self.assertNotIn("UNSAVED_WORKING_REPLACEMENT", document)
        self.assertNotIn("<script>literal source", document)

    def test_old_tool_calls_and_explicit_empty_selection_both_pass_empty_evidence(self):
        self.file("report.md", "Authored body")
        for extra in ({}, {"evidence_files": []}):
            with self.subTest(extra=extra), patch("researchkit.report.render", return_value=self.render_stub()) as render:
                self.tool.execute({"markdown_path": "report.md", **extra}, self.ctx)
            self.assertEqual(render.call_args.kwargs, {"evidence": [], "saved_literature": set()})

    def test_all_selection_validation_finishes_before_render_or_output_directory_creation(self):
        self.file("report.md", "Authored body")
        choices = [self.choice, {**self.choice, "source_path": "missing.txt"}]
        with patch("researchkit.report.render") as render, self.assertRaises(ValueError):
            self.tool.execute({"markdown_path": "report.md", "evidence_files": choices}, self.ctx)
        render.assert_not_called()
        self.assertFalse((self.workspace / ".research/reports").exists())
        with patch("researchkit.report.render") as render, self.assertRaises(ValueError):
            self.tool.execute({"markdown_path": "report.md", "evidence_files": None}, self.ctx)
        render.assert_not_called()

    def test_tool_uses_existing_read_permissions_for_manifest_and_selected_snapshot(self):
        self.file("report.md", "Authored body")
        for target in (self.workspace / self.saved["record_path"], self.snapshot(self.saved, "source.txt")):
            self.ctx.agent.permission = [Rule("*", "*", "allow"),
                                         Rule("read", target.relative_to(self.workspace).as_posix(), "deny")]
            with self.subTest(path=target), self.reads() as opened, patch("researchkit.report.render") as render, \
                    self.assertRaises(PermissionDenied):
                self.tool.execute({"markdown_path": "report.md", "evidence_files": [self.choice]}, self.ctx)
            render.assert_not_called()
            self.assertNotIn(target, opened)
            self.assertFalse((self.workspace / ".research/reports").exists())


if __name__ == "__main__":
    unittest.main()
