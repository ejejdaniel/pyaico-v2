"""Deterministic HTML-boundary checks; no research, model, browser, or PDF run."""

from html import escape
from html.parser import HTMLParser
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


class Page(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.ids, self.navigation, self.links, self.images = [], [], [], []
        self.sections, self.raw, self.resources = [], [], []
        self._nav = self._raw = False
        self._section = None
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if tag == "nav":
            self._nav = True
        if tag == "section":
            self._section = {"attrs": attrs, "text": "", "maps": []}
            self.sections.append(self._section)
        if "data-test-map" in attrs and self._section is not None:
            self._section["maps"].append(attrs["data-test-map"])
        if tag == "a":
            self.links.append(attrs.get("href"))
            if self._nav:
                self.navigation.append(attrs.get("href"))
        if tag == "img":
            self.images.append(attrs)
        if tag in {"script", "link"}:
            self.resources.extend(attrs[key] for key in ("src", "href") if key in attrs)
        if tag == "details" and attrs.get("class") == "raw":
            self._raw = True
        if self._raw and tag == "pre":
            self.raw.append("")
            self._raw = "content"

    def handle_endtag(self, tag):
        if tag == "nav":
            self._nav = False
        if tag == "section":
            self._section = None
        if tag == "details":
            self._raw = False

    def handle_data(self, data):
        if self._section is not None:
            self._section["text"] += data
        if self._raw == "content":
            self.raw[-1] += data


@unittest.skipUnless(importlib.util.find_spec("markdown"), "Optional Markdown dependency absent")
class ReportHTML(unittest.TestCase):
    def setUp(self):
        from researchkit.report_html import build_html
        self.build = build_html
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def render(self, text, **kwargs):
        source = self.root / "authored report.md"
        source.write_text(text, encoding="utf-8")
        destination = self.root / "output"
        document = self.build(source, destination, evidence=kwargs.get("evidence", []),
                              mindmaps=kwargs.get("mindmaps", []))
        self.assertFalse(destination.exists(), "HTML construction must not write files")
        return document, Page(document)

    def test_short_markdown_and_title_only_report_need_no_chapters(self):
        for text in ("A short authored report.\n", "# Authored title\n\nA short authored report.\n"):
            with self.subTest(text=text):
                document, page = self.render(text)
                self.assertIn("<p>A short authored report.</p>", document)
                self.assertFalse(page.navigation)
                self.assertFalse(page.sections)
                self.assertIn('class="hero"', document)
                self.assertNotIn('class="chapter abstract"', document)
                self.assertFalse(page.resources)

    def test_headings_in_fences_are_not_chapters_and_real_navigation_is_unique(self):
        document, page = self.render(
            "# top\n\n## main\n\n### Detail\n\nFirst text.\n\n"
            "```markdown\n## Fake chapter\n# Fake title\n```\n\n"
            "## main\n\n### Detail\n\nLast text.\n\n## section-0\n\nTail.\n"
        )
        self.assertEqual(len(page.navigation), 3)
        self.assertEqual(len(page.ids), len(set(page.ids)))
        for link in page.navigation:
            self.assertEqual(page.ids.count(link[1:]), 1)
        self.assertIn("## Fake chapter\n# Fake title", document)
        self.assertEqual(document.count('class="narrative-card"'), 2)
        self.assertIn("First text.", document)
        self.assertIn("Last text.", document)
        self.assertNotIn('class="chapter abstract"', document)

    def test_markdown_links_raw_html_images_and_literal_evidence_labels(self):
        document, page = self.render(
            "# Evidence\n\n[Paper](https://example.org/paper?q=1&view=full) "
            "[local](data/observations%20one.json?q=raw#value) [anchor](#method)\n\n"
            "![An authored image](https://example.org/image.png)\n\n"
            "<script>alert('literal')</script>\n\n"
            "```html\n<div>literal & code</div>\n```\n\n"
            "[E1] and `unlinked.json` stay authored text.\n\n"
            "## Method\n\n| Record | Value |\n| --- | --- |\n| OBS-A | 17.25 |\n\n"
            "> The conclusion remains conditional.\n"
        )
        self.assertIn("https://example.org/paper?q=1&view=full", page.links)
        self.assertIn("../data/observations%20one.json?q=raw#value", page.links)
        self.assertIn("#method", page.links)
        self.assertNotIn("unlinked.json", page.links)
        self.assertNotIn("#evidence-E1", page.links)
        self.assertFalse(page.images)
        self.assertIn("An authored image", document)
        self.assertIn("&lt;script&gt;alert('literal')&lt;/script&gt;", document)
        self.assertIn("&lt;div&gt;literal &amp; code&lt;/div&gt;", document)
        self.assertIn('class="table-scroll"', document)
        self.assertIn("The conclusion remains conditional.", document)

    def test_evidence_keeps_selected_order_exact_text_and_provenance(self):
        evidence = [
            {"record_ref": ".research/records/" + marker * 64 + "/record.json",
             "source_path": f"source/{marker}.json", "title": f"Selected {marker}",
             "kind": "frozen_file", "sha256": marker * 64, "bytes": 104 + index,
             "text": f'{{"depends_on": ["never-read-{marker}"], "raw": "<x> & Ω"}}\n\n'}
            for index, marker in enumerate(("b", "a"))
        ]
        document, page = self.render("Plain authored body.\n", evidence=evidence)
        from researchkit.report_html import build_evidence_html
        originals = build_evidence_html(evidence, "report")
        self.assertEqual(page.raw, [])
        self.assertEqual(Page(originals).raw, [item["text"] for item in evidence])
        self.assertLess(originals.index("Selected b"), originals.index("Selected a"))
        self.assertLess(document.index("Selected b"), document.index("Selected a"))
        for item in evidence:
            for key in ("record_ref", "source_path", "sha256", "bytes"):
                self.assertIn(escape(str(item[key])), document)
        self.assertEqual(len(page.sections), 1)
        self.assertIn("內部研究證據索引", page.sections[0]["text"])
        self.assertIn("element.open=true", document)

    def test_authored_numeric_fragment_links_use_superscript_with_existing_rebasing(self):
        document, page = self.render(
            "# Report\n\nInternal.[1](#evidence-1) External.[10](#published-paper) "
            "Repeated.[1](#evidence-1) Leading zero.[007](#author-target)\n\n"
            "Local citation.[3](local.md#record)\n\n"
            "[Method](#method) [2](https://example.org/paper#record) "
            "[4](#) and [E1](#evidence-1) stay ordinary links.\n\n"
            "[5] and (evidence 6) stay authored text. ` [7](#literal-code) `\n\n"
            "## Method\n\nAuthored method.\n\n## Published paper\n\nAuthored source.\n"
        )
        for label, target in (("10", "published-paper"), ("007", "author-target")):
            self.assertIn(f'<a aria-label="引用 {label}" class="citation" '
                          f'href="#{target}">{label}</a>', document)
        # Internal evidence reads E1 so it never looks like a literature number.
        self.assertIn('<a aria-label="內部證據 E1" class="citation" href="#evidence-1">E1</a>', document)
        self.assertIn('<a aria-label="引用 3" class="citation" '
                      'href="../local.md#record">3</a>', document)
        self.assertEqual(document.count('class="citation"'), 5)
        self.assertEqual(page.links.count("#evidence-1"), 3)
        self.assertIn('<a href="#method">Method</a>', document)
        self.assertIn('<a href="https://example.org/paper#record">2</a>', document)
        self.assertIn('<a href="#">4</a>', document)
        self.assertIn('<a href="#evidence-1">E1</a>', document)
        self.assertIn("[5] and (evidence 6) stay authored text.", document)
        self.assertIn("[7](#literal-code)", document)
        self.assertNotIn("#literal-code", page.links)
        self.assertIn('a.citation { vertical-align:super;', document)
        self.assertFalse(page.resources)

    def test_authored_external_references_stay_separate_from_internal_evidence(self):
        evidence = [{"record_ref": "saved/record.json", "source_path": "source/observations.json",
                     "title": "Selected observations", "kind": "frozen_file", "sha256": "a" * 64,
                     "bytes": 27, "text": "Exact selected observations.\n"}]
        document, page = self.render(
            "# Report\n\n## Findings\n\nInternal.[1](#evidence-1) "
            "External.[10](#published-paper)\n\n## 外部文獻\n\n"
            "### Published paper\n\n10. [Author-supplied publication](https://example.org/paper)\n",
            evidence=evidence,
        )
        self.assertEqual(len(page.sections), 3)
        self.assertIn("外部文獻", page.sections[1]["text"])
        self.assertIn("Author-supplied publication", page.sections[1]["text"])
        self.assertNotIn("Selected observations", page.sections[1]["text"])
        self.assertIn("內部研究證據索引", page.sections[2]["text"])
        self.assertIn("Selected observations", page.sections[2]["text"])
        self.assertEqual(page.raw, [])  # the complete original is in the separate evidence file
        self.assertIn("evidence.html#evidence-1", page.links)
        for target in ("evidence-1", "published-paper"):
            self.assertEqual(page.ids.count(target), 1)
            self.assertIn(f"#{target}", page.links)
        self.assertFalse(page.resources)

    def test_exact_canonical_layout_places_maps_and_evidence_without_content_inference(self):
        from researchkit.report_html import _FULL_REPORT_HEADINGS
        headings = _FULL_REPORT_HEADINGS
        markdown_text = "# Report\n\n" + "\n\n".join(
            f"## {heading}\n\nAuthored section {index}." for index, heading in enumerate(headings)
        )
        maps = [{"content": {"opaque": "one"}, "record_ref": "exact-one"},
                {"content": {"opaque": "two"}, "record_ref": "exact-two"}]

        def render_map(content, provenance, namespace):
            return f'<figure data-test-map="{content["opaque"]}" id="{namespace}-board"></figure>'

        with patch("researchkit.report_mindmap.render_mindmap", side_effect=render_map) as draw:
            document, page = self.render(markdown_text, mindmaps=maps)
        self.assertEqual(len(page.sections), 9)
        self.assertEqual(page.sections[2]["maps"], ["one", "two"])
        self.assertIn("abstract", page.sections[0]["attrs"]["class"])
        self.assertEqual(draw.call_args_list[0].args[:2],
                         ({"opaque": "one"}, {"record_ref": "exact-one"}))
        for index in range(9):
            self.assertIn(f"Authored section {index}.", document)
        with patch("researchkit.report_mindmap.render_mindmap", side_effect=render_map):
            _, other = self.render(markdown_text.replace("2. 共同研究資產與心智圖", "研究地圖"),
                                   mindmaps=maps)
        self.assertFalse(other.sections[2]["maps"])
        self.assertEqual(other.sections[-1]["maps"], ["one", "two"])
        self.assertIn("研究心智圖", other.sections[-1]["text"])

    def test_canonical_layout_keeps_map_and_evidence_when_author_appends_a_chapter(self):
        from researchkit.report_html import _FULL_REPORT_HEADINGS
        markdown_text = "# Report\n\n" + "\n\n".join(
            f"## {heading}\n\nAuthored section {index}."
            for index, heading in enumerate(_FULL_REPORT_HEADINGS)
        ) + "\n\n## 外部文獻\n\nAuthor-selected publication.\n"
        evidence = [{"record_ref": "saved/record.json", "source_path": "source/observations.json",
                     "title": "Selected observations", "kind": "frozen_file", "sha256": "b" * 64,
                     "bytes": 27, "text": "Exact selected observations.\n"}]
        maps = [{"content": {"opaque": "one"}, "record_ref": "exact-one"}]
        with patch("researchkit.report_mindmap.render_mindmap",
                   return_value='<figure data-test-map="one"></figure>'):
            document, page = self.render(markdown_text, mindmaps=maps, evidence=evidence)
        self.assertEqual(len(page.sections), 10)
        self.assertIn('<body>', document)
        self.assertEqual(page.sections[2]["maps"], ["one"])
        self.assertIn("Selected observations", page.sections[8]["text"])
        self.assertEqual(page.raw, [])  # the complete original is in the separate evidence file
        self.assertIn("外部文獻", page.sections[9]["text"])
        self.assertIn("Author-selected publication.", page.sections[9]["text"])
        self.assertNotIn("Selected observations", page.sections[9]["text"])
        self.assertFalse(page.sections[9]["maps"])

    def test_authored_ranking_heading_does_not_relocate_map_or_evidence(self):
        from researchkit.report_html import _FULL_REPORT_HEADINGS
        headings = list(_FULL_REPORT_HEADINGS)
        headings[5] = "5. 樣本演化與代理排名"
        markdown_text = "# Report\n\n" + "\n\n".join(
            f"## {heading}\n\nAuthored section {index}."
            for index, heading in enumerate(headings)
        )
        evidence = [{"record_ref": "saved/record.json", "source_path": "source/observations.json",
                     "title": "Selected observations", "kind": "frozen_file", "sha256": "c" * 64,
                     "bytes": 27, "text": "Exact selected observations.\n"}]
        maps = [{"content": {"opaque": "one"}, "record_ref": "exact-one"}]
        with patch("researchkit.report_mindmap.render_mindmap",
                   return_value='<figure data-test-map="one"></figure>'):
            document, page = self.render(markdown_text, mindmaps=maps, evidence=evidence)
        self.assertEqual(len(page.sections), 9)
        self.assertIn('<body class="generic-report">', document)
        self.assertIn("5. 樣本演化與代理排名", page.sections[5]["text"])
        self.assertEqual(page.sections[2]["maps"], ["one"])
        self.assertIn("Selected observations", page.sections[8]["text"])
        self.assertEqual(page.raw, [])  # the complete original is in the separate evidence file

    def test_reference_styles_and_print_dialog_behavior_are_packaged(self):
        import researchkit.report_html
        css = (Path(researchkit.report_html.__file__).parent / "assets" / "scientific-report.css").read_bytes()
        copied = css.split(b"/* Compatibility for generic authored H3 sections", 1)[0]
        self.assertEqual(hashlib.sha256(copied).hexdigest(),
                         "fdd551b18117d250f02f46a87cc52546c6e8e0421976422cbdd0afe02a503f00")
        document, _ = self.render("# Report\n\n## 摘要\n\nAuthored abstract.\n\n## Body\n\nBody.\n")
        for expected in ('--bg:#f3f1eb', '"Microsoft JhengHei","Noto Sans TC"',
                         'grid-template-columns:repeat(4,minmax(0,1fr))',
                         '@page { size:A4', 'class="map-dialog-toolbar"',
                         "this.dataset.mapTarget", "dialog.showModal()", "beforeprint",
                         "document.documentElement.dataset.theme='light'", "element.open=true"):
            self.assertIn(expected, document)
        self.assertIn('class="chapter abstract"', document)

    def test_generic_print_flow_does_not_change_canonical_chapter_pagination(self):
        from researchkit.report_html import _FULL_REPORT_HEADINGS
        generic, _ = self.render("# Report\n\n## First\n\nFirst text.\n\n## Second\n\nSecond text.\n")
        self.assertIn('<body class="generic-report">', generic)
        self.assertIn('@media print {\n  .map-context-strip { display:block; }', generic)
        self.assertIn('.generic-report .chapter { break-before:auto; }', generic)
        self.assertIn('grid-template-columns:minmax(260px,1.5fr) repeat(2,minmax(210px,1fr))', generic)
        canonical, page = self.render("# Report\n\n" + "\n\n".join(
            f"## {heading}\n\nSection {index}."
            for index, heading in enumerate(_FULL_REPORT_HEADINGS)
        ))
        self.assertIn('<body>', canonical)
        self.assertNotIn('<body class="generic-report">', canonical)
        self.assertIn('.chapter { break-before:page; }', canonical)
        self.assertEqual(len(page.sections), 9)
        self.assertIn('abstract', page.sections[0]["attrs"]["class"])


if __name__ == "__main__":
    unittest.main()
