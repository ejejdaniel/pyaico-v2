"""render_report says which layout it used; the documented headings give the full one."""

from pathlib import Path
import re

from researchkit import report_html

DELIVERY = Path(report_html.__file__).parent / "skills/scientific-report-writer/references/report-delivery.md"


def write(tmp_path, headings):
    path = tmp_path / "report.md"
    path.write_text("# T\n\n" + "\n\n".join(f"## {h}\n\ntext" for h in headings), encoding="utf-8")
    return path


def test_the_documented_headings_are_the_ones_the_renderer_needs(tmp_path):
    documented = re.findall(r"^- ((?:摘要)|(?:[1-8]\. .+))$", DELIVERY.read_text(encoding="utf-8"), re.MULTILINE)
    assert tuple(documented) == report_html._READER_REPORT_HEADINGS
    with_subtitles = [documented[0], *(f"{h}：subtitle" for h in documented[1:]), "附錄 A. 研究過程與方法"]
    assert report_html.layout_status(write(tmp_path, with_subtitles))["layout"] == "reader"
    assert report_html.layout_status(write(tmp_path, report_html._FULL_REPORT_HEADINGS))["layout"] == "full"


def test_a_generic_report_names_the_first_heading_that_differs(tmp_path):
    headings = list(report_html._FULL_REPORT_HEADINGS)
    headings[5] = "5. 樣本演化與評估"
    status = report_html.layout_status(write(tmp_path, headings))
    assert status["layout"] == "generic"
    assert status["first_difference"] == {"position": 6, "expected": "5. 樣本演化與多指標排名",
                                          "found": "5. 樣本演化與評估"}
