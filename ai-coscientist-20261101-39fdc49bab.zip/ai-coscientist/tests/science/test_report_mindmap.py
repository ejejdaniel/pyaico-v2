"""Report presentation tests against the saved six-family map, converted to the route-family format."""

from copy import deepcopy
from html import escape
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import unittest
import xml.etree.ElementTree as ET

from researchkit.mindmap_schema import RELATIONSHIP_PATTERN
from researchkit.report_mindmap import render_mindmap
from route_map_conversion import to_route_map


_FIXTURE = Path(__file__).parent / "fixtures" / "mindmap_saved" / "six_family_map.json"
_SVG = "{http://www.w3.org/2000/svg}"


class _Elements(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.elements = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)


def _strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from _strings(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from _strings(item)


class ReportMindmapTests(unittest.TestCase):
    def setUp(self):
        self.content = to_route_map(json.loads(_FIXTURE.read_text(encoding="utf-8")))
        self.provenance = {
            "record_ref": "record:mindmap-saved-six-family",
            "source_path": str(_FIXTURE),
            "sha256": "a" * 64,
        }

    def render(self, namespace="saved-map"):
        return render_mindmap(self.content, self.provenance, namespace)

    def test_all_saved_content_and_thirteen_family_fields_are_present(self):
        original = deepcopy(self.content)
        html = self.render()
        # All authored prose is retained exactly outside the wrapped SVG labels.
        for value in _strings(self.content):
            self.assertIn(escape(value, quote=True), html)
        self.assertEqual(self.content, original)
        elements = _Elements(html).elements
        details = [attrs for tag, attrs in elements
                   if tag == "details" and attrs.get("class") == "family"]
        self.assertEqual(len(details), 6)
        for key in self.content["families"][0]:
            self.assertEqual(sum(attrs.get("data-field") == key for _, attrs in elements), 6)
        self.assertNotIn("source_observations", html)
        self.assertNotIn("直接來源觀察", html)
        self.assertNotIn("parent_family_id", html)
        self.assertNotIn("lineage_role", html)
        for key, value in self.provenance.items():
            self.assertIn(f'{key}: {escape(value, quote=True)}', html)

    def test_diagram_preserves_declared_endpoints_stages_and_layout(self):
        html = self.render()
        svg = ET.fromstring(re.search(r"<svg\b.*?</svg>", html, re.DOTALL).group())
        self.assertEqual(svg.attrib["width"], "1692")
        lanes = [node for node in svg.iter(f"{_SVG}g")
                 if "mm-lane" in node.attrib.get("class", "").split()]
        self.assertEqual([node.attrib["data-family-id"] for node in lanes],
                         [family["family_id"] for family in self.content["families"]])
        relations = [node for node in svg.iter(f"{_SVG}g")
                     if node.attrib.get("class") == "mm-relation"]
        self.assertEqual(len(relations), len(self.content["supported_relationships"]))
        for node, original in zip(relations, self.content["supported_relationships"]):
            source, operator, target, _ = RELATIONSHIP_PATTERN.fullmatch(original).groups()
            self.assertEqual((node.attrib["data-from"], node.attrib["data-to"]), (source, target))
            self.assertEqual(node.find(f"{_SVG}title").text, original)
            path = node.find(f"{_SVG}path")
            self.assertEqual("marker-start" in path.attrib, operator == "<->")
            self.assertEqual(path.attrib["marker-end"], "url(#saved-map-arrow)")
        self.assertEqual(sum(node.attrib.get("class") == "mm-flow"
                             for node in svg.iter(f"{_SVG}path")), 18)
        self.assertEqual(sum(node.attrib.get("class") == "mm-risk-link"
                             for node in svg.iter(f"{_SVG}path")), 6)

    def test_multiple_maps_have_disjoint_resolvable_ids_and_dialog_targets(self):
        html = self.render("first-map") + self.render("second-map")
        elements = _Elements(html).elements
        ids = [attrs["id"] for _, attrs in elements if "id" in attrs]
        self.assertEqual(len(ids), len(set(ids)))
        for reference in re.findall(r"url\(#([^)]*)\)", html):
            self.assertIn(reference, ids)
        for _, attrs in elements:
            if "data-map-target" in attrs:
                self.assertIn(attrs["data-map-target"], ids)
                self.assertEqual(attrs["aria-controls"], "map-dialog")
            for reference in attrs.get("aria-labelledby", "").split():
                self.assertIn(reference, ids)
        self.assertTrue(all(identifier.startswith(("first-map-", "second-map-"))
                            for identifier in ids))

    def test_untrusted_content_and_provenance_are_text_only(self):
        attack = '<script>alert("&")</script><img src="https://example.invalid/a">'
        self.content["title"] = attack
        self.content["families"][0]["principle"] = attack
        self.provenance["record_ref"] = '\"><script>alert(1)</script>'
        self.provenance["source_path"] = attack
        html = self.render()
        self.assertIn(escape(attack, quote=True), html)
        elements = _Elements(html).elements
        self.assertFalse(any(tag in {"script", "img", "iframe", "link"} for tag, _ in elements))
        self.assertFalse(any(key.startswith("on") for _, attrs in elements for key in attrs))
        self.assertFalse(any(key in {"src", "href"} for _, attrs in elements for key in attrs))
        figure = next(attrs for tag, attrs in elements if tag == "figure")
        self.assertEqual(figure["data-source-path"], attack)
        self.assertEqual(figure["data-record-ref"], self.provenance["record_ref"])

    def test_no_declared_relations_produces_no_cross_family_lines(self):
        self.content["supported_relationships"] = []
        html = self.render()
        self.assertNotIn('class="mm-relation"', html)
        self.assertIn("本成果未聲明跨方向關係", html)
        self.assertIn("每一欄是一條作用路線", html)

    def test_rejects_invalid_formal_input_and_unsafe_placement(self):
        self.content["supported_relationships"][0] = "not a declared relationship"
        with self.assertRaisesRegex(ValueError, "supported_relationships"):
            self.render()
        self.content = to_route_map(json.loads(_FIXTURE.read_text(encoding="utf-8")))
        del self.content["families"][0]["steps"]
        with self.assertRaisesRegex(ValueError, "steps"):
            self.render()
        self.content = to_route_map(json.loads(_FIXTURE.read_text(encoding="utf-8")))
        for namespace in ("", 'bad\" onclick=\"alert(1)', "a b"):
            with self.subTest(namespace=namespace), self.assertRaisesRegex(ValueError, "namespace"):
                self.render(namespace)


if __name__ == "__main__":
    unittest.main()
