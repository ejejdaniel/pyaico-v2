"""The plain-spoken reading copy made at delivery (researchkit/report_notes.py); no model calls."""

from __future__ import annotations

import json
from types import SimpleNamespace

from researchkit import report_notes
from researchkit.report_notes import CAUTION, LABEL, READING_COPY, new_numbers, parse, place

REPORT = """# 研究報告

## 摘要

兩筆樣本的排序一致性 τ 為 −1.0，所以任何公式在這裡都看不出好壞。

係數只知道下界，至少是 111.3，
真正的值還要再量。

| 樣本 | 值 |
|---|---|
| A | 1,000 |

```text
這段是程式碼，不放註記。
```
"""


def test_a_note_may_write_only_numbers_the_report_writes_as_values():
    # A note wrote −1 where the report wrote −1.0 and was dropped by a comparison of the digits as text.
    assert new_numbers("τ 是 −1 表示完全反向，係數至少 111.3", REPORT) == []
    assert new_numbers("一千就是 1000", REPORT) == []
    assert new_numbers("三輪共 85 個候選", REPORT) == ["85"]


def test_the_notes_are_read_from_the_json_array_in_the_reply():
    reply = 'Here:\n```json\n[{"anchor": " 至少是 111.3 ", "note": "下界。"}, {"anchor": "x"}, "bad"]\n```'
    assert parse(reply) == [{"anchor": "至少是 111.3", "note": "下界。"}]
    assert parse("no notes") == [] and parse("[not json") == []


def test_a_note_goes_after_the_paragraph_that_holds_its_anchor():
    notes = [
        # The anchor spans a wrapped line.
        {"anchor": "至少是 111.3，真正的值還要再量。", "note": "你可以想成只知道起跳價。"},
        # Copied with a slip: a twelve-character stretch still places it.
        {"anchor": "兩筆樣本的排序一致性 τ 為 −1.0，所以任何公式在那裡都看不出好壞", "note": "只有兩筆，比不出來。"},
        {"anchor": "報告裡沒有這句話", "note": "放不進去。"},
        {"anchor": "這段是程式碼，不放註記。", "note": "程式碼裡不放。"},
        {"anchor": "| A | 1,000 |", "note": "表格裡不放。"},
        {"anchor": "真正的值還要再量", "note": "这个要再量。"},  # a Simplified slip
    ]
    text, unplaced = place(REPORT, notes)
    assert [note["note"] for note in unplaced] == ["放不進去。", "程式碼裡不放。", "表格裡不放。"]
    boxes = [line for line in text.splitlines() if line.startswith(f"> **{LABEL}**")]
    assert boxes == [f"> **{LABEL}**　只有兩筆，比不出來。", f"> **{LABEL}**　你可以想成只知道起跳價。",
                     f"> **{LABEL}**　這個要再量。"]
    assert text.index("只有兩筆") < text.index("係數只知道下界") < text.index("起跳價") < text.index("| 樣本")


NOTES = json.dumps([
    {"anchor": "係數只知道下界，至少是 111.3，", "note": "就像只知道起跳價，至少 111.3。"},
    {"anchor": "所以任何公式在這裡都看不出好壞。", "note": "三輪 85 個候選也一樣。"},  # 85 is not in the report
    {"anchor": "不在報告裡的句子", "note": "放不進去。"},
    {"anchor": "所以任何公式在這裡都看不出好壞。", "note": "因為只有兩筆，怎麼排都像是猜的。"},  # a cause of its own
    {"anchor": "所以任何公式在這裡都看不出好壞。", "note": "其實公式之間分得出好壞。"},  # the report's result reversed
], ensure_ascii=False)


def model(monkeypatch, check_reply=None):
    """A model that writes NOTES and then judges them: the note reversing the report's result does not hold."""
    asked = []

    def complete(ctx, *, system, messages):
        asked.append((system, messages))
        if system == report_notes.SYSTEM:
            return SimpleNamespace(text=NOTES)
        items = json.loads(messages[0]["content"])["notes"]
        verdicts = [{"i": item["i"], "ok": "分得出" not in item["note"], "why": "跟報告相反"} for item in items]
        return SimpleNamespace(text=json.dumps(verdicts, ensure_ascii=False) if check_reply is None else check_reply)

    def render(source, destination):
        destination.mkdir()
        return {"html_path": str(destination / "report.html"), "pdf_path": str(destination / "report.pdf")}

    monkeypatch.setattr(report_notes, "complete_once", complete)
    monkeypatch.setattr(report_notes, "render", render)
    return asked


def test_the_reading_copy_says_what_it_is_and_keeps_only_notes_that_hold(tmp_path, monkeypatch):
    asked = model(monkeypatch)
    summary = report_notes.write(None, REPORT, tmp_path)
    assert summary == {"asked": 5, "placed": 2, "unplaced": 1, "dropped_for_numbers": 1, "dropped_by_check": 1,
                       "html_path": str(tmp_path / "notes" / "report.html"),
                       "pdf_path": str(tmp_path / "notes" / "report.pdf")}
    assert asked[0][1] == [{"role": "user", "content": REPORT}]
    # The check reads the whole report and each placed note with its paragraph.
    checked = json.loads(asked[1][1][0]["content"])
    assert checked["report"] == REPORT
    assert [item["note"] for item in checked["notes"]] == [
        "就像只知道起跳價，至少 111.3。", "因為只有兩筆，怎麼排都像是猜的。", "其實公式之間分得出好壞。"]
    assert checked["notes"][0]["paragraph"] == "係數只知道下界，至少是 111.3，\n真正的值還要再量。"
    copy = (tmp_path / "report_notes.md").read_text(encoding="utf-8")
    assert copy.startswith("# 研究報告\n\n" + READING_COPY + "\n")
    # A cause the report never gave stays, with the caution in its box.
    assert f"> **{LABEL}**　因為只有兩筆，怎麼排都像是猜的。\n>\n> {CAUTION}" in copy
    assert f"> **{LABEL}**　就像只知道起跳價，至少 111.3。\n>\n> {CAUTION}" in copy
    assert "85" not in copy and "分得出" not in copy


def test_a_check_that_cannot_be_read_keeps_no_note(tmp_path, monkeypatch):
    model(monkeypatch, check_reply="I could not decide.")
    summary = report_notes.write(None, REPORT, tmp_path)
    assert summary["placed"] == 0 and summary["dropped_by_check"] == 3 and summary["check"] == "unreadable"
    assert not (tmp_path / "report_notes.md").exists()


def test_a_passage_the_review_found_wrong_takes_no_note(tmp_path, monkeypatch):
    model(monkeypatch)
    summary = report_notes.write(None, REPORT, tmp_path, avoid=["真正的值 還要再量。"])
    assert summary["placed"] == 1 and summary["unplaced"] == 2


def test_no_reading_copy_without_a_note_that_holds(tmp_path, monkeypatch):
    monkeypatch.setattr(report_notes, "complete_once", lambda ctx, **_: SimpleNamespace(text="[]"))
    monkeypatch.setattr(report_notes, "render", lambda *_: (_ for _ in ()).throw(AssertionError("not printed")))
    assert report_notes.write(None, REPORT, tmp_path) == {"asked": 0, "placed": 0, "unplaced": 0,
                                                           "dropped_for_numbers": 0, "dropped_by_check": 0}
    assert not (tmp_path / "report_notes.md").exists()
