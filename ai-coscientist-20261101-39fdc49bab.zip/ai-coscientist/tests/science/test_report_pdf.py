"""Offline boundary checks; browser output and PDF parsing are explicit mocks."""

from __future__ import annotations

import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
from urllib.parse import urlsplit
from urllib.request import url2pathname

from researchkit import report_pdf


class ReportPDFExport(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.temp_root = self.root / "temporary"
        self.temp_root.mkdir()
        self.source = self.root / "reviewed.html"
        self.original = b'\xef\xbb\xbf<!doctype html>\r\n<p>Original <a href="evidence/data.txt">evidence</a></p>\r\n'
        self.source.write_bytes(self.original)
        self.output = self.root / "report.pdf"
        self.browser = self.root / "chrome.exe"
        self.mock_pdf = b"%PDF-1.7\n" + b"mock browser output " * 100
        self.addCleanup(patch.stopall)
        patch.object(report_pdf, "_browser_executable", return_value=self.browser).start()
        patch.object(report_pdf.tempfile, "gettempdir", return_value=str(self.temp_root)).start()

    def printer(self, executable, args):
        self.assertEqual(executable, self.browser)
        snapshot = Path(url2pathname(urlsplit(args[-1]).path))
        self.assertEqual(snapshot.parent, self.source.parent)
        self.assertEqual(snapshot.read_bytes(), self.original)
        self.assertIn('href="evidence/data.txt"', snapshot.read_text(encoding="utf-8-sig"))
        self.assertIn("--headless=new", args)
        self.assertIn("--no-pdf-header-footer", args)
        profile = Path(next(arg.split("=", 1)[1] for arg in args if arg.startswith("--user-data-dir=")))
        staged = Path(next(arg.split("=", 1)[1] for arg in args if arg.startswith("--print-to-pdf=")))
        self.assertEqual(profile.parent, staged.parent)
        self.assertEqual(staged.parent.parent, self.temp_root)
        self.assertEqual(profile.name, "profile")
        # Mutating the source after capture must not change what is printed.
        self.source.write_bytes(b"changed after capture")
        self.assertEqual(snapshot.read_bytes(), self.original)
        staged.write_bytes(self.mock_pdf)

    def assert_cleaned(self):
        self.assertEqual(list(self.root.glob(".report-pdf-*.html")), [])
        self.assertEqual(list(self.temp_root.iterdir()), [])

    def test_exact_snapshot_relative_base_and_validated_output(self):
        with patch.object(report_pdf, "_print_with_browser", side_effect=self.printer), \
                patch.object(report_pdf, "_validate_pdf", return_value=3) as validate:
            result = report_pdf.export_pdf(self.source, self.output)
        self.assertEqual(result, {
            "pages": 3, "html_sha256": hashlib.sha256(self.original).hexdigest(),
            "browser": str(self.browser),
        })
        validate.assert_called_once_with(self.mock_pdf)
        self.assertEqual(self.output.read_bytes(), self.mock_pdf)
        self.assert_cleaned()

    def test_existing_output_is_never_overwritten(self):
        self.output.write_bytes(b"previous reviewed PDF")
        with patch.object(report_pdf, "_print_with_browser") as printer:
            with self.assertRaises(FileExistsError):
                report_pdf.export_pdf(self.source, self.output)
        printer.assert_not_called()
        self.assertEqual(self.output.read_bytes(), b"previous reviewed PDF")
        self.assert_cleaned()

    def test_browser_failure_removes_only_owned_artifacts(self):
        other = self.root / ".report-pdf-other.html"
        other.write_bytes(b"unrelated")
        outside = self.temp_root / "unrelated"
        outside.mkdir()
        with patch.object(report_pdf, "_print_with_browser", side_effect=RuntimeError("print failed")):
            with self.assertRaisesRegex(RuntimeError, "print failed"):
                report_pdf.export_pdf(self.source, self.output)
        self.assertFalse(self.output.exists())
        self.assertEqual(list(self.root.glob(".report-pdf-*.html")), [other])
        self.assertEqual(list(self.temp_root.iterdir()), [outside])
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_validation_failure_removes_reserved_output_and_temporary_files(self):
        with patch.object(report_pdf, "_print_with_browser", side_effect=self.printer), \
                patch.object(report_pdf, "_validate_pdf", side_effect=ValueError("unreadable PDF")):
            with self.assertRaisesRegex(ValueError, "unreadable PDF"):
                report_pdf.export_pdf(self.source, self.output)
        self.assertFalse(self.output.exists())
        self.assert_cleaned()

    def test_absent_browser_leaves_no_reserved_output(self):
        with patch.object(report_pdf, "_browser_executable", side_effect=RuntimeError("browser not found")):
            with self.assertRaisesRegex(RuntimeError, "browser not found"):
                report_pdf.export_pdf(self.source, self.output)
        self.assertFalse(self.output.exists())
        self.assert_cleaned()

    def test_invalid_suffix_and_missing_input_fail_before_launch(self):
        with patch.object(report_pdf, "_print_with_browser") as printer:
            with self.assertRaisesRegex(ValueError, "Expected HTML"):
                report_pdf.export_pdf(self.source, self.root / "wrong.txt")
            with self.assertRaises(FileNotFoundError):
                report_pdf.export_pdf(self.root / "missing.html", self.output)
        printer.assert_not_called()
        self.assertFalse(self.output.exists())
        self.assert_cleaned()

    def test_snapshot_collision_does_not_delete_an_unowned_file(self):
        other = self.root / ".report-pdf-collision.html"
        other.write_bytes(b"unrelated")
        with patch.object(report_pdf, "uuid4", return_value=SimpleNamespace(hex="collision")):
            with self.assertRaises(FileExistsError):
                report_pdf.export_pdf(self.source, self.output)
        self.assertEqual(other.read_bytes(), b"unrelated")
        self.assertFalse(self.output.exists())
        self.assertEqual(list(self.temp_root.iterdir()), [])

    def test_source_symlink_preserves_supplied_relative_link_base(self):
        target = self.root / "different-directory" / "target.html"
        target.parent.mkdir()
        target.write_bytes(self.original)
        self.source.unlink()
        try:
            self.source.symlink_to(target)
        except OSError as error:
            self.skipTest(f"Source symlinks unavailable on this filesystem: {error}")
        with patch.object(report_pdf, "_print_with_browser", side_effect=self.printer), \
                patch.object(report_pdf, "_validate_pdf", return_value=1):
            report_pdf.export_pdf(self.source, self.output)
        self.assert_cleaned()


class ReportPDFProcess(unittest.TestCase):
    def test_windows_browser_is_hidden_with_fixed_timeout_and_bounded_error(self):
        process = Mock(pid=4123, returncode=7)

        def spawn(command, **options):
            options["stderr"].write(b"not retained" + b"x" * 7000 + b"tail diagnostic")
            return process

        with patch.object(report_pdf, "_IS_WINDOWS", True), \
                patch.object(report_pdf.subprocess, "Popen", side_effect=spawn) as popen:
            with self.assertRaisesRegex(RuntimeError, "failed \\(7\\)") as error:
                report_pdf._print_with_browser(Path("chrome.exe"), ["--headless=new"])
        self.assertIn("tail diagnostic", str(error.exception))
        self.assertNotIn("not retained", str(error.exception))
        self.assertLess(len(str(error.exception)), 6100)
        self.assertEqual(popen.call_args.kwargs["creationflags"], report_pdf._CREATE_NO_WINDOW)
        self.assertEqual(popen.call_args.kwargs["stdin"], subprocess.DEVNULL)
        self.assertNotIn("shell", popen.call_args.kwargs)
        process.wait.assert_called_once_with(timeout=120)

    def test_timeout_terminates_only_the_spawned_process(self):
        process = Mock(pid=4123, returncode=-9)
        process.wait.side_effect = subprocess.TimeoutExpired("chrome", 120)
        with patch.object(report_pdf.subprocess, "Popen", return_value=process), \
                patch.object(report_pdf, "_terminate_browser") as terminate:
            with self.assertRaisesRegex(RuntimeError, "timed out"):
                report_pdf._print_with_browser(Path("chrome.exe"), ["--headless=new"])
        terminate.assert_called_once_with(process)

    def test_windows_termination_targets_owned_pid_tree(self):
        process = Mock(pid=4123)
        with patch.object(report_pdf, "_IS_WINDOWS", True), \
                patch.object(report_pdf.subprocess, "run") as run:
            report_pdf._terminate_browser(process)
        self.assertEqual(run.call_args.args[0], ["taskkill.exe", "/PID", "4123", "/T", "/F"])
        self.assertEqual(run.call_args.kwargs["creationflags"], report_pdf._CREATE_NO_WINDOW)
        self.assertEqual(run.call_args.kwargs["timeout"], 10)
        process.wait.assert_called_once_with(timeout=10)

    def test_posix_launch_owns_a_new_session(self):
        process = Mock(pid=4123, returncode=0)
        with patch.object(report_pdf, "_IS_WINDOWS", False), \
                patch.object(report_pdf.subprocess, "Popen", return_value=process) as popen:
            report_pdf._print_with_browser(Path("chromium"), ["--headless=new"])
        self.assertTrue(popen.call_args.kwargs["start_new_session"])
        self.assertNotIn("creationflags", popen.call_args.kwargs)


class ReportPDFValidation(unittest.TestCase):
    def test_signature_and_size_are_checked_before_pdf_parser(self):
        for data in (b"", b"%PDF-", b"not PDF" + b"x" * 1100):
            with self.subTest(size=len(data)), self.assertRaisesRegex(ValueError, "invalid signature"):
                report_pdf._validate_pdf(data)

    def test_parser_verifies_pages_and_text_without_layout(self):
        document = Mock()
        document.__enter__ = Mock(return_value=document)
        document.__exit__ = Mock(return_value=False)
        document.__len__ = Mock(return_value=2)
        document.__iter__ = Mock(return_value=iter([Mock(get_text=lambda: ""), Mock(get_text=lambda: "Readable")]))
        parser = Mock(open=Mock(return_value=document))
        data = b"%PDF-1.7\n" + b"x" * 1100
        with patch.dict(sys.modules, {"pymupdf": parser}):
            self.assertEqual(report_pdf._validate_pdf(data), 2)
        parser.open.assert_called_once_with(stream=data, filetype="pdf")
        parser.Story.assert_not_called()

    def test_zero_pages_or_no_readable_text_fail(self):
        for pages, text in ((0, ""), (1, " \n")):
            document = Mock()
            document.__enter__ = Mock(return_value=document)
            document.__exit__ = Mock(return_value=False)
            document.__len__ = Mock(return_value=pages)
            document.__iter__ = Mock(return_value=iter([Mock(get_text=lambda: text)] * pages))
            with self.subTest(pages=pages), patch.dict(sys.modules, {"pymupdf": Mock(open=Mock(return_value=document))}):
                with self.assertRaisesRegex(ValueError, "no readable text"):
                    report_pdf._validate_pdf(b"%PDF-1.7\n" + b"x" * 1100)


class ReportPDFDiscoveryAndCleanup(unittest.TestCase):
    def test_path_browser_is_preferred_without_download(self):
        with tempfile.TemporaryDirectory() as folder:
            browser = Path(folder) / "chromium.exe"
            browser.write_bytes(b"mock installed browser")
            with patch.object(report_pdf.shutil, "which", return_value=str(browser)):
                self.assertEqual(report_pdf._browser_executable(), browser.resolve())

    def test_windows_common_install_path_is_discovered(self):
        with tempfile.TemporaryDirectory() as folder:
            browser = Path(folder) / "Google/Chrome/Application/chrome.exe"
            browser.parent.mkdir(parents=True)
            browser.write_bytes(b"mock installed browser")
            with patch.object(report_pdf.shutil, "which", return_value=None), \
                    patch.dict(report_pdf.os.environ, {"PROGRAMFILES": folder}, clear=True):
                self.assertEqual(report_pdf._browser_executable(), browser.resolve())

    def test_missing_install_has_no_environment_override_or_download(self):
        with patch.object(report_pdf.shutil, "which", return_value=None), \
                patch.object(Path, "is_file", return_value=False), \
                patch.dict(report_pdf.os.environ, {"CHROME_BIN": "not-an-authorized-setting"}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "no browser is downloaded"):
                report_pdf._browser_executable()

    def test_cleanup_rejects_wrong_root_or_prefix_before_recursive_delete(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            for target in (root, root / "other", root.parent / "cosci-report-pdf-other"):
                with self.subTest(target=target), patch.object(report_pdf.shutil, "rmtree") as remove:
                    with self.assertRaisesRegex(ValueError, "Refusing report PDF cleanup"):
                        report_pdf._cleanup_temporary(target, root)
                remove.assert_not_called()

    def test_cleanup_retries_only_the_owned_directory_for_file_locks(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            target = root / "cosci-report-pdf-own"
            target.mkdir()
            with patch.object(report_pdf.shutil, "rmtree", side_effect=[PermissionError("locked"), None]) as remove, \
                    patch.object(report_pdf.time, "sleep") as sleep:
                report_pdf._cleanup_temporary(target, root)
            self.assertEqual([call.args for call in remove.call_args_list], [(target,), (target,)])
            sleep.assert_called_once_with(0.2)

    def test_cleanup_rejects_redirected_private_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve()
            target = root / "cosci-report-pdf-own"
            redirected = root / "cosci-report-pdf-unowned"
            with patch.object(Path, "resolve", return_value=redirected), \
                    patch.object(report_pdf.shutil, "rmtree") as remove:
                with self.assertRaisesRegex(ValueError, "Refusing report PDF cleanup"):
                    report_pdf._cleanup_temporary(target, root)
            remove.assert_not_called()


if __name__ == "__main__":
    unittest.main()
