"""Local Chromium presentation checks; no model or remote browser service."""

from __future__ import annotations

from html.parser import HTMLParser
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest

from researchkit.report import render

HAS_REPORT_DEPENDENCIES = all(
    importlib.util.find_spec(name) for name in ("markdown", "pymupdf")
)
if HAS_REPORT_DEPENDENCIES:
    import markdown
    import pymupdf


class ReportHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
        self.navigation_links = []
        self.links = []
        self.external_resources = []
        self.headings = []
        self.heading = None
        self.in_navigation = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if tag == "nav":
            self.in_navigation = True
        if re.fullmatch(r"h[1-6]", tag):
            self.heading = [tag, attrs.get("id"), []]
        if tag == "a":
            self.links.append(attrs.get("href"))
            if self.in_navigation:
                self.navigation_links.append(attrs.get("href"))
        if tag in {"script", "link"}:
            self.external_resources.extend(
                attrs[key] for key in ("src", "href") if key in attrs
            )

    def handle_endtag(self, tag):
        if tag == "nav":
            self.in_navigation = False
        if self.heading is not None and tag == self.heading[0]:
            self.headings.append((*self.heading[:2], "".join(self.heading[2])))
            self.heading = None

    def handle_data(self, data):
        if self.heading is not None:
            self.heading[2].append(data)


@unittest.skipUnless(HAS_REPORT_DEPENDENCIES, "Optional report dependencies absent")
class ReportPresentation(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def render_text(self, text):
        source = self.root / "authored-report.md"
        source.write_text(text, encoding="utf-8")
        result = render(source, self.root / "rendered")
        document = Path(result["html_path"]).read_text(encoding="utf-8")
        parsed = ReportHTML()
        parsed.feed(document)
        return result, document, parsed

    def test_short_report_requires_no_sections_and_preserves_result_contract(self):
        result, document, parsed = self.render_text("A short authored report.\n")
        self.assertEqual(set(result), {"html_path", "pdf_path", "pages", "renderer", "note", "layout", "layout_note", "style", "citations"})
        self.assertIn("<p>A short authored report.</p>", document)
        self.assertFalse(parsed.navigation_links)
        self.assertNotIn('class="chapter abstract"', document)
        self.assertEqual(result["pages"], 1)
        with pymupdf.open(result["pdf_path"]) as pdf:
            self.assertIn("A short authored report.", pdf[0].get_text())

    def test_heading_navigation_uses_actual_unique_heading_targets(self):
        text = "# 報告\n\n## 方法\n\nFirst section.\n\n## 方法\n\n### Details & limits\n\nLast section.\n"
        _, document, parsed = self.render_text(text)
        converter = markdown.Markdown(extensions=["tables", "fenced_code", "toc"])
        expected_body = converter.convert(text)
        expected = ReportHTML()
        expected.feed(expected_body)
        for heading in expected.headings:
            self.assertIn(heading, parsed.headings)
        # The formal report indexes H2 chapters; H1 remains its hero heading
        # and H3 remains a subsection inside the authored chapter.
        self.assertEqual(len(parsed.navigation_links), 2)
        self.assertEqual(len(set(parsed.navigation_links)), 2)
        for link in parsed.navigation_links:
            self.assertTrue(link.startswith("#"))
            self.assertEqual(parsed.ids.count(link[1:]), 1)
        self.assertFalse(parsed.external_resources)

    def test_markdown_content_and_authored_links_are_preserved_without_inferred_links(self):
        text = (
            "# Evidence and limits\n\n"
            "Authored statement with [a source](https://example.org/paper?q=1&view=full) "
            "and [local evidence](evidence/observations.json).\n\n"
            "`unlinked_observations.csv` remains an inline code span.\n\n"
            "| Record | Value |\n| --- | --- |\n| OBS-A | 17.25 |\n\n"
            "```python\nvalue = 17.25\nprint(value)\n```\n\n"
            "> The conclusion remains conditional.\n"
        )
        result, document, parsed = self.render_text(text)
        self.assertIn('<code>unlinked_observations.csv</code>', document)
        self.assertIn('<td>OBS-A</td>', document)
        self.assertIn('<td>17.25</td>', document)
        self.assertIn('value = 17.25\nprint(value)', document)
        self.assertIn('<blockquote>\n<p>The conclusion remains conditional.</p>\n</blockquote>', document)
        self.assertIn("https://example.org/paper?q=1&view=full", parsed.links)
        local = "../evidence/observations.json"
        self.assertIn(local, parsed.links)
        self.assertEqual((Path(result["html_path"]).parent / local).resolve(),
                         (self.root / "evidence/observations.json").resolve())
        self.assertNotIn("unlinked_observations.csv", parsed.links)
        with pymupdf.open(result["pdf_path"]) as pdf:
            content = "\n".join(page.get_text() for page in pdf)
        for expected in ("OBS-A", "17.25", "unlinked_observations.csv", "print(value)",
                         "The conclusion remains conditional."):
            self.assertIn(expected, content)

    def test_multipage_table_keeps_all_cells_in_reading_order_and_page_bounds(self):
        rows = [f"| ROW{i:04d} | VALUE{i:04d} |" for i in range(100)]
        text = (
            "# Table continuity\n\nBEFORE_TABLE\n\n"
            "| Record | Observation |\n| --- | --- |\n"
            + "\n".join(rows) + "\n\nAFTER_TABLE\n"
        )
        result, _, _ = self.render_text(text)
        with pymupdf.open(result["pdf_path"]) as pdf:
            self.assertGreater(len(pdf), 1)
            content = "\n".join(page.get_text() for page in pdf)
            for page in pdf:
                for word in page.get_text("words"):
                    self.assertGreaterEqual(word[0], 0)
                    self.assertLessEqual(word[2], page.rect.width)
                    self.assertGreaterEqual(word[1], 0)
                    self.assertLessEqual(word[3], page.rect.height)
        self.assertIn("BEFORE_TABLE", content)
        self.assertIn("AFTER_TABLE", content)
        self.assertIn("Record", content)
        self.assertIn("Observation", content)
        for index in range(100):
            self.assertEqual(content.count(f"ROW{index:04d}"), 1)
            self.assertEqual(content.count(f"VALUE{index:04d}"), 1)
            self.assertLess(content.index(f"ROW{index:04d}"), content.index(f"VALUE{index:04d}"))
            if index:
                self.assertLess(content.index(f"VALUE{index - 1:04d}"), content.index(f"ROW{index:04d}"))
        self.assertLess(content.index("BEFORE_TABLE"), content.index("ROW0000"))
        self.assertLess(content.index("VALUE0099"), content.index("AFTER_TABLE"))

    def test_table_heading_stays_with_first_data_at_page_boundary(self):
        for line_count in range(44, 51):
            with self.subTest(line_count=line_count):
                source = self.root / f"boundary-{line_count}.md"
                source.write_text(
                    "\n".join(["Preface  "] * line_count) + "\n\n"
                    "| COLUMN_ALPHA | COLUMN_BETA |\n| --- | --- |\n"
                    "| FIRST_DATA | FIRST_VALUE |\n| LAST_DATA | LAST_VALUE |\n",
                    encoding="utf-8",
                )
                result = render(source, self.root / f"boundary-{line_count}")
                with pymupdf.open(result["pdf_path"]) as pdf:
                    pages = [p.get_text() for p in pdf]
                heading_page = next(i for i, text in enumerate(pages) if "COLUMN_ALPHA" in text)
                first_page = next(i for i, text in enumerate(pages) if "FIRST_DATA" in text)
                self.assertEqual(heading_page, first_page)
                content = "".join(pages)
                for cell in ("FIRST_DATA", "FIRST_VALUE", "LAST_DATA", "LAST_VALUE"):
                    self.assertEqual(content.count(cell), 1)

    def test_existing_report_directory_and_files_are_not_overwritten(self):
        source = self.root / "authored-report.md"
        source.write_text("New report body.\n", encoding="utf-8")
        destination = self.root / "existing"
        destination.mkdir()
        originals = {"report.html": b"previous reviewed HTML", "report.pdf": b"previous reviewed PDF"}
        for name, data in originals.items():
            (destination / name).write_bytes(data)
        with self.assertRaises(FileExistsError):
            render(source, destination)
        for name, data in originals.items():
            self.assertEqual((destination / name).read_bytes(), data)


if __name__ == "__main__":
    unittest.main()
