"""Reader-first reports: notes as superscript letters, appendices, a separate evidence file, style counts."""

import hashlib
from pathlib import Path
import re
from unittest.mock import patch

import pymupdf
import pytest

from researchkit import report_citations, report_html
from researchkit.report import render
from researchkit.report_style import plain_labels, style_report

READER = ["摘要", "1. 結論：兩筆歷史資料能回答什麼", "2. 機制：酸預算與溶解對比", "3. 證據", "4. 候選與建議實驗",
          "5. 限制與未解問題", "附錄 A. 研究過程與方法"]


def markdown(headings, body="Text.", notes=""):
    return "# Report\n\n" + "\n\n".join(f"## {h}\n\n{body}" for h in headings) + "\n\n" + notes


def build(tmp_path, text, **kwargs):
    source = tmp_path / "report.md"
    source.write_text(text, encoding="utf-8")
    return report_html.build_html(source, tmp_path / "out", evidence=kwargs.get("evidence", []),
                                  mindmaps=kwargs.get("mindmaps", []))


def evidence(text="Saved original.\n"):
    raw = text.encode("utf-8")
    return {"record_ref": ".research/records/" + "c" * 64 + "/record.json", "source_path": "work/values.json",
            "title": "Saved values", "kind": "implementation", "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw), "text": text}


def chapters(document):
    return re.findall(r'<div class="chapter-title"><span>([^<]*)</span><h2[^>]*>(.*?)</h2>', document)


def test_notes_are_letters_collected_in_an_appendix_and_citations_stay_numbers(tmp_path):
    text = ("# Report\n\n## 1. 結論\n\nEOP falls with acid yield.[^yield] The scale was anchored.[^anchor] "
            "Measured.[1](#evidence-1)\n\n[^yield]: Two records only; see appendix A.\n"
            "[^anchor]: Offset −11.2 mJ from the measured values.\n")
    document = build(tmp_path, text)
    refs = re.findall(r'<a [^>]*class="footnote-ref" href="#fn-(\w+)"[^>]*>([^<]+)</a>', document)
    assert [label for _, label in refs] == ["a", "b"]
    assert re.search(r'<a aria-label="內部證據 E1" class="citation"[^>]*>E1</a>', document)
    assert chapters(document)[-1] == ("附錄", "註解")
    assert "Two records only" in document and 'class="footnote-backref"' in document
    assert report_html._note_label(27) == "aa"


def test_the_reader_layout_puts_notes_maps_and_evidence_in_appendices(tmp_path):
    maps = [{"content": {"opaque": "one"}, "record_ref": "exact-one"}]
    with patch("researchkit.report_mindmap.render_mindmap", return_value='<figure data-test-map="one"></figure>'):
        document = build(tmp_path, markdown(READER, "Text.[^n]", "[^n]: A note.\n"),
                         evidence=[evidence()], mindmaps=maps)
    titles = chapters(document)
    assert [t for _, t in titles][-4:] == ["附錄 A. 研究過程與方法", "附錄：註解", "附錄：研究心智圖", "附錄：內部研究證據索引"]
    assert [label for label, _ in titles][-4:] == ["附錄"] * 4
    assert [label for label, _ in titles][1:6] == ["01", "02", "03", "04", "05"]
    assert 'class="generic-report"' not in document
    assert "Saved original." not in document and "evidence.html#evidence-1" in document


def test_layout_status_names_the_reader_layout_and_the_first_difference(tmp_path):
    def status(headings):
        source = tmp_path / "status.md"
        source.write_text(markdown(headings), encoding="utf-8")
        return report_html.layout_status(source)

    assert status(READER)["layout"] == "reader"
    wrong = list(READER)
    wrong[3] = "3. 研究流程"
    result = status(wrong)
    assert result["layout"] == "generic"
    assert result["first_difference"] == {"position": 4, "expected": "3. 證據", "found": "3. 研究流程"}


def test_style_counts_asides_emphasis_stock_phrases_and_hashes_in_prose_only():
    draft = ("## 1. 結論\n\n**誠實地說**，這不是公式的問題，而是資料的問題（只有兩筆）。值得注意的是"
             "（見 `20a8143b…`），結果（P1）仍然一致（在誤差內）。事實上，**關鍵**在於酸量（mJ）。\n\n"
             "| 樣本 | EOP (mJ) |\n|---|---|\n| H1 | 53.7 (實測) |\n\n```python\nprint('(code)')\n```\n\n"
             "[^a]: 註解裡的（括號）不算。\n")
    result = style_report(draft)
    counts = result["counts"]
    assert counts["parentheses"] == 5 and counts["bold"] == 2 and counts["contrast_not_but"] == 1
    assert counts["phrases"] == {"誠實": 1, "值得注意": 1, "事實上": 1} and counts["hashes_or_paths_in_prose"] == 1
    assert counts["note_definitions"] == 1
    advice = " ".join(result["advice"])
    assert len(result["advice"]) == 3 and "括號" in advice and "套話 「誠實」" in advice and "雜湊" in advice
    clean = "## 1. 結論\n\n產酸量每增加一成，EOP 約降低 4 mJ，這與兩筆歷史資料的方向一致。[^n]\n\n[^n]: 細節。\n"
    assert style_report(clean)["advice"] == []



def test_a_bold_label_opening_a_paragraph_prints_plain_and_a_defined_term_stays_bold(tmp_path):
    # A run (2026-11-01) opened 44 paragraphs with bold labels, and 18 after the report rules named the habit.
    text = ("# R\n\n## 1. 結論\n**光子吸收與產酸。** 每個光子產生酸。\n\n**資料與計分**：兩筆紀錄。\n\n"
            "**LCDU** 是線寬的局部均勻度。\n\n- **P1**：一條公式。\n\n> **白話說**　框裡的標籤。\n\n"
            "```\n**不動。** 程式碼\n```\n")
    assert plain_labels(text) == text.replace("**光子吸收與產酸。**", "光子吸收與產酸。").replace(
        "**資料與計分**", "資料與計分")
    html = build(tmp_path, text)
    assert "<strong>LCDU</strong>" in html and "<strong>P1</strong>" in html and "<strong>白話說</strong>" in html
    assert "光子吸收與產酸。 每個光子產生酸。" in html and "<strong>資料與計分</strong>" not in html
    # Counted as printed: the labels no longer count as bold.
    assert style_report(text)["counts"]["bold"] == 3


def test_equations_become_mathml_while_prices_and_code_stay_literal(tmp_path):
    text = ("# Report\n\n## 1. 結論\n\nDose $E_0$ and diffusion\n\n$$L = \\sqrt{D t}$$\n\n"
            "It costs $5 and $10. Code `$x_1$` stays.\n")
    document = build(tmp_path, text)
    body = document[document.index("<body"):]
    assert len(re.findall(r'<math [^>]*display="inline"', body)) == 1
    assert len(re.findall(r'<math [^>]*display="block"', body)) == 1
    assert "<msub><mi>E</mi><mn>0</mn></msub>" in body and "<msqrt>" in body
    assert "costs $5 and $10." in body and "<code>$x_1$</code>" in body
    with patch("latex2mathml.converter.convert", side_effect=ValueError("unreadable")):
        fallback = build(tmp_path, "# Report\n\n## 1. 結論\n\nDose $E_0$.\n")
    assert '<code class="math-source">E_0</code>' in fallback
    assert style_report("## 1. 結論\n\n酸濃度 $f(E) = 1 - e^{-CE}$ 隨劑量上升。\n")["counts"]["parentheses"] == 0


CITED = ("# Report\n\n## 1. 結論\n\nAcid yield sets EOP.[@kozawa] Diffusion blurs it.[@tsubaki; @kozawa] "
         "Unknown.[@missing] Code `[@literal]` stays.\n\n## 附錄 A. 方法\n\nSteps.\n\n"
         "[@tsubaki]: H. Tsubaki et al., \"EUV Resist Materials Design,\" *J. Photopolym. Sci. Technol.* 26, 649 "
         "(2013). doi:10.2494/photopolymer.26.649\n"
         "[@kozawa]: T. Kozawa and S. Tagawa, \"Radiation Chemistry in Chemically Amplified Resists,\"\n"
         "    *Jpn. J. Appl. Phys.* 49, 030001 (2010). https://doi.org/10.1143/JJAP.49.030001\n"
         "[@unread]: A. Author, \"A paper nobody fetched,\" Journal 1, 1 (2020). doi:10.9999/unread.1\n"
         "[@kozawa]: Second definition of the same key.\n"
         "[@bare]: Someone, a talk without any identifier.\n")


def test_literature_citations_are_numbered_by_first_citation_and_listed_before_the_appendices(tmp_path):
    document = build(tmp_path, CITED)
    marks = re.findall(r'<sup class="literature-cite">(.*?)</sup>', document)
    labels = [re.sub(r"<[^>]+>", "", mark) for mark in marks]
    assert labels == ["[1]", "[1, 2]", "[?missing]"]
    assert '<a href="#literature-1">1</a>' in marks[0] and "<code>[@literal]</code>" in document
    rows = re.findall(r'<li id="(literature-\d+)"><span class="ref-number">\[(\d+)\]</span><div>(.*?)</div></li>',
                      document)
    assert [(identity, number) for identity, number, _ in rows] == [
        ("literature-1", "1"), ("literature-2", "2"), ("literature-3", "3"), ("literature-4", "4")]
    assert "Radiation Chemistry" in rows[0][2] and "<em>Jpn. J. Appl. Phys.</em>" in rows[0][2]
    assert '<a href="https://doi.org/10.1143/JJAP.49.030001">' in rows[0][2]
    assert '<a href="https://doi.org/10.2494/photopolymer.26.649">10.2494/photopolymer.26.649</a>' in rows[1][2]
    assert "Second definition" not in document and "[@tsubaki]:" not in document
    assert chapters(document) == [("01", "1. 結論"), ("文獻", "參考文獻"), ("附錄", "附錄 A. 方法")]


def test_an_authored_reference_heading_receives_the_list_where_the_author_put_it(tmp_path):
    text = ("# Report\n\n## 1. 結論\n\nCited.[@a]\n\n## 參考文獻\n\nWorks cited in the text.\n\n"
            "## 2. 後記\n\nMore.\n\n[@a]: A. Author, Title (2020). https://example.org/a\n")
    titles = chapters(build(tmp_path, text))
    assert titles == [("01", "1. 結論"), ("文獻", "參考文獻"), ("02", "2. 後記")]


def test_citation_check_names_missing_uncited_duplicate_bare_and_unsaved_entries(tmp_path):
    research = tmp_path / ".research"
    (research / "searches").mkdir(parents=True)
    (research / "searches" / "s.json").write_text(
        '{"items": [{"title": "x", "doi": "10.1143/jjap.49.030001", "url": "https://doi.org/10.1143/jjap.49.030001"}]}',
        encoding="utf-8")
    document = research / "documents" / "d1"
    document.mkdir(parents=True)
    (document / "source.json").write_text('{"requested_url": "https://www.jstage.jst.go.jp/article/x/_pdf"}',
                                          encoding="utf-8")
    (document / "text.txt").write_text("Title\nDOI: 10.2494/photopolymer.26.649\n", encoding="utf-8")
    (research / "agent-literature").mkdir()
    (research / "agent-literature" / "a.json").write_text(
        '{"result": {"references": ["https://arxiv.org/abs/2101.00001v2"]}}', encoding="utf-8")
    saved = report_citations.saved_identifiers(research)
    assert {"doi:10.1143/jjap.49.030001", "doi:10.2494/photopolymer.26.649", "arxiv:2101.00001",
            "url:jstage.jst.go.jp/article/x/_pdf"} <= saved
    result = report_citations.check(CITED, saved)
    assert (result["references"], result["cited"]) == (4, 2)
    assert result["undefined"] == ["missing"] and result["uncited"] == ["unread", "bare"]
    assert result["duplicates"] == ["kozawa"] and result["without_identifier"] == ["bare"]
    assert result["not_in_saved_literature"] == ["unread"]
    assert len(result["advice"]) == 5
    assert "not_in_saved_literature" not in report_citations.check(CITED)
    nudge = report_citations.check("# R\n\n## 1. 結論\n\nNo literature here.\n", saved)
    assert nudge["advice"] and "[@鍵]" in nudge["advice"][0]


def test_bibliography_entries_are_not_counted_as_prose():
    text = ("## 1. 結論\n\n產酸量決定 EOP。[@kozawa]\n\n"
            "[@kozawa]: T. Kozawa (2010), Jpn. J. Appl. Phys. 49(3), 030001.\n")
    counts = style_report(text)["counts"]
    assert counts["parentheses"] == 0 and counts["literature_citations"] == 1 and counts["note_definitions"] == 0


def test_a_rendered_report_keeps_notes_and_sends_originals_to_a_separate_pdf(tmp_path):
    source = tmp_path / "report.md"
    source.write_text(markdown(READER[:6], "產酸量決定 EOP。[^n]", "[^n]: NOTE_TEXT_IN_APPENDIX\n"), encoding="utf-8")
    result = render(source, tmp_path / "rendered", evidence=[evidence("ORIGINAL_TEXT_ONLY_IN_EVIDENCE\n")])
    assert result["layout"]["layout"] == "reader" and "Reader layout" in result["layout_note"]
    with pymupdf.open(result["pdf_path"]) as pdf:
        text = "".join(page.get_text() for page in pdf)
    assert "NOTE_TEXT_IN_APPENDIX" in text and "ORIGINAL_TEXT_ONLY_IN_EVIDENCE" not in text
    with pymupdf.open(result["evidence_pdf_path"]) as pdf:
        assert "ORIGINAL_TEXT_ONLY_IN_EVIDENCE" in "".join(page.get_text() for page in pdf)
    assert result["style"]["advice"] == []
