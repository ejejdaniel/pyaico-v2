"""Offline replay of the actual report-review request, never a scientific review.

The commission and source selection are explicitly scripted test inputs, not
choices made by an autonomous agent. No reviewer response is fabricated. The
transport captures the prepared OpenAI-compatible request and raises a sentinel.

Set REPORT_REVIEW_PACKET_DIR to retain private diagnostics; otherwise pytest's
tmp_path owns them. These diagnostics are not research records or public formats.
"""

from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace
import threading
from unittest.mock import Mock

import httpx
import pytest

from opencode.app import App
from opencode.permission import Rule
from opencode.store import Store
from researchkit import records, reviewer
from researchkit.tools import TOOLS


PROJECT = Path(__file__).resolve().parents[2]
HISTORY = PROJECT / "outputs/lit_report_delivery_20261021_v3"
SAVED_WORKSPACE = PROJECT / "outputs/lit_current_e2e_20261020_v1/workspace"
REPORT_SOURCES = PROJECT / "outputs/report_narrative_revision_20261021_v6/sources"
REPORT_NAMES = ("report_zh.md", "report_zh_easy.md")

# Questions, standards and access limits only: no expected scientific findings,
# numerical answers, decisions, or historical review conclusions are injected.
SCRIPTED_SCOPE = """This is a scripted offline report-review commission prepared by
the replay test, not an autonomous agent's choice of scope or sources. Assess the
selected formal report and readable companion against the selected saved sources.
Trace consequential mechanism claims through their proposed causal chain and
identify the support and limits of each necessary link. Distinguish a formula's
qualitative directional rationale from the justification of its numerical form,
coefficients, reference values and thresholds; distinguish implementation fidelity,
saved execution observations, calibration and independent validation. Examine
whether the saved evidence supports the described candidate proposal, comparison,
selection and retention reasons, and distinguish saved reasons and iteration
history from retrospective explanation. Check whether each consequential citation
supports the claim attributed to it at the access level actually evidenced. Compare
the two report versions for consistency of scientific claims, attribution, numerical
meaning and limitations; readability alone does not establish equivalent coverage.
Use the supplied sources to reach your own assessments without assuming the reports
or earlier assessments are correct. State missing evidence and the affected scope.

Access limits: the selected literature file is an author-written synthesis. No
original literature-provider response, original paper full text, or original source
receipt is selected here. You may compare the reports with that saved synthesis,
but may not claim to have checked the original literature or independently verified
its reported access level. Only explicitly selected file contents are supplied;
other files named in reports or manifests are not implicitly available. A missing
report version prevents a conclusion that both versions were reviewed. This is a
read-only commission; do not execute, repair, publish, or complete the parent task.
"""


class PacketCaptured(BaseException):
    """Intentional stop before any HTTP response or model completion exists."""


def _sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def _json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _selected_sources():
    # Use only the explicitly selected evidence of this historical render call;
    # its report and old reviewer response are deliberately not reused as evidence.
    call, = _json(HISTORY / "response-010.json")["tool_calls"]
    assert call["name"] == "render_report"
    return call["arguments"]["mindmap_files"] + call["arguments"]["evidence_files"]


def _copy_selected_sources(root, selection):
    expected = {}
    for locator in selection:
        ref, source = locator["record_ref"], locator["source_path"]
        original = SAVED_WORKSPACE / ref
        manifest_bytes = original.read_bytes()
        assert _sha256(manifest_bytes) == Path(ref).parent.name
        manifest = json.loads(manifest_bytes)
        entry, = [item for item in manifest["files"] if item["source_path"] == source]
        raw = (original.parent / entry["snapshot"]).read_bytes()
        assert len(raw) == entry["bytes"] and _sha256(raw) == entry["sha256"]
        target_manifest = root / ref
        target_manifest.parent.mkdir(parents=True, exist_ok=True)
        target_manifest.write_bytes(manifest_bytes)
        target = target_manifest.parent / entry["snapshot"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        expected[(ref, source)] = raw
    return expected


def _decode_delivered_files(message):
    # Parse the current reviewer's numbered sections, without calling a test
    # formatter or reconstructing the request from args instead of the transport.
    lines = message.split("\n")
    assert lines[0] == "Review commission (scope):"
    assert json.loads(lines[1]) == SCRIPTED_SCOPE
    assert lines[2] == "Reviewed record references (reviewed_refs):"
    delivered = {}
    for index in range(4, len(lines), 4):
        assert lines[index] == "Selected frozen file:"
        locator = json.loads(lines[index + 1])
        assert locator["file_id"] == "F" + str((index - 4) // 4 + 1)
        assert lines[index + 2] == "Numbered UTF-8 lines (JSON array; numbers are not source content):"
        key = (locator["record_ref"], locator["source_path"])
        assert key not in delivered
        numbered = json.loads(lines[index + 3])
        assert [number for number, _ in numbered] == list(range(1, len(numbered) + 1))
        delivered[key] = [text for _, text in numbered]
    return json.loads(lines[3]), delivered


