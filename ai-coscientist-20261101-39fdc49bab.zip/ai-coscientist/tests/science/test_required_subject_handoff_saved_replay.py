"""Replay the saved selector handoff without new model or network calls.

The original rejected second response stays rejected. These tests establish
only transport, quoting, persistence and format boundaries, not the validity of
the saved scientific judgments or completion of the original research task.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import socket
from types import SimpleNamespace

import httpx
import pytest

from opencode.permission import Broker, Rule
from opencode.provider import Completion
from researchkit import reviewer


SOURCE = (Path(__file__).resolve().parents[2]
          / "outputs/revision_identity_real_20261023_v1")
REQUIRED_LABEL = "Required exact subjects (one-based positions; every subject must be judged):"


def _json(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _hashes(paths):
    return {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def _completion(saved):
    assert saved["tool_calls"] == [] and saved["finish_reason"] == "stop"
    return Completion(text=saved["text"], finish_reason=saved["finish_reason"],
                      reasoning_content=saved["reasoning_content"])


def _raw_checks(saved):
    # The saved response has this exact wrapper; do not repair either answer.
    text = saved["text"]
    assert text.startswith("```json\n") and text.endswith("\n```")
    return json.loads(text[len("```json\n"):-len("\n```")])["checks"]


def _frozen_lines(message):
    sections = message.split("\n")
    return {json.loads(sections[index + 1])["file_id"]:
            [line for _, line in json.loads(sections[index + 3])]
            for index, section in enumerate(sections) if section == "Selected frozen file:"}


def _without_origin_headers(message):
    """Compare the original selected packet after the approved metadata addition."""
    lines = message.split("\n")
    for index, line in enumerate(lines):
        if line != "Selected frozen file:":
            continue
        metadata = json.loads(lines[index + 1])
        lines[index + 1] = json.dumps({key: metadata[key] for key in (
            "file_id", "record_ref", "source_path")}, ensure_ascii=False)
        lines[index + 2] = "Numbered UTF-8 lines (JSON array; numbers are not source content):"
    return "\n".join(lines)


def _expected_evidence(check, frozen):
    return [{**item, "quote": "\n".join(
        frozen[item["file_id"]][item["start_line"] - 1:item["end_line"]])}
        for item in check["evidence"]]


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Saved handoff replay must never call a model or network")

    monkeypatch.setattr(reviewer, "complete_once", forbidden)
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)


@pytest.fixture
def saved_packet(tmp_path):
    required = [SOURCE / name for name in (
        "response-002.json", "response-003.json", "response-004.json",
        "request-003.json", "request-004.json", "review-failure-boundary.json")]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        pytest.skip("Saved real evidence unavailable; no substitute fixture: " + ", ".join(missing))
    before = _hashes(required)
    try:
        call, = _json(SOURCE / "response-002.json")["tool_calls"]
        assert call["name"] == "research_review"
        # Planning is outside this reviewer-local replay; keep its saved inputs
        # untouched and select only the already-existing review arguments.
        args = {key: value for key, value in call["arguments"].items() if key != "revision_plan"}
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        for locator in args["files"]:
            manifest_path = SOURCE / "baseline/workspace" / locator["record_ref"]
            if not manifest_path.is_file():
                pytest.skip(f"Saved selected manifest unavailable; no substitute fixture: {manifest_path}")
            entry, = [item for item in _json(manifest_path)["files"]
                      if item["source_path"] == locator["source_path"]]
            source = manifest_path.parent / entry["snapshot"]
            if not source.is_file():
                pytest.skip(f"Saved selected snapshot unavailable; no substitute fixture: {source}")
            for original, target in (
                (manifest_path, workspace / locator["record_ref"]),
                (source, workspace / Path(locator["record_ref"]).parent / entry["snapshot"]),
            ):
                before.update(_hashes([original]))
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(original, target)
        identity = _json(SOURCE / "review-failure-boundary.json")
        ctx = SimpleNamespace(
            directory=workspace, worktree=workspace, read_files=set(),
            session_id=identity["session_id"], message_id=identity["message_id"],
            call_id=identity["call_id"], agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
            app=SimpleNamespace(permissions=Broker(auto=True)),
        )
        yield SimpleNamespace(
            args=args, ctx=ctx, workspace=workspace,
            initial=_json(SOURCE / "response-003.json"),
            rejected=_json(SOURCE / "response-004.json"),
            first_request=_json(SOURCE / "request-003.json"),
            historical_followup=_json(SOURCE / "request-004.json"),
        )
    finally:
        assert _hashes(before) == before, "Selected saved requests, responses and frozen sources must remain byte-identical"


def test_raw_initial_reaches_followup_as_selectors_and_original_second_answer_stays_rejected(
        saved_packet, monkeypatch):
    packet = saved_packet
    initial_checks = _raw_checks(packet.initial)
    assert [check["subject"] for check in initial_checks] == [
        {"required_subject": 1}, {"required_subject": 2}, {"required_subject": 3}]
    # Record the original defect without altering or adopting the public form.
    historical_message = packet.historical_followup["messages"][0]["content"]
    historical_handoff = json.loads(historical_message.split(reviewer.HANDOFF_LABEL + "\n", 1)[1])
    assert [check["subject"] for check in historical_handoff["checks"]] == packet.args["required_subjects"]
    assert all(set(check["subject"]) == {"record_ref", "source_path", "quote"}
               for check in _raw_checks(packet.rejected))
    sent, readback_at_followup = [], []

    def replay(ctx, *, system, messages, **kwargs):
        assert ctx is packet.ctx
        sent.append({"system": system, "messages": deepcopy(messages)})
        assert len(sent) <= 2, "The saved invalid response must not trigger a repair or retry"
        if len(sent) == 2:
            saved, = (packet.workspace / ".research/review-runs").glob("*/initial")
            readback_at_followup.append({path.name: path.read_bytes() for path in saved.iterdir()})
        return _completion(packet.initial if len(sent) == 1 else packet.rejected)

    monkeypatch.setattr(reviewer, "complete_once", replay)
    with pytest.raises(ValueError, match="review locator: expected exactly file_id, start_line, end_line, quote") as caught:
        reviewer.execute(packet.args, packet.ctx)
    assert "初審已保存、複核未完成" in str(caught.value)
    assert len(sent) == 2 and len(readback_at_followup) == 1
    first = sent[0]["messages"][0]["content"]
    # The saved request predates host-computed facts, which are appended after the selected files.
    saved_part, facts = first.split("\n\nHost-computed facts", 1)
    assert facts.startswith(" (calculated by the host from the selected sources")
    # So does the coverage checklist, two lines placed before the required subjects.
    head, checklist = saved_part.split("\nCoverage checklist (host-computed): ", 1)
    saved_part = head + "\n" + checklist.split("\n", 2)[2]
    assert _without_origin_headers(saved_part) == packet.first_request["messages"][0]["content"]
    assert _frozen_lines(first) == _frozen_lines(packet.first_request["messages"][0]["content"])
    second = sent[1]["messages"][0]["content"]
    prefix = first + "\n\n" + reviewer.HANDOFF_LABEL + "\n"
    assert second.startswith(prefix)
    appended = second[len(prefix):]
    handoff = json.loads(appended)
    frozen = _frozen_lines(first)
    expected = {"checks": [{"subject": check["subject"], "evidence": _expected_evidence(check, frozen)}
                           for check in initial_checks]}
    assert handoff == expected
    assert appended == json.dumps(expected, ensure_ascii=False, separators=(",", ":"))
    required_section = json.dumps(list(enumerate(packet.args["required_subjects"], start=1)), ensure_ascii=False)
    assert REQUIRED_LABEL + "\n" + required_section in first
    assert REQUIRED_LABEL + "\n" + required_section in second
    for check in handoff["checks"]:
        assert set(check) == {"subject", "evidence"}
        assert set(check["subject"]) == {"required_subject"}
        assert all(set(item) == {"file_id", "start_line", "end_line", "quote"}
                   for item in check["evidence"])
    for check in initial_checks:
        assert check["reason"] not in second
    assert '"decision"' not in appended and '"reason"' not in appended
    saved = readback_at_followup[0]
    assert set(saved) == {"arguments.json", "response.txt", "review.json"}
    assert saved["response.txt"] == packet.initial["text"].encode("utf-8")
    assert json.loads(saved["arguments.json"]) == packet.args
    public = json.loads(saved["review.json"])
    assert set(public) == {"reviewed_refs", "checks"}
    assert public["reviewed_refs"] == packet.args["reviewed_refs"]
    assert [check["subject"] for check in public["checks"]] == packet.args["required_subjects"]
    assert [(check["decision"], check["reason"]) for check in public["checks"]] == [
        (check["decision"], check["reason"]) for check in initial_checks]
    saved_folder, = (packet.workspace / ".research/review-runs").glob("*/initial")
    assert {path.name: path.read_bytes() for path in saved_folder.iterdir()} == saved
    assert {path.relative_to(saved_folder.parent).as_posix()
            for path in saved_folder.parent.rglob("*") if path.is_file()} == {
        "initial/arguments.json", "initial/response.txt", "initial/review.json",
        # The rejected followup reply is kept in full for diagnosis.
        "rejected-followup.txt"}


@pytest.mark.parametrize("with_required_list", [False, True])
def test_general_four_field_subjects_and_frozen_evidence_quotes_keep_existing_projection(
        saved_packet, with_required_list):
    packet = saved_packet
    _, message, _, _, selection = reviewer._input(packet.args, packet.ctx)
    frozen = _frozen_lines(message)
    # This explicitly constructed locator-only test variation is not a new
    # model answer. Never rewrite the original rejected response-004.
    checks = deepcopy(_raw_checks(packet.initial))
    for check in checks:
        subject = packet.args["required_subjects"][check["subject"]["required_subject"] - 1]
        file_id, = [file_id for file_id, selected in selection.items()
                    if (selected["record_ref"], selected["source_path"])
                    == (subject["record_ref"], subject["source_path"])]
        line, = [number for number, text in enumerate(frozen[file_id], start=1) if subject["quote"] in text]
        check["subject"] = {"file_id": file_id, "start_line": line, "end_line": line, "quote": subject["quote"]}
    before = deepcopy(checks)
    required = packet.args["required_subjects"] if with_required_list else []
    handoff = json.loads(reviewer._candidate_handoff(json.dumps({"checks": checks}), selection, required))
    assert handoff == {"checks": [
        {"subject": check["subject"], "evidence": _expected_evidence(check, frozen)} for check in checks]}
    assert all(set(check["subject"]) == {"file_id", "start_line", "end_line", "quote"}
               for check in handoff["checks"])
    assert any(item["end_line"] > item["start_line"]
               for check in handoff["checks"] for item in check["evidence"])
    assert checks == before
