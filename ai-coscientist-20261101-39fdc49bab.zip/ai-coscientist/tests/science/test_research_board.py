"""Read-only research board: derived from saved records, no model calls."""

import json
import os
from pathlib import Path

import pytest

from opencode.provider import Completion, ToolCall
from researchkit import board, records
from tests.prompt_view import host_facts, plain_messages


def save(root, kind, files, depends_on=(), title=None):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=title or kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def score(n):
    return {"direction": "higher", "kendall_tau_b": 1.0, "spearman_rho": 1.0, "sample_count": n}


@pytest.fixture
def chain(tmp_path):
    task = save(tmp_path, "task", {"task.md": "Rank formulations by EOP"})
    hypotheses = save(tmp_path, "hypothesis", {
        "h/hypotheses.md": "H1 and H2 prose",
        "h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "Acid lability drives EOP"},
                                             {"id": "H2", "statement": "Diffusion length drives EOP"}]}},
        [task])
    formula = save(tmp_path, "proxy_formula", {
        "p/proxy_formula.md": "S = f * L",
        "p/proxy_formula.json": {"formula_id": "P1", "expression": "S = f * L", "hypothesis_ids": ["H1"]}},
        [hypotheses])
    impl = save(tmp_path, "implementation", {"impl/proxy.py": "print(1)"}, [formula])
    calibration = save(tmp_path, "calibration", {".research/calibrations/a.json": score(2)}, [impl, formula])
    return tmp_path, task, hypotheses, formula, calibration


def test_template_links_each_hypothesis_to_its_formula_and_score(chain):
    root, task, hypotheses, formula, calibration = chain
    value = board.build(root)
    h, = value["hypotheses"]
    assert [item["id"] for item in h["items"]] == ["H1", "H2"]
    assert h["items"][0]["proxy_formula_refs"] == [formula["record_path"]]
    assert h["items"][1]["proxy_formula_refs"] == []
    p, = value["proxy_formulas"]
    assert p["hypothesis_refs"] == [hypotheses["record_path"]]
    assert p["template"]["hypothesis_ids"] == ["H1"]
    assert p["calibrations"] == [{"ref": calibration["record_path"], **score(2), "adjusted_tau": None,
                                  "p_two_sided": None}]
    notices = "\n".join(value["notices"])
    assert "沒有對應公式的假說：H2。" in notices
    assert "只有 2 筆樣本" in notices
    assert "沒有依賴任何 hypothesis" not in notices


def test_without_templates_falls_back_to_whole_record_and_says_so(tmp_path):
    task = save(tmp_path, "task", {"task.md": "goal"})
    hypothesis = save(tmp_path, "hypothesis", {"hypotheses.md": "H1-H5 prose"}, [task])
    save(tmp_path, "proxy_formula", {"proxy_formula.md": "S = f * L"}, [hypothesis])
    value = board.build(tmp_path)
    assert value["hypotheses"][0]["items"] is None
    assert value["proxy_formulas"][0]["template"] is None
    notices = "\n".join(value["notices"])
    assert "看不出對應哪一條假說" in notices
    assert "尚無依賴它的 calibration" in notices
    assert "未附可用的 hypotheses.json" in board.render(value)


def test_formula_without_hypothesis_and_unknown_ids_are_noticed(tmp_path):
    task = save(tmp_path, "task", {"task.md": "goal"})
    save(tmp_path, "proxy_formula", {"a/proxy_formula.json": {"expression": "x", "hypothesis_ids": ["H9"]}}, [task])
    hypothesis = save(tmp_path, "hypothesis", {
        "hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "s"}]}}, [task])
    save(tmp_path, "proxy_formula", {"b/proxy_formula.json": {"expression": "y", "hypothesis_ids": ["H1", "H7"]}},
         [hypothesis])
    notices = "\n".join(board.build(tmp_path)["notices"])
    assert "沒有依賴任何 hypothesis 紀錄" in notices
    assert "找不到：H7" in notices
    assert "H9" not in notices  # no linked hypothesis: already reported as unlinked


@pytest.mark.parametrize("content", ["not json", {"hypotheses": [{"id": "H1"}]},
                                     {"hypotheses": [{"id": "H1", "statement": "a"}, {"id": "H1", "statement": "b"}]}])
def test_malformed_template_is_a_notice_not_a_failure(tmp_path, content):
    save(tmp_path, "hypothesis", {"hypotheses.json": content})
    value = board.build(tmp_path)
    assert value["hypotheses"][0]["items"] is None
    assert any("hypotheses.json" in notice for notice in value["notices"])


def test_comparisons_and_unknown_kinds_are_listed_without_checking_values(chain):
    root, task, hypotheses, formula, calibration = chain
    comparison = {"method_ref": formula["record_path"], "direction": "higher",
                  "best_baseline": {"ids": ["hist_2"], "value": 1.0},
                  "best_candidate": {"ids": ["c3"], "value": 2.5}, "comparison": "better"}
    save(root, "implementation", {"cmp/comparison.json": comparison}, [formula])
    save(root, "sample_evolution", {"evo.json": {"claims": "beats hist_2"}}, [formula], title="Round 1")
    value = board.build(root)
    assert value["comparisons"][0]["best_candidate"] == {"ids": ["c3"], "value": 2.5}
    assert list(value["other_kinds"]) == ["sample_evolution"]
    text = board.render(value)
    assert "最佳候選 c3=2.5" in text
    assert "其他 kind sample_evolution：1 筆，宿主未核對其中數值" in text


def test_only_human_messages_are_listed(chain):
    root = chain[0]
    history = [{"role": "user", "id": "m1", "content": "原始 LIT 委託"},
               {"role": "assistant", "id": "a1", "content": "working"},
               {"role": "user", "id": "m2", "content": "synthetic", "synthetic": True},
               {"role": "user", "id": "m3", "content": "summary", "compaction_through": "a1"}]
    value = board.build(root, history=history)
    assert value["humans"] == [{"id": "m1", "text": "原始 LIT 委託"}]
    assert "m1：原始 LIT 委託" in board.render(value)


def test_render_is_bounded_and_counts_what_it_omits(tmp_path):
    task = save(tmp_path, "task", {"task.md": "goal"})
    items = [{"id": f"H{i}", "statement": "長敘述" * 60} for i in range(200)]
    save(tmp_path, "hypothesis", {"hypotheses.json": {"hypotheses": items}}, [task])
    text = board.render(board.build(tmp_path))
    assert len(text.encode("utf-8")) <= board.MAX_CONTEXT_BYTES
    assert "項未列出" in text
    assert text.startswith(board.TITLE)


def test_empty_workspace_adds_no_context(tmp_path):
    assert board.context(tmp_path, [{"role": "user", "id": "m1", "content": "hi"}]) == ""


def test_build_never_writes(chain):
    root = chain[0]
    before = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
    board.render(board.build(root))
    assert {p: p.read_bytes() for p in root.rglob("*") if p.is_file()} == before


def test_board_enters_the_next_step_system_and_full_tool_reads_it(tmp_path, monkeypatch):
    from test_delivery_acceptance import case as _case, mock_model
    root, app, session = next(_case.__wrapped__(tmp_path, monkeypatch))
    (root / "h").mkdir()
    (root / "h/hypotheses.json").write_text(json.dumps(
        {"hypotheses": [{"id": "H1", "statement": "Acid lability drives EOP"}]}), encoding="utf-8")

    def answer(n, kw):
        if n == 1:
            return Completion(tool_calls=[ToolCall("save", "research_record", {
                "kind": "hypothesis", "title": "H1 record", "files": ["h/hypotheses.json"]})],
                finish_reason="tool-calls")
        if n == 2:
            return Completion(tool_calls=[ToolCall("look", "research_board", {})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    calls = mock_model(app, answer)
    assert app.prompt(session, "原始委託")["text"] == "done"
    assert board.TITLE not in host_facts(calls[0])
    assert board.TITLE in host_facts(calls[1])
    assert "H1：Acid lability drives EOP" in host_facts(calls[1])
    assert "尚無任何 proxy_formula 依賴它" in host_facts(calls[1])
    reply = next(m for m in plain_messages(calls[2]["messages"]) if m.get("role") == "tool" and m.get("tool_call_id") == "look")
    full = reply["content"]
    assert full.startswith(board.TITLE) and "完整看板" in full
    assert "H1：Acid lability drives EOP" in full and "原始委託" in full


def test_publish_retries_a_transient_access_denied_rename(tmp_path, monkeypatch):
    original, attempts = Path.rename, []

    def flaky(self, target):
        attempts.append(target)
        if len(attempts) < 3:
            raise PermissionError(5, "Access is denied")
        return original(self, target)

    monkeypatch.setattr(Path, "rename", flaky)
    monkeypatch.setattr(records.time, "sleep", lambda _: None)
    saved = save(tmp_path, "notes", {"n.md": "x"})
    assert len(attempts) == 3
    assert records.read_record(tmp_path, saved["record_path"])["kind"] == "notes"


def test_publish_gives_up_after_bounded_retries(tmp_path, monkeypatch):
    def denied(self, target):
        raise PermissionError(5, "Access is denied")

    monkeypatch.setattr(Path, "rename", denied)
    monkeypatch.setattr(records.time, "sleep", lambda _: None)
    with pytest.raises(PermissionError):
        save(tmp_path, "notes", {"n.md": "x"})
    assert not any((tmp_path / ".research/records").glob(".staging-*"))


def formula_chain(root, *, hypothesis_ids=("H1",), direction="higher", target="-abs(EOP - 40)", score_direction="higher"):
    hypotheses = save(root, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": f"H{i}", "statement": f"mechanism {i}"} for i in range(1, 6)]}})
    formula = save(root, "proxy_formula", {"p/proxy_formula.json": {
        "formula_id": "P1", "expression": "S = f * L", "hypothesis_ids": list(hypothesis_ids),
        "direction": direction, "target_transform": target}}, [hypotheses])
    impl = save(root, "implementation", {"impl/proxy.py": "print(1)"}, [formula])
    calibration = save(root, "calibration", {
        ".research/calibrations/a.json": dict(score(2), direction=score_direction),
        "c/calibration.json": {"proxy_formula_ref": formula["record_path"],
                               "judgments": [{"hypothesis_id": "H1", "effect": "uninformative", "reason": "n=2"}]}},
        [impl, formula])
    return hypotheses, formula, calibration


def test_broad_formula_rule_change_and_optimum_target_are_noticed(tmp_path):
    formula_chain(tmp_path, hypothesis_ids=("H1", "H2", "H3"), score_direction="lower")
    value = board.build(tmp_path)
    notices = "\n".join(value["notices"])
    assert "同時代表 3 個假說" in notices
    assert "以方向 lower 計分，但 P1 宣告 higher：規則在公式之後改變了" in notices
    assert "目標 -abs(EOP - 40) 有最佳點" in notices
    assert value["decisions"][0]["kind"] == "scoring_rule" and "-abs(EOP - 40)" in value["decisions"][0]["text"]
    h1 = value["hypotheses"][0]["items"][0]
    assert h1["judgments"][0]["effect"] == "uninformative"
    assert "uninformative（calibration" in board.render(value)


def test_narrow_monotone_consistent_formula_raises_none_of_the_new_notices(tmp_path):
    formula_chain(tmp_path, target="EOP_alignment")
    notices = "\n".join(board.build(tmp_path)["notices"])
    assert "同時代表" not in notices and "規則在" not in notices and "有最佳點" not in notices


def test_evolution_template_checks_basis_rule_and_host_comparison(tmp_path):
    hypotheses, formula, calibration = formula_chain(tmp_path)
    comparison = save(tmp_path, "implementation", {"cmp/comparison.json": {
        "method_ref": formula["record_path"], "direction": "higher", "comparison": "better",
        "best_baseline": {"ids": ["hist_2"], "value": 1}, "best_candidate": {"ids": ["c1"], "value": 2}}}, [formula])

    def evolution(name, comparison_ref, **extra):
        body = {"proxy_formula_ref": formula["record_path"], "direction": "higher", "ranking_rule": "proxy rank",
                "rounds": [{"round": 1, "candidate_ids": ["c1"], "comparison_ref": comparison_ref}],
                "stop_reason": "strict surpass", "claims_surpass": True, **extra}
        return save(tmp_path, "sample_evolution", {f"{name}/evolution.json": body}, [calibration, comparison])

    good = evolution("good", comparison["record_path"])
    bad = evolution("bad", None, direction="lower")
    value = board.build(tmp_path)
    notices = "\n".join(value["notices"])
    assert records_short(good) not in notices
    assert f"sample_evolution {records_short(bad)} 宣稱超越，但沒有任何一輪指向顯示超越的宿主比較紀錄" in notices
    assert f"sample_evolution {records_short(bad)} 的方向 lower 與公式宣告的 higher 不同" in notices
    assert {d["kind"] for d in value["decisions"]} == {"scoring_rule", "evolution_rule"}
    assert "演化以 P1 計分；排名規則 proxy rank；停止理由 strict surpass" in board.render(value)


def test_evolution_kind_without_template_and_mindmap_gaps(tmp_path):
    save(tmp_path, "sample_evolution", {"evo.md": "R18 beats hist_2"})
    save(tmp_path, "mindmap", {"m/mindmap.json": {"unresolved_gaps": ["Does Mw matter?", "Is LCDU coupled?"]}})
    value = board.build(tmp_path)
    assert any("未附 evolution.json" in n for n in value["notices"])
    assert [q["text"] for q in value["questions"]] == ["Does Mw matter?", "Is LCDU coupled?"]
    assert "疑問 " in board.render(value) and "Does Mw matter?" in board.render(value)


def records_short(record):
    return record["record_path"].split("/")[2][:8]


def test_research_record_receipt_carries_notices_about_the_new_record(tmp_path, monkeypatch):
    from test_delivery_acceptance import case as _case, mock_model
    from tests.prompt_view import plain_messages
    root, app, session = next(_case.__wrapped__(tmp_path, monkeypatch))
    (root / "h").mkdir()
    (root / "h/hypotheses.json").write_text(json.dumps(
        {"hypotheses": [{"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"}]}), encoding="utf-8")

    def answer(n, kw):
        if n == 1:
            return Completion(tool_calls=[ToolCall("save", "research_record", {
                "kind": "hypothesis", "title": "H", "files": ["h/hypotheses.json"]})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    calls = mock_model(app, answer)
    assert app.prompt(session, "Record hypotheses")["text"] == "done"
    receipt = json.loads(next(m for m in plain_messages(calls[1]["messages"]) if m.get("tool_call_id") == "save")["content"])
    assert "沒有對應公式的假說：H1、H2。" in receipt["host_notice"]
    stored = records.read_record(root, receipt["record_path"])
    assert "host_notice" not in stored


def test_notices_have_levels_ids_and_merged_repeats(tmp_path):
    formula_chain(tmp_path, hypothesis_ids=("H1", "H2", "H3"))
    impl = save(tmp_path, "implementation", {"impl2/proxy.py": "print(2)"})
    save(tmp_path, "calibration", {".research/calibrations/b.json": score(2)}, [impl])
    value = board.build(tmp_path)
    items = value["notice_items"]
    small = [i for i in items if "只有 2 筆樣本" in i["text"]]
    assert len(small) == 1 and small[0]["level"] == "info"
    assert all(i["id"].startswith("N") and len(i["id"]) == 7 for i in items)
    assert [i["level"] for i in items] == sorted((i["level"] for i in items), key=["action", "info"].index)
    assert any("同時代表 3 個假說" in i["text"] for i in board.open_actions(value))
    text = board.render(value)
    assert text.index("需要處理的提醒") < text.index("推理圖") < text.index("資訊性提醒與已回覆")
    assert board.build(tmp_path)["notice_items"] == items  # ids are stable


def test_replying_to_a_notice_moves_it_out_of_the_open_list(tmp_path):
    from researchkit import graph
    formula_chain(tmp_path, hypothesis_ids=("H1", "H2", "H3"))
    target = next(i for i in board.open_actions(board.build(tmp_path)) if "同時代表" in i["text"])
    store = graph.GraphStore(tmp_path)
    store.update({"expected_revision": None, "reason": "answer notice",
                  "notice_replies": [{"notice_id": target["id"], "reason": "P1 ranks one shared mechanism"}]})
    value = board.build(tmp_path)
    assert target["id"] not in {i["id"] for i in board.open_actions(value)}
    assert "已回覆" in board.render(value) and "P1 ranks one shared mechanism" in board.render(value)
    with pytest.raises(ValueError, match="notice reply"):
        store.update({"expected_revision": store.head(), "reason": "bad",
                      "notice_replies": [{"notice_id": "X1", "reason": "nope"}]})


def test_formula_versions_unlinked_or_stale_in_a_delivery(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    old = save(tmp_path, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "a", "hypothesis_ids": ["H1"]}}, [hypotheses])
    other = save(tmp_path, "proxy_formula", {"p2/proxy_formula.json": {
        "formula_id": "P1", "expression": "b", "hypothesis_ids": ["H1"]}}, [hypotheses])
    notices = "\n".join(board.build(tmp_path)["notices"])
    assert "proxy_formula P1 有多份紀錄" in notices and "彼此沒有依賴關係" in notices
    tmp2 = tmp_path / "linked"
    tmp2.mkdir()
    hypotheses = save(tmp2, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    old = save(tmp2, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "a", "hypothesis_ids": ["H1"]}}, [hypotheses])
    new = save(tmp2, "proxy_formula", {"p2/proxy_formula.json": {
        "formula_id": "P1", "expression": "b", "hypothesis_ids": ["H1"]}}, [hypotheses, old])
    report = save(tmp2, "report", {"r/report.md": "uses old P1"}, [old])
    notices = "\n".join(board.build(tmp2)["notices"])
    assert "有多份紀錄" not in notices
    assert f"report {records_short(report)} 依賴 proxy_formula {records_short(old)}，但它已有修訂版 {records_short(new)}" in notices
    # v6: two revisions of the same old formula; a delivery built on one of them is current.
    copy = save(tmp2, "proxy_formula", {"p3/proxy_formula.json": {
        "formula_id": "P1", "expression": "c", "hypothesis_ids": ["H1"]}}, [hypotheses, old])
    current = save(tmp2, "report", {"r2/report.md": "uses the revision"}, [copy])
    notices = "\n".join(board.build(tmp2)["notices"])
    assert f"report {records_short(current)} 依賴" not in notices
    assert f"report {records_short(report)} 依賴 proxy_formula {records_short(old)}" in notices


def test_tied_rounds_need_a_tie_break_and_digest_lists_what_a_delivery_uses(tmp_path):
    hypotheses, formula, calibration = formula_chain(tmp_path)

    def compare(name, ids):
        return save(tmp_path, "implementation", {f"{name}/comparison.json": {
            "method_ref": formula["record_path"], "direction": "higher", "comparison": "better",
            "best_baseline": {"ids": ["b"], "value": 3.5}, "best_candidate": {"ids": ids, "value": 4.0}}}, [formula])

    rounds = [compare("c1", ["S1"]), compare("c2", ["S2"])]

    def evolution(name, **extra):
        body = {"proxy_formula_ref": formula["record_path"], "claims_surpass": True,
                "rounds": [{"round": i + 1, "comparison_ref": r["record_path"]} for i, r in enumerate(rounds)], **extra}
        return save(tmp_path, "sample_evolution", {f"{name}/evolution.json": body}, [calibration, *rounds])

    plain = evolution("plain")
    declared = evolution("declared", tie_break="ties are reported as ties")
    value = board.build(tmp_path)
    open_texts = "\n".join(i["text"] for i in board.open_actions(value))
    assert f"sample_evolution {records_short(plain)} 各輪最佳候選分數都是 4.0" in open_texts
    assert records_short(declared) not in open_texts
    assert any(records_short(declared) in i["text"] and i["level"] == "info" for i in value["notice_items"])
    tied = compare("c3", ["S1", "S2"])
    assert any("最佳候選同分（S1、S2=4.0）" in i["text"] for i in board.open_actions(board.build(tmp_path)))
    report = save(tmp_path, "report", {"r/report.md": "text"}, [declared])
    digest = board.delivery_digest(tmp_path, board.build(tmp_path), report["record_path"])
    assert any(line.startswith("proxy_formula P1") and "宣告 H1" in line for line in digest)
    assert any("H1 的作者判斷：uninformative" in line for line in digest)
    assert any("各輪最佳分數 [4.0, 4.0]" in line and "ties are reported as ties" in line for line in digest)


def test_delivery_receipt_lists_open_notices_and_digest(tmp_path, monkeypatch):
    from test_delivery_acceptance import case as _case, mock_model
    from tests.prompt_view import plain_messages
    root, app, session = next(_case.__wrapped__(tmp_path, monkeypatch))
    hypotheses, formula, calibration = formula_chain(root, hypothesis_ids=("H1", "H2", "H3"))
    (root / "report.md").write_text("Report text", encoding="utf-8")

    def answer(n, kw):
        if n == 1:
            return Completion(tool_calls=[ToolCall("rep", "research_record", {
                "kind": "report", "title": "Report", "files": ["report.md"],
                "depends_on": [calibration["record_path"]]})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    calls = mock_model(app, answer)
    assert app.prompt(session, "Write the report")["text"] == "done"
    receipt = json.loads(next(m for m in plain_messages(calls[1]["messages"]) if m.get("tool_call_id") == "rep")["content"])
    assert "同時代表 3 個假說" in receipt["host_notice"] and "[N" in receipt["host_notice"]
    assert "此交付所依賴紀錄的宿主摘要" in receipt["host_notice"]
    assert "proxy_formula P1" in receipt["host_notice"]


def test_notice_ids_follow_the_subject_so_replies_survive_wording_changes(tmp_path):
    from researchkit import graph
    hypotheses, formula, calibration = formula_chain(tmp_path)
    before = board.build(tmp_path)
    uncovered = next(i for i in before["notice_items"] if "沒有對應公式的假說" in i["text"])
    small = next(i for i in before["notice_items"] if "只有 2 筆樣本" in i["text"])
    graph.GraphStore(tmp_path).update({"expected_revision": None, "reason": "answer", "notice_replies": [
        {"notice_id": uncovered["id"], "reason": "H2-H5 lack the data for a formula"}]})
    second = save(tmp_path, "proxy_formula", {"p2/proxy_formula.json": {
        "formula_id": "P2", "expression": "Mw", "hypothesis_ids": ["H2"], "direction": "lower"}}, [hypotheses])
    impl = save(tmp_path, "implementation", {"impl2/proxy.py": "print(2)"}, [second])
    save(tmp_path, "calibration", {".research/calibrations/z.json": score(2)}, [impl, second])
    after = {i["id"]: i for i in board.build(tmp_path)["notice_items"]}
    assert "H3、H4、H5" in after[uncovered["id"]]["text"] and "H2" not in after[uncovered["id"]]["text"].split("：")[-1]
    assert after[uncovered["id"]]["reply"] == "H2-H5 lack the data for a formula"
    assert small["id"] in after and after[small["id"]]["text"] != small["text"]


def test_every_hypothesis_needs_a_formula_unless_it_says_why_it_cannot_be_computed(tmp_path):
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"},
        {"id": "H3", "statement": "c", "proxy_status": {
            "status": "not_computable", "reason": "no descriptor exists for any design",
            "tried": [{"proxy": "group contribution", "why_not": "no fragment values for this group"}]}}]}})
    save(tmp_path, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "a", "hypothesis_ids": ["H1"], "direction": "higher"}}, [hypotheses])
    items = board.build(tmp_path)["notice_items"]
    action = [i["text"] for i in items if i["level"] == "action"]
    info = [i["text"] for i in items if i["level"] == "info"]
    assert any("沒有對應公式的假說：H2。" in t for t in action)
    assert not any("H3" in t for t in action) and any("宣告無法計算：H3" in t for t in info)


def test_direction_mismatches_between_formula_code_and_comparison_are_flagged(tmp_path):
    # v10: every formula returned -abs(...) but declared lower; comparisons used higher, the leaderboard lower.
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [{"id": "H1", "statement": "a"}]}})
    formula = save(tmp_path, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "proxy = -abs(barrier - 4.0)", "hypothesis_ids": ["H1"],
        "direction": "lower"}}, [hypotheses])
    values = save(tmp_path, "implementation", {"v/values.json": {"h": -2.5, "c": -1.25}}, [formula])
    save(tmp_path, "implementation", {"cmp/comparison.json": {
        "method_ref": formula["record_path"], "direction": "higher", "comparison": "better",
        "best_baseline": {"ids": ["h"], "value": -2.5}, "best_candidate": {"ids": ["c"], "value": -1.25}}},
        [formula, values])
    texts = [i["text"] for i in board.open_actions(board.build(tmp_path))]
    assert any("回傳 -abs(...)" in t and "P1" in t for t in texts)
    assert any("候選比較與公式的方向不一致" in t for t in texts)


def test_a_comparison_through_one_formula_of_a_shared_table_is_checked_against_that_formula_only(tmp_path):
    # v18: one values table depends on every formula; a P2 comparison was flagged against P1's direction.
    hypotheses = save(tmp_path, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": "H1", "statement": "a"}, {"id": "H2", "statement": "b"}]}})
    p1 = save(tmp_path, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "a", "hypothesis_ids": ["H1"], "direction": "higher"}}, [hypotheses])
    p2 = save(tmp_path, "proxy_formula", {"p2/proxy_formula.json": {
        "formula_id": "P2", "expression": "b", "hypothesis_ids": ["H2"], "direction": "lower"}}, [hypotheses])
    table = save(tmp_path, "implementation", {"v/values.json": {"h": {"P1": 1, "P2": 2}, "c": {"P1": 2, "P2": 1}}},
                 [p1, p2])

    def comparison(name, method, direction):
        save(tmp_path, "implementation", {f"{name}/comparison.json": {
            "method_ref": method["record_path"], "direction": direction, "comparison": "better",
            "best_baseline": {"ids": ["h"], "value": 2}, "best_candidate": {"ids": ["c"], "value": 1}}},
            [method, table])
        return [i["text"] for i in board.open_actions(board.build(tmp_path)) if "方向不一致" in i["text"]]

    assert comparison("ok", p2, "lower") == []
    clash, = comparison("wrong", p2, "higher")
    assert "P2（lower）" in clash and "P1" not in clash


def test_a_round_is_early_only_when_its_newest_values_precede_the_previous_ranking(tmp_path):
    # v41's rounds 2 and 3 also ranked the history values saved before round 1, and were called precomputed.
    def at(name, seconds):
        (tmp_path / name).write_text(name, encoding="utf-8")
        os.utime(tmp_path / name, ns=(seconds * 10**9, seconds * 10**9))
        return name

    history, first, later, earlier, second = (at("history", 100), at("round1", 200), at("later", 300),
                                              at("earlier", 150), at("round2", 400))
    by_ref = {name: {"kind": "implementation", "depends_on": []} for name in (history, later, earlier)}
    by_ref[first] = {"kind": "leaderboard", "depends_on": [history]}
    by_ref[second] = {"kind": "leaderboard", "depends_on": [history, later]}
    rounds = [{"round": 1, "leaderboard_ref": first, "comparison_ref": None},
              {"round": 2, "leaderboard_ref": second, "comparison_ref": None}]
    notices = board.Notices()
    board._round_order_notices(tmp_path, "sample_evolution e", rounds, by_ref, notices)
    assert notices == []
    by_ref[second]["depends_on"] = [history, earlier]  # v30: the next round's values came before the ranking
    board._round_order_notices(tmp_path, "sample_evolution e", rounds, by_ref, notices)
    assert len(notices) == 1 and "早於第 1 輪的排名" in notices[0]
