"""A recorded continuation through the one entry (co-scientist <run> --continue --record <new>): its audit
boundaries, without a real model or scientific work."""

from contextlib import closing, contextmanager, redirect_stderr, redirect_stdout
import importlib
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from opencode import integrity
from opencode.permission import evaluate, from_config
from opencode.store import Store
from researchkit import records, task_runtime
from scripts import recording, run_tui
from scripts.llm_configuration import saved_llm_config
from scripts.setup_research_workspace import install
from tests.prompt_view import plain_messages


def watched(run, flag):
    """NodeWatcher.run that marks flag once the watcher has taken a person's stop request."""
    def wrapper(self):
        original = self.on_stop

        def on_stop():
            original()
            if self.requested:
                flag.write_text(self.requested, encoding="utf-8")

        self.on_stop = on_stop
        return run(self)
    return wrapper


class ReviewModel:
    """A stand-in for the model of the round's reviews: one reply (or an error) for every request."""

    def __init__(self, reply):
        self.reply, self.requests = reply, []

    def __call__(self, system, message, schema):
        self.requests.append(message)
        if isinstance(self.reply, BaseException):
            raise self.reply
        return SimpleNamespace(text=json.dumps(self.reply), finish_reason="stop")


@contextmanager
def offline():
    """No network: the stand-in app and reviewer never reach a model."""
    connect = socket.socket.connect

    def blocked(sock, address):
        # Windows asyncio creates a loopback self-pipe through socketpair(); nothing else may connect.
        if isinstance(address, tuple) and address[0] in ("127.0.0.1", "::1"):
            return connect(sock, address)
        raise AssertionError("The recorded continuation test attempted a network connection")

    with patch.object(socket.socket, "connect", blocked):
        yield


class ResearchContinuationRunner(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.run = self.root / "saved-run"
        self.workspace = self.run / "workspace"
        self.workspace.mkdir(parents=True)
        (self.workspace / ".git").mkdir()
        self.source = self.root / "source"
        self.source.mkdir()
        (self.source / "input.csv").write_text("id,value\nA,3\n", encoding="utf-8")
        (self.workspace / "result.csv").write_text("id,result\nA,9\n", encoding="utf-8")
        self.database = self.run / "state/opencode/opencode.db"
        self.store = Store(self.database)
        self.sid = self.store.create_session(directory=str(self.workspace), agent="build", model=None)["id"]
        self.commission = "Original commission: prepare, compute, review and deliver."
        self.first = self.store.add_message(self.sid, "user", {"content": self.commission})
        self.store.add_message(self.sid, "user", {"content": "A historical local readback test only."})
        self.store.commit_compaction(self.sid, self.first["id"], "Historical partial work, not acceptance.")
        self.todos = [{"id": "readback", "content": "Only the local readback test", "status": "completed", "priority": "medium"}]
        self.store.set_todos(self.sid, self.todos)
        recording.save(self.run / "sessions.json", [{"session": s, "messages": self.store.messages(s["id"])}
                                                   for s in self.store.list_sessions()])
        self.store.close()
        saved_config = saved_llm_config("http://localhost:1/v1", "deepseek-v4.1-flash")
        recording.save(self.run / "settings.json", {"source": str(self.source), "config": saved_config})
        recording.save(self.run / "result.json", {"result": {"sessionID": self.sid}})
        recording.save(self.run / "runtime-manifest.json", {})
        recording.save(self.workspace / "opencode.json", saved_config)
        install(self.workspace)  # a run the earlier installer set up
        self.prompt = self.root / "current.txt"
        self.prompt.write_text("Resume the full original commission, retaining completed work.", encoding="utf-8")
        self.output = self.root / "trace"
        self.env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"),
            "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_DATA_HOME": str(self.root / "data"),
            "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        self.env.start()
        self.addCleanup(self.env.stop)

    def arguments(self, output=None):
        # A research task: deep research on (opencode/deep.py), with its plan and reviews.
        return [str(self.run), "--continue", "--record", str(output or self.output), "--prompt", str(self.prompt),
                "--deep"]

    def run_entry(self, arguments, review=None):
        """The entry with nobody at the keyboard; (exit code, output, error output)."""
        stream, errors = io.StringIO(), io.StringIO()
        review = review or ReviewModel(ConnectionError("no reviewer model in this test"))
        with redirect_stdout(stream), redirect_stderr(errors), offline(), \
                patch.object(task_runtime, "model_call", lambda app, session: review), \
                patch.object(tempfile, "tempdir", tempfile.tempdir), \
                patch.object(sys, "dont_write_bytecode", sys.dont_write_bytecode):
            code = run_tui.main(arguments)
        return code, stream.getvalue(), errors.getvalue()

    def refused(self, pattern, arguments=None):
        """Refused before anything is written: no record folder, the earlier run as it was."""
        before = recording.hashes(self.run)
        built = []
        with patch.object(run_tui, "build_app", lambda *a, **kw: built.append(1)):
            code, _, errors = self.run_entry(arguments or self.arguments())
        self.assertEqual((code, built), (1, []))
        self.assertRegex(errors, pattern)
        self.assertFalse(self.output.exists())
        self.assertEqual(recording.hashes(self.run), before)

    def fake_run(self, during=lambda: None, *, model=None, options=(), reply=None):
        """The recorded continuation with the entry's own app, whose prompt is a stand-in (self.stand_in is the
        app): during() runs while the agent would work, reply(app, session, text) replaces the whole turn, and
        model stands in for the model of the round's reviews. Returns (exit code, the app's configuration)."""
        real = run_tui.build_app
        seen = {}

        def build(*args, **kwargs):
            app, effective, chosen = real(*args, **kwargs)

            def prompt(session_id, text, **_):
                if reply:
                    return reply(app, session_id, text)
                app.store.add_message(session_id, "user", {"content": text})
                during()
                return {"status": "completed", "sessionID": session_id, "text": "done"}

            app.prompt = prompt
            self.stand_in, seen["config"] = app, app.config
            return app, effective, chosen

        with patch.object(run_tui, "build_app", build):
            self.code, self.out, self.err = self.run_entry([*self.arguments(), *options], review=model)
        return self.code, seen.get("config")

    def failed_command(self):
        """The agent's work in a round: one command that fails."""
        store = Store(self.database)
        store.add_message(self.sid, "assistant", {"content": "", "tool_calls": [
            {"id": "call_pip", "name": "bash", "arguments": {"command": "pip install numpy"}}]})
        store.add_message(self.sid, "tool", {"tool_call_id": "call_pip", "name": "bash",
                                             "content": "ERROR: network is unreachable", "metadata": {"exit": 1}})
        store.close()

    def round_record(self):
        result = json.loads((self.output / "result.json").read_text(encoding="utf-8"))
        return result, json.loads((self.output / recording.ROUND_REVIEW).read_text(encoding="utf-8"))

    def capture_offline_prompt(self):
        with patch.object(sys, "path", [str(Path(recording.__file__).parent), *sys.path]):
            diagnostic = importlib.import_module("scripts.check_continuation_prompt")
        args = ["diagnostic", "--run", str(self.run), "--previous-trace", str(self.run),
                "--prompt", str(self.prompt), "--output", str(self.output)]
        with patch.object(sys, "argv", args), redirect_stdout(io.StringIO()):
            diagnostic.main()
        request_path = next(path for path in (self.output / "request.json", self.output / "assembly-before-compaction.json")
                            if path.exists())
        self.assertNotIn("abort_event", json.loads(request_path.read_text(encoding="utf-8")))
        return json.loads((self.output / "result.json").read_text(encoding="utf-8"))

    def test_original_request_is_read_only_and_not_the_latest_followup(self):
        before = recording.hashes(self.run)
        self.assertEqual(recording.original_request(self.run, self.sid), self.commission)
        self.assertEqual(recording.hashes(self.run), before)

    def test_interrupted_run_recovers_exact_root_and_preserves_failure_records(self):
        previous_workspace = str(self.root / "previous-workspace")
        with closing(Store(self.database)) as store:
            store.update_session(self.sid, directory=previous_workspace)
            store.create_session(directory=previous_workspace, agent="build", model=None, parent_id=self.sid)
            history = store.messages(self.sid)
            recording.save(self.run / "sessions.json", [{"session": s, "messages": store.messages(s["id"])}
                                                       for s in store.list_sessions()])
        (self.run / "result.json").write_bytes(b'{ "result": {}, "error": "HTTP 400: unsupported file" }\n')
        (self.run / "cli-transcript.txt").write_bytes(b"Original failed provider transcript.\r\n")
        records_before = {name: (self.run / name).read_bytes()
                          for name in ("result.json", "cli-transcript.txt", "sessions.json")}
        database_before = self.database.read_bytes()

        def reply(app, sid, text):
            self.assertEqual(sid, self.sid)
            self.assertEqual(Path(app.store.get_session(sid)["directory"]), self.workspace)
            self.assertEqual(app.store.messages(sid), history)
            app.store.add_message(sid, "user", {"content": text})
            return {"status": "completed", "sessionID": sid, "text": "Continuation boundary exercised."}

        code, _ = self.fake_run(reply=reply)
        self.assertEqual(code, 0)
        self.assertIn(f"[continuation] workspace: {previous_workspace} -> {self.workspace}", self.out)
        self.assertEqual((self.output / "baseline/state/opencode/opencode.db").read_bytes(), database_before)
        self.assertEqual(json.loads((self.output / "continuation.json").read_text(encoding="utf-8")), {
            "previous_run": str(self.run), "session_id": self.sid, "baseline": str(self.output / "baseline")})
        self.assertEqual((self.output / "original-request.txt").read_text(encoding="utf-8"), self.commission)
        for name, original in records_before.items():
            self.assertEqual((self.run / name).read_bytes(), original)
        with closing(Store(self.database)) as store:
            self.assertEqual(store.messages(self.sid), [*history, store.messages(self.sid)[-1]])
            self.assertEqual(store.messages(self.sid)[-1]["content"], self.prompt.read_text(encoding="utf-8"))
            self.assertEqual(store.todos(self.sid), self.todos)

    def test_interrupted_run_rejects_missing_or_ambiguous_snapshot_before_writes(self):
        recording.save(self.run / "result.json", {"result": {}, "error": "HTTP 400"})
        path = self.run / "sessions.json"
        saved = json.loads(path.read_text(encoding="utf-8"))
        missing_parent = [{"session": {key: value for key, value in saved[0]["session"].items() if key != "parentID"}}]
        child_only = [{"session": {**saved[0]["session"], "parentID": "another-session"}}]
        for content in (None, {}, [], missing_parent, child_only, [*saved, *saved]):
            with self.subTest(content=content):
                if content is None:
                    path.unlink(missing_ok=True)
                else:
                    recording.save(path, content)
                self.refused(".")

    def test_interrupted_run_rejects_snapshot_database_disagreement_before_writes(self):
        recording.save(self.run / "result.json", {"result": {}, "error": "HTTP 400"})
        path = self.run / "sessions.json"
        saved = json.loads(path.read_text(encoding="utf-8"))
        for changed in ({"id": "missing"}, {"directory": str(self.root / "stale-workspace")}):
            with self.subTest(changed=changed):
                recording.save(path, [{**saved[0], "session": {**saved[0]["session"], **changed}}])
                self.refused("disagrees with the database")
        recording.save(path, saved)
        with closing(Store(self.database)) as store:
            store.create_session(directory=str(self.workspace), agent="build", model=None)
        self.refused("disagrees with the database")

    def test_missing_original_fails_before_creating_trace_or_mutating_run(self):
        recording.save(self.run / "result.json", {"result": {"sessionID": "missing"}})
        self.refused("No saved original")

    def test_empty_current_request_is_not_inferred_from_summary(self):
        self.prompt.write_text(" \n", encoding="utf-8")
        self.refused("a prompt file is empty")

    def test_output_cannot_be_inside_saved_run_or_original_source(self):
        for output in (self.run / "trace", self.source / "trace", self.root):
            with self.subTest(output=output):
                before = recording.hashes(self.run)
                code, _, errors = self.run_entry(self.arguments(output))
                self.assertEqual(code, 1)
                self.assertIn("overlap", errors)
                self.assertEqual(recording.hashes(self.run), before)

    def test_the_entry_refuses_a_recorded_run_without_its_parts(self):
        source = ["--from", str(self.source)]
        for arguments, message in (
                ([str(self.run), "--record", str(self.output), "--prompt", str(self.prompt)], "give no folder"),
                (["--record", str(self.output), "--prompt", str(self.prompt)], "give no folder"),
                ([*self.arguments(), *source], "not --from"),
                (["--continue", "--record", str(self.output), "--prompt", str(self.prompt)], "earlier record folder"),
                ([str(self.run), "--continue", "--prompt", str(self.prompt), "--stop-at", "mindmap"],
                 "--stop-at goes with --record")):
            with self.subTest(arguments=arguments):
                errors = io.StringIO()
                with redirect_stderr(errors), self.assertRaises(SystemExit):
                    run_tui.main(arguments)
                self.assertIn(message, errors.getvalue())
        self.assertFalse(self.output.exists())

    def test_a_recorded_round_installs_the_skill_copies_before_its_meta_baseline(self):
        # Its agent sees the copies in the workspace, never the framework's source (opencode/deep.py).
        code, config = self.fake_run()
        self.assertEqual(code, 0)
        baseline = json.loads((self.output / recording.META_BASELINE).read_text(encoding="utf-8"))
        self.assertIn("workspace/.opencode/deep/research/research-practice/SKILL.md", baseline)
        copies = (self.workspace / ".opencode" / "deep").resolve()
        shown = [*config["deep"]["instructions"], *config["deep"]["skills"]]
        self.assertTrue(shown and all(Path(item).resolve().is_relative_to(copies) for item in shown))

    def test_returned_dialogue_is_not_scientific_acceptance(self):
        submitted = []
        before = recording.hashes(self.workspace)
        with closing(Store(self.database)) as store:
            store.update_session(self.sid, directory=str(self.root / "previous-workspace"))

        def reply(app, sid, text):
            self.assertEqual(Path(app.store.get_session(sid)["directory"]), self.workspace)
            submitted.append(text)
            app.store.add_message(sid, "user", {"content": text})
            app.store.add_message(sid, "assistant", {"content": "Files exist; everything is done."})
            return {"status": "completed", "sessionID": sid, "text": "Files exist; everything is done."}

        code, _ = self.fake_run(reply=reply)
        self.assertEqual(code, 0)
        self.assertEqual(submitted, [self.prompt.read_text(encoding="utf-8")])
        self.assertEqual((self.output / "original-request.txt").read_text(encoding="utf-8"), self.commission)
        self.assertEqual((self.output / "current-request.txt").read_text(encoding="utf-8"), submitted[0])
        self.assertEqual(json.loads((self.output / "result.json").read_text())["scientific_delivery"], "not_reviewed")
        self.assertIn("process completion is not research acceptance", self.out)
        # Deep research's skill copies (opencode/deep.py) are what the framework installs, not the agent's work.
        installed = lambda found: {key: value for key, value in found.items() if not key.startswith(".opencode/deep/")}
        self.assertEqual(installed(recording.hashes(self.workspace)), installed(before))
        store = Store(self.database)
        try:
            self.assertEqual(store.todos(self.sid), self.todos)
            self.assertEqual(store.messages(self.sid)[0]["content"], self.commission)
        finally:
            store.close()

    def test_the_round_ends_with_a_review_the_next_round_starts_with(self):
        # A tool this task mounted earlier: the review reads its tests (charter article 4).
        mount = self.workspace / ".research/simulations/m1/mount.json"
        mount.parent.mkdir(parents=True)
        mount.write_text(json.dumps({"name": "axial_modes", "id": "task.acoustics.axial_modes", "status": "mounted",
                                     "version": "ab" * 32, "session": self.sid, "round": 1, "charter": "0.2",
                                     "declaration": {"title": "Axial room modes"}, "tests": [
                                         {"name": "a 5.6 m room", "source": "f = c / (2 L)", "status": "passed"}]}),
                         encoding="utf-8")
        records.publish(self.workspace, kind="task_tool", title="task tool", files=[
            ".research/simulations/m1/mount.json"], depends_on=[])
        model = ReviewModel({"description": "Install packages offline.", "dropped": [],
                             "lessons": [{"lesson": "Install packages from the local wheel folder.", "evidence": ["T1"]}],
                             "framework_issues": [{"issue": "No network for pip.", "cause": "environment",
                                                   "evidence": ["T1"]}]})
        code, _ = self.fake_run(self.failed_command, model=model)
        self.assertEqual(code, 0)
        result, record = self.round_record()
        self.assertEqual((result["round"], result["round_review"], result["meta_region_unchanged"]), (2, "written", True))
        package = model.requests[0]
        self.assertIn("[T1] bash: pip install numpy -> exit 1\n    ERROR: network is unreachable", package)
        self.assertIn("Round 2 of this task. The working agent finished its reply.", package)
        self.assertIn(self.commission, package)  # the commission, and this round's request beside it
        self.assertIn("[C2] this round's request", package)
        self.assertNotIn("[T2]", package)  # only this round's calls
        self.assertIn("[M1] the tools this task wrote", package)
        self.assertIn("task.acoustics.axial_modes (Axial room modes): mounted", package)
        self.assertIn("  test 'a 5.6 m room', passed: its answer from f = c / (2 L)", package)
        skill = self.run / "state/opencode/task" / self.sid / "review/lessons-from-earlier-rounds/SKILL.md"
        self.assertEqual(record["skill"], str(skill))
        self.assertIn("1. Install packages from the local wheel folder.", skill.read_text(encoding="utf-8"))
        self.assertIn("## 環境\n\n1. No network for pip.", (self.output / recording.FRAMEWORK_ISSUES).read_text(encoding="utf-8"))

    def test_a_stalled_round_pauses_for_a_review_its_checks_then_hold(self):
        # The loop asks for the pause (opencode/loop.py _pause_for_review); here the round's work asks directly.
        model = ReviewModel({"description": "Install packages offline.", "dropped": [], "framework_issues": [],
                             "lessons": [{"lesson": "Install packages from the local wheel folder.", "evidence": ["T1"]}]})
        paused = []

        def during():
            self.failed_command()
            paused.append(self.stand_in.pause_review(self.sid, 31))

        code, _ = self.fake_run(during, model=model)
        result, record = self.round_record()
        self.assertEqual(paused[0]["status"], "written")
        # The review it wrote is the framework's: the round still counts, and is reviewed again at its end.
        self.assertEqual((code, result["pause_reviews"], result["meta_region_unchanged"], result["round_review"]),
                         (0, ["written"], True, "written"))
        pause = model.requests[0]
        self.assertIn("The round is not over: the host paused it because the last 31 model calls", pause)
        self.assertIn("[B1] the research board when the round was paused", pause)
        self.assertIn("a lesson of the previous review (the review written when round 2 was paused)", model.requests[1])
        saved = json.loads((self.output / recording.PAUSE_REVIEW.format(1)).read_text(encoding="utf-8"))
        self.assertEqual(saved["status"], "written")
        folder = self.run / "state/opencode/task" / self.sid / "review/lessons-from-earlier-rounds"
        self.assertIn("第 2 輪進行中因工作停滯而暫停，由檢討者整理", (folder / "history/SKILL.1.md").read_text(encoding="utf-8"))
        self.assertIn("第 2 輪結束後由檢討者整理", (folder / "SKILL.md").read_text(encoding="utf-8"))

    def test_the_verification_plan_is_written_before_the_first_step_and_the_round_still_counts(self):
        plan = {"needed": True, "reason": "No measurement can confirm the new design.",
                "description": "Results are predictions; check them by hand-computable cases.",
                "problem": {"text": "Design the room's treatment.", "evidence": ["C1"]},
                "resources": [{"resource": "Measurements", "what": "None", "evidence": ["C1"]}],
                "checks": [{"layer": "computation", "target": "The solver", "methods": "Known answers",
                            "strength": "medium", "ready_when": "A mounted task tool whose tests passed",
                            "evidence": ["C1"]}],
                "stops": [{"scope": "task", "condition": "As the commission states", "evidence": ["C1"]}]}
        review = {"description": "Install packages offline.", "dropped": [], "framework_issues": [],
                  "lessons": [{"lesson": "The solver check V1 is still not ready.", "evidence": ["V1", "T1"]}]}
        requests = []

        def model(system, message, schema):
            requests.append((schema[0], message))
            return SimpleNamespace(text=json.dumps(plan if schema[0] == "verification_plan" else review),
                                   finish_reason="stop")

        planned = []

        def during():
            planned.append(self.stand_in.plan_verification(self.sid))
            self.failed_command()

        code, _ = self.fake_run(during, model=model)
        result, record = self.round_record()
        self.assertEqual(planned[0]["status"], "written")
        self.assertEqual((code, result["verification_plan"], result["meta_region_unchanged"], result["round_review"]),
                         (0, "written", True, "written"))
        saved = json.loads((self.output / recording.VERIFICATION_PLAN).read_text(encoding="utf-8"))
        self.assertEqual(saved["plan"]["checks"][0]["target"], "The solver")
        self.assertEqual([name for name, _ in requests], ["verification_plan", "round_review"])
        self.assertIn("[V1] a check of the task's verification plan", requests[1][1])
        folder = self.run / "state/opencode/task" / self.sid / "review"
        self.assertTrue((folder / "verification-plan/SKILL.md").is_file())
        self.assertIn("The solver check V1 is still not ready.",
                      (folder / "lessons-from-earlier-rounds/SKILL.md").read_text(encoding="utf-8"))

    def test_no_pause_review_with_no_review(self):
        model = ReviewModel(AssertionError("the review's model was called"))
        paused = []
        code, _ = self.fake_run(lambda: paused.append(self.stand_in.pause_review(self.sid, 31)), model=model,
                                options=["--no-review"])
        self.assertEqual((paused[0]["status"], model.requests), ("skipped", []))
        self.assertNotIn("pause_reviews", self.round_record()[0])

    def test_a_round_that_does_not_count_is_not_reviewed(self):
        model = ReviewModel(AssertionError("the review's model was called"))
        skill = self.workspace / ".opencode/skills/sample/SKILL.md"
        code, _ = self.fake_run(lambda: skill.write_text("No round limit.\n", encoding="utf-8"), model=model)
        result, record = self.round_record()
        self.assertEqual((code, result["round_review"], model.requests), (1, "skipped", []))
        self.assertEqual(record["reason"], "the meta region changed during this round, so it does not count")

    def test_a_task_without_deep_research_is_not_reviewed(self):
        model = ReviewModel(AssertionError("the review's model was called"))
        real = self.arguments

        def without_deep(output=None):
            return [item for item in real(output) if item != "--deep"]

        self.arguments = without_deep
        code, config = self.fake_run(self.failed_command, model=model)
        result, record = self.round_record()
        self.assertEqual((code, result["round_review"], model.requests), (0, "skipped", []))
        self.assertEqual(record["reason"], "deep research is off for this task")
        self.assertNotIn("verification_plan", result)

    def test_a_round_told_not_to_is_not_reviewed(self):
        model = ReviewModel(AssertionError("the review's model was called"))
        code, _ = self.fake_run(self.failed_command, model=model, options=["--no-review"])
        result, record = self.round_record()
        self.assertEqual((code, result["round_review"], model.requests), (0, "skipped", []))
        self.assertEqual(record["reason"], "turned off with --no-review")

    def test_a_round_a_person_stops_ends_like_a_stage_and_is_still_reviewed(self):
        model = ReviewModel({"description": "d", "dropped": [], "framework_issues": [],
                             "lessons": [{"lesson": "Install packages offline.", "evidence": ["T1"]}]})

        def during():  # the person asks the round to end while the agent works
            self.failed_command()
            (self.output / recording.STOP_REQUEST).write_text("It keeps retrying pip.\n", encoding="utf-8")
            deadline = time.monotonic() + 10
            while not stopped.exists() and time.monotonic() < deadline:
                time.sleep(0.1)

        stopped = self.root / "stopped"
        with patch.object(recording.NodeWatcher, "run", watched(recording.NodeWatcher.run, stopped)):
            code, _ = self.fake_run(during, model=model)
        result, record = self.round_record()
        self.assertEqual((code, result["stop_requested"], result["round_review"]),
                         (0, "It keeps retrying pip.", "written"))
        self.assertIn("The person stopped this round before it ended, saying: It keeps retrying pip.",
                      model.requests[0])

    def test_a_failed_review_leaves_the_rounds_result_as_it_was(self):
        code, _ = self.fake_run(self.failed_command, model=ReviewModel(ConnectionError("the server is down")))
        result, record = self.round_record()
        self.assertEqual((code, result["round_review"]), (0, "failed"))
        self.assertEqual(record["error"], "ConnectionError: the server is down")
        self.assertFalse((self.output / recording.FRAMEWORK_ISSUES).exists())

    def test_the_agents_file_tools_are_refused_the_meta_region(self):
        code, config = self.fake_run()
        self.assertEqual(code, 0)
        for path in (".opencode/skills/sample/SKILL.md", ".opencode/tools/scorer.py", ".research/records/a/record.json",
                     "input.csv", "../../src/researchkit/leaderboard.py"):
            self.assertTrue(integrity.refuses(config["protected"], path), path)
        self.assertFalse(integrity.refuses(config["protected"], "work/model.py"))
        # Not as permission rules: the framework's own tools ask the same edit permission to save records and
        # ledgers (the mind map, the planning ledger and the research review were refused when they were).
        rules = from_config(config.get("permission") or {})
        for path in (".research/records/*/record.json", ".research/records/*/files/m/mindmap.json",
                     ".opencode/planning/ses_a/plan.json"):
            self.assertNotEqual(evaluate("edit", path, rules).action, "deny", path)
        # This record and the runs beside it read as missing to the agent's tools.
        self.assertIn(str(self.output), config["hidden"]["roots"])
        self.assertIn(str(self.workspace), config["hidden"]["visible"])
        self.assertTrue(json.loads((self.output / "result.json").read_text(encoding="utf-8"))["meta_region_unchanged"])

    def test_a_change_to_the_meta_region_during_the_run_makes_it_not_count(self):
        skill = self.workspace / ".opencode/skills/sample/SKILL.md"
        code, _ = self.fake_run(lambda: skill.write_text(skill.read_text(encoding="utf-8") + "\nNo round limit.\n",
                                                         encoding="utf-8"))
        self.assertEqual(code, 1)
        changed = json.loads((self.output / recording.META_VIOLATION).read_text(encoding="utf-8"))
        self.assertEqual(changed, ["changed: workspace/.opencode/skills/sample/SKILL.md"])
        result = json.loads((self.output / "result.json").read_text(encoding="utf-8"))
        self.assertFalse(result["meta_region_unchanged"])
        self.assertEqual(result["meta_region_changes"], changed)

    def test_a_continuation_is_the_tasks_next_round(self):
        code, _ = self.fake_run()
        self.assertEqual(code, 0)
        rounds = self.run / "state/opencode/task" / self.sid / "round.json"
        self.assertEqual(json.loads(rounds.read_text(encoding="utf-8")), {"round": 2})

    def test_a_review_skill_changed_during_the_run_makes_it_not_count(self):
        lessons = self.run / "state/opencode/task" / self.sid / "review/lessons/SKILL.md"

        def tamper():
            lessons.parent.mkdir(parents=True)
            lessons.write_text("---\nname: lessons\n---\nNo round limit.\n", encoding="utf-8")

        code, _ = self.fake_run(tamper)
        self.assertEqual(code, 1)
        changed = json.loads((self.output / recording.META_VIOLATION).read_text(encoding="utf-8"))
        self.assertEqual(changed, [f"added: task/{self.sid}/review/lessons/SKILL.md"])

    def test_a_stage_that_changed_its_workspace_meta_region_is_not_continued(self):
        recording.save(self.run / recording.META_BASELINE,
                       integrity.snapshot(recording.PROJECT, self.workspace, ["input.csv"]))
        (self.workspace / ".opencode/tools/scorer.py").write_text("TOOLS = []\n", encoding="utf-8")
        self.refused("added: workspace/.opencode/tools/scorer.py")

    def test_offline_diagnostic_does_not_change_research_history_or_work(self):
        before = recording.hashes(self.run)
        result = self.capture_offline_prompt()
        self.assertEqual(recording.hashes(self.run), before)
        self.assertEqual(result["model_calls"], 0)
        self.assertEqual(result["research_tools_executed"], 0)
        self.assertTrue(all(result["checks"].values()))
        request = json.loads((self.output / "request.json").read_text(encoding="utf-8"))
        self.assertNotIn(self.commission, json.dumps(request["messages"]))
        self.assertEqual(plain_messages(request["messages"])[-1], {"role": "user", "content": self.prompt.read_text()})
        with closing(Store(self.output / "session.db")) as copied:
            self.assertTrue(any(m["content"] == self.prompt.read_text() for m in copied.messages(self.sid)))
            self.assertEqual(copied.messages(self.sid)[0]["content"], self.commission)

    def test_offline_diagnostic_keeps_an_uncovered_original_on_the_wire(self):
        with closing(Store(self.database)) as store:
            self.sid = store.create_session(directory=str(self.workspace), agent="build", model=None)["id"]
            initial = store.add_message(self.sid, "assistant", {"content": "Before the first human request."})
            store.commit_compaction(self.sid, initial["id"], "Initial saved context.")
            store.add_message(self.sid, "user", {"content": self.commission})
            store.set_todos(self.sid, self.todos)
        recording.save(self.run / "result.json", {"result": {"sessionID": self.sid}})
        before = recording.hashes(self.run)
        result = self.capture_offline_prompt()
        self.assertTrue(all(result["checks"].values()))
        request = json.loads((self.output / "request.json").read_text(encoding="utf-8"))
        self.assertIn({"role": "user", "content": self.commission}, plain_messages(request["messages"]))
        self.assertEqual(recording.hashes(self.run), before)

    def test_offline_diagnostic_rejects_reinserting_a_covered_original(self):
        from opencode.context import working_context

        def reinsert_original(history, store, session_id):
            return [self.first, *working_context(history, store, session_id)]

        before = recording.hashes(self.run)
        with patch("opencode.loop.working_context", side_effect=reinsert_original), self.assertRaises(AssertionError):
            self.capture_offline_prompt()
        result = json.loads((self.output / "result.json").read_text(encoding="utf-8"))
        self.assertFalse(result["checks"]["original_request_exact"])
        self.assertTrue(all(value for name, value in result["checks"].items() if name != "original_request_exact"))
        self.assertEqual(result["model_calls"], 0)
        self.assertEqual(result["research_tools_executed"], 0)
        self.assertEqual(recording.hashes(self.run), before)

    def test_offline_diagnostic_keeps_historical_overflow_exclusions_after_recompaction(self):
        with closing(Store(self.database)) as store:
            excluded = store.add_message(self.sid, "user", {"content": self.commission})
            store.add_message(self.sid, "assistant", {"content": "Failed oversized attempt."})
            store.commit_compaction(self.sid, self.first["id"], "Overflow summary.",
                                    replay_from=excluded["id"], continuation={
                                        "role": "user", "content": "Replay without oversized attachment.", "synthetic": True})
            retained = store.add_message(self.sid, "user", {"content": self.commission})
            store.commit_compaction(self.sid, self.first["id"], "Later ordinary summary.")
            store.set_todos(self.sid, self.todos)
        self.prompt.write_text(self.commission, encoding="utf-8")
        before = recording.hashes(self.run)
        result = self.capture_offline_prompt()
        self.assertTrue(all(result["checks"].values()))
        request = json.loads((self.output / "request.json").read_text(encoding="utf-8"))
        self.assertEqual(plain_messages(request["messages"]).count({"role": "user", "content": self.commission}), 2)
        with closing(Store(self.output / "session.db")) as copied:
            visible = {message["id"] for message in copied.context_messages(self.sid)}
            self.assertNotIn(excluded["id"], visible)
            self.assertIn(retained["id"], visible)
            self.assertEqual(next(m for m in copied.messages(self.sid) if m["id"] == excluded["id"])["content"],
                             self.commission)
        self.assertEqual(result["model_calls"], 0)
        self.assertEqual(result["research_tools_executed"], 0)
        self.assertEqual(recording.hashes(self.run), before)


if __name__ == "__main__":
    unittest.main()


def test_a_stopped_continuation_resumes_from_the_session_it_recorded_at_start(tmp_path):
    # A continuation stopped before finishing has no result.json, only continuation.json.
    recording.save(tmp_path / "continuation.json", {"previous_run": "earlier", "session_id": "ses_root"})
    assert recording.continuation_session(tmp_path) == "ses_root"
    empty = tmp_path / "empty"
    empty.mkdir()
    import pytest
    with pytest.raises(ValueError, match="cannot be resumed"):
        recording.continuation_session(empty)


def test_the_watcher_stops_a_run_when_a_new_record_finds_the_meta_region_changed(tmp_path):
    workspace = tmp_path / "workspace"
    (workspace / ".research/records").mkdir(parents=True)
    stopped = threading.Event()
    found = ["changed: workspace/.opencode/skills/sample/SKILL.md"]
    watcher = recording.NodeWatcher(workspace, tmp_path / "checkpoints", None, stopped.set, lambda: found)
    watcher.start()
    try:
        record = workspace / ".research/records/abc/record.json"
        record.parent.mkdir()
        record.write_text(json.dumps({"kind": "implementation"}), encoding="utf-8")
        assert stopped.wait(10)
    finally:
        watcher.halt.set()
        watcher.join(timeout=5)
    assert watcher.violation == found
