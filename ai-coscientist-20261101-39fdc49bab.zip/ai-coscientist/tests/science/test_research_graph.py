"""Reasoning graph: validation, revisions and change propagation; no model calls."""

import json
from pathlib import Path

import pytest

from opencode.app import App
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from researchkit import board, graph, records
from scripts.setup_research_workspace import install
from tests.prompt_view import host_facts, plain_messages


def node(id, type, status, text=None, **extra):
    return {"id": id, "type": type, "status": status, "text": text or f"{type} {id}", "reason": "test", **extra}


@pytest.fixture
def world(tmp_path):
    (tmp_path / "score.md").write_text("tau=1, n=2", encoding="utf-8")
    ref = records.publish(tmp_path, kind="calibration", title="score", files=["score.md"], depends_on=[])["record_path"]
    store = graph.GraphStore(tmp_path)
    first = store.update({"expected_revision": None, "reason": "start", "nodes": [
        node("Q1", "question", "open"),
        node("C1", "conjecture", "proposed"),
        node("O1", "observation", "valid", records=[ref], edges=[{"type": "supports", "to": "C1"}]),
        node("D1", "decision", "active", edges=[{"type": "based_on", "to": "O1"}, {"type": "based_on", "to": "C1"}],
             requirement_ids=["R1"]),
        node("A1", "decision", "active", edges=[{"type": "based_on", "to": "D1"}]),
        node("B1", "decision", "active", edges=[{"type": "based_on", "to": "A1"}]),
    ]})
    return tmp_path, store, ref, first


def head_state(store):
    return store.read()[1]["state"]


def test_first_revision_has_no_flags_and_is_content_addressed(world):
    root, store, ref, first = world
    assert first["needs_review"] == {} and first["indirectly_affected"] == []
    raw = (root / first["revision_ref"]).read_bytes()
    assert Path(first["revision_ref"]).stem == records.digest(raw)
    assert json.loads((root / ".research/graph/head.json").read_bytes())["revision_ref"] == first["revision_ref"]
    assert not (root / ".research/graph/.lock").exists()


def test_superseding_flags_direct_dependents_and_lists_indirect_ones(world):
    root, store, ref, first = world
    result = store.update({"expected_revision": first["revision_ref"], "reason": "user changed the rule",
                           "nodes": [node("D2", "decision", "active", "Rank by consensus", supersedes="D1")]})
    assert result["needs_review"] == {"A1": ["上游 D1 已被 D2 取代"]}
    assert result["indirectly_affected"] == ["B1"]
    assert head_state(store)["nodes"]["D1"]["superseded_by"] == "D2"
    cleared = store.update({"expected_revision": result["revision_ref"], "reason": "checked",
                            "reviews": [{"node_id": "A1", "reason": "Still valid under D2"}]})
    assert cleared["needs_review"] == {} and cleared["indirectly_affected"] == []
    assert head_state(store)["nodes"]["A1"]["last_review"] == "Still valid under D2"


def test_updating_a_node_clears_its_own_flag_but_flags_its_dependents(world):
    root, store, ref, first = world
    second = store.update({"expected_revision": first["revision_ref"], "reason": "fact overturned",
                           "nodes": [node("O1", "observation", "overturned", records=[ref],
                                          edges=[{"type": "supports", "to": "C1"}])]})
    assert second["needs_review"] == {"C1": ["上游 O1 狀態為 overturned"], "D1": ["上游 O1 狀態為 overturned"]}
    third = store.update({"expected_revision": second["revision_ref"], "reason": "rework D1",
                          "nodes": [node("D1", "decision", "active", "Rank by P1 pending new evidence",
                                         edges=[{"type": "based_on", "to": "O1"}, {"type": "based_on", "to": "C1"}],
                                         requirement_ids=["R1"])]})
    assert "D1" not in third["needs_review"] and third["needs_review"]["A1"] == ["上游 D1 內容已更新"]


def test_new_evidence_flags_the_conjecture_it_bears_on(world):
    root, store, ref, first = world
    result = store.update({"expected_revision": first["revision_ref"], "reason": "second score",
                           "nodes": [node("O2", "observation", "valid", records=[ref],
                                          edges=[{"type": "contradicts", "to": "C1"}])]})
    assert result["needs_review"] == {"C1": ["上游 O2 是新連入的依據或證據"]}


def test_requirement_change_or_withdrawal_flags_linked_decisions(world):
    root, store, ref, first = world
    requirement = {"id": "R1", "text": "Evolve samples", "source_message_ids": ["m1"], "disposition": "active",
                   "reason": "asked"}
    second = store.update({"expected_revision": first["revision_ref"], "reason": "bind requirement",
                           "reviews": [{"node_id": "D1", "reason": "Serves R1"}]}, requirements={"R1": requirement})
    assert second["needs_review"] == {}
    withdrawn = dict(requirement, disposition="withdrawn", reason="user dropped evolution")
    direct, indirect = graph.flags(head_state(store), requirements={"R1": withdrawn})
    assert direct == {"D1": ["要求 R1 已撤回"]} and indirect == ["A1", "B1"]
    direct, _ = graph.flags(head_state(store), requirements={"R1": dict(requirement, text="Evolve once")})
    assert direct == {"D1": ["要求 R1 已修改"]}
    assert graph.flags(head_state(store), requirements=None) == ({}, [])


@pytest.mark.parametrize("bad, message", [
    (node("C9", "conjecture", "supported"), "keep status proposed"),
    (node("O9", "observation", "valid"), "must cite at least one saved record"),
    (node("O9", "observation", "valid", records=[".research/records/" + "0" * 64 + "/record.json"]),
     "cannot be read as a saved record"),
    (node("X", "decision", "active", edges=[{"type": "based_on", "to": "missing"}]), "does not exist"),
    (node("X", "decision", "active", edges=[{"type": "supports", "to": "C1"}]), "observation to a conjecture"),
    (node("X", "decision", "active", supersedes="C1"), "supersedes"),
    (node("Q1", "conjecture", "proposed"), "cannot change type"),
    (node("Q1", "question", "closed"), "status must be one of"),
    (node("1bad", "question", "open"), "node id"),
    (node("D1", "decision", "active", edges=[{"type": "based_on", "to": "B1"}]), "cycle"),
])
def test_invalid_nodes_are_rejected_without_a_new_revision(world, bad, message):
    root, store, ref, first = world
    with pytest.raises((ValueError, OSError), match=message):
        store.update({"expected_revision": first["revision_ref"], "reason": "bad", "nodes": [bad]})
    assert store.head() == first["revision_ref"]


def test_supported_conjecture_with_evidence_is_accepted(world):
    root, store, ref, first = world
    result = store.update({"expected_revision": first["revision_ref"], "reason": "weak support",
                           "nodes": [node("C1", "conjecture", "supported")]})
    assert result["changed"] == ["C1"] and result["needs_review"] == {"D1": ["上游 C1 內容已更新"]}


def test_stale_expected_revision_and_empty_update_are_rejected(world):
    root, store, ref, first = world
    store.update({"expected_revision": first["revision_ref"], "reason": "x", "nodes": [node("Q2", "question", "open")]})
    with pytest.raises(ValueError, match="not the current graph head"):
        store.update({"expected_revision": first["revision_ref"], "reason": "stale", "nodes": [node("Q3", "question", "open")]})
    with pytest.raises(ValueError, match="Provide nodes"):
        store.update({"expected_revision": store.head(), "reason": "nothing"})
    same = store.update({"expected_revision": store.head(), "reason": "same", "nodes": [node("Q2", "question", "open")]})
    assert same["changed"] == [] and "no-change" in same["notice"]


def test_board_shows_flags_first_and_stays_bounded(world):
    root, store, ref, first = world
    store.update({"expected_revision": first["revision_ref"], "reason": "rule change",
                  "nodes": [node("D2", "decision", "active", "Rank by consensus", supersedes="D1")]})
    text = board.render(board.build(root))
    section = text.split("推理圖（需要重看的節點優先）：", 1)[1]
    assert section.index("需要重看 decision A1") < section.index("decision D2（active）")
    assert "間接受影響（待上游處理後再看）：B1" in section
    assert "conjecture C1（proposed）" in section and "支持 O1" in section
    assert "decision D1" not in section.split("一致性提醒")[0].replace("上游 D1", "")
    assert len(text.encode("utf-8")) <= board.MAX_CONTEXT_BYTES


def test_calibration_without_host_score_file_is_named_not_missing(tmp_path):
    def save(kind, files, deps=()):
        for name, content in files.items():
            (tmp_path / name).write_text(content, encoding="utf-8")
        return records.publish(tmp_path, kind=kind, title=kind, files=list(files),
                               depends_on=[d["record_path"] for d in deps])
    hypothesis = save("hypothesis", {"h.md": "H1"})
    formula = save("proxy_formula", {"p.md": "P1"}, [hypothesis])
    calibration = save("calibration", {"calibration.md": "tau=1 written by hand"}, [formula])
    notices = "\n".join(board.build(tmp_path)["notices"])
    assert f"有 calibration 紀錄 {calibration['record_path'].split('/')[2][:8]}" in notices
    assert "未附 research_compare 產生的結果 JSON" in notices
    assert "尚無依賴它的 calibration" not in notices


def test_agent_loop_withdrawn_requirement_flags_decision_in_next_system(tmp_path, monkeypatch):
    from types import SimpleNamespace
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()
    install(root, planning=True)
    store = Store(tmp_path / "session.db")
    app = App(root, store=store, auto_approve=True, config={})
    app.generate_titles = False
    sid = app.create_session()["id"]
    calls, state = [], {}

    def requirement(human, disposition):
        return {"id": "R1", "text": "Evolve samples", "source_message_ids": [human], "disposition": disposition,
                "reason": "asked" if disposition == "active" else "user dropped evolution"}

    def complete(**kwargs):
        calls.append(kwargs)
        n = len(calls)
        human = next(m for m in store.messages(sid) if m["role"] == "user")["id"]
        if n == 1:
            return Completion(tool_calls=[ToolCall("p1", "planning_update", {
                "expected_revision": None, "reason": "record goal",
                "commission": {"summary": "Evolve samples", "source_message_ids": [human],
                               "observed_through_message_id": human},
                "requirements": [requirement(human, "active")]})], finish_reason="tool-calls")
        if n == 2:
            return Completion(tool_calls=[ToolCall("g1", "research_graph_update", {
                "expected_revision": None, "reason": "rule",
                "nodes": [node("D1", "decision", "active", "Rank by P1", requirement_ids=["R1"])]})],
                finish_reason="tool-calls")
        if n == 3:
            state["revision"] = json.loads(plain_messages(kwargs["messages"])[-1]["content"])["revision_ref"]
            plan_ref = json.loads((root / f".opencode/planning/{sid}/head.json").read_bytes())["revision_ref"]
            return Completion(tool_calls=[ToolCall("p2", "planning_update", {
                "expected_revision": plan_ref, "reason": "user dropped it",
                "requirements": [requirement(human, "withdrawn")]})], finish_reason="tool-calls")
        return Completion(text="done", finish_reason="stop")

    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                   complete=complete)
    assert app.prompt(sid, "Evolve samples")["text"] == "done"
    assert "decision D1（active）" in host_facts(calls[2])
    assert "需要重看 decision" not in host_facts(calls[2])
    assert "需要重看 decision D1" in host_facts(calls[3]) and "要求 R1 已撤回" in host_facts(calls[3])
    store.close()
