"""Offline C-wrapper boundaries, using real records, review assembly and solver.

Model completions below are transport fixtures, not expected scientific answers.
No network requests or claims about reviewer scientific accuracy are made.
"""

from copy import deepcopy
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Broker, PermissionDenied, PermissionRejected, Rule
from opencode.provider import Completion, ProviderError
from researchkit import inference, records, research_inference, reviewer


@pytest.fixture(autouse=True)
def no_live_model_or_network(monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("This boundary replay must not contact a model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)


@pytest.fixture
def case(tmp_path):
    def save(files, dependencies=()):
        for name, text in files.items():
            path = tmp_path / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(text.encode("utf-8"))
        return records.publish(tmp_path, kind="notes", title="Offline boundary fixture",
                               files=list(files), depends_on=list(dependencies))

    ancestor = save({"ancestor.txt": "UNSELECTED_ANCESTOR_CONTENT"})
    claim = "Claim: q is positive under the stated formal premise."
    goal_text = "GOAL_FULL_SOURCE_START\r\n" + claim + "\r\nGOAL_FULL_SOURCE_END\r\n"
    goal = save({"claim.txt": goal_text, "private-claim.txt": "UNSELECTED_CLAIM_CONTENT"},
                [ancestor["record_path"]])
    premise_text = "PREMISE_FULL_SOURCE_START\nPremise: q is at least one.\nPREMISE_FULL_SOURCE_END\n"
    source = save({"premise.txt": premise_text, "private-premise.txt": "UNSELECTED_PREMISE_CONTENT"})
    goal_cite = {"record_ref": goal["record_path"], "source_path": "claim.txt", "quote": claim}
    premise_cite = {"record_ref": source["record_path"], "source_path": "premise.txt",
                    "quote": "Premise: q is at least one."}
    args = {
        "scope": "Test an explicit formal implication and its review handoff",
        "goal": {"source": goal_cite, "expr": "(> q 0)",
                 "interpretation": "The author's formal test claim"},
        "variables": [{"name": "q", "sort": "Real", "meaning": "Formal test quantity", "unit": "1"}],
        "premises": [{"id": "p1", "origin": "source", "expr": "(>= q 1)",
                      "sources": [premise_cite, deepcopy(premise_cite)],
                      "interpretation": "The author's explicit lower bound"}],
    }
    ctx = SimpleNamespace(
        directory=tmp_path, worktree=tmp_path, session_id="offline-inference-session",
        message_id="offline-inference-message", call_id="offline-inference-call",
        model="unchanged-parent-model", abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")],
                              prompt="PARENT_PRIVATE_PROMPT", options={}),
        app=SimpleNamespace(permissions=Broker(auto=True),
                            store=SimpleNamespace(messages=Mock(side_effect=AssertionError("No history")),
                                                  todos=Mock(side_effect=AssertionError("No plan"))),
                            system="PARENT_PRIVATE_SYSTEM", history=["PARENT_PRIVATE_HISTORY"]),
    )
    return SimpleNamespace(root=tmp_path, args=args, ctx=ctx, goal=goal, source=source,
                           ancestor=ancestor, goal_text=goal_text, premise_text=premise_text)


def frozen(root, record, basename):
    entry, = [item for item in record["files"] if Path(item["source_path"]).name == basename]
    return root / Path(record["record_path"]).parent / entry["snapshot"]


def preparations(root):
    return [record for record in records.inventory(root)
            if any(item["source_path"].startswith(".research/inference-preparations/")
                   and Path(item["source_path"]).name == "arguments.json" for item in record["files"])]


def install_review_transport(monkeypatch, case, *, decision="conditional", fail_stage=None,
                             cancel_stage=None, after_review=None, mutate_caller=False,
                             reasoning_only_calls=()):
    """Keep reviewer.execute real; only provide offline provider completions."""
    trace = SimpleNamespace(arguments=None, messages=[], outputs=[], calls=0, recoveries=[])
    original = reviewer.execute

    def completion(ctx, **kwargs):
        trace.calls += 1
        trace.messages.append(deepcopy(kwargs["messages"]))
        trace.recoveries.append(kwargs.get("recovery_temperature"))
        assert ctx is case.ctx
        assert not list((case.root / ".research/inference-runs").glob("*/result.json"))
        assert not list((case.root / ".research/inference-preparations").glob("*/result.json"))
        if trace.calls == fail_stage:
            raise ValueError("Injected offline review-stage failure")
        if trace.calls == cancel_stage:
            case.ctx.abort.set()
        if reasoning_only_calls:
            state = {"provider": SimpleNamespace(api="openai"), "temperature": 0,
                     "temperature_supported": True}
            for name in ("prepared", "frozen"):
                for key, value in state.items():
                    kwargs[name].setdefault(key, value)
            if trace.calls in reasoning_only_calls:
                return Completion(text="", reasoning_content="PRIVATE_RECOVERY_REASONING",
                                  finish_reason="stop")
        if mutate_caller:
            case.args["goal"]["expr"] = "(< q 0)"
            case.args["scope"] = "MUTATED_CALLER_ARGUMENTS"
        candidate_id = next(f"F{index}" for index, locator in enumerate(trace.arguments["files"], 1)
                            if Path(locator["source_path"]).name == "input.json")
        input_text = trace.arguments["required_subjects"][1]["quote"]
        evidence = [{"file_id": candidate_id, "start_line": 1,
                     "end_line": len(input_text.splitlines())}]
        value = {"checks": [{"subject": {"required_subject": index},
                              "evidence": evidence, "decision": decision,
                              "reason": f"Offline stage {trace.calls}; no scientific verdict is asserted."}
                             for index in (1, 2)]}
        return Completion(text=json.dumps(value), finish_reason="stop")

    def execute(args, ctx):
        trace.arguments = deepcopy(args)
        output = original(args, ctx)
        trace.outputs.append(output.output)
        if after_review:
            after_review(args, output)
        return output

    monkeypatch.setattr(reviewer, "complete_once", completion)
    monkeypatch.setattr(reviewer, "execute", execute)
    return trace


@pytest.mark.parametrize("decision", ["unsupported", "contradicted", "conditional", "unassessed"])
def test_real_wrapper_freezes_reviews_and_solves_identical_input(case, monkeypatch, decision):
    pytest.importorskip("z3")
    original_args = deepcopy(case.args)
    trace = install_review_transport(monkeypatch, case, decision=decision)
    receipt = json.loads(research_inference.execute(case.args, case.ctx).output)
    candidate, = preparations(case.root)
    candidate_raw = frozen(case.root, candidate, "input.json").read_bytes()
    canonical = json.loads(candidate_raw)
    expected = deepcopy(original_args)
    for citation in inference._citations(expected):
        citation.update(start_line=2, end_line=2)
    assert canonical == expected
    assert case.args == original_args
    assert json.loads(frozen(case.root, candidate, "arguments.json").read_bytes()) == original_args
    assert candidate["kind"] == "implementation"
    assert {Path(item["source_path"]).name for item in candidate["files"]} == {"arguments.json", "input.json"}
    source_refs = [case.goal["record_path"], case.source["record_path"]]
    assert candidate["depends_on"] == source_refs

    candidate_entry, = [item for item in candidate["files"] if Path(item["source_path"]).name == "input.json"]
    candidate_locator = {"record_ref": candidate["record_path"], "source_path": candidate_entry["source_path"]}
    assert trace.arguments["reviewed_refs"] == [candidate["record_path"], case.goal["record_path"]]
    assert trace.arguments["required_subjects"] == [
        original_args["goal"]["source"], {**candidate_locator, "quote": candidate_raw.decode("utf-8")}]
    assert trace.arguments["files"] == [
        {key: original_args["goal"]["source"][key] for key in ("record_ref", "source_path")},
        {key: original_args["premises"][0]["sources"][0][key] for key in ("record_ref", "source_path")},
        candidate_locator]
    assert trace.calls == 2
    for messages in trace.messages:
        request = json.dumps(messages, ensure_ascii=False)
        for marker in ("GOAL_FULL_SOURCE_START", "GOAL_FULL_SOURCE_END",
                       "PREMISE_FULL_SOURCE_START", "PREMISE_FULL_SOURCE_END"):
            assert marker in request
        for private in ("UNSELECTED_ANCESTOR_CONTENT", "UNSELECTED_CLAIM_CONTENT",
                        "UNSELECTED_PREMISE_CONTENT", "PARENT_PRIVATE_PROMPT",
                        "PARENT_PRIVATE_SYSTEM", "PARENT_PRIVATE_HISTORY", "solver_version",
                        "base_counterexample", "result.json"):
            assert private not in request

    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on", "result",
                            "review_record_ref", "review"}
    review_record = {"record_path": receipt["review_record_ref"],
                     **records.read_record(case.root, receipt["review_record_ref"])}
    assert review_record["kind"] == "review"
    assert {Path(item["source_path"]).name for item in review_record["files"]} == {"review.json"}
    assert set(review_record["depends_on"]) == {*source_refs, candidate["record_path"]}
    assert frozen(case.root, review_record, "review.json").read_bytes() == trace.outputs[0].encode("utf-8")
    assert receipt["review"] == json.loads(trace.outputs[0])
    assert set(receipt["review"]) == {"reviewed_refs", "checks"}
    assert [check["decision"] for check in receipt["review"]["checks"]] == [decision, decision]

    solver_record = {"record_path": receipt["record_path"],
                     **records.read_record(case.root, receipt["record_path"])}
    assert frozen(case.root, solver_record, "input.json").read_bytes() == candidate_raw
    assert receipt["result"]["input_sha256"] == records.digest(candidate_raw)
    assert receipt["result"] == json.loads(frozen(case.root, solver_record, "result.json").read_bytes())
    assert solver_record["depends_on"] == [*source_refs, candidate["record_path"], receipt["review_record_ref"]]
    assert [query["status"] for query in receipt["result"]["queries"]] == ["sat", "unsat", "not_run", "not_run"]


def test_caller_mutation_cannot_replace_the_reviewed_input(case, monkeypatch):
    pytest.importorskip("z3")
    original = deepcopy(case.args)
    install_review_transport(monkeypatch, case, mutate_caller=True)
    receipt = json.loads(research_inference.execute(case.args, case.ctx).output)
    candidate, = preparations(case.root)
    assert case.args != original
    assert json.loads(frozen(case.root, candidate, "arguments.json").read_bytes()) == original
    assert json.loads(frozen(case.root, candidate, "input.json").read_bytes())["goal"]["expr"] == original["goal"]["expr"]
    solver = {"record_path": receipt["record_path"], **records.read_record(case.root, receipt["record_path"])}
    assert frozen(case.root, candidate, "input.json").read_bytes() == frozen(case.root, solver, "input.json").read_bytes()


@pytest.mark.parametrize("permission", ["check_inference", "research_review", "read", "edit"])
def test_all_authority_is_preflighted_before_candidate_or_model(case, monkeypatch, permission):
    case.ctx.agent.permission.append(Rule(permission, "*", "deny"))
    no_solver = Mock(side_effect=AssertionError("Denied work must not invoke solver"))
    no_review = Mock(side_effect=AssertionError("Denied work must not invoke review"))
    monkeypatch.setattr(inference, "run", no_solver)
    monkeypatch.setattr(reviewer, "execute", no_review)
    with pytest.raises(PermissionDenied):
        research_inference.execute(case.args, case.ctx)
    no_solver.assert_not_called()
    no_review.assert_not_called()
    assert not list((case.root / ".research/inference-preparations").glob("*"))
    assert not list((case.root / ".research/inference-runs").glob("*"))
    assert len(records.inventory(case.root)) == 3


@pytest.mark.parametrize("stage", [1, 2])
def test_review_failure_preserves_candidate_and_only_completed_initial_stage(case, monkeypatch, stage):
    trace = install_review_transport(monkeypatch, case, fail_stage=stage)
    solver = Mock(side_effect=AssertionError("Failed review must not invoke inference"))
    monkeypatch.setattr(inference, "run", solver)
    with pytest.raises(ValueError, match="Injected offline review-stage failure"):
        research_inference.execute(case.args, case.ctx)
    solver.assert_not_called()
    assert trace.calls == stage
    candidate, = preparations(case.root)
    assert frozen(case.root, candidate, "input.json").is_file()
    assert not [record for record in records.inventory(case.root) if record["kind"] == "review"]
    initial = list((case.root / ".research/review-runs").glob("*/initial/review.json"))
    assert len(initial) == (1 if stage == 2 else 0)
    assert not list((case.root / ".research/inference-runs").glob("*"))


@pytest.mark.parametrize("stage", [0, 1, 2, 3])
def test_cancellation_never_starts_next_stage_and_preserves_prior_work(case, monkeypatch, stage):
    if stage == 0:
        case.ctx.abort.set()
    trace = install_review_transport(
        monkeypatch, case, cancel_stage=stage,
        after_review=(lambda args, result: case.ctx.abort.set()) if stage == 3 else None)
    solver = Mock(side_effect=AssertionError("Cancelled work must not invoke inference"))
    monkeypatch.setattr(inference, "run", solver)
    with pytest.raises((PermissionRejected, ProviderError)):
        research_inference.execute(case.args, case.ctx)
    solver.assert_not_called()
    assert trace.calls == min(stage, 2)
    assert len(preparations(case.root)) == (0 if stage == 0 else 1)
    initial = list((case.root / ".research/review-runs").glob("*/initial/review.json"))
    assert len(initial) == (1 if stage >= 2 else 0)
    assert not [record for record in records.inventory(case.root) if record["kind"] == "review"]


def test_solver_execution_failure_preserves_published_review_and_candidate(case, monkeypatch):
    trace = install_review_transport(monkeypatch, case)
    computation = Mock(side_effect=RuntimeError("Injected offline solver execution failure"))
    monkeypatch.setattr(inference, "_compute", computation)
    with pytest.raises(RuntimeError, match="Injected offline solver execution failure"):
        research_inference.execute(case.args, case.ctx)
    computation.assert_called_once()
    assert trace.calls == 2
    candidate, = preparations(case.root)
    review_record, = [record for record in records.inventory(case.root) if record["kind"] == "review"]
    assert candidate["record_path"] in review_record["depends_on"]
    assert frozen(case.root, review_record, "review.json").read_bytes() == trace.outputs[0].encode("utf-8")
    saved_input, = (case.root / ".research/inference-runs").glob("*/input.json")
    assert saved_input.read_bytes() == frozen(case.root, candidate, "input.json").read_bytes()
    assert not list((case.root / ".research/inference-runs").glob("*/result.json"))


def test_cancellation_after_review_publication_keeps_both_prior_records(case, monkeypatch):
    trace = install_review_transport(monkeypatch, case)
    original = inference.run

    def cancel_before_run(*args, **kwargs):
        case.ctx.abort.set()
        return original(*args, **kwargs)

    monkeypatch.setattr(inference, "run", cancel_before_run)
    computation = Mock(side_effect=AssertionError("Cancelled invocation must not compute"))
    monkeypatch.setattr(inference, "_compute", computation)
    with pytest.raises((PermissionRejected, ProviderError)):
        research_inference.execute(case.args, case.ctx)
    computation.assert_not_called()
    candidate, = preparations(case.root)
    reviewed, = [record for record in records.inventory(case.root) if record["kind"] == "review"]
    assert candidate["record_path"] in reviewed["depends_on"]
    assert frozen(case.root, reviewed, "review.json").read_bytes() == trace.outputs[0].encode("utf-8")
    assert not list((case.root / ".research/inference-runs").glob("*"))


@pytest.mark.parametrize("empty_calls", [(1,), (2,), (1, 3)])
def test_wrapper_keeps_one_shared_recovery_and_three_generation_limit(case, monkeypatch, empty_calls):
    pytest.importorskip("z3")
    trace = install_review_transport(monkeypatch, case, reasoning_only_calls=empty_calls)
    if len(empty_calls) == 2:
        solver = Mock(side_effect=AssertionError("Exhausted recovery must not invoke inference"))
        monkeypatch.setattr(inference, "run", solver)
        with pytest.raises(ValueError, match="complete nonempty final answer"):
            research_inference.execute(case.args, case.ctx)
        solver.assert_not_called()
        assert not [record for record in records.inventory(case.root) if record["kind"] == "review"]
    else:
        receipt = json.loads(research_inference.execute(case.args, case.ctx).output)
        assert receipt["review"] == json.loads(trace.outputs[0])
    assert trace.calls == 3
    assert trace.recoveries.count(0.6) == 1
    assert trace.recoveries.count(None) == 2
    assert "PRIVATE_RECOVERY_REASONING" not in json.dumps(trace.messages)
    candidate, = preparations(case.root)
    assert frozen(case.root, candidate, "input.json").is_file()
    assert len(list((case.root / ".research/review-runs").glob("*/initial/review.json"))) == 1


@pytest.mark.parametrize("target", ["candidate", "source"])
def test_changed_frozen_input_or_source_stops_before_solver(case, monkeypatch, target):
    def tamper(args, output):
        if target == "candidate":
            candidate, = preparations(case.root)
            path = frozen(case.root, candidate, "input.json")
        else:
            path = frozen(case.root, case.source, "premise.txt")
        path.write_bytes(path.read_bytes() + b"\nchanged after review")

    trace = install_review_transport(monkeypatch, case, after_review=tamper)
    solver = Mock(side_effect=AssertionError("Changed input must not invoke solver"))
    monkeypatch.setattr(inference, "run", solver)
    with pytest.raises((RuntimeError, ValueError), match="changed|differ|hash|bytes"):
        research_inference.execute(case.args, case.ctx)
    solver.assert_not_called()
    assert trace.calls == 2
    assert list((case.root / ".research/inference-preparations").glob("*/arguments.json"))
    assert not list((case.root / ".research/inference-runs").glob("*"))


@pytest.mark.parametrize("kind", ["implementation", "review"])
def test_publication_sampling_change_cannot_be_returned_or_solved(case, monkeypatch, kind):
    trace = install_review_transport(monkeypatch, case)
    original = records.publish

    def publish(root, **kwargs):
        if kwargs["kind"] == kind:
            name = "input.json" if kind == "implementation" else "review.json"
            selected, = [source for source in kwargs["files"] if Path(source).name == name]
            path = root / selected
            path.write_bytes(path.read_bytes() + b"\n ")
        return original(root, **kwargs)

    monkeypatch.setattr(records, "publish", publish)
    solver = Mock(side_effect=AssertionError("Changed publication must not invoke solver"))
    monkeypatch.setattr(inference, "run", solver)
    with pytest.raises((RuntimeError, ValueError), match="changed|differ|readback|bytes"):
        research_inference.execute(case.args, case.ctx)
    solver.assert_not_called()
    assert trace.calls == (0 if kind == "implementation" else 2)
    assert list((case.root / ".research/inference-preparations").glob("*/input.json"))

