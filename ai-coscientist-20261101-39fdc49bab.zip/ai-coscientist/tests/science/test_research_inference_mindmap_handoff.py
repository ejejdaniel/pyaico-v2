"""Offline C-to-mindmap handoff only; no live model or scientific acceptance.

The formal input is a transport fixture. Mindmap replies predate that input and
are replayed unchanged: they cannot prove scientific consumption or revision.
"""

from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from researchkit import mindmap, records, report_evidence, research_inference
from test_mindmap_checkpoint import checkpoints, resumed
from test_mindmap_generation import install_replies, offline, packet, saved_replies, save, snapshot
from test_research_inference import install_review_transport, no_live_model_or_network


def test_three_frozen_inference_files_reach_only_resumed_deepening(
        monkeypatch, packet, saved_replies):
    pytest.importorskip("z3")
    initial_model = install_replies(monkeypatch, saved_replies[:2])
    mindmap.execute({**packet.args, "pause_after": "architecture"}, packet.ctx)
    assert initial_model.call_count == 2
    prior = checkpoints(packet)
    assert len(prior) == 2
    paused = prior[-1]
    before = {item.locator["record_ref"]:
              snapshot(packet.root, item.record, item.locator["source_path"]).read_bytes()
              for item in prior}

    source = save(packet.root, {"formal-handoff.txt":
                  "Offline transport fixture only.\nPremise: q is at least one.\nClaim: q is positive.\n"})

    def citation(quote):
        return {"record_ref": source["record_path"], "source_path": "formal-handoff.txt", "quote": quote}

    args = {
        "scope": "Offline handoff of authored formal input; no scientific acceptance",
        "goal": {"source": citation("Claim: q is positive."), "expr": "(> q 0)",
                 "interpretation": "Explicit transport-fixture claim"},
        "variables": [{"name": "q", "sort": "Real", "meaning": "Formal fixture variable", "unit": "1"}],
        "premises": [{"id": "p1", "origin": "source", "expr": "(>= q 1)",
                      "sources": [citation("Premise: q is at least one.")],
                      "interpretation": "Explicit transport-fixture premise"}],
    }
    packet.ctx.message_id = "offline-handoff-message"
    packet.ctx.call_id = "offline-handoff-inference"
    case = SimpleNamespace(root=packet.root, ctx=packet.ctx, args=args)
    review_trace = install_review_transport(monkeypatch, case, decision="unassessed")
    inferred = json.loads(research_inference.execute(args, packet.ctx).output)
    assert review_trace.calls == 2
    review_record = records.read_record(packet.root, inferred["review_record_ref"])

    def select(record, ref, basename):
        entry, = [item for item in record["files"] if Path(item["source_path"]).name == basename]
        return {"record_ref": ref, "source_path": entry["source_path"]}

    choices = [select(inferred, inferred["record_path"], name) for name in ("input.json", "result.json")]
    choices.append(select(review_record, inferred["review_record_ref"], "review.json"))
    expected = report_evidence.resolve(packet.root, choices)
    assert [Path(item["source_path"]).name for item in choices] == ["input.json", "result.json", "review.json"]
    assert json.loads(expected[0]["text"])["goal"]["expr"] == args["goal"]["expr"]
    assert json.loads(expected[1]["text"]) == inferred["result"]
    assert json.loads(expected[2]["text"]) == inferred["review"]
    assert expected[2]["text"].encode("utf-8") == review_trace.outputs[0].encode("utf-8")
    for choice in choices:
        (packet.root / choice["source_path"]).write_text("MUTABLE_HANDOFF_COPY_PRIVATE", encoding="utf-8")

    # Only this invocation is the resumed handoff: its sole stub completion is
    # the previously saved third-stage reply, not an answer authored for C.
    deepening_model = install_replies(monkeypatch, saved_replies[2:])
    resumed_args = {**resumed(packet, paused), "additional_evidence": deepcopy(choices)}
    completed = json.loads(mindmap.execute(resumed_args, packet.ctx).output)
    assert deepening_model.call_count == 1
    request = deepening_model.call_args.kwargs
    assert records.digest(request["system"].encode("utf-8")) == paused.value["system_sha256"]["deepening"]
    message = request["messages"][0]["content"]
    for selected in [*report_evidence.resolve(packet.root, packet.args["files"]), *expected]:
        assert mindmap._json(selected["text"]) in message
        assert selected["record_ref"] in message
        assert selected["source_path"] in message
        assert selected["sha256"] in message
    assert "MUTABLE_HANDOFF_COPY_PRIVATE" not in message
    for stage in ("observation", "architecture"):
        assert mindmap._json(paused.value[stage]) in message

    after = checkpoints(packet)
    assert len(after) == 3
    final = after[-1]
    assert final.value["additional_evidence"] == choices
    assert final.value["deepening"] == saved_replies[2]
    for item in prior:
        assert snapshot(packet.root, item.record, item.locator["source_path"]).read_bytes() == before[item.locator["record_ref"]]
    source_refs = [packet.task["record_path"], packet.evidence["record_path"],
                   inferred["record_path"], inferred["review_record_ref"]]
    assert final.record["depends_on"] == [*source_refs, paused.locator["record_ref"]]
    assert completed["depends_on"] == [*source_refs, final.locator["record_ref"]]
    closure = records._read_dependencies(packet.root, [completed["record_path"]])
    candidate_ref = inferred["review"]["reviewed_refs"][0]
    assert {*source_refs, source["record_path"], candidate_ref,
            paused.locator["record_ref"], packet.ancestor["record_path"]} <= set(closure)
    assert report_evidence.resolve(packet.root, choices) == expected
