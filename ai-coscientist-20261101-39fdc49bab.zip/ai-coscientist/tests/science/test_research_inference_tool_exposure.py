"""Offline App.prompt tool exposure/dispatch only; no scientific execution claim."""

from copy import deepcopy
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import Mock

import httpx

from opencode.provider import Completion, ToolCall
from opencode.tools.types import ToolResult
from researchkit.inference import INPUT_SCHEMA as INFERENCE_INPUT_SCHEMA
from researchkit.research_inference import execute
from researchkit.tools import TOOLS
import test_research_tools as research_cases


def test_installed_app_exposes_schema_and_dispatches_research_inference(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Tool exposure test must not contact a model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    # Keep the existing installation fixture inside the writable workspace;
    # Windows sandbox TEMP can reject atomic history-file replacements.
    test_temp = Path(__file__).resolve().parents[2] / "tmp/test-inference-tool-exposure"
    test_temp.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(tempfile, "tempdir", str(test_temp))
    case = research_cases.ResearchTools(methodName="runTest")
    case.setUp()
    try:
        ctx = case.ctx()  # Existing installer followed by the ordinary App.
        app = ctx.app
        app.generate_titles = False
        registered = next(tool for tool in app.extra_tools if tool.name == "research_inference")
        assert registered is next(tool for tool in TOOLS if tool.name == "research_inference")
        assert registered.execute.__wrapped__ is execute  # behind the host's record-reference resolution

        # Explicit synthetic routing input. The spy does not read this source,
        # review a claim, invoke the solver, or return a scientific receipt.
        arguments = {
            "scope": "Offline tool schema and dispatch fixture only.",
            "goal": {"expr": "(> x 0)", "interpretation": "Routing fixture goal.",
                     "source": {"record_ref": ".research/records/" + "0" * 64 + "/record.json",
                                "source_path": "routing-fixture.txt", "quote": "Routing fixture goal."}},
            "variables": [{"name": "x", "sort": "Real", "meaning": "Routing fixture variable.", "unit": "1"}],
            "premises": [{"id": "p1", "expr": "(> x 0)", "origin": "assumption",
                          "interpretation": "Routing fixture assumption.", "sources": []}],
        }
        marker = "OFFLINE_EXPOSURE_AND_DISPATCH_ONLY"
        dispatch = Mock(return_value=ToolResult(output=marker, title="routing probe"))
        monkeypatch.setattr(registered, "execute", dispatch)
        captured = []

        def complete(**request):
            captured.append(request)
            if len(captured) == 1:
                exposed = [tool for tool in request["tools"] if tool["name"] == "research_inference"]
                assert len(exposed) == 1
                assert exposed[0]["parameters"] == INFERENCE_INPUT_SCHEMA == registered.parameters
                assert exposed[0]["description"] == registered.description
                return Completion(tool_calls=[ToolCall("exposure-call", "research_inference", deepcopy(arguments))],
                                  finish_reason="tool-calls")
            assert len(captured) == 2
            assert any(message.get("role") == "tool" and marker in message.get("content", "")
                       for message in request["messages"])
            return Completion(text="Offline routing check complete.", finish_reason="stop")

        app.provider = SimpleNamespace(
            resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"), complete=complete)
        result = app.prompt(ctx.session_id, "Run only the offline tool exposure and dispatch probe.")

        assert len(captured) == 2
        dispatch.assert_called_once()
        actual_arguments, actual_ctx = dispatch.call_args.args
        assert actual_arguments == arguments
        assert actual_ctx.app is app and actual_ctx.session_id == ctx.session_id
        assert actual_ctx.agent.name == "build" and actual_ctx.call_id == "exposure-call"
        assert result["status"] == "completed" and result["text"] == "Offline routing check complete."
        saved = [message for message in app.store.messages(ctx.session_id) if message["role"] == "tool"]
        assert len(saved) == 1 and saved[0]["content"] == marker
    finally:
        case.doCleanups()
