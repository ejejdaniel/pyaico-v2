"""research_judge: blinded repeats in web-only sub-sessions; mock model, no network."""

import json
import re

import pytest

from opencode import search_switch
from opencode.loop import ToolContext
from opencode.provider import Completion
from researchkit import board, judge, leaderboard, records
from test_delivery_acceptance import case, mock_model  # noqa: F401  (fixture)

SAMPLES = {"h1": "polymer A with ester X", "h2": "polymer A with ester Y", "c1": "polymer A with ester Z"}
TRUE_SCORE = {"ester X": 2, "ester Y": 5, "ester Z": 8}


def save(root, kind, name, content, depends_on=()):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=[name], depends_on=[d["record_path"] for d in depends_on])


@pytest.fixture
def judged(case):
    root, app, session = case
    hypotheses = save(root, "hypothesis", "h/hypotheses.json", {"hypotheses": [
        {"id": "H4", "statement": "a stronger photoacid lowers the dose"}]})
    formula = save(root, "proxy_formula", "f/proxy_formula.json", {
        "formula_id": "J4", "method": "llm_judge", "hypothesis_ids": ["H4"], "direction": "higher",
        "expression": "judged acid strength"}, [hypotheses])
    seen = []

    def answer(n, kw):
        names = [t.get("name") or (t.get("function") or {}).get("name") for t in kw.get("tools") or []]
        prompt = next(m["content"] for m in reversed(kw["messages"]) if m["role"] == "user")
        prompt = prompt if isinstance(prompt, str) else json.dumps(prompt)
        seen.append({"system": kw["system"], "tools": names, "prompt": prompt})
        codes = dict(re.findall(r"(S\d\d): polymer A with (ester \w)", prompt))
        scores = {code: {"score": TRUE_SCORE[ester], "reason": "mechanism", "sources": ["https://example.org/p"]}
                  for code, ester in codes.items()}
        return Completion(text="```json\n" + json.dumps({"scores": scores}) + "\n```", finish_reason="stop")

    mock_model(app, answer)
    ctx = ToolContext(app, session, app.agents["build"], "m", "c", 0, root, root, set(), 1)
    return root, ctx, formula, seen


def test_repeats_are_blinded_recoded_and_web_only(judged):
    root, ctx, formula, seen = judged
    receipt = judge.judge(ctx, {"formula_ref": formula["record_path"], "criterion": "acid strength",
                                "samples": SAMPLES, "repeats": 3})
    assert receipt["values"] == {"h1": 2.0, "h2": 5.0, "c1": 8.0}
    assert receipt["summary"]["agreement_kendall_tau_b"] == pytest.approx(1.0)
    assert len(seen) == 3 and all("independent scientific judge" in s["system"] for s in seen)
    for s in seen:
        assert "webfetch" in s["tools"] and set(s["tools"]) <= {"webfetch", "websearch"}  # nothing else
        # Whole codes only: a random message ID in the prompt may contain "c1" (msg_...00c1a0 did).
        assert not re.search(r"\b(h1|c1)\b", s["prompt"]) and "研究看板" not in s["prompt"]
    assert len({s["prompt"] for s in seen}) > 1  # each repeat reshuffles the codes
    # the cited URL was never fetched in the sub-session, so the host flags it
    assert receipt["summary"]["unfetched_citations"] == ["https://example.org/p"]
    record = records.read_record(root, receipt["record"]["record_path"])
    assert record["kind"] == "judgment" and record["depends_on"] == [formula["record_path"]]
    texts = [i["text"] for i in board.open_actions(board.build(root))]
    assert any("從未讀取的網址" in t for t in texts)


def test_scorers_cannot_search_the_web_while_the_users_switch_is_off(judged):
    root, ctx, formula, seen = judged
    ctx.app.store.update_session(ctx.session_id, permission=search_switch.apply([], {"web": False}))
    judge.judge(ctx, {"formula_ref": formula["record_path"], "criterion": "acid strength",
                      "samples": SAMPLES, "repeats": 2})
    assert seen and all(not s["tools"] for s in seen)


def test_judgment_values_become_an_llm_judge_sheet(judged):
    root, ctx, formula, seen = judged
    receipt = judge.judge(ctx, {"formula_ref": formula["record_path"], "criterion": "acid strength",
                                "samples": SAMPLES})
    lb = leaderboard.run({"baseline_ids": ["h1", "h2"], "candidate_ids": ["c1"],
                          "sheets": [{"formula_ref": formula["record_path"], "values": receipt["values_selection"]}]},
                         root, root / ".research/leaderboards/j")["result"]
    assert lb["sheets"][0]["evidence"] == "llm_judge"
    assert lb["candidates"][0]["verdict"] == "conditional_surpass"


def test_descriptions_that_reveal_history_are_rejected(judged):
    root, ctx, formula, seen = judged
    with pytest.raises(ValueError, match="must not say which samples are historical"):
        judge.judge(ctx, {"formula_ref": formula["record_path"], "criterion": "acid strength",
                          "samples": {**SAMPLES, "h1": "historical sample, measured EOP 47"}})
    assert not seen


def test_a_judge_formula_must_stand_for_one_hypothesis(judged):
    root, ctx, formula, seen = judged
    broad = save(root, "proxy_formula", "g/proxy_formula.json", {
        "formula_id": "J5", "method": "llm_judge", "hypothesis_ids": ["H4", "H5"], "direction": "higher"})
    with pytest.raises(ValueError, match="exactly one hypothesis"):
        judge.judge(ctx, {"formula_ref": broad["record_path"], "criterion": "x", "samples": SAMPLES})


def test_tool_is_registered():
    from researchkit.tools import TOOLS
    assert "research_judge" in {tool.name for tool in TOOLS}
