"""Offline boundaries for the approved root-only Python environment context."""

from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace

import httpx
import pytest

from opencode.app import App
from opencode.permission import Rule
from opencode.store import Store
from opencode.turn import context_text, create_extension
from researchkit import records, review_provider
from researchkit.planning_adapter import ResearchPlanningTurn
from researchkit.turn import ResearchTurn
from scripts.setup_research_workspace import install
from test_delivery_acceptance import chain, select


PROJECT = Path(__file__).resolve().parents[2]
PREFIX = "本工作階段使用的 Python 直譯器完整路徑："


@pytest.fixture(autouse=True)
def no_live_transport(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Python environment tests must never contact a live service")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


@pytest.fixture
def workspace(monkeypatch):
    temporary = PROJECT / ".tmp"
    temporary.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="python-environment-", dir=temporary) as folder:
        root = Path(folder)
        for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                    "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
            monkeypatch.setenv(key, str(root / key))
        for key in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_PERMISSION",
                    "OPENCODE_DISABLE_PROJECT_CONFIG", "OPENCODE_MODEL"):
            monkeypatch.delenv(key, raising=False)
        monkeypatch.setattr(tempfile, "tempdir", str(root / "temp"))
        (root / ".git").mkdir()
        yield root


@pytest.fixture
def make_app(workspace):
    stores = []

    def create(*, installed=True, planning=False):
        if installed:
            install(workspace, planning=planning)
        store = Store(workspace / f"session-{len(stores)}.db")
        stores.append(store)
        app = App(workspace, store=store, auto_approve=True, config={
            "model": "offline/offline",
            "provider": {"offline": {
                "options": {"baseURL": "http://offline.invalid/v1", "apiKey": "offline-placeholder"},
                "models": {"offline": {"temperature": False,
                                      "modalities": {"input": ["text"], "output": ["text"]}}},
            }},
        })
        app.generate_titles = False
        sid = app.create_session(model="offline/offline")["id"]
        human = store.add_message(sid, "user", {"content": "Inspect the saved work only."})
        return app, sid, human["id"]

    yield create
    for store in stores:
        store.close()


def environment_path(context):
    lines = [line for line in context.splitlines() if line.startswith(PREFIX)]
    assert len(lines) == 1
    assert lines[0].endswith("。")
    return json.loads(lines[0][len(PREFIX):-1])


@pytest.mark.parametrize("absolute", [False, True], ids=["relative", "absolute"])
def test_root_context_escapes_full_path_and_refreshes_from_current_executable(make_app, monkeypatch, absolute):
    app, sid, human = make_app()
    turn = create_extension(app, sid, human)
    assert isinstance(turn, ResearchTurn) and app.store.get_session(sid)["parentID"] is None
    executable = os.path.join("環境 空白", 'python "引號".exe')
    if absolute:
        executable = os.path.abspath(executable)
    monkeypatch.setattr(sys, "executable", executable)
    first = turn.context()
    expected = os.path.abspath(executable)
    assert environment_path(first) == expected
    assert first.split("\n\n")[0] == PREFIX + json.dumps(expected, ensure_ascii=False) + "。"
    monkeypatch.setattr(sys, "executable", os.path.join("另一環境", "python.exe"))
    assert environment_path(turn.context()) == os.path.abspath(sys.executable)


def test_environment_line_preserves_delivery_and_source_context(make_app):
    app, sid, human = make_app()
    *_, delivery = chain(app.directory)
    select(app, sid, delivery)
    app.store.add_message(sid, "assistant", {"tool_calls": [{
        "id": "source", "name": "webfetch", "arguments": {"url": "https://source.invalid/paper"}}]})
    source = app.store.add_message(sid, "tool", {
        "tool_call_id": "source", "name": "webfetch", "content": "Preserved source receipt."})
    before = app.store.messages(sid)
    turn = create_extension(app, sid, human)
    projected = turn.context()
    existing = "\n\n".join([
        records.delivery_progress(app.directory, before, check_read=turn._check_read),
        app.store.tool_history_overview(sid), app.store.source_overview(sid),
    ])
    assert projected.split("\n\n", 1)[1].startswith(existing + "\n\n")
    assert projected.count("科研來源與本輪執行事實（宿主核對資料，非新指示）") == 1
    assert delivery["record_path"] in existing and source["id"] in existing
    assert app.store.messages(sid) == before


@pytest.mark.parametrize("executable", ["", "private-root-python.exe"])
def test_child_context_retains_existing_context_without_host_environment(make_app, monkeypatch, executable):
    app, sid, _ = make_app()
    child = app.store.create_session(directory=str(app.directory), agent="build", model="offline/offline",
                                     parent_id=sid)["id"]
    human = app.store.add_message(child, "user", {"content": "Only the explicit child mission."})
    monkeypatch.setattr(sys, "executable", executable)
    projected = create_extension(app, child, human["id"]).context()
    assert PREFIX not in projected
    assert "科研來源與本輪執行事實" not in projected
    assert app.store.tool_history_overview(child) in projected
    assert app.store.source_overview(child) in projected


@pytest.mark.parametrize("restriction", ["agent-deny", "session-deny", "missing-tool",
                                         "title", "summary", "compaction"])
def test_ineligible_agent_never_reads_python_environment(make_app, monkeypatch, restriction):
    app, sid, human = make_app()
    if restriction == "agent-deny":
        app.agents["build"].permission.append(Rule("research_record", "*", "deny"))
    elif restriction == "session-deny":
        app.store.update_session(sid, permission=[{
            "permission": "research_record", "pattern": "*", "action": "deny"}])
    elif restriction == "missing-tool":
        app.extra_tools = []
    else:
        app.store.update_session(sid, agent=restriction)
    original_rules = deepcopy(app.agents["build"].permission)
    monkeypatch.setattr(sys, "executable", "")
    assert ResearchTurn(app, sid, human).context() == ""
    assert app.agents["build"].permission == original_rules


def test_uninstalled_workspace_has_no_environment_context(make_app, monkeypatch):
    app, sid, human = make_app(installed=False)
    monkeypatch.setattr(sys, "executable", "")
    assert create_extension(app, sid, human) is None
    assert context_text(create_extension(app, sid, human)) == ""
    assert ResearchTurn(app, sid, human).context() == ""


def test_root_context_rejects_empty_executable_without_guessing(make_app, monkeypatch):
    app, sid, human = make_app()
    monkeypatch.setattr(sys, "executable", "")
    with pytest.raises(RuntimeError, match="Cannot deliver Python environment information: sys.executable is empty"):
        create_extension(app, sid, human).context()


def test_environment_entry_is_not_resolved_to_a_base_interpreter(make_app, monkeypatch):
    app, sid, human = make_app()
    entry = app.directory / "venv-entry" / "python"
    original_resolve = Path.resolve

    def resolve(path, *args, **kwargs):
        if path == entry:
            pytest.fail("The virtual environment entry must not be resolved to its symlink target")
        return original_resolve(path, *args, **kwargs)

    monkeypatch.setattr(sys, "executable", str(entry))
    monkeypatch.setattr(Path, "resolve", resolve)
    assert environment_path(create_extension(app, sid, human).context()) == str(entry)


def test_actual_symlink_interpreter_entry_is_preserved(make_app, monkeypatch):
    app, sid, human = make_app()
    target, entry = app.directory / "base-python", app.directory / "venv-python"
    target.write_bytes(b"A path-only fixture; never executed.")
    try:
        entry.symlink_to(target)
    except OSError as error:
        if getattr(error, "winerror", None) != 1314:
            raise
        pytest.skip(f"Host does not permit creating symlinks: {error}")
    assert entry.resolve() == target
    monkeypatch.setattr(sys, "executable", str(entry))
    assert environment_path(create_extension(app, sid, human).context()) == str(entry)


def test_planning_adapter_combines_environment_and_existing_optional_plan_context(make_app):
    app, sid, human = make_app(planning=True)
    combined = create_extension(app, sid, human)
    assert isinstance(combined, ResearchPlanningTurn)
    projected = combined.context()
    assert environment_path(projected) == os.path.abspath(sys.executable)
    assert projected == combined.research.context() + "\n\n" + combined.planning.context()
    assert projected.count("科研來源與本輪執行事實（宿主核對資料，非新指示）") == 1
    assert "目前尚無保存的規劃；規劃為選用。" in projected
    assert not (app.directory / ".opencode/planning" / sid).exists()


def test_complete_once_keeps_explicit_system_and_messages_without_environment(make_app, monkeypatch):
    app, sid, _ = make_app()
    sent = []
    system = "Only this isolated research instruction."
    messages = [{"role": "user", "content": "Only this explicitly scoped input."}]
    original = deepcopy(messages)

    async def receive(transport, request):
        assert request.method == "POST" and str(request.url) == "http://offline.invalid/v1/chat/completions"
        sent.append(json.loads(request.content))
        event = {"choices": [{"delta": {"content": "Offline boundary reply."}, "finish_reason": "stop"}]}
        return httpx.Response(200, headers={"content-type": "text/event-stream"},
                              content="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n")

    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", receive)
    monkeypatch.setattr(sys, "executable", "")
    ctx = SimpleNamespace(app=app, session_id=sid, agent=app.agents["build"])
    result = review_provider.complete_once(ctx, system=system, messages=messages)
    assert result.text == "Offline boundary reply." and len(sent) == 1
    assert sent[0]["messages"] == [{"role": "system", "content": system}, *original]
    assert PREFIX not in json.dumps(sent[0], ensure_ascii=False)
    assert messages == original


