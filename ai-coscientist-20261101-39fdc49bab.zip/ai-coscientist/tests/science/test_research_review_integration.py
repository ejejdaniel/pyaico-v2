"""Native tool dispatch into the real review transport, with offline HTTP only."""

import json
from contextlib import closing
from pathlib import Path
from unittest.mock import Mock

import httpx
import pytest

from opencode.app import App
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from researchkit import records, review, reviewer
from scripts.setup_research_workspace import install
from tests.prompt_view import plain_messages


@pytest.mark.parametrize("mode", [
    "valid", "unsupported", "empty", "truncated_presentation", "anthropic_pause", "anthropic_valid",
    "nonstream_json", "unknown_finish", "length_finish", "missing_finish",
    "tool_calls", "malformed_stream", "read_timeout",
    "recovered_length", "recovery_failed_length",
])
def test_native_review_is_one_stage_and_saved_as_a_review_record(tmp_path, monkeypatch, mode):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))

    def no_network(*args, **kwargs):
        pytest.fail("No real network in review integration tests")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", no_network)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", no_network)
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()
    install(root)
    (root / "report.md").write_text("A claim requiring additional evidence.", encoding="utf-8")
    saved = records.publish(root, kind="report", title="Claim", files=["report.md"], depends_on=[])
    ref = saved["record_path"]
    value = {"reviewed_refs": [ref], "checks": [{
        "subject": {"record_ref": ref, "source_path": "report.md", "quote": "A claim requiring additional evidence."},
        "evidence": [], "decision": "unassessed", "reason": "No observation was supplied.",
    }]}
    if mode == "truncated_presentation":
        value["checks"][0]["reason"] += " The claim remains unassessed." * 100
    if mode == "unsupported":
        value["checks"][0].update(decision="unsupported", evidence=[dict(value["checks"][0]["subject"])],
                                  reason="The selected assertion alone does not establish the claim.")
    model_value = {"checks": [{**value["checks"][0],
        "subject": {"file_id": "F1", "start_line": 1, "end_line": 1,
                    "quote": value["checks"][0]["subject"]["quote"]}}]}
    if mode == "unsupported":
        model_value["checks"][0]["evidence"] = [{"file_id": "F1", "start_line": 1, "end_line": 1}]
    text = "" if mode == "empty" else json.dumps(model_value)
    assembled_text = json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n"
    if mode == "anthropic_pause":
        # Establish that only the raw finish reason makes this response invalid.
        review.validate(root, assembled_text.encode(), [ref], {ref: saved})
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        if mode in {"anthropic_pause", "anthropic_valid"}:
            return httpx.Response(200, json={"content": [{"type": "text", "text": text}],
                                            "stop_reason": "pause_turn" if mode == "anthropic_pause" else "end_turn"})
        if mode == "nonstream_json":
            # A service ignoring stream=true must not be made valid by our fixture.
            return httpx.Response(200, json={"choices": [{"message": {
                "content": text, "reasoning_content": "Unpublished model reasoning."}, "finish_reason": "stop"}]})
        recovering = mode in {"recovered_length", "recovery_failed_length"}
        empty_length = recovering and (len(sent) == 1 or mode == "recovery_failed_length")
        delta = {"content": "" if empty_length else text,
                 "reasoning_content": "Unpublished model reasoning."}
        if mode == "tool_calls":
            delta["tool_calls"] = [{
                "index": 0, "id": "unexpected", "function": {"name": "read", "arguments": "{}"},
            }]
        event = {"choices": [{"delta": delta}]}
        content = ("data: " + json.dumps(event) + "\n\n").encode()
        if mode == "read_timeout":
            class Body(httpx.AsyncByteStream):
                async def __aiter__(self):
                    yield content
                    raise httpx.ReadTimeout("idle read timed out", request=request)

            return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=Body())
        if mode == "malformed_stream":
            content += b"data: {invalid}\n\n"
        elif mode != "missing_finish":
            reason = {"unknown_finish": "unexpected", "length_finish": "length"}.get(mode, "stop")
            if empty_length:
                reason = "length"
            content += ("data: " + json.dumps({"choices": [{"delta": {}, "finish_reason": reason}]})
                        + "\n\ndata: [DONE]\n\n").encode()
        return httpx.Response(200, headers={"content-type": "text/event-stream"}, content=content)

    original = httpx.AsyncClient
    monkeypatch.setattr(httpx, "AsyncClient",
                        lambda **kwargs: original(transport=httpx.MockTransport(receive), **kwargs))
    config = {"model": "review/review-model", "provider": {"review": {
        "api": "openai", "options": {"baseURL": "https://review.invalid/v1", "apiKey": "test-key"},
        "models": {"review-model": {"temperature": False, "limit": {"output": 12000}}},
    }}}
    if mode == "truncated_presentation":
        config["tool_output"] = {"max_lines": 2000, "max_bytes": 256}
    if mode in {"anthropic_pause", "anthropic_valid"}:
        config["provider"]["review"]["api"] = "anthropic"
    if mode in {"recovered_length", "recovery_failed_length"}:
        config["provider"]["review"]["models"]["review-model"]["temperature"] = True
        config["agent"] = {"build": {"temperature": 0}}
    with closing(Store(tmp_path / "session.db")) as store:
        app = App(root, store=store, auto_approve=True, config=config)
        app.generate_titles = False
        session = app.create_session()["id"]
        args = {"scope": "Assess this selected claim without writing or running anything.",
                "reviewed_refs": [ref], "files": [{"record_ref": ref, "source_path": "report.md"}]}
        outer_requests = []

        def outer(**kwargs):
            outer_requests.append(kwargs)
            if len(outer_requests) == 1:
                assert any(tool["name"] == "research_review" for tool in kwargs["tools"])
                return Completion(tool_calls=[ToolCall("review-call", "research_review", args)],
                                  finish_reason="tool-calls")
            assert len(outer_requests) == 2
            # Check the actual next model request, not merely the stored receipt.
            delivered = [message for message in plain_messages(kwargs["messages"])
                         if message.get("role") == "tool" and message.get("tool_call_id") == "review-call"]
            stored = [message for message in store.messages(session)
                      if message.get("name") == "research_review"]
            assert len(delivered) == len(stored) == 1
            assert delivered[0]["content"] == stored[0]["content"]
            assert "Unpublished model reasoning" not in json.dumps(kwargs["messages"])
            if mode in {"valid", "unsupported", "recovered_length", "anthropic_valid"}:
                # The agent gets a short summary; the full review is the saved record's review.json (v25's
                # 35 KB reviews were cut by the output limit together with the delivery note).
                content = delivered[0]["content"]
                assert content.startswith("Review saved as review record .research/records/")
                assert "/final/review.json" in content and "1 checks: " in content
                decision = "unsupported" if mode == "unsupported" else "unassessed"
                assert f"- check 1 ({decision}) on report.md" in content and "research_deliver" in content
            elif mode == "truncated_presentation":
                assert delivered[0]["content"] != assembled_text
                assert stored[0]["metadata"]["truncated"] is True
            else:
                assert stored[0]["metadata"]["error"] is True
            return Completion(text="The bounded review call has returned; no publication requested.",
                              finish_reason="stop")

        app.provider.complete = Mock(side_effect=outer)
        app.prompt(session, "PARENT_PRIVATE_COMMISSION: inspect selected sources, without publication.")
        receipts = [message for message in store.messages(session) if message.get("name") == "research_review"]
        assert len(receipts) == 1
        if mode in {"recovered_length", "recovery_failed_length"}:
            # One stage: the empty first answer and its recovery, and no second stage.
            assert len(sent) == 2
            assert sent[0]["temperature"] == 0
            assert sent[1] == {**sent[0], "temperature": 0.6}
        else:
            assert len(sent) == 1
        receipt = receipts[0]
        if mode == "empty":
            assert receipt["metadata"]["error"] is True
            assert "does not support the requested recovery temperature" in receipt["content"]
            assert "Unpublished model reasoning" not in receipt["content"]
        elif mode == "anthropic_pause":
            assert receipt["metadata"]["error"] is True
            assert "pause_turn" in receipt["content"]
        elif mode == "truncated_presentation":
            assert receipt["metadata"]["truncated"] is True
            assert Path(receipt["metadata"]["outputPath"]).read_text(encoding="utf-8").startswith(
                "Review saved as review record")
            assert "truncated" in receipt["content"]
        elif mode in {"nonstream_json", "unknown_finish", "length_finish", "missing_finish", "tool_calls",
                      "malformed_stream", "read_timeout", "recovery_failed_length"}:
            assert receipt["metadata"]["error"] is True
            expected_error = {"malformed_stream": "Invalid JSON in model stream",
                              "read_timeout": "idle read timed out"}.get(mode, "nonempty final answer")
            assert expected_error in receipt["content"]
            assert "Unpublished model reasoning" not in receipt["content"]
        else:
            assert not receipt["metadata"].get("error")
            assert json.loads((root / receipt["metadata"]["review_file"]).read_text(encoding="utf-8")) == value
        assert "PARENT_PRIVATE_COMMISSION" not in json.dumps(sent)
        if mode in {"anthropic_pause", "anthropic_valid"}:
            system = sent[0]["system"]
            assert len(sent[0]["messages"]) == 1 and sent[0]["messages"][0]["role"] == "user"
        else:
            assert len(sent[0]["messages"]) == 2
            assert sent[0]["messages"][0]["role"] == "system"
            assert sent[0]["messages"][1]["role"] == "user"
            system = sent[0]["messages"][0]["content"]
        # Inspect the actual HTTP system, not a skill link or a mocked _input.
        assert system == "\n\n".join(path.read_text(encoding="utf-8") for path in (
            reviewer.SYSTEM_PATH, reviewer.FORMAT_PATH, reviewer.VERIFICATION_PATH))
        assert args["scope"] not in system
        user, = [message for message in sent[0]["messages"] if message["role"] == "user"]
        assert json.dumps(args["scope"], ensure_ascii=False) in user["content"]
        assert "tools" not in sent[0]
        if mode in {"anthropic_pause", "anthropic_valid"}:
            assert "stream" not in sent[0]
        else:
            assert sent[0]["stream"] is True
            assert sent[0]["stream_options"] == {"include_usage": True}
        saved = records.inventory(root)
        if mode in {"valid", "unsupported", "truncated_presentation", "anthropic_valid", "recovered_length"}:
            # The tool saves the finished review as a kind=review record that depends on the reviewed report.
            review_record, = [item for item in saved if item["kind"] == "review"]
            assert review_record["depends_on"] == [ref]
            assert len(saved) == 2
        else:
            assert len(saved) == 1
        assert not (root / "review.json").exists()
