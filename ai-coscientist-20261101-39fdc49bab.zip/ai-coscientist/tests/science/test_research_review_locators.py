"""Mechanical selector assembly only; all model replies are scripted test data."""

from copy import deepcopy
import json
from unittest.mock import Mock

import httpx
import pytest

from opencode.provider import Completion
from researchkit import records, reviewer
import test_research_review as review_cases


@pytest.fixture
def packet(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Locator boundary tests must never use a real model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def selected(packet, content):
    record = packet.save({"units.txt": content})
    args = {"scope": "Check only the explicitly selected test lines.",
            "reviewed_refs": [record["record_path"]],
            "files": [packet.locator(record, "units.txt")]}
    return record, args


def answer(quote, start=1, end=1):
    return {"checks": [{"subject": {"file_id": "F1", "start_line": start, "end_line": end, "quote": quote},
                        "evidence": [], "decision": "unassessed", "reason": "Test boundary only."}]}


@pytest.mark.parametrize(("raw", "expected"), [
    (b"", ()), (b"\n", ("",)), (b"\n\n", ("", "")),
    (b"a", ("a",)), (b"a\n", ("a",)), (b"a\n\n", ("a", "")),
    (b"a\r\nb\rc\n", ("a", "b", "c")),
    ("\ufeff  1.0 µm\t\r\n\r  2 kg mol⁻¹  \ninside\ufeffmark\u2028same\u2029line\x85x\v\f\n".encode(),
     ("  1.0 µm\t", "", "  2 kg mol⁻¹  ", "inside\ufeffmark\u2028same\u2029line\x85x\v\f")),
])
def test_numbered_source_is_the_exact_single_normalized_copy(packet, raw, expected):
    record, args = selected(packet, raw)
    before = packet.snapshot(record, "units.txt").read_bytes()
    _, message, _, _, mapping = reviewer._input(args, packet.ctx)
    assert mapping == {"F1": {**packet.locator(record, "units.txt"), "lines": expected}}
    sections = message.split("\n")
    assert len(sections) == 10
    assert json.loads(sections[9]) == {record["record_path"]: ["F1"]}
    metadata = json.loads(sections[5])
    assert {key: metadata[key] for key in ("file_id", "record_ref", "source_path")} == {
        "file_id": "F1", **args["files"][0]}
    assert metadata["origin"]["status"] == "snapshot_only"
    assert sections[6].startswith("Numbered UTF-8 lines (JSON array; numbers are not source content). ")
    assert json.loads(sections[7]) == [[i, line] for i, line in enumerate(expected, 1)]
    assert packet.snapshot(record, "units.txt").read_bytes() == before == raw


def test_range_copy_keeps_units_whitespace_unicode_and_real_blank_line(packet):
    record, args = selected(packet, "\ufeffunused\r\n  3.0 µm\t\r\n\r  2 kg mol⁻¹  \ninside\ufeffmark\u2028same\u2029line\n")
    supplied = "  3.0 µm\t\r\n\r  2 kg mol⁻¹  \ninside\ufeffmark\u2028same\u2029line"
    result, _ = packet.execute(args, packet.completion(answer(supplied, 2, 5)))
    quote = json.loads(result.output)["checks"][0]["subject"]["quote"]
    assert quote == "  3.0 µm\t\n\n  2 kg mol⁻¹  \ninside\ufeffmark\u2028same\u2029line"
    assert json.loads(result.output)["checks"][0]["subject"] == {
        **packet.locator(record, "units.txt"), "quote": quote}


@pytest.mark.parametrize("content,start,end", [
    ("", 1, 1), ("\n", 1, 1), (" \t\n\n", 1, 2),
    ("a\n", 2, 2), ("a\n\n", 1, 3),
])
def test_empty_whitespace_or_phantom_lines_cannot_be_quoted(packet, content, start, end):
    _, args = selected(packet, content)
    with pytest.raises(ValueError):
        packet.execute(args, packet.completion(answer("a", start, end)))


@pytest.mark.parametrize("content,quote,start,end,expected", [
    ("Prefix. Actual claim. Suffix.\n", "Actual claim.", 1, 1, "Actual claim."),
    ("Prefix. Actual claim. Suffix.\n", "claim", 1, 1, "claim"),
    ("first\nsecond\nthird\n", "rst\nsec", 1, 2, "rst\nsec"),
    ("first\r\nsecond\rthird\n", "first\r\nsecond\rthird", 1, 3, "first\nsecond\nthird"),
    ("  units: µm\t\n", "  units: µm\t", 1, 1, "  units: µm\t"),
    ("A\u2028B\u2029C\x85D\vE\fF\ufeffG\n", "A\u2028B\u2029C\x85D\vE\fF\ufeffG", 1, 1,
     "A\u2028B\u2029C\x85D\vE\fF\ufeffG"),
    ("cafe\u0301; café; Ａ; A\n", "cafe\u0301; café; Ａ; A", 1, 1, "cafe\u0301; café; Ａ; A"),
])
def test_subject_quote_is_exact_contiguous_substring_with_only_newline_normalization(
        packet, content, quote, start, end, expected):
    record, args = selected(packet, content)
    original = packet.snapshot(record, "units.txt").read_bytes()
    value = answer(quote, start, end)
    result, _ = packet.execute(args, packet.completion(value))
    check, = json.loads(result.output)["checks"]
    assert check["subject"] == {**packet.locator(record, "units.txt"), "quote": expected}
    assert check["decision"] == "unassessed" and check["reason"] == value["checks"][0]["reason"]
    assert value["checks"][0]["subject"]["quote"] == quote
    assert packet.snapshot(record, "units.txt").read_bytes() == original


@pytest.mark.parametrize("content,quote,start,end,lines", [
    ("first\nsecond\n", "second", 1, 1, (2, 2)),
    ("first\nsecond\n", "first\nsecond", 2, 2, (1, 2)),
    ("a\nclaim\nb\nclaim\nc\n", "claim", 5, 5, (4, 4)),
])
def test_literal_subject_quote_with_wrong_line_numbers_is_moved_to_where_it_occurs(
        packet, monkeypatch, content, quote, start, end, lines):
    record, args = selected(packet, content)
    handoffs, original = [], reviewer._candidate_handoff
    monkeypatch.setattr(reviewer, "_candidate_handoff", lambda *a, **k: handoffs.append(original(*a, **k)) or handoffs[-1])
    result, _ = packet.execute(args, packet.completion(answer(quote, start, end)))
    assert json.loads(result.output)["checks"][0]["subject"] == {**packet.locator(record, "units.txt"), "quote": quote}
    subject = json.loads(handoffs[0])["checks"][0]["subject"]
    assert (subject["start_line"], subject["end_line"]) == lines


@pytest.mark.parametrize("content,quote,start,end,expected", [
    ("first  second\n", "first second", 1, 1, "first  second"),
    ("claim.\n", " claim. ", 1, 1, "claim."),
    ("claim.\n", "claim.\n", 1, 1, "claim."),
    ("first second\n", "first\nsecond", 1, 1, "first second"),
    ("first second\n", "first second", 1, 1, "first second"),
    ('{\n  "rounds": 3,\n  "stop": false\n}\n', '    "rounds": 3,\n    "stop": false', 2, 3,
     '"rounds": 3,\n  "stop": false'),
    ("x\nsheets are\nmechanism-only\n", "sheets are\n  mechanism-only", 1, 1, "sheets are\nmechanism-only"),
])
def test_quote_differing_only_in_whitespace_is_published_as_the_file_text(
        packet, content, quote, start, end, expected):
    record, args = selected(packet, content)
    result, _ = packet.execute(args, packet.completion(answer(quote, start, end)))
    assert json.loads(result.output)["checks"][0]["subject"] == {**packet.locator(record, "units.txt"),
                                                                  "quote": expected}


def test_oversize_selection_names_the_largest_files(packet):
    record = packet.save({"big.txt": "x" * (reviewer.MAX_BYTES + 10) + "\n", "small.txt": "y\n"})
    args = {"scope": "Check the selected lines.", "reviewed_refs": [record["record_path"]],
            "files": [packet.locator(record, "small.txt"), packet.locator(record, "big.txt")]}
    with pytest.raises(ValueError, match=r"Largest: big.txt 262155 bytes; small.txt 2 bytes"):
        reviewer._input(args, packet.ctx)


def test_quote_found_nowhere_names_the_check_and_where_it_stops_matching(packet):
    _, args = selected(packet, "strong claim on line one.\n")
    with pytest.raises(ValueError, match=r"check 1: .*first 1 of 3 words occur, then the quote has \"weak claim\""):
        packet.execute(args, packet.completion(answer("strong weak claim", 1, 1)))


@pytest.mark.parametrize("content,quote,start,end", [
    ("first\nsecond\nthird\n", "first\nthird", 1, 3),
    ("first second third\n", "first third", 1, 1),
    ("first second third\n", "first...third", 1, 1),
    ("strong claim.\n", "weak claim.", 1, 1),
    ("firstsecond\n", "first second", 1, 1),
    ("first second\n", "firstsecond", 1, 1),
    ("claim.\n", "claim!", 1, 1),
    ("café\n", "cafe\u0301", 1, 1),
    ("Ａ\n", "A", 1, 1),
    ("claim\n", "1: claim", 1, 1),
])
def test_subject_quote_cannot_use_another_range_or_fuzzy_text(packet, content, quote, start, end):
    _, args = selected(packet, content)
    with pytest.raises(ValueError, match="quote"):
        packet.execute(args, packet.completion(answer(quote, start, end)))


@pytest.mark.parametrize("quote", [None, 0, True, False, 1.5, [], {}, "", " \t\r\n"])
def test_subject_quote_requires_nonblank_string_without_retry(packet, quote):
    value = deepcopy(packet.model_value)
    value["checks"][0]["subject"]["quote"] = quote
    with pytest.raises(ValueError, match="quote"):
        packet.execute(completion=packet.completion(value))


def test_duplicate_subject_quote_key_is_rejected_without_retry(packet):
    text = packet.completion().text.replace('"quote":', '"quote": "first", "quote":', 1)
    with pytest.raises(ValueError, match="duplicate JSON key"):
        packet.execute(completion=Completion(text=text, finish_reason="stop"))


@pytest.mark.parametrize("field,bad", [
    ("file_id", "F0"), ("file_id", "F01"), ("file_id", "f1"), ("file_id", " F1"),
    ("file_id", ""), ("file_id", 1), ("file_id", None), ("file_id", True),
    ("file_id", ["F1"]), ("file_id", {"id": "F1"}),
    *[(field, value) for field in ("start_line", "end_line")
      for value in (True, False, 1.0, "1", None, 0, -1, 2)],
])
def test_locator_ids_and_integer_ranges_are_exact_and_never_retried(packet, field, bad):
    value = deepcopy(packet.model_value)
    value["checks"][0]["subject"][field] = bad
    with pytest.raises(ValueError):
        packet.execute(completion=packet.completion(value))


def test_reversed_range_is_invalid(packet):
    _, args = selected(packet, "first\nsecond\n")
    with pytest.raises(ValueError):
        packet.execute(args, packet.completion(answer("second", 2, 1)))


def test_one_manifest_multiple_files_uses_ordered_independent_ids(packet):
    record = packet.save({"first.txt": "First file.\n", "second.txt": "Second file.\n"})
    args = {"scope": "Check selected files.", "reviewed_refs": [record["record_path"]],
            "files": [packet.locator(record, "second.txt"), packet.locator(record, "first.txt")]}
    _, _, _, _, mapping = reviewer._input(args, packet.ctx)
    assert list(mapping) == ["F1", "F2"]
    assert mapping["F1"]["source_path"] == "second.txt"
    assert mapping["F2"]["source_path"] == "first.txt"
    value = deepcopy(packet.model_value)
    value["checks"][0]["subject"]["quote"] = "Second file."
    result, _ = packet.execute(args, packet.completion(value))
    check = json.loads(result.output)["checks"][0]
    assert check["subject"] == {**args["files"][0], "quote": "Second file."}
    assert check["evidence"] == [{**args["files"][1], "quote": "First file."}]


@pytest.mark.parametrize("mutate", [
    lambda value: value.update(reviewed_refs=[]),
    lambda value: value.update(extra=True),
    lambda value: value.update(checks=[]),
    lambda value: value.update(checks={}),
    lambda value: value["checks"][0].update(extra=True),
    lambda value: value["checks"][0]["subject"].pop("quote"),
    lambda value: value["checks"][0]["subject"].update(extra=True),
    lambda value: value["checks"][0]["evidence"][0].update(quote="Frozen observation under condition A."),
    lambda value: value["checks"][0]["subject"].pop("end_line"),
    lambda value: value["checks"][0].update(evidence={}),
    lambda value: value["checks"][0].update(reason=" \t"),
    lambda value: value["checks"][0].update(decision="accepted"),
    lambda value: value["checks"][0].update(evidence=[]),
])
def test_model_schema_has_no_legacy_or_extra_field_fallback(packet, mutate):
    value = deepcopy(packet.model_value)
    mutate(value)
    with pytest.raises(ValueError):
        packet.execute(completion=packet.completion(value))


def test_duplicate_evidence_is_rejected_by_existing_public_validator(packet):
    value = deepcopy(packet.model_value)
    value["checks"][0]["evidence"] *= 2
    with pytest.raises(ValueError, match="duplicate evidence locator"):
        packet.execute(completion=packet.completion(value))


def test_all_decisions_reasons_and_check_order_pass_through_unchanged(packet):
    value = {"checks": []}
    decisions = ["contradicted", "unassessed", "supported", "conditional", "unsupported"]
    for index, decision in enumerate(decisions):
        check = deepcopy(packet.model_value["checks"][0])
        check.update(decision=decision, reason=f"  原主張 {index}；理由原文\t\n不可摘要。  ")
        if decision == "unassessed":
            check["evidence"] = []
        value["checks"].append(check)
    result, _ = packet.execute(completion=packet.completion(value))
    assert [(item["decision"], item["reason"]) for item in json.loads(result.output)["checks"]] == [
        (item["decision"], item["reason"]) for item in value["checks"]]


@pytest.mark.parametrize("decision", ["supported", "conditional", "contradicted", "unsupported"])
def test_private_empty_evidence_remains_forbidden_except_unassessed(packet, decision):
    value = deepcopy(packet.model_value)
    value["checks"][0].update(evidence=[], decision=decision)
    with pytest.raises(ValueError, match="empty evidence requires"):
        packet.execute(completion=packet.completion(value))


def test_compact_utf8_plus_one_lf_output_limit_is_inclusive(packet):
    value = deepcopy(packet.model_value)
    value["checks"][0]["reason"] = "界\n\"\\"
    _, _, verified, snapshots, selection = reviewer._input(packet.args, packet.ctx)
    def assemble():
        return reviewer._validate_completion(packet.completion(value), packet.args, packet.ctx,
                                             verified, snapshots, selection)
    output = assemble()
    value["checks"][0]["reason"] += "x" * (262144 - len(output.encode("utf-8")))
    output = assemble()
    assert len(output.encode("utf-8")) == 262144
    assert output == json.dumps(json.loads(output), ensure_ascii=False, separators=(",", ":")) + "\n"
    value["checks"][0]["reason"] += "x"
    with pytest.raises(ValueError, match="262144"):
        assemble()


def test_short_selectors_cannot_expand_past_output_limit_or_trigger_retry(packet, monkeypatch):
    _, args = selected(packet, "界" * 9000 + "\n")
    value = answer("界")
    value["checks"][0]["evidence"] = [{"file_id": "F1", "start_line": 1, "end_line": 1}]
    value["checks"] *= 10
    completion = packet.completion(value)
    assert len(completion.text.encode("utf-8")) < 3000
    model = Mock(return_value=completion)
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(ValueError, match="262144"):
        reviewer.execute(args, packet.ctx)
    model.assert_called_once()


def test_hash_is_rechecked_even_for_same_size_source_mutation(packet, monkeypatch):
    target = packet.snapshot(packet.source, "source.txt")
    original = target.read_bytes()

    def mutate(*args, **kwargs):
        target.write_bytes(b"X" * len(original))
        return packet.completion()

    model = Mock(side_effect=mutate)
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(ValueError, match="snapshot changed"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


def test_assembled_public_review_uses_unchanged_publication_and_readback_contract(packet):
    result, _ = packet.execute()
    packet.file("review.json", result.output)
    published = records.publish(packet.workspace, kind="review", title="Scripted assembly boundary",
                                files=["review.json"], depends_on=[packet.report["record_path"],
                                                                  packet.source["record_path"]])
    readback = packet.snapshot(published, "review.json").read_bytes().decode("utf-8")
    assert readback == result.output
    assert json.loads(readback) == packet.value
    assert published["kind"] == "review"
