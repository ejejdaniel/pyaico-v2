"""Exact required-subject boundaries; scripted replies, no scientific-model claim."""

from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.provider import Completion
from researchkit import review, reviewer
import test_research_review as review_cases
from test_research_review_two_stage import initial_files, run_directory


@pytest.fixture
def packet(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Required-subject tests must not use a real model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def require_report(packet):
    packet.args["required_subjects"] = [deepcopy(packet.value["checks"][0]["subject"])]
    return packet.args["required_subjects"]


def selector_answer(packet, number=1):
    value = deepcopy(packet.model_value)
    value["checks"][0]["subject"] = {"required_subject": number}
    return value


def model_replies(monkeypatch, packet, *values):
    model = Mock(side_effect=[packet.completion(value) for value in values])
    monkeypatch.setattr(reviewer, "complete_once", model)
    return model


@pytest.mark.parametrize("present", [False, True])
def test_absent_and_empty_lists_preserve_existing_messages_and_public_result(packet, monkeypatch, present):
    original = reviewer._input(packet.args, packet.ctx)
    if present:
        packet.args["required_subjects"] = []
    assert reviewer._input(packet.args, packet.ctx) == original
    model = model_replies(monkeypatch, packet, packet.model_value, packet.model_value)
    assert json.loads(reviewer.execute(packet.args, packet.ctx).output) == packet.value
    assert model.call_count == 2


@pytest.mark.parametrize("bad", [None, {}, "subject", 1, True])
def test_required_list_type_fails_before_dispatch(packet, monkeypatch, bad):
    packet.args["required_subjects"] = bad
    model = model_replies(monkeypatch, packet)
    with pytest.raises(ValueError, match="required_subjects"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("mutation", [
    lambda subjects, packet: subjects.__setitem__(0, None),
    lambda subjects, packet: subjects[0].update(extra=True),
    lambda subjects, packet: subjects[0].pop("quote"),
    *[lambda subjects, packet, field=field, bad=bad: subjects[0].update({field: bad})
      for field in ("record_ref", "source_path", "quote")
      for bad in (None, True, 1, "", " \t\r\n")],
    lambda subjects, packet: subjects[0].update(record_ref=packet.source["record_path"]),
    lambda subjects, packet: subjects[0].update(source_path="unselected-report.txt"),
    lambda subjects, packet: subjects[0].update(quote="Altered interpretation for condition A."),
    lambda subjects, packet: subjects.append(deepcopy(subjects[0])),
])
def test_invalid_required_entry_never_reaches_model(packet, monkeypatch, mutation):
    mutation(require_report(packet), packet)
    model = model_replies(monkeypatch, packet)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_required_duplicate_normalizes_only_newlines(packet):
    subjects = require_report(packet)
    subjects[0]["quote"] = "First\r\nSecond\rThird"
    subjects.append({**subjects[0], "quote": "First\nSecond\nThird"})
    with pytest.raises(ValueError, match="Duplicate required_subjects"):
        reviewer._selection(packet.args)
    for quote in ("First\nSecond\nThird ", "first\nSecond\nThird", "Ｆirst\nSecond\nThird"):
        subjects[1]["quote"] = quote
        reviewer._selection(packet.args)


@pytest.mark.parametrize("quote", ["cafe\u0301", "Cafe\u0301", "café ", "cafe", "CAFÉ"])
def test_required_quote_has_no_unicode_case_or_space_repair(packet, monkeypatch, quote):
    record = packet.save({"text.txt": "café\n"})
    packet.args["files"] = [packet.locator(record, "text.txt")]
    packet.args["reviewed_refs"] = [record["record_path"]]
    packet.args["required_subjects"] = [{**packet.args["files"][0], "quote": quote}]
    model = model_replies(monkeypatch, packet)
    with pytest.raises(ValueError, match="literal contiguous excerpt"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("number", [True, False, None, "1", 1.0, [], {}, 0, -1, 2])
def test_private_selector_is_strict_one_based_integer_without_retry(packet, monkeypatch, number):
    require_report(packet)
    model = model_replies(monkeypatch, packet, selector_answer(packet, number))
    with pytest.raises(ValueError, match="required_subject"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()
    assert not (run_directory(packet) / "initial").exists()


@pytest.mark.parametrize("present", [False, True])
def test_selector_rejected_without_nonempty_required_list(packet, monkeypatch, present):
    if present:
        packet.args["required_subjects"] = []
    model = model_replies(monkeypatch, packet, selector_answer(packet))
    with pytest.raises(ValueError, match="nonempty required_subjects"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("position", ["subject", "evidence"])
def test_selector_cannot_add_fields_or_replace_evidence(packet, monkeypatch, position):
    require_report(packet)
    value = selector_answer(packet)
    if position == "subject":
        value["checks"][0]["subject"]["quote"] = "replacement"
    else:
        value["checks"][0]["evidence"] = [{"required_subject": 1}]
    model = model_replies(monkeypatch, packet, value)
    with pytest.raises(ValueError, match="expected exactly"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("stage", [1, 2])
def test_public_subject_is_still_rejected_as_model_output(packet, monkeypatch, stage):
    require_report(packet)
    good = selector_answer(packet)
    bad = deepcopy(good)
    bad["checks"][0]["subject"] = deepcopy(packet.args["required_subjects"][0])
    model = model_replies(monkeypatch, packet, *([good, bad] if stage == 2 else [bad]))
    with pytest.raises(ValueError, match="review locator: expected exactly file_id, start_line, end_line, quote"):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == stage
    assert (run_directory(packet) / "initial").exists() == (stage == 2)


def omitted(packet, omission):
    """A reply judging every required subject (good) and one that misses one of them (bad)."""
    require_report(packet)
    packet.args["files"].append(packet.locator(packet.report, "unselected-report.txt"))
    good = selector_answer(packet)
    if omission == "missing_second":
        packet.args["required_subjects"].append({
            **packet.locator(packet.report, "unselected-report.txt"), "quote": "UNSELECTED_REPORT_CONTENT"})
        good["checks"].append({"subject": {"required_subject": 2}, "evidence": [],
                               "decision": "unassessed", "reason": "Second required test subject."})
    bad = deepcopy(good)
    if omission == "missing_second":
        bad["checks"].pop()
    elif omission == "other_file":
        bad["checks"][0]["subject"] = {
            "file_id": "F3", "start_line": 1, "end_line": 1, "quote": "UNSELECTED_REPORT_CONTENT"}
    else:
        bad["checks"][0]["subject"] = {**packet.model_value["checks"][0]["subject"], "quote": "condition A."}
        if omission == "evidence_only":
            bad["checks"][0]["evidence"] = [{"file_id": "F1", "start_line": 1, "end_line": 1}]
    return good, bad, [2] if omission == "missing_second" else [1]


OMISSIONS = ["shorter", "evidence_only", "other_file", "missing_second"]


@pytest.mark.parametrize("omission", OMISSIONS)
def test_a_required_subject_the_first_stage_missed_is_asked_of_the_second(packet, monkeypatch, omission):
    good, bad, missing = omitted(packet, omission)
    model = model_replies(monkeypatch, packet, bad, good)
    result = reviewer.execute(packet.args, packet.ctx)
    followup = model.call_args_list[1].kwargs["messages"][0]["content"]
    assert reviewer.MISSED_LABEL + "\n" + json.dumps(missing) + "\n\n" + reviewer.HANDOFF_LABEL in followup
    assert "unjudged_required_subjects" not in result.output


@pytest.mark.parametrize("omission", OMISSIONS)
def test_required_subjects_unjudged_in_both_stages_are_reported_not_discarded(packet, monkeypatch, omission):
    _, bad, missing = omitted(packet, omission)
    model = model_replies(monkeypatch, packet, bad, bad)
    value = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    assert model.call_count == 2
    assert value["unjudged_required_subjects"] == missing and "not assessed" in value["unjudged_note"]
    assert value["review"]["checks"]  # the judged checks are kept


@pytest.mark.parametrize("decision", ["supported", "conditional", "unsupported", "contradicted", "unassessed"])
def test_required_selection_preserves_all_decisions_and_existing_public_format(packet, monkeypatch, decision):
    require_report(packet)
    value = selector_answer(packet)
    value["checks"][0].update(decision=decision, reason="  原判斷及限制\n逐字保存。  ")
    if decision == "unassessed":
        value["checks"][0]["evidence"] = []
    model = model_replies(monkeypatch, packet, value, value)
    result = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    assert set(result) == {"reviewed_refs", "checks"}
    assert result["checks"][0]["subject"] == packet.args["required_subjects"][0]
    assert result["checks"][0]["decision"] == decision
    assert result["checks"][0]["reason"] == value["checks"][0]["reason"]
    assert model.call_count == 2


def test_old_locator_covers_exact_required_subject_with_newline_normalization(packet, monkeypatch):
    record = packet.save({"text.txt": "prefix\r\nExact\rclaim.\r\nsuffix\n"})
    locator = packet.locator(record, "text.txt")
    packet.args.update(reviewed_refs=[record["record_path"]], files=[locator],
                       required_subjects=[{**locator, "quote": "Exact\r\nclaim."}])
    value = {"checks": [{"subject": {"file_id": "F1", "start_line": 2, "end_line": 3,
                                      "quote": "Exact\nclaim."},
                         "evidence": [], "decision": "unassessed", "reason": "No observation."}]}
    model_replies(monkeypatch, packet, value, value)
    result = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    assert result["checks"][0]["subject"] == {**locator, "quote": "Exact\nclaim."}


def test_full_file_selector_preserves_final_newline_and_handoff_omits_initial_judgments(packet, monkeypatch):
    content = '{\r\n  "scope": "Complete candidate input",\r\n  "symbols": ["µm", "界"]\r\n}\r\n'
    record = packet.save({"input.json": content})
    locator = packet.locator(record, "input.json")
    subjects = require_report(packet)
    subjects.append({**locator, "quote": content})
    packet.args["reviewed_refs"].append(record["record_path"])
    packet.args["files"].append(locator)
    initial = selector_answer(packet)
    initial["checks"][0].update(decision="contradicted", reason="INITIAL_PRIVATE_REASON")
    initial["checks"].append({"subject": {"required_subject": 2}, "evidence": [],
                              "decision": "unassessed", "reason": "INITIAL_SECOND_PRIVATE_REASON"})
    initial["checks"].append(deepcopy(packet.model_value["checks"][0]))
    final = deepcopy(initial)
    final["checks"][0].update(decision="conditional", reason="Independent followup.")
    original_args, original_initial, original_final = map(deepcopy, (packet.args, initial, final))
    model = model_replies(monkeypatch, packet, initial, final)
    result = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    expected = {**locator, "quote": review._newlines(content)}
    assert result["checks"][1]["subject"] == expected
    first = model.call_args_list[0].kwargs["messages"][0]["content"]
    second = model.call_args_list[1].kwargs["messages"][0]["content"]
    assert second.startswith(first + "\n\n" + reviewer.HANDOFF_LABEL + "\n")
    required_label = "Required exact subjects (one-based positions; every subject must be judged):\n"
    for message in (first, second):
        listed_subjects = json.loads(message.split(required_label, 1)[1].split("\n", 1)[0])
        assert listed_subjects == [[number, subject] for number, subject in enumerate(subjects, start=1)]
    handoff = json.loads(second.split(reviewer.HANDOFF_LABEL + "\n", 1)[1])
    assert handoff["checks"][1] == {"subject": {"required_subject": 2}, "evidence": []}
    assert handoff["checks"][0]["subject"] == {"required_subject": 1}
    assert handoff["checks"][2]["subject"] == initial["checks"][2]["subject"]
    assert handoff["checks"][0]["evidence"][0]["quote"] == packet.value["checks"][0]["evidence"][0]["quote"]
    assert "INITIAL_PRIVATE_REASON" not in second and "INITIAL_SECOND_PRIVATE_REASON" not in second
    assert '"decision"' not in json.dumps(handoff) and '"reason"' not in json.dumps(handoff)
    saved = initial_files(packet)
    assert json.loads(saved["response.txt"])["checks"][1]["subject"] == {"required_subject": 2}
    assert json.loads(saved["review.json"])["checks"][1]["subject"] == expected
    assert json.loads(saved["arguments.json"]) == original_args
    assert packet.args == original_args
    assert initial == original_initial and final == original_final


def test_required_order_and_original_arguments_stay_frozen_through_shared_recovery(packet, monkeypatch):
    require_report(packet)
    original = deepcopy(packet.args)
    value = selector_answer(packet)
    sent = []

    def complete(ctx, **kwargs):
        sent.append(deepcopy(kwargs["messages"]))
        kwargs["prepared"].update(provider=SimpleNamespace(api="openai"), temperature=0)
        if len(sent) == 1:
            packet.args["required_subjects"][0]["quote"] = "CALLER_MUTATION"
            packet.args["required_subjects"].append(deepcopy(packet.args["required_subjects"][0]))
            return Completion(text="", finish_reason="stop", reasoning_content="Only private reasoning.")
        return packet.completion(value)

    model = Mock(side_effect=complete)
    monkeypatch.setattr(reviewer, "complete_once", model)
    result = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    assert model.call_count == 3
    assert sent[0] == sent[1]
    assert "CALLER_MUTATION" not in json.dumps(sent)
    assert result["checks"][0]["subject"] == original["required_subjects"][0]
    assert json.loads(initial_files(packet)["arguments.json"]) == original


def test_selected_required_snapshot_change_stops_before_model(packet, monkeypatch):
    require_report(packet)
    packet.snapshot(packet.report, "report.md").write_bytes(b"Changed source bytes")
    model = model_replies(monkeypatch, packet)
    with pytest.raises(ValueError, match="hash or bytes changed"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_complete_input_limit_includes_required_quotes_without_truncation(packet, monkeypatch):
    require_report(packet)
    system, message, *_ = reviewer._input(packet.args, packet.ctx)
    packet.args["scope"] += "x" * (reviewer.MAX_BYTES - len(system.encode()) - len(message.encode()))
    system, message, *_ = reviewer._input(packet.args, packet.ctx)
    assert len(system.encode()) + len(message.encode()) == reviewer.MAX_BYTES
    assert packet.args["required_subjects"][0]["quote"] in message
    packet.args["scope"] += "x"
    model = model_replies(monkeypatch, packet)
    with pytest.raises(ValueError, match="Complete review request exceeds"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_small_selectors_cannot_expand_beyond_public_output_limit(packet, monkeypatch):
    content = "A" * 6000 + "\n"
    record = packet.save({"long.txt": content})
    locator = packet.locator(record, "long.txt")
    packet.args.update(reviewed_refs=[record["record_path"]], files=[locator],
                       required_subjects=[{**locator, "quote": content}])
    check = {"subject": {"required_subject": 1}, "evidence": [],
             "decision": "unassessed", "reason": "No observation."}
    value = {"checks": [deepcopy(check) for _ in range(44)]}
    assert len(packet.completion(value).text.encode()) < 10000
    model = model_replies(monkeypatch, packet, value)
    with pytest.raises(ValueError, match="262144-byte output limit"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()
    assert not (run_directory(packet) / "initial").exists()
