"""Offline review recovery boundaries, using synthetic test-only record content.

No completion here is a real scientific review or published research outcome.
The existing review fixture creates content-addressed files only in a temporary
workspace, so acceptance still exercises real scope and literal-quote validation.
"""

from copy import deepcopy
import json
from types import SimpleNamespace
from unittest.mock import Mock, patch

import httpx
import pytest

from opencode.permission import PermissionRejected
from opencode.provider import Completion, ProviderError, ToolCall
from researchkit import records, reviewer
import test_research_review as review_cases


PRIVATE_REASONING = "PRIVATE_REASONING_MUST_NOT_BECOME_AN_ANSWER_OR_PROMPT"


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Review retry tests must not call real models or network transports")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)


@pytest.fixture
def packet():
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def reasoning_only(*, text="", reasoning=PRIVATE_REASONING, reason="stop", tools=()):
    return Completion(text=text, reasoning_content=reasoning, finish_reason=reason,
                      tool_calls=list(tools))


def install_replies(monkeypatch, replies, *, api="openai", after_call=None):
    pending = iter(replies)

    def complete(ctx, **kwargs):
        state = {"provider": SimpleNamespace(api=api), "temperature": 0, "temperature_supported": True}
        for name in ("prepared", "frozen"):
            for key, value in state.items():
                kwargs[name].setdefault(key, value)
        reply = next(pending)
        if isinstance(reply, BaseException):
            raise reply
        if after_call is not None:
            after_call(ctx, kwargs)
        return reply

    model = Mock(side_effect=complete)
    monkeypatch.setattr(reviewer, "complete_once", model)
    return model


def invalid_answer(packet, case):
    if case == "invalid-json":
        return "{broken"
    if case == "duplicate-field":
        return packet.completion().text.replace('"checks":', '"checks": [], "checks":', 1)
    if case == "duplicate-quote":
        return packet.completion().text.replace('"quote":', '"quote": "first", "quote":', 1)
    value = deepcopy(packet.model_value)
    if case == "wrong-refs":
        value["reviewed_refs"] = [packet.source["record_path"]]
    elif case == "outside-selection":
        value["checks"][0]["evidence"][0]["file_id"] = "F999"
    elif case == "outside-lines":
        value["checks"][0]["evidence"][0]["end_line"] = 2
    elif case == "missing-quote":
        value["checks"][0]["subject"].pop("quote")
    elif case == "mismatched-quote":
        value["checks"][0]["subject"]["quote"] = "A paraphrase absent from the selected source."
    elif case == "evidence-quote":
        value["checks"][0]["evidence"][0]["quote"] = "Frozen observation under condition A."
    else:
        raise AssertionError(f"Unknown test case: {case}")
    return json.dumps(value)


@pytest.mark.parametrize("reason", ["stop", "length"])
@pytest.mark.parametrize("text", ["", " \t\n "])
def test_reasoning_only_recovery_reuses_input_and_validates_only_the_final_answer(
        monkeypatch, packet, reason, text):
    final = packet.completion()
    before = {path.relative_to(packet.workspace): path.read_bytes()
              for path in packet.workspace.rglob("*") if path.is_file()}
    model = install_replies(monkeypatch, [reasoning_only(text=text, reason=reason), final, final])
    with patch.object(reviewer, "_input", wraps=reviewer._input) as prepare_input, \
            patch.object(reviewer, "_validate_completion", wraps=reviewer._validate_completion) as validate, \
            patch.object(records, "publish", side_effect=AssertionError("Review must not publish")):
        result = reviewer.execute(packet.args, packet.ctx)

    assert json.loads(result.output) == packet.value
    assert result.output != final.text
    assert set(result.metadata) == {"host_note"} and result.attachments == []
    assert model.call_count == 3
    original, recovery, second = model.call_args_list
    assert original.args == recovery.args == (packet.ctx,)
    assert set(original.kwargs) == {"system", "messages", "prepared", "frozen", "response_schema"}
    assert recovery.kwargs == {**original.kwargs, "recovery_temperature": 0.6}
    assert original.kwargs["prepared"] is recovery.kwargs["prepared"]
    assert original.kwargs["messages"] is recovery.kwargs["messages"]
    for call in model.call_args_list:
        request = {name: call.kwargs[name] for name in ("system", "messages")}
        assert PRIVATE_REASONING not in json.dumps(request)
    prepare_input.assert_called_once_with(packet.args, packet.ctx)
    assert all(call.args[0].text == final.text for call in validate.call_args_list)
    assert validate.call_count >= 2
    after = {path.relative_to(packet.workspace): path.read_bytes()
             for path in packet.workspace.rglob("*") if path.is_file()}
    assert {path: after[path] for path in before} == before
    added = set(after) - set(before)
    assert {path.name for path in added} == {"arguments.json", "response.txt", "review.json"}
    assert all(path.parts[:2] == (".research", "review-runs") for path in added)


@pytest.mark.parametrize("failure", [
    reasoning_only(reason="unknown"), reasoning_only(reason=None),
    reasoning_only(reason="tool_calls"), reasoning_only(reason="content_filter"),
    reasoning_only(tools=[ToolCall("unexpected", "read", {})]),
    reasoning_only(reasoning=None), reasoning_only(reasoning=""),
    reasoning_only(reasoning=" \n\t "), reasoning_only(reasoning=17),
    reasoning_only(reasoning=["private"]), reasoning_only(text=None),
    reasoning_only(text=[]), reasoning_only(text={}),
], ids=["unknown-finish", "missing-finish", "tool-finish", "filtered", "tool-calls",
        "missing-reasoning", "empty-reasoning", "blank-reasoning", "numeric-reasoning",
        "list-reasoning", "missing-text", "list-text", "object-text"])
def test_ineligible_first_completion_is_rejected_without_retry(monkeypatch, packet, failure):
    model = install_replies(monkeypatch, [failure, packet.completion()])
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()
    assert "recovery_temperature" not in model.call_args.kwargs


@pytest.mark.parametrize("case", ["invalid-json", "duplicate-field", "wrong-refs",
                                  "outside-selection", "outside-lines", "missing-quote",
                                  "mismatched-quote", "duplicate-quote", "evidence-quote"])
def test_nonempty_invalid_first_answer_is_not_repaired(monkeypatch, packet, case):
    invalid = reasoning_only(text=invalid_answer(packet, case))
    model = install_replies(monkeypatch, [invalid, packet.completion()])
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("failure", [
    reasoning_only(), reasoning_only(reason="length"),
    reasoning_only(text='{"checks":', reason="length"),
    reasoning_only(reason="unknown"), reasoning_only(reason=None),
    reasoning_only(tools=[ToolCall("unexpected", "read", {})]),
    reasoning_only(text=None),
], ids=["still-empty", "still-length", "length-partial-text", "unknown-finish",
        "missing-finish", "tool-calls", "missing-text"])
def test_failed_recovery_never_uses_a_third_generation(monkeypatch, packet, failure):
    model = install_replies(monkeypatch, [reasoning_only(reason="length"), failure, packet.completion()])
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2


@pytest.mark.parametrize("case", ["invalid-json", "duplicate-field", "wrong-refs",
                                  "outside-selection", "outside-lines", "length-valid-json",
                                  "missing-quote", "mismatched-quote", "duplicate-quote", "evidence-quote"])
def test_recovery_must_pass_all_existing_answer_validation(monkeypatch, packet, case):
    final = (Completion(text=packet.completion().text, finish_reason="length")
             if case == "length-valid-json"
             else Completion(text=invalid_answer(packet, case), finish_reason="stop"))
    model = install_replies(monkeypatch, [reasoning_only(), final, packet.completion()])
    with patch.object(reviewer, "_validate_completion", wraps=reviewer._validate_completion) as validate, \
            pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    validate.assert_called_once()
    assert validate.call_args.args[0] is final


@pytest.mark.parametrize("failure", [
    ProviderError("HTTP 503", partial=reasoning_only()),
    ProviderError("local deadline", partial=reasoning_only(reason="length")),
    httpx.ConnectError("transport unavailable"), httpx.ReadTimeout("idle timeout"),
    RuntimeError("model request failed"),
], ids=["http-status", "deadline", "transport", "read-timeout", "unexpected-error"])
@pytest.mark.parametrize("attempt", [1, 2])
def test_exceptions_are_terminal_even_if_partial_completion_is_eligible(
        monkeypatch, packet, failure, attempt):
    replies = ([reasoning_only()] if attempt == 2 else []) + [failure, packet.completion()]
    model = install_replies(monkeypatch, replies)
    with pytest.raises(type(failure)) as caught:
        reviewer.execute(packet.args, packet.ctx)
    assert caught.value is failure
    assert model.call_count == attempt


@pytest.mark.parametrize("reason", ["stop", "length"])
def test_anthropic_reasoning_only_completion_keeps_single_call_policy(monkeypatch, packet, reason):
    model = install_replies(monkeypatch, [reasoning_only(reason=reason), packet.completion()], api="anthropic")
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("cancel_after", [0, 1, 2])
def test_parent_cancellation_prevents_retry_or_return(monkeypatch, packet, cancel_after):
    completed = 0

    def cancel(ctx, kwargs):
        nonlocal completed
        completed += 1
        if completed == cancel_after:
            ctx.abort.set()

    if cancel_after == 0:
        packet.abort.set()
    model = install_replies(monkeypatch, [reasoning_only(), packet.completion()], after_call=cancel)
    expected = ProviderError if cancel_after else PermissionRejected
    with pytest.raises(expected, match="aborted" if cancel_after else "Execution stopped"):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == cancel_after


def test_json_shaped_reasoning_is_never_used_as_answer_or_recovery_input(monkeypatch, packet):
    private_answer = packet.completion().text
    model = install_replies(monkeypatch, [reasoning_only(reasoning=private_answer), reasoning_only()])
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    for call in model.call_args_list:
        assert private_answer not in call.kwargs["system"]
        assert private_answer not in call.kwargs["messages"][0]["content"]


def test_prepared_state_and_recovery_allowance_are_local_to_each_invocation(monkeypatch, packet):
    model = install_replies(monkeypatch, [reasoning_only(), packet.completion(), packet.completion(),
                                        reasoning_only(reason="length"), packet.completion(), packet.completion()])
    reviewer.execute(packet.args, packet.ctx)
    packet.next_call()
    reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 6
    first, recovery, second, next_first, next_recovery, next_second = model.call_args_list
    assert first.kwargs["prepared"] is recovery.kwargs["prepared"]
    assert second.kwargs["prepared"] is not first.kwargs["prepared"]
    assert next_first.kwargs["prepared"] is next_recovery.kwargs["prepared"]
    assert first.kwargs["frozen"] is second.kwargs["frozen"]
    assert first.kwargs["frozen"] is not next_first.kwargs["frozen"]
    assert "recovery_temperature" not in first.kwargs
    assert "recovery_temperature" not in second.kwargs
    assert "recovery_temperature" not in next_first.kwargs
    assert recovery.kwargs["recovery_temperature"] == next_recovery.kwargs["recovery_temperature"] == 0.6


def test_recovery_does_not_reread_changed_instruction_file(monkeypatch, packet):
    instructions = packet.file("retry-verification.md", "Initial frozen verification instructions.")
    monkeypatch.setattr(reviewer, "VERIFICATION_PATH", instructions)

    def change_instructions(ctx, kwargs):
        instructions.write_text("Changed instructions must wait for the next invocation.", encoding="utf-8")

    model = install_replies(monkeypatch, [reasoning_only(), packet.completion(), packet.completion()], after_call=change_instructions)
    reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 3
    assert model.call_args_list[0].kwargs["system"] == model.call_args_list[1].kwargs["system"]
    assert "Initial frozen verification instructions." in model.call_args_list[1].kwargs["system"]
    assert "Changed instructions" not in model.call_args_list[1].kwargs["system"]


def test_recovery_freezes_selection_ids_and_public_refs_from_original_arguments(monkeypatch, packet):
    original_args = deepcopy(packet.args)

    def change_caller_arguments(ctx, kwargs):
        packet.args["files"].reverse()
        packet.args["reviewed_refs"][:] = [packet.source["record_path"]]

    model = install_replies(monkeypatch, [reasoning_only(), packet.completion(), packet.completion()],
                            after_call=change_caller_arguments)
    result = reviewer.execute(packet.args, packet.ctx)
    assert json.loads(result.output) == packet.value
    assert model.call_count == 3
    original, recovery, second = model.call_args_list
    assert original.kwargs["messages"] is recovery.kwargs["messages"]
    user = original.kwargs["messages"][0]["content"].split("\n")
    assert json.loads(user[3]) == original_args["reviewed_refs"]
    for number, line in enumerate((5, 9), start=1):
        metadata = json.loads(user[line])
        assert {key: metadata[key] for key in ("file_id", "record_ref", "source_path")} == {
            "file_id": f"F{number}", **original_args["files"][number - 1]}
        assert metadata["origin"]["status"] == "snapshot_only"
