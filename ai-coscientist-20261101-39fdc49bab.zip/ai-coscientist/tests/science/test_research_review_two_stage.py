"""Approved two-stage boundary replay with local, scripted HTTP responses only.

The synthetic decisions prove transport, isolation and persistence mechanics;
none is evidence that the model's scientific judgments improve.
"""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import threading
from unittest.mock import Mock, patch

import httpx
import pytest

from opencode.permission import PermissionDenied, Rule
from opencode.provider import Completion, ProviderError
from researchkit import reviewer
import test_research_review as review_cases
import test_review_provider as transport_cases


INITIAL_REASON_SENTINEL = "INITIAL_REASON_ONLY_9d2750d8_MUST_STAY_IN_SAVED_REVIEW"


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Two-stage boundary tests must never contact a real endpoint")
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


@pytest.fixture
def packet():
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def run_directory(packet):
    identity = [packet.ctx.session_id, packet.ctx.message_id, packet.ctx.call_id]
    key = sha256(json.dumps(identity, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()
    return packet.workspace / ".research/review-runs" / key


def initial_files(packet):
    folder = run_directory(packet) / "initial"
    return {name: (folder / name).read_bytes() for name in ("arguments.json", "response.txt", "review.json")}


def install_wire(monkeypatch, packet, replies, *, api="openai", capable=True, temperature=0, hook=None):
    transport_ctx, _ = transport_cases.context(api=api, capable=capable, temperature=temperature)
    packet.ctx.app.provider = transport_ctx.app.provider
    packet.ctx.app.store.get_session = transport_ctx.app.store.get_session
    packet.ctx.agent.temperature = temperature
    packet.ctx.app.provider.config["provider"]["review"]["models"]["current-model"]["options"]["reasoningEffort"] = "none"
    requests, pending = [], iter(replies)

    def receive(request):
        requests.append(request)
        if hook:
            hook(len(requests), request)
        reply = next(pending)
        if isinstance(reply, BaseException):
            raise reply
        if isinstance(reply, tuple):
            text, reason = reply
        else:
            text, reason = reply, None
        return transport_cases.wire_response(api, text=text, reason=reason)

    transport_cases.install_transport(monkeypatch, receive)
    return requests


def body(request):
    return json.loads(request.content)


def changed_answer(packet):
    value = deepcopy(packet.model_value)
    value["checks"][0].update(decision="contradicted", reason="Second-stage scripted decision; retained verbatim.")
    return packet.completion(value).text


def assert_locator_handoff(first_user, second_user, initial):
    """Rebuild the quotations from encoded frozen lines, without product helpers."""
    prefix = first_user + "\n\n" + reviewer.HANDOFF_LABEL + "\n"
    assert second_user.startswith(prefix)
    appended = second_user[len(prefix):]
    sections = first_user.split("\n")
    frozen = {json.loads(sections[offset + 1])["file_id"]:
              [line for _, line in json.loads(sections[offset + 3])]
              for offset, section in enumerate(sections) if section == "Selected frozen file:"}
    expected = {"checks": []}
    for check in json.loads(initial)["checks"]:
        subject = dict(check["subject"])
        subject["quote"] = subject["quote"].replace("\r\n", "\n").replace("\r", "\n")
        evidence = [{**item, "quote": "\n".join(frozen[item["file_id"]][item["start_line"] - 1:item["end_line"]])}
                    for item in check["evidence"]]
        expected["checks"].append({"subject": subject, "evidence": evidence})
    assert json.loads(appended) == expected
    assert appended == json.dumps(expected, ensure_ascii=False, separators=(",", ":"))
    assert INITIAL_REASON_SENTINEL not in appended
    for check in json.loads(appended)["checks"]:
        assert set(check) == {"subject", "evidence"}
        for locator in [check["subject"], *check["evidence"]]:
            assert set(locator) == {"file_id", "start_line", "end_line", "quote"}
    return appended


def test_actual_second_stage_uses_bound_claim_and_source_quotations_without_initial_judgments(monkeypatch, packet):
    packet.model_value["checks"][0]["reason"] = INITIAL_REASON_SENTINEL
    packet.value["checks"][0]["reason"] = INITIAL_REASON_SENTINEL
    # These ordinary words may occur in original evidence/commission text; only
    # the appended projection must lack the initial judgment fields and values.
    packet.args["scope"] += " The words reason and decision remain valid source text."
    initial = " \n" + json.dumps(packet.model_value, ensure_ascii=False, indent=3) + "\n "
    final = changed_answer(packet)
    original_args = deepcopy(packet.args)
    reads, committed_at_dispatch = [], []
    original_open = Path.open

    def observe(path, mode="r", *args, **kwargs):
        if "r" in mode and "initial" in path.parts:
            reads.append(path.resolve())
        return original_open(path, mode, *args, **kwargs)

    def dispatch(index, request):
        if index == 2:
            committed_at_dispatch.append(initial_files(packet))
            folder = run_directory(packet) / "initial"
            assert all((folder / name).resolve() in reads for name in ("arguments.json", "response.txt", "review.json"))
            assert not (run_directory(packet) / ".initial.pending").exists()

    sent = install_wire(monkeypatch, packet, [initial, final], hook=dispatch)
    with patch.object(Path, "open", observe):
        result = reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2 and len(committed_at_dispatch) == 1
    saved = committed_at_dispatch[0]
    assert saved["arguments.json"] == (json.dumps(original_args, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
    assert saved["response.txt"] == initial.encode()
    assert json.loads(saved["review.json"]) == packet.value
    assert saved["review.json"] == (json.dumps(packet.value, ensure_ascii=False, separators=(",", ":")) + "\n").encode()
    first, second = map(body, sent)
    assert second["messages"] != first["messages"]
    first_user, second_user = first["messages"][-1]["content"], second["messages"][-1]["content"]
    assert_locator_handoff(first_user, second_user, initial)
    assert "reason and decision" in second_user
    assert INITIAL_REASON_SENTINEL not in second_user
    assert first["messages"][0]["content"] != second["messages"][0]["content"]
    assert reviewer.FOLLOWUP_PATH.read_text(encoding="utf-8") in second["messages"][0]["content"]
    for request in sent:
        encoded = request.content.decode()
        assert "Frozen observation under condition A." in encoded
        assert "Conditional interpretation for condition A." in encoded
        assert "private reasoning" not in encoded
        assert "UNSELECTED_PRIVATE_CONTENT" not in encoded
        assert "PARENT_BUILD_PROMPT_PRIVATE" not in encoded
        assert "tools" not in body(request)
    output = json.loads(result.output)
    assert output["checks"][0]["decision"] == "contradicted"
    assert output["checks"][0]["reason"] == json.loads(final)["checks"][0]["reason"]
    assert set(result.metadata) == {"host_note"} and result.attachments == []
    assert (run_directory(packet) / "final" / "review.json").read_text(encoding="utf-8") == result.output
    assert initial_files(packet) == saved


def test_projection_preserves_order_exact_ranges_and_empty_evidence_without_deriving_labels(monkeypatch, packet):
    source = packet.save({"ordered-source.txt": "First observation.\r\nSecond observation.\rThird observation.\n"})
    report = packet.save({"ordered-report.md": "First claim.\r\nSecond claim.\rThird claim.\n"})
    packet.args["reviewed_refs"] = [report["record_path"]]
    packet.args["files"] = [packet.locator(report, "ordered-report.md"),
                            packet.locator(source, "ordered-source.txt")]
    one = {"file_id": "F2", "start_line": 1, "end_line": 1}
    two = {"file_id": "F2", "start_line": 2, "end_line": 3}
    initial_value = {"checks": [
        {"subject": {"file_id": "F1", "start_line": 3, "end_line": 3, "quote": "Third claim."},
         "evidence": [two, one], "decision": "supported", "reason": INITIAL_REASON_SENTINEL + "_0"},
        {"subject": {"file_id": "F1", "start_line": 1, "end_line": 2, "quote": "claim.\r\nSecond"},
         "evidence": [one, two], "decision": "unsupported", "reason": INITIAL_REASON_SENTINEL + "_1"},
        {"subject": {"file_id": "F1", "start_line": 2, "end_line": 2, "quote": "Second claim."},
         "evidence": [], "decision": "unassessed", "reason": INITIAL_REASON_SENTINEL + "_2"},
    ]}
    initial = packet.completion(initial_value).text
    final_value = deepcopy(initial_value)
    final_value["checks"] = final_value["checks"][:1]
    final_value["checks"][0].update(decision="unsupported", reason="Final independent scripted explanation.")
    final_value["checks"][0]["subject"]["quote"] = "claim"
    sent = install_wire(monkeypatch, packet, [initial, packet.completion(final_value).text])
    result = reviewer.execute(packet.args, packet.ctx)
    first, second = map(body, sent)
    assert_locator_handoff(first["messages"][-1]["content"], second["messages"][-1]["content"], initial)
    saved = initial_files(packet)
    assert saved["response.txt"] == initial.encode()
    assert json.loads(saved["response.txt"])["checks"][1]["subject"]["quote"] == "claim.\r\nSecond"
    assert json.loads(saved["review.json"])["checks"][1]["subject"]["quote"] == "claim.\nSecond"
    assert [(check["decision"], check["reason"]) for check in json.loads(saved["review.json"])["checks"]] == [
        (check["decision"], check["reason"]) for check in initial_value["checks"]]
    final_check, = json.loads(result.output)["checks"]
    assert final_check["decision"] == "unsupported"
    assert final_check["reason"] == "Final independent scripted explanation."
    assert final_check["subject"]["quote"] == "claim"
    assert [item["quote"] for item in final_check["evidence"]] == ["Second observation.\nThird observation.", "First observation."]


@pytest.mark.parametrize("route,count,temperatures,ok", [
    ("normal", 2, [0, 0], True),
    ("recover-first", 3, [0, 0.6, 0], True),
    ("recover-second", 3, [0, 0, 0.6], True),
    ("exhausted", 3, [0, 0.6, 0], False),
    ("failed-first-recovery", 2, [0, 0.6], False),
    ("failed-second-recovery", 3, [0, 0, 0.6], False),
])
def test_shared_recovery_budget_and_stage_temperature(monkeypatch, packet, route, count, temperatures, ok):
    packet.model_value["checks"][0]["reason"] = INITIAL_REASON_SENTINEL
    packet.value["checks"][0]["reason"] = INITIAL_REASON_SENTINEL
    good = packet.completion().text
    empty = ("", "length")
    replies = {"normal": [good, good], "recover-first": [empty, good, good],
               "recover-second": [good, empty, good], "exhausted": [empty, good, empty],
               "failed-first-recovery": [empty, empty], "failed-second-recovery": [good, empty, empty]}[route]
    sent = install_wire(monkeypatch, packet, replies)
    if ok:
        assert json.loads(reviewer.execute(packet.args, packet.ctx).output) == packet.value
    else:
        with pytest.raises(ValueError):
            reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == count <= 3
    bodies = list(map(body, sent))
    assert [item["temperature"] for item in bodies] == temperatures
    assert all(item["reasoning_effort"] == "none" for item in bodies)
    if "first" in route or route == "exhausted":
        assert bodies[1] == {**bodies[0], "temperature": 0.6}
    if "second" in route:
        assert bodies[2] == {**bodies[1], "temperature": 0.6}
    if route != "failed-first-recovery":
        second_index = 2 if route in {"recover-first", "exhausted"} else 1
        for item in bodies[second_index:]:
            assert_locator_handoff(bodies[0]["messages"][-1]["content"],
                                   item["messages"][-1]["content"], good)
        assert initial_files(packet)["response.txt"] == good.encode()
        assert json.loads(initial_files(packet)["review.json"]) == packet.value
    assert all(INITIAL_REASON_SENTINEL not in request.content.decode() for request in sent)
    assert (run_directory(packet) / "initial").exists() == (route != "failed-first-recovery")
    assert run_directory(packet).is_dir()


@pytest.mark.parametrize("stage", ["first", "first-recovery", "second", "second-recovery"])
@pytest.mark.parametrize("damage", ["missing-quote", "mismatched-quote", "evidence-quote", "unsupported-empty"])
def test_invalid_bound_claim_never_adds_generation_and_preserves_completed_initial(
        monkeypatch, packet, stage, damage):
    good = packet.completion().text
    invalid = deepcopy(packet.model_value)
    if damage == "missing-quote":
        invalid["checks"][0]["subject"].pop("quote")
    elif damage == "mismatched-quote":
        invalid["checks"][0]["subject"]["quote"] = "Changed interpretation for condition B."
    elif damage == "evidence-quote":
        invalid["checks"][0]["evidence"][0]["quote"] = "Frozen observation under condition A."
    else:
        invalid["checks"][0].update(evidence=[], decision="unsupported")
    replies = [good] if stage.startswith("second") else []
    if stage.endswith("recovery"):
        replies.append(("", "length"))
    replies.append(packet.completion(invalid).text)
    sent = install_wire(monkeypatch, packet, replies)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == len(replies) <= 3
    if stage.endswith("recovery"):
        assert body(sent[-1]) == {**body(sent[-2]), "temperature": 0.6}
    if stage.startswith("second"):
        assert initial_files(packet)["response.txt"] == good.encode()
        assert json.loads(initial_files(packet)["review.json"]) == packet.value
        first_user = body(sent[0])["messages"][-1]["content"]
        for request in sent[1:]:
            assert_locator_handoff(first_user, body(request)["messages"][-1]["content"], good)
    else:
        assert not (run_directory(packet) / "initial").exists()


@pytest.mark.parametrize("api,capable,temperature", [("anthropic", True, 0), ("openai", False, 0), ("openai", True, 0.6)])
def test_second_stage_ineligible_recovery_never_dispatches_extra(monkeypatch, packet, api, capable, temperature):
    good = packet.completion().text
    sent = install_wire(monkeypatch, packet, [good, ""], api=api, capable=capable, temperature=temperature)
    expected = ProviderError if api == "openai" and not capable else ValueError
    with pytest.raises(expected):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2
    assert initial_files(packet)["response.txt"] == good.encode()


def test_anthropic_two_normal_stages(monkeypatch, packet):
    good = packet.completion().text
    sent = install_wire(monkeypatch, packet, [good, changed_answer(packet)], api="anthropic")
    result = reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2
    assert body(sent[0])["messages"] != body(sent[1])["messages"]
    assert json.loads(result.output)["checks"][0]["decision"] == "contradicted"


def test_settings_arguments_and_sources_are_frozen_across_stages(monkeypatch, packet):
    good = packet.completion().text
    original_args = deepcopy(packet.args)
    def mutate(index, request):
        if index != 1:
            return
        live = packet.ctx.app.provider
        definition = live.config["provider"]["review"]["models"]["current-model"]
        definition["limit"]["output"] = 23
        definition["options"].update(top_p=0.9, reasoningEffort="high", include_stream_usage=False)
        definition["temperature"] = False
        live.providers["review"].base_url = "https://changed.invalid/v2"
        live.providers["review"].api_key = "changed-key"
        packet.ctx.app.store.get_session.return_value = {"model": "review/changed-model"}
        packet.ctx.agent.temperature = 0.3
        packet.args["scope"] = "MUTATED_SCOPE"
        packet.args["files"].reverse()
        packet.args["reviewed_refs"][:] = [packet.source["record_path"]]
        packet.file("source.txt", "MUTATED_WORKING_SOURCE")
    sent = install_wire(monkeypatch, packet, [good, good], hook=mutate)
    assert json.loads(reviewer.execute(packet.args, packet.ctx).output) == packet.value
    first, second = map(body, sent)
    assert {k: v for k, v in first.items() if k != "messages"} == {k: v for k, v in second.items() if k != "messages"}
    assert sent[0].url == sent[1].url
    assert sent[0].headers["authorization"] == sent[1].headers["authorization"]
    assert json.loads(initial_files(packet)["arguments.json"]) == original_args
    assert b"MUTATED_SCOPE" not in sent[1].content and b"MUTATED_WORKING_SOURCE" not in sent[1].content
    packet.ctx.app.store.get_session.assert_called_once()


@pytest.mark.parametrize("failure", ["invalid", "length", "http", "abort"])
def test_second_stage_failure_keeps_initial_and_never_falls_back(monkeypatch, packet, failure):
    good = packet.completion().text
    error = ProviderError("second dispatch failed", partial=Completion(text="partial", finish_reason="length"))
    completion = {"invalid": "{broken", "length": (good, "length"), "http": error, "abort": good}[failure]
    def abort(index, request):
        if index == 2 and failure == "abort":
            packet.abort.set()
    sent = install_wire(monkeypatch, packet, [good, completion], hook=abort)
    expected = ProviderError if failure in {"http", "abort"} else ValueError
    with pytest.raises(expected) as caught:
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2
    assert initial_files(packet)["response.txt"] == good.encode()
    if failure != "abort":
        message = str(caught.value)
        assert "初審已保存" in message and "複核未完成" in message
        assert str((run_directory(packet) / "initial").resolve()) in message
    if failure == "http":
        assert caught.value is error
        assert caught.value.partial is error.partial


@pytest.mark.parametrize("part", ["session_id", "message_id", "call_id"])
@pytest.mark.parametrize("bad", [None, "", "  "])
def test_missing_native_identity_fails_before_model(monkeypatch, packet, part, bad):
    setattr(packet.ctx, part, bad)
    model = Mock()
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_existing_identity_is_not_overwritten_or_redispatched(monkeypatch, packet):
    folder = run_directory(packet)
    folder.mkdir(parents=True)
    marker = folder / "already-used.txt"
    marker.write_text("retain", encoding="utf-8")
    model = Mock()
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises((ValueError, FileExistsError)):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert marker.read_text() == "retain"


def test_concurrent_same_identity_allows_only_one_owner_to_dispatch(monkeypatch, packet):
    entered, release = threading.Event(), threading.Event()
    calls = []
    def complete(*args, **kwargs):
        calls.append(kwargs)
        if len(calls) == 1:
            entered.set()
            assert release.wait(5)
        return packet.completion()
    monkeypatch.setattr(reviewer, "complete_once", complete)
    with ThreadPoolExecutor(max_workers=2) as pool:
        first = pool.submit(reviewer.execute, packet.args, packet.ctx)
        assert entered.wait(5)
        duplicate = pool.submit(reviewer.execute, packet.args, packet.ctx)
        try:
            with pytest.raises((ValueError, FileExistsError)):
                duplicate.result(timeout=5)
            assert len(calls) == 1
        finally:
            release.set()
        assert json.loads(first.result(timeout=5).output) == packet.value
    assert len(calls) == 2


@pytest.mark.parametrize("phase", ["initial", ".initial.pending"])
@pytest.mark.parametrize("target", ["", "arguments.json", "response.txt", "review.json"])
@pytest.mark.parametrize("permission", ["read", "edit"])
def test_all_final_and_pending_destinations_require_preflight_permission(monkeypatch, packet, phase, target, permission):
    path = run_directory(packet) / phase
    if target:
        path /= target
    packet.ctx.agent.permission.append(Rule(permission, path.relative_to(packet.workspace).as_posix(), "deny"))
    model = Mock()
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(PermissionDenied):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert not (run_directory(packet) / "initial").exists()


def test_large_initial_reason_and_whitespace_are_saved_but_do_not_consume_second_stage_capacity(monkeypatch, packet):
    large = deepcopy(packet.model_value)
    large["checks"][0]["reason"] = INITIAL_REASON_SENTINEL + "x" * (reviewer.MAX_BYTES - 2048)
    initial = packet.completion(large).text + " " * reviewer.MAX_BYTES
    assert len(initial.encode()) > reviewer.MAX_BYTES
    sent = install_wire(monkeypatch, packet, [initial, changed_answer(packet)])
    result = reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2
    first, second = map(body, sent)
    assert_locator_handoff(first["messages"][-1]["content"], second["messages"][-1]["content"], initial)
    assert initial_files(packet)["response.txt"] == initial.encode()
    assert json.loads(initial_files(packet)["review.json"])["checks"][0]["reason"] == large["checks"][0]["reason"]
    assert json.loads(result.output)["checks"][0]["decision"] == "contradicted"


def test_actual_projected_second_stage_request_limit_preserves_initial_and_stops_dispatch(monkeypatch, packet):
    # Make the locator projection larger than the difference between the two
    # system prompts. Then measure an actual encoded request to set the boundary.
    many = {"checks": [deepcopy(packet.model_value["checks"][0]) for _ in range(100)]}
    for index, check in enumerate(many["checks"]):
        check["reason"] = INITIAL_REASON_SENTINEL + str(index)
    initial = packet.completion(many).text
    sent = install_wire(monkeypatch, packet, [initial, changed_answer(packet), initial, changed_answer(packet), initial])
    reviewer.execute(packet.args, packet.ctx)
    first, second = map(body, sent)
    first_size = sum(len(item["content"].encode()) for item in first["messages"])
    second_size = sum(len(item["content"].encode()) for item in second["messages"])
    assert second_size > first_size
    assert_locator_handoff(first["messages"][-1]["content"], second["messages"][-1]["content"], initial)
    packet.args["scope"] += "x" * (reviewer.MAX_BYTES - second_size)
    packet.next_call()
    reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 4
    assert sum(len(item["content"].encode()) for item in body(sent[3])["messages"]) == reviewer.MAX_BYTES
    packet.args["scope"] += "x"
    packet.next_call()
    with pytest.raises(ValueError, match="Complete review request exceeds the 262144-byte limit"):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 5
    assert initial_files(packet)["response.txt"] == initial.encode()
    assert [(check["decision"], check["reason"]) for check in json.loads(initial_files(packet)["review.json"])["checks"]] == [
        (check["decision"], check["reason"]) for check in many["checks"]]


@pytest.mark.parametrize("tamper", ["source", "abort"])
def test_post_commit_readback_or_source_change_blocks_second_stage(monkeypatch, packet, tamper):
    original_save = reviewer._save_initial
    def mutate(*args, **kwargs):
        result = original_save(*args, **kwargs)
        if tamper == "source":
            source = packet.snapshot(packet.source, "source.txt")
            source.write_bytes(b"X" * source.stat().st_size)
        else:
            packet.abort.set()
        return result
    monkeypatch.setattr(reviewer, "_save_initial", mutate)
    sent = install_wire(monkeypatch, packet, [packet.completion().text])
    with pytest.raises((ValueError, ProviderError)):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert (run_directory(packet) / "initial").is_dir()


@pytest.mark.parametrize("phase", [".initial.pending", "initial"])
def test_changed_initial_bytes_at_required_readback_prevent_second_dispatch(monkeypatch, packet, phase):
    original_open = Path.open
    def altered_read(path, mode="r", *args, **kwargs):
        if path.parent.name == phase and path.name == "response.txt" and mode == "rb":
            return BytesIO(b"changed saved bytes")
        return original_open(path, mode, *args, **kwargs)
    monkeypatch.setattr(Path, "open", altered_read)
    sent = install_wire(monkeypatch, packet, [packet.completion().text])
    with pytest.raises(ValueError, match="Saved initial review bytes changed"):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert (run_directory(packet) / "initial").exists() == (phase == "initial")
    assert run_directory(packet).is_dir()


def test_second_stage_public_output_limit_remains_enforced(monkeypatch, packet):
    initial = packet.completion().text
    large = deepcopy(packet.model_value)
    large["checks"][0]["reason"] = "界" * (reviewer.MAX_BYTES // 3 + 1)
    sent = install_wire(monkeypatch, packet, [initial, packet.completion(large).text])
    with pytest.raises(ValueError, match="262144-byte output limit"):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 2
    assert initial_files(packet)["response.txt"] == initial.encode()


@pytest.mark.parametrize("target", ["parent", "invocation"])
@pytest.mark.parametrize("permission", ["edit", "read"])
def test_save_parent_and_invocation_permissions_are_preflighted(monkeypatch, packet, target, permission):
    path = run_directory(packet) if target == "invocation" else run_directory(packet).parent
    packet.ctx.agent.permission.append(Rule(permission, path.relative_to(packet.workspace).as_posix(), "deny"))
    model = Mock()
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(PermissionDenied):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_permission_rejection_after_commit_keeps_original_exception_type(monkeypatch, packet):
    original_save = reviewer._save_initial
    def revoke(*args, **kwargs):
        result = original_save(*args, **kwargs)
        selected = packet.snapshot(packet.source, "source.txt").relative_to(packet.workspace).as_posix()
        packet.ctx.agent.permission.append(Rule("read", selected, "deny"))
        return result
    monkeypatch.setattr(reviewer, "_save_initial", revoke)
    sent = install_wire(monkeypatch, packet, [packet.completion().text])
    with pytest.raises(PermissionDenied) as caught:
        reviewer.execute(packet.args, packet.ctx)
    assert "初審已保存" not in str(caught.value)
    assert len(sent) == 1
    assert initial_files(packet)["response.txt"] == packet.completion().text.encode()


def test_failed_initial_keeps_identity_and_cannot_be_reused(monkeypatch, packet):
    model = Mock(return_value=Completion(text="{broken", finish_reason="stop"))
    monkeypatch.setattr(reviewer, "complete_once", model)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert run_directory(packet).is_dir()
    assert not (run_directory(packet) / "initial").exists()
    with pytest.raises((ValueError, FileExistsError)):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("failed_name", ["arguments.json", "response.txt", "review.json"])
def test_partial_pending_write_never_commits_or_starts_second_stage(monkeypatch, packet, failed_name):
    original_open = Path.open
    def fail_write(path, mode="r", *args, **kwargs):
        if path.parent.name == ".initial.pending" and path.name == failed_name and mode == "xb":
            raise OSError("injected write failure")
        return original_open(path, mode, *args, **kwargs)
    monkeypatch.setattr(Path, "open", fail_write)
    sent = install_wire(monkeypatch, packet, [packet.completion().text])
    with pytest.raises(OSError, match="injected write failure"):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert run_directory(packet).is_dir()
    assert not (run_directory(packet) / "initial").exists()


def test_existing_initial_destination_is_not_overwritten(monkeypatch, packet):
    def collide(index, request):
        folder = run_directory(packet) / "initial"
        folder.mkdir()
        (folder / "retain.txt").write_bytes(b"existing bytes")
    sent = install_wire(monkeypatch, packet, [packet.completion().text], hook=collide)
    with pytest.raises(FileExistsError):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert (run_directory(packet) / "initial/retain.txt").read_bytes() == b"existing bytes"
    assert not (run_directory(packet) / "initial/review.json").exists()


def test_normal_two_stages_with_unspecified_temperature_need_no_capability_lookup(monkeypatch, packet):
    initial = packet.completion().text
    sent = install_wire(monkeypatch, packet, [initial, initial], capable=None, temperature=None)
    assert json.loads(reviewer.execute(packet.args, packet.ctx).output) == packet.value
    assert len(sent) == 2 and all(request.method == "POST" for request in sent)
    assert all("temperature" not in body(request) for request in sent)


def test_uncited_selected_source_is_rechecked_before_second_dispatch(monkeypatch, packet):
    extra = packet.save({"additional.txt": "Selected but not cited by initial review."})
    packet.args["files"].append(packet.locator(extra, "additional.txt"))
    original_save = reviewer._save_initial
    def mutate(*args, **kwargs):
        result = original_save(*args, **kwargs)
        selected = packet.snapshot(extra, "additional.txt")
        selected.write_bytes(b"X" * selected.stat().st_size)
        return result
    monkeypatch.setattr(reviewer, "_save_initial", mutate)
    sent = install_wire(monkeypatch, packet, [packet.completion().text])
    with pytest.raises(ValueError, match="snapshot changed"):
        reviewer.execute(packet.args, packet.ctx)
    assert len(sent) == 1
    assert initial_files(packet)["response.txt"] == packet.completion().text.encode()
