"""Research runner sampling, through config loading and offline HTTP encoding."""

import json
from copy import deepcopy
from pathlib import Path
import threading
from types import SimpleNamespace

import httpx
import pytest

from opencode import config as config_module
from opencode import provider as provider_module
from opencode.agent import build_agents
from opencode.config import load_config
from opencode.provider import Client
from researchkit import mindmap, mindmap_schema, review_provider


from scripts.llm_configuration import saved_llm_config
from tests import canonical_config as canonical
MODEL = canonical.model_name()
BASE_URL = "https://research-sampling.invalid/v1"


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Sampling tests must not use network, catalog, or saved credentials")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(provider_module, "_catalog_temperature", forbidden)
    for name in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_PERMISSION",
                 "OPENCODE_DISABLE_PROJECT_CONFIG", "OPENCODE_MODEL"):
        monkeypatch.delenv(name, raising=False)
    global_config, home = tmp_path / "global-config", tmp_path / "home"
    global_config.mkdir()
    home.mkdir()
    monkeypatch.setattr(config_module, "config_dir", lambda: global_config)
    monkeypatch.setattr(config_module, "home", lambda: home)
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(global_config))
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(home))
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-sampling-key")
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()  # Stop project config lookup before the real checkout.
    (root / "opencode.json").write_text(
        json.dumps(saved_llm_config(BASE_URL, MODEL)), encoding="utf-8"
    )
    return root, forbidden


def test_research_config_loads_only_existing_sampling_overrides(workspace):
    root, _ = workspace
    config = load_config(root)
    assert config == {
        "model": "local/" + MODEL,
        "provider": {"local": {
            "options": {"baseURL": BASE_URL, "apiKey": "offline-sampling-key"},
            "models": {MODEL: canonical.model_definition()},
        }},
        "agent": {name: {"temperature": value} for name, value in canonical.agent_temperatures().items()},
        "plugin": [],
    }
    agent = build_agents(config, worktree=root)["build"]
    assert agent.temperature == canonical.agent_temperature("build")
    assert agent.prompt is None


def test_load_config_validates_temperature_capability_type(workspace):
    root, _ = workspace
    config = saved_llm_config(BASE_URL, MODEL)
    config["provider"]["local"]["models"][MODEL]["temperature"] = 0
    (root / "opencode.json").write_text(json.dumps(config), encoding="utf-8")
    with pytest.raises(ValueError, match=r"temperature must be a boolean"):
        load_config(root)


@pytest.mark.parametrize("reasoning_effort", ["none", "medium"], ids=["fresh-default", "explicit-medium"])
@pytest.mark.parametrize("route", [
    "complete", "complete_stream", "review", "observation", "architecture", "deepening",
])
def test_sampling_reaches_serialized_request_without_added_prompt_or_tools(
    workspace, monkeypatch, route, reasoning_effort
):
    root, forbidden = workspace
    config = load_config(root)
    if reasoning_effort is not None:
        config["provider"]["local"]["models"][MODEL]["options"]["reasoningEffort"] = reasoning_effort
    agent = build_agents(config, worktree=root)["build"]
    client = Client(SimpleNamespace(get=forbidden), config)
    signal = threading.Event()
    sent, chunks = [], []
    system = "Offline transport test instructions."
    messages = [{"role": "user", "content": "Offline transport test input."}]
    original_messages = deepcopy(messages)

    async def receive(transport, request):
        assert request.method == "POST"
        assert str(request.url) == BASE_URL + "/chat/completions"
        assert request.headers["authorization"] == "Bearer offline-sampling-key"
        sent.append(json.loads(request.content))
        if route != "complete":
            event = {"choices": [{"delta": {"content": "offline reply"}, "finish_reason": "stop"}]}
            return httpx.Response(
                200, headers={"content-type": "text/event-stream"},
                content="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n",
            )
        return httpx.Response(200, json={
            "choices": [{"message": {"content": "offline reply"}, "finish_reason": "stop"}]
        })

    # Only HTTP is replaced: both _temperature and _openai execute unchanged.
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", receive)
    if route not in {"complete", "complete_stream"}:
        app = SimpleNamespace(
            provider=client,
            store=SimpleNamespace(get_session=lambda _: {"model": config["model"]}),
            abort_event=lambda _: signal,
        )
        ctx = SimpleNamespace(app=app, session_id="offline-session", agent=agent)
        if route == "review":
            result = review_provider.complete_once(ctx, system=system, messages=messages)
        else:
            result = mindmap._stage(
                ctx, route, messages[0]["content"], system, lambda text: text, frozen={}
            )
    else:
        provider, model = client.resolve(config["model"])
        result = client.complete(
            provider=provider, model=model, system=system, messages=messages,
            tools=[], temperature=agent.temperature, abort_event=signal,
            on_text=chunks.append if route == "complete_stream" else None,
        )

    expected = {
        "model": MODEL,
        "messages": [{"role": "system", "content": system}, *original_messages],
        "max_tokens": canonical.output_limit(),
        "temperature": canonical.agent_temperature("build"),
    }
    if reasoning_effort is not None:
        expected["reasoning_effort"] = reasoning_effort
    if route != "complete":
        expected.update(stream=True, stream_options={"include_usage": True})
    if route in {"observation", "architecture", "deepening"}:
        # Mind-map stages also constrain the reply to the stage schema.
        schema = {"observation": mindmap_schema.OBSERVATION_SCHEMA, "architecture": mindmap_schema.MAP_SCHEMA,
                  "deepening": mindmap_schema.EDITS_SCHEMA}[route]
        expected["response_format"] = {"type": "json_schema", "json_schema": {
            "name": "mindmap_" + route, "strict": True, "schema": review_provider.generation_schema(schema)}}
    if route == "complete_stream":
        assert chunks == ["offline reply"]
    else:
        assert chunks == []
    if canonical.seed() == "random":
        # A new seed for each request, as configured: its value cannot be expected, only that it is sent.
        for body in sent:
            assert isinstance(body.pop("seed"), int)
    elif canonical.seed() is not None:
        expected["seed"] = canonical.seed()
    assert sent == [expected]
    assert messages == original_messages
    if route in {"observation", "architecture", "deepening"}:
        assert result == "offline reply"
    else:
        assert result.text == "offline reply"
        assert result.finish_reason == "stop"
        assert result.tool_calls == []
    assert not signal.is_set()
    assert not any(t.name in {"opencode-provider-request", "researchkit-review-deadline"}
                   for t in threading.enumerate())
