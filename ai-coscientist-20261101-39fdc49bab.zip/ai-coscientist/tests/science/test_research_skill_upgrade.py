"""Hash-authorized research installation, without model or network calls."""

import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout

import researchkit
from scripts import setup_research_workspace as setup


class ResearchSkillUpgrade(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.workspace = self.root / "workspace"
        self.sources = Path(researchkit.__file__).parent / "skills"
        self.report = "scientific-report-writer/SKILL.md"
        self.reference = "scientific-report-writer/references/report-delivery.md"

    def file(self, relative, content):
        path = self.workspace / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def old_guidance(self):
        """Two distinct unchanged prior files exercise all-or-nothing checks."""
        manifest = {}
        for relative in (self.report, self.reference):
            content = ("Previously installed " + relative + "\n").encode()
            self.file(".opencode/skills/" + relative, content)
            manifest["src/researchkit/skills/" + relative] = hashlib.sha256(content).hexdigest()
        return manifest

    def snapshot(self):
        if not self.workspace.exists():
            return None
        return {path.relative_to(self.workspace).as_posix(): path.read_bytes() if path.is_file() else None
                for path in self.workspace.rglob("*")}

    def assert_rejected_without_writes(self, action, pattern=None):
        before = self.snapshot()
        with self.assertRaisesRegex((ValueError, OSError), pattern or ".*"):
            action()
        self.assertEqual(self.snapshot(), before)

    def test_fresh_install_and_repetition_preserve_unrelated_content_and_return_none(self):
        root_config = self.file("opencode.jsonc", b'// keep comments\n{"model":"local/model"}')
        custom_skill = self.file(".opencode/skills/user-skill/SKILL.md", b"User-owned guidance")
        project_config = self.file(".opencode/opencode.json", b'{"steps":33,"instructions":["custom.md"]}')
        original = (root_config.read_bytes(), custom_skill.read_bytes())
        self.assertIsNone(setup.install(self.workspace))
        before = self.snapshot()
        self.assertIsNone(setup.install(self.workspace))
        self.assertEqual(self.snapshot(), before)
        self.assertEqual((root_config.read_bytes(), custom_skill.read_bytes()), original)
        config = json.loads(project_config.read_bytes())
        self.assertEqual(config["steps"], 33)
        self.assertEqual(config["instructions"], ["custom.md", ".opencode/skills/research-practice/SKILL.md"])
        for source in self.sources.rglob("*"):
            if source.is_file():
                installed = self.workspace / ".opencode/skills" / source.relative_to(self.sources)
                self.assertEqual(installed.read_bytes(), source.read_bytes())

    def test_trusted_upgrade_new_files_and_repetition(self):
        manifest = self.old_guidance()
        self.assertIsNone(setup.install(self.workspace, manifest))
        for relative in (self.report, self.reference):
            self.assertEqual((self.workspace / ".opencode/skills" / relative).read_bytes(),
                             (self.sources / relative).read_bytes())
        before = self.snapshot()
        self.assertIsNone(setup.install(self.workspace, manifest))
        # Once installed, current files do not need old entries to be written again.
        self.assertIsNone(setup.install(self.workspace, {}))
        self.assertEqual(self.snapshot(), before)

    def test_edited_or_untrusted_file_blocks_every_other_update(self):
        manifest = self.old_guidance()
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace), "refusing silent replacement")
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace, {}), "Missing previous hash")
        self.file(".opencode/skills/" + self.reference, b"User-edited reference")
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest), "edited; refusing replacement")

    def test_invalid_parsed_manifests_fail_before_writing(self):
        for manifest in ([], "text", {"src/file.py": "bad"}, {"src/file.py": 12},
                         {"src/file.py": "z" * 64}, {1: "a" * 64}, {"": "a" * 64}):
            with self.subTest(manifest=manifest):
                self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest), "manifest")

    def test_cli_rejects_missing_or_invalid_manifest_before_writing(self):
        manifest_path = self.root / "runtime-manifest.json"
        argv = [str(self.workspace), "--previous-manifest", str(manifest_path)]
        self.assert_rejected_without_writes(lambda: setup.main(argv))
        for content in ("{", "[]", "null", '{"src/file.py":"bad"}'):
            with self.subTest(content=content):
                manifest_path.write_text(content, encoding="utf-8")
                self.assert_rejected_without_writes(lambda: setup.main(argv))

    def test_cli_loads_saved_manifest_for_authorized_upgrade(self):
        manifest_path = self.root / "runtime-manifest.json"
        manifest_path.write_text(json.dumps(self.old_guidance()), encoding="utf-8")
        with redirect_stdout(io.StringIO()):
            setup.main([str(self.workspace), "--previous-manifest", str(manifest_path)])
        self.assertEqual((self.workspace / ".opencode/skills" / self.report).read_bytes(),
                         (self.sources / self.report).read_bytes())

    def test_config_plugin_and_backup_errors_leave_no_partial_upgrade(self):
        manifest = self.old_guidance()
        for config in (b"{", b"[]", b'{"instructions":true}', b'{"instructions":[3]}'):
            with self.subTest(config=config):
                path = self.file(".opencode/opencode.json", config)
                self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest))
                path.unlink()
        plugin = self.file(".opencode/tools/research.py", b"User-owned plugin")
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest), "Existing plugin differs")
        plugin.write_bytes(b"from researchkit.tools import TOOLS\n")
        self.file(".opencode/tools/research.py.pre-turn-extension.bak", b"Other backup")
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest), "backup differs")

    def test_existing_plugin_upgrade_keeps_original_backup_format(self):
        old_content = b"from researchkit.tools import TOOLS\n"
        plugin = self.file(".opencode/tools/research.py", old_content)
        setup.install(self.workspace)
        self.assertEqual(plugin.read_bytes(), b"from researchkit.tools import TOOLS, TURN_EXTENSION\n")
        self.assertEqual(plugin.with_suffix(".py.pre-turn-extension.bak").read_bytes(), old_content)
        before = self.snapshot()
        setup.install(self.workspace)
        self.assertEqual(self.snapshot(), before)

    def test_validation_rejects_file_in_place_of_destination_directory(self):
        manifest = self.old_guidance()
        self.file(".opencode/tools", b"This is a file, not the plugin directory")
        self.assert_rejected_without_writes(lambda: setup.install(self.workspace, manifest), "not a directory")

    def test_edit_between_preflight_and_apply_prevents_all_writes(self):
        for index, relative in enumerate((".opencode/skills/" + self.report, ".opencode/opencode.json",
                                           ".opencode/tools/research.py", ".opencode/tools/research.py.pre-turn-extension.bak",
                                           ".opencode/skills/materializer/SKILL.md")):
            with self.subTest(relative=relative):
                self.workspace = self.root / f"workspace-{index}"
                manifest = self.old_guidance()
                self.file(".opencode/tools/research.py", b"from researchkit.tools import TOOLS\n")
                _, apply = setup._prepare_install(self.workspace, manifest)
                # Existing files may be edited; absent destinations may appear
                # while the runner creates its baseline. Neither can be replaced.
                self.file(relative, b"An intervening user edit")
                self.assert_rejected_without_writes(apply, "changed after validation")

    def test_saved_v3_exact_bytes_upgrade_in_an_isolated_workspace(self):
        project = Path(__file__).resolve().parents[2]
        run = project / "outputs/lit_report_delivery_20261021_v3"
        manifest_path = run / "runtime-manifest.json"
        if not manifest_path.is_file():
            self.skipTest("Saved local v3 evidence is not present in this checkout")
        saved_skills = run / "baseline/workspace/.opencode/skills"
        manifest_bytes = manifest_path.read_bytes()
        manifest = setup.load_previous_manifest(manifest_path)
        saved = {path.relative_to(saved_skills): path.read_bytes() for path in saved_skills.rglob("*.md")}
        self.assertIn(Path(self.report), saved)
        self.assertIn(Path(self.reference), saved)
        for relative, content in saved.items():
            self.assertEqual(hashlib.sha256(content).hexdigest(),
                             manifest["src/researchkit/skills/" + relative.as_posix()])
            self.file(".opencode/skills/" + relative.as_posix(), content)
        self.assertNotEqual(saved[Path(self.report)], (self.sources / self.report).read_bytes())
        self.assertIsNone(setup.install(self.workspace, manifest))
        for source in self.sources.rglob("*.md"):
            self.assertEqual((self.workspace / ".opencode/skills" / source.relative_to(self.sources)).read_bytes(),
                             source.read_bytes())
        self.assertEqual(manifest_path.read_bytes(), manifest_bytes)
        self.assertEqual({path.relative_to(saved_skills): path.read_bytes() for path in saved_skills.rglob("*.md")}, saved)


if __name__ == "__main__":
    unittest.main()
