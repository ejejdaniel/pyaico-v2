"""Deterministic research-extension tests, with no live model or web requests."""

from __future__ import annotations

import importlib.util
import io
import json
import math
import os
import re
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from contextlib import contextmanager, redirect_stdout
from unittest.mock import patch

import httpx

from opencode.app import App
from opencode import cli
from opencode.loop import ToolContext
from opencode.store import Store
from opencode.provider import Completion, ToolCall
from opencode.tools.files import _read
from researchkit import literature, records, report_evidence, scoring
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install
from tests.prompt_view import host_facts, plain_messages


@contextmanager
def native_web_response(response):
    original = httpx.AsyncClient
    with patch("opencode.tools.web.httpx.AsyncClient", side_effect=lambda **kwargs: original(
            transport=httpx.MockTransport(lambda request: response), **kwargs)):
        yield


class ResearchTools(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".git").mkdir()
        env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"), "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_CONFIG_HOME": str(self.root / "global-config"),
            "XDG_DATA_HOME": str(self.root / "data"), "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        env.start()
        self.addCleanup(env.stop)
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)

    def ctx(self):
        install(self.workspace)
        app = App(self.workspace, store=self.store, auto_approve=True, config={})
        session = app.create_session()
        return ToolContext(app, session["id"], app.agents["build"], "m", "c", 0,
                           self.workspace, self.workspace, set(), 1)

    def file(self, name, text):
        path = self.workspace / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        return path

    def tool(self, name, args, ctx=None):
        return next(t for t in TOOLS if t.name == name).execute(args, ctx or self.ctx())

    def test_pack_loads_only_in_installed_workspace(self):
        plain = App(self.workspace, store=self.store, config={})
        self.assertFalse(plain.extra_tools)
        ctx = self.ctx()
        self.assertEqual({t.name for t in ctx.app.extra_tools}, {t.name for t in TOOLS})
        self.assertIn("materializer", ctx.app.skills)
        self.assertIn("problem-formulation", ctx.app.skills)
        # skill/index.ts discovers explicit installations, not local science assets.
        self.assertEqual(set(plain.skills), set())
        self.assertEqual(len(set(ctx.app.skills) - set(plain.skills)), 13)  # includes research-judge, simulation

    def test_install_does_not_overwrite_edited_skill(self):
        install(self.workspace)
        path = self.workspace / ".opencode/skills/materializer/SKILL.md"
        path.write_text("local changes", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "refusing silent replacement"):
            install(self.workspace)
        self.assertEqual(path.read_text(), "local changes")

    def test_installed_homepage_reaches_actual_prompt_and_refreshes_on_continuation(self):
        from opencode.config import load_config
        root_config = self.file("opencode.jsonc", '// keep comments\n{"instructions": ["custom.md"]}')
        self.file("custom.md", "Existing project instruction")
        project_config = self.file(".opencode/opencode.json", '{"steps": 33, "instructions": ["custom.md"]}')
        original_config = root_config.read_bytes()
        install(self.workspace)
        install(self.workspace)
        self.assertEqual(root_config.read_bytes(), original_config)
        self.assertEqual(json.loads(project_config.read_text())["steps"], 33)
        config = load_config(self.workspace)
        self.assertEqual(config["instructions"].count(".opencode/skills/research-practice/SKILL.md"), 1)
        app = App(self.workspace, store=self.store, config=config)
        app.generate_titles = False
        sid = app.create_session()["id"]
        original = self.store.add_message(sid, "user", {"content": "ORIGINAL_COMMISSION"})
        summary = self.store.commit_compaction(sid, original["id"], "SAVED_SUMMARY_WITH_LATER_CHANGES")
        todos = [{"id": "done", "content": "NARROW_COMPLETED_TODO", "status": "completed", "priority": "medium"}]
        self.store.set_todos(sid, todos)
        homepage = self.workspace / ".opencode/skills/research-practice/SKILL.md"
        captured = []
        app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
            complete=lambda **kw: (captured.append(kw) or Completion(text="Partial result", finish_reason='stop')))
        app.prompt(sid, "Continue")
        self.assertIn(homepage.read_text(encoding="utf-8"), captured[0]["system"])
        self.assertIn("Continuation and completion", captured[0]["system"])
        self.assertIn("Existing project instruction", captured[0]["system"])
        self.assertIn("SAVED_SUMMARY_WITH_LATER_CHANGES", json.dumps(captured[0]["messages"]))
        # Source todo.ts persists state; session prompt does not inject a projection.
        self.assertNotIn("NARROW_COMPLETED_TODO", json.dumps(captured[0]["messages"]))
        self.assertEqual(self.store.todos(sid), todos)
        homepage.write_text(homepage.read_text(encoding="utf-8") + "\nUPDATED_GUIDANCE\n", encoding="utf-8")
        app.prompt(sid, "Continue again")
        self.assertNotIn("UPDATED_GUIDANCE", captured[0]["system"])
        self.assertIn("UPDATED_GUIDANCE", captured[1]["system"])
        self.assertIn("UPDATED_GUIDANCE", app.skills["research-practice"].body)
        self.assertEqual(len(captured), 2)
        for request, current in zip(captured, ("Continue", "Continue again")):
            self.assertNotIn("ORIGINAL_COMMISSION", json.dumps(request["messages"]))
            self.assertIn({"role": "assistant", "content": summary["content"]}, request["messages"])
            self.assertNotIn("NARROW_COMPLETED_TODO", json.dumps(request["messages"]))
            self.assertEqual(plain_messages(request["messages"])[-1], {"role": "user", "content": current})
        self.assertEqual(self.store.messages(sid)[0]["content"], original["content"])
        self.assertEqual(self.store.todos(sid), todos)

    def test_refresh_does_not_refetch_remote_instructions_or_keep_deleted_local_file(self):
        from opencode.instructions import collect
        local = self.file("local.md", "local version one")
        config = {"instructions": ["local.md", "https://example.invalid/instructions"]}
        with patch("opencode.instructions._fetch", return_value="remote text") as fetch:
            first = collect(self.workspace, self.workspace, config)
            local.write_text("local version two", encoding="utf-8")
            second = collect(self.workspace, self.workspace, config, previous=first)
            self.assertIn((str(local), "local version two"), second)
            local.unlink()
            third = collect(self.workspace, self.workspace, config, previous=second)
            self.assertFalse(any(p == str(local) for p, _ in third))
            self.assertIn(("https://example.invalid/instructions", "remote text"), third)
            fetch.assert_called_once()

    def test_continuation_guidance_upgrade_requires_original_baseline(self):
        from scripts.setup_research_workspace import upgrade_test_guidance
        project = self.root / "project"
        source = project / "src/researchkit/skills/example/SKILL.md"
        source.parent.mkdir(parents=True)
        source.write_text("new guidance", encoding="utf-8")
        installed = self.file(".opencode/skills/example/SKILL.md", "old guidance")
        manifest = {"src/researchkit/skills/example/SKILL.md": records.digest(installed.read_bytes())}
        upgrade_test_guidance(self.workspace, project, manifest)
        self.assertEqual(installed.read_text(), "new guidance")
        installed.write_text("user edits", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "refusing replacement"):
            upgrade_test_guidance(self.workspace, project, manifest)
        self.assertEqual(installed.read_text(), "user edits")

    def test_research_runner_uses_the_configured_build_sampling(self):
        from scripts.llm_configuration import saved_llm_config
        from opencode.provider import Client
        from tests import canonical_config as canonical
        config = saved_llm_config("http://localhost:8000/v1", canonical.model_name())
        app = App(self.workspace, store=self.store, config=config)
        for name in ("build", "general", "explore", "compaction"):
            self.assertEqual(app.agents[name].temperature, canonical.agent_temperature(name))
        client = Client(None, config)
        captured = []
        with patch.object(client, "_openai_stream", side_effect=lambda u, h, b, *a, **kw: captured.append(b) or Completion(finish_reason='stop')):
            client._openai(client.providers["local"], "not-sent", canonical.model_name(), "system", [], [],
                           app.agents["build"].temperature, lambda _: None)
        self.assertEqual(captured[0]["temperature"], canonical.agent_temperature("build"))
        self.assertEqual(captured[0]["reasoning_effort"], canonical.reasoning_effort())
        self.assertEqual(captured[0]["max_tokens"], canonical.output_limit())

    def test_broken_plugin_is_not_silently_ignored(self):
        self.file(".opencode/tools/bad.py", "raise ImportError('missing_optional_package')")
        with self.assertRaisesRegex(RuntimeError, "bad.py.*missing_optional_package"):
            App(self.workspace, store=self.store, config={})

    def test_native_loop_can_use_skill_publish_and_read_exact_snapshot(self):
        ctx = self.ctx()
        app = ctx.app
        app.generate_titles = False
        source = self.file("actual.md", "the calculated result with its limitations")
        calls = []
        self_test = self

        class Provider:
            def resolve(self, model=None):
                return SimpleNamespace(id="test", context=131072), "test"
            def complete(self, **kwargs):
                calls.append(kwargs)
                turn = len(calls)
                if turn == 1:
                    return Completion(tool_calls=[ToolCall("s", "skill", {"name": "materializer"})], finish_reason='tool-calls')
                if turn == 2:
                    return Completion(tool_calls=[ToolCall("r", "research_record", {
                        "kind": "implementation", "title": "Test result", "files": [str(source)]})], finish_reason='tool-calls')
                if turn == 3:
                    presented = plain_messages(kwargs["messages"])[-1]["content"]
                    # message-v2.ts forwards the tool output without a local receipt prefix.
                    receipt = json.loads(presented)
                    saved = Path(receipt["record_path"]).parent / receipt["files"][0]["snapshot"]
                    return Completion(tool_calls=[ToolCall("b", "read", {"filePath": str(saved)})], finish_reason='tool-calls')
                return Completion(text="Finished with exact recorded evidence.", finish_reason='stop')

        app.provider = Provider()
        result = app.prompt(ctx.session_id, "Use the already computed file and preserve its evidence.")
        self.assertEqual(result["status"], "completed")
        presented = json.dumps(calls[-1]["messages"])
        self.assertIn("the calculated result with its limitations", presented)
        self.assertIn("materializer", presented)
        self.assertEqual(len(records.inventory(self.workspace)), 1)

    def test_review_error_returns_to_native_loop_without_repeating_completed_work(self):
        ctx = self.ctx()
        app = ctx.app
        app.generate_titles = False
        self.file("result.md", "Measured result with stated limitations.")
        source = records.publish(self.workspace, kind="result", title="Retained",
                                 files=["result.md"], depends_on=[])
        self.file("old-review.md", "Previous unstructured notes")
        review = {
            "reviewed_refs": [source["record_path"]],
            "checks": [{"subject": {"record_ref": source["record_path"], "source_path": "result.md",
                                    "quote": "Measured result with stated limitations."},
                        "evidence": [], "decision": "unassessed", "reason": "Further evidence missing."}]
        }
        frozen = {p: p.read_bytes() for p in (self.workspace / ".research/records").rglob("*") if p.is_file()}
        calls = []
        def complete(**kwargs):
            calls.append(kwargs)
            turn = len(calls)
            if turn == 1:
                return Completion(tool_calls=[ToolCall("old", "research_record", {
                    "kind": "review", "title": "Audit", "files": ["old-review.md"],
                    "depends_on": [source["record_path"]]})], finish_reason='tool-calls')
            if turn == 2:
                self.assertIn("explicitly select exactly one review.json", plain_messages(kwargs["messages"])[-1]["content"])
                return Completion(tool_calls=[ToolCall("write", "write", {
                    "filePath": str(self.workspace / "audit/review.json"), "content": json.dumps(review)})], finish_reason='tool-calls')
            if turn == 3:
                return Completion(tool_calls=[ToolCall("new", "research_record", {
                    "kind": "review", "title": "Audit", "files": ["audit/review.json"],
                    "depends_on": [source["record_path"]]})], finish_reason='tool-calls')
            return Completion(text="The selected claim remains unassessed; no new calculation was done.", finish_reason='stop')
        app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                       complete=complete)
        self.assertEqual(app.prompt(ctx.session_id, "Review the saved result.")["status"], "completed")
        self.assertEqual(len(calls), 4)
        self.assertEqual(frozen, {p: p.read_bytes() for p in frozen})
        self.assertEqual(len(records.inventory(self.workspace)), 2)
        history = self.store.messages(ctx.session_id)
        self.assertEqual([m["name"] for m in history if m["role"] == "tool"],
                         ["research_record", "write", "research_record"])

    def test_plain_completion_does_not_synthesize_a_review_or_scientific_acceptance(self):
        ctx = self.ctx()
        ctx.app.generate_titles = False
        ctx.app.provider = SimpleNamespace(
            resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
            complete=lambda **kwargs: Completion(text="All checked, done.", finish_reason='stop'))
        reply = ctx.app.prompt(ctx.session_id, "Inspect the available records.")
        self.assertEqual(reply["status"], "completed")
        self.assertEqual(records.inventory(self.workspace), [])

    def test_record_versions_keep_original_files_and_dependencies(self):
        ctx = self.ctx()
        self.file("study/formula.md", "original formula")
        first = json.loads(self.tool("research_record", {"kind": "formula", "title": "Method", "files": ["study/formula.md"]}, ctx).output)
        self.file("study/formula.md", "revised formula")
        second = json.loads(self.tool("research_record", {"kind": "formula", "title": "Method revised", "files": ["study/formula.md"],
                                                       "depends_on": [first["record_path"]]}, ctx).output)
        self.assertNotEqual(first["record_path"], second["record_path"])
        saved = self.workspace / Path(first["record_path"]).parent / first["files"][0]["snapshot"]
        self.assertIn("original formula", _read({"filePath": str(saved)}, ctx).output)
        self.assertEqual(records.read_record(self.workspace, second["record_path"])["depends_on"], [first["record_path"]])
        self.assertEqual(len(json.loads(self.tool("research_list", {}, ctx).output)), 2)

    def test_mixed_source_receipts_publish_and_reach_downstream_after_restart(self):
        self._mixed_source_receipts(first="websearch")

    def test_mixed_source_receipts_also_preserve_identity_when_paper_finishes_first(self):
        self._mixed_source_receipts(first="paper_search")

    def _mixed_source_receipts(self, first):
        ctx = self.ctx()
        app = ctx.app
        app.generate_titles = False
        seen = {}
        raw = {"message": {"items": [{"title": ["Provider-only source"],
               "URL": "https://example.org/provider"}]}}
        response = httpx.Response(200, json=raw, request=httpx.Request("GET", "https://api.crossref.org/works"))
        # read.ts offers line paging, not local character-offset continuation.
        source_text = "WEB_ONLY_EVIDENCE\n" + "long passage\n" * 10000 + "END_OF_SOURCE"
        test = self

        def publish_sources(**kwargs):
            saved = [m for m in self.store.messages(ctx.session_id) if m["role"] == "tool"]
            test.assertEqual([m["name"] for m in saved], [first, "paper_search" if first == "websearch" else "websearch"])
            by_name = {m["name"]: m for m in saved}
            test.assertEqual(set(by_name), {"paper_search", "websearch"})
            test.assertEqual(by_name["paper_search"]["tool_call_id"], "p")
            test.assertEqual(by_name["websearch"]["tool_call_id"], "w")
            index = self.store.source_index_path(ctx.session_id)
            test.assertIn(str(index), host_facts(kwargs))
            test.assertIn("paper_search: 1", index.read_text(encoding="utf-8"))
            test.assertIn("websearch: 1", index.read_text(encoding="utf-8"))
            receipts = [index.parent / (m["id"] + ".json") for m in saved]
            provider_file = next((self.workspace / ".research/searches").glob("*.json"))
            test.assertNotIn("WEB_ONLY_EVIDENCE", provider_file.read_text(encoding="utf-8"))
            links = [p.relative_to(self.workspace).as_posix() for p in receipts]
            self.file("synthesis.md", "# Interpretation\n\n" + "\n".join(f"Source: `{m['id']}`" for m in saved))
            web_receipt = index.parent / (by_name["websearch"]["id"] + ".json")
            web_receipt.write_text("tampered source projection before publication", encoding="utf-8")
            seen.update(receipts=receipts, saved=saved, links=links, by_name=by_name,
                        web_link=web_receipt.relative_to(self.workspace).as_posix())
            return Completion(tool_calls=[ToolCall("publish", "research_record", {
                "kind": "literature", "title": "Mixed-source synthesis",
                "files": ["synthesis.md"],
            })], finish_reason='tool-calls')

        replies = [Completion(tool_calls=[
            ToolCall("p", "paper_search", {"query": "provider question", "provider": "crossref"}),
            ToolCall("w", "websearch", {"query": "alternate question", "numResults": 2}),
        ], finish_reason='tool-calls'), publish_sources, Completion(text="Source files preserved.", finish_reason='stop')]
        def complete(**kwargs):
            item = replies.pop(0)
            return item(**kwargs) if callable(item) else item
        app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                       complete=complete)
        search_response = httpx.Response(200, json={"result": {"content": [{"type": "text", "text": source_text}]}},
                                        request=httpx.Request("POST", "https://mcp.exa.ai/mcp"))
        first_saved = threading.Event()
        add_message = self.store.add_message
        def save_message(session_id, role, data):
            saved = add_message(session_id, role, data)
            if role == "tool" and data.get("name") == first:
                first_saved.set()
            return saved
        def reply_after_first(name, value):
            if name != first:
                self.assertTrue(first_saved.wait(5), "The other source must commit before this response completes")
            return value
        with patch("researchkit.literature.httpx.Client") as client, \
             patch("opencode.tools.web.httpx.AsyncClient") as web_client, \
             patch.dict(os.environ, {"OPENCODE_WEBSEARCH_PROVIDER": "exa", "OPENCODE_ENABLE_EXA": "true"}), \
             patch.object(self.store, "add_message", side_effect=save_message):
            client.return_value.__enter__.return_value.get.side_effect = lambda *a, **kw: reply_after_first("paper_search", response)
            web_client.return_value.__aenter__.return_value.post.side_effect = lambda *a, **kw: reply_after_first("websearch", search_response)
            self.assertEqual(app.prompt(ctx.session_id, "Save the sources used in this synthesis.")["status"], "completed")
            self.assertEqual(web_client.return_value.__aenter__.return_value.post.call_count, 1)
            self.assertEqual(client.return_value.__enter__.return_value.get.call_count, 1)

        record = records.inventory(self.workspace)[0]
        self.assertEqual(len(record["files"]), 5)
        record_path = self.workspace / record["record_path"]
        frozen = {p: p.read_bytes() for p in record_path.parent.rglob("*") if p.is_file()}
        history = self.store.messages(ctx.session_id)
        self.store.commit_compaction(ctx.session_id, history[-1]["id"], "Only a short interpretation remains.")
        for receipt in seen["receipts"]:
            receipt.write_text("edited mutable projection", encoding="utf-8")
        web_reply = seen["by_name"]["websearch"]
        self.assertTrue(web_reply["metadata"]["truncated"])
        Path(web_reply["metadata"]["outputPath"]).unlink()
        self.file("synthesis.md", "new, unrecorded interpretation")

        reopened = Store(self.store.path)
        try:
            from opencode.tools import builtin_tools
            from opencode.tools.types import external_source_names
            reopened.export_tool_history(ctx.session_id, source_tools=external_source_names([*builtin_tools(), *TOOLS]))
            for receipt, saved in zip(seen["receipts"], seen["saved"]):
                self.assertEqual(json.loads(receipt.read_text(encoding="utf-8"))[-1], saved)
                receipt.unlink()
            consumer = App(self.workspace, store=reopened, config={}, auto_approve=True)
            consumer.generate_titles = False
            sid = consumer.create_session()["id"]
            observed = []
            def consume(**kwargs):
                observed.append(kwargs)
                if len(observed) == 1:
                    return Completion(tool_calls=[ToolCall("manifest", "read", {"filePath": str(record_path)})], finish_reason='tool-calls')
                if len(observed) == 2:
                    numbered = plain_messages(kwargs["messages"])[-1]["content"]
                    manifest = json.loads("\n".join(re.findall(r"^\d+: (.*)$", numbered, re.M)))
                    text_link = str(Path(seen["web_link"]).with_suffix(".txt")).replace("\\", "/")
                    item = next(f for f in manifest["files"] if f["source_path"] == text_link)
                    seen["snapshot"] = record_path.parent / item["snapshot"]
                    return Completion(tool_calls=[ToolCall("source", "read", {"filePath": str(seen["snapshot"])})], finish_reason='tool-calls')
                content = plain_messages(kwargs["messages"])[-1]["content"]
                continuation = re.search(r"Use offset=(\d+) to continue", content)
                if continuation:
                    return Completion(tool_calls=[ToolCall(f"page-{len(observed)}", "read", {
                        "filePath": str(seen["snapshot"]), "offset": int(continuation.group(1)),
                    })], finish_reason='tool-calls')
                return Completion(text="Read the recorded source, not the revised synthesis.", finish_reason='stop')
            consumer.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"), complete=consume)
            self.assertEqual(consumer.prompt(sid, f"Inspect sources in {record_path}")["status"], "completed")
            presented = "\n".join(plain_messages(turn["messages"])[-1]["content"] for turn in observed[2:])
            self.assertIn("WEB_ONLY_EVIDENCE", presented)
            self.assertIn("END_OF_SOURCE", presented)
            self.assertGreater(len(observed), 4)
            lines = [line for turn in observed[2:] for line in re.findall(r"^(\d+): (.*)$", plain_messages(turn["messages"])[-1]["content"], re.M)]
            self.assertEqual([int(number) for number, _ in lines], list(range(1, 10003)))
            self.assertEqual("\n".join(value for _, value in lines), source_text)
            self.assertEqual(seen["snapshot"].read_bytes(), source_text.encode("utf-8"))
            for name, call_id, arguments in (
                ("paper_search", "p", {"query": "provider question", "provider": "crossref"}),
                ("websearch", "w", {"query": "alternate question", "numResults": 2}),
            ):
                reply = seen["by_name"][name]
                link = (self.store.source_index_path(ctx.session_id).parent / (reply["id"] + ".json")).relative_to(self.workspace).as_posix()
                item = next(f for f in record["files"] if f["source_path"] == link)
                source = json.loads((record_path.parent / item["snapshot"]).read_text(encoding="utf-8"))
                self.assertEqual(source[0]["tool_calls"], [{"id": call_id, "name": name, "arguments": arguments}])
                self.assertEqual(source[1], reply)
                text_link = Path(link).with_suffix(".txt").as_posix()
                text_item = next(f for f in record["files"] if f["source_path"] == text_link)
                expected = source_text if name == "websearch" else reply["content"]
                self.assertEqual((record_path.parent / text_item["snapshot"]).read_bytes(), expected.encode("utf-8"))
            self.assertEqual(frozen, {p: p.read_bytes() for p in frozen})
            self.assertEqual(len(records.inventory(self.workspace)), 1)
        finally:
            reopened.close()

    def test_record_repetition_reuses_same_exact_version(self):
        self.file("a.txt", "unchanged")
        args = dict(kind="notes", title="A", files=["a.txt"], depends_on=[])
        self.assertEqual(records.publish(self.workspace, **args), records.publish(self.workspace, **args))
        self.assertEqual(len(records.inventory(self.workspace)), 1)

    def test_dependency_drift_is_visible_but_does_not_rewrite_or_reject_history(self):
        ctx = self.ctx()
        formula = self.file("formula.md", "x + y")
        old = records.publish(self.workspace, kind="formula", title="Formula", files=["formula.md"], depends_on=[])
        original = (self.workspace / old["record_path"]).read_bytes()
        formula.write_text("x + 2*y", encoding="utf-8")
        self.file("main.py", "result = x + 2*y")
        implementation = json.loads(self.tool("research_record", {
            "kind": "implementation", "title": "Calculation", "files": ["main.py"],
            "depends_on": [old["record_path"]]}, ctx).output)
        # The receipt names the record and file; research_list keeps the hashes and snapshot path.
        self.assertEqual(implementation["workspace_differences"],
                         [{"record_path": old["record_path"], "source_path": "formula.md", "status": "changed"}])
        change, = records.workspace_differences(self.workspace, [old["record_path"]])
        self.assertEqual(change["working_sha256"], records.digest(formula.read_bytes()))
        self.assertEqual((self.workspace / change["snapshot_path"]).read_text(), "x + y")
        self.assertIn("Intentional use of historical versions is valid", implementation["dependency_notice"])
        self.assertNotIn("workspace_differences", records.read_record(self.workspace, implementation["record_path"]))
        self.assertEqual((self.workspace / old["record_path"]).read_bytes(), original)

        # An indirect selected reference must still expose the original mismatch.
        self.file("report.md", "Calculation report")
        report = json.loads(self.tool("research_record", {
            "kind": "report", "title": "Report", "files": ["report.md"],
            "depends_on": [implementation["record_path"], old["record_path"]]}, ctx).output)
        self.assertEqual(len(report["workspace_differences"]), 1)
        listed = json.loads(self.tool("research_list", {}, ctx).output)
        self.assertEqual(next(r for r in listed if r["record_path"] == old["record_path"])["workspace_differences"], [change])

        # Author-selected revised inputs remove the mismatch without executing code.
        revised = records.publish(self.workspace, kind="formula", title="Revision", files=["formula.md"], depends_on=[])
        fixed = json.loads(self.tool("research_record", {
            "kind": "implementation", "title": "Calculation", "files": ["main.py"],
            "depends_on": [revised["record_path"]]}, ctx).output)
        self.assertNotIn("workspace_differences", fixed)
        formula.unlink()
        self.assertEqual(records.workspace_differences(self.workspace, [revised["record_path"]])[0]["status"], "missing")

    def test_workspace_comparison_checks_read_permission_before_current_bytes(self):
        self.file("private.txt", "source")
        saved = records.publish(self.workspace, kind="data", title="Input", files=["private.txt"], depends_on=[])
        checked = []
        def authorize(path):
            checked.append(path)
            if path == self.workspace / "private.txt":
                raise PermissionError("not authorized")
        with self.assertRaisesRegex(PermissionError, "not authorized"):
            records.workspace_differences(self.workspace, [saved["record_path"]], check_read=authorize)
        self.assertEqual(checked, [self.workspace / saved["record_path"],
                                  self.workspace / Path(saved["record_path"]).parent / saved["files"][0]["snapshot"],
                                  self.workspace / "private.txt"])

    def test_new_formula_beside_old_calculation_does_not_hide_ancestor_warning(self):
        ctx = self.ctx()
        formula = self.file("formula.md", "original specification")
        old = records.publish(self.workspace, kind="formula", title="Original", files=["formula.md"], depends_on=[])
        self.file("result.csv", "id,value\na,1\n")
        calculation = records.publish(self.workspace, kind="calculation", title="Recorded run", files=["result.csv"],
                                      depends_on=[old["record_path"]])
        formula.write_text("revised specification", encoding="utf-8")
        new = records.publish(self.workspace, kind="formula", title="Revised", files=["formula.md"], depends_on=[])
        self.file("report.md", "Use compatible calculations")
        receipt = json.loads(self.tool("research_record", {
            "kind": "report", "title": "Report", "files": ["report.md"],
            "depends_on": [calculation["record_path"], new["record_path"]]}, ctx).output)
        self.assertEqual([d["record_path"] for d in receipt["workspace_differences"]], [old["record_path"]])
        short = lambda saved: saved["record_path"].split("/")[2][:8]
        expected_path = (f"report {short(receipt)} -> calculation {short(calculation)} "
                         f"-> formula {short(old)} -> formula.md (changed)")
        self.assertIn(expected_path, receipt["dependency_notice"])
        self.assertNotIn(f"formula {short(new)} ->", receipt["dependency_notice"])
        self.assertNotIn("dependency_notice", records.read_record(self.workspace, receipt["record_path"]))
        self.assertEqual(records.read_record(self.workspace, calculation["record_path"])["depends_on"], [old["record_path"]])
        self.assertEqual(records.read_record(self.workspace, receipt["record_path"])["depends_on"],
                         [calculation["record_path"], new["record_path"]])

    def test_research_list_shows_direct_reverse_dependencies_without_selecting_a_version(self):
        ctx = self.ctx()
        self.file("formula.md", "expression")
        formula = records.publish(self.workspace, kind="formula", title="Formula", files=["formula.md"], depends_on=[])
        self.file("values.csv", "id,value\na,1\n")
        self.assertEqual(records.direct_dependents([{
            "record_path": "calc", "kind": "calculation", "depends_on": ["formula", "formula"],
        }]), {"formula": [{"record_path": "calc", "kind": "calculation"}]})
        calculation = records.publish(self.workspace, kind="calculation", title="Calculation", files=["values.csv"],
                                      depends_on=[formula["record_path"]])
        self.file("old.md", "old report")
        old = records.publish(self.workspace, kind="report", title="Old report", files=["old.md"],
                              depends_on=[calculation["record_path"]])
        self.file("review.md", "review of the old report")
        review = records.publish(self.workspace, kind="audit", title="Review", files=["review.md"],
                                 depends_on=[old["record_path"]])
        self.file("lca.md", "final lca")
        lca = records.publish(self.workspace, kind="final_lca", title="Final LCA", files=["lca.md"],
                              depends_on=[review["record_path"], old["record_path"]])
        self.file("new.md", "new report")
        newer = records.publish(self.workspace, kind="report", title="New report", files=["new.md"], depends_on=[])
        stored = {path: path.read_bytes() for path in (self.workspace / ".research/records").rglob("record.json")}
        listed = json.loads(self.tool("research_list", {}, ctx).output)
        by_path = {item["record_path"]: item for item in listed}
        self.assertEqual(by_path[formula["record_path"]]["depended_on_by"],
                         [{"record_path": calculation["record_path"], "kind": "calculation"}])
        self.assertEqual(by_path[old["record_path"]]["depended_on_by"], sorted(
                         [{"record_path": review["record_path"], "kind": "audit"},
             {"record_path": lca["record_path"], "kind": "final_lca"}],
            key=lambda item: item["record_path"]))
        self.assertEqual(by_path[review["record_path"]]["depended_on_by"],
                         [{"record_path": lca["record_path"], "kind": "final_lca"}])
        self.assertEqual(by_path[newer["record_path"]]["depended_on_by"], [])
        self.assertTrue(all("depended_on_by" in item for item in listed))
        published = json.loads(self.tool("research_record", {
            "kind": "notes", "title": "Note", "files": ["new.md"], "depends_on": []}, ctx).output)
        self.assertNotIn("depended_on_by", published)
        self.assertEqual(stored, {path: path.read_bytes() for path in stored})

    def test_delivery_note_shows_stored_edges_without_selecting_a_version(self):
        self.file("calc.txt", "1")
        self.assertEqual(records.delivery_note(self.workspace), "")
        self.file("source.txt", "Observation under condition A.\n")
        source = records.publish(self.workspace, kind="notes", title="Source", files=["source.txt"], depends_on=[])
        self.file("old.md", "Conditional interpretation for condition A.\n")
        old = records.publish(self.workspace, kind="report", title="Old report", files=["old.md"],
                              depends_on=[source["record_path"]])
        review_body = {
            "reviewed_refs": [old["record_path"]],
            "checks": [{
                "subject": {"record_ref": old["record_path"], "source_path": "old.md",
                            "quote": "Conditional interpretation for condition A."},
                "evidence": [{"record_ref": source["record_path"], "source_path": "source.txt",
                              "quote": "Observation under condition A."}],
                "decision": "conditional", "reason": "Limited to the observed condition.",
            }],
        }
        self.file("audit/review.json", records.encoded(review_body).decode("utf-8"))
        review = records.publish(self.workspace, kind="review", title="Review", files=["audit/review.json"],
                                 depends_on=[old["record_path"]])
        self.file("lca.md", "final lca")
        lca = records.publish(self.workspace, kind="final_lca", title="Final LCA", files=["lca.md"],
                              depends_on=[review["record_path"], old["record_path"]])
        self.file("new.md", "new report")
        newer = records.publish(self.workspace, kind="report", title="New report", files=["new.md"], depends_on=[])
        self.file("user.md", "user report")
        user = records.publish(self.workspace, kind="user_report", title="User report", files=["user.md"],
                               depends_on=[newer["record_path"], lca["record_path"]])
        calculation = records.publish(self.workspace, kind="calculation", title="Calculation", files=["calc.txt"],
                                      depends_on=[newer["record_path"]])
        stored = {path: path.read_bytes() for path in (self.workspace / ".research/records").rglob("record.json")}
        note = records.delivery_note(self.workspace)
        self.assertIn("宿主沒有判斷舊審查是否仍適用，也沒有指定哪一筆是目前版本。", note)
        self.assertIn(str(self.workspace), note)
        self.assertIn(f"`review` `{review['record_path']}`", note)
        review_section = note.split(f"`review` `{review['record_path']}`", 1)[1].split("\n- `", 1)[0]
        self.assertIn(old["record_path"], review_section)
        user_section = note.split(f"`user_report` `{user['record_path']}`", 1)[1].split("\n- `", 1)[0]
        self.assertIn(newer["record_path"], user_section)
        self.assertIn(lca["record_path"], user_section)
        new_section = note.split(f"`report` `{newer['record_path']}`", 1)[1].split("\n- `", 1)[0]
        self.assertIn("depends_on: （無）", new_section)
        self.assertIn(f"user_report {user['record_path']}", new_section)
        self.assertIn(f"calculation {calculation['record_path']}", new_section)
        self.assertNotIn("- `calculation`", note)
        self.assertNotIn("- `notes`", note)
        self.assertEqual(stored, {path: path.read_bytes() for path in stored})
        record = self.workspace / newer["record_path"]
        record.write_bytes(record.read_bytes() + b" ")
        failed = records.delivery_note(self.workspace)
        self.assertIn("未能讀取已保存成果", failed)
        # Not listed as a delivery (the error itself names the file by its absolute path).
        self.assertNotIn(f"`report` `{newer['record_path']}`", failed)

    def test_unselected_workspace_records_do_not_modify_an_answer(self):
        self.file("report.md", "Report text")
        saved = records.publish(self.workspace, kind="report", title="Report", files=["report.md"], depends_on=[])
        ctx = self.ctx()
        ctx.app.generate_titles = False
        calls = []

        def complete(**kwargs):
            calls.append(kwargs)
            if kwargs.get("tools"):
                return Completion(text="審查已完成。", finish_reason='stop')
            return Completion(text="review 依賴既有報告。", finish_reason='stop')

        ctx.app.provider = SimpleNamespace(
            resolve=lambda _model: (SimpleNamespace(id="test", context=131072), "test"),
            complete=complete,
        )
        result = ctx.app.prompt(ctx.session_id, "交付")
        self.assertEqual(len(calls), 1)
        self.assertEqual(result["text"], "審查已完成。")
        self.assertNotIn("## 依賴表讀出", result["text"])
        self.assertNotIn("審查對照未進行", result["text"])
        self.assertNotIn(saved["record_path"], result["text"])
        stored = [message.get("content") or "" for message in ctx.app.store.messages(ctx.session_id)
                  if message.get("role") == "assistant"]
        self.assertIn("審查已完成。", stored)
        self.assertTrue(all("宿主依賴表" not in content for content in stored))

    def test_version_gap_returns_to_the_same_agent_with_the_records(self):
        self.file("old.md", "Formula ALI stays.\nGreene and Wuts.\n")
        old = records.publish(self.workspace, kind="report", title="Old report", files=["old.md"], depends_on=[])
        self.file("new.md", "Formula ALI stays.\nRobertson chapter.\n")
        newer = records.publish(self.workspace, kind="report", title="New report", files=["new.md"], depends_on=[])
        review_body = {
            "reviewed_refs": [old["record_path"]],
            "checks": [{
                "subject": {"record_ref": old["record_path"], "source_path": "old.md",
                            "quote": "Greene and Wuts."},
                "evidence": [], "decision": "unassessed", "reason": "Checked the old citation only.",
            }],
        }
        self.file("audit/review.json", records.encoded(review_body).decode("utf-8"))
        review = records.publish(self.workspace, kind="review", title="Review", files=["audit/review.json"],
                                 depends_on=[old["record_path"]])
        self.file("lca.md", "Final LCA of the old report.")
        lca = records.publish(self.workspace, kind="final_lca", title="Final LCA", files=["lca.md"],
                              depends_on=[review["record_path"], old["record_path"]])
        self.file("user.md", "User report of the new report.")
        selected = records.publish(self.workspace, kind="user_report", title="User report", files=["user.md"],
                                   depends_on=[newer["record_path"], lca["record_path"]])
        ctx = self.ctx()
        ctx.app.generate_titles = False
        ctx.app.store.add_message(ctx.session_id, "assistant", {"tool_calls": [{
            "id": "selected", "name": "research_record", "arguments": {"kind": "user_report"}}]})
        ctx.app.store.add_message(ctx.session_id, "tool", {
            "tool_call_id": "selected", "name": "research_record", "content": json.dumps(selected)})
        calls = []

        def complete(**kwargs):
            calls.append(kwargs)
            if len(calls) == 1:
                # This human turn selects the delivery to repair. An old receipt
                # alone must not recommission publication on an unrelated follow-up.
                ctx.app.store.add_message(ctx.session_id, "assistant", {"tool_calls": [{
                    "id": "current-selected", "name": "research_record", "arguments": {"kind": "user_report"}}]})
                ctx.app.store.add_message(ctx.session_id, "tool", {
                    "tool_call_id": "current-selected", "name": "research_record", "content": json.dumps(selected)})
                return Completion(text="審查已完成。", finish_reason='stop')
            return Completion(text="引用變更尚未覆蓋，公式是否仍適用仍不確定。", finish_reason='stop')

        ctx.app.provider = SimpleNamespace(
            resolve=lambda _model: (SimpleNamespace(id="test", context=131072), "test"),
            complete=complete,
        )
        result = ctx.app.prompt(ctx.session_id, "交付")
        self.assertEqual(len(calls), 2)
        second = json.dumps(calls[1]["messages"], ensure_ascii=False)
        self.assertIn(old["record_path"], second)
        self.assertIn(newer["record_path"], second)
        self.assertNotIn("Greene and Wuts.", second)
        self.assertNotIn("Robertson chapter.", second)
        self.assertIn(review["record_path"], host_facts(calls[1]))
        self.assertIn(lca["record_path"], second)
        for saved, text in ((old, "Greene and Wuts."), (newer, "Robertson chapter.")):
            snapshot = (self.workspace / saved["record_path"]).parent / saved["files"][0]["snapshot"]
            self.assertIn(text, snapshot.read_text(encoding="utf-8"))
        self.assertTrue(result["text"].startswith("引用變更尚未覆蓋"))
        self.assertNotIn("審查對照未進行", result["text"])
        self.assertIn("科研交付尚未接妥", result["text"])
        stored = ctx.app.store.messages(ctx.session_id)
        self.assertTrue(any(message.get("synthetic") and "宿主交付檢查" in (message.get("content") or "") for message in stored))
        self.assertEqual([message.get("content") for message in stored if message.get("role") == "assistant" and message.get("content") and not message.get("synthetic")],
                         ["審查已完成。", "引用變更尚未覆蓋，公式是否仍適用仍不確定。"])

    def test_dependency_paths_show_each_selected_branch_without_duplicate_differences(self):
        source = self.file("input.txt", "original")
        base = records.publish(self.workspace, kind="source", title="Input", files=["input.txt"], depends_on=[])
        self.file("a.txt", "A")
        self.file("b.txt", "B")
        a = records.publish(self.workspace, kind="calculation", title="A", files=["a.txt"], depends_on=[base["record_path"]])
        b = records.publish(self.workspace, kind="calculation", title="B", files=["b.txt"], depends_on=[base["record_path"]])
        source.write_text("revised", encoding="utf-8")
        paths, reads = [], []
        differences = records.workspace_differences(self.workspace, [a["record_path"], b["record_path"]],
                                                    paths=paths, check_read=reads.append)
        self.assertEqual(len(differences), 1)
        self.assertEqual(len(paths), 2)
        short = lambda saved: saved["record_path"].split("/")[2][:8]
        self.assertTrue(paths[0].startswith(f"calculation {short(a)} -> source {short(base)} -> input.txt"))
        self.assertTrue(paths[1].startswith(f"calculation {short(b)} -> source {short(base)} -> input.txt"))
        self.assertEqual(reads.count(source), 1)

    def test_rebinding_a_delivery_chain_preserves_numbers_and_old_records(self):
        ctx = self.ctx()
        self.file("formula.md", "old documented expression")
        old_formula = records.publish(self.workspace, kind="formula", title="Formula", files=["formula.md"], depends_on=[])
        self.file("main.py", "# existing implementation")
        values = self.file("values.csv", "id,value\na,1.5\nb,2.5\n")
        old_calc = records.publish(self.workspace, kind="implementation", title="Calculation",
                                   files=["main.py", "values.csv"], depends_on=[old_formula["record_path"]])
        self.file("score.json", '{"score": 1}')
        old_score = records.publish(self.workspace, kind="calibration", title="Score", files=["score.json"],
                                    depends_on=[old_calc["record_path"]])
        before = {p: p.read_bytes() for p in (self.workspace / ".research/records").rglob("*") if p.is_file()}
        values_before = values.read_bytes()
        self.file("formula.md", "corrected documentation of the existing implementation")
        new_formula = records.publish(self.workspace, kind="formula", title="Formula", files=["formula.md"], depends_on=[])
        new_calc = json.loads(self.tool("research_record", {
            "kind": "implementation", "title": "Calculation", "files": ["main.py", "values.csv"],
            "depends_on": [new_formula["record_path"]]}, ctx).output)
        new_score = json.loads(self.tool("research_record", {
            "kind": "calibration", "title": "Score", "files": ["score.json"],
            "depends_on": [new_calc["record_path"]]}, ctx).output)
        self.file("report.md", "Results with selected exact dependencies")
        report = json.loads(self.tool("research_record", {
            "kind": "report", "title": "Report", "files": ["report.md"],
            "depends_on": [new_score["record_path"]]}, ctx).output)
        self.assertNotIn("workspace_differences", report)
        self.assertNotEqual(new_score["record_path"], old_score["record_path"])
        self.assertEqual(records.read_record(self.workspace, new_calc["record_path"])["files"], old_calc["files"])
        self.assertEqual(values.read_bytes(), values_before)
        self.assertTrue(all(path.read_bytes() == data for path, data in before.items()))

    def test_record_that_uses_reviewed_inputs_without_the_review_gets_binding_notice(self):
        ctx = self.ctx()
        self.file("note.md", "Claim and its local check")
        note = records.publish(self.workspace, kind="notes", title="Checked note", files=["note.md"], depends_on=[])
        self.file("receipt.txt", "tool receipt")
        receipt = records.publish(self.workspace, kind="source", title="Receipt", files=["receipt.txt"], depends_on=[])
        def review_json(name):
            self.file(name, json.dumps({"reviewed_refs": [note["record_path"]], "checks": [{
                "subject": {"record_ref": note["record_path"], "source_path": "note.md",
                            "quote": "Claim and its local check"},
                "evidence": [], "decision": "unassessed", "reason": "Evidence not selected."}]}))
        review_json("review.json")
        review = records.publish(self.workspace, kind="review", title="Review", files=["review.json"],
                                 depends_on=[receipt["record_path"], note["record_path"]])
        # The disposition uses the reviewed inputs but substitutes them for the review itself.
        self.file("disposition.md", "Retained after review")
        unbound = json.loads(self.tool("research_record", {
            "kind": "implementation", "title": "Disposition", "files": ["disposition.md"],
            "depends_on": [receipt["record_path"], note["record_path"]]}, ctx).output)
        self.assertEqual(unbound["unbound_reviews"], [{"review": review["record_path"],
                                                       "shared_inputs": sorted([receipt["record_path"], note["record_path"]])}])
        self.assertIn(review["record_path"], unbound["review_binding_notice"])
        self.assertNotIn("unbound_reviews", records.read_record(self.workspace, unbound["record_path"]))
        # Depending on the review directly, or through an ancestor, raises no notice.
        self.file("disposition.md", "Retained after review; cites it")
        bound = json.loads(self.tool("research_record", {
            "kind": "implementation", "title": "Disposition", "files": ["disposition.md"],
            "depends_on": [review["record_path"], receipt["record_path"], note["record_path"]]}, ctx).output)
        self.assertNotIn("review_binding_notice", bound)
        self.file("summary.md", "Builds on the bound disposition")
        later = json.loads(self.tool("research_record", {
            "kind": "notes", "title": "Summary", "files": ["summary.md"],
            "depends_on": [bound["record_path"], note["record_path"]]}, ctx).output)
        self.assertNotIn("review_binding_notice", later)
        # A new review over the same inputs is not itself flagged.
        review_json("second/review.json")
        second = json.loads(self.tool("research_record", {
            "kind": "review", "title": "Second review", "files": ["second/review.json"],
            "depends_on": [note["record_path"]]}, ctx).output)
        self.assertNotIn("review_binding_notice", second)

    def test_large_dependency_notice_keeps_new_record_location_in_preview(self):
        ctx = self.ctx()
        self.file("result.md", "retained result")
        with patch("researchkit.records.workspace_differences",
                   return_value=[{"record_path": "r", "source_path": "x" * 60000, "status": "changed"}]):
            receipt = self.tool("research_record", {"kind": "result", "title": "Result", "files": ["result.md"]}, ctx)
        saved = records.inventory(self.workspace)[0]
        self.assertIn(saved["record_path"], receipt.output)
        self.assertEqual(json.loads(receipt.output)["workspace_differences"],
                         [{"record_path": "r", "source_path": "x" * 60000, "status": "changed"}])
        # tool.ts truncates at execution; message-v2.ts does not truncate on replay.
        from opencode.tools.util import truncate_output
        preview, metadata = truncate_output(receipt.output)
        self.assertIn(saved["record_path"], preview)
        self.assertIn("Full output saved to", preview)
        self.assertEqual(Path(metadata["outputPath"]).read_text(encoding="utf-8"), receipt.output)

    def test_record_tampering_is_detected_not_repaired_silently(self):
        self.file("a.txt", "original")
        saved = records.publish(self.workspace, kind="notes", title="A", files=["a.txt"], depends_on=[])
        folder = (self.workspace / saved["record_path"]).parent
        (folder / saved["files"][0]["snapshot"]).write_text("tampered", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "content has changed"):
            records.read_record(self.workspace, saved["record_path"])

    def test_record_rejects_missing_dependency_and_outside_file(self):
        self.file("a.txt", "source")
        with self.assertRaises(ValueError):
            records.publish(self.workspace, kind="x", title="x", files=["../outside"], depends_on=[])
        with self.assertRaises(ValueError):
            records.publish(self.workspace, kind="x", title="x", files=["a.txt"], depends_on=["a.txt"])
        self.assertFalse((self.workspace / ".research/records").exists())

    def test_scoring_orientation_and_ties(self):
        result = scoring.compare({"a": 1, "b": 1, "c": 2}, {"a": 1, "b": 2, "c": 3}, "higher")
        self.assertAlmostEqual(result["kendall_tau_b"], 2 / math.sqrt(6))
        self.assertAlmostEqual(result["spearman_rho"], math.sqrt(3) / 2)
        inverse = scoring.compare({"a": 3, "b": 2, "c": 1}, {"a": 1, "b": 2, "c": 3}, "lower")
        self.assertEqual(inverse["direction_adjusted_kendall_tau_b"], 1)
        self.assertIsNone(scoring.compare({"a": 1, "b": 1}, {"a": 1, "b": 2}, "higher")["kendall_tau_b"])

    def test_scoring_never_guesses_target_transform_or_drops_rows(self):
        with self.assertRaises(ValueError):
            scoring.compare({"a": 1}, {"a": 1, "b": 2}, "higher")
        for invalid in [True, "1", None, float("nan"), float("inf")]:
            with self.assertRaises(ValueError):
                scoring.compare({"a": invalid}, {"a": 1}, "higher")

    def test_comparison_saves_actual_input_hashes_and_can_be_recorded(self):
        ctx = self.ctx()
        proxy = self.file("proxy.json", '{"a": 1, "b": 2}')
        self.file("target.json", '{"a": 0, "b": -1}')
        observed = json.loads(self.tool("research_compare", {"proxy_path": "proxy.json", "target_path": "target.json", "direction": "lower"}, ctx).output)
        self.assertEqual(observed["direction_adjusted_kendall_tau_b"], 1)
        self.assertEqual(observed["input_files"][0]["sha256"], records.digest(proxy.read_bytes()))
        saved = json.loads(self.tool("research_record", {"kind": "calibration", "title": "Actual comparison",
                                  "files": [observed["result_path"], "proxy.json", "target.json"]}, ctx).output)
        self.assertEqual(len(saved["files"]), 3)

    def test_search_preserves_query_raw_response_and_scope(self):
        raw = {"message": {"items": [{"title": ["Paper"], "DOI": "10.test/item", "URL": "https://doi.org/10.test/item", "abstract": "Observed result"}]}}
        response = httpx.Response(200, json=raw, request=httpx.Request("GET", "https://api.crossref.org/works"))
        with patch("researchkit.literature.httpx.Client") as client:
            client.return_value.__enter__.return_value.get.return_value = response
            output = self.tool("paper_search", {"query": "the actual scientific question", "provider": "crossref"})
        path = next((self.workspace / ".research/searches").glob("*.json"))
        saved = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(saved["query"], "the actual scientific question")
        self.assertEqual(saved["raw_response"], raw)
        self.assertEqual(saved["items"][0]["scope"], "provider_metadata")
        self.assertIn(str(path), output.output)

    def test_search_http_error_is_not_an_empty_success(self):
        response = httpx.Response(403, request=httpx.Request("GET", "https://api.crossref.org/works"))
        with patch("researchkit.literature.httpx.Client") as client:
            client.return_value.__enter__.return_value.get.return_value = response
            with self.assertRaises(httpx.HTTPStatusError):
                literature.search("query", "crossref")

    def test_native_web_sources_keep_returned_tail_before_prompt_presentation(self):
        from opencode.tools.web import _websearch, _webfetch
        from opencode.tools.util import truncate_output
        from opencode.loop import _present_history
        text = "long returned passage " * 6000 + " SOURCE_TAIL"
        ctx = self.ctx()
        # websearch.ts uses JSON-RPC for both services, preserving returned text.
        for provider in ("exa", "parallel"):
            response = httpx.Response(200, json={"result": {"content": [{"type": "text", "text": text}]}},
                                      request=httpx.Request("POST", "https://example.test/mcp"))
            with native_web_response(response), \
                 patch.dict(os.environ, {"OPENCODE_WEBSEARCH_PROVIDER": provider}):
                self.assertEqual(_websearch({"query": "question"}, ctx).output, text)
        with native_web_response(httpx.Response(
                200, text=text, headers={"content-type": "text/plain"}, request=httpx.Request("GET", "https://example.org/paper"))):
            fetch = _webfetch({"url": "https://example.org/paper"}, ctx)
        self.assertEqual(fetch.output, text)
        self.store.add_message(ctx.session_id, "assistant", {"tool_calls": [
            {"id": "w", "name": "websearch", "arguments": {"query": "question"}}]})
        output, metadata = truncate_output(text)
        message = self.store.add_message(ctx.session_id, "tool", {
            "name": "websearch", "tool_call_id": "w", "content": output, "metadata": metadata})
        output_path = Path(metadata["outputPath"])
        self.assertEqual(output_path.read_text(encoding="utf-8"), text)
        presented = _present_history([message], self.store, ctx.session_id)[0]["content"]
        self.assertEqual(presented, output)
        self.assertNotIn("SOURCE_TAIL", presented)
        self.assertIn(f"Full output saved to: {output_path}", presented)
        self.assertLess(len(presented.encode()), 60 * 1024)

    def test_oversized_native_fetch_is_not_silently_saved_as_complete(self):
        from opencode.tools.web import _webfetch, MAX_BYTES
        with native_web_response(httpx.Response(
                200, content=b"x" * (MAX_BYTES + 1), request=httpx.Request("GET", "https://example.org/large"))):
            with self.assertRaisesRegex(ValueError, "exceeds 5MB limit"):
                _webfetch({"url": "https://example.org/large"}, self.ctx())

    def test_truncated_source_with_missing_full_output_fails_publication(self):
        ctx = self.ctx()
        self.store.add_message(ctx.session_id, "assistant", {"tool_calls": [
            {"id": "source", "name": "websearch", "arguments": {"query": "bounded source query"}}]})
        source = self.store.add_message(ctx.session_id, "tool", {"name": "websearch", "tool_call_id": "source",
            "content": "Only a preview", "metadata": {"truncated": True, "outputPath": str(self.workspace / "missing.txt")}})
        self.file("synthesis.md", f"Source: `{source['id']}`")
        with self.assertRaises(FileNotFoundError):
            self.tool("research_record", {"kind": "literature", "title": "Source record", "files": ["synthesis.md"]}, ctx)
        self.assertEqual(records.inventory(self.workspace), [])

    def test_truncated_source_without_full_output_path_fails_publication(self):
        ctx = self.ctx()
        self.store.add_message(ctx.session_id, "assistant", {"tool_calls": [
            {"id": "source", "name": "websearch", "arguments": {"query": "bounded source query"}}]})
        source = self.store.add_message(ctx.session_id, "tool", {"name": "websearch", "tool_call_id": "source",
            "content": "Only a preview", "metadata": {"truncated": True}})
        self.file("synthesis.md", f"Source: `{source['id']}`")
        with self.assertRaisesRegex(ValueError, "has no full output path"):
            self.tool("research_record", {"kind": "literature", "title": "Source record", "files": ["synthesis.md"]}, ctx)
        self.assertEqual(records.inventory(self.workspace), [])

    def test_citation_identity_precedes_abstract_and_missing_fields_are_not_invented(self):
        raw = {"message": {"items": [{"title": ["Acid-labile protecting groups"],
            "DOI": "10.1093/hesc/9780198502753.003.0002", "URL": "https://doi.org/10.1093/hesc/9780198502753.003.0002",
            "author": [{"given": "Jeremy", "family": "Robertson"}],
            "published": {"date-parts": [[2000, 8, 3]]}, "container-title": ["Protecting Group Chemistry"],
            "publisher": "Oxford University Press", "abstract": "abstract " * 20000},
            {"title": ["Missing identity"], "URL": "https://example.org/source"}]}}
        response = httpx.Response(200, json=raw, request=httpx.Request("GET", "https://api.crossref.org/works"))
        with patch("researchkit.literature.httpx.Client") as client:
            client.return_value.__enter__.return_value.get.return_value = response
            output = self.tool("paper_search", {"query": "protecting groups", "provider": "crossref"}).output
        for expected in ("Jeremy Robertson", "2000", "Protecting Group Chemistry", "10.1093/hesc/9780198502753.003.0002",
                         "Missing identity", "authors: not supplied"):
            self.assertIn(expected, output)
        self.assertNotIn("Greene", output)
        self.assertLess(output.index("Missing identity"), output.index("Abstract for result 1"))

    def test_document_fetch_preserves_complete_long_text(self):
        original = ("scientific content " * 10000).encode()
        response = httpx.Response(200, content=original, headers={"content-type": "text/plain"},
                                  request=httpx.Request("GET", "https://example.org/paper"))
        with patch("researchkit.tools.httpx.Client") as client:
            client.return_value.__enter__.return_value.stream.return_value.__enter__.return_value = response
            output = self.tool("paper_fetch", {"url": "https://example.org/paper"})
        folder = next((self.workspace / ".research/documents").iterdir())
        self.assertEqual((folder / "original.bin").read_bytes(), original)
        self.assertEqual((folder / "text.txt").read_text(encoding="utf-8").encode(), original)
        # The reply carries the opening and where the rest is; v36's full-text replies filled its context.
        from researchkit.tools import FETCH_EXCERPT
        self.assertIn(original.decode()[:FETCH_EXCERPT], output.output)
        self.assertIn(f"全文共 {len(original)} 字", output.output)
        self.assertLess(len(output.output), FETCH_EXCERPT + 1000)

    def test_document_fetch_replaces_extraction_control_characters_and_keeps_the_original(self):
        # Unmapped PDF glyphs arrive as control characters; saved evidence must stay readable text.
        original = "yield \x03rose\x02 to 70%\tunder\f3% loading\x7f\n".encode()
        response = httpx.Response(200, content=original, headers={"content-type": "text/plain"},
                                  request=httpx.Request("GET", "https://example.org/paper"))
        with patch("researchkit.tools.httpx.Client") as client:
            client.return_value.__enter__.return_value.stream.return_value.__enter__.return_value = response
            output = self.tool("paper_fetch", {"url": "https://example.org/paper"}).output
        folder = next((self.workspace / ".research/documents").iterdir())
        self.assertEqual((folder / "original.bin").read_bytes(), original)
        self.assertEqual((folder / "text.txt").read_text(encoding="utf-8"),
                         "yield  rose  to 70%\tunder\f3% loading \n")
        self.assertIn("3 control characters from the extraction were replaced with spaces", output)
        # The cleaned text can now be selected as evidence.
        saved = json.loads(self.tool("research_record", {
            "kind": "literature", "title": "Fetched paper",
            "files": [(folder / "text.txt").relative_to(self.workspace).as_posix()]}).output)
        resolved = report_evidence.resolve(self.workspace, [
            {"record_ref": saved["record_path"], "source_path": saved["files"][0]["source_path"]}])
        # text.txt is written in the platform's text mode, so compare after normalizing line ends.
        self.assertEqual(resolved[0]["text"].replace("\r\n", "\n"), "yield  rose  to 70%\tunder\f3% loading \n")

    def test_source_bundle_requires_explicit_files_and_preserves_bytes(self):
        self.file("sources/raw data.json", '{"query":"actual question","answer":"complete reply"}')
        self.file("sources/index.md", "[raw](raw%20data.json#result)\n[cycle](../notes/synthesis.md)")
        self.file("notes/synthesis.md", "[sources](../sources/index.md)\n[remote](https://example.org/paper)\n"
                  "[anchor](#results)\n`[not a source](missing.json)`\n"
                  "```markdown\n[example](another-missing.json)\n```\n")
        saved = json.loads(self.tool("research_record", {
            "kind": "literature", "title": "Explicit sources",
            "files": ["notes/synthesis.md", "sources/index.md", "sources/raw data.json"]}).output)
        self.assertEqual([f["source_path"] for f in saved["files"]],
                         ["notes/synthesis.md", "sources/index.md", "sources/raw data.json"])
        self.assertEqual(set(saved) - {"record_path"}, {"kind", "title", "files", "depends_on"})
        original = self.workspace / saved["record_path"]
        original_bytes = original.read_bytes()
        self.file("sources/raw data.json", '{"answer":"changed"}')
        newer = json.loads(self.tool("research_record", {
            "kind": "literature", "title": "Explicit sources",
            "files": ["notes/synthesis.md", "sources/index.md", "sources/raw data.json"]}).output)
        self.assertNotEqual(saved["record_path"], newer["record_path"])
        self.assertEqual(original.read_bytes(), original_bytes)
        item = saved["files"][-1]
        self.assertIn("complete reply", (original.parent / item["snapshot"]).read_text())

    def test_explicit_missing_denied_and_external_files_fail_without_publication(self):
        ctx = self.ctx()
        self.file("source.txt", "private")
        for link in ("missing.txt", "../outside.txt"):
            with self.subTest(link=link):
                self.file("synthesis.md", f"[source]({link})")
                with self.assertRaises((FileNotFoundError, ValueError)):
                    self.tool("research_record", {"kind": "notes", "title": "Links", "files": ["synthesis.md", link]}, ctx)
                self.assertFalse(records.inventory(self.workspace))
        self.file("synthesis.md", "[source](source.txt)")
        from researchkit.tools import ensure_access as original_check
        def check(c, path, permission):
            if path.name == "source.txt":
                raise PermissionError("source denied")
            original_check(c, path, permission)
        with patch("researchkit.tools.ensure_access", side_effect=check), self.assertRaisesRegex(PermissionError, "source denied"):
            self.tool("research_record", {"kind": "notes", "title": "Links", "files": ["synthesis.md", "source.txt"]}, ctx)
        self.assertFalse(records.inventory(self.workspace))

    def test_common_group_can_be_frozen_with_all_saved_calls_without_summary_scope(self):
        ctx = self.ctx()
        sid = ctx.session_id
        expected = []
        for i, name in enumerate(["paper_search", "websearch", "websearch"]):
            self.store.add_message(sid, "assistant", {"tool_calls": [
                {"id": str(i), "name": name, "arguments": {"query": f"question {i}"}}]})
            message = self.store.add_message(sid, "tool", {"tool_call_id": str(i), "name": name,
                "content": f"result {i}" if i < 2 else "Error: verification challenge"})
            expected.append(message)
        self.store.commit_compaction(sid, expected[-1]["id"], "Only paper_search had sources. This is an old judgment.")
        index = self.store.export_tool_history(sid)
        self.file("handoff.md", f"[All recorded calls]({index.relative_to(self.workspace).as_posix()})")
        source_files = [index.relative_to(self.workspace).as_posix()] + [
            (index.parent / (message["id"] + suffix)).relative_to(self.workspace).as_posix()
            for message in expected for suffix in (".json", ".txt")]
        record = records.publish(self.workspace, kind="literature", title="Sources",
                                 files=["handoff.md", *source_files], depends_on=[])
        paths = {item["source_path"]: item for item in record["files"]}
        folder = (self.workspace / record["record_path"]).parent
        for message in expected:
            for suffix in (".json", ".txt"):
                relative = (index.parent / (message["id"] + suffix)).relative_to(self.workspace).as_posix()
                self.assertIn(relative, paths)
                content = (folder / paths[relative]["snapshot"]).read_text(encoding="utf-8")
                self.assertIn(message["content"], content)
                self.assertNotIn("old judgment", content)

    @unittest.skipUnless(importlib.util.find_spec("pymupdf") and importlib.util.find_spec("markdown"), "Optional PDF dependencies absent")
    def test_report_renders_chinese_and_table_without_browser(self):
        import pymupdf
        self.file("report.md", "# 研究結果\n\n可追溯的計算，不代表實驗驗證。\n\n|Sample|Value|\n|---|---:|\n|A|1.25|\n|B|2.5|\n\n## References\n[Paper](https://example.org/paper)\n")
        receipt = self.tool("render_report", {"markdown_path": "report.md"})
        output = json.loads(receipt.output)
        self.assertEqual(receipt.metadata["files"], [output["html_path"], output["pdf_path"]])
        with pymupdf.open(output["pdf_path"]) as doc:
            text = "\n".join(p.get_text() for p in doc)
            self.assertIn("研究結果", text)
            self.assertIn("1.25", text)
            self.assertIn("References", text)
        self.assertIn("研究結果", Path(output["html_path"]).read_text(encoding="utf-8"))

    def test_cli_delivers_tool_files_even_when_model_omits_paths(self):
        from opencode.tools.types import Tool, ToolResult
        ctx = self.ctx()
        app = ctx.app
        app.generate_titles = False
        output_file = self.file("reports/complete path.html", "delivered")
        receipt = ToolResult(output="Generated", metadata={"files": [str(output_file), str(output_file)]})
        app.extra_tools = [Tool("deliver", "Produce a file", {"type": "object", "properties": {}}, lambda a, c: receipt)]
        replies = [Completion(tool_calls=[ToolCall("r", "deliver", {})], finish_reason='tool-calls'), Completion(text="Done.", finish_reason='stop')]
        app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                       complete=lambda **kw: replies.pop(0))
        args = SimpleNamespace(agent=None, model=None)
        terminal = io.StringIO()
        with redirect_stdout(terminal):
            cli._print_prompt(app, ctx.session_id, "Deliver the result", args)
        self.assertEqual(terminal.getvalue().count(str(output_file)), 1)
        saved = next(m for m in app.store.messages(ctx.session_id) if m.get("role") == "tool")
        self.assertEqual(saved["metadata"]["files"], receipt.metadata["files"])

    def test_interactive_cli_uses_same_file_delivery_and_hides_missing_files(self):
        from opencode.tools.types import ToolResult
        ctx = self.ctx()
        path = self.file("reports/presentation.pdf", "test file")
        def prompt(*args, **kwargs):
            kwargs["on_tool_result"](ToolResult(output="generated", metadata={"files": [str(path), "missing", None]}))
            return {"text": "Done"}
        terminal = io.StringIO()
        with redirect_stdout(terminal), patch("builtins.input", side_effect=["Run", EOFError]), patch.object(ctx.app, "prompt", prompt):
            cli._interactive(ctx.app, SimpleNamespace(agent=None, model=None))
        self.assertIn(str(path), terminal.getvalue())
        self.assertNotIn("[File] " + str(self.workspace / "missing"), terminal.getvalue())

    def test_cli_legacy_encoding_does_not_abort_stream_or_corrupt_transcript(self):
        from scripts.recording import Tee
        ctx = self.ctx()
        raw = io.BytesIO()
        terminal = io.TextIOWrapper(raw, encoding="cp950", errors="strict")
        transcript = io.StringIO()
        text = "Verified \u2713 \U0001f9ea"
        replies = []

        def prompt(*args, **kwargs):
            kwargs["on_text"](text)
            ctx.app.store.add_message(args[0], "assistant", {"content": text})
            replies.append(text)
            return {"text": text, "status": "completed"}

        with redirect_stdout(Tee(terminal, transcript)), patch.object(cli, "_app", return_value=ctx.app), patch.object(ctx.app, "prompt", prompt):
            cli.main(["--dir", str(self.workspace), "--auto", "run", "continue"])
        self.assertEqual(replies, [text])
        self.assertEqual(transcript.getvalue(), text)
        self.assertIn(b"\\u2713", raw.getvalue())
        self.assertIn(b"\\U0001f9ea", raw.getvalue())

    def test_cli_utf8_output_keeps_unicode_characters(self):
        raw = io.BytesIO()
        terminal = io.TextIOWrapper(raw, encoding="utf-8")
        with redirect_stdout(terminal), self.assertRaises(SystemExit):
            cli.main(["--version"])
        terminal.write("\u2713")
        terminal.flush()
        self.assertIn("\u2713".encode(), raw.getvalue())


if __name__ == "__main__":
    unittest.main()
