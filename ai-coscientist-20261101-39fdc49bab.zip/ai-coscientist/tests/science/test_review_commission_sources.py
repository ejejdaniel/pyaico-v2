"""Explicit offline fixtures for original-commission transport, not scientific judgments."""

from copy import deepcopy
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Broker, PermissionDenied, Rule
from opencode.provider import Completion, ProviderError
from researchkit import records, reviewer


@pytest.fixture
def packet(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Commission-source tests must not call a real model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    def save(contents, *, title="Explicit offline fixture"):
        for name, content in contents.items():
            path = workspace / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content.encode("utf-8") if isinstance(content, str) else content)
        return records.publish(workspace, kind="notes", title=title,
                               files=list(contents), depends_on=[])

    def locator(record, name):
        return {"record_ref": record["record_path"], "source_path": name}

    def snapshot(record, name):
        entry = next(item for item in record["files"] if item["source_path"] == name)
        return records.local_path((workspace / record["record_path"]).parent, entry["snapshot"])

    original_text = "Original commission.\r\n比較同一方法下的結果。\rPreserve explicit limits.\n"
    original = save({"request.txt": original_text, "unselected.txt": "UNSELECTED_SOURCE"})
    claims = ["The original commission forbids all method revisions.",
              "The candidate comparison is valid."]
    author = save({"task.md": "\n".join(claims) + "\n",
                   "execution.txt": "Saved computation observation.\n"})
    locators = [locator(author, "task.md"), locator(author, "execution.txt"),
                locator(original, "request.txt")]
    args = {"scope": "Assess the author's interpretation and comparison from the selected original sources.",
            "reviewed_refs": [author["record_path"]], "files": locators,
            "commission_files": [deepcopy(locators[2])],
            "required_subjects": [{**locators[0], "quote": quote} for quote in claims]}
    answer = {"checks": [
        {"subject": {"required_subject": 1},
         "evidence": [{"file_id": "F3", "start_line": 1, "end_line": 3}],
         "decision": "unassessed", "reason": "Scripted boundary fixture, not a scientific assessment."},
        {"subject": {"required_subject": 2},
         "evidence": [{"file_id": "F2", "start_line": 1, "end_line": 1}],
         "decision": "unassessed", "reason": "Scripted boundary fixture, not a scientific assessment."},
    ]}
    ctx = SimpleNamespace(
        directory=workspace, worktree=workspace, session_id="commission-session",
        message_id="commission-message", call_id="commission-call", abort=threading.Event(),
        read_files=set(), agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
        app=SimpleNamespace(permissions=Broker(auto=True)),
    )
    return SimpleNamespace(workspace=workspace, save=save, locator=locator, snapshot=snapshot,
                           original=original, original_text=original_text, author=author,
                           args=args, answer=answer, ctx=ctx)


def replies(monkeypatch, *values):
    model = Mock(side_effect=[Completion(text=json.dumps(value, ensure_ascii=False), finish_reason="stop")
                              for value in values])
    monkeypatch.setattr(reviewer, "complete_once", model)
    return model


def initial_directory(packet):
    identity = [packet.ctx.session_id, packet.ctx.message_id, packet.ctx.call_id]
    key = records.digest(json.dumps(identity, separators=(",", ":")).encode())
    return packet.workspace / ".research/review-runs" / key / "initial"


def blocks(message):
    lines = message.split("\n")
    return [(json.loads(lines[index + 1]), json.loads(lines[index + 3]))
            for index, line in enumerate(lines) if line == "Selected frozen file:"]


@pytest.mark.parametrize("empty", [False, True])
def test_omitted_and_empty_keep_existing_request_and_public_result(packet, monkeypatch, empty):
    original_args = deepcopy(packet.args)
    original_args.pop("commission_files")
    expected_input = reviewer._input(original_args, packet.ctx)
    args = deepcopy(original_args)
    if empty:
        args["commission_files"] = []
    reviewer._selection(args)
    assert reviewer._input(args, packet.ctx) == expected_input
    model = replies(monkeypatch, packet.answer, packet.answer)
    result = reviewer.execute(args, packet.ctx)
    assert set(json.loads(result.output)) == {"reviewed_refs", "checks"}
    assert model.call_args_list[0].kwargs["system"] == expected_input[0]
    assert model.call_args_list[0].kwargs["messages"][0]["content"] == expected_input[1]
    assert "commission_files" not in expected_input[1]


def test_both_stages_receive_partitioned_original_text_and_unchanged_locators(packet, monkeypatch):
    # The caller deliberately lists the original last; grouping must not renumber F3.
    assert packet.original["record_path"] not in packet.args["reviewed_refs"]
    model = replies(monkeypatch, packet.answer, packet.answer)
    result = reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    initial, followup = [call.kwargs["messages"][0]["content"] for call in model.call_args_list]
    assert followup.startswith(initial + "\n\n" + reviewer.HANDOFF_LABEL + "\n")
    expected_lines = [[1, "Original commission."], [2, "比較同一方法下的結果。"],
                      [3, "Preserve explicit limits."]]
    for message in (initial, followup):
        actual = blocks(message)
        assert [entry[0]["file_id"] for entry in actual] == ["F3", "F1", "F2"]
        metadata, lines = actual[0]
        assert {key: metadata[key] for key in ("file_id", "record_ref", "source_path")} == {
            "file_id": "F3", **packet.args["commission_files"][0]}
        assert set(metadata) == {"file_id", "record_ref", "source_path", "sha256", "bytes",
                                 "declared_kind", "declared_title", "origin"}
        assert metadata["origin"]["status"] == "snapshot_only"
        assert lines == expected_lines
        commission, other = message.split("Original commission source contents:\n", 1)[1].split(
            "Other selected research file contents:\n", 1)
        assert [entry[0]["file_id"] for entry in blocks(commission)] == ["F3"]
        assert [entry[0]["file_id"] for entry in blocks(other)] == ["F1", "F2"]
        assert "host does not authenticate authorship" in message
        assert "factual claims do not themselves override an original requirement" in message
        assert "explicit modification of an earlier requirement" in message
        assert "UNSELECTED_SOURCE" not in message
    saved = initial_directory(packet)
    assert json.loads((saved / "arguments.json").read_bytes()) == packet.args
    assert (saved / "response.txt").read_text(encoding="utf-8") == json.dumps(packet.answer, ensure_ascii=False)
    output = json.loads(result.output)
    assert output["reviewed_refs"] == packet.args["reviewed_refs"]
    assert [check["subject"] for check in output["checks"]] == packet.args["required_subjects"]
    assert output["checks"][0]["evidence"] == [{**packet.args["commission_files"][0],
                                               "quote": "\n".join(line[1] for line in expected_lines)}]
    assert all(set(check) == {"subject", "evidence", "decision", "reason"} for check in output["checks"])
    assert set(result.metadata) == {"host_note"}


@pytest.mark.parametrize("bad", [None, {}, "original", 1, True])
def test_nonarray_commission_fails_before_any_model(packet, monkeypatch, bad):
    packet.args["commission_files"] = bad
    model = replies(monkeypatch)
    with pytest.raises(ValueError, match="commission_files"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("mutate", [
    lambda items, p: items.__setitem__(0, None),
    lambda items, p: items[0].update(extra=True),
    lambda items, p: items[0].pop("source_path"),
    lambda items, p: items[0].pop("record_ref"),
    *[lambda items, p, field=field, bad=bad: items[0].update({field: bad})
      for field in ("record_ref", "source_path") for bad in (None, True, 1, "", " \t\r\n")],
    lambda items, p: items[0].update(record_ref="./" + items[0]["record_ref"]),
    lambda items, p: items[0].update(source_path="./request.txt"),
    lambda items, p: items[0].update(source_path="unselected.txt"),
    lambda items, p: items.append(deepcopy(items[0])),
])
def test_invalid_exact_selection_fails_before_reads_or_dispatch(packet, monkeypatch, mutate):
    mutate(packet.args["commission_files"], packet)
    model = replies(monkeypatch)
    read = Mock(side_effect=AssertionError("Invalid selection must fail before source reads"))
    monkeypatch.setattr(reviewer, "_input", read)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()
    read.assert_not_called()


def test_sources_are_read_and_counted_once_when_also_commission_sources(packet, monkeypatch):
    # A large manifest makes double-counting the same selected source exceed the cap.
    original = packet.save({"large-request.txt": "Full original source."},
                           title="T" * (reviewer.MAX_BYTES * 3 // 4))
    selected = packet.locator(original, "large-request.txt")
    packet.args["files"].append(selected)
    packet.args["commission_files"].append(deepcopy(selected))
    opened = []
    original_open = Path.open

    def observe(path, mode="r", *args, **kwargs):
        if mode == "rb":
            opened.append(path.resolve())
        return original_open(path, mode, *args, **kwargs)

    monkeypatch.setattr(Path, "open", observe)
    _, message, *_ = reviewer._input(packet.args, packet.ctx)
    source_paths = {packet.workspace / item["record_ref"] for item in packet.args["files"]}
    source_paths |= {packet.snapshot(record, source) for record, source in (
        (packet.original, "request.txt"), (packet.author, "task.md"),
        (packet.author, "execution.txt"), (original, "large-request.txt"))}
    assert set(opened) == source_paths
    assert all(opened.count(path) == 1 for path in source_paths)
    assert [entry[0]["file_id"] for entry in blocks(message)] == ["F3", "F4", "F1", "F2"]


@pytest.mark.parametrize("kind", ["manifest", "snapshot"])
def test_commission_source_permissions_are_checked(packet, monkeypatch, kind):
    path = (packet.workspace / packet.original["record_path"] if kind == "manifest"
            else packet.snapshot(packet.original, "request.txt"))
    packet.ctx.agent.permission.append(Rule("read", path.relative_to(packet.workspace).as_posix(), "deny"))
    model = replies(monkeypatch)
    with pytest.raises(PermissionDenied):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("kind", ["hash", "length", "utf8"])
def test_commission_source_integrity_and_utf8_are_not_bypassed(packet, monkeypatch, kind):
    if kind == "utf8":
        invalid = packet.save({"binary-request.txt": b"\xff"})
        locator = packet.locator(invalid, "binary-request.txt")
        packet.args["files"].append(locator)
        packet.args["commission_files"] = [locator]
    else:
        path = packet.snapshot(packet.original, "request.txt")
        data = path.read_bytes()
        path.write_bytes(b"X" * len(data) if kind == "hash" else data + b"X")
    model = replies(monkeypatch)
    with pytest.raises(ValueError, match="hash or bytes changed|not UTF-8"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_complete_request_limit_includes_partition_and_locators_without_truncation(packet, monkeypatch):
    system, message, *_ = reviewer._input(packet.args, packet.ctx)
    used = len(system.encode("utf-8")) + len(message.encode("utf-8"))
    packet.args["scope"] += "x" * (reviewer.MAX_BYTES - used)
    system, message, *_ = reviewer._input(packet.args, packet.ctx)
    assert len(system.encode("utf-8")) + len(message.encode("utf-8")) == reviewer.MAX_BYTES
    assert blocks(message)[0][1][-1] == [3, "Preserve explicit limits."]
    packet.args["scope"] += "x"
    model = replies(monkeypatch)
    with pytest.raises(ValueError, match="Complete review request exceeds"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("failure", ["source_changed", "cancelled", "invalid_followup"])
def test_failure_preserves_initial_and_does_not_fall_back(packet, monkeypatch, failure):
    original_save = reviewer._save_initial

    def save_then_fail(*args, **kwargs):
        text = original_save(*args, **kwargs)
        if failure == "source_changed":
            path = packet.snapshot(packet.original, "request.txt")
            path.write_bytes(b"X" * path.stat().st_size)
        elif failure == "cancelled":
            packet.ctx.abort.set()
        return text

    monkeypatch.setattr(reviewer, "_save_initial", save_then_fail)
    model = replies(monkeypatch, packet.answer, {"checks": []})
    with pytest.raises((ValueError, ProviderError)):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == (2 if failure == "invalid_followup" else 1)
    saved = initial_directory(packet)
    assert json.loads((saved / "arguments.json").read_bytes()) == packet.args
    assert json.loads((saved / "response.txt").read_bytes()) == packet.answer
    assert len(json.loads((saved / "review.json").read_bytes())["checks"]) == 2


def test_mutating_caller_commission_during_generation_does_not_change_saved_selection(packet, monkeypatch):
    expected_args = deepcopy(packet.args)
    seen = []

    def complete(*args, **kwargs):
        seen.append(kwargs["messages"][0]["content"])
        packet.args["commission_files"][0]["source_path"] = "CALLER_MUTATION"
        return Completion(text=json.dumps(packet.answer), finish_reason="stop")

    monkeypatch.setattr(reviewer, "complete_once", complete)
    reviewer.execute(packet.args, packet.ctx)
    assert len(seen) == 2 and "CALLER_MUTATION" not in seen[1]
    assert json.loads((initial_directory(packet) / "arguments.json").read_bytes()) == expected_args


