"""Exact review publication boundaries, without a live model or semantic scoring."""

from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from researchkit import records


class ReviewContract(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.file("source.txt", b"Observation under condition A.\nLimit: not tested under B.\n")
        self.source = self.save("source.txt")
        self.file("report.md", b"Conditional interpretation for condition A.\nOther claims are not audited.\n")
        self.report = self.save("report.md", [self.source["record_path"]])
        self.value = {
            "reviewed_refs": [self.report["record_path"]],
            "checks": [{
                "subject": {"record_ref": self.report["record_path"], "source_path": "report.md",
                            "quote": "Conditional interpretation for condition A."},
                "evidence": [{"record_ref": self.source["record_path"], "source_path": "source.txt",
                              "quote": "Observation under condition A."}],
                "decision": "conditional", "reason": "Limited to the observed condition."
            }]
        }

    def file(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def save(self, name, dependencies=(), kind="notes"):
        return records.publish(self.root, kind=kind, title=name, files=[name], depends_on=list(dependencies))

    def review(self, value=None, dependencies=None, **kwargs):
        self.file("audit/review.json", records.encoded(self.value if value is None else value))
        return records.publish(self.root, kind="review", title="Selected claims", files=["audit/review.json"],
                               depends_on=dependencies if dependencies is not None else [self.report["record_path"]],
                               **kwargs)

    def snapshot(self, record):
        return self.root / Path(record["record_path"]).parent / record["files"][0]["snapshot"]

    def test_exact_source_chain_and_public_shape_unchanged(self):
        saved = self.review()
        self.assertEqual(set(saved), {"record_path", "kind", "title", "files", "depends_on"})
        self.assertEqual(json.loads(self.snapshot(saved).read_bytes()), self.value)
        self.assertEqual(saved["depends_on"], [self.report["record_path"]])
        self.assertEqual(self.review(), saved)

    def test_missing_indirect_only_and_multiple_review_files_rejected(self):
        self.file("audit/review.json", records.encoded(self.value))
        self.file("other/review.json", records.encoded(self.value))
        self.file("audit/explanation.md", b"[review](review.json)")
        for files in (["audit/explanation.md"], ["report.md"], ["audit/review.json", "other/review.json"]):
            with self.subTest(files=files), self.assertRaisesRegex(ValueError, "explicitly select exactly one"):
                records.publish(self.root, kind="review", title="Review", files=files,
                                depends_on=[self.report["record_path"]])
        self.assertEqual(len(records.inventory(self.root)), 2)

    def test_format_errors_have_locations_and_no_partial_publication(self):
        cases = [
            ([], "expected an object"),
            ({"reviewed_refs": [], "checks": []}, "/reviewed_refs"),
            ({**self.value, "extra": True}, "unexpected"),
            ({"reviewed_refs": self.value["reviewed_refs"]}, "missing"),
            ({**self.value, "checks": []}, "/checks"),
            ({**self.value, "reviewed_refs": [None]}, "/reviewed_refs/0"),
            ({**self.value, "reviewed_refs": self.value["reviewed_refs"] * 2}, "duplicate reviewed"),
        ]
        for value, error in cases:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, error):
                self.review(value)
        self.assertEqual(len(records.inventory(self.root)), 2)

    def test_check_and_locator_types_are_exact(self):
        cases = [("decision", "approved"), ("decision", []), ("reason", " \n"), ("reason", 42),
                 ("evidence", {}), ("subject", "report.md")]
        for field, invalid in cases:
            value = deepcopy(self.value)
            value["checks"][0][field] = invalid
            with self.subTest(field=field, invalid=invalid), self.assertRaisesRegex(ValueError, "/checks/0/" + field):
                self.review(value)
        for field in ("record_ref", "source_path", "quote"):
            value = deepcopy(self.value)
            value["checks"][0]["subject"][field] = " "
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "/subject/" + field):
                self.review(value)
        for target in ("check", "subject", "evidence"):
            value = deepcopy(self.value)
            obj = value["checks"][0]
            if target == "subject":
                obj = obj["subject"]
            elif target == "evidence":
                obj = obj["evidence"][0]
            obj["extra"] = "not permitted"
            with self.subTest(target=target), self.assertRaisesRegex(ValueError, "unexpected"):
                self.review(value)

    def test_all_independent_quote_and_field_errors_are_reported_without_mutation(self):
        value = deepcopy(self.value)
        value["checks"].append(deepcopy(value["checks"][0]))
        bad = "Conditional interpretation\n   for condition A."
        value["checks"][0]["subject"]["quote"] = bad
        value["checks"][1]["evidence"][0]["quote"] = "Observation under condition B."
        value["checks"][1]["reason"] = " "
        value["checks"][1]["decision"] = "approved"
        (self.root / "source.txt").write_text("New unrelated working content", encoding="utf-8")
        before = {p: p.read_bytes() for p in (self.root / ".research").rglob("*") if p.is_file()}
        with self.assertRaises(ValueError) as caught:
            self.review(value)
        error = str(caught.exception)
        for path in ("/checks/0/subject/quote", "/checks/1/evidence/0/quote",
                     "/checks/1/reason", "/checks/1/decision"):
            self.assertIn(path, error)
        self.assertIn(json.dumps(bad), error)
        self.assertIn(json.dumps(str(self.snapshot(self.report))), error)
        self.assertIn(json.dumps(str(self.snapshot(self.source))), error)
        self.assertIn("Review was not published", error)
        self.assertEqual((self.root / "audit/review.json").read_bytes(), records.encoded(value))
        self.assertEqual(len(records.inventory(self.root)), 2)
        self.assertTrue(all(p.read_bytes() == data for p, data in before.items()))

    def test_duplicate_json_keys_are_never_last_write_wins(self):
        raw = records.encoded(self.value).decode()
        for token, duplicate in [('"reviewed_refs":', '"reviewed_refs": [], "reviewed_refs":'),
                                 ('"reason":', '"reason": "first", "reason":'),
                                 ('"quote":', '"quote": "first", "quote":')]:
            self.file("review.json", raw.replace(token, duplicate, 1).encode())
            with self.subTest(token=token), self.assertRaisesRegex(ValueError, "duplicate JSON key"):
                self.save("review.json", [self.report["record_path"]], kind="review")

    def test_bad_encoding_and_malformed_json_rejected(self):
        for raw in (b"{broken", b"\xff", b"null"):
            self.file("review.json", raw)
            with self.subTest(raw=raw), self.assertRaisesRegex(ValueError, "review.json"):
                self.save("review.json", [self.report["record_path"]], kind="review")

    def test_empty_evidence_is_allowed_only_for_unassessed(self):
        value = deepcopy(self.value)
        value["checks"][0]["evidence"] = []
        for decision in ("supported", "conditional", "contradicted", "unsupported"):
            value["checks"][0]["decision"] = decision
            with self.subTest(decision=decision), self.assertRaisesRegex(ValueError, "empty evidence requires"):
                self.review(value)
        value["checks"][0]["decision"] = "unassessed"
        value["checks"][0]["reason"] = "Evidence is unavailable; no conclusion."
        self.assertEqual(json.loads(self.snapshot(self.review(value)).read_bytes()), value)

    def test_does_not_infer_support_or_independence_from_content(self):
        value = deepcopy(self.value)
        value["checks"][0]["evidence"] = [deepcopy(value["checks"][0]["subject"])]
        for decision in ("supported", "conditional", "contradicted", "unassessed", "unsupported"):
            value["checks"][0]["decision"] = decision
            self.review(value)
        self.assertNotIn("overall_pass", json.loads(self.snapshot(self.review(value)).read_bytes()))

    def test_old_public_shape_and_new_unsupported_publish_without_rewriting_quotes_or_reasons(self):
        value = deepcopy(self.value)
        value["checks"][0]["subject"]["quote"] = "interpretation for condition A"
        value["checks"][0]["reason"] = "  Author-authored judgment; preserve exactly.\t\n"
        for decision in ("supported", "conditional", "contradicted", "unassessed", "unsupported"):
            value["checks"][0]["decision"] = decision
            raw = records.encoded(value)
            with self.subTest(decision=decision):
                saved = self.review(value)
                self.assertEqual(self.snapshot(saved).read_bytes(), raw)
                self.assertEqual(set(json.loads(raw)), {"reviewed_refs", "checks"})
                self.assertEqual(set(value["checks"][0]["subject"]), {"record_ref", "source_path", "quote"})

    def test_duplicate_evidence_locator_rejected(self):
        value = deepcopy(self.value)
        value["checks"][0]["evidence"] *= 2
        with self.assertRaisesRegex(ValueError, "/evidence/1: duplicate"):
            self.review(value)

    def test_distinct_quotes_from_same_file_are_allowed_in_one_check(self):
        value = deepcopy(self.value)
        value["checks"][0]["evidence"].append({
            **value["checks"][0]["evidence"][0],
            "quote": "Limit: not tested under B.",
        })
        saved = self.review(value)
        self.assertEqual(json.loads(self.snapshot(saved).read_bytes()), value)

    def test_all_reviewed_refs_must_be_direct_and_have_a_subject(self):
        with self.assertRaisesRegex(ValueError, "direct depends_on"):
            self.review(dependencies=[self.source["record_path"]])
        value = deepcopy(self.value)
        value["reviewed_refs"].append(self.source["record_path"])
        with self.assertRaisesRegex(ValueError, "no check.subject"):
            self.review(value, dependencies=[self.report["record_path"], self.source["record_path"]])
        value["checks"].append({"subject": deepcopy(value["checks"][0]["evidence"][0]), "evidence": [],
                                "decision": "unassessed", "reason": "Not checked further."})
        self.review(value, dependencies=[self.report["record_path"], self.source["record_path"]])

    def test_subject_cannot_be_an_unreviewed_dependency(self):
        value = deepcopy(self.value)
        value["checks"][0]["subject"] = deepcopy(value["checks"][0]["evidence"][0])
        with self.assertRaisesRegex(ValueError, "/subject/record_ref"):
            self.review(value)

    def test_existing_unselected_and_noncanonical_references_rejected(self):
        self.file("outside.txt", b"Observation under condition A.")
        other = self.save("outside.txt")
        for ref, source in [(other["record_path"], "outside.txt"),
                            (str(self.root / self.source["record_path"]), "source.txt"),
                            ("./" + self.source["record_path"], "source.txt"),
                            (".research/records/missing/record.json", "source.txt")]:
            value = deepcopy(self.value)
            value["checks"][0]["evidence"][0].update(record_ref=ref, source_path=source)
            with self.subTest(ref=ref), self.assertRaisesRegex(ValueError, "/evidence/0/record_ref"):
                self.review(value)

    def test_source_path_is_manifest_field_not_snapshot_or_working_alias(self):
        for source in ("files/source.txt", "./source.txt", "missing.txt", "../source.txt"):
            value = deepcopy(self.value)
            value["checks"][0]["evidence"][0]["source_path"] = source
            with self.subTest(source=source), self.assertRaisesRegex(ValueError, "/source_path"):
                self.review(value)

    def test_quote_is_literal_with_only_newline_normalization(self):
        self.file("unicode.txt", "\ufeff量測 α\r\ncondition A\rend\ne\u0301".encode())
        source = self.save("unicode.txt")
        value = deepcopy(self.value)
        evidence = value["checks"][0]["evidence"][0]
        evidence.update(record_ref=source["record_path"], source_path="unicode.txt", quote="量測 α\ncondition A\nend")
        dependencies = [self.report["record_path"], source["record_path"]]
        self.review(value, dependencies)
        # Skipping the intervening condition line cannot produce one literal quote.
        for quote in ("量測 α\nCondition A", "量測  α", "é", "condition A end", "量測 α\nend"):
            evidence["quote"] = quote
            with self.subTest(quote=quote), self.assertRaisesRegex(ValueError, "literal quote not found"):
                self.review(value, dependencies)
        evidence["quote"] = "condition A\rend"
        self.review(value, dependencies)

    def test_long_quotes_and_reasons_have_no_new_hard_limit(self):
        text = "evidence " * 3000
        self.file("long.txt", text.encode())
        source = self.save("long.txt")
        value = deepcopy(self.value)
        value["checks"][0]["evidence"][0].update(record_ref=source["record_path"], source_path="long.txt", quote=text)
        value["checks"][0]["reason"] = "scope " * 3000
        self.review(value, [self.report["record_path"], source["record_path"]])

    def test_working_files_and_newer_records_cannot_replace_exact_old_evidence(self):
        old_bytes = self.snapshot(self.source).read_bytes()
        self.file("source.txt", b"new observation")
        newer = self.save("source.txt")
        (self.root / "report.md").unlink()
        saved = self.review()
        self.assertEqual(self.snapshot(self.source).read_bytes(), old_bytes)
        self.assertNotIn(newer["record_path"], saved["depends_on"])
        value = deepcopy(self.value)
        value["checks"][0]["evidence"][0]["quote"] = "new observation"
        with self.assertRaisesRegex(ValueError, "literal quote not found"):
            self.review(value)

    def test_frozen_source_missing_or_tampered_is_not_repaired(self):
        snapshot = self.snapshot(self.source)
        snapshot.write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "content has changed"):
            self.review()
        snapshot.unlink()
        with self.assertRaises(FileNotFoundError):
            self.review()
        self.assertEqual(len(list((self.root / ".research/records").glob("*/record.json"))), 2)

    def test_source_permission_is_checked_before_reading_bytes(self):
        forbidden = self.snapshot(self.source)
        read = Path.read_bytes
        reads = []
        def observe(path):
            reads.append(path)
            return read(path)
        def authorize(path):
            if path == forbidden:
                raise PermissionError("not authorized")
        with patch.object(Path, "read_bytes", observe), self.assertRaises(PermissionError):
            self.review(check_read=authorize)
        self.assertNotIn(forbidden, reads)

    def test_validated_bytes_are_the_bytes_snapshotted_even_if_working_file_changes(self):
        from researchkit import review
        validate = review.validate
        def change_after_validation(root, data, *args, **kwargs):
            validate(root, data, *args, **kwargs)
            (root / "audit/review.json").write_bytes(b"invalid replacement")
        with patch.object(review, "validate", side_effect=change_after_validation):
            saved = self.review()
        self.assertEqual(json.loads(self.snapshot(saved).read_bytes()), self.value)
        self.assertEqual((self.root / "audit/review.json").read_bytes(), b"invalid replacement")

    def test_citation_read_rechecks_bytes_after_dependency_validation(self):
        from researchkit import review
        validate = review.validate
        def change_before_validation(root, data, *args, **kwargs):
            self.snapshot(self.source).write_bytes(b"tampered")
            validate(root, data, *args, **kwargs)
        with patch.object(review, "validate", side_effect=change_before_validation), \
                self.assertRaisesRegex(ValueError, "snapshot changed before quote"):
            self.review()

    def test_bom_json_accepted_but_non_utf8_evidence_is_not_guessed(self):
        self.file("review.json", b"\xef\xbb\xbf" + records.encoded(self.value))
        self.save("review.json", [self.report["record_path"]], kind="review")
        self.file("binary.bin", b"\xff\xfe")
        binary = self.save("binary.bin")
        value = deepcopy(self.value)
        value["checks"][0]["evidence"][0].update(record_ref=binary["record_path"], source_path="binary.bin")
        with self.assertRaisesRegex(ValueError, "not UTF-8"):
            self.review(value, [self.report["record_path"], binary["record_path"]])

    def test_old_review_readable_without_retroactive_validation_or_mutation(self):
        self.file("old.md", b"Old free-text review")
        old = self.save("old.md")
        manifest = records.read_record(self.root, old["record_path"])
        manifest["kind"] = "review"
        raw = records.encoded(manifest)
        folder = self.root / ".research/records" / records.digest(raw)
        self.file(str(folder / "record.json"), raw)
        self.file(str(folder / "files/old.md"), b"Old free-text review")
        ref = (folder / "record.json").relative_to(self.root).as_posix()
        self.assertEqual(records.read_record(self.root, ref), manifest)
        self.assertIn(ref, [r["record_path"] for r in records.inventory(self.root)])
        self.file("delivery.md", b"Historical review retained, not revalidated")
        self.save("delivery.md", [ref], kind="final_lca")
        self.assertEqual((folder / "record.json").read_bytes(), raw)
        with self.assertRaisesRegex(ValueError, "explicitly select"):
            self.save("old.md", kind="review")

    def test_other_record_kinds_are_not_classified_by_filename_or_title(self):
        self.file("review.json", b"not json")
        for kind in ("notes", "final_lca", "report"):
            self.save("review.json", kind=kind)


if __name__ == "__main__":
    unittest.main()
