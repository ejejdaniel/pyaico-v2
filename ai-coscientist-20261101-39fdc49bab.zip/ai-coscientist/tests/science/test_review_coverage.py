"""The host says which report version is reviewed when a report, Final-LCA or delivery is saved; no model calls."""

from __future__ import annotations

import json
import os
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import board, records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install

CLOCK = [1_700_000_000]


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    saved = records.publish(root, kind=kind, title=kind, files=list(files),
                            depends_on=[ref["record_path"] for ref in depends_on])
    CLOCK[0] += 1  # save order, independent of the file system's timer resolution
    os.utime(root / saved["record_path"], (CLOCK[0], CLOCK[0]))
    return saved


def review_of(root, folder, report, source):
    body = {"reviewed_refs": [report["record_path"]], "checks": [{
        "subject": {"record_ref": report["record_path"], "source_path": report["files"][0]["source_path"],
                    "quote": "The claim."},
        "evidence": [{"record_ref": source["record_path"], "source_path": "source.txt", "quote": "The observation."}],
        "decision": "supported", "reason": "Matches the observation."}]}
    return save(root, "review", {f"{folder}/review.json": body}, [report, source])


def actions(root):
    return [item["text"] for item in board.open_actions(board.build(root))]


@pytest.fixture
def study(tmp_path):
    source = save(tmp_path, "notes", {"source.txt": "The observation.\n"})
    first = save(tmp_path, "report", {"v1/report.md": "The claim.\n"}, [source])
    review = review_of(tmp_path, "r1", first, source)
    second = save(tmp_path, "report", {"v2/report.md": "The claim.\nA corrected sentence.\n"}, [first])
    return tmp_path, source, first, review, second


def short(record):
    return record["record_path"].split("/")[2][:8]


def test_a_newer_report_built_on_the_reviewed_one_needs_no_second_review(study):
    # The delivered report is rendered or revised after its draft was reviewed; research_deliver carries the
    # review over through answers, so the board only says so.
    root, source, first, _, second = study
    assert not any("還沒有審查" in t for t in actions(root))
    infos = [item["text"] for item in board.build(root)["notice_items"] if item["level"] == "info"]
    assert any(f"report {short(second)} 建立在審查過的版本 {short(first)}" in t for t in infos)


def test_a_newer_report_not_built_on_a_reviewed_one_is_flagged_until_it_is_reviewed(study):
    root, source, first, _, _ = study
    third = save(root, "report", {"v3/report.md": "The claim.\nAnother claim.\n"}, [source])
    flagged = [t for t in actions(root) if "是最新的報告，但還沒有審查" in t]
    assert len(flagged) == 1 and short(third) in flagged[0] and short(first) in flagged[0]
    review_of(root, "r3", third, source)
    assert not any("還沒有審查" in t for t in actions(root))


def test_a_final_lca_of_an_unreviewed_version_is_flagged_and_a_revision_clears_it(study):
    # v16: the Final-LCA judged the corrected report but carried the old review's review.json as its own file.
    root, source, first, review, second = study
    lca = save(root, "final_lca", {"lca/final_lca.md": "released", "lca/review.json": "{}"}, [second, review])
    flagged = [t for t in actions(root) if t.startswith(f"final_lca {short(lca)}")]
    assert len(flagged) == 1 and short(second) in flagged[0] and f"涵蓋：{short(first)}" in flagged[0]
    assert "Final-LCA 自己的檔案裡有 review.json，但那不算審查" in flagged[0]
    new_review = review_of(root, "r2", second, source)
    save(root, "final_lca", {"lca2/final_lca.md": "released"}, [second, new_review, lca])
    assert not any(t.startswith("final_lca ") for t in actions(root))


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def test_a_delivery_that_is_not_bound_says_so_in_its_own_receipt(ctx):
    root = ctx.directory
    source = save(root, "notes", {"source.txt": "The observation.\n"})
    report = save(root, "report", {"report.md": "The claim.\n"}, [source])
    lca = save(root, "final_lca", {"final_lca.md": "released"}, [report])
    (root / "user.md").write_text("delivery", encoding="utf-8")
    tool = next(t for t in TOOLS if t.name == "research_record")
    receipt = json.loads(tool.execute({"kind": "user_report", "title": "delivery", "files": ["user.md"],
                                       "depends_on": [report["record_path"], lca["record_path"]]}, ctx).output)
    assert any("lacks a saved review" in issue for issue in receipt["delivery_issues"])
    assert "before the final answer" in receipt["delivery_note"]
