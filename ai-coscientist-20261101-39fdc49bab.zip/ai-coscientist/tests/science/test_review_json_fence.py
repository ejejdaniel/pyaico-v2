"""Approved JSON-wrapper boundaries, with offline scripted completions only.

These tests prove parsing, persistence and handoff mechanics, not the validity
of any scientific judgment or a completed real-model research workflow.
"""

from copy import deepcopy
import json
from unittest.mock import patch

import httpx
import pytest

from opencode.provider import Completion, ToolCall
from researchkit import reviewer
import test_research_review as review_cases
from test_research_review_temperature_retry import install_replies, reasoning_only
from test_research_review_two_stage import initial_files, run_directory


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Fence boundary tests must not use a real model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(reviewer, "complete_once", forbidden)


@pytest.fixture
def packet():
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def fenced(text, opening="\n", closing="\n", margin=""):
    return margin + "```json" + opening + text + closing + "```" + margin


def validate(packet, text, prepared=None):
    if prepared is None:
        prepared = reviewer._input(packet.args, packet.ctx)[2:]
    return reviewer._validate_completion(Completion(text=text, finish_reason="stop"),
                                         packet.args, packet.ctx, *prepared)


@pytest.mark.parametrize("opening,closing", [("\n", "\n"), ("\r\n", "\r\n"),
                                            ("\n", "\r\n"), ("\r\n", "\n")])
@pytest.mark.parametrize("margin", ["", " \t\r\n\t "])
def test_exact_single_fence_preserves_inner_text_and_each_parser_type(packet, opening, closing, margin):
    inner = " \t\r\n" + json.dumps(packet.model_value, ensure_ascii=False, indent=2) + "\r\n\t "
    text = fenced(inner, opening, closing, margin)
    prepared = reviewer._input(packet.args, packet.ctx)[2:]
    expected = validate(packet, inner, prepared)
    with patch.object(reviewer.json, "loads", wraps=json.loads) as parse:
        assert validate(packet, text, prepared) == expected
        assert parse.call_args_list[0].args[0] == inner.encode("utf-8")
        assert type(parse.call_args_list[0].args[0]) is bytes
    expected_handoff = reviewer._candidate_handoff(inner, prepared[-1])
    with patch.object(reviewer.json, "loads", wraps=json.loads) as parse:
        assert reviewer._candidate_handoff(text, prepared[-1]) == expected_handoff
        assert parse.call_args_list[0].args[0] == inner
        assert type(parse.call_args_list[0].args[0]) is str


@pytest.mark.parametrize("wrap_initial,wrap_final", [(False, False), (True, False),
                                                   (False, True), (True, True)])
@pytest.mark.parametrize("required_selector", [False, True])
def test_two_stage_save_is_exact_and_handoff_remains_blinded(
        packet, monkeypatch, wrap_initial, wrap_final, required_selector):
    initial_value = deepcopy(packet.model_value)
    initial_value["checks"][0].update(decision="contradicted", reason="INITIAL_PRIVATE_REASON_界")
    if required_selector:
        packet.args["required_subjects"] = [deepcopy(packet.value["checks"][0]["subject"])]
        initial_value["checks"][0]["subject"] = {"required_subject": 1}
    initial_body = json.dumps(initial_value, ensure_ascii=False, indent=2)
    final_body = packet.completion().text
    initial = fenced(initial_body, "\r\n", "\r\n", " \t\r\n") if wrap_initial else initial_body
    final = fenced(final_body) if wrap_final else final_body
    initial_public = deepcopy(packet.value)
    initial_public["checks"][0].update(decision="contradicted", reason="INITIAL_PRIVATE_REASON_界")
    observed = []

    def at_dispatch(ctx, kwargs):
        observed.append(kwargs["messages"][0]["content"])
        if len(observed) == 2:
            saved = initial_files(packet)
            assert saved["response.txt"] == initial.encode("utf-8")
            assert saved["review.json"] == (json.dumps(initial_public, ensure_ascii=False,
                                                      separators=(",", ":")) + "\n").encode("utf-8")
            assert json.loads(saved["arguments.json"]) == packet.args
            assert not (run_directory(packet) / ".initial.pending").exists()

    model = install_replies(monkeypatch, [Completion(text=initial, finish_reason="stop"),
                                          Completion(text=final, finish_reason="stop")],
                            after_call=at_dispatch)
    result = reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    assert result.output == json.dumps(packet.value, ensure_ascii=False, separators=(",", ":")) + "\n"
    assert initial_files(packet)["response.txt"] == initial.encode("utf-8")
    handoff = json.loads(observed[1].split(reviewer.HANDOFF_LABEL + "\n", 1)[1])
    expected_subject = initial_value["checks"][0]["subject"]
    assert handoff == {"checks": [{"subject": expected_subject,
                                   "evidence": [{**packet.model_value["checks"][0]["evidence"][0],
                                                 "quote": packet.value["checks"][0]["evidence"][0]["quote"]}]}]}
    assert "INITIAL_PRIVATE_REASON_界" not in observed[1]
    assert '"decision"' not in json.dumps(handoff) and '"reason"' not in json.dumps(handoff)
    assert set(result.metadata) == {"host_note"} and result.attachments == []


@pytest.mark.parametrize("opening,closing", [
    ("```\n", "\n```"), ("```JSON\n", "\n```"), ("```python\n", "\n```"),
    ("```json note\n", "\n```"), ("```json \n", "\n```"), ("```json\t\n", "\n```"),
    ("````json\n", "\n```"), ("```json\n", "\n````"),
    ("~~~json\n", "\n~~~"), ("```json ", "```"),
    ("```json\n", ""), ("", "\n```"),
    ("Explanation\n```json\n", "\n```"), ("```json\n", "\n```\nExplanation"),
    ("```json\r", "\n```"), ("```json\n", "\r```"),
    ("```json\n", "\n ```"), ("```json\n", "\n``` note"),
    ("\u00a0```json\n", "\n```"), ("```json\n", "\n```\u2003"),
    ("\ufeff```json\n", "\n```"), ("```json\n", "\n```\ufeff"),
    ("\v```json\n", "\n```"), ("```json\n", "\n```\f"),
])
def test_unapproved_outer_forms_fail_at_both_parse_sites(packet, opening, closing):
    text = opening + packet.completion().text + closing
    prepared = reviewer._input(packet.args, packet.ctx)[2:]
    with pytest.raises(ValueError):
        validate(packet, text, prepared)
    with pytest.raises(ValueError):
        reviewer._candidate_handoff(text, prepared[-1])


@pytest.mark.parametrize("case", ["two-fences", "nested-fence", "two-values", "explanation",
                                  "broken-json", "comment", "json5", "empty", "null", "array",
                                  "duplicate-checks", "duplicate-quote"])
@pytest.mark.parametrize("stage", [1, 2])
def test_invalid_nonblank_fenced_answers_stop_without_recovery(packet, monkeypatch, case, stage):
    good = packet.completion().text
    bad = {
        "two-fences": fenced(good) + "\n" + fenced(good),
        "nested-fence": fenced(fenced(good)),
        "two-values": fenced(good + "\n" + good),
        "explanation": fenced("Explanation\n" + good),
        "broken-json": fenced(good[:-1]),
        "comment": fenced("// commentary\n" + good),
        "json5": fenced("{checks: []}"),
        "empty": fenced(""), "null": fenced("null"), "array": fenced("[]"),
        "duplicate-checks": fenced(good.replace('"checks":', '"checks": [], "checks":', 1)),
        "duplicate-quote": fenced(good.replace('"quote":', '"quote": "other", "quote":', 1)),
    }[case]
    replies = ([Completion(text=fenced(good), finish_reason="stop")] if stage == 2 else [])
    replies.append(reasoning_only(text=bad))
    model = install_replies(monkeypatch, replies)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == stage
    assert (run_directory(packet) / "initial").exists() == (stage == 2)
    if stage == 2:
        assert initial_files(packet)["response.txt"] == fenced(good).encode("utf-8")


def test_literal_triple_backticks_in_source_and_json_strings_are_not_extra_fences(packet, monkeypatch):
    quote = "Literal ```json and ``` remain source characters."
    record = packet.save({"backticks.txt": quote + "\n"})
    locator = packet.locator(record, "backticks.txt")
    packet.args.update(reviewed_refs=[record["record_path"]], files=[locator])
    value = {"checks": [{"subject": {"file_id": "F1", "start_line": 1, "end_line": 1, "quote": quote},
                         "evidence": [], "decision": "unassessed",
                         "reason": "Literal ```\n```json and escaped \\\" quotes stay unchanged."}]}
    text = fenced(json.dumps(value, ensure_ascii=False), "\r\n", "\r\n")
    model = install_replies(monkeypatch, [Completion(text=text, finish_reason="stop")] * 2)
    result = json.loads(reviewer.execute(packet.args, packet.ctx).output)
    assert model.call_count == 2
    assert result["checks"] == [{**value["checks"][0], "subject": {**locator, "quote": quote}}]
    assert initial_files(packet)["response.txt"] == text.encode("utf-8")


@pytest.mark.parametrize("failure", ["length", "unknown", "tool_calls"])
def test_complete_fence_cannot_bypass_completion_status(packet, monkeypatch, failure):
    completion = Completion(text=fenced(packet.completion().text),
                            finish_reason="stop" if failure == "tool_calls" else failure,
                            reasoning_content="Private reasoning cannot repair a nonblank answer.",
                            tool_calls=[ToolCall("bad", "read", {})] if failure == "tool_calls" else [])
    model = install_replies(monkeypatch, [completion])
    with pytest.raises(ValueError, match="complete nonempty final answer without tool calls"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


@pytest.mark.parametrize("route", ["recover-initial", "recover-followup", "exhausted"])
def test_fences_do_not_consume_or_expand_shared_recovery(packet, monkeypatch, route):
    good = Completion(text=fenced(packet.completion().text), finish_reason="stop")
    replies = {"recover-initial": [reasoning_only(), good, good],
               "recover-followup": [good, reasoning_only(), good],
               "exhausted": [reasoning_only(), good, reasoning_only()]}[route]
    model = install_replies(monkeypatch, replies)
    if route == "exhausted":
        with pytest.raises(ValueError):
            reviewer.execute(packet.args, packet.ctx)
    else:
        assert json.loads(reviewer.execute(packet.args, packet.ctx).output) == packet.value
    assert model.call_count == 3
    calls = model.call_args_list
    recovered = [index for index, call in enumerate(calls) if "recovery_temperature" in call.kwargs]
    assert recovered == ([2] if route == "recover-followup" else [1])
    assert calls[recovered[0]].kwargs["recovery_temperature"] == 0.6
    assert initial_files(packet)["response.txt"] == good.text.encode("utf-8")


@pytest.mark.parametrize("damage", ["mismatched-quote", "outside-lines", "outside-files"])
def test_fence_cannot_bypass_bound_claim_validation(packet, monkeypatch, damage):
    # A missed required subject is carried to stage two, not a validation failure (test_research_review_required_subjects).
    value = deepcopy(packet.model_value)
    subject = value["checks"][0]["subject"]
    if damage == "mismatched-quote":
        subject["quote"] = "An invented source quotation."
    elif damage == "outside-lines":
        subject["end_line"] = 99
    else:
        subject["file_id"] = "F999"
    model = install_replies(monkeypatch, [Completion(text=fenced(packet.completion(value).text), finish_reason="stop")])
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


def test_fence_cannot_bypass_frozen_source_integrity(packet, monkeypatch):
    target = packet.snapshot(packet.source, "source.txt")
    original = target.read_bytes()

    def mutate(ctx, kwargs):
        target.write_bytes(b"X" * len(original))

    model = install_replies(monkeypatch, [Completion(text=fenced(packet.completion().text), finish_reason="stop")],
                            after_call=mutate)
    with pytest.raises(ValueError, match="snapshot changed"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()


def test_only_assembled_output_has_the_existing_inclusive_byte_limit(packet):
    prepared = reviewer._input(packet.args, packet.ctx)[2:]
    value = deepcopy(packet.model_value)
    value["checks"][0]["reason"] = "界\n\"\\"
    output = validate(packet, packet.completion(value).text, prepared)
    value["checks"][0]["reason"] += "x" * (262144 - len(output.encode("utf-8")))
    inner = packet.completion(value).text
    # Formatting and outer ASCII whitespace may make raw content larger than
    # the public output cap; this approved change adds no raw response cap.
    text = fenced(inner, margin=" " * 1024)
    assert len(text.encode("utf-8")) > 262144
    assert len(validate(packet, text, prepared).encode("utf-8")) == 262144
    value["checks"][0]["reason"] += "x"
    with pytest.raises(ValueError, match="262144-byte output limit"):
        validate(packet, fenced(packet.completion(value).text), prepared)


def test_bare_json_keeps_existing_bytes_versus_str_bom_behavior(packet):
    prepared = reviewer._input(packet.args, packet.ctx)[2:]
    text = "\ufeff" + packet.completion().text
    assert json.loads(validate(packet, text, prepared)) == packet.value
    with pytest.raises(json.JSONDecodeError, match="BOM"):
        reviewer._candidate_handoff(text, prepared[-1])
