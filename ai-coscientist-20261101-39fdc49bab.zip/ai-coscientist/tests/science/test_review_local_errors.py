"""A reviewer error affects only its own check, and a retry reuses a saved first stage; scripted replies only."""

import json
from unittest.mock import Mock, patch

import httpx
import pytest

from opencode.provider import Completion
from researchkit import reviewer
import test_research_review as review_cases

LINES = ["三個代理公式都以可追溯的物理量（產酸質量、酯疏水性、酚基供氫）構成，並以可執行程式算出數值。",
         "但這個排序與實測 EOP 的優劣相反，且 n=2 無法判定這是混雜還是公式結構錯誤。",
         "第一組候選甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥甲A。",
         "第一組候選甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥甲B。"]


@pytest.fixture
def packet(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Review tests never use a real model or network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def selected(packet):
    record = packet.save({"report.md": "\n".join(LINES) + "\n"})
    return {"scope": "Check only the explicitly selected report lines.", "reviewed_refs": [record["record_path"]],
            "files": [packet.locator(record, "report.md")]}


def check(quote, line):
    return {"subject": {"file_id": "F1", "start_line": line, "end_line": line, "quote": quote},
            "evidence": [], "decision": "unassessed", "reason": "Test boundary only."}


def run(packet, args, *replies):
    model = Mock(side_effect=[reply if isinstance(reply, Completion) else
                              Completion(text=json.dumps(reply, ensure_ascii=False), finish_reason="stop")
                              for reply in replies])
    packet.next_call()
    with patch.object(reviewer, "complete_once", model):
        return reviewer.execute(args, packet.ctx), model


def test_a_quotation_with_one_retyped_character_is_repaired_from_the_file(packet):
    args = selected(packet)
    typo = LINES[0].replace("供氫", "供氧")  # the v16 slip: one character retyped
    reply = {"checks": [check(typo, 1), check(LINES[1], 2)]}
    result, model = run(packet, args, reply, reply)
    output = json.loads(result.output)
    assert output["review"]["checks"][0]["subject"]["quote"] == LINES[0]
    repair, = output["quote_repairs"]
    assert repair == {"cited": typo, "file": LINES[0], "retyped_characters": 1}
    assert model.call_count == 2 and "dropped_checks" not in output


def test_a_near_match_at_two_places_is_not_guessed(packet):
    args = selected(packet)
    ambiguous = LINES[2][:-2] + "C。"  # one character away from both candidate lines
    reply = {"checks": [check(ambiguous, 3), check(LINES[0], 1), check(LINES[1], 2), check(LINES[3], 4)]}
    result, _ = run(packet, args, reply, reply)
    output = json.loads(result.output)
    assert len(output["review"]["checks"]) == 3 and "quote_repairs" not in output
    assert output["dropped_checks"]["final"][0]["check"] == 1


def test_a_retry_with_the_same_arguments_reuses_the_saved_first_stage(packet):
    args = selected(packet)
    good = {"checks": [check(LINES[0], 1), check(LINES[1], 2)]}
    with pytest.raises(ValueError, match=r"(?s)初審已保存、複核未完成.*沿用這次的初審") as failed:
        run(packet, args, good, {"checks": [{"subject": {"file_id": "F1"}}]})
    assert "No check in the review output is usable" in str(failed.value)
    result, model = run(packet, args, good)  # only the second stage is generated
    assert model.call_count == 1
    assert json.loads(result.output)["checks"][1]["subject"]["quote"] == LINES[1]
    assert "first stage was reused" in result.metadata["host_note"]
    # Once these arguments have a finished review, a new call is a new review.
    _, fresh = run(packet, args, good, good)
    assert fresh.call_count == 2
