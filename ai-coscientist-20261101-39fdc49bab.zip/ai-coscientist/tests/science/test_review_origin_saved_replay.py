"""Replay saved real sources and reviews without generating a scientific answer.

The saved reviews predate the added native sources. Retaining their decisions
proves that provenance bookkeeping does not rewrite judgments; it cannot prove
that those decisions are valid for either the old or expanded evidence packet.
All publication and deliberate corruption happen in temporary copies only.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import socket
import sqlite3
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.permission import Broker, Rule
from opencode.provider import Completion
from opencode.store import Store
from researchkit import records, reviewer
from researchkit.tools import _publish


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "outputs/review_selector_handoff_real_20261023_v1"
DATABASE = ROOT / "outputs/method_exploration_real_20261023_v1/state/opencode/opencode.db"
SESSION_ID = "ses_1792751020351fac46230"
USER_ID = "msg_1792751020353fae2e714"
TOOL_IDS = ("msg_179275486150151227adc", "msg_17927548732840f73d358", "msg_1792754884417a70cafbc")


def _json(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _hashes(paths):
    return {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def _checks(saved):
    # The saved initial response is fenced; the final response is bare JSON.
    # Parse that existing presentation without changing either replayed answer.
    text = saved["text"]
    if text.startswith("```json\n"):
        assert text.endswith("\n```")
        text = text[len("```json\n"):-len("\n```")]
    return json.loads(text)["checks"]


def _completion(saved):
    assert saved["finish_reason"] == "stop" and saved["tool_calls"] == []
    return Completion(text=saved["text"], finish_reason=saved["finish_reason"],
                      reasoning_content=saved["reasoning_content"])


def _blocks(message):
    lines = message.split("\n")
    return {json.loads(lines[index + 1])["file_id"]:
            (json.loads(lines[index + 1]), lines[index + 2], json.loads(lines[index + 3]))
            for index, line in enumerate(lines) if line == "Selected frozen file:"}


def _initial_files(packet):
    folder, = (packet.workspace / ".research/review-runs").glob("*/initial")
    return {path.name: path.read_bytes() for path in folder.iterdir()}


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Saved origin replay must never execute a model or network request")

    monkeypatch.setattr(reviewer, "complete_once", forbidden)
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)


@pytest.fixture
def saved_packet(tmp_path):
    required = [SOURCE / f"response-{number:03}.json" for number in (4, 5, 6)] + [DATABASE]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        pytest.skip("Saved real source unavailable; no fabricated substitute: " + ", ".join(missing))
    database_files = {path for path in DATABASE.parent.iterdir()
                      if path.name == DATABASE.name or path.name.startswith(DATABASE.name + "-")}
    originals = _hashes([*required, *database_files])
    store = None
    try:
        call, = [item for item in _json(SOURCE / "response-004.json")["tool_calls"]
                 if item["name"] == "research_review"]
        # This reviewer-local replay does not execute or revise the saved plan.
        args = {key: deepcopy(value) for key, value in call["arguments"].items() if key != "revision_plan"}
        assert len(args["files"]) == 5
        original_locators = deepcopy(args["files"])
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        old_content = {}
        for locator in original_locators:
            manifest = SOURCE / "baseline/workspace" / locator["record_ref"]
            if not manifest.is_file():
                pytest.skip(f"Saved selected manifest unavailable; no substitute: {manifest}")
            entry, = [item for item in _json(manifest)["files"] if item["source_path"] == locator["source_path"]]
            snapshot = manifest.parent / entry["snapshot"]
            if not snapshot.is_file():
                pytest.skip(f"Saved selected snapshot unavailable; no substitute: {snapshot}")
            originals.update(_hashes([manifest, snapshot]))
            old_content[locator["record_ref"], locator["source_path"]] = snapshot.read_bytes()
            for source, target in ((manifest, workspace / locator["record_ref"]),
                                   (snapshot, workspace / Path(locator["record_ref"]).parent / entry["snapshot"])):
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
        copy_database = tmp_path / "session-copy.db"
        original_connection = sqlite3.connect(DATABASE.resolve().as_uri() + "?mode=ro", uri=True)
        copied_connection = sqlite3.connect(copy_database)
        try:
            original_connection.backup(copied_connection)
            present = {row[0] for row in copied_connection.execute(
                "SELECT id FROM message WHERE session_id=?", (SESSION_ID,))}
            if missing_ids := {USER_ID, *TOOL_IDS} - present:
                pytest.skip("Saved native messages unavailable; no substitute: " + ", ".join(sorted(missing_ids)))
            changed = copied_connection.execute("UPDATE session SET directory=? WHERE id=?",
                                                (str(workspace), SESSION_ID)).rowcount
            assert changed == 1
            copied_connection.commit()
        finally:
            original_connection.close()
            copied_connection.close()
        store = Store(copy_database)
        ctx = SimpleNamespace(
            directory=workspace, worktree=workspace, read_files=set(), session_id=SESSION_ID,
            message_id="saved-origin-replay", call_id="offline-origin-review",
            agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
            app=SimpleNamespace(store=store, permissions=Broker(auto=True)),
        )
        tool_paths = [f".opencode/history/{SESSION_ID}/tools/{message_id}.json" for message_id in TOOL_IDS]
        user_path = f".opencode/history/{SESSION_ID}/conversation/{USER_ID}.json"
        assert not (workspace / ".opencode").exists()
        published = json.loads(_publish({
            "kind": "notes", "title": "Saved real native sources for offline origin-boundary replay",
            "files": [*tool_paths, user_path], "depends_on": [],
        }, ctx).output)
        # Production publication rebuilds frozen copies from SQLite without
        # recreating editable workspace projections or reexecuting the tools.
        assert not (workspace / ".opencode").exists()
        native_manifest = _json(workspace / published["record_path"])
        assert set(native_manifest) == {"kind", "title", "files", "depends_on"}
        assert {entry["source_path"] for entry in native_manifest["files"]} == {
            *tool_paths, user_path, *(str(Path(path).with_suffix(".txt")).replace("\\", "/") for path in tool_paths),
        }
        native_locators = [{"record_ref": published["record_path"], "source_path": entry["source_path"]}
                           for entry in native_manifest["files"]]
        args["files"].extend(native_locators)
        args["commission_files"].append({"record_ref": published["record_path"], "source_path": user_path})
        yield SimpleNamespace(
            args=args, ctx=ctx, workspace=workspace, store=store, copy_database=copy_database,
            original_locators=original_locators, old_content=old_content, native=published,
            native_manifest=native_manifest, native_locators=native_locators,
            tool_paths=tool_paths, user_path=user_path,
            initial=_json(SOURCE / "response-005.json"), final=_json(SOURCE / "response-006.json"),
        )
    finally:
        if store is not None:
            store.close()
        assert {path for path in DATABASE.parent.iterdir()
                if path.name == DATABASE.name or path.name.startswith(DATABASE.name + "-")} == database_files
        assert _hashes(originals) == originals, "Original DB, saved responses and selected frozen sources must remain unchanged"


def _replay(monkeypatch, packet):
    sent = []

    def complete(ctx, *, system, messages, **kwargs):
        assert ctx is packet.ctx and len(sent) < 2
        sent.append({"system": system, "messages": deepcopy(messages)})
        return _completion(packet.initial if len(sent) == 1 else packet.final)

    model = Mock(side_effect=complete)
    monkeypatch.setattr(reviewer, "complete_once", model)
    return model, sent


def test_real_saved_sources_reach_both_stages_without_rewriting_saved_judgments(saved_packet, monkeypatch):
    packet = saved_packet
    model, sent = _replay(monkeypatch, packet)
    result = reviewer.execute(packet.args, packet.ctx)
    assert model.call_count == 2
    first, second = [item["messages"][0]["content"] for item in sent]
    assert second.startswith(first + "\n\n" + reviewer.HANDOFF_LABEL + "\n")
    assert _blocks(first) == _blocks(second)
    blocks = _blocks(first)
    for number, locator in enumerate(packet.original_locators, start=1):
        meta, _, lines = blocks[f"F{number}"]
        assert {key: meta[key] for key in ("record_ref", "source_path")} == locator
        assert meta["origin"]["status"] == "snapshot_only"
        text = packet.old_content[locator["record_ref"], locator["source_path"]].decode("utf-8-sig")
        expected = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if expected[-1] == "":
            expected.pop()
        assert lines == list(map(list, enumerate(expected, start=1)))
    by_path = {meta["source_path"]: (meta, notice, lines) for meta, notice, lines in blocks.values()}
    messages = {item["id"]: item for item in packet.store.messages(SESSION_ID)}
    for path, message_id in zip(packet.tool_paths, TOOL_IDS):
        meta, _, lines = by_path[path]
        assert meta["origin"]["status"] == "tool_match" and meta["origin"]["content"] == "receipt"
        assert meta["origin"]["message_id"] == message_id and meta["origin"]["tool_name"] == "bash"
        frozen = json.loads("\n".join(line for _, line in lines))
        assert frozen[1] == messages[message_id]
        assert frozen[0]["tool_calls"] == [next(call for call in messages[frozen[0]["id"]]["tool_calls"]
                                               if call["id"] == messages[message_id]["tool_call_id"])]
        text_path = str(Path(path).with_suffix(".txt")).replace("\\", "/")
        assert by_path[text_path][0]["origin"]["content"] == "stored_text"
    user_meta, user_notice, user_lines = by_path[packet.user_path]
    assert user_meta["origin"]["status"] == "message_match"
    assert user_meta["origin"]["message_id"] == USER_ID
    assert "not authenticated human authorship" in user_notice
    assert json.loads("\n".join(line for _, line in user_lines)) == {
        key: value for key, value in messages[USER_ID].items() if key not in {"reasoning", "reasoning_content"}}
    assert len(blocks) == 12
    public = json.loads(result.output)
    assert set(public) == {"reviewed_refs", "checks"}
    assert [(check["decision"], check["reason"]) for check in public["checks"]] == [
        (check["decision"], check["reason"]) for check in _checks(packet.final)]
    assert [check["subject"] for check in public["checks"]] == packet.args["required_subjects"]
    handoff = json.loads(second.split(reviewer.HANDOFF_LABEL + "\n", 1)[1])
    assert [check["subject"] for check in handoff["checks"]] == [
        check["subject"] for check in _checks(packet.initial)]
    assert all(set(check) == {"subject", "evidence"} for check in handoff["checks"])
    saved = _initial_files(packet)
    assert set(saved) == {"arguments.json", "response.txt", "review.json"}
    assert saved["response.txt"] == packet.initial["text"].encode("utf-8")
    assert [(check["decision"], check["reason"]) for check in json.loads(saved["review.json"])["checks"]] == [
        (check["decision"], check["reason"]) for check in _checks(packet.initial)]


def test_saved_tool_text_without_explicitly_selected_json_remains_snapshot_only(saved_packet, monkeypatch):
    packet = saved_packet
    args = deepcopy(packet.args)
    texts = [entry for entry in packet.native_locators if entry["source_path"].endswith(".txt")]
    args["files"] = deepcopy(packet.original_locators) + texts
    args["commission_files"] = [entry for entry in args["commission_files"] if entry["source_path"] != packet.user_path]
    no_db = Mock(side_effect=AssertionError("Unselected paired JSON must not trigger native DB reads"))
    monkeypatch.setattr(packet.store, "messages", no_db)
    _, message, *_ = reviewer._input(args, packet.ctx)
    blocks = _blocks(message)
    assert len(blocks) == 8
    for index in range(6, 9):
        origin = blocks[f"F{index}"][0]["origin"]
        assert origin["status"] == "snapshot_only" and origin["content"] == "file"
        assert all(value is None for key, value in origin.items() if key not in {"status", "content"})
    no_db.assert_not_called()


@pytest.mark.parametrize("damage", ["mismatched_content", "missing_db_message"])
def test_damaged_saved_native_source_stops_before_any_model_or_checkpoint(saved_packet, monkeypatch, damage):
    packet = saved_packet
    path = packet.tool_paths[0]
    if damage == "mismatched_content":
        entry, = [item for item in packet.native_manifest["files"] if item["source_path"] == path]
        original = packet.workspace / Path(packet.native["record_path"]).parent / entry["snapshot"]
        changed = _json(original)
        changed[1]["content"] += "\nDeliberate temporary-copy corruption for boundary testing."
        target = packet.workspace / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(changed), encoding="utf-8")
        # Create a self-consistent content-addressed negative fixture. This
        # intentionally bypasses native publication so review must catch the
        # DB mismatch, rather than merely rejecting a changed snapshot hash.
        corrupt = records.publish(packet.workspace, kind="notes", title="Deliberately damaged copied receipt",
                                  files=[path], depends_on=[])
        packet.args["files"].append({"record_ref": corrupt["record_path"], "source_path": path})
    else:
        with sqlite3.connect(packet.copy_database) as copied:
            assert copied.execute("DELETE FROM message WHERE id=? AND session_id=?",
                                  (TOOL_IDS[0], SESSION_ID)).rowcount == 1
    model, _ = _replay(monkeypatch, packet)
    with pytest.raises(ValueError):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert not (packet.workspace / ".research/review-runs").exists()


def test_saved_initial_three_files_survive_a_changed_source_before_followup(saved_packet, monkeypatch):
    packet = saved_packet
    committed = []
    save_initial = reviewer._save_initial

    def save_then_damage(*args, **kwargs):
        text = save_initial(*args, **kwargs)
        committed.append(_initial_files(packet))
        entry, = [item for item in packet.native_manifest["files"] if item["source_path"] == packet.tool_paths[0]]
        snapshot = packet.workspace / Path(packet.native["record_path"]).parent / entry["snapshot"]
        snapshot.write_bytes(snapshot.read_bytes() + b" ")
        return text

    monkeypatch.setattr(reviewer, "_save_initial", save_then_damage)
    model, _ = _replay(monkeypatch, packet)
    with pytest.raises(ValueError, match="初審已保存、複核未完成"):
        reviewer.execute(packet.args, packet.ctx)
    model.assert_called_once()
    assert _initial_files(packet) == committed[0]
    assert committed[0]["response.txt"] == packet.initial["text"].encode("utf-8")
