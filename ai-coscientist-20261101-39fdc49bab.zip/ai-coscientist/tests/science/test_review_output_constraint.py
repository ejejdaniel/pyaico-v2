"""Review and mind-map replies are constrained at generation time, with a fallback and diagnosable failures."""

import json

import httpx
import jsonschema
import pytest

from opencode.provider import ProviderError
from researchkit import review_provider, reviewer
from researchkit.mindmap_schema import MAP_SCHEMA
from test_review_provider import context, install_transport, offline, wire_response  # noqa: F401

SCHEMA = ("review_checks", {"type": "object", "properties": {"checks": {"type": "array"}},
                            "required": ["checks"], "additionalProperties": False})


def call(ctx, frozen):
    return review_provider.complete_once(ctx, system="Review instructions",
                                         messages=[{"role": "user", "content": "evidence"}],
                                         frozen=frozen, response_schema=SCHEMA)


def test_openai_request_carries_the_strict_json_schema(monkeypatch):
    ctx, _ = context()
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        return wire_response("openai", text='{"checks": []}')

    install_transport(monkeypatch, receive)
    frozen = {}
    assert call(ctx, frozen).text == '{"checks": []}'
    assert sent[0]["response_format"] == {"type": "json_schema", "json_schema": {
        "name": "review_checks", "strict": True, "schema": SCHEMA[1]}}
    assert frozen["output_constraint"] == "json_schema"


def test_a_server_that_rejects_the_schema_gets_the_same_request_without_it_once(monkeypatch):
    ctx, _ = context()
    sent = []

    def receive(request):
        body = json.loads(request.content)
        sent.append(body)
        if "response_format" in body:
            return httpx.Response(400, json={"error": "response_format is not supported"})
        return wire_response("openai", text="free reply")

    install_transport(monkeypatch, receive)
    frozen = {}
    assert call(ctx, frozen).text == "free reply"
    assert ["response_format" in body for body in sent] == [True, False]
    assert {k: v for k, v in sent[0].items() if k != "response_format"} == sent[1]
    assert frozen["output_constraint"].startswith("free; the server rejected json_schema")
    # Later stages of the same invocation do not ask again.
    assert call(ctx, frozen).text == "free reply"
    assert ["response_format" in body for body in sent] == [True, False, False]
    assert review_provider.output_constraint(frozen).startswith("output constraint: free")


@pytest.mark.parametrize("status", [401, 429, 500, 503])
def test_other_server_errors_are_not_treated_as_an_unsupported_schema(monkeypatch, status):
    ctx, _ = context()
    sent = []

    def receive(request):
        sent.append(request)
        return httpx.Response(status, json={"error": "unavailable"})

    install_transport(monkeypatch, receive)
    with pytest.raises(ProviderError):
        call(ctx, {})
    assert len(sent) == 1


def test_anthropic_requests_are_sent_unconstrained(monkeypatch):
    ctx, _ = context(api="anthropic")
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        return wire_response("anthropic")

    install_transport(monkeypatch, receive)
    call(ctx, {})
    assert "response_format" not in sent[0]


def test_generation_schema_drops_only_length_limits():
    schema = review_provider.generation_schema(MAP_SCHEMA)
    text = json.dumps(schema)
    assert "minLength" not in text and "maxLength" not in text
    assert "maxItems" in text and schema["required"] == MAP_SCHEMA["required"]
    assert "minLength" in json.dumps(MAP_SCHEMA)  # the validation schema is unchanged


def test_json_error_position_points_into_the_complete_saved_reply():
    body = '{"checks": [\n  {"a": 1}}\n]}'
    text = "```json\n" + body + "\n```"
    with pytest.raises(json.JSONDecodeError) as error:
        json.loads(reviewer._unwrap_json_fence(text))
    detail = review_provider.json_error_detail(text, error.value)
    position = text.index("}}") + 1
    assert f"(char {position} of {len(text)})" in detail
    assert "line 3, column 11" in detail
    assert detail.startswith(error.value.msg)
    assert "text from there: '}\\n]}\\n```'" in detail


def test_reviewer_schema_puts_reason_before_decision_and_limits_ids():
    selection = {"F1": {}, "F2": {}}
    schema = reviewer.output_schema({"required_subjects": [{}, {}]}, selection)
    check = schema["properties"]["checks"]["items"]
    assert list(check["properties"]) == ["subject", "evidence", "reason", "decision"]
    assert check["properties"]["evidence"]["items"]["properties"]["file_id"]["enum"] == ["F1", "F2"]
    good = {"checks": [
        {"subject": {"file_id": "F1", "start_line": 1, "end_line": 2, "quote": "q"},
         "evidence": [{"file_id": "F2", "start_line": 3, "end_line": 3}], "reason": "r", "decision": "supported"},
        {"subject": {"required_subject": 2}, "evidence": [], "reason": "r", "decision": "unassessed"}]}
    jsonschema.validate(good, schema)
    for bad in ({"file_id": "F9", "start_line": 1, "end_line": 1, "quote": "q"}, {"required_subject": 3}):
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate({"checks": [{**good["checks"][0], "subject": bad}]}, schema)
    # Without required subjects the selector form is not offered.
    plain = reviewer.output_schema({}, selection)["properties"]["checks"]["items"]["properties"]["subject"]
    assert "anyOf" not in plain and "quote" in plain["required"]
