"""S22 transport boundaries, using real provider encoding and offline HTTP."""

import asyncio
import json
import threading
import time
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode import provider as provider_module
from opencode.agent import Agent
from opencode.provider import Client, Completion, ProviderError
from researchkit import review_provider


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Review tests must not open real network connections")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    monkeypatch.setattr(provider_module, "_temperature_catalog", None)


def context(*, api="openai", capable=True, temperature=0, model="current-model", key="test-key",
            include_usage=True):
    definition = {"limit": {"output": 137}, "options": {"top_p": 0.7, "reasoningEffort": "low"}}
    definition["options"]["include_stream_usage"] = include_usage
    if capable is not None:
        definition["temperature"] = capable
    client = Client(SimpleNamespace(get=lambda _: None), {"model": "review/old-config-model", "provider": {
        "review": {"api": api, "options": {"baseURL": "https://review.invalid/v1", "apiKey": key},
                   "models": {model: definition}},
    }})
    # Invoking the common retrying entry point would violate the review boundary.
    client.complete = Mock(side_effect=AssertionError("Review must not call Client.complete"))
    parent = threading.Event()
    store = SimpleNamespace(get_session=Mock(return_value={"model": f"review/{model}"}))
    app = SimpleNamespace(provider=client, store=store, abort_event=Mock(return_value=parent))
    return SimpleNamespace(app=app, session_id="current-session",
                           agent=Agent("build", model="review/old-agent-model", temperature=temperature)), parent


def response(api, *, text="review text", reason=None):
    if api == "openai":
        return {"choices": [{"message": {"content": text, "reasoning_content": "private reasoning"},
                             "finish_reason": reason or "stop"}], "usage": {"prompt_tokens": 11}}
    return {"content": [{"type": "thinking", "thinking": "private reasoning"},
                        {"type": "text", "text": text}],
            "stop_reason": reason or "end_turn", "usage": {"input_tokens": 11}}


def sse_event(delta=None, *, reason=None, usage=None):
    value = {"choices": [{"delta": delta or {}, "finish_reason": reason}]}
    if usage is not None:
        value["usage"] = usage
    return ("data: " + json.dumps(value) + "\n\n").encode()


def wire_response(api, *, text="review text", reason=None):
    if api == "anthropic":
        return httpx.Response(200, json=response(api, text=text, reason=reason))
    return httpx.Response(
        200, headers={"content-type": "text/event-stream"},
        content=(sse_event({"reasoning_content": "private reasoning"})
                 + sse_event({"content": text}, reason=reason or "stop", usage={"prompt_tokens": 11})
                 + b"data: [DONE]\n\n"),
    )


def install_transport(monkeypatch, handler, *, transport_class=httpx.MockTransport):
    original = httpx.AsyncClient
    monkeypatch.setattr(provider_module.httpx, "AsyncClient",
                        lambda **kwargs: original(transport=transport_class(handler), **kwargs))


def assert_joined():
    assert not any(t.name in {"opencode-provider-request", "researchkit-review-deadline"}
                   for t in threading.enumerate())


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("capable", [False, True])
@pytest.mark.parametrize("include_usage", [False, True])
def test_actual_request_uses_current_model_isolated_input_and_existing_options(
    monkeypatch, api, capable, include_usage
):
    ctx, parent = context(api=api, capable=capable, include_usage=include_usage)
    sent = []
    messages = [{"role": "user", "content": "Only selected evidence"}]
    before = deepcopy(messages)

    def receive(request):
        sent.append(request)
        return wire_response(api)

    install_transport(monkeypatch, receive)
    result = review_provider.complete_once(ctx, system="Review instructions", messages=messages)
    assert isinstance(result, Completion)
    assert result.text == "review text"
    assert result.model == "current-model"
    assert result.finish_reason == "stop"
    assert result.reasoning_content == "private reasoning"
    assert result.usage == ({"prompt_tokens": 11} if api == "openai" else {"input_tokens": 11})
    assert result.tool_calls == []
    assert len(sent) == 1
    body = json.loads(sent[0].content)
    assert body["model"] == "current-model"
    assert body["max_tokens"] == 137
    assert ("temperature" in body) is capable
    if capable:
        assert body["temperature"] == 0
    assert "tools" not in body and "abort_event" not in body
    assert sent[0].extensions["timeout"] == {"connect": 30.0, "read": 600.0, "write": 600.0, "pool": 600.0}
    if api == "openai":
        assert body["stream"] is True
        assert ("stream_options" in body) is include_usage
        if include_usage:
            assert body["stream_options"] == {"include_usage": True}
        assert body["messages"] == [{"role": "system", "content": "Review instructions"}, *messages]
        assert body["top_p"] == 0.7 and body["reasoning_effort"] == "low"
        assert sent[0].url.path == "/v1/chat/completions"
        assert sent[0].headers["authorization"] == "Bearer test-key"
    else:
        assert "stream" not in body and "stream_options" not in body
        assert body["system"] == "Review instructions"
        assert body["messages"] == messages
        assert sent[0].url.path == "/v1/messages"
        assert sent[0].headers["x-api-key"] == "test-key"
    assert messages == before
    ctx.app.store.get_session.assert_called_once_with("current-session")
    ctx.app.provider.complete.assert_not_called()
    assert not parent.is_set()
    assert_joined()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_default_temperature_uses_existing_capability_rule(monkeypatch, api):
    ctx, _ = context(api=api, temperature=None, model="qwen-test")
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        return wire_response(api)

    install_transport(monkeypatch, receive)
    review_provider.complete_once(ctx, system="", messages=[])
    assert sent[0]["temperature"] == 0.55


@pytest.mark.parametrize("api", ["openai", "anthropic"])
def test_http_503_is_one_completion_request_without_retry(monkeypatch, api):
    ctx, parent = context(api=api)
    sent = []

    def receive(request):
        sent.append(request)
        return httpx.Response(503, json={"error": "unavailable"})

    install_transport(monkeypatch, receive)
    with pytest.raises(ProviderError, match="503") as caught:
        review_provider.complete_once(ctx, system="", messages=[])
    assert isinstance(caught.value.__cause__, httpx.HTTPStatusError)
    assert len(sent) == 1
    assert not parent.is_set()
    assert_joined()


def test_missing_key_remains_provider_error_before_http(monkeypatch):
    ctx, _ = context(key=None)
    send = Mock(side_effect=AssertionError("Missing key must fail before HTTP"))
    install_transport(monkeypatch, send)
    with pytest.raises(ProviderError, match="Missing API key for provider 'review'"):
        review_provider.complete_once(ctx, system="", messages=[])
    send.assert_not_called()
    assert_joined()


def test_transport_error_remains_provider_error_without_retry(monkeypatch):
    ctx, _ = context()
    sent = []

    def receive(request):
        sent.append(request)
        raise httpx.ConnectError("connection unavailable", request=request)

    install_transport(monkeypatch, receive)
    with pytest.raises(ProviderError, match="connection unavailable") as caught:
        review_provider.complete_once(ctx, system="", messages=[])
    assert isinstance(caught.value.__cause__, httpx.ConnectError)
    assert len(sent) == 1
    assert_joined()


@pytest.mark.parametrize("context_abort", [False, True])
def test_already_cancelled_request_prevents_model_preparation(monkeypatch, context_abort):
    ctx, parent = context()
    if context_abort:
        ctx.abort = threading.Event()
        ctx.abort.set()
    else:
        parent.set()
    resolve = Mock(side_effect=AssertionError("Cancellation must prevent model preparation"))
    monkeypatch.setattr(ctx.app.provider, "resolve", resolve)
    with pytest.raises(ProviderError, match="aborted"):
        review_provider.complete_once(ctx, system="", messages=[])
    resolve.assert_not_called()
    if context_abort:
        assert not parent.is_set()
        ctx.app.abort_event.assert_not_called()
    assert_joined()


@pytest.mark.parametrize("api,cancel,stage", [
    (api, cancel, stage)
    for api, cancel in [("openai", "parent"), ("anthropic", "parent"), ("anthropic", "deadline")]
    for stage in ["headers", "body"]
] + [("openai", "parent", "partial")])
def test_cancel_or_deadline_waits_for_http_cleanup_and_joins(monkeypatch, api, cancel, stage):
    ctx, parent = context(api=api)
    entered, cleaned, closed = threading.Event(), threading.Event(), threading.Event()
    sent, outcome = [], []

    async def block():
        entered.set()
        try:
            await asyncio.Event().wait()
        finally:
            # Delayed cleanup must finish before the synchronous call returns.
            await asyncio.sleep(0.03)
            cleaned.set()

    class Body(httpx.AsyncByteStream):
        async def __aiter__(self):
            if stage == "partial":
                yield sse_event({"reasoning_content": "reasoning received"})
                yield sse_event({"content": "unfinished answer"})
            await block()
            yield b"{}"

    class Transport(httpx.MockTransport):
        async def aclose(self):
            await super().aclose()
            closed.set()

    async def receive(request):
        sent.append(request)
        if stage == "headers":
            await block()
        return httpx.Response(200, stream=Body())

    install_transport(monkeypatch, receive, transport_class=Transport)
    if cancel == "deadline":
        monkeypatch.setattr(review_provider, "_DEADLINE_SECONDS", 0.2)

    def run():
        try:
            review_provider.complete_once(ctx, system="", messages=[])
        except BaseException as error:
            outcome.append(error)

    caller = threading.Thread(target=run)
    caller.start()
    try:
        assert entered.wait(2)
        if cancel == "parent":
            parent.set()
        caller.join(2)
        assert not caller.is_alive()
        assert len(outcome) == 1 and isinstance(outcome[0], ProviderError)
        assert ("aborted" if cancel == "parent" else "local deadline") in str(outcome[0])
        assert parent.is_set() is (cancel == "parent")
        assert cleaned.is_set() and closed.is_set()
        assert len(sent) == 1
        if api == "openai":
            partial = outcome[0].partial
            assert partial is not None and partial.finish_reason is None
            assert partial.text == ("unfinished answer" if stage == "partial" else "")
            assert partial.reasoning_content == ("reasoning received" if stage == "partial" else None)
        assert_joined()
    finally:
        if caller.is_alive():
            parent.set()
            caller.join(3)


@pytest.mark.parametrize("cancel", ["parent", "deadline"])
def test_cancellation_covers_temperature_catalog_preparation(monkeypatch, cancel):
    ctx, parent = context(capable=None)
    entered, cleaned = threading.Event(), threading.Event()
    sent, outcome = [], []

    async def receive(request):
        sent.append(request)
        entered.set()
        try:
            await asyncio.Event().wait()
        finally:
            cleaned.set()

    install_transport(monkeypatch, receive)
    if cancel == "deadline":
        monkeypatch.setattr(review_provider, "_DEADLINE_SECONDS", 0.2)

    def run():
        try:
            review_provider.complete_once(ctx, system="", messages=[])
        except BaseException as error:
            outcome.append(error)

    caller = threading.Thread(target=run)
    caller.start()
    try:
        assert entered.wait(2)
        if cancel == "parent":
            parent.set()
        caller.join(2)
        assert not caller.is_alive()
        assert len(outcome) == 1 and isinstance(outcome[0], ProviderError)
        assert ("aborted" if cancel == "parent" else "local deadline") in str(outcome[0])
        assert parent.is_set() is (cancel == "parent")
        assert cleaned.is_set()
        assert len(sent) == 1 and sent[0].method == "GET"
        assert str(sent[0].url) == "https://models.dev/api.json"
        assert_joined()
    finally:
        if caller.is_alive():
            parent.set()
            caller.join(3)


def test_catalog_lookup_can_precede_the_single_completion_request(monkeypatch):
    ctx, _ = context(capable=None)
    sent = []

    def receive(request):
        sent.append(request)
        if request.method == "GET":
            return httpx.Response(200, json={"review": {"models": {"current-model": {"temperature": True}}}})
        return wire_response("openai")

    install_transport(monkeypatch, receive)
    result = review_provider.complete_once(ctx, system="", messages=[])
    assert result.text == "review text"
    assert [request.method for request in sent] == ["GET", "POST"]
    assert json.loads(sent[1].content)["temperature"] == 0


@pytest.mark.parametrize("cancel", ["parent", "deadline"])
def test_cancel_during_preparation_timer_cleanup_prevents_dispatch(monkeypatch, cancel):
    ctx, parent = context()
    sent = Mock(side_effect=AssertionError("Cancelled preparation must not dispatch a completion"))
    install_transport(monkeypatch, sent)

    class FinishingTimer:
        def __init__(self, interval, function):
            self.function = function
            self.joined = False

        def start(self):
            pass

        def cancel(self):
            pass

        def join(self):
            # A timer callback already in progress cannot be stopped by cancel().
            if not self.joined:
                self.joined = True
                (parent.set if cancel == "parent" else self.function)()

    monkeypatch.setattr(review_provider.threading, "Timer", FinishingTimer)
    with pytest.raises(ProviderError, match="aborted" if cancel == "parent" else "local deadline"):
        review_provider.complete_once(ctx, system="", messages=[])
    sent.assert_not_called()
    assert parent.is_set() is (cancel == "parent")
    assert_joined()


def test_openai_continuous_stream_completes_after_preparation_deadline(monkeypatch):
    ctx, parent = context()
    monkeypatch.setattr(review_provider, "_DEADLINE_SECONDS", 0.2)
    sent, arrived = [], []
    closed = threading.Event()
    pieces = [
        {"reasoning_content": "first"}, {"reasoning_content": " second"},
        {"reasoning_content": " third"}, {"content": "complete"}, {"content": " answer"},
    ]

    class Body(httpx.AsyncByteStream):
        async def __aiter__(self):
            for piece in pieces:
                await asyncio.sleep(0.06)
                arrived.append(time.monotonic())
                yield sse_event(piece)
            yield sse_event(reason="stop", usage={"prompt_tokens": 11, "completion_tokens": 19})
            yield b"data: [DONE]\n\n"

        async def aclose(self):
            closed.set()

    def receive(request):
        sent.append(request)
        assert not any(t.name == "researchkit-review-deadline" for t in threading.enumerate())
        return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=Body())

    install_transport(monkeypatch, receive)
    started = time.monotonic()
    result = review_provider.complete_once(ctx, system="same instructions", messages=[])
    assert arrived[-1] - started > review_provider._DEADLINE_SECONDS
    assert len(arrived) == len(pieces) and len(sent) == 1
    assert result.text == "complete answer"
    assert result.reasoning_content == "first second third"
    assert result.usage == {"prompt_tokens": 11, "completion_tokens": 19}
    assert result.finish_reason == "stop" and result.tool_calls == []
    assert closed.is_set() and not parent.is_set()
    assert_joined()


@pytest.mark.parametrize("stage", ["headers", "body", "partial"])
def test_openai_read_timeout_preserves_partial_and_never_retries(monkeypatch, stage):
    ctx, parent = context()
    sent = []
    body_closed, transport_closed = threading.Event(), threading.Event()

    class Body(httpx.AsyncByteStream):
        async def __aiter__(self):
            if stage == "partial":
                yield sse_event({"reasoning_content": "incomplete reasoning"})
                yield sse_event({"content": "incomplete answer"})
            raise httpx.ReadTimeout("idle read timed out", request=sent[0])

        async def aclose(self):
            body_closed.set()

    class Transport(httpx.MockTransport):
        async def aclose(self):
            await super().aclose()
            transport_closed.set()

    def receive(request):
        sent.append(request)
        if stage == "headers":
            raise httpx.ReadTimeout("idle read timed out", request=request)
        return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=Body())

    install_transport(monkeypatch, receive, transport_class=Transport)
    with pytest.raises(ProviderError, match="idle read timed out") as caught:
        review_provider.complete_once(ctx, system="", messages=[])
    assert isinstance(caught.value.__cause__, httpx.ReadTimeout)
    partial = caught.value.partial
    assert partial is not None and partial.finish_reason is None
    assert partial.text == ("incomplete answer" if stage == "partial" else "")
    assert partial.reasoning_content == ("incomplete reasoning" if stage == "partial" else None)
    assert len(sent) == 1 and not parent.is_set()
    assert transport_closed.is_set()
    assert body_closed.is_set() is (stage != "headers")
    assert_joined()


@pytest.mark.parametrize("malformed", [b"data: {invalid}\n\n", b"data: []\n\n"])
def test_bad_openai_stream_preserves_partial_without_retry(monkeypatch, malformed):
    ctx, _ = context()
    sent = []

    def receive(request):
        sent.append(request)
        return httpx.Response(200, headers={"content-type": "text/event-stream"},
                              content=sse_event({"reasoning_content": "partial"}) + malformed)

    install_transport(monkeypatch, receive)
    with pytest.raises(ProviderError) as caught:
        review_provider.complete_once(ctx, system="", messages=[])
    assert caught.value.partial.reasoning_content == "partial"
    assert caught.value.partial.text == "" and caught.value.partial.finish_reason is None
    assert len(sent) == 1
    assert_joined()


def test_parent_cancel_after_response_parse_prevents_success(monkeypatch):
    ctx, parent = context()
    install_transport(monkeypatch, lambda request: wire_response("openai"))
    original = provider_module._check_completion

    def cancel_after_parse(completion):
        parent.set()
        return original(completion)

    monkeypatch.setattr(provider_module, "_check_completion", cancel_after_parse)
    with pytest.raises(ProviderError, match="aborted") as caught:
        review_provider.complete_once(ctx, system="", messages=[])
    assert caught.value.partial.text == "review text"
    assert_joined()


def test_openai_completion_semantics_are_left_for_review_validator(monkeypatch):
    ctx, _ = context()
    install_transport(monkeypatch, lambda request:
                      wire_response("openai", text="", reason="length"))
    result = review_provider.complete_once(ctx, system="", messages=[])
    assert result.text == "" and result.finish_reason == "length"
    assert result.reasoning_content == "private reasoning"
    assert_joined()


def review_json():
    # This has the existing review shape. Resolving real record references and
    # validating quotations belong to the review entry point's integration test.
    ref = ".research/records/" + "a" * 64 + "/record.json"
    return json.dumps({"reviewed_refs": [ref], "checks": [{
        "subject": {"record_ref": ref, "source_path": "report.md",
                    "quote": "A claim requiring additional evidence."},
        "evidence": [], "decision": "unassessed", "reason": "No observation was supplied.",
    }]})


@pytest.mark.parametrize("reason", ["pause_turn", "unknown", None, "max_tokens", "tool_use"])
def test_anthropic_requires_raw_normal_completion_even_with_review_json(monkeypatch, reason):
    ctx, _ = context(api="anthropic")
    data = response("anthropic", text=review_json())
    if reason is None:
        data.pop("stop_reason")
    else:
        data["stop_reason"] = reason
    install_transport(monkeypatch, lambda request: httpx.Response(200, json=data))
    with pytest.raises(ProviderError, match="normal Anthropic completion"):
        review_provider.complete_once(ctx, system="", messages=[])
    assert_joined()


@pytest.mark.parametrize("reason", ["end_turn", "stop_sequence"])
def test_anthropic_normal_reasons_preserve_text_reasoning_and_usage(monkeypatch, reason):
    ctx, _ = context(api="anthropic")
    data = {"stop_reason": reason, "content": [
        {"type": "thinking", "thinking": "first"}, {"type": "text", "text": "answer"},
        {"type": "thinking", "thinking": " second"}, {"type": "text", "text": " text"},
    ], "usage": {"input_tokens": 17, "output_tokens": 23}}
    install_transport(monkeypatch, lambda request: httpx.Response(200, json=data))
    result = review_provider.complete_once(ctx, system="", messages=[])
    assert result.text == "answer text"
    assert result.reasoning_content == "first second"
    assert result.usage == data["usage"]
    assert result.finish_reason == "stop" and result.tool_calls == []
    assert_joined()


def test_anthropic_tool_content_is_rejected_even_with_normal_reason(monkeypatch):
    ctx, _ = context(api="anthropic")
    data = response("anthropic")
    data["content"].append({"type": "tool_use", "id": "unexpected", "name": "read", "input": {}})
    install_transport(monkeypatch, lambda request: httpx.Response(200, json=data))
    with pytest.raises(ProviderError, match="must not contain tool calls"):
        review_provider.complete_once(ctx, system="", messages=[])
    assert_joined()


def test_anthropic_server_tool_content_is_rejected_even_with_review_json(monkeypatch):
    ctx, _ = context(api="anthropic")
    data = response("anthropic", text=review_json())
    data["content"].append({"type": "server_tool_use", "id": "unexpected", "name": "web_search", "input": {}})
    install_transport(monkeypatch, lambda request: httpx.Response(200, json=data))
    with pytest.raises(ProviderError, match="unsupported content block: 'server_tool_use'"):
        review_provider.complete_once(ctx, system="", messages=[])
    assert_joined()


def test_anthropic_redacted_thinking_preserves_normal_text_response(monkeypatch):
    ctx, _ = context(api="anthropic")
    text = review_json()
    data = response("anthropic", text=text)
    data["content"].insert(0, {"type": "redacted_thinking", "data": "opaque"})
    install_transport(monkeypatch, lambda request: httpx.Response(200, json=data))
    result = review_provider.complete_once(ctx, system="", messages=[])
    assert result.text == text
    assert result.reasoning_content == "private reasoning"
    assert result.finish_reason == "stop" and result.tool_calls == []
    assert result.usage == data["usage"]
    assert_joined()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("temperature", [None, 0, 1])
def test_scoped_recovery_temperature_changes_only_one_request(monkeypatch, api, temperature):
    ctx, parent = context(api=api, temperature=temperature)
    messages = [{"role": "user", "content": "The same complete selected evidence"}]
    original_messages = deepcopy(messages)
    sent = []

    def receive(request):
        sent.append(json.loads(request.content))
        return wire_response(api)

    install_transport(monkeypatch, receive)
    original_temperature = ctx.app.provider._temperature
    capability = Mock(wraps=original_temperature)
    monkeypatch.setattr(ctx.app.provider, "_temperature", capability)
    for index, override in enumerate(({}, {"recovery_temperature": 0.6}, {}), start=1):
        result = review_provider.complete_once(ctx, system="Identical instructions", messages=messages, **override)
        assert result.text == "review text"
        assert len(sent) == index
        assert_joined()
    assert sent[1] == {**sent[0], "temperature": 0.6}
    assert sent[2] == sent[0]
    assert [call.args[2] for call in capability.call_args_list] == [temperature, temperature, 0.6, temperature]
    assert ctx.agent.temperature is temperature
    assert messages == original_messages
    ctx.app.provider.complete.assert_not_called()
    assert not parent.is_set()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("capable,temperature,model", [
    (False, 0, "current-model"),
    (True, 0.6, "current-model"),
    (True, None, "kimi-k2"),
], ids=["unsupported", "already-explicit-point-six", "already-default-point-six"])
def test_ineffective_recovery_temperature_fails_before_http(
        monkeypatch, api, capable, temperature, model):
    ctx, parent = context(api=api, capable=capable, temperature=temperature, model=model)
    send = Mock(side_effect=AssertionError("An unchanged temperature must not dispatch HTTP"))
    install_transport(monkeypatch, send)
    with pytest.raises(ProviderError):
        review_provider.complete_once(ctx, system="", messages=[], recovery_temperature=0.6)
    send.assert_not_called()
    ctx.app.provider.complete.assert_not_called()
    assert ctx.agent.temperature is temperature
    assert not parent.is_set()
    assert_joined()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("failure", ["status", "transport"])
def test_recovery_override_does_not_add_transport_retry(monkeypatch, api, failure):
    ctx, parent = context(api=api)
    sent = []

    def receive(request):
        sent.append(request)
        if failure == "transport":
            raise httpx.ConnectError("recovery connection unavailable", request=request)
        return httpx.Response(503, json={"error": "unavailable"})

    install_transport(monkeypatch, receive)
    with pytest.raises(ProviderError):
        review_provider.complete_once(ctx, system="", messages=[], recovery_temperature=0.6)
    assert len(sent) == 1
    assert json.loads(sent[0].content)["temperature"] == 0.6
    assert not parent.is_set()
    assert_joined()


@pytest.mark.parametrize("api", ["openai", "anthropic"])
@pytest.mark.parametrize("recovery", [False, True])
def test_reasoning_only_complete_once_returns_after_one_http_without_implicit_retry(
        monkeypatch, api, recovery):
    ctx, _ = context(api=api)
    sent = []

    def receive(request):
        sent.append(request)
        return wire_response(api, text=" \n ")

    install_transport(monkeypatch, receive)
    kwargs = {"recovery_temperature": 0.6} if recovery else {}
    result = review_provider.complete_once(ctx, system="", messages=[], **kwargs)
    assert result.text == " \n " and result.finish_reason == "stop"
    assert result.reasoning_content == "private reasoning" and result.tool_calls == []
    assert len(sent) == 1
    assert json.loads(sent[0].content)["temperature"] == (0.6 if recovery else 0)
    assert_joined()


def test_prepared_review_freezes_request_and_does_not_leak_into_next_invocation(monkeypatch):
    ctx, parent = context()
    messages = [{"role": "user", "content": "Original selected evidence"}]
    sent, prepared = [], {}

    def receive(request):
        sent.append(request)
        return wire_response("openai", text="", reason="length")

    install_transport(monkeypatch, receive)
    first = review_provider.complete_once(ctx, system="Original instructions", messages=messages,
                                          prepared=prepared)
    assert first.finish_reason == "length" and first.text == ""
    live = ctx.app.provider
    original_config = deepcopy(live.config)
    # These changes occur while one invocation is still awaiting its recovery.
    # Its snapshot must not switch model, endpoint, credentials, input or options.
    definition = live.config["provider"]["review"]["models"]["current-model"]
    definition["limit"]["output"] = 23
    definition["options"].update(top_p=0.9, reasoningEffort="high", include_stream_usage=False)
    definition["temperature"] = False
    live.config["provider"]["review"]["models"]["new-model"] = {
        "temperature": True, "limit": {"output": 99}, "options": {"top_p": 0.8},
    }
    live.providers["review"].base_url = "https://new-review.invalid/v2"
    live.providers["review"].api_key = "new-test-key"
    ctx.app.store.get_session.return_value = {"model": "review/new-model"}
    ctx.agent.temperature = 0.3
    messages[0]["content"] = "Changed evidence that must not enter this recovery"
    changed_config = deepcopy(live.config)

    review_provider.complete_once(ctx, system="Changed instructions", messages=messages,
                                  prepared=prepared, recovery_temperature=0.6)
    assert len(sent) == 2
    assert sent[1].url == sent[0].url
    # HTTP recalculates body length because 0 -> 0.6 adds two encoded bytes.
    assert {k: v for k, v in sent[1].headers.items() if k != "content-length"} == {
        k: v for k, v in sent[0].headers.items() if k != "content-length"}
    assert all(int(request.headers["content-length"]) == len(request.content) for request in sent)
    assert json.loads(sent[1].content) == {**json.loads(sent[0].content), "temperature": 0.6}
    assert prepared["client"].config == original_config
    assert live.config == changed_config
    ctx.app.store.get_session.assert_called_once_with("current-session")

    review_provider.complete_once(ctx, system="New invocation instructions", messages=messages,
                                  prepared={})
    latest = json.loads(sent[2].content)
    assert str(sent[2].url) == "https://new-review.invalid/v2/chat/completions"
    assert sent[2].headers["authorization"] == "Bearer new-test-key"
    assert latest["model"] == "new-model" and latest["temperature"] == 0.3
    assert latest["max_tokens"] == 99 and latest["top_p"] == 0.8
    assert "reasoning_effort" not in latest
    assert latest["messages"] == [{"role": "system", "content": "New invocation instructions"}, *messages]
    assert ctx.app.store.get_session.call_count == 2
    assert not parent.is_set()
    assert_joined()


@pytest.mark.parametrize("capable,temperature,model", [
    (False, 0, "current-model"), (True, 0.6, "current-model"), (True, None, "kimi-k2"),
])
def test_prepared_review_rejects_ineffective_recovery_before_second_dispatch(
        monkeypatch, capable, temperature, model):
    ctx, _ = context(capable=capable, temperature=temperature, model=model)
    sent, prepared = [], {}

    def receive(request):
        sent.append(request)
        return wire_response("openai", text="", reason="length")

    install_transport(monkeypatch, receive)
    review_provider.complete_once(ctx, system="", messages=[], prepared=prepared)
    with pytest.raises(ProviderError, match="temperature"):
        review_provider.complete_once(ctx, system="", messages=[], prepared=prepared,
                                      recovery_temperature=0.6)
    assert len(sent) == 1
    assert ctx.agent.temperature == temperature
    assert_joined()


def test_prepared_review_cancel_prevents_second_dispatch(monkeypatch):
    ctx, parent = context()
    sent, prepared = [], {}

    def receive(request):
        sent.append(request)
        return wire_response("openai", text="", reason="length")

    install_transport(monkeypatch, receive)
    review_provider.complete_once(ctx, system="", messages=[], prepared=prepared)
    parent.set()
    with pytest.raises(ProviderError, match="aborted"):
        review_provider.complete_once(ctx, system="", messages=[], prepared=prepared,
                                      recovery_temperature=0.6)
    assert len(sent) == 1
    assert_joined()


def test_prepared_review_unknown_temperature_capability_never_sends_second_generation(monkeypatch):
    ctx, _ = context(capable=None, temperature=None)
    sent, prepared = [], {}

    def receive(request):
        sent.append(request)
        if request.method == "GET":
            return httpx.Response(503, json={"error": "offline catalogue unavailable"})
        return wire_response("openai", text="", reason="length")

    install_transport(monkeypatch, receive)
    review_provider.complete_once(ctx, system="", messages=[], prepared=prepared)
    with pytest.raises(ProviderError):
        review_provider.complete_once(ctx, system="", messages=[], prepared=prepared,
                                      recovery_temperature=0.6)
    # The existing catalogue fetch may retry reads; no additional generation is sent.
    assert sent[0].method == "POST" and len(sent) > 1
    assert all(request.method == "GET" and str(request.url) == "https://models.dev/api.json"
               for request in sent[1:])
    assert "temperature" not in json.loads(sent[0].content)
    assert_joined()


@pytest.mark.parametrize("text,reason", [("review text", "end_turn"), ("", "end_turn"), ("", "max_tokens")])
def test_prepared_anthropic_keeps_original_encoding_and_stop_rules(monkeypatch, text, reason):
    ctx, _ = context(api="anthropic")
    sent, prepared = [], {}
    messages = [{"role": "user", "content": "Selected evidence only"}]

    def receive(request):
        sent.append(request)
        return wire_response("anthropic", text=text, reason=reason)

    install_transport(monkeypatch, receive)
    if reason == "max_tokens":
        with pytest.raises(ProviderError, match="normal Anthropic completion"):
            review_provider.complete_once(ctx, system="Instructions", messages=messages, prepared=prepared)
    else:
        result = review_provider.complete_once(ctx, system="Instructions", messages=messages, prepared=prepared)
        assert result.text == text and result.finish_reason == "stop"
        assert result.reasoning_content == "private reasoning"
    assert len(sent) == 1 and prepared["provider"].api == "anthropic"
    assert json.loads(sent[0].content) == {
        "model": "current-model", "max_tokens": 137, "system": "Instructions",
        "messages": messages, "temperature": 0,
    }
    assert_joined()
