"""One malformed reviewer check is dropped and reported, not fatal to the whole review (v7)."""

from copy import deepcopy
import json

import httpx
import pytest

import test_research_review as review_cases


@pytest.fixture
def packet(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("No real model or network in review tests")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    case = review_cases.ResearchReview(methodName="runTest")
    case.setUp()
    try:
        yield case
    finally:
        case.doCleanups()


def with_checks(packet, good, bad):
    value = deepcopy(packet.model_value)
    check = value["checks"][0]
    value["checks"] = [deepcopy(check) for _ in range(good)] + bad
    return value


MALFORMED = {"context": "a stray note the reviewer model emitted", "subject": {"file_id": "F1"}}


def test_a_single_malformed_check_is_dropped_and_noted(packet):
    value = with_checks(packet, 6, [MALFORMED])
    result, _ = packet.execute(completion=packet.completion(value))
    output = json.loads(result.output)
    assert len(output["review"]["checks"]) == 6
    assert output["dropped_checks"]["initial"][0]["check"] == 7
    assert output["dropped_checks"]["final"][0]["check"] == 7
    assert "expected exactly subject, evidence, decision, reason" in output["dropped_checks"]["final"][0]["problem"]
    note = next(packet.root.rglob("dropped-checks.json"))
    assert json.loads(note.read_text(encoding="utf-8")) == output["dropped_checks"]
    assert note.relative_to(packet.ctx.directory.resolve()).as_posix() in output["dropped_note"]


def test_a_clean_review_keeps_its_plain_output(packet):
    result, _ = packet.execute()
    assert set(json.loads(result.output)) == {"reviewed_refs", "checks"}


def test_too_many_malformed_checks_still_fail(packet):
    value = with_checks(packet, 2, [MALFORMED, MALFORMED])
    with pytest.raises(ValueError, match="2 of 4 checks are malformed"):
        packet.execute(completion=packet.completion(value))


def test_a_quotation_that_is_not_in_the_file_drops_only_its_own_check(packet):
    # v16: one mistyped quotation rejected all 18 checks of the second stage.
    value = with_checks(packet, 6, [])
    value["checks"][3]["subject"]["quote"] = "words that are not in the file"
    result, _ = packet.execute(completion=packet.completion(value))
    output = json.loads(result.output)
    assert len(output["review"]["checks"]) == 5
    dropped, = output["dropped_checks"]["final"]
    assert dropped["check"] == 4 and "literal contiguous excerpt" in dropped["problem"]
    assert "quoted text not in the selected file" in output["dropped_note"]


def test_quotations_missing_from_the_file_beyond_the_share_still_fail(packet):
    value = with_checks(packet, 2, [])
    for check in value["checks"]:
        check["subject"]["quote"] = "words that are not in the file"
    with pytest.raises(ValueError, match="No check in the review output is usable; first problem: check 1: .*literal"):
        packet.execute(completion=packet.completion(value))
