"""Saved v6 prose through native delivery; never autonomous research evidence.

Only the final PDF export is stubbed. Native App/Loop, skill, read, write,
render_report, frozen-source resolution, mindmap parsing and HTML building run.
"""

import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
from unittest.mock import patch
from urllib.parse import unquote, urlsplit

import pytest

from researchkit import report
from scripts import replay_report_delivery as replay


PROJECT = Path(__file__).resolve().parents[2]
WORKSPACE = PROJECT / "outputs/lit_current_e2e_20261020_v1/workspace"
RESPONSES = PROJECT / "outputs/lit_report_delivery_20261021_v3"
DRAFTS = PROJECT / "outputs/report_narrative_revision_20261021_v6/sources"
COMMISSION = (
    "這是腳本控制的離線交接測試。請沿用明確選取的保存來源及人工編修稿，"
    "經正式技能讀取、寫入與報告工具處理，保存回條；不代表自主研究、寫作或審查通過。"
)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


@pytest.fixture(autouse=True)
def route_format_map(monkeypatch):
    """The saved run selected a map in the earlier format, which is no longer drawn.

    These tests cover the delivery handoff, not the map format, so the saved map
    is reshaped into the route-family format when render_report parses it
    (route_map_conversion). The saved workspace files are not changed.
    """
    from researchkit import mindmap_schema
    from route_map_conversion import to_route_map

    monkeypatch.setattr(mindmap_schema, "parse_map",
                        lambda text: mindmap_schema.validate_map(to_route_map(mindmap_schema._parse(text))))


@pytest.fixture
def saved_packet():
    required = [RESPONSES / "response-010.json", RESPONSES / "response-013.json",
                DRAFTS / "report_zh.md", DRAFTS / "report_zh_easy.md"]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        pytest.skip("Saved report evidence unavailable; no demo substitute: " + ", ".join(missing))
    try:
        selected = replay.selected_paths(WORKSPACE, [replay.render_arguments(path) for path in required[:2]])
    except FileNotFoundError as exc:
        pytest.skip("Saved selected evidence unavailable; no demo substitute: " + str(exc))
    paths = [*required, *selected]
    before = {path: path.read_bytes() for path in paths}
    yield required
    assert all(path.read_bytes() == raw for path, raw in before.items())


def run(output, packet, **kwargs):
    formal_response, companion_response, formal, companion = packet
    return replay.replay(WORKSPACE, formal_response, formal, output, COMMISSION,
                         companion_response=companion_response, companion_markdown=companion, **kwargs)


class Links(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.links, self.ids = [], set()
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.add(attrs["id"])
        if tag == "a" and "href" in attrs:
            self.links.append(attrs["href"])


def test_saved_formal_and_adapted_companion_cross_native_tool_boundaries(saved_packet, tmp_path, monkeypatch):
    printed = []

    def export_only(html_path, pdf_path):
        # Do not fabricate a PDF or let the diagnostic claim one exists.
        printed.append((html_path, pdf_path, html_path.read_bytes()))
        return {"pages": 0, "browser": "TEST-STUB-NO-BROWSER-NO-PDF",
                "html_sha256": hashlib.sha256(html_path.read_bytes()).hexdigest()}

    monkeypatch.setattr(report, "export_pdf", export_only)
    output = tmp_path / "native-report-replay"
    result = run(output, saved_packet)
    assert result["report_tool_handoff_passed"] is True
    assert result["guidance_in_next_model_input"] == {
        "SKILL.md": True, "references/report-delivery.md": True,
    }
    assert result["formal_written_bytes_exact"] is True
    assert result["companion_written_body_exact_except_target"] is True
    assert result["outer_request_count"] == 8
    assert result["source_unchanged"] and result["selected_copies_unchanged"]
    assert result["actual_tools_used"] == sorted(replay.USED_TOOLS)
    assert result["blocked_network_attempts"] == []
    assert result["new_model_calls"] == result["live_http_calls"] == 0
    for key in ("autonomous_skill_selection_proven", "autonomous_writing_quality_proven",
                "scientific_acceptance", "full_end_to_end_passed", "visual_inspection_performed",
                "delivery_acceptance_exercised"):
        assert result[key] is False
    assert result["pdf_files_exist"] == [False, False]
    # Both reports, plus the separate evidence file of the formal report, which selected saved originals.
    assert sorted(pdf.name for _, pdf, _ in printed) == ["evidence.pdf", "report.pdf", "report.pdf"]
    assert all(path.read_bytes() == raw for path, _, raw in printed)
    assert all("TEST-STUB" in receipt["renderer"] for receipt in result["render_receipts_consumed"])

    selected = set(load(output / "selected-files.json"))
    copied = {path.relative_to(output / "workspace").as_posix()
              for path in (output / "workspace/.research/records").rglob("*") if path.is_file()}
    assert copied == selected
    assert set(result["read_files_in_next_model_input"]) == selected | {
        "saved-inputs/formal.md", "saved-inputs/companion.md",
    }
    requests = load(output / "outer-requests.json")
    history = load(output / "session-history.json")
    for name, index in (("formal-render", 5), ("companion-render", 7)):
        stored, = [m for m in history if m.get("role") == "tool" and m.get("tool_call_id") == name]
        consumed, = [m for m in requests[index]["messages"] if m.get("tool_call_id") == name]
        assert consumed["content"] == stored["content"]
        assert load(output / f"{name}-receipt.json") == stored
    assert all(request["_offline_diagnostic"]["provider"] == "scripted_offline_test_provider"
               for request in requests)
    # Native edit aliases may be exposed; the script does not replace tools_for.
    assert all(replay.USED_TOOLS <= set(names) for names in result["exposed_tools_by_request"])

    formal, companion = [Path(item["html_path"]) for item in result["render_receipts_consumed"]]
    formal_html = formal.read_text(encoding="utf-8")
    formal_doc, companion_doc = Links(formal_html), Links(companion.read_text(encoding="utf-8"))
    historical = replay.render_arguments(saved_packet[0])
    for choice in historical["evidence_files"]:
        assert choice["record_ref"] in formal_html
        assert choice["source_path"] in formal_html
    assert {f"evidence-{i}" for i in range(1, 10)} <= formal_doc.ids
    assert "report-map-1-board" in formal_doc.ids
    local_links = [urlsplit(href) for href in companion_doc.links
                   if not urlsplit(href).scheme and urlsplit(href).path]
    assert local_links
    adaptation = load(output / "companion-link-adaptation.json")
    formal_links = []
    for link in local_links:
        target = (companion.parent / unquote(link.path)).resolve()
        # The renderer also adds its normal link to the authored Markdown.
        assert target in {formal, output / "workspace/sources/report_zh_easy.md"}
        assert target.is_file()
        if target == formal:
            formal_links.append(link)
            assert not link.fragment or unquote(link.fragment) in formal_doc.ids
    assert len(formal_links) == adaptation["occurrences"]
    written = (output / "workspace/sources/report_zh_easy.md").read_bytes().decode("utf-8")
    assert written.replace(adaptation["new_target"], adaptation["old_target"]) == saved_packet[3].read_bytes().decode("utf-8")
    assert adaptation["body_equal_after_reversing_target_adaptation"] is True


def test_pdf_export_failure_returns_native_error_and_retains_generated_html(saved_packet, tmp_path, monkeypatch):
    def unavailable_browser(*args):
        raise RuntimeError("TEST: browser unavailable")

    monkeypatch.setattr(report, "export_pdf", unavailable_browser)
    output = tmp_path / "native-export-failure"
    result = run(output, saved_packet)
    assert result["earliest_remaining_boundary"] == "formal-render_returned_error"
    assert result.get("report_tool_handoff_passed") is not True
    assert result["outer_request_count"] == 6
    assert result["render_receipts_consumed"] == []
    error = load(output / "error-receipt.json")
    assert error["metadata"]["error"] is True
    assert "TEST: browser unavailable" in error["content"]
    assert len(list((output / "workspace/.research/reports").glob("*/report.html"))) == 1
    assert not list((output / "workspace/.research/reports").glob("*/report.pdf"))
    assert result["app_result"]["text"] == replay.ERROR_CONTROL
    assert result["source_unchanged"] is True


def test_missing_saved_input_fails_without_canned_draft(saved_packet, tmp_path):
    output = tmp_path / "must-not-start"
    with pytest.raises(FileNotFoundError):
        replay.replay(WORKSPACE, saved_packet[0], tmp_path / "missing.md", output, COMMISSION)
    assert not output.exists()


def test_upgraded_saved_v3_guidance_reaches_next_native_model_input(tmp_path_factory):
    """Optional REPORT_GUIDANCE_REPLAY_OUTPUT retains this private diagnostic."""
    import researchkit
    from scripts.replay_research_review_handoff import _jsonable, _offline_network, _save, _sha
    from scripts.setup_research_workspace import install

    saved_root = RESPONSES / "baseline/workspace/.opencode/skills"
    manifest_path = RESPONSES / "runtime-manifest.json"
    if not saved_root.is_dir() or not manifest_path.is_file():
        pytest.skip("Saved v3 guidance unavailable; no invented old-guidance substitute")
    saved = {path.relative_to(saved_root): path.read_bytes() for path in saved_root.rglob("*.md")}
    assert len(saved) == 21
    manifest_bytes = manifest_path.read_bytes()
    previous = json.loads(manifest_bytes.decode("utf-8"))
    for relative, raw in saved.items():
        assert _sha(raw) == previous["src/researchkit/skills/" + relative.as_posix()]
    current_root = Path(researchkit.__file__).parent / "skills"
    names = [Path("scientific-report-writer/SKILL.md"),
             Path("scientific-report-writer/references/report-delivery.md")]
    current = {name: (current_root / name).read_bytes() for name in names}
    assert all(saved[name] != current[name] for name in names)
    requested_output = os.environ.get("REPORT_GUIDANCE_REPLAY_OUTPUT")
    output = (Path(requested_output).resolve() if requested_output
              else tmp_path_factory.mktemp("guide") / "run")
    assert not output.exists(), "Diagnostic output must be new; never overwrite a previous capture"
    assert not output.is_relative_to(RESPONSES.resolve()) and not RESPONSES.resolve().is_relative_to(output)
    output.mkdir(parents=True)
    workspace = output / "workspace"
    (workspace / ".git").mkdir(parents=True)
    for relative, raw in saved.items():
        copied = workspace / ".opencode/skills" / relative
        copied.parent.mkdir(parents=True, exist_ok=True)
        copied.write_bytes(raw)
    (output / "runtime-manifest.json").write_bytes(manifest_bytes)
    source_hashes = {str(saved_root / name): _sha(raw) for name, raw in saved.items()}
    source_hashes[str(manifest_path)] = _sha(manifest_bytes)
    _save(output / "source-hashes.json", source_hashes)
    _save(output / "installed-before.json", {name.as_posix(): _sha(raw) for name, raw in saved.items()})
    env = {}
    for name in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                 "XDG_STATE_HOME", "XDG_CACHE_HOME", "TEMP", "TMP"):
        folder = output / name.lower()
        folder.mkdir()
        env[name] = str(folder)
    env.update(OPENCODE_DISABLE_CLAUDE_CODE_PROMPT="1", OPENCODE_DISABLE_PROJECT_CONFIG="0")
    blocked, loopback, requests, receipts = [], [], [], []
    result = {
        "scope": "Saved v3 skills -> approved hash-authorized install -> native skill/read -> next input",
        "outer_provider": "scripted_offline_test_provider", "saved_markdown_count": len(saved),
        "new_model_calls": 0, "pdf_export_exercised": False,
        "autonomous_writing_quality_proven": False, "full_end_to_end_passed": False,
        "guidance_in_next_model_input": {},
    }
    store, session = None, None

    def deny_http(request):
        blocked.append(str(request.url))
        raise AssertionError("Upgrade replay must not contact HTTP")

    try:
        with patch.dict(os.environ, env), _offline_network(deny_http, blocked, loopback):
            from opencode.app import App
            from opencode.config import _frontmatter
            from opencode.provider import Completion, ToolCall
            from opencode.store import Store

            install(workspace, previous_manifest=previous)
            installed = {name.as_posix(): _sha(path.read_bytes())
                         for path in (workspace / ".opencode/skills").rglob("*.md")
                         for name in [path.relative_to(workspace / ".opencode/skills")]}
            _save(output / "installed-after.json", installed)
            assert all((workspace / ".opencode/skills" / name).read_bytes() == raw
                       for name, raw in current.items())
            config = {
                "model": "offline/scripted-guidance-replay", "enabled_providers": ["offline"],
                "provider": {"offline": {"options": {"baseURL": "https://replay.invalid/v1",
                    "apiKey": "offline-not-a-real-api-key"},
                    "models": {"scripted-guidance-replay": {"limit": {"context": 131072, "output": 32000}}}}},
                "mcp": {}, "lsp": False, "skills": {},
                "permission": {"*": "deny", "skill": "allow", "read": "allow"},
                "compaction": {"auto": False, "prune": False},
                "instructions": load(workspace / ".opencode/opencode.json")["instructions"],
            }
            _save(output / "offline-config.json", config)
            store = Store(output / "session.db")
            app = App(workspace, store=store, auto_approve=False, config=config)
            app.generate_titles = False
            session = app.create_session(title="Scripted upgraded guidance replay", model=config["model"])["id"]
            skill = app.skills["scientific-report-writer"]
            reference = skill.location.parent / "references/report-delivery.md"

            def outer(**kwargs):
                request = _jsonable(kwargs)
                request["_offline_diagnostic"] = {"provider": "scripted_offline_test_provider"}
                requests.append(request)
                step = len(requests)
                _save(output / f"request-{step:03}.json", request)
                if step == 1:
                    return Completion(tool_calls=[ToolCall("upgraded-skill", "skill", {
                        "name": "scientific-report-writer"})], finish_reason="tool-calls")
                assert step in (2, 3), "Unexpected extra inference or retry"
                call_id = "upgraded-skill" if step == 2 else "upgraded-reference"
                stored, = [m for m in store.messages(session)
                           if m.get("role") == "tool" and m.get("tool_call_id") == call_id]
                consumed, = [m for m in kwargs["messages"]
                             if m.get("role") == "tool" and m.get("tool_call_id") == call_id]
                receipts.append(stored)
                assert not stored.get("metadata", {}).get("error")
                assert not stored.get("metadata", {}).get("truncated")
                assert consumed["content"] == stored["content"]
                if step == 2:
                    assert skill.body.strip() in consumed["content"]
                    assert _frontmatter(saved[names[0]].decode("utf-8"))[1].strip() not in consumed["content"]
                    result["guidance_in_next_model_input"][names[0].as_posix()] = True
                    return Completion(tool_calls=[ToolCall("upgraded-reference", "read", {
                        "filePath": str(reference)})], finish_reason="tool-calls")
                for raw, must_be_present in ((current[names[1]], True), (saved[names[1]], False)):
                    numbered = "\n".join(f"{i}: {line}" for i, line in enumerate(raw.decode("utf-8").splitlines(), 1))
                    assert (numbered in consumed["content"]) is must_be_present
                result["guidance_in_next_model_input"][names[1].as_posix()] = True
                result["upgrade_to_native_input_passed"] = True
                return Completion(text="離線測試已確認升級後的技能與參考文件進入下一次模型輸入。", finish_reason="stop")

            app.provider.complete = outer
            result["app_result"] = app.prompt(session, "離線腳本只驗證已保存舊技能升級後的原生讀取與模型輸入交接。")
            assert not blocked
    finally:
        if store is not None:
            if session is not None:
                _save(output / "session-history.json", store.messages(session))
            store.close()
        result["source_unchanged"] = (manifest_path.read_bytes() == manifest_bytes and
            {path.relative_to(saved_root): path.read_bytes() for path in saved_root.rglob("*.md")} == saved)
        result["blocked_network_attempts"] = blocked
        result["loopback_wakeup_connections"] = loopback
        result["outer_request_count"] = len(requests)
        _save(output / "tool-receipts.json", receipts)
        _save(output / "result.json", result)
    assert result["source_unchanged"] is True
    assert result["upgrade_to_native_input_passed"] is True
    assert result["outer_request_count"] == 3
