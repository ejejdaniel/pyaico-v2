"""Replay a saved real review through native dispatch, without a live model.

The outer completions are explicitly scripted test steps. Historical public
replies are rejected by the current selector-only model contract. These checks
prove raw transport and error handoff, never autonomous scientific judgment or
completion of the original research commission. Public historical citation
errors are separately preserved through the unchanged public validator.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
from types import SimpleNamespace

import httpx
import pytest

from opencode.permission import Broker, PermissionDenied, Rule
from opencode.tools.util import ensure_access
from researchkit import review, reviewer
from scripts import replay_research_review_handoff as saved_replay


SOURCE = Path(__file__).resolve().parents[2] / "tmp/s22_aligned_live_review_20261020"
FAILED_SOURCE = Path(__file__).resolve().parents[2] / "tmp/live_review_handoff_selected_20261020"
SAVED_FILES = (
    "arguments.json", "opencode.json", "request.body.json", "response.body.bin",
    "response-http.json", "parsed-completion.json",
)
FAILED_CAPTURE_FILES = {
    "arguments.json": "live/review-arguments.json",
    "opencode.json": "opencode.json",
    "request.body.json": "live/review-001/request.body.json",
    "response.body.bin": "live/review-001/response.raw.bin",
    "response-http.json": "live/review-001/response-http.json",
    "parsed-completion.json": "live/review-completion.json",
}
PRIVATE_COMMISSION = (
    "SCRIPTED_OUTER_PRIVATE_COMMISSION: inspect the bounded saved review receipt. "
    "This offline test does not commission or complete the original research."
)


def _json(path):
    return json.loads(path.read_bytes().decode("utf-8-sig"))


def _source_hashes(source):
    # Hash only the explicit saved packet, including its frozen workspace.
    paths = [source / name for name in SAVED_FILES]
    paths.extend(path for path in (source / "workspace").rglob("*") if path.is_file())
    return {path.relative_to(source).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths}


def _copy_saved_packet(source, destination):
    destination.mkdir()
    for name in SAVED_FILES:
        shutil.copyfile(source / name, destination / name)
    shutil.copytree(source / "workspace", destination / "workspace")
    return destination


@pytest.fixture
def saved_packet(monkeypatch):
    missing = [name for name in SAVED_FILES if not (SOURCE / name).is_file()]
    if not (SOURCE / "workspace").is_dir():
        missing.append("workspace/")
    if missing:
        pytest.skip("Saved real-review evidence is unavailable; no demo substitute: " + ", ".join(missing))
    arguments = _json(SOURCE / "arguments.json")
    for locator in arguments["files"]:
        manifest = SOURCE / "workspace" / locator["record_ref"]
        if not manifest.is_file():
            pytest.skip(f"Saved real-review manifest is unavailable; no demo substitute: {manifest}")
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == locator["source_path"]]
        snapshot = manifest.parent / entry["snapshot"]
        if not snapshot.is_file():
            pytest.skip(f"Saved real-review snapshot is unavailable; no demo substitute: {snapshot}")

    def no_network(*args, **kwargs):
        pytest.fail("Saved-review replay tests must never use a real HTTP transport")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", no_network)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", no_network)
    before = _source_hashes(SOURCE)
    yield SOURCE
    assert _source_hashes(SOURCE) == before, "Replay changed the saved real evidence packet"


@pytest.fixture
def saved_failed_packet(tmp_path, monkeypatch):
    """Repackage saved bytes for offline replay, without inventing a new request."""
    missing = [name for name in FAILED_CAPTURE_FILES.values()
               if not (FAILED_SOURCE / name).is_file()]
    if not (FAILED_SOURCE / "workspace").is_dir():
        missing.append("workspace/")
    if missing:
        pytest.skip("Saved failed-review evidence is unavailable; no demo substitute: " + ", ".join(missing))
    arguments = _json(FAILED_SOURCE / FAILED_CAPTURE_FILES["arguments.json"])
    frozen_paths = set()
    for locator in arguments["files"]:
        manifest = FAILED_SOURCE / "workspace" / locator["record_ref"]
        if not manifest.is_file():
            pytest.skip(f"Saved failed-review manifest is unavailable; no demo substitute: {manifest}")
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == locator["source_path"]]
        snapshot = manifest.parent / entry["snapshot"]
        if not snapshot.is_file():
            pytest.skip(f"Saved failed-review snapshot is unavailable; no demo substitute: {snapshot}")
        frozen_paths.update((manifest, snapshot))
    # Validate identity and literal bytes before copying. Keep only the explicit
    # record/snapshot allowlist, not the saved workspace's old installed skills.
    saved_replay._selected_files(FAILED_SOURCE / "workspace", arguments)
    source_paths = frozen_paths | {FAILED_SOURCE / name for name in FAILED_CAPTURE_FILES.values()}

    def hashes():
        return {path.relative_to(FAILED_SOURCE).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in source_paths}

    before = hashes()
    packet = tmp_path / "historical-failed-review-packet"
    packet.mkdir()
    assert set(FAILED_CAPTURE_FILES) == set(SAVED_FILES) == set(saved_replay.CAPTURE_FILES)
    for name, origin in FAILED_CAPTURE_FILES.items():
        shutil.copyfile(FAILED_SOURCE / origin, packet / name)
    for origin in frozen_paths:
        destination = packet / origin.relative_to(FAILED_SOURCE)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)
    assert _source_hashes(packet) == {
        **{name: before[origin] for name, origin in FAILED_CAPTURE_FILES.items()},
        **{path.relative_to(FAILED_SOURCE).as_posix(): before[path.relative_to(FAILED_SOURCE).as_posix()]
           for path in frozen_paths},
    }

    def no_network(*args, **kwargs):
        pytest.fail("Saved-review replay tests must never use a real HTTP transport")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", no_network)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", no_network)
    yield packet
    assert hashes() == before, "Replay changed the saved failed-review source evidence"


def _assert_readonly_isolation(result, output):
    assert result["live_http_calls"] == 0
    assert result["blocked_network_attempts"] == []
    assert result["source_unchanged"] is True
    assert result["selected_files_unchanged"] is True
    assert result["copied_original_files_unchanged"] is True
    assert result["research_records_unchanged"] is True
    assert result["publication_tool_calls"] == 0
    assert result["outer_provider"] == "scripted_offline_test_provider"
    assert result["autonomous_skill_selection_proven"] is False
    assert result["scientific_acceptance"] is False
    assert result["full_end_to_end_passed"] is False
    config = _json(output / "offline-config.json")
    assert config["permission"] == {
        "*": "deny", "read": "allow", "skill": "allow", "research_review": "allow",
        "edit": {"*": "deny", ".research/review-runs": "allow", ".research/review-runs/*": "allow"},
    }
    root = (output / "workspace").resolve()
    rules = [Rule("*", "*", "deny"), *[Rule("edit", pattern, action)
             for pattern, action in config["permission"]["edit"].items()]]
    ctx = SimpleNamespace(directory=root, worktree=root, session_id="permission-replay",
                          agent=SimpleNamespace(permission=rules), app=SimpleNamespace(permissions=Broker(auto=True)))
    for path in (root / ".research/review-runs", root / ".research/review-runs/call/initial/review.json"):
        ensure_access(ctx, path, "edit")
    for path in (root / "report.md", root / ".research/records/hash/record.json", root / "unrelated/output.txt"):
        with pytest.raises(PermissionDenied):
            ensure_access(ctx, path, "edit")
    for request in _json(output / "outer-requests.json"):
        assert request["_offline_diagnostic"]["provider"] == "scripted_offline_test_provider"
        assert {tool["name"] for tool in request["tools"]} == {"read", "skill", "research_review", "write", "edit"}


def _review_messages(request):
    return [message for message in request["messages"]
            if message.get("role") == "tool" and message.get("tool_call_id") == "replay-review"]


def _assert_current_input_and_s26_transport(actual, historical):
    expected_system = "\n\n".join(path.read_text(encoding="utf-8") for path in (
        reviewer.SYSTEM_PATH, reviewer.FORMAT_PATH, reviewer.VERIFICATION_PATH))
    expected = deepcopy(historical)
    assert expected["messages"][0]["role"] == "system"
    assert expected["messages"][0]["content"] != expected_system
    expected["messages"][0]["content"] = expected_system
    # Independently translate only the saved input framing. This does not create
    # a model answer, alter a decision, or repair a historical quotation.
    lines = expected["messages"][1]["content"].split("\n")
    numbered = lines[:4]
    for offset in range(4, len(lines), 4):
        assert lines[offset] == "Selected frozen file:"
        assert lines[offset + 2] == "Literal UTF-8 file content (JSON string):"
        locator = json.loads(lines[offset + 1])
        text = json.loads(lines[offset + 3]).replace("\r\n", "\n").replace("\r", "\n")
        if text:
            source_lines = (text[:-1] if text.endswith("\n") else text).split("\n")
        else:
            source_lines = []
        numbered.extend(["Selected frozen file:",
                         json.dumps({"file_id": f"F{(offset - 4) // 4 + 1}", **locator}, ensure_ascii=False),
                         "Numbered UTF-8 lines (JSON array; numbers are not source content):",
                         json.dumps(list(enumerate(source_lines, 1)), ensure_ascii=False)])
    expected["messages"][1]["content"] = "\n".join(numbered)
    expected.update(stream=True, stream_options={"include_usage": True})
    assert actual == expected
    assert actual["messages"][0] == {"role": "system", "content": expected_system}


def _assert_original_bytes_and_synthetic_framing(output, source, result):
    raw = (source / "response.body.bin").read_bytes()
    assert (output / "response.body.bin").read_bytes() == raw
    assert (output / "historical-request.body.json").read_bytes() == (source / "request.body.json").read_bytes()
    assert _json(output / "source-hashes.json") == _source_hashes(source)
    historical = json.loads(raw)
    choice = historical["choices"][0]
    event = {"choices": [{
        "delta": {key: value for key, value in choice["message"].items()
                  if key in {"content", "reasoning", "reasoning_content"}},
        "finish_reason": choice["finish_reason"],
    }]}
    if "usage" in historical:
        event["usage"] = historical["usage"]
    lines = (output / "synthetic-response.sse.bin").read_bytes().decode("utf-8").splitlines()
    assert lines[0].startswith("data: ") and lines[1:] == ["", "data: [DONE]", ""]
    assert json.loads(lines[0].removeprefix("data: ")) == event
    assert result["review_response_origin"] == (
        "historical_openai_completion_with_synthetic_sse_framing_not_original_stream")


@pytest.mark.parametrize("damage", ["selected_snapshot", "invalid_reference"])
def test_replay_input_check_rejects_damage_before_http(saved_packet, tmp_path, monkeypatch, damage):
    # This exercises the replay script's preflight, not the native reviewer.
    source = _copy_saved_packet(saved_packet, tmp_path / "damaged-packet")
    arguments = _json(source / "arguments.json")
    if damage == "selected_snapshot":
        selected = arguments["files"][0]
        manifest = source / "workspace" / selected["record_ref"]
        entry, = [item for item in _json(manifest)["files"]
                  if item["source_path"] == selected["source_path"]]
        snapshot = manifest.parent / entry["snapshot"]
        snapshot.write_bytes(snapshot.read_bytes() + b"\nOFFLINE_TRANSPORT_CORRUPTION\n")
        expected_error, message = AssertionError, "Changed selected snapshot"
    else:
        arguments["reviewed_refs"][0] = "../not-a-record.json"
        expected_error, message = ValueError, "Expected an exact relative"
    before = _source_hashes(source)
    client_calls = []

    def unexpected_http_client(*args, **kwargs):
        client_calls.append((args, kwargs))
        pytest.fail("Invalid replay input reached HTTP client construction")

    monkeypatch.setattr(httpx, "Client", unexpected_http_client)
    monkeypatch.setattr(httpx, "AsyncClient", unexpected_http_client)
    output = tmp_path / "rejected-replay"
    with pytest.raises(expected_error, match=message):
        saved_replay.replay(source, output, arguments, PRIVATE_COMMISSION)
    assert client_calls == []
    assert not output.exists()
    assert _source_hashes(source) == before


@pytest.mark.parametrize("damage", ["multiple_choices", "content_array", "tool_call", "missing_finish", "usage_array"])
def test_synthetic_framing_rejects_unsupported_saved_completion(saved_packet, damage):
    response = _json(saved_packet / "response.body.bin")
    choice = response["choices"][0]
    if damage == "multiple_choices":
        response["choices"].append(deepcopy(choice))
    elif damage == "content_array":
        choice["message"]["content"] = [{"type": "text", "text": choice["message"]["content"]}]
    elif damage == "tool_call":
        choice["message"]["function_call"] = {"name": "read", "arguments": "{}"}
    elif damage == "missing_finish":
        choice.pop("finish_reason")
    else:
        response["usage"] = []
    with pytest.raises(ValueError, match="Offline SSE adaptation"):
        saved_replay._synthetic_openai_sse(json.dumps(response).encode())
