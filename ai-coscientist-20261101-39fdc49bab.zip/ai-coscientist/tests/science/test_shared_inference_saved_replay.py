"""Saved real artifacts exercise outer transport; no new scientific answer."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from researchkit import records, report_evidence
from researchkit.tools import TOOLS
from scripts import replay_shared_inference as replay


@pytest.fixture(scope="module")
def saved_result(tmp_path_factory):
    try:
        replay._saved_packet(replay.SOURCE, replay.SAVED_INFERENCE)
    except FileNotFoundError as exc:
        pytest.skip(f"Saved real evidence unavailable; no synthetic replacement: {exc}")
    pytest.importorskip("z3")
    output = tmp_path_factory.mktemp("shared-inference-parent") / "replay"
    selected = next(tool for tool in TOOLS if tool.name == "check_inference")
    with patch.object(selected, "execute", wraps=selected.execute) as executed:
        summary = replay.replay(output)
    assert executed.call_count == 1
    return output, summary


def test_missing_saved_input_fails_before_creating_output(tmp_path):
    output = tmp_path / "new-output"
    with pytest.raises(FileNotFoundError):
        replay.replay(output, source=tmp_path / "missing-source")
    assert not output.exists()


def test_existing_output_is_never_replaced(tmp_path):
    output = tmp_path / "existing"
    output.mkdir()
    marker = output / "preserve.txt"
    marker.write_text("existing evidence", encoding="utf-8")
    with pytest.raises(FileExistsError):
        replay.replay(output)
    assert marker.read_text(encoding="utf-8") == "existing evidence"
