"""One values table serves the history check, the leaderboard and the candidate comparison, ranked alike."""

import json

import jsonschema
import pytest

from researchkit import candidate_comparison, history_check, leaderboard, records, values_table


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content if isinstance(content, str) else json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


# Two historical samples the formula cannot tell apart (same raw prediction) but whose measured KPI
# differs; the formula predicts that KPI with an offset and declares mean_offset anchoring.
TABLE = {"TV0": {"P1": 40.4, "P2": 1.0}, "TV1": {"P1": 40.4, "P2": 2.0},
         "C1": {"P1": 31.0, "P2": 3.0}, "C2": {"P1": -10.0, "P2": 0.5}}


@pytest.fixture
def anchored(tmp_path):
    measured = save(tmp_path, "prepared_data", {"data/measured.json": {"TV0": {"EOP": 53.7},
                                                                      "TV1": {"EOP": 47.9}}})
    formula = save(tmp_path, "proxy_formula", {"f/proxy_formula.json": {
        "formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "target",
        "target_value": 40, "anchor": "mean_offset",
        "measured": {"record_ref": measured["record_path"], "source_path": "data/measured.json", "column": "EOP"}}},
        [measured])
    values = save(tmp_path, "implementation", {"work/values.json": TABLE}, [formula])
    selection = {"record_ref": values["record_path"], "source_path": "work/values.json", "column": "P1"}
    return tmp_path, formula, selection


def compare(root, formula, selection, **extra):
    args = {"method_ref": formula["record_path"], "values": selection,
            "baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"], **extra}
    return candidate_comparison.run(args, root, root / f".research/method_comparisons/{len(extra)}")["result"]


def test_the_comparison_ranks_a_table_column_by_the_formula_declaration_like_the_leaderboard(anchored):
    root, formula, selection = anchored
    board = leaderboard.run({"baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"],
                             "sheets": [{"formula_ref": formula["record_path"], "values": selection}]},
                            root, root / ".research/leaderboards/one")["result"]
    sheet, = board["sheets"]
    result = compare(root, formula, selection)
    # Anchored: baselines rank by their measurements, candidates by prediction minus the offset (-10.4).
    assert result["basis"].startswith("declared by method_ref")
    assert result["direction"] == "target" and result["target_value"] == 40
    assert result["best_baseline"] == {"ids": ["TV1"], "value": 47.9}
    assert result["best_candidate"]["ids"] == ["C1"] and result["best_candidate"]["value"] == pytest.approx(41.4)
    assert result["comparison"] == "better" and result["scale_check"]["anchored"] is True
    assert result["raw_values"]["C1"] == 31.0
    assert sheet["best_baselines"] == ["TV1"] and sheet["candidate_status"]["C1"] == "better"
    # The same call may restate the declaration; a different direction is refused, not silently used.
    assert compare(root, formula, selection, direction="target", target_value=40.0)["comparison"] == "better"
    with pytest.raises(ValueError, match="declares"):
        compare(root, formula, selection, direction="lower")


def test_a_method_without_a_declaration_still_needs_its_direction(tmp_path):
    method = save(tmp_path, "formula", {"m.txt": "method"})
    values = save(tmp_path, "implementation", {"v.json": TABLE}, [method])
    selection = {"record_ref": values["record_path"], "source_path": "v.json", "column": "P2"}
    with pytest.raises(ValueError, match="direction is required"):
        compare(tmp_path, method, selection)
    result = compare(tmp_path, method, selection, direction="higher")
    assert result["basis"] == "this call" and result["best_candidate"] == {"ids": ["C1"], "value": 3.0}


@pytest.mark.parametrize("data,column,message", [
    (TABLE, None, "add values.column naming the column to use: P1, P2"),
    ({"TV0": {"P1": 1.0}, "C1": 2.0}, "P1", r"mixes plain numbers \(C1\) with rows \(TV0\)"),
    ({"TV0": 1.0, "C1": 2.0}, "P1", "leave column out"),
    ({"TV0": {"P1": 1.0}, "C1": {"P2": 2.0}}, "P1", r"missing for: C1\. Number columns in the file: P1, P2"),
])
def test_values_file_errors_say_what_shape_is_expected(data, column, message):
    with pytest.raises(ValueError, match=message):
        values_table.column_values(json.dumps(data), column)


# LIT v21: the formulas' kpi pointed at the prepared data CSV; the tools raised a bare
# "Expecting value: line 1 column 1 (char 0)" and the author ranked candidates with its own scripts.
PREPARED_CSV = ("sample_id,source_material_label,EOP_mJ,LCDU_nm\n"
                'S1,"PHS/R12, Mw=7k",53.7,4.78\nS2,"PHS/R17, Mw=9k",47.9,\n')


def test_a_csv_column_is_read_with_the_sample_ids_in_the_first_column(tmp_path):
    data = save(tmp_path, "prepared_data", {"data/prepared.csv": PREPARED_CSV})
    selection = {"record_ref": data["record_path"], "source_path": "data/prepared.csv", "column": "EOP_mJ"}
    numbers, digest = values_table.read(tmp_path, selection, None, "kpi")
    assert numbers == {"S1": 53.7, "S2": 47.9} and len(digest) == 64
    # A blank cell is a sample without a value in that column, not an error.
    assert values_table.read(tmp_path, {**selection, "column": "LCDU_nm"}, None, "kpi")[0] == {"S1": 4.78}


@pytest.mark.parametrize("column,message", [
    (None, "is a table; add kpi.column naming the column to use: source_material_label, EOP_mJ, LCDU_nm"),
    ("EOP", r"Column 'EOP' is not in data/prepared.csv\. Columns: sample_id, source_material_label, EOP_mJ"),
    ("sample_id", "holds the sample IDs; name a column of values"),
    ("source_material_label", r"has no number for 'S1': 'PHS/R12, Mw=7k'"),
])
def test_csv_column_errors_name_the_file_and_the_columns(tmp_path, column, message):
    data = save(tmp_path, "prepared_data", {"data/prepared.csv": PREPARED_CSV})
    selection = {"record_ref": data["record_path"], "source_path": "data/prepared.csv"}
    if column is not None:
        selection["column"] = column
    with pytest.raises(ValueError, match=message):
        values_table.read(tmp_path, selection, None, "kpi")


def test_a_file_that_is_neither_json_nor_a_table_says_which_file_and_what_is_expected(tmp_path):
    data = save(tmp_path, "prepared_data", {"data/notes.txt": "S1 53.7\nS2 47.9\n"})
    with pytest.raises(ValueError, match=r"The kpi file data/notes\.txt is not JSON \(Expecting value.*\)\. "
                                         r"Select a JSON values table .*or a CSV/TSV whose first column"):
        values_table.read(tmp_path, {"record_ref": data["record_path"], "source_path": "data/notes.txt",
                                     "column": "EOP"}, None, "kpi")


def test_a_kpi_in_the_prepared_csv_reaches_the_history_check_and_the_leaderboard(tmp_path):
    data = save(tmp_path, "prepared_data", {"data/prepared.csv": PREPARED_CSV})
    kpi = {"record_ref": data["record_path"], "source_path": "data/prepared.csv", "column": "EOP_mJ",
           "better": "target", "target_value": 40.0}
    # v21's P1: the R17 share, declared lower-is-better, while S2 (all R17) is nearer the 40 mJ target.
    formula = save(tmp_path, "proxy_formula", {"p1/proxy_formula.json": {
        "formula_id": "P1", "expression": "R17 share", "hypothesis_ids": ["H1"], "direction": "lower",
        "kpi": kpi}}, [data])
    values = save(tmp_path, "implementation", {"work/values.json": {
        "S1": {"P1": 0.0}, "S2": {"P1": 1.0}, "C92": {"P1": 0.0}}}, [formula])
    sheet = {"formula_ref": formula["record_path"],
             "values": {"record_ref": values["record_path"], "source_path": "work/values.json", "column": "P1"}}
    checked = history_check.run({"baseline_ids": ["S1", "S2"], "sheets": [sheet]}, tmp_path,
                                tmp_path / ".research/history-checks/one")["result"]
    assert checked["sheets"][0]["flags"] == ["order_reversed"]
    ranked = leaderboard.run({"baseline_ids": ["S1", "S2"], "candidate_ids": ["C92"], "sheets": [sheet]},
                             tmp_path, tmp_path / ".research/leaderboards/one")["result"]
    assert [item["evidence"] for item in ranked["sheets"]] == ["history_reversed"]


def test_flat_maps_and_table_columns_read_the_same_numbers():
    flat = {sample: row["P2"] for sample, row in TABLE.items()}
    assert values_table.column_values(json.dumps(flat), None) == values_table.column_values(json.dumps(TABLE), "P2")


def formula_record(root, depends_on=(), name="f"):
    return save(root, "proxy_formula", {f"{name}/proxy_formula.json": {
        "formula_id": "P2", "expression": "x", "hypothesis_ids": ["H1"], "direction": "higher"}}, depends_on)


def board_args(formula, selection):
    return {"baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"],
            "sheets": [{"formula_ref": formula["record_path"], "values": selection}]}


def test_values_saved_before_their_formula_get_an_error_that_says_how_to_save_them(tmp_path):
    # v19: the values were saved first and the formulas were made to depend on them.
    table = save(tmp_path, "implementation", {"v/values.json": TABLE})
    formula = formula_record(tmp_path, [table])
    selection = {"record_ref": table["record_path"], "source_path": "v/values.json", "column": "P2"}
    for attempt in (lambda: leaderboard.run(board_args(formula, selection), tmp_path, tmp_path / ".research/lb"),
                    lambda: compare(tmp_path, formula, selection)):
        with pytest.raises(ValueError) as error:
            attempt()
        assert values_table.SAVE_ORDER in str(error.value) and "the opposite direction" in str(error.value)


def test_values_in_a_record_of_another_kind_name_that_kind_and_the_save_order(tmp_path):
    formula = formula_record(tmp_path)
    values = save(tmp_path, "calibration", {"v/values.json": TABLE}, [formula])
    selection = {"record_ref": values["record_path"], "source_path": "v/values.json", "column": "P2"}
    with pytest.raises(ValueError, match="is kind=calibration. Save each formula"):
        leaderboard.run(board_args(formula, selection), tmp_path, tmp_path / ".research/lb")
    with pytest.raises(ValueError, match="is kind=calibration. Save each formula"):
        compare(tmp_path, formula, selection)


def test_a_null_column_means_no_column(tmp_path):
    formula = formula_record(tmp_path)
    flat = save(tmp_path, "implementation", {"v/flat.json": {s: row["P2"] for s, row in TABLE.items()}}, [formula])
    selection = {"record_ref": flat["record_path"], "source_path": "v/flat.json", "column": None}
    args = board_args(formula, selection)
    jsonschema.validate(args, leaderboard.INPUT_SCHEMA)
    jsonschema.validate({"baseline_ids": ["TV0", "TV1"], "sheets": args["sheets"]}, history_check.INPUT_SCHEMA)
    sheet, = leaderboard.run(args, tmp_path, tmp_path / ".research/lb")["result"]["sheets"]
    assert sheet["values"]["C1"] == 3.0
    result = compare(tmp_path, formula, selection)
    assert result["values"] == {"record_ref": flat["record_path"], "source_path": "v/flat.json",
                                "sha256": result["values"]["sha256"]}
    assert result["best_candidate"] == {"ids": ["C1"], "value": 3.0}


def test_values_of_an_earlier_formula_version_say_that_the_formula_was_revised(tmp_path):
    # v19: P1 was revised after its values were saved, and the check kept failing on the old values.
    first = formula_record(tmp_path)
    table = save(tmp_path, "implementation", {"v/values.json": TABLE}, [first])
    revised = formula_record(tmp_path, [first], name="f2")
    selection = {"record_ref": table["record_path"], "source_path": "v/values.json", "column": "P2"}
    with pytest.raises(ValueError) as error:
        leaderboard.run(board_args(revised, selection), tmp_path, tmp_path / ".research/lb")
    text = str(error.value)
    assert f"The values depend on {first['record_path']}, which {revised['record_path']} itself builds on" in text
    assert "Save the values table again" in text and "opposite direction" not in text
    other = formula_record(tmp_path, name="f3")
    with pytest.raises(ValueError, match="depends on these formula records: " + first["record_path"]):
        leaderboard.run(board_args(other, selection), tmp_path, tmp_path / ".research/lb")


ROWS = [{"sample_id": "S1", "label": "PHS/R12", "measured": {"EOP_mJ": 53.7, "LCDU_nm": 4.78}},
        {"sample_id": "S2", "label": "PHS/R17", "measured": {"EOP_mJ": 47.9, "LCDU_nm": 4.87}}]


def test_a_list_of_rows_is_read_by_its_id_field_with_nested_columns_named_by_dots():
    # v42 kept its measurements as a list of rows like these, was refused, and copied them into new files.
    text = json.dumps(ROWS)
    assert values_table.column_values(text, "measured.EOP_mJ", "kpi") == {"S1": 53.7, "S2": 47.9}
    with pytest.raises(ValueError, match="Column 'EOP' is missing for: S1, S2. Number columns like it: "
                                         "measured.EOP_mJ"):
        values_table.column_values(text, "EOP", "kpi")
    # Nested columns of an object of rows are named the same way.
    nested = json.dumps({row["sample_id"]: {"measured": row["measured"]} for row in ROWS})
    assert values_table.column_values(nested, "measured.LCDU_nm") == {"S1": 4.78, "S2": 4.87}


def test_a_list_of_rows_needs_one_field_that_names_each_sample():
    two = json.dumps([{"name": f"S{i}", "batch": f"B{i}", "EOP": 50.0 + i} for i in (1, 2)])
    with pytest.raises(ValueError, match=r"several fields could \(name, batch\)"):
        values_table.column_values(two, "EOP", "kpi")
    shared = json.dumps([{"name": "S", "EOP": 50.0}, {"name": "S", "EOP": 51.0}])
    with pytest.raises(ValueError, match="no field has unique sample IDs in every row"):
        values_table.column_values(shared, "EOP", "kpi")
    with pytest.raises(ValueError, match="a list must hold one object per sample"):
        values_table.column_values("[1, 2]", "EOP", "kpi")
    # The shape the messages give names a column, not a formula.
    assert '"<column>": number' in values_table.SHAPE and "<formula id>" not in values_table.SHAPE
