"""Simulation routes, executor, tool and board; local numerical runs only, no model calls."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import board, records
from researchkit.simulation import executor, registry
from researchkit.simulation.models import rc
from researchkit.simulation.route import Route, problems
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install

RC_TREE = "circuit.electrical.rc_tree_delay"
WIRE = "device.electrical.interconnect_rc"
IMAGE = "device.optics.thin_mask_aerial_image"
MMFF = "molecule.energetics.rdkit_mmff_conformers"
EMT = "condensed.energetics.ase_emt_relax"
MD = "condensed.transport.ase_md_diffusion"
BENCH = "algorithm.performance.optimizer_benchmark"


def values(document):
    return {name: item["value"] for name, item in document["values"].items()}


# Registry and declarations


def test_every_route_file_loads_with_a_valid_declaration_and_example():
    found, broken = registry.load()
    assert broken == []
    assert set(found) == {RC_TREE, WIRE, IMAGE, MMFF, EMT, MD, BENCH}
    for route in found.values():
        registry.validate_inputs(route, registry.with_defaults(route.inputs, route.example))


def test_catalog_lists_the_taxonomy_cells_and_filters():
    full = registry.catalog()
    assert full["cells_with_routes"]["device x optics"] == 1 and "organism" in full["objects"]
    assert [row["id"] for row in registry.catalog(object="condensed")["routes"]] == [EMT, MD]
    assert [row["id"] for row in registry.catalog(discipline="lithography")["routes"]] == [IMAGE, MMFF]
    with pytest.raises(ValueError, match="is not one of"):
        registry.catalog(object="planet")


def test_describe_and_unknown_route_suggestions():
    described = registry.describe(WIRE)
    assert described["object"] == "device" and described["outputs"]["t50_s"]["unit"] == "s"
    assert described["available"] and "scipy" in described["installed"]
    with pytest.raises(ValueError, match="closest: device.electrical.interconnect_rc"):
        registry.get("device.electrical.interconect_rc")


def test_declaration_problems_are_reported():
    route = Route(id="device.flavour.sweet", title="t", summary="s", tier="T9", disciplines=("cooking",),
                  inputs={"type": "object"}, outputs={"x": {"unit": "1"}}, assumptions=(), applicability="",
                  uncertainty="", references=(), example={}, run=lambda inputs, workdir: {})
    found = problems(route, package="circuit", module="sweet")
    text = " | ".join(found)
    for expected in ("quantity 'flavour'", "routes/circuit/sweet.py", "tier 'T9'", "cooking", "output 'x'",
                     "assumptions"):
        assert expected in text


# Executor statuses


def test_completed_run_records_inputs_units_environment_and_seed(tmp_path):
    document = executor.run(RC_TREE, {"ladder": {"total_resistance_ohm": 1.0, "total_capacitance_F": 1.0,
                                                 "segments": 20}}, tmp_path)
    assert document["status"] == "completed"
    assert document["inputs"]["ladder"]["driver_resistance_ohm"] == 0  # defaults are filled and kept
    assert document["values"]["worst_elmore_delay_s"]["unit"] == "s"
    assert document["environment"]["packages"]["numpy"] and len(document["input_sha256"]) == 64
    assert document["assumptions"] and document["applicability"]["problems"] == []


def test_invalid_inputs_are_a_usage_error_not_a_record(tmp_path):
    with pytest.raises(ValueError, match="width_nm"):
        executor.run(WIRE, {"thickness_nm": 10}, tmp_path)


def test_outside_applicability_is_refused_with_reasons(tmp_path):
    inputs = dict(registry.get(WIRE).example, width_nm=5)  # W/H = 0.05
    document = executor.run(WIRE, inputs, tmp_path)
    assert document["status"] == "refused" and "W/H = 0.05" in document["reason"]
    assert document["values"] == {}


def test_over_the_time_limit_is_refused_before_running(tmp_path):
    document = executor.run(MD, dict(registry.get(MD).example, production_steps=500000), tmp_path)
    assert document["status"] == "refused" and "job executor" in document["reason"]
    small = executor.run(MD, registry.get(MD).example, tmp_path, time_limit_s=5)
    assert small["status"] == "refused" and "raise time_limit_s" in small["reason"]


def test_missing_package_is_refused(tmp_path):
    with patch.object(registry, "availability", return_value=(["pyscf"], {})):
        document = executor.run(RC_TREE, registry.get(RC_TREE).example, tmp_path)
    assert document["status"] == "refused" and document["reason"] == "unavailable: missing pyscf"


def _module(tmp_path, name, body):
    path = tmp_path / name
    path.write_text(body, encoding="utf-8")
    return lambda requested: tmp_path / requested


def test_route_error_is_failed_and_overrun_is_timeout(tmp_path):
    resolve = _module(tmp_path, "broken.py", "raise RuntimeError('cannot import this optimizer')\n")
    small = {"functions": ["sphere"], "seeds": 3, "budget": 50, "baselines": []}
    failed = executor.run(BENCH, {**small, "candidates": [{"name": "c", "module": "broken.py", "function": "f"}]},
                          tmp_path / "a", resolve_file=resolve)
    assert failed["status"] == "failed" and "cannot import this optimizer" in failed["reason"]
    resolve = _module(tmp_path, "slow.py", "import time\ndef f(f, bounds, budget, rng):\n    time.sleep(60)\n")
    late = executor.run(BENCH, {**small, "candidates": [{"name": "c", "module": "slow.py", "function": "f"}]},
                        tmp_path / "b", time_limit_s=4, resolve_file=resolve)
    assert late["status"] == "timeout" and late["elapsed_s"] < 20


# Numerical content


def test_rc_model_reproduces_single_pole_and_distributed_line_limits():
    single = rc.far_end_delays([{"name": "a", "parent": "source", "resistance_ohm": 2.0, "capacitance_F": 3.0}])
    assert single[0] == pytest.approx(6.0) and single[1] == pytest.approx(6.0 * math.log(2), rel=1e-9)
    elmore, t50, rise = rc.far_end_delays(rc.ladder(1.0, 1.0, 400))
    assert elmore == pytest.approx(0.5, rel=0.01)
    assert 0.375 < t50 < 0.385 and 0.89 < rise < 0.92  # distributed RC line: about 0.38 RC and 0.9 RC
    # A zero-capacitance node in series is eliminated exactly.
    chain = [{"name": "a", "parent": "source", "resistance_ohm": 1.0, "capacitance_F": 0.0},
             {"name": "b", "parent": "a", "resistance_ohm": 1.0, "capacitance_F": 1.0}]
    assert rc.far_end_delays(chain)[1] == pytest.approx(2 * math.log(2), rel=1e-9)
    with pytest.raises(ValueError, match="cycle"):
        rc.build([{"name": "a", "parent": "b", "resistance_ohm": 1, "capacitance_F": 1},
                  {"name": "b", "parent": "a", "resistance_ohm": 1, "capacitance_F": 1}])


def test_interconnect_capacitance_formulas_and_elmore_by_hand(tmp_path):
    inputs = {"width_nm": 50, "thickness_nm": 100, "dielectric_height_nm": 100, "spacing_nm": 100,
              "length_um": 100, "resistivity_ohm_m": 2e-8, "relative_permittivity": 3.0,
              "driver_resistance_ohm": 1000, "load_capacitance_F": 1e-15}
    v = values(executor.run(WIRE, inputs, tmp_path))
    eps = 8.8541878128e-12 * 3.0
    ground = eps * (1.15 * 0.5 + 2.80 * 1.0 ** 0.222) * 100e-6
    coupling = eps * (0.03 * 0.5 + 0.83 * 1.0 - 0.07 * 1.0 ** 0.222) * 1.0 ** -1.34 * 100e-6
    resistance = 2e-8 * 100e-6 / (50e-9 * 100e-9)
    total = ground + 2 * coupling
    assert v["resistance_ohm"] == pytest.approx(resistance)
    assert v["ground_capacitance_F"] == pytest.approx(ground, rel=1e-6)
    assert v["coupling_capacitance_F"] == pytest.approx(coupling, rel=1e-6)
    elmore = 1000 * (total + 1e-15) + resistance * total / 2 + resistance * 1e-15
    assert v["elmore_delay_s"] == pytest.approx(elmore, rel=0.005)
    assert v["t50_s"] < v["elmore_delay_s"]


def test_coherent_aerial_image_matches_two_beam_algebra(tmp_path):
    # pitch 300 nm at 193 nm / NA 0.75 passes orders 0 and +-1 only; E(x) = 1/2 - (2/pi) cos(2 pi x / p).
    document = executor.run(IMAGE, {"wavelength_nm": 193, "numerical_aperture": 0.75, "pitch_nm": 300,
                                    "feature_nm": 150, "illumination": {"sigma": 0.0}}, tmp_path)
    v = values(document)
    assert v["intensity_at_nominal_edge"] == [pytest.approx(0.25)]
    slope = 2 * 0.5 * (2 / math.pi) * (2 * math.pi / 300)
    assert v["nils"] == [pytest.approx(150 * slope / 0.25)]
    assert v["cd_nm"] == [pytest.approx(150.0, abs=0.05)] and v["orders_captured"] == 3.0
    assert {a["path"] for a in document["artifacts"]} == {"aerial_image.csv", "aerial_image.png"}


def test_unresolved_pitch_is_flagged(tmp_path):
    document = executor.run(IMAGE, {"wavelength_nm": 193, "numerical_aperture": 0.5, "pitch_nm": 200,
                                    "feature_nm": 100, "illumination": {"sigma": 0.3}}, tmp_path)
    assert any("below the resolution limit" in w for w in document["warnings"])


def test_mmff_runs_a_small_molecule_and_refuses_missing_parameters(tmp_path):
    done = executor.run(MMFF, {"smiles": "CCCCO", "n_conformers": 10}, tmp_path / "a")
    v = values(done)
    assert done["status"] == "completed" and v["conformers_converged"] >= 1
    assert v["relative_energies_kcal_mol"][0] == 0.0 and done["artifacts"][0]["path"] == "conformers.sdf"
    refused = executor.run(MMFF, {"smiles": "[Li]C"}, tmp_path / "b")
    assert refused["status"] == "refused" and "MMFF94 has no parameters" in refused["reason"]


def test_emt_vacancy_and_mixing_energies(tmp_path):
    vacancy = values(executor.run(EMT, {"host": "Cu", "supercell": 2, "vacancies": 1}, tmp_path / "a"))
    assert vacancy["vacancy_formation_energy_eV"] > 0 and 3.4 < vacancy["host_lattice_constant_A"] < 3.8
    alloy = executor.run(EMT, {"host": "Cu", "supercell": 2, "substitutions": {"Ni": 4}}, tmp_path / "b")
    assert "mixing_energy_eV_per_atom" in alloy["values"]
    assert alloy["details"]["composition"] == {"Cu": 28, "Ni": 4}


def test_md_diffusion_short_run_reports_its_regime(tmp_path):
    document = executor.run(MD, {"potential": "lj", "epsilon_eV": 0.0103, "sigma_A": 3.4, "mass_amu": 39.95,
                                 "density_g_cm3": 1.4, "temperature_K": 90, "cells": 2,
                                 "equilibration_steps": 200, "production_steps": 600}, tmp_path)
    assert document["status"] == "completed" and values(document)["atoms"] == 32
    assert "msd_loglog_exponent" in document["details"] and any("finite box" in w for w in document["warnings"])


def test_benchmark_scores_counted_evaluations_and_keeps_candidate_errors(tmp_path):
    resolve = _module(tmp_path, "opt.py", (
        "def good(f, bounds, budget, rng):\n"
        "    import numpy as np\n"
        "    x = bounds.mean(axis=1)\n"
        "    while True:\n"
        "        x = x + 0.0\n"
        "        f(x)\n"
        "def bad(f, bounds, budget, rng):\n"
        "    f(bounds[:, 0])\n"
        "    raise ValueError('gave up')\n"))
    document = executor.run(BENCH, {"candidates": [{"name": "centre", "module": "opt.py", "function": "good"},
                                                   {"name": "quitter", "module": "opt.py", "function": "bad"}],
                                    "functions": ["sphere"], "seeds": 3, "budget": 100}, tmp_path,
                            resolve_file=resolve)
    assert document["status"] == "completed"
    rows = document["details"]["rows"]
    assert [r["optimizer"] for r in rows] == ["random_search", "nelder_mead", "centre", "quitter"]
    centre = values(document)["median_final_error"][2]
    assert centre > 0  # the shifted optimum is not at the centre of the box
    assert any("gave up" in w for w in document["warnings"])
    assert document["input_files"][0]["field"] == "candidates[0].module"
    assert len(document["details"]["comparisons"]) == 4


# Tool and board


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def tool(ctx, args):
    return next(t for t in TOOLS if t.name == "research_simulate").execute(args, ctx)


def test_tool_catalog_describe_and_run_saves_a_simulation_record(ctx):
    catalog = json.loads(tool(ctx, {"action": "catalog", "object": "device"}).output)
    assert [row["id"] for row in catalog["routes"]] == [WIRE, IMAGE]
    assert json.loads(tool(ctx, {"action": "describe", "route": IMAGE}).output)["tier"] == "T2"
    out = json.loads(tool(ctx, {"action": "run", "route": IMAGE, "input": {
        "wavelength_nm": 193, "numerical_aperture": 0.75, "pitch_nm": 300, "feature_nm": 150}}).output)
    assert out["status"] == "completed" and out["values"]["nils"]["unit"] == "1"
    saved = records.read_record(ctx.directory, out["record_path"])
    assert saved["kind"] == "simulation" and saved["title"] == f"{IMAGE}: completed"
    names = {Path(item["source_path"]).name for item in saved["files"]}
    assert names == {"result.json", "aerial_image.csv", "aerial_image.png"}
    assert json.loads(Path(out["result_file"]).read_text(encoding="utf-8"))["route"]["id"] == IMAGE


def test_refused_runs_are_records_and_a_report_built_on_one_is_flagged(ctx):
    out = json.loads(tool(ctx, {"action": "run", "route": WIRE, "input": dict(registry.get(WIRE).example,
                                                                               width_nm=5)}).output)
    assert out["status"] == "refused"
    workspace = ctx.directory
    (workspace / "report.md").write_text("report\n", encoding="utf-8")
    records.publish(workspace, kind="report", title="r", files=["report.md"], depends_on=[out["record_path"]])
    value = board.build(workspace)
    assert value["simulations"][0]["status"] == "refused"
    texts = [item["text"] for item in value["notice_items"]]
    assert any("狀態 refused" in t and "沒有產生結果" in t for t in texts)
    assert any("report" in t and "不能當作證據" in t for t in texts)
    assert "simulation" in board.render(value)


def test_benchmark_through_the_tool_freezes_the_candidate_code(ctx):
    (ctx.directory / "work").mkdir()
    (ctx.directory / "work/opt.py").write_text(
        "def search(f, bounds, budget, rng):\n    while True:\n        f(rng.uniform(bounds[:, 0], bounds[:, 1]))\n",
        encoding="utf-8")
    out = json.loads(tool(ctx, {"action": "run", "route": BENCH, "input": {
        "candidates": [{"name": "mine", "module": "work/opt.py", "function": "search"}],
        "functions": ["sphere"], "seeds": 3, "budget": 50, "baselines": ["random_search"]}}).output)
    assert out["status"] == "completed"
    saved = records.read_record(ctx.directory, out["record_path"])
    assert "work/opt.py" in {item["source_path"] for item in saved["files"]}
