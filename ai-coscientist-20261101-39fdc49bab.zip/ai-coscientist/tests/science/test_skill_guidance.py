"""A research tool's skill comes back in the host facts when compaction has dropped it; no model calls."""

from types import SimpleNamespace

from researchkit import skill_guidance

RULES = "Put terms at the top level of the template."
SKILLS = {"final-kpi-proxy-discovery": SimpleNamespace(body=RULES), "sample": SimpleNamespace(body="Rank rounds.")}
COMPACTED = {"role": "assistant", "content": "## Objective ...", "compaction_through": "msg_1"}


def call(name, **arguments):
    return {"role": "assistant", "content": "", "tool_calls": [{"id": "c", "name": name, "arguments": arguments}]}


def read(name, **metadata):
    return {"role": "tool", "content": f'<skill_content name="{name}">\n# Skill: {name}\n...</skill_content>',
            "metadata": metadata}


def test_the_skill_of_a_tool_used_since_the_last_compaction_comes_back_when_its_text_is_gone():
    # v40 read the proxy-formula skill in its ninth call and saved its formulas after the first compaction.
    history = [read("final-kpi-proxy-discovery"), COMPACTED, call("research_record", kind="proxy_formula")]
    assert skill_guidance.missing(history, SKILLS) == ["final-kpi-proxy-discovery"]
    text = skill_guidance.context(history, SKILLS)
    assert "skill「final-kpi-proxy-discovery」" in text and text.endswith(RULES)
    # Tools that follow no skill, or a record kind none governs, bring nothing.
    assert skill_guidance.missing([COMPACTED, call("research_list"), call("research_record", kind="implementation")],
                                  SKILLS) == []


def test_nothing_comes_back_while_the_skill_is_still_in_context_or_unused_since_compaction():
    assert skill_guidance.missing([COMPACTED, read("final-kpi-proxy-discovery"), call("research_history_check")],
                                  SKILLS) == []
    # Used only before the last compaction: nothing to bring back until the tool is used again.
    assert skill_guidance.missing([call("research_history_check"), COMPACTED], SKILLS) == []
    # A skill reply cleared by pruning is not in context any more.
    history = [read("final-kpi-proxy-discovery", compacted=1), call("research_history_check")]
    assert skill_guidance.missing(history, SKILLS) == ["final-kpi-proxy-discovery"]


def test_several_tools_bring_their_skills_once_each_and_missing_skills_are_skipped():
    history = [COMPACTED, call("research_leaderboard"), call("research_record", kind="proxy_formula"),
               call("research_compare_candidates"), call("render_report")]
    assert skill_guidance.missing(history, SKILLS) == ["sample", "final-kpi-proxy-discovery"]
    assert skill_guidance.context(history, None) == "" and skill_guidance.context([], SKILLS) == ""


def test_the_report_rules_come_once_the_evolution_says_why_it_stopped():
    # v41 and v42 wrote their reports before reading these rules, and rewrote them after.
    skills = {**SKILLS, "scientific-report-writer": SimpleNamespace(body="Write the answer first.")}
    stopped = call("research_record", kind="sample_evolution", template={"rounds": [], "stop_reason": "three rounds"})
    assert skill_guidance.missing([stopped], skills) == ["sample", "scientific-report-writer"]
    text = skill_guidance.context([stopped], skills)
    assert "演化紀錄已寫明停止理由" in text and text.endswith("Write the answer first.")
    assert "你用過的工具由 skill「sample」規範" in text
    # Not while the rounds go on, and not once a report is saved: its record brings the rules then.
    running = call("research_record", kind="sample_evolution", template={"rounds": []})
    assert skill_guidance.missing([running], skills) == ["sample"]
    assert not skill_guidance.report_next([stopped, call("research_record", kind="report")])
    # A compaction between the end of the rounds and the report does not take them away.
    assert skill_guidance.missing([stopped, COMPACTED], skills) == ["scientific-report-writer"]
