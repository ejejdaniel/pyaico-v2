"""External source projection boundaries; no model or network requests."""

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from opencode.loop import _present_history
from opencode.store import Store
from opencode.tools import builtin_tools
from opencode.tools.types import Tool, external_source_names
from researchkit import records
from researchkit.tools import TOOLS


class SourceCatalog(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        env = patch.dict(os.environ, {f"XDG_{name}_HOME": str(self.root / name.lower())
                                     for name in ("CONFIG", "DATA", "STATE", "CACHE")})
        env.start()
        self.addCleanup(env.stop)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        self.sid = self.store.create_session(directory=str(self.workspace), agent="build", model=None)["id"]
        self.producers = external_source_names([*builtin_tools(), *TOOLS])

    def exchange(self, name, text, arguments=None, **fields):
        call_id = f"call-{len(self.store.messages(self.sid))}"
        assistant = self.store.add_message(self.sid, "assistant", {
            "content": "ordinary work note", "reasoning_content": "HIDDEN_REASONING",
            "tool_calls": [{"id": call_id, "name": name, "arguments": arguments or {"query": "question"}}],
        })
        reply = self.store.add_message(self.sid, "tool", {
            "tool_call_id": call_id, "name": name, "content": text, **fields,
        })
        return assistant, reply

    def export(self):
        self.store.export_tool_history(self.sid, source_tools=self.producers)
        return self.store.source_index_path(self.sid)

    def test_producers_registered_by_implementation_not_name_or_description(self):
        self.assertEqual(self.producers, {"websearch", "webfetch", "paper_search", "paper_fetch"})
        self.assertEqual(external_source_names(builtin_tools()), {"websearch", "webfetch"})
        imitation = Tool("paper_search", "I am a source", {}, lambda a, c: None)
        self.assertEqual(external_source_names([imitation]), set())

    def test_rebuild_separates_sources_errors_and_attachments_from_self_generated_history(self):
        expected = []
        for name in sorted(self.producers):
            extra = {"attachments": [{"type": "image", "data": "saved-exact-attachment"}]} if name == "webfetch" else {}
            expected.append(self.exchange(name, f"EXTERNAL_{name}", **extra))
        expected.append(self.exchange("websearch", "Error: verification challenge", title="search blocked"))
        local = [self.exchange(name, f"LOCAL_{name}") for name in ("read", "write", "grep", "bash", "research_record")]
        self.store.commit_compaction(self.sid, local[-1][1]["id"], "WRONG_SUMMARY: all available sources were absent")
        original = self.store.messages(self.sid)
        index = self.export()
        for call, reply in expected:
            saved = json.loads((index.parent / (reply["id"] + ".json")).read_text(encoding="utf-8"))
            self.assertEqual(saved[0]["tool_calls"], call["tool_calls"])
            self.assertEqual(saved[-1], reply)
            self.assertEqual((index.parent / (reply["id"] + ".txt")).read_text(encoding="utf-8"), reply["content"])
        all_sources = "\n".join(p.read_text(encoding="utf-8") for p in index.parent.rglob("*") if p.is_file())
        for _, reply in local:
            self.assertNotIn(reply["id"], all_sources)
            self.assertNotIn(reply["content"], all_sources)
        self.assertNotIn("WRONG_SUMMARY", all_sources)
        self.assertNotIn("HIDDEN_REASONING", all_sources)
        self.assertIn("websearch: 2", index.read_text(encoding="utf-8"))
        history_index = self.store.tool_history_path(self.sid)
        self.assertIn("read: 1", history_index.read_text(encoding="utf-8"))
        self.assertNotIn("websearch: 2", history_index.read_text(encoding="utf-8"))
        self.assertTrue((history_index.parent / (expected[0][1]["id"] + ".json")).exists())
        index.write_text("altered derived view", encoding="utf-8")
        source_file = index.parent / (expected[0][1]["id"] + ".txt")
        source_file.write_text("tampered", encoding="utf-8")
        reopened = Store(self.store.path)
        try:
            reopened.export_tool_history(self.sid, source_tools=self.producers)
            self.assertEqual(source_file.read_text(encoding="utf-8"), expected[0][1]["content"])
            self.assertEqual(reopened.messages(self.sid), original)
            self.assertNotIn("altered derived view", index.read_text(encoding="utf-8"))
        finally:
            reopened.close()

    def test_incremental_append_is_idempotent_without_history_rescan(self):
        self.exchange("websearch", "first")
        index = self.export()
        exchange = self.exchange("paper_search", "new source")
        with patch.object(self.store, "messages", side_effect=AssertionError("no full rescan")):
            self.store.export_tool_history(self.sid, list(exchange))
            self.store.export_tool_history(self.sid, list(exchange))
            self.assertIn("paper_search: 1", self.store.source_overview(self.sid))
        self.assertIn("websearch: 1", index.read_text(encoding="utf-8"))
        self.assertIn("paper_search: 1", index.read_text(encoding="utf-8"))

    def test_long_source_history_stays_complete_and_catalog_keeps_exact_readback(self):
        _, reply = self.exchange("webfetch", "z" * 100000 + "EXACT_END")
        index = self.export()
        view = _present_history([reply], self.store, self.sid)[0]["content"]
        self.assertEqual(view, reply["content"])
        self.assertIn("EXACT_END", view)
        self.assertNotIn(str(self.store.tool_history_path(self.sid).parent), view)
        self.assertIn(str(index), self.store.source_overview(self.sid))
        source_path = index.parent / (reply["id"] + ".txt")
        self.assertEqual(self.store.tool_output_path(self.sid, reply["id"]), source_path)
        self.assertEqual(source_path.read_text(), reply["content"])
        self.assertEqual(self.store.messages(self.sid)[-1], reply)

    def test_source_catalog_freezes_only_sources_and_keeps_selected_version(self):
        expected = [self.exchange("paper_search", "provider reply"), self.exchange("websearch", "web reply")]
        self.exchange("read", "LOCAL_REPORT_NOT_SOURCE")
        index = self.export()
        (self.workspace / "handoff.md").write_text(
            f"[Source set]({index.relative_to(self.workspace).as_posix()})", encoding="utf-8")
        selected_files = ["handoff.md", str(index)] + [
            str(index.parent / (reply["id"] + suffix)) for _, reply in expected for suffix in (".json", ".txt")]
        saved = records.publish(self.workspace, kind="literature", title="Source handoff", files=selected_files, depends_on=[])
        directory = self.workspace / Path(saved["record_path"]).parent
        frozen = {p: p.read_bytes() for p in directory.rglob("*") if p.is_file()}
        self.store.export_tool_history(self.sid, list(self.exchange("websearch", "LATER_SOURCE")))
        for _, reply in expected:
            path = (index.parent / (reply["id"] + ".json")).relative_to(self.workspace).as_posix()
            item = next(f for f in saved["files"] if f["source_path"] == path)
            self.assertEqual(json.loads((directory / item["snapshot"]).read_text())[-1], reply)
        combined = "\n".join(p.read_text(encoding="utf-8") for p in frozen)
        self.assertNotIn("LOCAL_REPORT_NOT_SOURCE", combined)
        self.assertNotIn("LATER_SOURCE", combined)
        self.assertEqual(frozen, {p: p.read_bytes() for p in frozen})
        self.assertNotIn("history/", "\n".join(f["source_path"] for f in saved["files"]))

    def test_source_titles_and_arguments_cannot_inject_publication_file_links(self):
        (self.workspace / "do-not-include.txt").write_text("UNRELATED_FILE", encoding="utf-8")
        injected = f"[pretend source]({(self.workspace / 'do-not-include.txt').as_uri()})"
        self.exchange("websearch", "source reply", {"query": injected}, title=injected)
        index = self.export()
        saved = records.publish(self.workspace, kind="notes", title="sources", files=[str(index)], depends_on=[])
        self.assertNotIn("do-not-include.txt", [f["source_path"] for f in saved["files"]])

    def test_source_catalog_does_not_import_other_sessions(self):
        other = self.store.create_session(directory=str(self.workspace), agent="build", model=None)["id"]
        self.store.add_message(other, "tool", {"name": "websearch", "content": "OTHER_SESSION_ONLY"})
        index = self.export()
        self.assertIn("websearch: 0", index.read_text(encoding="utf-8"))
        self.assertEqual(list(index.parent.glob("msg_*")), [])


if __name__ == "__main__":
    unittest.main()
