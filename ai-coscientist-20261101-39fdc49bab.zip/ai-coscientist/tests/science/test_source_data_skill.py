"""prepare-source-data: values derived from a source are checked against what the source states; no model calls."""

from pathlib import Path

import researchkit

SKILL = Path(researchkit.__file__).parent / "skills/prepare-source-data/SKILL.md"


def test_derived_values_are_checked_against_what_the_source_states():
    # Room v1 parsed its drawing with its own program, put the door on the wrong wall and took label positions
    # for the loudspeaker centres; LIT v40/v41 misread two ester structures and an onium salt's role. Each time
    # the source's own statement (a dimension, a described role) was at hand and was never compared.
    text = " ".join(SKILL.read_text(encoding="utf-8").split())
    assert "Check every value you derive against what the source itself states about it" in text
    assert "a dimension written on a drawing" in text and "a role or structure described in its text" in text
    assert "a reading error to resolve before anything uses it" in text
