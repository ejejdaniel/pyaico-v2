"""Stored-source search uses the upstream ripgrep boundaries and rendering."""

from pathlib import Path
import shutil
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

from opencode.agent import Agent
from opencode.loop import ToolContext
from opencode.permission import Broker, Rule
from opencode.tools.files import _grep


class SourceSearch(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.ctx = ToolContext(
            app=SimpleNamespace(permissions=Broker(auto=True)), session_id="search-session",
            agent=Agent("build", permission=[Rule("*", "*", "allow")]), message_id="message",
            call_id="call", depth=0, directory=self.root, worktree=self.root, read_files=set(), turn=1,
        )

    def file(self, name, text):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    @unittest.skipUnless(shutil.which("rg"), "Requires existing ripgrep; tests never download executables")
    def test_hidden_receipts_are_searchable_with_native_backend(self):
        self.file("report/report.md", "shared query: an authored judgment")
        self.file(".opencode/history/session/tools/source.txt", "shared query: actual saved source")
        self.file(".research/searches/provider.json", '{"query":"shared query"}')
        self.file(".git/private.txt", "shared query: not a work source")
        for include in (None, "*"):
            with self.subTest(include=include):
                reply = _grep({"pattern": "shared query", "include": include}, self.ctx)
                for expected in ("actual saved source", "provider.json", "authored judgment"):
                    self.assertIn(expected, reply.output)
                self.assertNotIn("not a work source", reply.output)
                self.assertEqual(reply.metadata, {"matches": 3, "truncated": False})

    @unittest.skipUnless(shutil.which("rg"), "Requires existing ripgrep; tests never download executables")
    def test_source_search_reports_the_upstream_100_match_limit(self):
        self.file(".opencode/history/source.txt", "match\n" * 500 + "match LAST_SOURCE_LINE")
        reply = _grep({"pattern": "match"}, self.ctx)
        self.assertEqual(reply.metadata, {"matches": 100, "truncated": True})
        self.assertIn("Found 100 matches (more matches available)", reply.output)
        self.assertIn("Results truncated", reply.output)
        self.assertNotIn("LAST_SOURCE_LINE", reply.output)
        self.assertIn("LAST_SOURCE_LINE", _grep({"pattern": "LAST_SOURCE_LINE"}, self.ctx).output)

    def test_native_execution_failure_propagates(self):
        # core/ripgrep.ts accepts code 2 partial rows. Execution failures remain
        # errors and must not turn into Python-regex or empty results.
        with patch("opencode.tools.files._ripgrep", side_effect=RuntimeError("ripgrep execution failed")) as run, \
             self.assertRaisesRegex(RuntimeError, "ripgrep execution failed"):
            _grep({"pattern": "-literal"}, self.ctx)
        command = run.call_args.args[1]
        self.assertIn("--hidden", command)
        self.assertEqual(command[-3:], ["--", "-literal", "."])

    @unittest.skipUnless(shutil.which("rg"), "Requires existing ripgrep; tests never download executables")
    def test_invalid_native_regex_is_not_an_empty_search(self):
        self.file("source.txt", "source")
        with self.assertRaisesRegex(ValueError, "regex parse error"):
            _grep({"pattern": "("}, self.ctx)
