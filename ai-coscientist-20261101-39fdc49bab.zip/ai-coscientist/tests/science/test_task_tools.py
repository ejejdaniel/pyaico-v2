"""Task tools: routes a task writes, mounts after known-answer tests and runs (simulation/task_tools.py)."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from opencode.app import App
from opencode.loop import ToolContext
from opencode.store import Store
from researchkit import leaderboard, records
from researchkit.tools import TOOLS
from scripts.setup_research_workspace import install

ROUTE = '''
from researchkit.simulation.route import Route

SPEED = 343.0


def check(inputs):
    return ["only rooms up to 100 m"] if inputs["length_m"] > 100 else []


def run(inputs, workdir):
    modes = [n * inputs["speed_m_s"] / (2 * inputs["length_m"]) for n in range(1, inputs["count"] + 1)]
    return {"values": {"axial_modes_hz": modes, "first_mode_hz": modes[0]}}


ROUTE = Route(
    id="task.acoustics.axial_modes", title="Axial room modes",
    summary="Axial mode frequencies of a rigid room along one dimension", tier="T1", disciplines=("physics",),
    inputs={"type": "object", "additionalProperties": False, "required": ["length_m"], "properties": {
        "length_m": {"type": "number", "exclusiveMinimum": 0},
        "speed_m_s": {"type": "number", "default": SPEED},
        "count": {"type": "integer", "minimum": 1, "maximum": 20, "default": 3}}},
    outputs={"axial_modes_hz": {"unit": "Hz", "description": "Axial modes n = 1..count"},
             "first_mode_hz": {"unit": "Hz", "description": "The lowest axial mode"}},
    assumptions=("Rigid walls",), applicability="Rectangular rooms up to 100 m",
    uncertainty="Exact for rigid walls; absorbing walls shift modes by a few percent", references=(),
    example={"length_m": 5.6}, run=run, check=check)
'''
TESTS = [{"name": "a 5.6 m room", "input": {"length_m": 5.6}, "source": "f_n = n c / (2 L), c = 343 m/s",
          "expect": {"first_mode_hz": {"value": 30.625, "tolerance": 0.001},
                     "axial_modes_hz": {"value": [30.625, 61.25, 91.875], "relative": 1e-6}}}]


@pytest.fixture
def ctx(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / ".git").mkdir()
    env = {"OPENCODE_TEST_HOME": str(tmp_path / "home"), "OPENCODE_CONFIG_DIR": str(tmp_path / "config"),
           "XDG_CONFIG_HOME": str(tmp_path / "global-config"), "XDG_DATA_HOME": str(tmp_path / "data"),
           "XDG_STATE_HOME": str(tmp_path / "state"), "XDG_CACHE_HOME": str(tmp_path / "cache")}
    with patch.dict(os.environ, env):
        store = Store(tmp_path / "session.db")
        install(workspace)
        app = App(workspace, store=store, auto_approve=True, config={})
        session = app.create_session()
        yield ToolContext(app, session["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
        store.close()


def other(ctx, session_id):
    return ToolContext(ctx.app, session_id, ctx.agent, "m", "c", 0, ctx.directory, ctx.directory, set(), 1)


def tool(ctx, args):
    return json.loads(next(t for t in TOOLS if t.name == "research_simulate").execute(args, ctx).output)


def write_tool(ctx, name="axial_modes", route=ROUTE, tests=TESTS):
    folder = ctx.directory / ".task" / ctx.session_id / "tools" / name
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "route.py").write_text(route, encoding="utf-8")
    if tests is not None:
        (folder / "tests.json").write_text(json.dumps(tests), encoding="utf-8")
    return folder


def test_a_task_tool_mounts_after_its_known_answer_tests_and_runs_like_a_route(ctx):
    catalog = tool(ctx, {"action": "catalog"})["task_tools"]
    assert catalog["folder"] == f".task/{ctx.session_id}/tools" and catalog["tools"] == []
    folder = write_tool(ctx)
    mounted = tool(ctx, {"action": "mount", "tool": "axial_modes"})
    assert mounted["status"] == "mounted" and mounted["id"] == "task.acoustics.axial_modes"
    assert mounted["tests"] == [{"name": "a 5.6 m room", "status": "passed"}] and len(mounted["version"]) == 64
    saved = records.read_record(ctx.directory, mounted["record_path"])
    assert saved["kind"] == "task_tool" and saved["title"] == "task tool task.acoustics.axial_modes: mounted"
    assert {Path(item["source_path"]).name for item in saved["files"]} == {"route.py", "tests.json", "mount.json",
                                                                           "result.json"}
    [row] = tool(ctx, {"action": "catalog"})["task_tools"]["tools"]
    assert (row["id"], row["status"], row["tests"]) == ("task.acoustics.axial_modes", "mounted",
                                                        "1/1 known-answer tests passed")
    described = tool(ctx, {"action": "describe", "route": "task.acoustics.axial_modes"})
    assert described["runs_user_code"] and described["task_tool"]["tests"][0]["status"] == "passed"
    assert described["task_tool"]["folder"] == f".task/{ctx.session_id}/tools/axial_modes"

    out = tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 3.5}})
    assert out["status"] == "completed" and out["values"]["first_mode_hz"] == {"value": 49.0, "unit": "Hz"}
    assert out["task_tool"] == {"version": mounted["version"], "record_path": mounted["record_path"]}
    run = records.read_record(ctx.directory, out["record_path"])
    assert run["kind"] == "simulation" and run["depends_on"] == [mounted["record_path"]]
    named = next(t for t in TOOLS if t.name == "research_simulate").execute(
        {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 3.5},
         "depends_on": [str(ctx.directory / mounted["record_path"])]}, ctx).output  # the mount, named another way
    reply, note = named.split("\n\nHost note: resolved record references")
    assert note.rstrip().endswith(mounted["record_path"]) and records.read_record(
        ctx.directory, json.loads(reply)["record_path"])["depends_on"] == [mounted["record_path"]]
    assert json.loads(Path(out["result_file"]).read_text(encoding="utf-8"))["route"]["version"] == mounted["version"]

    # Runs use the mounted copy until the tool is mounted again, as a new version.
    route = folder / "route.py"
    route.write_text(route.read_text(encoding="utf-8").replace("SPEED = 343.0", "SPEED = 340.0"), encoding="utf-8")
    again = tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 3.5}})
    assert again["values"]["first_mode_hz"]["value"] == 49.0 and "differs from this mounted version" in \
        again["task_tool"]["note"]
    newer = tool(ctx, {"action": "mount", "tool": "axial_modes"})
    assert newer["status"] == "refused" and "known-answer tests not passed: a 5.6 m room: first_mode_hz" in \
        newer["reason"]  # the change broke the known answer, so the earlier version stays in use
    assert tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes",
                      "input": {"length_m": 3.5}})["task_tool"]["version"] == mounted["version"]
    write_tool(ctx, route=ROUTE.replace("SPEED = 343.0", "SPEED = 340.0"),
               tests=[{**TESTS[0], "expect": {"first_mode_hz": {"value": 340 / 11.2, "tolerance": 0.001}}}])
    fixed = tool(ctx, {"action": "mount", "tool": "axial_modes"})
    assert fixed["status"] == "mounted" and fixed["version"] != mounted["version"]
    latest = tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 3.5}})
    assert latest["values"]["first_mode_hz"]["value"] == pytest.approx(340 / 7) and "note" not in latest["task_tool"]


@pytest.mark.parametrize("change, reason", [
    (lambda route, tests: (route.replace('"task.acoustics.axial_modes"', '"device.acoustics.axial_modes"'), tests),
     "is not task.<quantity>.<name>, lowercase (skill and tool charter article 1)"),
    (lambda route, tests: (route.replace('"task.acoustics.axial_modes"', '"task.acoustics.modes"'), tests),
     "must end with the tool's folder name 'axial_modes' (skill and tool charter article 1)"),
    (lambda route, tests: (route.replace('uncertainty="Exact for rigid walls; absorbing walls shift modes by a few '
                                         'percent"', 'uncertainty=""'), tests),
     "uncertainty must be stated (skill and tool charter article 4)"),
    (lambda route, tests: (route, []), "0 known-answer tests; at least 1 are needed (skill and tool charter article 4)"),
    (lambda route, tests: (route, None), "tests.json is missing (skill and tool charter article 4)"),
    (lambda route, tests: (route, [{**tests[0], "source": ""}]), "needs a source: where its answer comes from"),
    (lambda route, tests: (route, [{**tests[0], "expect": {"first_mode_hz": {"value": 31.0, "tolerance": 0.001}}}]),
     "known-answer tests not passed: a 5.6 m room: first_mode_hz: expected 31.0 within 0.001, got 30.625"),
    (lambda route, tests: (route.replace("ROUTE = Route(", "ROUTES = Route("), tests),
     "its declaration could not be read: TypeError: route.py must define ROUTE = Route(...)"),
])
def test_a_tool_that_breaks_the_charter_or_misses_a_known_answer_is_not_mounted(ctx, change, reason):
    route, tests = change(ROUTE, TESTS)
    write_tool(ctx, route=route, tests=tests)
    out = tool(ctx, {"action": "mount", "tool": "axial_modes"})
    assert out["status"] == "refused" and reason in out["reason"]
    assert records.read_record(ctx.directory, out["record_path"])["kind"] == "task_tool"  # a refusal is kept
    with pytest.raises(ValueError, match="is not mounted in this task; its last mount was refused"):
        tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 3}})


TABLE_ROUTE = '''
import json
from researchkit.simulation.route import Route

PREDICTED = {"TV0": 40.4, "TV1": 40.4, "C1": 31.0, "C2": -10.0}


def run(inputs, workdir):
    table = {sample: {"P1": value * inputs["scale"]} for sample, value in PREDICTED.items()}
    (workdir / "values.json").write_text(json.dumps(table), encoding="utf-8")
    return {"values": {"rows": len(table)}, "artifacts": ["values.json"]}


ROUTE = Route(
    id="task.performance.proxy_table", title="Proxy table", summary="The proxy value of each sample, as a table",
    tier="T1", disciplines=(), inputs={"type": "object", "properties": {"scale": {"type": "number", "default": 1.0}}},
    outputs={"rows": {"unit": "1", "description": "Rows written"}}, assumptions=("A fixed stand-in model",),
    applicability="The four samples of this test", uncertainty="None: a fixed table", references=(), example={},
    run=run)
'''


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        (root / name).parent.mkdir(parents=True, exist_ok=True)
        (root / name).write_text(json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def test_a_tools_values_table_is_ranked_directly(ctx):
    from researchkit import candidate_comparison

    root = ctx.directory
    measured = save(root, "prepared_data", {"data/measured.json": {"TV0": {"EOP": 53.7}, "TV1": {"EOP": 47.9}}})
    formula = save(root, "proxy_formula", {"f/proxy_formula.json": {
        "formula_id": "P1", "expression": "x", "hypothesis_ids": ["H1"], "direction": "target", "target_value": 40,
        "anchor": "mean_offset",
        "measured": {"record_ref": measured["record_path"], "source_path": "data/measured.json", "column": "EOP"}}},
        [measured])
    write_tool(ctx, name="proxy_table", route=TABLE_ROUTE, tests=[
        {"name": "four rows", "input": {}, "expect": {"rows": {"value": 4, "tolerance": 0}},
         "source": "the table holds the four samples of this test"}])
    assert tool(ctx, {"action": "mount", "tool": "proxy_table"})["status"] == "mounted"
    out = tool(ctx, {"action": "run", "route": "task.performance.proxy_table", "input": {},
                     "depends_on": [formula["record_path"]]})
    [selection] = out["artifact_selections"]
    assert selection["record_ref"] == out["record_path"] and selection["source_path"].endswith("/work/values.json")
    values = {**selection, "column": "P1"}
    ranked = leaderboard.run({"baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"],
                              "sheets": [{"formula_ref": formula["record_path"], "values": values}]},
                             root, root / ".research/leaderboards/one")["result"]
    assert ranked["sheets"][0]["candidate_status"]["C1"] == "better"
    compared = candidate_comparison.run({"method_ref": formula["record_path"], "values": values,
                                         "baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"]},
                                        root, root / ".research/method_comparisons/one")["result"]
    assert compared["best_candidate"]["ids"] == ["C1"]
    with pytest.raises(ValueError, match="kind=implementation or kind=simulation record, or the kind=judgment"):
        leaderboard.run({"baseline_ids": ["TV0", "TV1"], "candidate_ids": ["C1", "C2"], "sheets": [
            {"formula_ref": formula["record_path"], "values": {"record_ref": measured["record_path"],
                                                               "source_path": "data/measured.json", "column": "EOP"}}]},
                        root, root / ".research/leaderboards/two")


def test_the_round_review_reads_each_tools_newest_mount_with_its_tests(ctx):
    from researchkit.simulation import task_tools

    write_tool(ctx)
    mounted = tool(ctx, {"action": "mount", "tool": "axial_modes"})
    write_tool(ctx, name="broken", route=ROUTE.replace("axial_modes", "broken"), tests=[])
    tool(ctx, {"action": "mount", "tool": "broken"})
    text = task_tools.review_text(ctx.directory, ctx.session_id)
    assert (f"task.acoustics.axial_modes (Axial room modes): mounted, version {mounted['version'][:12]}, mounted in "
            f"round 1, record {mounted['record_path']}\n  test 'a 5.6 m room', passed: its answer from f_n = n c / "
            "(2 L), c = 343 m/s") in text
    assert "task.acoustics.broken (Axial room modes): refused" in text and "0 known-answer tests" in text
    # The mounted copy runs without leaving a bytecode cache beside it.
    tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 5}})
    assert not list((ctx.directory / ".research").rglob("__pycache__"))


def test_a_task_tools_own_check_refuses_runs_outside_its_applicability(ctx):
    write_tool(ctx)
    tool(ctx, {"action": "mount", "tool": "axial_modes"})
    out = tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 150}})
    assert out["status"] == "refused" and out["reason"] == "outside applicability: only rooms up to 100 m"
    assert records.read_record(ctx.directory, out["record_path"])["kind"] == "simulation"


def test_the_framework_never_imports_a_task_tool(ctx):
    write_tool(ctx, route=ROUTE + "\nimport researchkit.leaderboard\nresearchkit.leaderboard.TAMPERED = True\n")
    assert tool(ctx, {"action": "mount", "tool": "axial_modes"})["status"] == "mounted"
    assert tool(ctx, {"action": "run", "route": "task.acoustics.axial_modes",
                      "input": {"length_m": 5}})["status"] == "completed"
    assert not hasattr(leaderboard, "TAMPERED")


def test_a_tool_belongs_to_its_task_and_its_subagents(ctx):
    write_tool(ctx)
    tool(ctx, {"action": "mount", "tool": "axial_modes"})
    child = ctx.app.store.create_session(directory=str(ctx.directory), agent="build", model=None,
                                         parent_id=ctx.session_id)["id"]
    assert tool(other(ctx, child), {"action": "run", "route": "task.acoustics.axial_modes",
                                    "input": {"length_m": 5}})["status"] == "completed"
    stranger = other(ctx, ctx.app.create_session()["id"])
    assert tool(stranger, {"action": "catalog"})["task_tools"]["tools"] == []
    with pytest.raises(ValueError, match="is not mounted in this task; write it under"):
        tool(stranger, {"action": "run", "route": "task.acoustics.axial_modes", "input": {"length_m": 5}})
    with pytest.raises(ValueError, match="No task tool at"):
        tool(stranger, {"action": "mount", "tool": "axial_modes"})
