"""A quantitative model's coefficients come from the history and the signs; its sheet compares under all of them."""

import json

import pytest

from researchkit import board, candidate_comparison, history_check, leaderboard, records

BASE = ["h1", "h2"]
CANDIDATES = ["cut4", "cut6", "cut9", "mw11"]
# Two historical samples that changed both quantities; candidates that move one of them from h2.
QUANTITIES = {"h1": {"quencher": 35.44, "mw": 7.0}, "h2": {"quencher": 30.23, "mw": 9.0},
              "cut4": {"quencher": 26.23, "mw": 9.0}, "cut6": {"quencher": 24.23, "mw": 9.0},
              "cut9": {"quencher": 21.23, "mw": 9.0}, "mw11": {"quencher": 30.23, "mw": 11.0}}


def save(root, kind, files, depends_on=()):
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(content), encoding="utf-8")
    return records.publish(root, kind=kind, title=kind, files=list(files),
                           depends_on=[ref["record_path"] for ref in depends_on])


def pool(root, terms=None, hypotheses=("H1", "H2"), with_indices=True, quantities=QUANTITIES, tolerance=1.0):
    """Hypotheses, measured EOP, one index formula per hypothesis and the model, and their values table."""
    hypothesis = save(root, "hypothesis", {"h/hypotheses.json": {"hypotheses": [
        {"id": h, "statement": f"mechanism {h}"} for h in hypotheses]}}) if with_indices else None
    data = save(root, "prepared_data", {"d/measured.json": {"h1": {"EOP_mJ": 53.7}, "h2": {"EOP_mJ": 47.9}}})
    measured = {"record_ref": data["record_path"], "source_path": "d/measured.json", "column": "EOP_mJ"}
    kpi = {**measured, "better": "target", "target_value": 40.0}
    up = [hypothesis] if hypothesis else []
    formulas = []
    if with_indices:
        for number, (h, column) in enumerate(zip(hypotheses, ("quencher", "mw")), 1):
            formulas.append(save(root, "proxy_formula", {f"p{number}/proxy_formula.json": {
                "formula_id": f"P{number}", "expression": column, "hypothesis_ids": [h], "direction": "lower",
                "mechanism_predicts": "kpi_rises", "kpi": kpi}}, up))
    model = {"formula_id": "PM", "expression": "EOP = offset + c1*quencher + c2*mw", "hypothesis_ids": list(hypotheses),
             "direction": "target", "target_value": 40.0, "measured": measured, "kpi": kpi,
             **({"tolerance": tolerance} if tolerance is not None else {}),
             "terms": terms or [{"hypothesis_id": "H1", "lever": "quencher_wt", "quantity": "quencher",
                                 "mechanism_predicts": "kpi_rises"},
                                {"hypothesis_id": "H2", "lever": "mw_kda", "quantity": "mw",
                                 "mechanism_predicts": "kpi_rises"}]}
    formulas.append(save(root, "proxy_formula", {"pm/proxy_formula.json": model}, up))
    values = save(root, "implementation", {"v/values.json": quantities}, formulas)
    sheets = [{"formula_ref": f["record_path"], "values": {"record_ref": values["record_path"],
                                                          "source_path": "v/values.json", "column": column}}
              for f, column in zip(formulas[:-1], ("quencher", "mw"))]
    sheets.append({"formula_ref": formulas[-1]["record_path"],
                   "values": {"record_ref": values["record_path"], "source_path": "v/values.json"}})
    return sheets


def notices(root):
    return {item["text"]: item["level"] for item in board.build(root)["notice_items"]}


def test_the_history_check_gives_the_coefficients_the_history_and_signs_allow(tmp_path):
    sheets = pool(tmp_path)
    result = history_check.run({"baseline_ids": BASE, "sheets": sheets[-1:]}, tmp_path,
                               tmp_path / ".research/history-checks/one")["result"]
    row, = result["sheets"]
    assert row["flags"] == ["fitted_history", "coefficients_undetermined"]
    # EOP fell 5.8 while the quencher fell 5.21 wt% and Mw rose: the quencher's term must explain it all.
    assert "c[quencher] (H1) >= 1.113; c[mw] (H2) > 0, size not set" in row["findings"][0]
    assert row["model"]["coefficients"]["quencher"]["high"] is None
    found = notices(tmp_path)
    assert any("定不出量化模型的部分係數" in text and level == "info" for text, level in found.items())


def test_the_model_sheet_says_what_holds_under_every_coefficient_set(tmp_path):
    sheets = pool(tmp_path)
    receipt = leaderboard.run({"baseline_ids": BASE, "candidate_ids": CANDIDATES, "sheets": sheets}, tmp_path,
                              tmp_path / ".research/leaderboards/one")
    model = receipt["result"]["sheets"][-1]
    assert model["evidence"] == "history_fitted" and "values" not in model
    assert model["model"]["band"] == {"h1": "surely_above", "h2": "surely_above", "cut4": "possibly_in",
                                      "cut6": "possibly_in", "cut9": "surely_below", "mw11": "surely_above"}
    # Cutting 6 is surely closer to 40 than cutting 9; raising Mw is surely farther than h2; the rest is open.
    assert model["candidate_status"] == {"cut4": "undecided", "cut6": "undecided", "cut9": "undecided",
                                         "mw11": "worse"}
    assert model["possibly_best"] == ["h2", "cut4", "cut6"]
    assert model["model"]["next_measurements"] == {"c[quencher] (H1)": ["cut4", "cut6", "cut9"],
                                                   "c[mw] (H2)": ["mw11"]}
    rows = {row["id"]: row for row in receipt["result"]["candidates"]}
    # The two samples tie the coefficients together (c_mw = 2.605 c_quencher - 2.9), so under every consistent
    # set cutting 4 wt% also lands closer to 40 than raising Mw to 11, besides being lower on both indices.
    assert rows["mw11"]["dominated_by"] == ["h2", "cut4"]
    shown = leaderboard.summary(receipt)["sheets"][-1]["model"]
    assert shown["band"]["possibly_in"] == ["cut4", "cut6"] and shown["coefficients"].startswith("c[quencher]")
    assert any("是量化模型，係數由歷史樣本與各機制的正負號求得" in text for text in notices(tmp_path))


def test_signs_the_history_contradicts_stop_the_model_before_it_ranks(tmp_path):
    falling = [{"hypothesis_id": "H1", "lever": "quencher_wt", "quantity": "quencher", "mechanism_predicts": "kpi_falls"}]
    sheets = pool(tmp_path, terms=falling, hypotheses=("H1",), with_indices=False)
    row, = history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path,
                             tmp_path / ".research/history-checks/one")["result"]["sheets"]
    assert row["flags"] == ["coefficients_infeasible"] and row["model"]["min_noise"] == pytest.approx(2.9)
    assert "the smallest error that would is 2.9" in row["findings"][0] and "Never change a sign" in row["findings"][0]
    assert any("找不到任何一組" in text and level == "action" for text, level in notices(tmp_path).items())
    with pytest.raises(ValueError, match="no coefficients with the signs its mechanisms give reproduce the history"):
        leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["cut4"], "sheets": sheets}, tmp_path,
                        tmp_path / ".research/leaderboards/one")


def test_a_values_table_without_a_terms_quantity_says_what_it_must_hold(tmp_path):
    partial = {sample: {"quencher": row["quencher"]} for sample, row in QUANTITIES.items()}
    sheets = pool(tmp_path, with_indices=False, quantities=partial)
    with pytest.raises(ValueError, match="holds each term's quantity per sample"):
        history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path, tmp_path / ".research/history-checks/x")


def test_a_values_table_keyed_by_other_sample_ids_names_both_sides(tmp_path):
    # A run (2026-11-01) keyed its rows S1 and S2 where the samples were named by the data file's labels.
    renamed = {{"h1": "S1", "h2": "S2"}.get(sample, sample): row for sample, row in QUANTITIES.items()}
    sheets = pool(tmp_path, with_indices=False, quantities=renamed)
    with pytest.raises(ValueError, match="has no value for h1, h2; that file's sample IDs are S1, S2, cut4"):
        history_check.run({"baseline_ids": BASE, "sheets": sheets}, tmp_path, tmp_path / ".research/history-checks/x")


def test_a_record_that_is_not_a_formula_is_named_for_what_it_is(tmp_path):
    # A run (2026-11-01) passed its implementation record as a formula and was told only what it was not.
    implementation = save(tmp_path, "implementation", {"work/proxy.py.json": {"code": "x"}})
    with pytest.raises(ValueError, match="is a kind=implementation record, not a kind=proxy_formula record"):
        leaderboard._template(tmp_path, implementation["record_path"], None)


def test_a_model_is_ranked_by_the_leaderboard_not_by_a_one_formula_comparison(tmp_path):
    sheets = pool(tmp_path, with_indices=False)
    args = {"method_ref": sheets[-1]["formula_ref"], "values": {**sheets[-1]["values"], "column": "quencher"},
            "baseline_ids": BASE, "candidate_ids": ["cut4"]}
    with pytest.raises(ValueError, match="method_ref is a model with terms: research_leaderboard compares"):
        candidate_comparison.run(args, tmp_path, tmp_path / ".research/method_comparisons/one")


def test_without_a_declared_tolerance_the_band_is_the_target_value_itself(tmp_path):
    # v38's model declared no tolerance, and four candidates predicted below 39 were not marked as overshooting.
    sheets = pool(tmp_path, tolerance=None)
    model = leaderboard.run({"baseline_ids": BASE, "candidate_ids": CANDIDATES, "sheets": sheets}, tmp_path,
                            tmp_path / ".research/leaderboards/one")["result"]["sheets"][-1]["model"]
    assert model["band_tolerance"] == 0
    assert model["band"] == {"h1": "surely_above", "h2": "surely_above", "cut4": "possibly_in",
                             "cut6": "possibly_in", "cut9": "surely_below", "mw11": "surely_above"}


def test_a_sure_loss_on_the_model_sheet_turns_a_surpass_into_a_tradeoff(tmp_path):
    # Far less quencher is lower on the quencher index, a history sheet, but surely overshoots 40 by more
    # than h2 misses it: v38's C2 was called a surpass on the index alone.
    far = {**QUANTITIES, "cut20": {"quencher": 10.23, "mw": 9.0}}
    sheets = pool(tmp_path, quantities=far)
    result = leaderboard.run({"baseline_ids": BASE, "candidate_ids": ["cut20"], "sheets": sheets}, tmp_path,
                             tmp_path / ".research/leaderboards/one")["result"]
    assert [s["evidence"] for s in result["sheets"]] == ["history", "history_reversed", "history_fitted"]
    assert result["sheets"][-1]["candidate_status"] == {"cut20": "worse"}
    candidate, = result["candidates"]
    assert candidate["verdict"] == "tradeoff_surpass" and "PM" in candidate["worse_on"]


def test_a_term_whose_mechanism_gives_no_sign_is_bounded_by_the_history(tmp_path):
    # v42's script said its mechanism gave Mw no sign; the schema made it declare kpi_rises anyway.
    terms = [{"hypothesis_id": "H1", "lever": "quencher_wt", "quantity": "quencher", "mechanism_predicts": "kpi_rises"},
             {"hypothesis_id": "H2", "lever": "mw_kda", "quantity": "mw", "mechanism_predicts": "unknown"}]
    sheets = pool(tmp_path, terms=terms)
    row, = history_check.run({"baseline_ids": BASE, "sheets": sheets[-1:]}, tmp_path,
                             tmp_path / ".research/history-checks/one")["result"]["sheets"]
    # c_mw = 2.605 c_quencher - 2.9: the quencher need no longer explain the whole fall of 5.8 mJ.
    assert "c[quencher] (H1) > 0, size not set; c[mw] (H2): no sign from its mechanism, >= -2.9" in row["findings"][0]
    assert "coefficient_pinned_zero" not in row["flags"]
    receipt = leaderboard.run({"baseline_ids": BASE, "candidate_ids": CANDIDATES, "sheets": sheets}, tmp_path,
                              tmp_path / ".research/leaderboards/one")
    # Raising Mw to 11 was surely worse when Mw had to raise EOP; with no sign it may land nearer 40.
    assert receipt["result"]["sheets"][-1]["candidate_status"]["mw11"] == "undecided"
