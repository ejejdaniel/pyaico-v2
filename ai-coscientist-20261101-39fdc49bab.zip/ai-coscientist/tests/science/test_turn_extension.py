"""Installed turn hooks, permissions and actual CLI delivery; no model requests."""

import io
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode import cli
from opencode.app import App, _load_local_tools
from opencode.permission import PermissionDenied, Rule
from opencode.provider import Completion, ToolCall
from opencode.tools.types import Tool, ToolResult
from researchkit import records
from scripts.setup_research_workspace import install
from test_delivery_acceptance import case, chain, mock_model, repaired, select
from tests.prompt_view import host_facts


def test_ordinary_workspace_does_not_enable_installed_research_module(case):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)
    (root / ".opencode/tools/research.py").unlink()
    plain = App(root, store=app.store, auto_approve=True, config={})
    plain.generate_titles = False
    calls = mock_model(plain, lambda *_: Completion(text="Plain answer", finish_reason='stop'))
    assert plain.turn_extension_factory is None
    assert plain.prompt(session, "Hello")["text"] == "Plain answer"
    assert len(calls) == 1
    assert user["record_path"] not in host_facts(calls[0])
    assert str(app.store.source_index_path(session)) not in host_facts(calls[0])
    assert app.store.tool_history_overview(session) not in host_facts(calls[0])
    # Without an extension the request is assembled exactly as before.
    assert user["record_path"] not in calls[0]["system"]
    assert "## Context labels" not in calls[0]["system"]
    assert not any("<host-facts>" in str(m.get("content")) or str(m.get("content")).startswith("<human id=")
                   for m in calls[0]["messages"])


@pytest.mark.parametrize("source", ["TURN_EXTENSION = 3", "TURN_EXTENSION = lambda *a: object()"])
def test_invalid_extension_fails_before_model(case, source):
    root, app, session = case
    (root / ".opencode/tools/research.py").write_text(source, encoding="utf-8")
    if source.endswith("3"):
        with pytest.raises(RuntimeError, match="callable"):
            App(root, store=app.store, config={})
    else:
        broken = App(root, store=app.store, config={})
        calls = mock_model(broken, lambda *_: pytest.fail("Model must not start"))
        with pytest.raises(TypeError, match="context"):
            broken.prompt(session, "Test")
        assert not calls


def test_duplicate_extension_and_legacy_tools(case):
    root, _, _ = case
    extra = root / ".opencode/tool/extra.py"
    extra.parent.mkdir()
    extra.write_text("TURN_EXTENSION = lambda *args: None", encoding="utf-8")
    with pytest.raises(RuntimeError, match="Multiple"):
        _load_local_tools(root)
    extra.write_text("TOOLS = []", encoding="utf-8")
    (root / ".opencode/tools/research.py").write_bytes(b"from researchkit.tools import TOOLS\n")
    tools, factory = _load_local_tools(root)
    assert tools and factory is None
    install(root)
    assert (root / ".opencode/tools/research.py.pre-turn-extension.bak").read_bytes() == b"from researchkit.tools import TOOLS\n"
    install(root)
    assert _load_local_tools(root)[1] is not None
    (root / ".opencode/tools/research.py").write_text("# User change\n", encoding="utf-8")
    with pytest.raises(ValueError, match="Existing plugin differs"):
        install(root)


@pytest.mark.parametrize("agent", ["title", "summary", "compaction"])
def test_private_agents_do_not_create_extensions(case, agent):
    _, app, session = case
    app.turn_extension_factory = lambda *a: pytest.fail("No private-agent extension")
    calls = mock_model(app, lambda *_: Completion(text="Private answer", finish_reason='stop'))
    assert app.prompt(session, "Text", agent=agent)["text"] == "Private answer"
    assert len(calls) == 1 and not calls[0]["tools"]


def test_prior_unready_delivery_does_not_reopen_repairs_on_read_only_followup(case):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)
    before = {p: p.read_bytes() for p in (root / ".research").rglob("*") if p.is_file()}
    calls = mock_model(app, lambda *_: Completion(text="The saved review covers the earlier report.", finish_reason='stop'))
    app.prompt(session, "只讀說明現有 review 的審查範圍，不要修改或重新發布成果。")
    assert len(calls) == 1
    assert user["record_path"] in host_facts(calls[0])
    assert "已保存的交付工作" in host_facts(calls[0])
    assert not any(m.get("synthetic") for m in app.store.messages(session))
    assert all(p.read_bytes() == contents for p, contents in before.items())
    assert len(records.inventory(root)) == 5


def test_current_unready_delivery_feedback_is_not_a_user_or_model_statement(case):
    root, app, session = case
    *_, user = chain(root)

    def answer(n, _):
        if n == 1:
            select(app, session, user)
        return Completion(text="Still unsupported.", finish_reason='stop')

    calls = mock_model(app, answer)
    app.prompt(session, "Original human commission")
    assert len(calls) == 2
    # Locate by explicit host label rather than relying on optional working-context messages.
    notifications = [m for m in calls[1]["messages"] if m.get("content", "").startswith("[宿主執行檢查")]
    assert len(notifications) == 1 and notifications[0]["role"] == "assistant"
    history = app.store.messages(session)
    assert [m["content"] for m in history if m["role"] == "user"] == ["Original human commission"]
    assert len([m for m in history if m.get("synthetic")]) == 1
    index = app.store.export_work_history(session).read_text(encoding="utf-8")
    assert "host notification" in index


def test_permission_denial_blocks_delivery_reads(case):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)
    app.agents["build"].permission.append(Rule("read", ".research/*", "deny"))
    calls = mock_model(app, lambda *_: pytest.fail("Denied source must not reach model"))
    with pytest.raises(PermissionDenied):
        app.prompt(session, "Continue")
    assert not calls


def test_permission_switch_removes_research_context_and_feedback(case):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)

    def switch(args, ctx):
        ctx.app.store.update_session(session, agent="restricted")
        return ToolResult(output="Switched")

    from dataclasses import replace
    app.agents["restricted"] = replace(app.agents["build"], name="restricted",
                                       permission=[Rule("*", "*", "allow"), Rule("research_record", "*", "deny")])
    app.extra_tools.append(Tool("switch", "test switch", {"type": "object"}, switch))
    calls = mock_model(app, lambda n, kw: Completion(tool_calls=[ToolCall("s", "switch", {})], finish_reason='tool-calls')
                       if n == 1 else Completion(text="Restricted answer", finish_reason='stop'))
    assert app.prompt(session, "Switch")["text"] == "Restricted answer"
    assert len(calls) == 2
    assert "已保存的交付工作" in host_facts(calls[0])
    assert "已保存的交付工作" not in host_facts(calls[1])
    assert app.store.tool_history_overview(session) in host_facts(calls[0])
    assert app.store.tool_history_overview(session) not in host_facts(calls[1])


def test_prompt_tools_denial_disables_research_context_and_delivery_without_mutating_agent(case):
    root, app, session = case
    *_, user = chain(root)
    select(app, session, user)
    shared_rules = list(app.agents["build"].permission)
    calls = mock_model(app, lambda *_: Completion(text="Plain answer", finish_reason="stop"))
    result = app.prompt(session, "Continue without research publication", tools={"research_record": False})
    assert result["text"] == "Plain answer"
    assert len(calls) == 1
    assert user["record_path"] not in host_facts(calls[0])
    assert app.store.tool_history_overview(session) not in host_facts(calls[0])
    assert not any(tool["name"] == "research_record" for tool in calls[0]["tools"])
    assert {"permission": "research_record", "pattern": "*", "action": "deny"} in app.store.get_session(session)["permission"]
    assert app.agents["build"].permission == shared_rules


def ready_delivery(root):
    _, review, _, report, _ = chain(root)
    _, lca, user = repaired(root, review, report)
    return report, lca, user


def publish_on_turn(app, session, user, text="Only a repair explanation"):
    def answer(n, kw):
        if n == 1:
            return Completion(tool_calls=[ToolCall("deliver", "research_record", {
                "kind": "user_report", "title": user["title"],
                "files": [f["source_path"] for f in user["files"]], "depends_on": user["depends_on"]})], finish_reason='tool-calls')
        kw["on_text"](text) if kw.get("on_text") else None
        return Completion(text=text, finish_reason='stop')
    return mock_model(app, answer)


def test_cli_delivers_frozen_document_not_last_repair_body_and_does_not_repost(case):
    root, app, session = case
    *_, unready = chain(root)
    select(app, session, unready)
    _, _, user = ready_delivery(root)
    calls = publish_on_turn(app, session, user)
    terminal = io.StringIO()
    with redirect_stdout(terminal):
        cli._print_prompt(app, session, "Finish original study", SimpleNamespace(agent=None, model=None))
    output = terminal.getvalue()
    assert "[Final response]" in output
    assert "Bounded study delivered; source support unresolved." in output
    assert (root / user["record_path"]).parent.as_posix() in output
    assert "本輪工作說明（模型原文）" in output
    assert len(calls) == 2
    assert not any(m.get("synthetic") for m in app.store.messages(session))
    assert all("已保存的交付文件" not in m.get("content", "") for m in app.store.messages(session))
    (root / "new-user.md").unlink()
    calls = mock_model(app, lambda *_: Completion(text="Follow-up answer", finish_reason='stop'))
    assert app.prompt(session, "Another question")["text"] == "Follow-up answer"
    assert len(calls) == 1


def test_many_files_budget_non_utf8_and_report_paths(case):
    root, app, session = case
    report, lca, _ = ready_delivery(root)
    (root / "extra.md").write_bytes(b"\xef\xbb\xbfSECOND FULL DOCUMENT")
    (root / "long.txt").write_bytes(b"X" * (50 * 1024 + 1))
    (root / "bad.txt").write_bytes(b"\xff\xfe")
    (root / "attachment.bin").write_bytes(b"binary")
    (root / "render.html").write_text("<html>Report</html>", encoding="utf-8")
    (root / "render.pdf").write_bytes(b"%PDF-test")
    rendered = records.publish(root, kind="report", title="Rendered", files=["new.md", "render.html", "render.pdf"], depends_on=[])
    from test_delivery_acceptance import review_file, record
    review_file(root, rendered)
    review = records.publish(root, kind="review", title="Review", files=["review.json"], depends_on=[rendered["record_path"]])
    lca = record(root, "final_lca", "render-lca.md", "Conditional", [rendered["record_path"], review["record_path"]])
    user = records.publish(root, kind="user_report", title="Multiple docs",
                           files=["new-user.md", "extra.md", "long.txt", "bad.txt", "attachment.bin"],
                           depends_on=[rendered["record_path"], lca["record_path"]])
    publish_on_turn(app, session, user)
    text = app.prompt(session, "Deliver")["text"]
    assert "SECOND FULL DOCUMENT" in text and "不是有效 UTF-8" in text and "未展開" in text
    assert "X" * 100 not in text
    for f in user["files"]:
        assert f["sha256"] in text
        assert (root / user["record_path"]).parent.joinpath(f["snapshot"]).as_posix() in text
    for f in rendered["files"][1:]:
        assert f["sha256"] in text
        assert (root / rendered["record_path"]).parent.joinpath(f["snapshot"]).as_posix() in text


def test_snapshot_tampering_never_displays_valid_delivery(case):
    root, app, session = case
    _, _, user = ready_delivery(root)
    def answer(n, _):
        select(app, session, user)
        path = (root / user["record_path"]).parent / user["files"][0]["snapshot"]
        path.write_bytes(b"tampered")
        return Completion(text="Done", finish_reason='stop')
    app.agents["build"].steps = 1
    calls = mock_model(app, answer)
    result = app.prompt(session, "Deliver")
    assert "科研交付尚未接妥" in result["text"]
    assert "已保存的交付文件" not in result["text"]
    assert len(calls) == 1


def test_cli_does_not_reprint_identical_streamed_answer(case):
    _, app, session = case
    def answer(_, kw):
        kw["on_text"]("Plain ")
        kw["on_text"]("answer")
        return Completion(text="Plain answer", finish_reason='stop')
    mock_model(app, answer)
    output = io.StringIO()
    with redirect_stdout(output):
        cli._print_prompt(app, session, "Hello", SimpleNamespace(agent=None, model=None))
    assert output.getvalue() == "Plain answer"


def test_answer_review_keeps_scientific_delivery_checks_and_frozen_report(case):
    root, app, session = case
    # Explicit extension activation needs an explicitly installed skill document.
    from opencode import skills
    guidance = Path(skills.__file__).parent / "skill_assets/investigate/SKILL.md"
    installed = root / ".opencode/skills/investigate/SKILL.md"
    installed.parent.mkdir()
    installed.write_bytes(guidance.read_bytes())
    app.agents["build"].options["answer_review_skill"] = "investigate"
    *_, unready = chain(root)

    def answer(n, _):
        if n == 1:
            select(app, session, unready)
        return Completion(text="Unsupported claim", finish_reason='stop')

    calls = mock_model(app, answer)
    app.agents["build"].steps = 2
    result = app.prompt(session, "Check this study")
    human = [m for m in app.store.messages(session) if m["role"] == "user"][-1]
    assert result["status"] == "step_limit" and len(calls) == 2
    assert app.store.answer_review(session, human["id"])["phase"] == "collecting"
    assert "本輪已停止" in result["text"]
    assert "已保存的交付文件" not in result["text"]
    expected_feedback = records.delivery_repair_packet(unready["record_path"],
                          records.delivery_issues(root, unready["record_path"]))
    assert expected_feedback
    assert any(m.get("synthetic") and expected_feedback in m.get("content", "")
               for m in app.store.messages(session))

    _, _, ready = ready_delivery(root)
    app.agents["build"].steps = 8
    calls = publish_on_turn(app, session, ready)
    result = app.prompt(session, "Deliver the corrected study")
    assert len(calls) == 3  # Publication, candidate, one checked final.
    assert "Bounded study delivered; source support unresolved." in result["text"]
    assert ready["record_path"] in result["text"]
    assert len([m for m in app.store.messages(session) if m.get("answer_review_role") == "answer"]) == 1


def test_delivery_shows_unanswered_action_notices_to_the_human(case):
    root, app, session = case
    *_, unready = chain(root)
    select(app, session, unready)
    _, _, user = ready_delivery(root)
    (root / "orphan.md").write_text("A formula with no hypothesis", encoding="utf-8")
    records.publish(root, kind="proxy_formula", title="Orphan formula", files=["orphan.md"], depends_on=[])
    publish_on_turn(app, session, user)
    terminal = io.StringIO()
    with redirect_stdout(terminal):
        cli._print_prompt(app, session, "Finish original study", SimpleNamespace(agent=None, model=None))
    output = terminal.getvalue()
    assert "尚未處理的宿主提醒" in output and "沒有依賴任何 hypothesis 紀錄" in output
    assert output.index("尚未處理的宿主提醒") < output.index("本輪工作說明（模型原文）")
