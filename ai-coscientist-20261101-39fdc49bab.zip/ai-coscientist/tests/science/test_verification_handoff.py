"""Prescribed provider turns exercise real tools, not autonomous scientific review.

The arithmetic fixture is only a deterministic handoff probe. The assertions
below belong to this test harness; they do not add a runtime acceptance gate.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import shlex
import sys
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

from opencode.app import App
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from opencode.tools.shell import _shell_executable
from researchkit import records, review
from scripts.setup_research_workspace import install
from tests.prompt_view import plain_messages


PROGRAM = """from pathlib import Path
import sys

values = [int(line) for line in Path("operands.txt").read_text(encoding="utf-8").splitlines()]
output = f"total={sum(values)}\\n"
if sys.argv[1] != "incomplete":
    output += f"count={len(values)}\\n"
raw = output.encode("utf-8")
Path("output.txt").write_bytes(raw)
sys.stdout.buffer.write(raw)
raise SystemExit(7 if sys.argv[1] == "failed" else 0)
"""


class VerificationHandoff(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".git").mkdir()
        env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"),
            "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_CONFIG_HOME": str(self.root / "global-config"),
            "XDG_DATA_HOME": str(self.root / "data"),
            "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
            "PYTHONUTF8": "1", "PYTHONDONTWRITEBYTECODE": "1",
        })
        env.start()
        self.addCleanup(env.stop)
        shell = "powershell.exe" if os.name == "nt" else _shell_executable({"shell": "bash"})
        if os.name != "nt" and Path(shell).stem.lower() != "bash":
            self.skipTest("A real Bash executable is required for this boundary replay")
        self.store = Store(self.root / "session.db")
        self.addCleanup(self.store.close)
        install(self.workspace)
        self.app = App(self.workspace, store=self.store, auto_approve=True,
                       config={"shell": shell, "steps": 12})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]
        self.inputs = b"13\n-5\n8\n"
        self.expected = "total=16\ncount=3\n"
        self.claim = "The three supplied integers have a sum of 16."
        for name, data in {"calculate.py": PROGRAM.encode(), "operands.txt": self.inputs,
                           "claim.txt": (self.claim + "\n").encode()}.items():
            (self.workspace / name).write_bytes(data)
        self.calls = []
        self.observed = {}

    def stored_tool(self, call_id):
        return next(message for message in self.store.messages(self.sid)
                    if message["role"] == "tool" and message["tool_call_id"] == call_id)

    def presented_tool(self, request, call_id):
        return next(message["content"] for message in plain_messages(request["messages"])
                    if message["role"] == "tool" and message["tool_call_id"] == call_id)

    def assert_complete_execution(self, request):
        receipt = self.stored_tool("execute")
        presented = self.presented_tool(request, "execute")
        # Native provider messages contain tool text; exit/truncation metadata
        # remains in the store. Check both instead of equating loop completion
        # or the presence of a plausible number with verified execution.
        self.assertEqual(presented, receipt["content"])
        self.assertEqual(receipt["metadata"].get("exit"), 0, "command must exit zero")
        self.assertFalse(receipt["metadata"].get("error"))
        self.assertIs(receipt["metadata"].get("truncated"), False)
        raw = (self.workspace / "output.txt").read_bytes()
        self.assertEqual(raw, self.expected.encode(), "complete arithmetic output is required")
        # PowerShell can prepend its own startup diagnostics and translate
        # newlines. Preserve the whole tool return above and require the exact
        # file output to reach the next turn, with only newline normalization.
        self.assertIn(raw.decode(), presented.replace("\r\n", "\n").replace("\r", "\n"))
        self.assertEqual((self.workspace / "operands.txt").read_bytes(), self.inputs)
        self.observed["stdout"] = raw.decode()

    def run_handoff(self, mode="success"):
        def tool(call_id, name, **arguments):
            return Completion(tool_calls=[ToolCall(call_id, name, arguments)], finish_reason="tool-calls")

        def complete(**request):
            self.calls.append(request)
            turn = len(self.calls)
            if turn == 1:
                if os.name == "nt":
                    quote = lambda value: "'" + value.replace("'", "''") + "'"
                    command = "& " + " ".join(map(quote, [sys.executable, "calculate.py", mode]))
                    command += "; exit $LASTEXITCODE"
                else:
                    command = shlex.join([sys.executable, "calculate.py", mode])
                return tool("execute", "bash", command=command, timeout=10000)
            if turn == 2:
                self.assert_complete_execution(request)
                return tool("implementation", "research_record", kind="implementation",
                            title="Executed arithmetic handoff fixture",
                            files=["calculate.py", "operands.txt", "output.txt", "claim.txt"])
            if turn == 3:
                receipt = json.loads(self.presented_tool(request, "implementation"))
                self.observed["implementation"] = receipt
                self.observed["frozen"] = {Path(item["snapshot"]): Path(item["snapshot"]).read_bytes()
                                           for item in receipt["files"]}
                # Deliberately change only the working output after publication.
                # Later review must still read and quote the recorded version.
                return tool("change-working-output", "write", filePath=str(self.workspace / "output.txt"),
                            content="Working output changed after publication.\n")
            if turn == 4:
                receipt = self.observed["implementation"]
                return Completion(tool_calls=[
                    ToolCall("read-" + item["source_path"], "read", {"filePath": item["snapshot"]})
                    for item in receipt["files"]
                ], finish_reason="tool-calls")
            if turn == 5:
                receipt = self.observed["implementation"]
                for item in receipt["files"]:
                    call_id = "read-" + item["source_path"]
                    presented = self.presented_tool(request, call_id)
                    self.assertEqual(self.stored_tool(call_id)["metadata"]["path"], item["snapshot"])
                    self.assertFalse(self.stored_tool(call_id)["metadata"]["truncated"])
                    frozen = self.observed["frozen"][Path(item["snapshot"])].decode()
                    for number, line in enumerate(frozen.splitlines(), 1):
                        self.assertIn(f"{number}: {line}", presented)
                output = self.presented_tool(request, "read-output.txt")
                self.assertNotIn("Working output changed", output)
                ref = receipt["record_path"]
                value = {
                    "reviewed_refs": [ref],
                    "checks": [{
                        "subject": {"record_ref": ref, "source_path": "claim.txt", "quote": self.claim},
                        "evidence": [
                            {"record_ref": ref, "source_path": "output.txt",
                             "quote": self.observed["stdout"].strip()},
                            {"record_ref": ref, "source_path": "operands.txt", "quote": self.inputs.decode().strip()},
                        ],
                        "decision": "supported",
                        "reason": "The recorded arithmetic output matches this claim for these three inputs only.",
                    }],
                }
                self.observed["review"] = value
                return tool("write-review", "write", filePath=str(self.workspace / "audit/review.json"),
                            content=json.dumps(value))
            if turn == 6:
                return tool("publish-review", "research_record", kind="review", title="Arithmetic fixture review",
                            files=["audit/review.json"], depends_on=[self.observed["implementation"]["record_path"]])
            if turn == 7:
                self.observed["published_review"] = json.loads(self.presented_tool(request, "publish-review"))
                return Completion(text="The saved arithmetic fixture was reviewed within its stated scope.",
                                  finish_reason="stop")
            self.fail("Unexpected extra provider turn")

        self.app.provider = SimpleNamespace(
            resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"), complete=complete)
        return self.app.prompt(self.sid, "Execute and preserve the arithmetic fixture, then review its saved output.")

    def test_real_execution_reaches_snapshot_readback_and_exact_review(self):
        result = self.run_handoff()
        self.assertEqual(result["status"], "completed")
        self.assertEqual(len(self.calls), 7)
        implementation = self.observed["implementation"]
        self.assertEqual({item["source_path"] for item in implementation["files"]},
                         {"calculate.py", "operands.txt", "output.txt", "claim.txt"})
        self.assertEqual(implementation["depends_on"], [])
        self.assertEqual((self.workspace / "operands.txt").read_bytes(), self.inputs)
        self.assertEqual((self.workspace / "calculate.py").read_bytes(), PROGRAM.encode())
        self.assertNotEqual((self.workspace / "output.txt").read_text(), self.expected)
        for path, data in self.observed["frozen"].items():
            self.assertEqual(path.read_bytes(), data)
        saved = self.observed["published_review"]
        self.assertEqual(saved["depends_on"], [implementation["record_path"]])
        raw = Path(saved["files"][0]["snapshot"]).read_bytes()
        self.assertEqual(json.loads(raw), self.observed["review"])
        verified = {implementation["record_path"]: records.read_record(self.workspace, implementation["record_path"])}
        review.validate(self.workspace, raw, saved["depends_on"], verified)
        self.assertEqual(sorted(item["kind"] for item in records.inventory(self.workspace)),
                         ["implementation", "review"])
        self.assertEqual(self.observed["review"]["checks"][0]["evidence"][0]["quote"],
                         self.observed["stdout"].strip())

    def test_nonzero_exit_with_plausible_output_is_not_verified(self):
        with self.assertRaisesRegex(AssertionError, "command must exit zero"):
            self.run_handoff("failed")
        self.assertEqual(self.stored_tool("execute")["metadata"]["exit"], 7)
        self.assertIn(self.expected, self.presented_tool(self.calls[-1], "execute").replace("\r\n", "\n"))
        self.assertEqual((self.workspace / "output.txt").read_bytes(), self.expected.encode())
        self.assert_unpublished()

    def test_zero_exit_with_incomplete_output_is_not_verified(self):
        with self.assertRaisesRegex(AssertionError, "complete arithmetic output is required"):
            self.run_handoff("incomplete")
        self.assertEqual(self.stored_tool("execute")["metadata"]["exit"], 0)
        self.assertIn("total=16\n", self.presented_tool(self.calls[-1], "execute").replace("\r\n", "\n"))
        self.assertEqual((self.workspace / "output.txt").read_bytes(), b"total=16\n")
        self.assert_unpublished()

    def assert_unpublished(self):
        self.assertEqual(len(self.calls), 2)
        self.assertEqual(records.inventory(self.workspace), [])
        self.assertFalse((self.workspace / "audit/review.json").exists())
        self.assertEqual((self.workspace / "operands.txt").read_bytes(), self.inputs)


if __name__ == "__main__":
    unittest.main()
