"""Context-selection boundaries, not claims about a real model's reasoning."""

import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from opencode.app import App
from opencode.context import working_context
from opencode.loop import _present_history
from opencode.provider import Completion, ToolCall, openai_messages_from_history
from opencode.store import Store
from opencode.tools import builtin_tools
from opencode.tools.types import external_source_names
from researchkit.records import publish, read_record


class WorkingContextTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.env = patch.dict(os.environ, {
            "OPENCODE_TEST_HOME": str(self.root / "home"), "OPENCODE_CONFIG_DIR": str(self.root / "config"),
            "XDG_CONFIG_HOME": str(self.root / "global-config"),
            "XDG_DATA_HOME": str(self.root / "data"), "XDG_STATE_HOME": str(self.root / "state"),
            "XDG_CACHE_HOME": str(self.root / "cache"),
        })
        self.env.start()
        self.addCleanup(self.env.stop)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".git").mkdir()
        self.store = Store(self.root / "test.db")
        self.addCleanup(self.store.close)
        self.app = App(self.workspace, store=self.store, auto_approve=True, config={})
        self.app.generate_titles = False
        self.sid = self.app.create_session()["id"]

    def add(self, role, **data):
        return self.store.add_message(self.sid, role, data)

    def old_work(self):
        (self.workspace / "calculation.json").write_text('{"value": 4.25}', encoding="utf-8")
        record = publish(self.workspace, kind="calculation", title="Saved calculation",
                         files=["calculation.json"], depends_on=[])
        request = self.add("user", content="Keep completed calculations. Audit saved source receipts.")
        self.add("assistant", content="Checking sources", tool_calls=[{
            "id": "original", "name": "websearch", "arguments": {"query": "source question"}}])
        source = self.add("tool", name="websearch", tool_call_id="original",
                          content="A saved source snippet. Scope is not full text.")
        self.add("assistant", content="Old claim: the source is absent.")
        summary = self.store.commit_compaction(self.sid, source["id"],
            "Old claim: the source is absent. Proposed next step: remove the citation.")
        self.add("user", content="Continue the same work")
        note = self.add("assistant", content="Old working explanation", reasoning_content="private-protocol",
                        tool_calls=[{"id": "old-scan", "name": "bash", "arguments": {"command": "old narrow scan"}}])
        scan = self.add("tool", name="bash", tool_call_id="old-scan", content="NARROW_SCAN " * 20000)
        self.add("assistant", content="Prior answer with two points: 1. saved calculation; 2. source absent.")
        self.store.set_todos(self.sid, [{"id": "1", "content": "Audit sources", "status": "pending"}])
        return request, source, summary, note, scan, record

    def project(self):
        self.store.export_tool_history(self.sid, source_tools=external_source_names(builtin_tools()))
        self.store.export_work_history(self.sid)
        history = _present_history(self.store.context_messages(self.sid), self.store, self.sid)
        return working_context(history, self.store, self.sid)

    def test_committed_summary_and_uncovered_history_are_not_selected_again(self):
        request, source, summary, note, scan, record = self.old_work()
        current = self.add("user", content="Recheck point 2 against actual saved sources. Do not recompute.")
        before = self.store.messages(self.sid)
        todos = self.store.todos(self.sid)
        projection = self.project()
        wire = json.dumps(openai_messages_from_history(projection))
        self.assertIn("NARROW_SCAN", wire)
        # message-v2.ts preserves stored output; truncation happens during execution.
        self.assertIn(scan["content"], json.dumps(projection))
        self.assertNotIn(request["content"], wire)
        self.assertNotIn(request["id"], [m.get("id") for m in projection])
        self.assertIn("Prior answer with two points", wire)
        self.assertNotIn("Saved human messages omitted from the later context", wire)
        self.assertNotIn("immutable current goal", wire)
        self.assertNotIn("can supersede", wire)
        self.assertIn(summary["content"], wire.replace("\\n", "\n"))
        history = _present_history(self.store.context_messages(self.sid), self.store, self.sid)
        self.assertEqual(projection, history)
        self.assertEqual(projection[-1], current)
        self.assertEqual(self.store.messages(self.sid), before)
        self.assertEqual(self.store.todos(self.sid), todos)
        self.assertEqual(read_record(self.workspace, record["record_path"])["files"], record["files"])
        self.assertEqual((self.workspace / "calculation.json").read_text(), '{"value": 4.25}')
        index = self.store._receipt_index_path(self.sid, "history", "conversation")
        saved_note = json.loads((index.parent / (note["id"] + ".json")).read_text(encoding="utf-8"))
        self.assertEqual(saved_note["content"], note["content"])
        self.assertNotIn("reasoning_content", saved_note)
        self.assertEqual(json.loads((index.parent / (summary["id"] + ".json")).read_text(encoding="utf-8")), summary)
        self.assertEqual(self.store.tool_output_path(self.sid, scan["id"]).read_text(encoding="utf-8"), scan["content"])
        self.assertEqual(self.store.tool_output_path(self.sid, source["id"]).read_text(encoding="utf-8"), source["content"])
        self.assertIn(source["id"], self.store.source_overview(self.sid))

    def test_current_tools_and_correction_remain_intact_after_restart(self):
        self.old_work()
        current = self.add("user", content="Verify, do not simply reuse the prior judgment")
        call = self.add("assistant", content="Checking the actual receipt", reasoning_content="current-protocol",
                        tool_calls=[{"id": "read-new", "name": "read", "arguments": {"filePath": "receipt.json"}}])
        reply = self.add("tool", name="read", tool_call_id="read-new", content="The source exists as a snippet.")
        correction = self.add("assistant", content="Corrected earlier absence claim; full text is still unavailable.")
        projected = self.project()
        self.assertEqual([m["id"] for m in projected[-4:]], [current["id"], call["id"], reply["id"], correction["id"]])
        self.assertEqual(projected[-3]["reasoning_content"], "current-protocol")
        reopened = Store(self.store.path)
        try:
            # Exporting views after reopening reproduces the same context, no model reconstruction.
            reopened.export_tool_history(self.sid, source_tools=external_source_names(builtin_tools()))
            history = _present_history(reopened.context_messages(self.sid), reopened, self.sid)
            self.assertEqual(working_context(history, reopened, self.sid), projected)
        finally:
            reopened.close()

    def test_short_followup_and_first_long_turn_keep_original_content(self):
        self.add("user", content="first request")
        self.add("assistant", content="correct prior answer", reasoning_content="retained-protocol")
        self.add("user", content="explain the answer")
        projected, history = self.project(), self.store.context_messages(self.sid)
        self.assertEqual(len(projected), len(history))
        self.assertEqual(projected[0], history[0])
        self.assertEqual(projected[2], history[2])
        self.assertEqual(projected[1], history[1])
        other = self.store.create_session(directory=str(self.workspace), agent="build", model=None)["id"]
        self.store.add_message(other, "user", {"content": "Long running task"})
        self.store.add_message(other, "assistant", {"content": "ongoing work " * 20000})
        history = self.store.context_messages(other)
        shown = working_context(history, self.store, other)
        self.assertEqual(len(shown), len(history))
        self.assertEqual(shown[0], history[0])
        self.assertEqual(shown[1], history[1])

    def test_normal_correction_survives_next_question_without_erasing_original_claim(self):
        self.old_work()
        self.add("user", content="Recheck source")
        self.add("assistant", content="Correction: snippet exists; do not treat it as full text.")
        self.add("user", content="Use that corrected access scope")
        projection = self.project()
        self.assertIn("Correction: snippet exists", json.dumps(projection))
        self.assertIn("Old claim: the source is absent", json.dumps(self.store.messages(self.sid)))

    def test_small_turns_keep_protocol_and_no_isolated_tool_reply_is_selected(self):
        self.old_work()
        call = self.add("assistant", content="Publish saved file", reasoning_content="last-protocol",
                        tool_calls=[{"id": "save", "name": "write", "arguments": {"filePath": "out.txt", "content": "saved"}}])
        self.add("tool", name="write", tool_call_id="save", content="Saved")
        self.add("user", content="What was saved?")
        projection = self.project()
        wire = openai_messages_from_history(projection)
        calls = {c["id"] for m in wire for c in m.get("tool_calls", [])}
        self.assertTrue(all(m["tool_call_id"] in calls for m in wire if m["role"] == "tool"))
        kept = next(m for m in projection if m.get("id") == call["id"])
        self.assertEqual(kept["reasoning_content"], "last-protocol")

    def test_source_overview_is_bounded_and_excludes_self_written_report(self):
        for i in range(30):
            self.add("assistant", tool_calls=[{"id": str(i), "name": "websearch", "arguments": {"query": f"question {i}"}}])
            self.add("tool", name="websearch", tool_call_id=str(i), content="Search reply", title="web result")
        self.add("tool", name="write", content="SELF_AUTHORED_VERDICT")
        self.project()
        overview = self.store.source_overview(self.sid)
        self.assertIn("websearch: 30", overview)
        self.assertIn("additional replies omitted", overview)
        self.assertNotIn("SELF_AUTHORED_VERDICT", overview)

    def test_loop_uses_new_projection_without_extra_summary_model_call(self):
        self.old_work()
        captured = []
        from types import SimpleNamespace
        class Provider:
            def resolve(self, model):
                return SimpleNamespace(id="test", context=131072), "test"
            def complete(self, **kwargs):
                captured.append(kwargs)
                return Completion(text="Test answer; not a claim of real source verification.", finish_reason='stop')
        self.app.provider = Provider()
        outcome = self.app.prompt(self.sid, "Verify source existence")
        self.assertEqual(outcome["status"], "completed")
        # No summary model call (every call carries tools); an extra call is the unattended todo reminder.
        self.assertTrue(all(call.get("tools") for call in captured))
        self.assertLessEqual(len(captured), 2)
        self.assertIn("NARROW_SCAN", json.dumps(captured[0]["messages"]))
        self.assertIn("Old claim: the source is absent. Proposed next step: remove the citation.", json.dumps(captured[0]["messages"]))
        self.assertIn("The exact model ID is test/test", captured[0]["system"])
        self.assertEqual(captured[0]["messages"][-1]["content"], "Verify source existence")

    def test_current_todos_survive_compaction_and_restart_without_inheriting_other_sessions(self):
        self.old_work()
        old = self.add("assistant", content="Prior plan", tool_calls=[{
            "id": "plan", "name": "todowrite", "arguments": {"todos": []}}])
        last = self.add("tool", name="todowrite", tool_call_id="plan", content="Old todo list was completed")
        self.store.commit_compaction(self.sid, last["id"], "Earlier account says everything is done.")
        current = [{"id": "audit", "content": "Check the selected source version", "status": "pending", "priority": "high"},
                   {"id": "calculation", "content": "Existing calculation retained", "status": "completed", "priority": "medium"}]
        self.store.set_todos(self.sid, current)
        other = self.app.create_session()["id"]
        self.store.set_todos(other, [{"content": "OTHER_SESSION_PRIVATE", "status": "pending"}])
        request = self.add("user", content="Continue the saved work")
        before = self.store.messages(self.sid)
        projected = self.project()
        self.assertEqual(projected[0]["role"], "assistant")
        # todo.ts stores state; prompt.ts does not create a permanent todo message.
        self.assertEqual(projected, self.store.context_messages(self.sid))
        self.assertNotIn("Check the selected source version", json.dumps(projected))
        self.assertNotIn("OTHER_SESSION_PRIVATE", json.dumps(projected))
        self.assertEqual(projected[-1], request)
        self.assertEqual(self.store.messages(self.sid), before)
        self.assertEqual(self.store.todos(self.sid), current)
        reopened = Store(self.store.path)
        try:
            history = _present_history(reopened.context_messages(self.sid), reopened, self.sid)
            self.assertEqual(working_context(history, reopened, self.sid)[0], projected[0])
            self.assertEqual(reopened.todos(self.sid), current)
        finally:
            reopened.close()

    def test_latest_todo_write_reaches_next_model_call_as_tool_output(self):
        from types import SimpleNamespace
        old = [{"id": "1", "content": "Unfinished check", "status": "pending", "priority": "medium"}]
        revised = [{"id": "1", "content": "Completed check with selected evidence", "status": "completed", "priority": "medium"}]
        self.store.set_todos(self.sid, old)
        captured = []
        def complete(**kwargs):
            captured.append(kwargs)
            if len(captured) == 1:
                self.assertNotIn("Unfinished check", json.dumps(kwargs["messages"]))
                return Completion(tool_calls=[ToolCall("todo", "todowrite", {"todos": revised})], finish_reason='tool-calls')
            reply = next(m for m in kwargs["messages"] if m["role"] == "tool")
            self.assertEqual(json.loads(reply["content"]), revised)
            return Completion(text="Finished this check.", finish_reason='stop')
        self.app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                            complete=complete)
        self.assertEqual(self.app.prompt(self.sid, "Continue")["status"], "completed")
        self.assertEqual(len(captured), 2)
        self.assertEqual(self.store.todos(self.sid), revised)
        self.assertFalse(any("Current saved todo list" in m.get("content", "") for m in self.store.messages(self.sid)))

    def test_oversized_todos_remain_saved_without_automatic_prompt_injection(self):
        value = [{"id": "long", "content": "中文內容 " * 20000 + " EXACT_TODO_TAIL", "status": "pending", "priority": "high"}]
        self.store.set_todos(self.sid, value)
        request = self.add("user", content="Continue")
        projected = self.project()
        self.assertEqual(projected, [request])
        self.assertEqual(self.store.todos(self.sid), value)
        self.assertEqual(projected[-1], request)
        self.store.set_todos(self.sid, [{"content": "replacement", "status": "completed"}])
        self.assertEqual(self.project(), [request])
        self.assertEqual(self.store.todos(self.sid)[0]["content"], "replacement")
        self.assertEqual(self.store.todos(self.sid)[0]["status"], "completed")

    def test_projection_does_not_silently_drop_history_for_a_smaller_private_budget(self):
        self.add("user", content="older request " * 300)
        self.add("assistant", content="older answer " * 300)
        current = self.add("user", content="current request")
        self.store.set_todos(self.sid, [{"content": "long task " * 600, "status": "pending"}])
        projected = self.project()
        self.assertEqual(projected[-1], current)
        self.assertNotIn("long task", json.dumps(projected))
        history = self.store.context_messages(self.sid)
        self.assertEqual(projected, history)

    def test_todos_do_not_add_a_completion_gate_or_reopen_completed_items(self):
        from types import SimpleNamespace
        todos = [{"id": "1", "content": "Still pending", "status": "pending", "priority": "medium"},
                 {"id": "2", "content": "Already done", "status": "completed", "priority": "low"}]
        self.store.set_todos(self.sid, todos)
        self.app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=131072), "test"),
                                           complete=lambda **kw: Completion(text="Returning a partial result.", finish_reason='stop'))
        self.assertEqual(self.app.prompt(self.sid, "Report current status")["status"], "completed")
        self.assertEqual(self.store.todos(self.sid), todos)
        self.store.set_todos(self.sid, [])
        self.assertFalse(any("Current saved todo list" in m.get("content", "") for m in self.project()))

    def test_pending_tool_exchange_is_not_split_by_todo_projection(self):
        self.add("user", content="Begin")
        call = self.add("assistant", tool_calls=[{"id": "unanswered", "name": "read", "arguments": {"filePath": "a"}}])
        latest = self.add("user", content="One more constraint")
        self.store.set_todos(self.sid, [{"content": "Observe previous read", "status": "in_progress"}])
        history = self.store.context_messages(self.sid)
        projected = working_context(history, self.store, self.sid)
        self.assertEqual(projected, history)
        self.assertEqual(projected[-2]["id"], call["id"])
        self.assertEqual(projected[-1]["id"], latest["id"])

    def test_covered_human_messages_are_not_reinserted_beside_the_summary(self):
        original = self.add("user", content="Original commission")
        followups = []
        for i in range(20):
            followups.append(self.add("user", content=f"Earlier followup {i}"))
            last = self.add("assistant", content=f"Earlier answer {i}")
        summary = self.store.commit_compaction(self.sid, last["id"],
            "The human changed the scope: no new computation. Prior results saved.")
        latest = self.add("user", content="Only explain the saved result")
        before = self.store.messages(self.sid)
        projected = self.project()
        wire = json.dumps(projected)
        for message in [original, *followups]:
            self.assertNotIn(message["content"], wire)
            self.assertIn(message, before)
        self.assertNotIn("Saved human messages omitted", wire)
        self.assertNotIn("Earlier answer 0", wire)
        self.assertEqual(projected, [summary, latest])
        self.assertEqual(self.store.messages(self.sid), before)

    def test_oversized_covered_human_message_stays_saved_without_context_refill(self):
        body = "中文內容 " * 20000 + " EXACT_HUMAN_TAIL"
        huge = self.add("user", content=body)
        noted = self.add("assistant", content="noted")
        summary = self.store.commit_compaction(self.sid, noted["id"], "Earlier account only.")
        latest = self.add("user", content="Continue from the saved requests")
        projected = self.project()
        self.assertEqual(projected, [summary, latest])
        self.assertNotIn(huge["id"], [m.get("id") for m in projected])
        self.assertNotIn("EXACT_HUMAN_TAIL", json.dumps(projected))
        self.assertEqual(self.store.messages(self.sid)[0]["content"], body)

    def test_scripted_usage_compaction_keeps_saved_todos_and_uncovered_request(self):
        from types import SimpleNamespace
        original = self.add("user", content="Original commission: preserve saved calculations. " * 20)
        for i in range(6):
            self.add("assistant", tool_calls=[{"id": f"read-{i}", "name": "read", "arguments": {"filePath": f"saved-{i}.txt"}}])
            self.add("tool", tool_call_id=f"read-{i}", name="read", content="Large working observation " * 4000)
        self.store.set_todos(self.sid, [{"content": "Current todo " * 400, "status": "pending"}])
        # compaction.ts triggers on recorded provider usage, not character estimates.
        self.add("assistant", content="Prior work recorded", tokens={"input_tokens": 23500, "output_tokens": 100},
                 finish_reason="stop")
        calls = []
        provider = SimpleNamespace(id="test", context=24000)
        def complete(**kwargs):
            calls.append(kwargs)
            if not kwargs.get("tools"):
                return Completion(text="Human requests and constraints: no recomputation. Saved work retained.", finish_reason='stop')
            messages = kwargs["messages"]
            self.assertNotIn(original["content"], json.dumps(messages))
            self.assertIn("Continue without recomputation", json.dumps(messages))
            # The unattended stop reminder may preview a todo; the full saved text never enters context.
            self.assertNotIn("Current todo " * 10, json.dumps(messages))
            self.assertIn("Human requests and constraints: no recomputation. Saved work retained.", json.dumps(messages))
            return Completion(text="Partial answer", finish_reason='stop')
        self.app.provider = SimpleNamespace(resolve=lambda _: (provider, "test"), complete=complete)
        self.app.prompt(self.sid, "Continue without recomputation")
        self.assertGreater(len(calls), 1)
        # One summary call (no tools) plus the turn; an unattended stop with a pending todo is reminded once.
        self.assertEqual(sum(not c.get("tools") for c in calls), 1)
        self.assertEqual(sum(bool(c.get("tools")) for c in calls), 2)
        self.assertEqual(self.store.todos(self.sid)[0]["status"], "pending")


if __name__ == "__main__":
    unittest.main()
