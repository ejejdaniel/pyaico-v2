"""Observer stop policy for ordinary tool errors; no model, network or Common loop."""

from types import SimpleNamespace

import pytest

from scripts.continuation_error_policy import (
    RecoverableToolErrors, RepeatedToolErrorPolicy, latest_tool_receipt)

PLANNING_ERROR = "Error: A supplied commission must observe the latest human message."


def test_first_validation_error_is_left_to_the_agent_and_a_correction_resets():
    policy = RepeatedToolErrorPolicy()
    assert policy.observe("planning_update", error=PLANNING_ERROR) is None
    assert policy.observe("planning_update", error=None) is None
    assert policy.observe("planning_update", error=PLANNING_ERROR) is None


def test_same_error_repeated_stops_but_a_changed_error_is_progress():
    policy = RepeatedToolErrorPolicy(repeat_limit=2)
    assert policy.observe("planning_update", error=PLANNING_ERROR) is None
    assert policy.observe("planning_update", error="Error: different field") is None
    reason = policy.observe("planning_update", error="Error: different field")
    assert reason and "same error 2 times" in reason


def test_many_consecutive_failures_across_tools_stop():
    policy = RepeatedToolErrorPolicy(repeat_limit=9, consecutive_limit=3)
    assert policy.observe("read", error="a") is None
    assert policy.observe("grep", error="b") is None
    assert "3 consecutive" in policy.observe("bash", error="c")


def test_invalid_limits_are_rejected():
    with pytest.raises(ValueError):
        RepeatedToolErrorPolicy(repeat_limit=0)


class _Base:
    def __init__(self, apps):
        self.apps, self.stopped, self.base_calls = apps, [], []

    def stop(self, reason):
        self.stopped.append(reason)

    def tool_finished(self, event):
        self.base_calls.append(event)
        if event.get("title") == "error":
            self.stop("base stops on every error")


class _Observed(RecoverableToolErrors, _Base):
    pass


def _app(messages):
    return SimpleNamespace(store=SimpleNamespace(messages=lambda session_id: messages))


def test_mixin_reads_saved_receipt_and_keeps_boundary_tools_strict():
    messages = [{"role": "tool", "name": "planning_update", "content": PLANNING_ERROR}]
    observed = _Observed([_app(messages)])
    event = {"sessionID": "s", "tool": "planning_update", "title": "error"}
    observed.tool_finished(event)
    assert observed.stopped == [] and observed.base_calls == []
    observed.tool_finished(event)
    assert len(observed.stopped) == 1 and PLANNING_ERROR[:40] in observed.stopped[0]
    strict = _Observed([_app([])])
    strict.tool_finished({"sessionID": "s", "tool": "research_review", "title": "error"})
    assert strict.stopped == ["base stops on every error"]


def test_latest_receipt_selects_newest_message_for_that_tool():
    messages = [{"role": "tool", "name": "planning_update", "content": "old"},
                {"role": "tool", "name": "read", "content": "other"},
                {"role": "tool", "name": "planning_update", "content": "new"}]
    assert latest_tool_receipt([_app(messages)], "s", "planning_update") == "new"
    assert latest_tool_receipt([_app(messages)], "s", "bash") == ""
