import json
import os
import tempfile
import unittest
from pathlib import Path

from opencode.agent import build_agents
from opencode.config import load_config, merge_config
from opencode.jsonc import loads
from opencode.patch import apply_chunks, parse_patch
from opencode.permission import Broker, PermissionDenied, evaluate, from_config
from opencode.provider import Completion, ToolCall
from opencode.store import Store
from opencode.tools.files import _edit, _glob, _grep, _read, _write


class JsoncTests(unittest.TestCase):
    def test_comments_and_trailing_commas(self):
        data = loads(
            """
            {
              // comment
              "model": "openai/gpt-4.1",
              "permission": {"bash": "ask",},
            }
            """
        )
        self.assertEqual(data["model"], "openai/gpt-4.1")
        self.assertEqual(data["permission"]["bash"], "ask")


class PermissionTests(unittest.TestCase):
    def test_last_match_wins(self):
        rules = from_config({"read": {"*": "allow", "*.env": "ask", "*.env.example": "allow"}})
        self.assertEqual(evaluate("read", "app/.env", rules).action, "ask")
        self.assertEqual(evaluate("read", "app/.env.example", rules).action, "allow")
        self.assertEqual(evaluate("edit", "src/main.py", rules).action, "ask")

    def test_plan_denies_edits(self):
        agents = build_agents({}, worktree=Path("."))
        rule = evaluate("edit", "D:/repo/src/app.py", agents["plan"].permission)
        self.assertEqual(rule.action, "deny")
        allowed = evaluate("edit", ".opencode/plans/ses.md", agents["plan"].permission)
        self.assertEqual(allowed.action, "allow")

    def test_broker_deny(self):
        broker = Broker()
        with self.assertRaises(PermissionDenied):
            broker.ask(
                session_id="ses",
                permission="edit",
                patterns=["src/app.py"],
                ruleset=from_config({"edit": "deny"}),
            )


class ConfigTests(unittest.TestCase):
    def test_merge_instructions(self):
        merged = merge_config({"instructions": ["AGENTS.md"]}, {"instructions": ["AGENTS.md", "extra.md"], "model": "a/b"})
        self.assertEqual(merged["instructions"], ["AGENTS.md", "extra.md"])
        self.assertEqual(merged["model"], "a/b")

    def test_load_project_file(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            os.environ["OPENCODE_TEST_HOME"] = str(root / "home")
            os.environ["OPENCODE_DISABLE_PROJECT_CONFIG"] = ""
            (root / "opencode.jsonc").write_text('{ "model": "openai/gpt-4.1", "default_agent": "plan", }', encoding="utf-8")
            config = load_config(root)
            self.assertEqual(config["model"], "openai/gpt-4.1")
            self.assertEqual(config["default_agent"], "plan")


class PatchTests(unittest.TestCase):
    def test_update_file(self):
        original = "def greet():\n    print('Hi')\n"
        patch = """*** Begin Patch
*** Update File: src/app.py
@@ def greet():
-    print('Hi')
+    print('Hello')
*** End Patch
"""
        hunks = parse_patch(patch)
        updated = apply_chunks(original, hunks[0].chunks, "src/app.py")
        self.assertIn("Hello", updated)
        self.assertNotIn("Hi", updated)


class ToolTests(unittest.TestCase):
    def test_read_edit_write_grep_glob(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            target = root / "hello.py"
            target.write_text("value = 1\n", encoding="utf-8")
            ctx = _ctx(root)
            listed = _glob({"pattern": "*.py", "path": str(root)}, ctx)
            self.assertIn("hello.py", listed.output)
            found = _grep({"pattern": "value", "path": str(root)}, ctx)
            self.assertIn("value = 1", found.output)
            read = _read({"filePath": str(target)}, ctx)
            self.assertIn("1: value = 1", read.output)
            edited = _edit({"filePath": str(target), "oldString": "value = 1", "newString": "value = 2"}, ctx)
            self.assertEqual("Edit applied successfully.", edited.output)
            self.assertEqual(target.read_text(encoding="utf-8"), "value = 2\n")
            other = root / "new.txt"
            written = _write({"filePath": str(other), "content": "hi\n"}, ctx)
            self.assertTrue(other.exists(), written.output)
            with self.assertRaises(ValueError):
                _edit({"filePath": str(target), "oldString": "missing", "newString": "x"}, ctx)
            unread = root / "other.py"
            unread.write_text("x = 1\n", encoding="utf-8")
            _edit({"filePath": str(unread), "oldString": "x = 1", "newString": "x = 2"}, ctx)
            self.assertEqual(unread.read_text(encoding="utf-8"), "x = 2\n")


class LoopTests(unittest.TestCase):
    def test_tool_then_answer(self):
        from opencode.app import App

        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            os.environ["OPENCODE_TEST_HOME"] = str(root / "home")
            (root / "note.txt").write_text("hello from disk\n", encoding="utf-8")
            store = Store(root / "state.db")
            app = App(root, store=store, auto_approve=True, config={"model": "fake/test"})
            app.generate_titles = False
            app.provider = ScriptedProvider(
                [
                    Completion(tool_calls=[ToolCall(id="call_1", name="read", arguments={"filePath": str(root / "note.txt")})], finish_reason='tool-calls'),
                    Completion(text="the file says hello", finish_reason='stop'),
                ]
            )
            session = app.create_session()
            result = app.prompt(session["id"], "read the note")
            self.assertEqual(result["text"], "the file says hello")
            roles = [item["role"] for item in store.messages(session["id"])]
            self.assertEqual(roles, ["user", "assistant", "tool", "assistant"])
            store.close()


class ScriptedProvider:
    def __init__(self, responses):
        self.responses = list(responses)
        self.provider = type("P", (), {"id": "fake", "context": 100000})()

    def resolve(self, model=None):
        return self.provider, "test"

    def complete(self, **kwargs):
        if not self.responses:
            return Completion(text="", finish_reason='stop')
        return self.responses.pop(0)


def _ctx(root: Path):
    from opencode.agent import build_agents

    class Ctx:
        pass

    ctx = Ctx()
    ctx.directory = root
    ctx.worktree = root
    ctx.session_id = "ses_test"
    ctx.agent = build_agents({}, worktree=root)["build"]
    ctx.read_files = set()
    ctx.turn = 1
    ctx.app = type("App", (), {"permissions": Broker(auto=True), "store": _MemoryStore()})()
    return ctx


class _MemoryStore:
    def save_snapshot(self, *args, **kwargs):
        return None

    def set_todos(self, session_id, todos):
        return todos


class ServerTests(unittest.TestCase):
    def test_health_and_session(self):
        from opencode.app import App
        from opencode.server import Server
        import urllib.request

        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            os.environ["OPENCODE_TEST_HOME"] = str(root / "home")
            store = Store(root / "state.db")
            app = App(root, store=store, auto_approve=True, config={})
            app.generate_titles = False
            server = Server(app, "127.0.0.1", 0)
            server.start()
            try:
                health = json.load(urllib.request.urlopen(server.url + "/global/health"))
                self.assertTrue(health["healthy"])
                page = urllib.request.urlopen(server.url + "/").read().decode("utf-8")
                self.assertIn("opencode", page)
                request = urllib.request.Request(
                    server.url + "/session",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                created = json.load(urllib.request.urlopen(request))
                self.assertTrue(created["id"].startswith("ses_"))
            finally:
                server.httpd.shutdown()
                store.close()


if __name__ == "__main__":
    unittest.main()
