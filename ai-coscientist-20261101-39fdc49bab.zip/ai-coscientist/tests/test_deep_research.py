"""Deep research is on or off per task (opencode/deep.py); no real model is run."""

from types import SimpleNamespace

import pytest

from opencode import deep
from opencode.app import App
from opencode.config import validate_config
from opencode.provider import Completion, ToolCall
from opencode.store import Store

MODULE = '''
from opencode.tools.types import Tool, ToolResult

TOOLS = [Tool("deep_probe", "A stand-in research tool.", {"type": "object", "properties": {}},
              lambda args, ctx: ToolResult(output="probed"))]


class Turn:
    def __init__(self, app, session_id, user_message_id):
        pass

    def context(self):
        return "Research board (stand-in)."

    def feedback(self):
        return None

    def present(self, text, status):
        return text


TURN_EXTENSION = Turn
'''


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    modules = tmp_path / "modules"
    modules.mkdir()
    (modules / "deep_standin.py").write_text(MODULE, encoding="utf-8")
    monkeypatch.syspath_prepend(str(modules))
    guide = tmp_path / "research-guide.md"
    guide.write_text("Research guide: plan one complete delivery.", encoding="utf-8")
    skill = tmp_path / "skills" / "mindmap"
    skill.mkdir(parents=True)
    (skill / "SKILL.md").write_text("---\nname: mindmap\ndescription: Draw the study's mind map.\n---\nMap it.\n",
                                    encoding="utf-8")
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    config = {"deep": {"instructions": [str(guide)], "skills": [str(tmp_path / "skills")],
                       "tool_modules": ["deep_standin"]}}
    app = App(project, store=Store(tmp_path / "session.db"), config=config, auto_approve=True)
    app.generate_titles = False
    yield app
    app.store.close()


def model(app, replies):
    calls = []
    responses = iter(replies)

    def complete(**kwargs):
        calls.append(kwargs)
        return next(responses)

    app.provider = SimpleNamespace(resolve=lambda target: (SimpleNamespace(id="test", context=131072), "test"),
                                   output_limit=lambda p, m: 8000, complete=complete)
    return calls


def names(call):
    return {tool["name"] for tool in call["tools"] or []}


def test_deep_research_loads_apart_and_comes_only_while_the_task_has_it_on(case):
    app = case
    assert [tool.name for tool in app.deep.tools] == ["deep_probe"] and "mindmap" in app.deep.skills
    assert "deep_probe" not in {tool.name for tool in app.extra_tools} and "mindmap" not in app.skills
    session = app.create_session()["id"]
    calls = model(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(session, "What does notes.md say?")
    # Off by default: the general agent, and one line on how to turn deep research on.
    off = calls[0]
    assert "deep_probe" not in names(off) and "read" in names(off)
    assert "Research guide" not in off["system"] and "mindmap" not in off["system"]
    assert deep.HINT in off["system"] and "Research board" not in str(off["messages"])
    # On, from the next message: its tools, guides, skills and turn extension.
    deep.set_on(app.store, session, True)
    calls = model(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Now study why.")
    on = calls[0]
    assert "deep_probe" in names(on) and "Research guide: plan one complete delivery." in on["system"]
    assert "mindmap" in on["system"] and deep.HINT not in on["system"]
    assert "Research board (stand-in)." in str(on["messages"])
    # A subagent works for the same task.
    child = app.store.create_session(directory=str(app.directory), agent="build", model=None, parent_id=session)["id"]
    assert deep.is_on(app, child) and not deep.is_on(app, app.create_session()["id"]) and not deep.is_on(app, None)


def test_a_deep_skill_loads_only_while_deep_research_is_on(case):
    app = case
    session = app.create_session()["id"]
    calls = model(app, [Completion(tool_calls=[ToolCall("s1", "skill", {"name": "mindmap"})],
                                   finish_reason="tool-calls"), Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Load the mind map skill.")
    reply = [m for m in calls[1]["messages"] if m["role"] == "tool"][-1]
    assert "not found" in str(reply["content"])
    deep.set_on(app.store, session, True)
    calls = model(app, [Completion(tool_calls=[ToolCall("s2", "skill", {"name": "mindmap"})],
                                   finish_reason="tool-calls"), Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Load it now.")
    reply = [m for m in calls[1]["messages"] if m["role"] == "tool"][-1]
    assert "Map it." in str(reply["content"])


def test_the_deep_configuration_is_checked():
    validate_config({"deep": {"instructions": ["a.md"], "skills": [], "tool_modules": ["m"]}})
    for bad, message in (([], "deep must be an object"), ({"tool_modules": "m"}, "deep.tool_modules"),
                         ({"skills": [""]}, "deep.skills")):
        with pytest.raises(ValueError, match=message):
            validate_config({"deep": bad})
    assert not deep.Deep() and deep.Deep(tools=[object()])


def test_research_tools_find_their_skill_among_deep_researchs(tmp_path):
    # LIT through the switch (2026-10-31): the mind-map tool looked only in the general skills, found no
    # mindmap-builder, and the run went to hypotheses without a mind map.
    import threading
    from pathlib import Path

    from opencode.permission import Broker, Rule
    from researchkit import method_exploration, mindmap

    skills = Path(__file__).resolve().parents[1] / "src" / "researchkit" / "skills"
    installed = {name: SimpleNamespace(location=skills / name / "SKILL.md")
                 for name in ("mindmap-builder", "final-kpi-proxy-discovery")}
    ctx = SimpleNamespace(
        directory=tmp_path, worktree=tmp_path, session_id="ses_deep", abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
        app=SimpleNamespace(permissions=Broker(auto=True), skills={}, deep=deep.Deep(skills=installed)))
    assert set(mindmap._load_systems(ctx)) == {"observation", "architecture", "deepening"}
    assert method_exploration._system(ctx).strip()
    assert set(deep.skills(ctx.app)) == set(installed) and deep.skills(SimpleNamespace(skills={"a": 1})) == {"a": 1}


def test_the_installed_research_setup_gives_its_tools_and_guidance_their_skills(tmp_path, monkeypatch):
    # Through the entry's own configuration: the research skills are deep research's, and the tools and the
    # research turn that need them find them there.
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    from researchkit import skill_guidance
    from scripts.run_tui import research_config

    folder = tmp_path / "study"
    folder.mkdir()
    app = App(folder, store=Store(tmp_path / "session.db"), config=research_config({}, folder), auto_approve=True)
    try:
        assert {"mindmap-builder", "final-kpi-proxy-discovery", "hypothesis-gen"} <= set(deep.skills(app))
        assert "mindmap-builder" not in app.skills  # deep research's only
        history = [{"role": "assistant", "content": "", "tool_calls": [
                        {"id": "h1", "name": "research_history_check", "arguments": {}}]},
                   {"role": "tool", "tool_call_id": "h1", "name": "research_history_check", "content": "ranked"}]
        assert skill_guidance.missing(history, deep.skills(app)) == ["final-kpi-proxy-discovery"]
    finally:
        app.store.close()


def test_the_research_turn_runs_on_deep_researchs_tools(tmp_path, monkeypatch):
    # From the switch (2026-10-31) until 2026-11-01 the research turn looked for research_record only among the
    # folder's own tools, found none, and sent no host facts: reports were written without their rules.
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    from opencode.tools.types import external_source_names
    from researchkit.turn import ResearchTurn
    from scripts.run_tui import research_config

    folder = tmp_path / "study"
    folder.mkdir()
    app = App(folder, store=Store(tmp_path / "session.db"), config=research_config({}, folder), auto_approve=True)
    try:
        assert not app.extra_tools  # the research tools come from deep research only
        session = app.create_session()
        deep.set_on(app.store, session["id"], True)
        user = app.store.add_message(session["id"], "user", {"content": "Study it."})
        app.store.add_message(session["id"], "assistant", {"content": "", "tool_calls": [
            {"id": "e1", "name": "research_record",
             "arguments": {"kind": "sample_evolution", "template": {"stop_reason": "Three rounds ran."}}}]})
        app.store.add_message(session["id"], "tool", {"content": "{}", "tool_call_id": "e1", "name": "research_record"})
        turn = ResearchTurn(app, session["id"], user["id"])
        assert turn._agent() is not None
        context = turn.context()
        # The rounds have stopped, so the report's rules come with the host facts.
        assert "演化紀錄已寫明停止理由" in context and "## Style" in context
        # The literature tools bring in outside sources wherever they come from.
        assert {"paper_search", "paper_fetch"} <= external_source_names(deep.tools(app))
    finally:
        app.store.close()


def test_the_skills_and_guides_a_task_sees_are_copies_in_its_own_folder(tmp_path, monkeypatch):
    # An agent (2026-11-01) read the framework's code from the skill locations the prompt showed in its source.
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    from pathlib import Path

    import researchkit
    from opencode import skills as skill_list
    from scripts.run_tui import research_config

    from scripts.run_tui import install_deep_skills

    folder = tmp_path / "study"
    folder.mkdir()
    # A person's own folder gets nothing written and keeps the installation's folders ...
    assert research_config({}, folder)["deep"]["skills"][0].endswith("skills") and list(folder.iterdir()) == []
    # ... a recorded run installs the copies before it starts, and its configuration shows only them.
    install_deep_skills(folder)
    config = research_config({}, folder)
    installation = Path(researchkit.__file__).resolve().parents[1]
    copies = (folder / deep.COPIES).resolve()
    shown = [*config["deep"]["skills"], *config["deep"]["instructions"]]
    assert shown and all(Path(item).resolve().is_relative_to(copies) for item in shown)
    app = App(folder, store=Store(tmp_path / "session.db"), config=config, auto_approve=True)
    try:
        listed = skill_list.render(deep.skills(app))
        assert "<location>" in listed and str(installation) not in listed and str(copies) in listed
        assert all(skill.location.resolve().is_relative_to(copies) for skill in deep.skills(app).values())
    finally:
        app.store.close()


def test_installing_the_copies_again_changes_nothing_current_and_drops_what_is_gone(tmp_path):
    source = tmp_path / "skills"
    (source / "a").mkdir(parents=True)
    (source / "a" / "SKILL.md").write_text("one", encoding="utf-8")
    (source / "a" / "__pycache__").mkdir()
    (source / "a" / "__pycache__" / "x.pyc").write_bytes(b"\0")
    copy = deep.install_copies(tmp_path / "work", {"research": source})["research"]
    assert (copy / "a" / "SKILL.md").read_text(encoding="utf-8") == "one" and not (copy / "a" / "__pycache__").exists()
    before = (copy / "a" / "SKILL.md").stat().st_mtime_ns
    deep.install_copies(tmp_path / "work", {"research": source})
    assert (copy / "a" / "SKILL.md").stat().st_mtime_ns == before
    (source / "a" / "SKILL.md").unlink()
    (source / "b").mkdir()
    (source / "b" / "SKILL.md").write_text("two", encoding="utf-8")
    deep.install_copies(tmp_path / "work", {"research": source})
    assert not (copy / "a").exists() and (copy / "b" / "SKILL.md").read_text(encoding="utf-8") == "two"


def test_the_copies_are_in_the_meta_region(tmp_path):
    from opencode import integrity

    (tmp_path / "skills" / "a").mkdir(parents=True)
    (tmp_path / "skills" / "a" / "SKILL.md").write_text("guidance", encoding="utf-8")
    workspace = tmp_path / "work"
    deep.install_copies(workspace, {"research": tmp_path / "skills"})
    found = integrity.snapshot(tmp_path / "no-installation", workspace, [])
    assert "workspace/.opencode/deep/research/a/SKILL.md" in found
    assert integrity.refuses(integrity.protected([]), ".opencode/deep/research/a/SKILL.md")
