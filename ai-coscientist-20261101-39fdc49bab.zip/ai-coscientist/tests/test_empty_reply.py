"""An empty model reply is asked once more, and a second one stops the turn as an error; no model calls."""

import os
from pathlib import Path

import pytest

from opencode.app import App
from opencode.provider import Completion, ProviderError, ToolCall
from opencode.store import Store


class Scripted:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = 0
        self.provider = type("P", (), {"id": "fake", "context": 100000})()

    def resolve(self, model=None):
        return self.provider, "test"

    def complete(self, **kwargs):
        self.calls += 1
        return self.responses.pop(0)


EMPTY = Completion(text="", finish_reason="stop", usage={"completion_tokens": 330})


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    store = Store(tmp_path / "state.db")
    app = App(tmp_path, store=store, auto_approve=True, config={"model": "fake/test"})
    app.generate_titles = False
    yield app
    store.close()


def test_an_empty_reply_is_asked_once_more(app, tmp_path):
    # LIT v26 ended at its ninth call: 330 generated tokens arrived as neither text nor a tool call.
    (tmp_path / "note.txt").write_text("hello\n", encoding="utf-8")
    app.provider = Scripted([
        Completion(tool_calls=[ToolCall(id="c1", name="read", arguments={"filePath": str(tmp_path / "note.txt")})],
                   finish_reason="tool-calls"),
        EMPTY,
        Completion(text="the note says hello", finish_reason="stop"),
    ])
    session = app.create_session()
    result = app.prompt(session["id"], "read the note")
    assert result["text"] == "the note says hello" and app.provider.calls == 3


def test_a_second_empty_reply_stops_the_turn_as_an_error(app):
    app.provider = Scripted([EMPTY, EMPTY])
    session = app.create_session()
    with pytest.raises(ProviderError, match="empty reply twice"):
        app.prompt(session["id"], "start")
    assert app.provider.calls == 2
