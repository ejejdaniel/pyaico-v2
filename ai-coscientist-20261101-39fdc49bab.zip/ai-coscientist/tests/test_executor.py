"""Stage 1 of the integrated executor: one entry point for processes, an audit log, no behaviour change."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from opencode import executor
from opencode.app import App
from opencode.provider import Completion, ToolCall
from opencode.store import Store

PY = [sys.executable, "-c"]


def audit(directory):
    path = Path(directory) / executor.AUDIT_FILE
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()] if path.exists() else []


def test_unknown_purpose_is_rejected():
    with pytest.raises(ValueError, match="unknown launch purpose"):
        executor.Launch("anything")


def test_outside_a_tool_call_nothing_is_audited(tmp_path):
    result = executor.run([*PY, "print(42)"], executor.Launch("framework_helper"), capture_output=True, text=True,
                          cwd=tmp_path)
    assert result.stdout.strip() == "42" and result.returncode == 0
    assert audit(tmp_path) == []


def test_a_launch_inside_a_tool_call_is_attributed_and_audited(tmp_path):
    with executor.scope(tmp_path, "ses_1", "bash", "call_9"):
        process = executor.spawn([*PY, "import sys; sys.exit(3)"], executor.Launch("agent_command"), cwd=tmp_path)
        assert process.wait() == 3
        executor.run([*PY, "pass"], executor.Launch("agent_code", "calc properties"), cwd=tmp_path)
    start, finished = audit(tmp_path)
    assert start["event"] == "start" and start["purpose"] == "agent_command" and start["pid"] == process.pid
    assert (start["tool"], start["session"], start["call"]) == ("bash", "ses_1", "call_9")
    assert (start["backend"], start["sandboxed"], start["network"]) == ("local", False, "host")
    assert finished["event"] == "run" and finished["returncode"] == 0 and finished["note"] == "calc properties"
    assert "elapsed_s" in finished


def test_a_timeout_is_audited_and_still_raised(tmp_path):
    with executor.scope(tmp_path, "s", "calc", "c"):
        with pytest.raises(subprocess.TimeoutExpired):
            executor.run([*PY, "import time; time.sleep(30)"], executor.Launch("agent_code"), timeout=0.5)
    assert audit(tmp_path)[0]["outcome"] == "timeout"


def test_a_replaced_popen_is_used_and_audit_failure_never_stops_work(tmp_path):
    fake = SimpleNamespace(pid=7)
    blocked = tmp_path / "file-not-dir"
    blocked.write_text("x", encoding="utf-8")  # .opencode cannot be created under a file
    with patch.object(subprocess, "Popen", return_value=fake) as popen, executor.scope(blocked, "s", "bash", "c"):
        assert executor.spawn(["anything"], executor.Launch("agent_command"), cwd=tmp_path) is fake
    popen.assert_called_once_with(["anything"], cwd=tmp_path)


def test_a_real_turn_audits_the_shell_command_it_ran(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    app = App(project, store=Store(tmp_path / "session.db"), auto_approve=True, config={})
    app.generate_titles = False
    monkeypatch.setattr(app, "ensure_mcp", lambda: None)
    replies = iter([Completion(tool_calls=[ToolCall("call_echo", "bash", {"command": "echo audited"})],
                               finish_reason="tool-calls"),
                    Completion(text="done", finish_reason="stop"),
                    Completion(text="done", finish_reason="stop")])
    app.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=200000), "test"),
                                   complete=lambda **kwargs: next(replies))
    session = app.create_session()["id"]
    app.prompt(session, "run it")
    app.store.close()
    entries = [entry for entry in audit(project) if entry["purpose"] == "agent_command"]
    assert len(entries) == 1
    assert entries[0]["tool"] == "bash" and entries[0]["call"] == "call_echo" and entries[0]["session"] == session
    assert "echo audited" in entries[0]["args"]
