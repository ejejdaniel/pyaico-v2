"""The meta region of a research run (opencode/integrity.py): hashes, changes, and the file tools' edit rules."""

import pytest

from opencode import integrity
from opencode.app import App
from opencode.loop import ToolContext
from opencode.permission import PermissionDenied
from opencode.store import Store


def tree(root, files):
    for name, text in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


@pytest.fixture
def run(tmp_path):
    project, workspace = tmp_path / "project", tmp_path / "workspace"
    tree(project, {"src/opencode/loop.py": "loop", "src/researchkit/skills/sample/SKILL.md": "three rounds",
                   "config/runtime.json": "{}", "scripts/run_tui.py": "run"})
    tree(workspace, {".opencode/skills/sample/SKILL.md": "three rounds", ".opencode/tools/research.py": "stub",
                     ".opencode/opencode.json": "{}", "goal.md": "the task", "work/model.py": "x = 1"})
    return project, workspace, ["goal.md"]


def test_a_snapshot_covers_the_installation_the_installed_guidance_and_tools_and_the_sources(run):
    project, workspace, sources = run
    found = integrity.snapshot(project, workspace, sources)
    assert {"install/src/opencode/loop.py", "install/config/runtime.json", "install/scripts/run_tui.py",
            "workspace/.opencode/skills/sample/SKILL.md", "workspace/.opencode/tools/research.py",
            "workspace/.opencode/opencode.json", "workspace/goal.md", "environment/site-packages"} <= found.keys()
    assert "workspace/work/model.py" not in found  # the agent's own work is not part of it
    assert set(integrity.workspace_part(found)) == {key for key in found if key.startswith("workspace/")}


@pytest.mark.parametrize("change, expected", [
    # A guidance copy loosened, a tool added that would load into the framework's process on the next stage,
    # the task's source edited or deleted, the installed code patched.
    (lambda p, w: (w / ".opencode/skills/sample/SKILL.md").write_text("no limit", encoding="utf-8"),
     "changed: workspace/.opencode/skills/sample/SKILL.md"),
    (lambda p, w: (w / ".opencode/tools/scorer.py").write_text("TOOLS = []", encoding="utf-8"),
     "added: workspace/.opencode/tools/scorer.py"),
    (lambda p, w: (w / "goal.md").write_text("an easier task", encoding="utf-8"), "changed: workspace/goal.md"),
    (lambda p, w: (w / "goal.md").unlink(), "changed: workspace/goal.md"),
    (lambda p, w: (p / "src/opencode/loop.py").write_text("patched", encoding="utf-8"),
     "changed: install/src/opencode/loop.py"),
])
def test_every_change_to_the_meta_region_is_named(run, change, expected):
    project, workspace, sources = run
    before = integrity.snapshot(project, workspace, sources)
    change(project, workspace)
    assert integrity.changes(before, integrity.snapshot(project, workspace, sources)) == [expected]


def test_task_skills_kept_in_the_state_are_hashed_but_not_part_of_the_workspace(run, tmp_path):
    project, workspace, sources = run
    state = tmp_path / "state" / "task"
    tree(state, {"ses_a/review/lessons/SKILL.md": "Check the drawing.", "ses_a/round.json": '{"round": 2}'})
    before = integrity.snapshot(project, workspace, sources, {"task": state})
    assert {"task/ses_a/review/lessons/SKILL.md", "task/ses_a/round.json"} <= before.keys()
    assert not any(key.startswith("task/") for key in integrity.workspace_part(before))
    tree(state, {"ses_a/review/lessons/SKILL.md": "No round limit."})
    assert integrity.changes(before, integrity.snapshot(project, workspace, sources, {"task": state})) == \
        ["changed: task/ses_a/review/lessons/SKILL.md"]


def test_framework_ledgers_and_the_agents_own_work_may_change(run):
    project, workspace, sources = run
    before = integrity.snapshot(project, workspace, sources)
    tree(workspace, {".opencode/executions.jsonl": "{}", ".opencode/planning/s/plan.json": "{}",
                     ".opencode/history/s/index.md": "x", "work/model.py": "x = 2",
                     ".research/records/a/record.json": "{}"})
    tree(project, {"src/opencode/__pycache__/loop.cpython-312.pyc": "bytecode"})
    assert integrity.changes(before, integrity.snapshot(project, workspace, sources)) == []


@pytest.mark.parametrize("path, refused", [
    (".opencode/skills/sample/SKILL.md", True),
    (".opencode/tools/scorer.py", True),
    (".opencode/executions.jsonl", True),
    (".opencode/planning/ses_a/plan.json", True),  # to the file tools; the planning tool still writes it
    (".research/records/abc/record.json", True),
    ("goal.md", True),
    ("../../src/researchkit/leaderboard.py", True),  # relpath of a file outside the workspace
    ("C:/Users/someone/file.py", True),  # another drive: the absolute path
    ("work/model.py", False),
    (".research/mindmaps/m/mindmap.json", False),
    ("report/draft.md", False),
])
def test_the_file_tools_are_refused_the_meta_region_and_everything_outside_the_workspace(path, refused):
    assert integrity.refuses(integrity.protected(["goal.md"]), path) is refused


@pytest.fixture
def guarded(tmp_path, monkeypatch):
    """A workspace whose host protects the meta region, as the research runner does; its permissions allow all."""
    for key, name in {"OPENCODE_TEST_HOME": "home", "OPENCODE_CONFIG_DIR": "config", "XDG_CONFIG_HOME": "global",
                      "XDG_DATA_HOME": "data", "XDG_STATE_HOME": "state", "XDG_CACHE_HOME": "cache"}.items():
        monkeypatch.setenv(key, str(tmp_path / name))
    workspace = tmp_path / "workspace"
    tree(workspace, {"work/a.py": "x = 1\n", "goal.md": "target"})
    (workspace / ".git").mkdir()
    app = App(workspace, store=Store(tmp_path / "session.db"), auto_approve=True,
              config={"protected": integrity.protected(["goal.md"]), "permission": {"edit": {".opencode/*": "allow"}}})
    yield ToolContext(app, app.create_session()["id"], app.agents["build"], "m", "c", 0, workspace, workspace, set(), 1)
    app.store.close()


def test_the_agents_file_tools_are_refused_what_the_host_protects_whatever_its_permissions(guarded):
    from opencode.tools.extra import _apply_patch
    from opencode.tools.files import _edit, _write

    with pytest.raises(PermissionDenied, match=r"edit \(\.opencode/skills/x/SKILL\.md\)"):
        _write({"filePath": ".opencode/skills/x/SKILL.md", "content": "No round limit."}, guarded)
    with pytest.raises(PermissionDenied, match="goal.md"):
        _edit({"filePath": "goal.md", "oldString": "target", "newString": "anything"}, guarded)
    with pytest.raises(PermissionDenied, match=r"\.opencode/tools/a\.py"):  # a move into the meta region
        _apply_patch({"patchText": "*** Begin Patch\n*** Update File: work/a.py\n*** Move to: .opencode/tools/a.py\n"
                                   "@@\n-x = 1\n+x = 2\n*** End Patch"}, guarded)
    assert (guarded.directory / "work/a.py").read_text(encoding="utf-8") == "x = 1\n"
    assert not (guarded.directory / ".opencode/skills/x").exists()
    _write({"filePath": "work/b.py", "content": "y = 1"}, guarded)  # the rest of the workspace is the agent's


def test_the_frameworks_own_tools_still_save_records_and_ledgers(guarded):
    from opencode.tools.util import ensure_access
    from researchkit import method_exploration, mindmap

    root = guarded.directory
    ensure_access(guarded, root / ".research/records/*/record.json", "edit")
    ensure_access(guarded, root / ".opencode/planning/ses_a/plan.json", "edit")
    mindmap._preflight_outputs(guarded, [(root / ".research/mindmaps/m", ["mindmap.json", "mindmap.md"])])
    method_exploration._preflight_outputs(guarded, root / ".research/method-explorations/e")
