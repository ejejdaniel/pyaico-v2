"""Approved method-exploration boundaries, using synthetic offline fixtures only."""

from copy import deepcopy
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import jsonschema
import pytest

from opencode.permission import Broker, PermissionDenied, PermissionRejected, Rule
from opencode.provider import Completion, ProviderError, ToolCall
from researchkit import method_exploration, records


GUIDANCE = (Path(__file__).resolve().parents[1] / "src/researchkit/skills/"
            "final-kpi-proxy-discovery/references/method-exploration.md")
NAMES = ["input.json", "prompt.json", "response.json", "exploration.md"]
ANSWER = " \n# 已知與待確認\n\n離線測試文字，未作科學驗收。\n\n保留未知。\n \t"


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Method exploration tests must never use real network")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


def save(root, contents, dependencies=(), *, title="Synthetic offline source"):
    for name, data in contents.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data.encode("utf-8") if isinstance(data, str) else data)
    return records.publish(root, kind="notes", title=title, files=list(contents),
                           depends_on=list(dependencies))


def locator(record, name):
    return {"record_ref": record["record_path"], "source_path": name}


def completion(**changes):
    values = dict(text=ANSWER, tool_calls=[], usage={"prompt_tokens": 7, "completion_tokens": 9},
                  model="offline-model", finish_reason="stop", reasoning_content="PRIVATE_REASONING")
    return Completion(**{**values, **changes})


def response_fields(value):
    return {"text": value.text,
            "tool_calls": [{"id": call.id, "name": call.name, "arguments": call.arguments}
                           for call in value.tool_calls],
            "usage": value.usage, "model": value.model,
            "finish_reason": value.finish_reason, "reasoning_content": value.reasoning_content}


@pytest.fixture
def packet(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    ancestor = save(root, {"ancestor.txt": "UNSELECTED_ANCESTOR_PRIVATE"})
    commission = save(root, {"commission.md": "原委託全文：探索觀測限制；不要求定案。\n",
                             "revision.md": "適用修訂：缺少量測時保留未知。\n"})
    evidence = save(root, {"observation.txt": "Observation A; preserved verbatim.\nSecond line.\n",
                           "unselected.txt": "UNSELECTED_SIBLING_PRIVATE"}, [ancestor["record_path"]])
    args = {"scope": "  釐清局部未知，保留邊界。  ",
            "files": [locator(evidence, "observation.txt"), locator(commission, "commission.md"),
                      locator(commission, "revision.md")],
            "commission_files": [locator(commission, "revision.md"), locator(commission, "commission.md")]}
    store = SimpleNamespace(
        messages=Mock(side_effect=AssertionError("Parent history is not an exploration input")),
        todos=Mock(side_effect=AssertionError("Parent plan is not an exploration input")),
        source_receipts=Mock(side_effect=AssertionError("Parent receipts are not an exploration input")))
    ctx = SimpleNamespace(
        directory=root, worktree=root, session_id="parent-session", message_id="parent-message",
        call_id="exploration-call", abort=threading.Event(), read_files=set(),
        agent=SimpleNamespace(permission=[Rule("*", "*", "allow")], temperature=0,
                              prompt="PARENT_PROMPT_PRIVATE", options={}),
        app=SimpleNamespace(permissions=Broker(auto=True), store=store,
                            system="PARENT_SYSTEM_PRIVATE", instructions="PARENT_INSTRUCTIONS_PRIVATE",
                            history=[{"role": "user", "content": "PARENT_HISTORY_PRIVATE"}],
                            skills={"final-kpi-proxy-discovery": SimpleNamespace(
                                location=str(GUIDANCE.parent.parent / "SKILL.md")),
                                "unselected": SimpleNamespace(body="UNSELECTED_SKILL_PRIVATE")}))
    return SimpleNamespace(root=root, ctx=ctx, args=args, commission=commission,
                           evidence=evidence, ancestor=ancestor)


def runs(packet):
    return sorted((packet.root / ".research/method-explorations").glob("*"))


def test_exact_contract_and_persisted_bytes_with_readable_receipt(packet, monkeypatch):
    value = completion()
    before = deepcopy(packet.args)
    seen = []

    def generate(ctx, **kwargs):
        folder, = runs(packet)
        assert set(path.name for path in folder.iterdir()) == {"input.json", "prompt.json"}
        assert (folder / "input.json").read_bytes() == records.encoded(before)
        prompt = {"system": kwargs["system"], "messages": kwargs["messages"]}
        assert (folder / "prompt.json").read_bytes() == records.encoded(prompt)
        seen.append(kwargs)
        return value

    model = Mock(side_effect=generate)
    monkeypatch.setattr(method_exploration, "complete_once", model)
    result = method_exploration.execute(packet.args, packet.ctx)
    model.assert_called_once()
    assert packet.args == before
    assert result.title == "research_method_explore"
    assert result.metadata == {} and result.attachments == []
    receipt = json.loads(result.output)
    assert set(receipt) == {"record_path", "kind", "title", "files", "depends_on"}
    assert receipt["kind"] == "method_exploration" and receipt["title"] == before["scope"]
    assert receipt["depends_on"] == [packet.evidence["record_path"], packet.commission["record_path"]]
    assert [Path(item["source_path"]).name for item in receipt["files"]] == NAMES
    folder, = runs(packet)
    assert len(folder.name) == 32 and all(c in "0123456789abcdef" for c in folder.name)
    expected = [records.encoded(before), records.encoded({"system": seen[0]["system"],
                "messages": seen[0]["messages"]}), records.encoded(response_fields(value)), ANSWER.encode("utf-8")]
    manifest = records.read_record(packet.root, receipt["record_path"])
    for entry, stored, raw in zip(receipt["files"], manifest["files"], expected):
        assert Path(entry["snapshot"]).is_absolute()
        assert not Path(stored["snapshot"]).is_absolute()
        assert Path(entry["snapshot"]).read_bytes() == raw
        assert (packet.root / entry["source_path"]).read_bytes() == raw
        assert entry["sha256"] == records.digest(raw) and entry["bytes"] == len(raw)
    assert set(path.name for path in folder.iterdir()) == set(NAMES)


def test_model_receives_only_selected_frozen_sources_and_partitioned_commission(packet, monkeypatch):
    (packet.root / "observation.txt").write_text("CHANGED_WORKING_CONTENT", encoding="utf-8")
    (packet.root / "AGENTS.md").write_text("WORKSPACE_GUIDANCE_PRIVATE", encoding="utf-8")
    model = Mock(return_value=completion())
    monkeypatch.setattr(method_exploration, "complete_once", model)
    method_exploration.execute(packet.args, packet.ctx)
    call = model.call_args
    assert call.args == (packet.ctx,)
    assert set(call.kwargs) == {"system", "messages", "frozen"}
    assert call.kwargs["system"] == GUIDANCE.read_text(encoding="utf-8")
    messages = call.kwargs["messages"]
    assert len(messages) == 1 and messages[0]["role"] == "user"
    content = messages[0]["content"]
    for text in ("原委託全文：探索觀測限制；不要求定案。", "適用修訂：缺少量測時保留未知。",
                 "Observation A; preserved verbatim."):
        assert content.count(text) == 1
    for entry in packet.args["files"]:
        assert entry["record_ref"] in content and entry["source_path"] in content
        saved = records.read_record(packet.root, entry["record_ref"])
        selected, = [item for item in saved["files"] if item["source_path"] == entry["source_path"]]
        raw = (packet.root / Path(entry["record_ref"]).parent / selected["snapshot"]).read_bytes()
        assert json.dumps(raw.decode("utf-8"), ensure_ascii=False) in content
        for field in ("sha256", "bytes"):
            assert json.dumps(selected[field], ensure_ascii=False) in content
    assert content.index("Caller-selected original commission") < content.index("適用修訂")
    assert content.index("適用修訂") < content.index("原委託全文") < content.index("Other explicitly selected evidence")
    assert content.index("Other explicitly selected evidence") < content.index("Observation A;")
    for secret in ("UNSELECTED_ANCESTOR_PRIVATE", "UNSELECTED_SIBLING_PRIVATE", "CHANGED_WORKING_CONTENT",
                   "PARENT_PROMPT_PRIVATE", "PARENT_SYSTEM_PRIVATE", "PARENT_INSTRUCTIONS_PRIVATE",
                   "PARENT_HISTORY_PRIVATE", "UNSELECTED_SKILL_PRIVATE", "WORKSPACE_GUIDANCE_PRIVATE"):
        assert secret not in json.dumps(call.kwargs, ensure_ascii=False)
    # The partition is explicit in the prompt; it is not inferred from titles.
    assert "commission" in content.lower() or "委託" in content
    assert "evidence" in content.lower() or "其他來源" in content or "其他證據" in content
    for name in ("messages", "todos", "source_receipts"):
        getattr(packet.ctx.app.store, name).assert_not_called()


@pytest.mark.parametrize("change", [
    lambda a: a.update(extra=True), lambda a: a.update(scope=None), lambda a: a.update(scope=" \t"),
    lambda a: a.update(scope="字" * 4097), lambda a: a.update(files=[]),
    lambda a: a.update(commission_files=[]), lambda a: a.update(files=None),
    lambda a: a["files"].append(deepcopy(a["files"][0])),
    lambda a: a["commission_files"].append(deepcopy(a["commission_files"][0])),
    lambda a: a["files"][0].update(extra="no"),
    lambda a: a["files"][0].update(record_ref=".research/records/latest/record.json"),
    lambda a: a["files"][0].update(record_ref=".research/records/" + "A" * 64 + "/record.json"),
    lambda a: a["files"][0].update(source_path=" "),
    lambda a: a["commission_files"][0].update(source_path="not-selected.md"),
])
def test_invalid_arguments_never_generate(packet, monkeypatch, change):
    args = deepcopy(packet.args)
    change(args)
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises((ValueError, jsonschema.ValidationError)):
        method_exploration.execute(args, packet.ctx)
    model.assert_not_called()
    assert runs(packet) == []


def test_schema_exposes_only_approved_three_fields(packet):
    spec = method_exploration.INPUT_SCHEMA
    assert set(spec["properties"]) == set(spec["required"]) == {"scope", "files", "commission_files"}
    assert spec["additionalProperties"] is False
    jsonschema.validate(packet.args, spec)
    for key in ("files", "commission_files"):
        assert spec["properties"][key]["minItems"] == 1
        assert spec["properties"][key]["maxItems"] == 32
    assert spec["properties"]["scope"]["maxLength"] == 4096


@pytest.mark.parametrize("failure", ["missing-selection", "changed-manifest", "changed-snapshot", "dependency"])
def test_frozen_integrity_and_dependency_preflight_prevent_generation(packet, monkeypatch, failure):
    if failure == "missing-selection":
        packet.args["files"][0]["source_path"] = "observation"
    elif failure == "changed-manifest":
        (packet.root / packet.evidence["record_path"]).write_bytes(b"changed")
    else:
        record = packet.ancestor if failure == "dependency" else packet.evidence
        item = record["files"][0]
        path = packet.root / Path(record["record_path"]).parent / item["snapshot"]
        path.write_bytes(b"changed")
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ValueError):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()


@pytest.mark.parametrize("permission,pattern", [
    ("research_method_explore", "*"), ("read", "*.research/records/*"),
    ("read", "*.research/method-explorations/*"), ("edit", "*.research/method-explorations/*"),
    ("edit", "*.research/records*"), ("read", "*method-exploration.md"),
])
def test_permission_failure_is_zero_generation(packet, monkeypatch, permission, pattern):
    packet.ctx.agent.permission.append(Rule(permission, pattern, "deny"))
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(PermissionDenied):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_broker_receives_unique_ordered_record_patterns_and_parent_abort(packet, monkeypatch):
    ask = Mock(wraps=packet.ctx.app.permissions.ask)
    monkeypatch.setattr(packet.ctx.app.permissions, "ask", ask)
    monkeypatch.setattr(method_exploration, "complete_once", Mock(return_value=completion()))
    method_exploration.execute(packet.args, packet.ctx)
    call, = [call for call in ask.call_args_list if call.kwargs["permission"] == "research_method_explore"]
    assert call.kwargs["patterns"] == [packet.evidence["record_path"], packet.commission["record_path"]]
    assert call.kwargs["always"] == ["*"] and call.kwargs["metadata"] == {}
    assert call.kwargs["abort_event"] is packet.ctx.abort


def test_permission_ask_rejection_is_zero_generation(packet, monkeypatch):
    packet.ctx.agent.permission.append(Rule("research_method_explore", "*", "ask"))
    packet.ctx.app.permissions = Broker(callback=lambda pending: "reject")
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(PermissionRejected):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_full_utf8_capacity_is_checked_before_generation_without_truncating(packet, monkeypatch):
    large = save(packet.root, {"large.txt": "資料" * 45000})
    packet.args["files"].append(locator(large, "large.txt"))
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ValueError):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()


def test_capacity_includes_both_system_and_user_message(packet, monkeypatch):
    skill = packet.root / "local-skill"
    guide = skill / "references/method-exploration.md"
    guide.parent.mkdir(parents=True)
    # Each input part fits alone; their complete combined UTF-8 bytes do not.
    guide.write_bytes(b"g" * (262144 - 32))
    packet.ctx.app.skills["final-kpi-proxy-discovery"].location = str(skill / "SKILL.md")
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ValueError):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert runs(packet) == []


@pytest.mark.parametrize("changes", [
    {"finish_reason": "length"}, {"finish_reason": "unknown"}, {"finish_reason": None},
    {"text": ""}, {"text": " \n\t"}, {"text": "", "reasoning_content": "ONLY_REASONING"},
    {"tool_calls": [ToolCall("unexpected", "read", {"filePath": "outside"})]},
])
def test_nonfinal_completion_is_preserved_but_never_published_or_retried(packet, monkeypatch, changes):
    value = completion(**changes)
    model = Mock(return_value=value)
    publish = Mock(side_effect=AssertionError("Incomplete response must not publish"))
    monkeypatch.setattr(method_exploration, "complete_once", model)
    monkeypatch.setattr(records, "publish", publish)
    with pytest.raises(ValueError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_called_once()
    publish.assert_not_called()
    folder, = runs(packet)
    assert str(folder) in str(caught.value)
    assert set(path.name for path in folder.iterdir()) == set(NAMES[:3])
    assert (folder / "response.json").read_bytes() == records.encoded(response_fields(value))


@pytest.mark.parametrize("cancelled", [False, True])
def test_transport_failure_or_cancellation_preserves_partial_and_original_error(packet, monkeypatch, cancelled):
    value = completion(text="incomplete bytes\n", finish_reason=None)
    error = ProviderError("Model request aborted" if cancelled else "stream interrupted", value)

    def generate(*args, **kwargs):
        if cancelled:
            packet.ctx.abort.set()
        raise error

    model = Mock(side_effect=generate)
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ProviderError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    assert caught.value is error
    model.assert_called_once()
    folder, = runs(packet)
    assert str(folder) in str(error)
    assert (folder / "response.json").read_bytes() == records.encoded(response_fields(value))
    assert not (folder / "exploration.md").exists()
    assert len(records.inventory(packet.root)) == 3


def test_input_write_failure_prevents_model(packet, monkeypatch):
    original = Path.open

    def fail(path, mode="r", *args, **kwargs):
        if path.name == "prompt.json" and any(flag in mode for flag in ("w", "x", "+")):
            raise OSError("offline injected disk failure")
        return original(path, mode, *args, **kwargs)

    model = Mock()
    monkeypatch.setattr(Path, "open", fail)
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(OSError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()
    folder, = runs(packet)
    assert str(folder) in str(caught.value)
    assert (folder / "input.json").exists()


def test_publish_then_readback_failure_keeps_committed_record_and_all_files(packet, monkeypatch):
    original = records.publish
    committed = []

    def commit_then_fail(*args, **kwargs):
        result = original(*args, **kwargs)
        committed.append(result)
        raise OSError("offline injected post-commit readback failure")

    model = Mock(return_value=completion())
    monkeypatch.setattr(method_exploration, "complete_once", model)
    monkeypatch.setattr(records, "publish", commit_then_fail)
    with pytest.raises(OSError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_called_once()
    folder, = runs(packet)
    assert str(folder) in str(caught.value)
    record, = committed
    assert record["record_path"] in str(caught.value)
    assert (packet.root / record["record_path"]).exists()
    assert set(path.name for path in folder.iterdir()) == set(NAMES)
    assert records.read_record(packet.root, record["record_path"])["kind"] == "method_exploration"


def test_repeated_explicit_invocations_create_new_directories_without_overwrite(packet, monkeypatch):
    model = Mock(return_value=completion())
    monkeypatch.setattr(method_exploration, "complete_once", model)
    first = json.loads(method_exploration.execute(packet.args, packet.ctx).output)
    second = json.loads(method_exploration.execute(packet.args, packet.ctx).output)
    assert model.call_count == 2
    assert len(runs(packet)) == 2
    assert first["record_path"] != second["record_path"]


@pytest.mark.parametrize("changes", [
    {"text": None}, {"usage": None}, {"usage": {1: "coerced key"}}, {"usage": {"tokens": float("nan")}},
    {"model": None}, {"finish_reason": 1}, {"reasoning_content": []}, {"tool_calls": {}},
    {"tool_calls": [ToolCall(1, "read", {})]}, {"tool_calls": [ToolCall("id", "read", "{}")]},
])
def test_invalid_completion_types_are_not_coerced_or_published(packet, monkeypatch, changes):
    model = Mock(return_value=completion(**changes))
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ValueError):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_called_once()
    folder, = runs(packet)
    assert not (folder / "response.json").exists()
    assert not (folder / "exploration.md").exists()
    assert len(records.inventory(packet.root)) == 3


def test_partial_save_failure_reports_both_causes_and_does_not_retry(packet, monkeypatch):
    error = ProviderError("offline transport interrupted", completion(text="partial", finish_reason=None))
    model = Mock(side_effect=error)
    original = Path.open

    def fail(path, mode="r", *args, **kwargs):
        if path.name == "response.json" and any(flag in mode for flag in ("w", "x", "+")):
            raise OSError("offline response disk failure")
        return original(path, mode, *args, **kwargs)

    monkeypatch.setattr(Path, "open", fail)
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises(ProviderError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    assert caught.value is error
    assert "offline transport interrupted" in str(error) and "offline response disk failure" in str(error)
    model.assert_called_once()
    folder, = runs(packet)
    assert set(path.name for path in folder.iterdir()) == {"input.json", "prompt.json"}


def test_postpublication_exact_readback_failure_retains_known_record(packet, monkeypatch):
    original_publish = records.publish
    original_read = records.read_record
    committed = []

    def publish(*args, **kwargs):
        result = original_publish(*args, **kwargs)
        committed.append(result)
        return result

    def read(root, ref, **kwargs):
        if committed and ref == committed[0]["record_path"]:
            raise OSError("offline formal readback failure")
        return original_read(root, ref, **kwargs)

    model = Mock(return_value=completion())
    monkeypatch.setattr(method_exploration, "complete_once", model)
    monkeypatch.setattr(records, "publish", publish)
    monkeypatch.setattr(records, "read_record", read)
    with pytest.raises(OSError) as caught:
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_called_once()
    record, = committed
    folder, = runs(packet)
    assert record["record_path"] in str(caught.value) and str(folder) in str(caught.value)
    assert original_read(packet.root, record["record_path"])["kind"] == "method_exploration"
    assert set(path.name for path in folder.iterdir()) == set(NAMES)


def test_parent_already_cancelled_generates_nothing(packet, monkeypatch):
    packet.ctx.abort.set()
    model = Mock()
    monkeypatch.setattr(method_exploration, "complete_once", model)
    with pytest.raises((ProviderError, PermissionRejected)):
        method_exploration.execute(packet.args, packet.ctx)
    model.assert_not_called()
    assert runs(packet) == []
