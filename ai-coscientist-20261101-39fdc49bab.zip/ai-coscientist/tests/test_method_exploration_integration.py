"""Actual provider encoding and native outer receipt/read consumption; offline only."""

import asyncio
from contextlib import closing
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest

from opencode.app import App
from opencode.provider import Client, Completion, ProviderError, ToolCall
from opencode.store import Store
from researchkit import method_exploration, records
from scripts.llm_configuration import validate_llm_fragment
from scripts.llm_wire import WireRecorder
from scripts.setup_research_workspace import install
from test_method_exploration import ANSWER, locator, offline, packet, runs, save
from tests.prompt_view import plain_messages


ENDPOINT = "https://offline.invalid/v1/chat/completions"


def config():
    value = {"model": "offline/deepseek-v4-flash", "enabled_providers": ["offline"],
             "agent": {"build": {"temperature": 0}},
             "provider": {"offline": {"api": "openai", "options": {
                 "baseURL": "https://offline.invalid/v1", "apiKey": "offline-key"},
                 "models": {"deepseek-v4-flash": {"temperature": True,
                     "limit": {"output": 32000}, "options": {"reasoningEffort": "none"}}}}}}
    validate_llm_fragment(value)
    return value


def sse(delta=None, *, reason=None, usage=None):
    event = {"choices": [{"delta": delta or {}, "finish_reason": reason}]}
    if usage is not None:
        event["usage"] = usage
    return ("data: " + json.dumps(event, ensure_ascii=False) + "\n\n").encode("utf-8")


def response(*, text=ANSWER, reason="stop", calls=None, reasoning="PRIVATE_REASONING"):
    delta = {"content": text, "reasoning_content": reasoning}
    if calls is not None:
        delta["tool_calls"] = calls
    return httpx.Response(200, headers={"content-type": "text/event-stream"}, content=(
        sse(delta, reason=reason, usage={"prompt_tokens": 19, "completion_tokens": 23})
        + b"data: [DONE]\n\n"))


def transport(monkeypatch, receive):
    # Both paths must stay offline even if the provider changes its transport.
    mock = httpx.MockTransport(receive)
    monkeypatch.setattr(httpx.Client, "_transport_for_url", lambda self, url: mock)
    monkeypatch.setattr(httpx.AsyncClient, "_transport_for_url", lambda self, url: mock)


def configure(packet):
    packet.ctx.app.provider = Client(SimpleNamespace(get=lambda key: None), config())
    packet.ctx.app.provider.complete = Mock(side_effect=AssertionError("No retrying model entry point"))
    packet.ctx.app.store.get_session = Mock(return_value={"model": "offline/deepseek-v4-flash"})


@pytest.mark.parametrize("mode", ["stop", "length", "length-reasoning-only", "unknown", "empty", "reasoning-only", "tool-calls",
                                  "http-error", "stream-failure", "cancel"])
def test_actual_http_is_single_post_with_central_settings_and_preserves_failures(packet, monkeypatch, mode):
    configure(packet)
    sent = []
    partial_bytes = sse({"content": "incomplete observation", "reasoning_content": "PRIVATE_REASONING"})

    class Interrupted(httpx.AsyncByteStream):
        closed = False

        async def __aiter__(self):
            yield partial_bytes
            if mode == "cancel":
                packet.ctx.abort.set()
                await asyncio.wait_for(asyncio.Event().wait(), timeout=2)
            else:
                raise httpx.ReadError("offline stream interruption")

        async def aclose(self):
            self.closed = True

    source = Interrupted()

    def receive(request):
        assert str(request.url) == ENDPOINT
        assert request.method == "POST"
        sent.append(request)
        if mode == "http-error":
            return httpx.Response(503, text="offline unavailable")
        if mode in {"cancel", "stream-failure"}:
            return httpx.Response(200, headers={"content-type": "text/event-stream"}, stream=source)
        if mode == "tool-calls":
            return response(calls=[{"index": 0, "id": "unexpected", "function": {
                "name": "read", "arguments": "{}"}}])
        return response(text="" if mode in {"empty", "reasoning-only", "length-reasoning-only"} else ANSWER,
                        reason={"length": "length", "length-reasoning-only": "length",
                                "unknown": "future-reason"}.get(mode, "stop"),
                        reasoning=None if mode == "empty" else "PRIVATE_REASONING")

    transport(monkeypatch, receive)
    wire = packet.root.parent / "wire"
    with WireRecorder(wire, endpoints=[ENDPOINT]) as recorder:
        if mode == "stop":
            result = method_exploration.execute(packet.args, packet.ctx)
            assert json.loads(result.output)["kind"] == "method_exploration"
        else:
            with pytest.raises((ProviderError, ValueError)):
                method_exploration.execute(packet.args, packet.ctx)
        assert recorder.count == 1
    assert len(sent) == 1
    body = json.loads(sent[0].content)
    assert (body["reasoning_effort"], body["temperature"], body["max_tokens"]) == ("none", 0, 32000)
    assert body["model"] == "deepseek-v4-flash"
    assert body["stream"] is True and body["stream_options"] == {"include_usage": True}
    assert "tools" not in body and "tool_choice" not in body
    assert [item["role"] for item in body["messages"]] == ["system", "user"]
    assert "PARENT_HISTORY_PRIVATE" not in json.dumps(body, ensure_ascii=False)
    assert sent[0].extensions["timeout"] == {"connect": 30.0, "read": 600.0, "write": 600.0, "pool": 600.0}
    folder, = runs(packet)
    prompt = json.loads((folder / "prompt.json").read_bytes())
    assert body["messages"] == [{"role": "system", "content": prompt["system"]}, *prompt["messages"]]
    captured, = wire.glob("wire-*")
    assert (captured / "request.body.json").read_bytes() == sent[0].content
    assert (folder / "exploration.md").exists() is (mode == "stop")
    assert len(records.inventory(packet.root)) == (4 if mode == "stop" else 3)
    if mode != "http-error":
        value = json.loads((folder / "response.json").read_bytes())
        assert set(value) == {"text", "tool_calls", "usage", "model", "finish_reason", "reasoning_content"}
        assert value["reasoning_content"] == (None if mode == "empty" else "PRIVATE_REASONING")
        if mode in {"cancel", "stream-failure"}:
            assert source.closed
            assert value["text"] == "incomplete observation" and value["finish_reason"] is None
            assert (captured / "response.raw.bin").read_bytes() == partial_bytes
    else:
        # Existing streaming provider attaches its empty snapshot on HTTP failure.
        # Preserve that exact available partial, without inventing usage or text.
        assert json.loads((folder / "response.json").read_bytes()) == {
            "text": "", "tool_calls": [], "usage": {}, "model": "deepseek-v4-flash",
            "finish_reason": None, "reasoning_content": None,
        }
    packet.ctx.app.provider.complete.assert_not_called()
    assert not any(t.name in {"opencode-provider-request", "researchkit-review-deadline"}
                   for t in threading.enumerate())


def test_native_outer_receives_exact_receipt_then_reads_frozen_exploration(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
                "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()
    install(root)
    saved = save(root, {"commission.md": "Synthetic offline commission: preserve an unresolved observation.\n",
                       "observation.txt": "Synthetic offline evidence; no scientific conclusion supplied.\n"})
    args = {"scope": "Explore the bounded unresolved observation from explicit offline sources.",
            "files": [locator(saved, "commission.md"), locator(saved, "observation.txt")],
            "commission_files": [locator(saved, "commission.md")]}
    sent = []

    def receive(request):
        assert str(request.url) == ENDPOINT and request.method == "POST"
        sent.append(request)
        return response()

    transport(monkeypatch, receive)
    with closing(Store(tmp_path / "session.db")) as store:
        app = App(root, store=store, auto_approve=True, config=config())
        app.generate_titles = False
        session = app.create_session()["id"]
        outer_requests = []
        selected = []

        def outer(**kwargs):
            outer_requests.append(kwargs)
            if len(outer_requests) == 1:
                assert "research_method_explore" in {tool["name"] for tool in kwargs["tools"]}
                return Completion(tool_calls=[ToolCall("explore-call", "research_method_explore", args)],
                                  finish_reason="tool-calls")
            receipt, = [item for item in plain_messages(kwargs["messages"])
                        if item.get("role") == "tool" and item.get("tool_call_id") == "explore-call"]
            stored, = [item for item in store.messages(session) if item.get("name") == "research_method_explore"]
            assert not stored.get("metadata", {}).get("error"), stored["content"]
            assert receipt["content"] == stored["content"]
            record = json.loads(receipt["content"])
            if len(outer_requests) == 2:
                frozen, = [item["snapshot"] for item in record["files"]
                           if Path(item["source_path"]).name == "exploration.md"]
                assert Path(frozen).is_absolute()
                assert Path(frozen).read_bytes() == ANSWER.encode("utf-8")
                selected.append(frozen)
                return Completion(tool_calls=[ToolCall("read-exploration", "read", {"filePath": frozen})],
                                  finish_reason="tool-calls")
            assert len(outer_requests) == 3
            consumed, = [item for item in kwargs["messages"]
                         if item.get("role") == "tool" and item.get("tool_call_id") == "read-exploration"]
            assert selected[0] in consumed["content"]
            assert "離線測試文字，未作科學驗收。" in consumed["content"]
            assert "保留未知。" in consumed["content"]
            assert "PRIVATE_REASONING" not in json.dumps(kwargs["messages"])
            return Completion(text="已讀到『保留未知』；此離線回放只核對交接。", finish_reason="stop")

        app.provider.complete = Mock(side_effect=outer)
        with WireRecorder(tmp_path / "wire", endpoints=[ENDPOINT]) as recorder:
            app.prompt(session, "PARENT_PRIVATE_MESSAGE: perform the explicitly selected offline exercise.")
            assert recorder.count == 1
        assert len(sent) == 1 and len(outer_requests) == 3
        assert "PARENT_PRIVATE_MESSAGE" not in sent[0].content.decode("utf-8")
        assert len(records.inventory(root)) == 2
        final = store.messages(session)[-1]
        assert "已讀到『保留未知』" in final["content"]
        assert not (root / ".planning").exists()
