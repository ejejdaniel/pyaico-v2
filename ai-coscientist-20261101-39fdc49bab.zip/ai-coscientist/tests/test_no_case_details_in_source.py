"""The framework's source carries no case's details: an agent that reads it must not find a case's answers
(AGENTS.md: no known answers in a formal question). The details once kept in comments are in
docs/source_comment_lit_details_20261101_zh-TW.md."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# The LIT case's KPI names, component labels and measured numbers.
CASE_DETAILS = re.compile(r"\bEOP\b|\bLCDU\b|\bC13IB2\b|\bC2-?AA2\b|\bR1[27]\b|\b47\.9\b|\b53\.7\b|\b48\.9\b|40 ± 1")


def test_the_framework_source_carries_no_case_details():
    found = []
    for path in sorted((ROOT / "src").rglob("*")):
        if path.suffix in (".py", ".md", ".json", ".txt") and "__pycache__" not in path.parts:
            for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if CASE_DETAILS.search(line):
                    found.append(f"{path.relative_to(ROOT)}:{number}: {line.strip()[:100]}")
    assert not found, "\n".join(found)
