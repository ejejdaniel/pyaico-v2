"""The portable package: pinned requirements stay complete and readable, and keys are not shipped."""

import re
import sys
from pathlib import Path

import tomllib

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import package  # noqa: E402


def pinned():
    return {re.sub(r"[-_.]+", "-", m[1]).lower(): m[2] for m in re.finditer(
        r"^([A-Za-z0-9_.-]+)==([^\s;]+)", (ROOT / "requirements.txt").read_text(encoding="ascii"), re.M)}


def test_every_declared_dependency_is_pinned_for_the_package():
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    declared = [*project["dependencies"]] + [text for extra in ("science", "inference", "simulation")
                                              for text in project["optional-dependencies"][extra]]
    names = {re.sub(r"[-_.]+", "-", re.match(r"[A-Za-z0-9_.-]+", text)[0]).lower() for text in declared}
    missing = names - set(pinned())
    assert not missing, f"run python scripts/package.py --write-requirements: {sorted(missing)}"


def test_files_read_in_the_system_encoding_are_ascii():
    for name in ("requirements.txt", "requirements-dev.txt", "install.cmd", "install.sh", "co-scientist.cmd",
                 "co-scientist.sh"):
        assert (ROOT / name).read_bytes().isascii(), name
    for name in ("install.sh", "co-scientist.sh"):
        assert b"\r\n" not in (ROOT / name).read_bytes(), f"{name} needs LF line endings for bash"


def test_secret_patterns_catch_keys_but_not_placeholders():
    def flagged(text):
        return any(pattern.search(text) for pattern, _ in package.SECRETS)
    # Assembled here, so this file itself passes the scan when tests are packaged.
    assert flagged('"apiKey": "' + "a8f3k29dk3l0" + "qpz8x7c6" + '"')
    assert flagged("token sk-" + "A1b2C3d4" * 4)
    assert not flagged('"apiKey": "{env:LOCAL_OPENAI_API_KEY}"')
    assert not flagged('"apiKey": "local"')
    assert not flagged('"apiKey": "offline-not-a-real-api-key"')
