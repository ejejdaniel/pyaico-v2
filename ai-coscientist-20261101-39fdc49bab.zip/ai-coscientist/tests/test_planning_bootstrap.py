"""Offline first-plan entry checks; the entry grants no source or planning authority."""

import json
from types import SimpleNamespace

import pytest

from opencode.agent import Agent
from opencode.permission import Broker, Rule
from opencode.store import Store
from opencode.tools.files import _read
from opencode.tools.util import relative_path
from planningkit.storage import PlanningStore
from planningkit.turn import PlanningTurn


@pytest.fixture(autouse=True)
def no_live_transport(monkeypatch):
    import httpx

    def forbidden(*args, **kwargs):
        raise AssertionError("Planning bootstrap tests must never contact a live service")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


@pytest.fixture
def case(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    store = Store(tmp_path / "session.db")
    sid = store.create_session(directory=str(root), agent="build", model="offline/offline")["id"]
    human = store.add_message(sid, "user", {"content": "Inspect only the explicitly provided source."})
    agent = Agent("build", permission=[Rule("*", "*", "allow")])
    app = SimpleNamespace(store=store, directory=root, worktree=root,
                          agents={"build": agent}, default_agent="build", permissions=Broker(auto=True))
    ctx = SimpleNamespace(app=app, directory=root, worktree=root, agent=agent, session_id=sid)
    yield ctx, human
    store.close()


def entry(index):
    return ("目前尚無保存的規劃；規劃為選用。\n"
            f"本會話的對話歷史索引位置：{json.dumps(index.as_posix(), ensure_ascii=False)}\n"
            "真正人類訊息的 ID 已標在 <human id> 標頭；首次建立規劃時直接引用這些 ID，需要核對原文時再讀索引；"
            "此處只提供位置，不表示已讀取來源。")


def turn(ctx, human):
    return PlanningTurn(ctx.app, ctx.session_id, human["id"])


def test_no_plan_entry_only_locates_index_and_does_not_read_or_create_sources(case, monkeypatch):
    ctx, human = case
    index = ctx.app.store._receipt_index_path(ctx.session_id, "history", "conversation")

    def forbidden(*args, **kwargs):
        pytest.fail("The first-plan entry must neither read messages nor export history")

    monkeypatch.setattr(ctx.app.store, "messages", forbidden)
    monkeypatch.setattr(ctx.app.store, "export_work_history", forbidden)
    projected = turn(ctx, human).context()
    assert projected == entry(index) and len(projected.splitlines()) == 3
    assert human["id"] not in projected and human["content"] not in projected
    assert not index.exists() and not (ctx.directory / ".opencode/planning").exists()
    assert PlanningStore(ctx).read({"view": "full"}) == {
        "revision_ref": None, "snapshot": None, "history": [], "summary": "", "notices": []}
    with pytest.raises(FileNotFoundError):
        _read({"filePath": index.as_posix()}, ctx)
    assert not index.exists()


def test_full_index_path_is_json_escaped_without_summary_truncation(case, monkeypatch):
    ctx, human = case
    # Exercise presentation of a host-provided path without creating a file.
    index = ctx.directory.joinpath(*(["x" * 200] * 80), '索引 "\n\r\t', "index.md")
    calls = []

    def host_index(owner, area, part):
        calls.append((owner, area, part))
        return index

    monkeypatch.setattr(ctx.app.store, "_receipt_index_path", host_index)
    projected = turn(ctx, human).context()
    lines = projected.splitlines()
    assert calls == [(ctx.session_id, "history", "conversation")]
    assert len(projected.encode("utf-8")) > 16000 and len(lines) == 3
    assert json.loads(lines[1].split("：", 1)[1]) == index.as_posix()
    assert projected == entry(index)


@pytest.mark.parametrize("action", ["ask", "deny"])
@pytest.mark.parametrize("boundary", ["planning_read", "head", "index"])
@pytest.mark.parametrize("source", ["agent", "session"])
def test_bootstrap_requires_effective_allow_without_using_broker_cache(case, action, boundary, source):
    ctx, human = case
    index = ctx.app.store._receipt_index_path(ctx.session_id, "history", "conversation")
    permission, pattern = {
        "planning_read": ("planning_read", "*"),
        "head": ("read", f".opencode/planning/{ctx.session_id}/head.json"),
        "index": ("read", relative_path(ctx, index)),
    }[boundary]
    rule = Rule(permission, pattern, action)
    if source == "agent":
        ctx.agent.permission.append(rule)
    else:
        ctx.app.store.update_session(ctx.session_id, permission=[vars(rule)])
    ctx.app.permissions = Broker(callback=lambda _: pytest.fail("Automatic entry must not ask"))
    ctx.app.permissions._approved.append(Rule(permission, pattern, "allow"))
    assert turn(ctx, human).context() == ""
    assert not index.exists() and not (ctx.directory / ".opencode/planning").exists()


@pytest.mark.parametrize("action", ["allow", "ask", "deny"])
def test_index_outside_current_directory_and_worktree_needs_external_permission(case, tmp_path, action):
    ctx, human = case
    external = tmp_path / "session-workspace"
    external.mkdir()
    ctx.app.store.update_session(ctx.session_id, directory=str(external))
    index = ctx.app.store._receipt_index_path(ctx.session_id, "history", "conversation")
    ctx.agent.permission.append(Rule("external_directory", index.parent.as_posix() + "/*", action))
    ctx.app.permissions = Broker(callback=lambda _: pytest.fail("Automatic entry must not ask"))
    ctx.app.permissions._approved.append(Rule("external_directory", "*", "allow"))
    assert turn(ctx, human).context() == (entry(index) if action == "allow" else "")
    assert not index.exists()


def test_session_allow_and_agent_switch_refresh_current_effective_rules(case):
    ctx, human = case
    ctx.agent.permission.append(Rule("planning_read", "*", "deny"))
    original = list(ctx.agent.permission)
    active = turn(ctx, human)
    assert active.context() == ""
    ctx.app.store.update_session(ctx.session_id, permission=[{
        "permission": "planning_read", "pattern": "*", "action": "allow"}])
    assert active.context() and ctx.agent.permission == original
    ctx.app.agents["restricted"] = Agent("restricted", permission=[Rule("*", "*", "allow"),
        Rule("read", ".opencode/history/*", "deny")])
    ctx.app.store.update_session(ctx.session_id, agent="restricted")
    assert active.context() == ""


def test_corrupt_head_is_not_treated_as_first_use(case):
    ctx, human = case
    head = ctx.directory / f".opencode/planning/{ctx.session_id}/head.json"
    head.parent.mkdir(parents=True)
    head.write_bytes(b'{"broken":')
    with pytest.raises(ValueError):
        turn(ctx, human).context()


def test_child_entry_uses_only_own_owner_even_when_parent_history_exists(case):
    ctx, human = case
    parent_index = ctx.app.store.export_work_history(ctx.session_id)
    child = ctx.app.store.create_session(directory=str(ctx.directory), parent_id=ctx.session_id,
                                          agent="build", model="offline/offline")["id"]
    child_human = ctx.app.store.add_message(child, "user", {"content": "Only this child's scoped mission."})
    child_ctx = SimpleNamespace(**{**vars(ctx), "session_id": child})
    child_index = ctx.app.store._receipt_index_path(child, "history", "conversation")
    projected = turn(child_ctx, child_human).context()
    assert projected == entry(child_index)
    assert parent_index.as_posix() not in projected and human["id"] not in projected
    assert ctx.session_id not in projected and not child_index.exists()
    with pytest.raises(ValueError, match="does not belong to this owner session"):
        PlanningStore(child_ctx).update({
            "expected_revision": None, "reason": "Attempt an explicitly selected foreign source.",
            "commission": {"summary": "Child commission", "source_message_ids": [human["id"]],
                           "observed_through_message_id": child_human["id"]},
            "requirements": [{"id": "scope", "text": "Child scope", "source_message_ids": [human["id"]],
                              "disposition": "active", "reason": "Selected source"}]})


@pytest.mark.parametrize("role, extra", [("assistant", {}), ("user", {"synthetic": True})])
def test_empty_human_index_does_not_authorize_substitute_sources(case, role, extra):
    ctx, _ = case
    sid = ctx.app.store.create_session(directory=str(ctx.directory), agent="build", model="offline/offline")["id"]
    message = ctx.app.store.add_message(sid, role, {"content": "A saved summary is not a human commission.", **extra})
    index = ctx.app.store.export_work_history(sid)
    assert "| human request |" not in index.read_text(encoding="utf-8")
    scoped = SimpleNamespace(**{**vars(ctx), "session_id": sid})
    assert turn(scoped, message).context() == entry(index)
    with pytest.raises(ValueError, match="nonsynthetic human"):
        PlanningStore(scoped).update({
            "expected_revision": None, "reason": "Attempt a nonhuman source.",
            "commission": {"summary": "Selected source", "source_message_ids": [message["id"]],
                           "observed_through_message_id": message["id"]},
            "requirements": [{"id": "scope", "text": "Selected scope", "source_message_ids": [message["id"]],
                              "disposition": "active", "reason": "Selected source"}]})
