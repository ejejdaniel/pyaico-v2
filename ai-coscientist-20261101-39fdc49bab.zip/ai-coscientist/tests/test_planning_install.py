"""Optional pack installation boundaries, with no model or network calls."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from scripts import setup_planning_workspace as planning
from scripts import setup_research_workspace as research


def files(root):
    return {p.relative_to(root).as_posix(): p.read_bytes() if p.is_file() else None
            for p in root.rglob("*")}


def write(root, relative, content):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    return path


def unchanged_rejection(root, action, match=".*"):
    before = files(root)
    with pytest.raises((ValueError, OSError), match=match):
        action()
    assert files(root) == before


def test_standalone_is_independent_preserves_config_and_does_not_create_plan(tmp_path):
    config = write(tmp_path, ".opencode/opencode.json", b'{"model":"kept/model","instructions":["custom.md"]}')
    root_config = write(tmp_path, "opencode.jsonc", b'// keep this\n{"custom":true}')
    helper = write(tmp_path, ".opencode/tool/helper.py", b"import math\ndef helper(value):\n    return math.sqrt(value)\n")
    project = Path(__file__).resolve().parents[1]
    code = ("import sys; from pathlib import Path; from scripts.setup_planning_workspace import install; "
            "install(Path(sys.argv[1])); assert not any(k == 'researchkit' or k.startswith('researchkit.') "
            "for k in sys.modules)")
    subprocess.run([sys.executable, "-X", "utf8", "-B", "-c", code, str(tmp_path)], cwd=project,
                   env={**os.environ, "PYTHONPATH": str(project / "src")}, check=True)
    before = files(tmp_path)
    planning.install(tmp_path)
    assert files(tmp_path) == before
    assert json.loads(config.read_bytes()) == {"model": "kept/model", "instructions": [
        "custom.md", ".opencode/skills/work-planning/SKILL.md"]}
    assert root_config.read_bytes() == b'// keep this\n{"custom":true}'
    assert helper.read_bytes().startswith(b"import math")
    assert (tmp_path / ".opencode/tools/planning.py").read_bytes() == research.PLANNING_STUB
    assert not (tmp_path / ".opencode/tools/research.py").exists()
    assert not (tmp_path / ".opencode/skills/research-practice").exists()
    assert not (tmp_path / ".opencode/planning").exists()


@pytest.mark.parametrize("order", ["research-first", "planning-first", "together", "two-stubs"])
def test_install_orders_combine_once_and_omission_preserves_planning(tmp_path, order):
    if order == "research-first":
        research.install(tmp_path)
        planning.install(tmp_path)
    elif order == "planning-first":
        planning.install(tmp_path)
        research.install(tmp_path)
    elif order == "together":
        research.install(tmp_path, planning=True)
    else:
        write(tmp_path, ".opencode/tools/research.py", research.RESEARCH_STUB)
        write(tmp_path, ".opencode/tools/planning.py", research.PLANNING_STUB)
        research.install(tmp_path)
    assert (tmp_path / ".opencode/tools/research.py").read_bytes() == research.COMBINED_STUB
    assert not (tmp_path / ".opencode/tools/planning.py").exists()
    config = json.loads((tmp_path / ".opencode/opencode.json").read_bytes())
    assert set(config["instructions"]) == {".opencode/skills/research-practice/SKILL.md",
                                           ".opencode/skills/work-planning/SKILL.md"}
    assert config["tool_output"] == research.RESEARCH_TOOL_OUTPUT
    before = files(tmp_path)
    research.install(tmp_path)
    planning.install(tmp_path)
    assert files(tmp_path) == before


def test_standalone_preserves_existing_customized_research_guidance(tmp_path):
    research.install(tmp_path)
    path = tmp_path / ".opencode/skills/research-practice/SKILL.md"
    path.write_bytes(b"Existing customized research guidance")
    planning.install(tmp_path)
    assert path.read_bytes() == b"Existing customized research guidance"
    assert (tmp_path / ".opencode/tools/research.py").read_bytes() == research.COMBINED_STUB


def test_research_omission_on_fresh_workspace_has_original_behavior(tmp_path):
    research.install(tmp_path)
    assert (tmp_path / ".opencode/tools/research.py").read_bytes() == research.RESEARCH_STUB
    assert not (tmp_path / ".opencode/skills/work-planning").exists()


def test_manifest_authorizes_only_untouched_old_planning_files_and_stays_unchanged(tmp_path):
    old = b"Previous untouched guidance\n"
    relative = "work-planning/references/operations.md"
    target = write(tmp_path, ".opencode/skills/" + relative, old)
    manifest = tmp_path / "runtime-manifest.json"
    manifest.write_text(json.dumps({"src/planningkit/skills/" + relative: hashlib.sha256(old).hexdigest()}))
    saved = manifest.read_bytes()
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path), "refusing silent replacement")
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path, {}), "Missing previous hash")
    target.write_bytes(b"User-edited guidance")
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path, planning.load_previous_manifest(manifest)), "edited")
    target.write_bytes(old)
    planning.main([str(tmp_path), "--previous-manifest", str(manifest)])
    assert target.read_bytes() != old
    assert manifest.read_bytes() == saved
    before = files(tmp_path)
    planning.install(tmp_path, {})
    assert files(tmp_path) == before


@pytest.mark.parametrize("content", [b"{", b"[]", b"null", b'{"src/planningkit/skills/x":"invalid"}'])
def test_invalid_manifest_is_rejected_before_installation(tmp_path, content):
    manifest = write(tmp_path, "runtime-manifest.json", content)
    unchanged_rejection(tmp_path, lambda: planning.main([str(tmp_path), "--previous-manifest", str(manifest)]))


def test_standalone_requires_existing_workspace(tmp_path):
    missing = tmp_path / "missing"
    unchanged_rejection(tmp_path, lambda: planning.install(missing), "existing directory")
    assert not missing.exists()


@pytest.mark.parametrize("directory", ["tools", "tool"])
@pytest.mark.parametrize("custom", [
    b"def TURN_EXTENSION(*args):\n    return None\n",
    b"from elsewhere import TURN_EXTENSION\n",
    b"from elsewhere import TOOLS\n",
    b"from opencode.tools.types import Tool\nTOOLS=[Tool('planning_read', '', {}, lambda **kw: None)]\n",
    b"from opencode.tools.types import Tool\nTOOLS=[Tool('research_record', '', {}, lambda **kw: None)]\n",
    b"TOOLS = make_tools()\n",
    b"from elsewhere import *\n",
])
def test_all_custom_stubs_are_checked_before_any_install_write(tmp_path, directory, custom):
    path = write(tmp_path, f".opencode/{directory}/custom.py", custom)
    unchanged_rejection(tmp_path, lambda: research.install(tmp_path, planning=True), "custom.py")
    assert path.read_bytes() == custom


def test_unknown_module_and_hidden_constructor_side_effects_are_never_executed(tmp_path):
    marker = tmp_path / "side-effect.txt"
    modules = [
        f"from pathlib import Path\nPath({str(marker)!r}).write_text('executed')\nTOOLS=[]\n",
        "from opencode.tools.types import Tool\nTOOLS=[Tool('custom', '', {}, "
        "globals().__setitem__('TURN_EXTENSION', lambda: None))]\n",
        "def helper(value=globals().__setitem__('TURN_EXTENSION', lambda: None)): pass\n",
        "TOOLS: globals().__setitem__('TURN_EXTENSION', lambda: None) = []\n",
    ]
    for content in modules:
        write(tmp_path, ".opencode/tool/side_effect.py", content.encode())
        unchanged_rejection(tmp_path, lambda: planning.install(tmp_path), "side_effect.py")
        assert not marker.exists()


def test_static_nonconflicting_tools_remain_untouched_in_both_directories(tmp_path):
    custom = (b"from opencode.tools.types import Tool, schema, prop\n"
              b"def handle(args, ctx):\n    return None\n"
              b"custom = Tool('custom_one', '', schema({'x':prop('string','')}, []), handle)\nTOOLS=[custom]\n")
    paths = [write(tmp_path, ".opencode/tools/one.py", custom),
             write(tmp_path, ".opencode/tool/two.py", custom.replace(b"custom_one", b"custom_two"))]
    saved = [p.read_bytes() for p in paths]
    planning.install(tmp_path)
    assert [p.read_bytes() for p in paths] == saved


def test_duplicate_custom_names_across_both_directories_are_rejected(tmp_path):
    custom = b"from opencode.tools.types import Tool\nTOOLS=[Tool('shared_name', '', {}, lambda **kw: None)]\n"
    write(tmp_path, ".opencode/tools/one.py", custom)
    write(tmp_path, ".opencode/tool/two.py", custom)
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path), "Conflicting tool name")


@pytest.mark.parametrize("path", [".opencode/tools/research.py", ".opencode/tools/planning.py"])
def test_customized_managed_stubs_are_not_overwritten_or_removed(tmp_path, path):
    write(tmp_path, path, b"# customized managed stub\nTOOLS=[]\n")
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path), "Existing plugin differs")


@pytest.mark.parametrize("path", [".opencode/tools", ".opencode/tool", ".opencode/skills", ".opencode"])
def test_invalid_installation_directories_fail_before_writes(tmp_path, path):
    write(tmp_path, path, b"not a directory")
    unchanged_rejection(tmp_path, lambda: planning.install(tmp_path))


@pytest.mark.parametrize("path,content", [
    (".opencode/tool/new.py", b"TOOLS=[]\n"),
    (".opencode/tools/custom.py", b"TOOLS=[unknown]\n"),
    (".opencode/skills/work-planning/SKILL.md", b"Intervening skill edit"),
    (".opencode/opencode.json", b"{}"),
    (".opencode/tools/planning.py", b"Intervening plugin edit"),
])
def test_preflight_rechecks_changed_and_added_files_before_all_writes(tmp_path, path, content):
    write(tmp_path, ".opencode/tools/custom.py", b"TOOLS=[]\n")
    _, apply = planning._prepare_install(tmp_path)
    write(tmp_path, path, content)
    unchanged_rejection(tmp_path, apply, "changed after validation")


def test_unchanged_installed_skill_is_also_rechecked_before_combining(tmp_path):
    planning.install(tmp_path)
    _, apply = research._prepare_install(tmp_path)
    write(tmp_path, ".opencode/skills/work-planning/SKILL.md", b"Intervening edit to unchanged skill")
    unchanged_rejection(tmp_path, apply, "changed after validation")
