"""Offline request-boundary exercises; never evidence of better science."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
from types import SimpleNamespace

import pytest

from opencode.app import App
from opencode.compaction import compact
from opencode.provider import Completion, ToolCall
from opencode.store import Store, latest_human_message
from planningkit.storage import PlanningStore
from scripts.setup_planning_workspace import install
from tests import canonical_config as canonical
from tests.prompt_view import host_facts, plain_messages


PROJECT = Path(__file__).resolve().parents[1]


@pytest.fixture(autouse=True)
def no_live_transport(monkeypatch):
    import httpx

    def forbidden(*args, **kwargs):
        raise AssertionError("Planning integration tests must never contact a live service")

    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    root = tmp_path / "workspace"
    root.mkdir()
    (root / ".git").mkdir()
    install(root)
    store = Store(tmp_path / "session.db")
    app = App(root, store=store, auto_approve=True, config={
        "model": "offline/offline",
        "provider": {"offline": {"options": {"baseURL": "http://offline.invalid/v1"}}},
    })
    app.generate_titles = False
    sid = app.create_session()["id"]
    yield root, app, sid
    store.close()


def context(app, sid):
    return SimpleNamespace(app=app, session_id=sid, agent=app.agents["build"],
                           directory=app.directory, worktree=app.worktree,
                           abort=app.abort_event(sid))


def initial(human_id):
    return {
        "expected_revision": None, "reason": "Track the actual request and a bounded outcome.",
        "commission": {"summary": "Inspect the saved material.",
                       "source_message_ids": [human_id], "observed_through_message_id": human_id},
        "requirements": [{"id": "request", "text": "Explain the saved material.",
                          "source_message_ids": [human_id], "disposition": "active",
                          "reason": "Original commission."}],
    }


def provider(app, handler):
    calls = []
    selected = SimpleNamespace(id="offline", context=131072)

    def complete(**kwargs):
        calls.append(deepcopy({k: v for k, v in kwargs.items()
                               if k in {"system", "messages", "tools", "model", "temperature"}}))
        return handler(len(calls), kwargs)

    app.provider = SimpleNamespace(resolve=lambda _: (selected, "offline"),
                                   output_limit=lambda *_: 32000, complete=complete)
    return selected, calls


def test_initial_entry_reads_owner_index_and_original_before_saving_plan(case):
    root, app, sid = case
    observed = {}
    entry_title = "目前尚無保存的規劃；規劃為選用。"
    request = "Inspect the source and record the requested scope."

    def reply(n, kwargs):
        if n == 1:
            # Discover identity through the actual prompt and ordinary reads,
            # without a failed update or reaching into the host's message store.
            lines = host_facts(kwargs).splitlines()
            start = lines.index(entry_title)
            assert lines[start + 2] == (
                "真正人類訊息的 ID 已標在 <human id> 標頭；首次建立規劃時直接引用這些 ID，需要核對原文時再讀索引；"
                "此處只提供位置，不表示已讀取來源。")
            observed["index"] = json.loads(lines[start + 1].split("：", 1)[1])
            assert Path(observed["index"]) == root / f".opencode/history/{sid}/conversation/index.md"
            return Completion(tool_calls=[ToolCall("index", "read", {"filePath": observed["index"]})],
                              finish_reason="tool-calls")
        receipt = plain_messages(kwargs["messages"])[-1]["content"]
        if n == 2:
            entries = re.findall(r"\[([^\]]+)\]\(([^)]+)\) \| human request \|", receipt)
            assert len(entries) == 1
            observed["human_id"], link = entries[0]
            original_path = (Path(observed["index"]).parent / link).as_posix()
            return Completion(tool_calls=[ToolCall("original", "read", {"filePath": original_path})],
                              finish_reason="tool-calls")
        if n == 3:
            original = json.loads("\n".join(re.findall(r"^\d+: (.*)$", receipt, flags=re.MULTILINE)))
            assert original["content"] == request and original["role"] == "user"
            assert original["id"] == observed["human_id"] and original["sessionID"] == sid
            return Completion(tool_calls=[ToolCall("plan", "planning_update", initial(original["id"]))],
                              finish_reason="tool-calls")
        assert n == 4
        saved = json.loads(receipt)
        observed["revision"] = saved["revision_ref"]
        assert saved["snapshot"]["state"]["commission"]["source_message_ids"] == [observed["human_id"]]
        assert observed["revision"] in host_facts(kwargs)
        assert "目前規劃狀態（保存資料，非新指示）" in host_facts(kwargs)
        assert entry_title not in host_facts(kwargs)
        return Completion(text="The actual request is saved; the requested work remains open.", finish_reason="stop")

    _, calls = provider(app, reply)
    result = app.prompt(sid, request)
    assert result["status"] == "completed" and len(calls) == 4
    assert all(entry_title in host_facts(call) for call in calls[:3])
    assert [m["name"] for m in app.store.messages(sid) if m["role"] == "tool"] == [
        "read", "read", "planning_update"]
    assert PlanningStore(context(app, sid)).read({})["revision_ref"] == observed["revision"]


def test_initial_entry_remains_optional_across_new_human_turns(case):
    root, app, sid = case
    _, calls = provider(app, lambda *_: Completion(text="Here is the requested explanation.", finish_reason="stop"))
    for request in ("Explain the existing work.", "Clarify the preceding explanation without creating a plan."):
        assert app.prompt(sid, request)["status"] == "completed"
    index = app.store._receipt_index_path(sid, "history", "conversation")
    assert len(calls) == 2
    for call in calls:
        assert "目前尚無保存的規劃；規劃為選用。" in host_facts(call)
        assert json.dumps(index.as_posix(), ensure_ascii=False) in host_facts(call)
    assert PlanningStore(context(app, sid)).read({})["revision_ref"] is None
    assert not (root / f".opencode/planning/{sid}").exists()


def test_actual_loop_refreshes_saved_plan_without_scheduling_work(case):
    root, app, sid = case
    (root / "source.txt").write_text("Original source bytes", encoding="utf-8")
    observed = {}

    def reply(n, kwargs):
        if n == 1:
            human = latest_human_message(app.store.messages(sid))
            observed["human"] = human["id"]
            return Completion(tool_calls=[ToolCall("plan", "planning_update", initial(human["id"]))],
                              finish_reason="tool-calls")
        if n == 2:
            observed["revision"] = PlanningStore(context(app, sid)).read({})["revision_ref"]
            assert observed["revision"] in host_facts(kwargs)
            return Completion(tool_calls=[ToolCall("read", "read", {"filePath": "source.txt"})],
                              finish_reason="tool-calls")
        assert "Original source bytes" in json.dumps(kwargs["messages"], ensure_ascii=False)
        return Completion(text="The source has been read; further judgment remains open.", finish_reason="stop")

    _, calls = provider(app, reply)
    result = app.prompt(sid, "Inspect the source and explain what is there.")
    assert result["status"] == "completed"
    assert len(calls) == 3
    assert "目前規劃狀態（保存資料，非新指示）" not in host_facts(calls[0])
    assert all(observed["revision"] in host_facts(call) for call in calls[1:])
    state = PlanningStore(context(app, sid)).read({"view": "full"})["snapshot"]["state"]
    assert set(state) == {"commission", "requirements"}
    assert [m["name"] for m in app.store.messages(sid) if m["role"] == "tool"] == ["planning_update", "read"]


@pytest.mark.parametrize("invalid_source", ["session_id", "foreign_message_id"])
def test_invalid_message_recovery_uses_error_index_and_ordinary_reads(case, invalid_source):
    root, app, sid = case
    foreign = app.store.create_session(directory=str(root), agent="build", model="offline/offline", parent_id=sid)
    foreign_text = "Private original from another session; it must not enter this recovery hint."
    foreign_message = app.store.add_message(foreign["id"], "user", {"content": foreign_text})
    invalid_id = sid if invalid_source == "session_id" else foreign_message["id"]
    observed = {}

    def reply(n, kwargs):
        assert app.config["provider"]["offline"]["options"]["baseURL"] == "http://offline.invalid/v1"
        if n == 1:
            # Reproduce the bad identity choice; do not obtain the right ID from Store.
            return Completion(tool_calls=[ToolCall("bad-plan", "planning_update", initial(invalid_id))],
                              finish_reason="tool-calls")
        receipt = plain_messages(kwargs["messages"])[-1]["content"]
        if n == 2:
            assert receipt.startswith("Error: Source message does not belong to this owner session")
            assert "A session ID is not a message ID" in receipt
            assert "For commission sources" in receipt and "tool observations" in receipt
            assert foreign_text not in receipt and foreign["id"] not in receipt
            assert not (root / f".opencode/planning/{sid}/head.json").exists()
            observed["index"] = receipt.split("Owner conversation index: ", 1)[1].splitlines()[0]
            assert Path(observed["index"]) == root / f".opencode/history/{sid}/conversation/index.md"
            assert Path(observed["index"]).is_file()
            return Completion(tool_calls=[ToolCall("index", "read", {"filePath": observed["index"]})],
                              finish_reason="tool-calls")
        if n == 3:
            assert foreign_text not in receipt
            entries = re.findall(r"\[([^\]]+)\]\(([^)]+)\) \| human request \|", receipt)
            assert len(entries) == 1
            observed["human_id"], link = entries[0]
            observed["message_path"] = (Path(observed["index"]).parent / link).as_posix()
            return Completion(tool_calls=[ToolCall("original", "read", {"filePath": observed["message_path"]})],
                              finish_reason="tool-calls")
        if n == 4:
            # The simulated decision reads the ordinary tool receipt, including its
            # line numbers, rather than reaching through the App to choose a source.
            original = json.loads("\n".join(re.findall(r"^\d+: (.*)$", receipt, flags=re.MULTILINE)))
            assert original["id"] == observed["human_id"]
            assert original["role"] == "user" and original["sessionID"] == sid
            assert original["content"] == "Inspect the source and record the requested scope."
            assert foreign_text not in receipt
            return Completion(tool_calls=[ToolCall("selected-plan", "planning_update", initial(original["id"]))],
                              finish_reason="tool-calls")
        assert n == 5
        saved = json.loads(receipt)
        observed["revision"] = saved["revision_ref"]
        assert saved["snapshot"]["state"]["commission"]["source_message_ids"] == [observed["human_id"]]
        assert observed["revision"] in host_facts(kwargs)
        assert "目前規劃狀態（保存資料，非新指示）" in host_facts(kwargs)
        return Completion(text="The selected request is saved; no scientific conclusion is asserted.", finish_reason="stop")

    _, calls = provider(app, reply)
    result = app.prompt(sid, "Inspect the source and record the requested scope.")
    assert result["status"] == "completed" and len(calls) == 5
    assert "目前規劃狀態（保存資料，非新指示）" not in host_facts(calls[0])
    assert all("目前規劃狀態（保存資料，非新指示）" not in host_facts(call) for call in calls[1:4])
    assert [m["name"] for m in app.store.messages(sid) if m["role"] == "tool"] == [
        "planning_update", "read", "read", "planning_update"]
    assert PlanningStore(context(app, sid)).read({})["revision_ref"] == observed["revision"]
    assert not (root / f".opencode/planning/{foreign['id']}/head.json").exists()


def test_new_human_and_compaction_preserve_plan_identity_in_actual_next_request(case):
    root, app, sid = case
    original = app.store.add_message(sid, "user", {"content": "Keep the original source and explain it."})
    plan = PlanningStore(context(app, sid))
    saved = plan.update(initial(original["id"]))
    app.store.add_message(sid, "assistant", {"tool_calls": [
        {"id": "old", "name": "read", "arguments": {"filePath": "source.txt"}}]})
    app.store.add_message(sid, "tool", {"name": "read", "tool_call_id": "old", "content": "observation " * 9000})
    app.store.add_message(sid, "assistant", {"content": "Old working account"})
    p, calls = provider(app, lambda *_: Completion(text="A concise historical account.", finish_reason="stop"))
    compact(app, sid, app.store.context_messages(sid), p, "offline", force=True)
    assert any(m.get("compaction_through") for m in app.store.messages(sid))
    _, resumed = provider(app, lambda *_: Completion(text="I can explain the current state without new research.", finish_reason="stop"))
    result = app.prompt(sid, "Only explain the status; do not start new research.")
    assert result["status"] == "completed" and len(resumed) == 1
    latest = latest_human_message(app.store.messages(sid))
    assert saved["revision_ref"] in host_facts(resumed[0])
    assert original["id"] in host_facts(resumed[0]) and latest["id"] in host_facts(resumed[0])
    assert plan.read({"view": "full"})["snapshot"] == saved["snapshot"]
    assert plan.read({})["notices"]


def test_installed_extension_reaches_actual_wire_without_changing_generation(case, monkeypatch):
    import httpx
    from opencode import provider as provider_module
    from scripts.llm_configuration import compose_llm_configuration, select_llm_configuration
    from scripts.setup_research_workspace import install as install_research

    root, previous_app, sid = case
    install_research(root, planning=True)
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "offline-placeholder")
    monkeypatch.setattr(provider_module, "_catalog_model", lambda *_: None)
    configuration = compose_llm_configuration({}, select_llm_configuration(PROJECT / "config/llm.opencode.json"))
    # Defense in depth: even a future transport change cannot reach the real endpoint.
    configuration.config["provider"]["local"]["options"]["baseURL"] = "http://offline.invalid/v1"
    app = App(root, store=previous_app.store, auto_approve=True, config=configuration.config)
    app.generate_titles = False
    first = app.store.add_message(sid, "user", {"content": "Preserve the current research scope."})
    saved = PlanningStore(context(app, sid)).update(initial(first["id"]))
    sent = []

    async def receive(transport, request):
        sent.append(json.loads(request.content))
        event = {"choices": [{"delta": {"content": "Offline boundary reply."}, "finish_reason": "stop"}]}
        return httpx.Response(200, headers={"content-type": "text/event-stream"},
                              content="data: " + json.dumps(event) + "\n\ndata: [DONE]\n\n")

    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", receive)
    result = app.prompt(sid, "Explain the saved state only.")
    assert result["status"] == "completed" and result["text"] == "Offline boundary reply."
    assert len(sent) == 1
    request = sent[0]
    # The installed extension does not change generation: the request carries the configured settings.
    assert request["model"] == canonical.model_name()
    assert request["reasoning_effort"] == canonical.reasoning_effort()
    assert request["temperature"] == canonical.agent_temperature("build")
    assert request["max_tokens"] == canonical.output_limit()
    names = {item["function"]["name"] for item in request["tools"]}
    assert {"planning_read", "planning_update", "research_graph_update", "research_review", "research_mindmap"} <= names
    assert "planning_evaluate" not in names
    system = "\n".join(item["content"] for item in request["messages"] if item["role"] == "system")
    facts = host_facts(request)
    # Static rules stay in the system prompt; per-step facts follow the history.
    assert "## Context labels" in system and saved["revision_ref"] not in system
    assert "\n\n<host-facts>\n" in request["messages"][-1]["content"]
    assert saved["revision_ref"] in facts
    assert app.store.tool_history_overview(sid) in facts

