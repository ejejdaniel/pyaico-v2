"""Exact revision identities and unchanged authority boundaries; no model calls."""

import copy
import json
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.store import Store
from planningkit import contracts as c
from planningkit.storage import PlanningStore
from planningkit.tools import READ_SCHEMA, REFERENCE, UPDATE_SCHEMA


@pytest.fixture
def case(tmp_path):
    messages = Store(tmp_path / "messages.sqlite")
    owner = messages.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    human = messages.add_message(owner, "user", {"content": "Inspect the supplied observations."})
    ctx = SimpleNamespace(directory=tmp_path, session_id=owner, abort=threading.Event(),
                          app=SimpleNamespace(store=messages))
    checks = []
    store = PlanningStore(ctx, check_access=lambda path, permission: checks.append((path, permission)))
    initial = {"expected_revision": None, "reason": "Record the actual request.",
               "commission": {"summary": "Inspect the supplied observations.", "source_message_ids": [human["id"]],
                              "observed_through_message_id": human["id"]},
               "requirements": [{"id": "r", "text": "Explain the observations.", "source_message_ids": [human["id"]],
                                 "disposition": "active", "reason": "Requested."}]}
    arguments.human = human["id"]
    yield SimpleNamespace(store=store, ctx=ctx, messages=messages, initial=initial, checks=checks)
    messages.close()


def identity(ref, form):
    return {"canonical": ref, "hash": Path(ref).stem, "filename": Path(ref).name}[form]


def arguments(operation, ref):
    # Each call words the requirement differently, so every update is a real change.
    arguments.calls = getattr(arguments, "calls", 0) + 1
    return {"expected_revision": ref, "reason": "Clarify the saved request.",
            "requirements": [{"id": "r", "text": f"Explain the observations ({arguments.calls}).",
                              "source_message_ids": [arguments.human], "disposition": "active", "reason": "Requested."}]}


def saved_files(store):
    return {path.relative_to(store.folder).as_posix(): path.read_bytes()
            for path in store.folder.rglob("*") if path.is_file()}


@pytest.mark.parametrize("operation", ["update"])
@pytest.mark.parametrize("form", ["canonical", "hash", "filename"])
def test_three_identities_preserve_arguments_and_canonical_persistence(case, operation, form):
    store = case.store
    first = store.update(case.initial)
    original_files = saved_files(store)
    args = arguments(operation, identity(first["revision_ref"], form))
    submitted = copy.deepcopy(args)
    result = getattr(store, operation)(args)
    assert args == submitted
    assert result["revision_ref"].startswith(store.prefix + "/revisions/")
    raw = (store.root / result["revision_ref"]).read_bytes()
    assert Path(result["revision_ref"]).stem == c.digest(raw)
    assert json.loads(raw)["previous_revision"] == first["revision_ref"]
    assert json.loads(store.head.read_bytes()) == {"schema_version": c.SCHEMA_VERSION, "revision_ref": result["revision_ref"]}
    for path, original in original_files.items():
        if path != "head.json":
            assert (store.folder / path).read_bytes() == original
    assert result["snapshot"]["previous_revision"] == first["revision_ref"]


@pytest.mark.parametrize("operation", ["update"])
@pytest.mark.parametrize("value", [
    "a" * 63, "a" * 65, "A" * 64, " " + "a" * 64, "a" * 64 + " ",
    "a" * 64 + ".JSON", "a" * 64 + ".json\n", "a" * 64 + ".json.json", "arbitrary.json",
    "../" + "a" * 64 + ".json", "", 1, False, [], {},
])
def test_invalid_identity_reports_original_without_reading_head(case, operation, value):
    store = case.store
    first = store.update(case.initial)
    before = saved_files(store)
    case.checks.clear()
    args = arguments(operation, value)
    original = copy.deepcopy(args)
    with pytest.raises(ValueError) as error:
        getattr(store, operation)(args)
    message = str(error.value)
    assert f"planning_{operation}.expected_revision" in message
    assert repr(value) in message
    assert 'planning_read(view="full")' in message
    # No file path to copy: a run (2026-11-01) passed the head file's path given here.
    assert f"{store.prefix}/head.json" not in message
    assert first["revision_ref"] not in message
    assert args == original and case.checks == [] and saved_files(store) == before


@pytest.mark.parametrize("operation", ["update"])
@pytest.mark.parametrize("path_form", ["absolute", "other_owner", "dotdot", "dot", "backslashes"])
def test_noncanonical_paths_are_not_new_identity_forms(case, operation, path_form):
    store = case.store
    ref = store.update(case.initial)["revision_ref"]
    malformed = {"absolute": (store.root / ref).as_posix(),
                 "other_owner": ref.replace(store.owner, "ses_other"),
                 "dotdot": ref.replace("/revisions/", "/revisions/../revisions/"),
                 "dot": "./" + ref, "backslashes": ref.replace("/", "\\")}[path_form]
    before = saved_files(store)
    with pytest.raises(ValueError, match=f"planning_{operation}.expected_revision") as error:
        getattr(store, operation)(arguments(operation, malformed))
    assert repr(malformed) in str(error.value)
    assert saved_files(store) == before


@pytest.mark.parametrize("operation", ["update"])
@pytest.mark.parametrize("form", ["canonical", "hash", "filename"])
@pytest.mark.parametrize("missing", [False, True])
def test_stale_and_missing_identities_do_not_select_current_head(case, operation, form, missing):
    store = case.store
    first = store.update(case.initial)
    second = store.update(arguments("update", first["revision_ref"]))
    ref = f"{store.prefix}/revisions/{'0' * 64}.json" if missing else first["revision_ref"]
    value = identity(ref, form)
    before = saved_files(store)
    with pytest.raises(ValueError, match="does not match the head") as error:
        getattr(store, operation)(arguments(operation, value))
    message = str(error.value)
    assert f"planning_{operation}.expected_revision" in message
    assert repr(value) in message and repr(ref) in message and repr(second["revision_ref"]) in message
    assert 'planning_read(view="full")' in message
    assert saved_files(store) == before


def test_null_still_means_initial_update_only(case):
    store = case.store
    initial = copy.deepcopy(case.initial)
    result = store.update(initial)
    assert initial == case.initial and result["snapshot"]["previous_revision"] is None
    before = saved_files(store)
    with pytest.raises(ValueError, match="planning_update.expected_revision.*received None"):
        store.update(initial)
    assert saved_files(store) == before


@pytest.mark.parametrize("operation", ["update"])
def test_valid_identity_cannot_read_a_denied_head_for_diagnostics(case, operation):
    store = case.store
    ref = store.update(case.initial)["revision_ref"]
    reads = []
    def deny_head(path, permission):
        reads.append((path, permission))
        if path == store.head and permission == "read":
            raise PermissionError("Denied head read")
    store.check_access = deny_head
    with pytest.raises(PermissionError, match="Denied head read") as error:
        getattr(store, operation)(arguments(operation, Path(ref).name))
    assert reads.count((store.head, "read")) == 1
    assert ref not in str(error.value)


def test_resolution_and_comparison_helpers_do_not_read_or_mutate(case, monkeypatch):
    store = case.store
    ref = f"{store.prefix}/revisions/{'a' * 64}.json"
    monkeypatch.setattr(store, "_head_ref", lambda: pytest.fail("Helpers must not read head"))
    for form in ("canonical", "hash", "filename"):
        supplied = identity(ref, form)
        assert store._expected_revision(supplied, field="planning_update.expected_revision") == ref
        store._expect_head(supplied, ref, ref, field="planning_update.expected_revision")
    assert store._expected_revision(None, field="planning_update.expected_revision", allow_none=True) is None
    store._expect_head(None, None, None, field="planning_update.expected_revision")
    with pytest.raises(ValueError, match="planning_update.expected_revision"):
        store._expect_head(Path(ref).name, ref, None, field="planning_update.expected_revision")
    assert case.checks == [] and not store.folder.exists()


def test_a_first_plan_is_told_to_pass_json_null(case):
    # LIT 2026-10-31 sent the text 'null' for its first plan, then guessed hashes of the head file; a run on
    # 2026-11-01 sent it twice more. The text can be no path or hash, so where null is allowed it means null.
    field = "planning_update.expected_revision"
    assert case.store._expected_revision("null", field=field, allow_none=True) is None
    assert case.store._expected_revision("None", field=field, allow_none=True) is None
    with pytest.raises(ValueError, match="pass JSON null itself \\(not the text 'null'"):
        case.store._expected_revision("head", field=field, allow_none=True)
    with pytest.raises(ValueError) as error:
        case.store._expected_revision("null", field="planning_read.revision")
    assert "JSON null" not in str(error.value)  # where null is not allowed, it is not offered
    ref = f"{case.store.prefix}/revisions/{'a' * 64}.json"
    with pytest.raises(ValueError, match="no plan has been saved yet.*JSON null itself"):
        case.store._expect_head("a" * 64, ref, None, field=field)


@pytest.mark.parametrize("form", ["hash", "filename"])
def test_other_reference_fields_keep_canonical_only_contract(case, form):
    store = case.store
    first = store.update(case.initial)
    ref = identity(first["revision_ref"], form)
    with pytest.raises(ValueError):
        store.read({"revision_ref": ref})
    with pytest.raises(ValueError):
        store._managed(ref, "revisions")
    assert "description" not in REFERENCE
    assert READ_SCHEMA["properties"]["revision_ref"] == REFERENCE
    assert "64-character lowercase" in UPDATE_SCHEMA["properties"]["expected_revision"]["description"]


@pytest.mark.parametrize("operation", ["update"])
def test_head_changed_after_explicit_preflight_is_rejected_without_commit(case, operation):
    store = case.store
    first = store.update(case.initial)
    supplied = Path(first["revision_ref"]).name
    resolved = store._expected_revision(supplied, field=f"planning_{operation}.expected_revision")
    store._expect_head(supplied, resolved, store._head_ref(), field=f"planning_{operation}.expected_revision")
    second = store.update(arguments("update", first["revision_ref"]))
    before = saved_files(store)
    with pytest.raises(ValueError, match="does not match the head") as error:
        getattr(store, operation)(arguments(operation, supplied))
    assert repr(supplied) in str(error.value) and second["revision_ref"] in str(error.value)
    assert saved_files(store) == before


@pytest.mark.parametrize("operation", ["update"])
def test_final_head_check_keeps_original_identity_and_does_not_replace_head(case, operation, monkeypatch):
    store = case.store
    first = store.update(case.initial)
    supplied = Path(first["revision_ref"]).name
    original_head = store.head.read_bytes()
    original_read = store._head_ref
    head_calls = []
    changed_head = f"{store.prefix}/revisions/{'0' * 64}.json"
    def changed_after_load():
        head_calls.append(True)
        return original_read() if len(head_calls) == 1 else changed_head
    monkeypatch.setattr(store, "_head_ref", changed_after_load)
    with pytest.raises(ValueError, match="does not match the head") as error:
        getattr(store, operation)(arguments(operation, supplied))
    message = str(error.value)
    assert f"planning_{operation}.expected_revision" in message
    assert repr(supplied) in message and changed_head in message
    assert store.head.read_bytes() == original_head
    assert not list(store.folder.glob(".head-*.tmp"))


def test_concurrent_equivalent_identity_forms_commit_at_most_once(case):
    store = case.store
    first = store.update(case.initial)
    barrier = threading.Barrier(2)
    results, errors = [], []
    def submit(form):
        contender = PlanningStore(case.ctx, check_access=lambda *args: None)
        barrier.wait()
        try:
            results.append(contender.update(arguments("update", identity(first["revision_ref"], form))))
        except (RuntimeError, ValueError) as exc:
            errors.append(exc)
    threads = [threading.Thread(target=submit, args=(form,)) for form in ("hash", "filename")]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=10)
        assert not thread.is_alive()
    assert len(results) == len(errors) == 1
    assert store.read({"view": "full"})["snapshot"]["revision"] == 2
