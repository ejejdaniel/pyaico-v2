"""Deterministic persistence/authority boundaries of the goal layer; no model quality."""

import copy
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode.permission import PermissionRejected
from opencode.store import Store
from planningkit import contracts as c
from planningkit.storage import PlanningStore


@pytest.fixture
def setup(tmp_path):
    root = tmp_path / "workspace"
    root.mkdir()
    messages = Store(tmp_path / "messages.sqlite")
    session = messages.create_session(directory=str(root), agent="build", model=None)
    human = messages.add_message(session["id"], "user", {"content": "Investigate the supplied evidence."})
    ctx = SimpleNamespace(directory=root, session_id=session["id"], abort=threading.Event(),
                          app=SimpleNamespace(store=messages))
    checks = []
    store = PlanningStore(ctx, check_access=lambda path, permission: checks.append((path, permission)))
    yield root, messages, ctx, store, human, checks
    messages._conn.close()


def requirement(human, id="r", text="Explain the supplied observations", disposition="active"):
    return {"id": id, "text": text, "source_message_ids": [human["id"]], "disposition": disposition,
            "reason": "Requested"}


def initial(human):
    return {"expected_revision": None, "reason": "Record the actual request",
            "commission": {"summary": "Investigate evidence", "source_message_ids": [human["id"]],
                           "observed_through_message_id": human["id"]},
            "requirements": [requirement(human)]}


def start(setup):
    root, messages, ctx, store, human, checks = setup
    return store.update(initial(human))


def change(store, ref, human, reason="Clarify", text="Explain the observations with sources"):
    return store.update({"expected_revision": ref, "reason": reason, "requirements": [requirement(human, text=text)]})


def test_empty_read_does_not_create_and_checks_before_existence(setup):
    root, messages, ctx, store, human, checks = setup
    result = store.read({})
    assert result == {"revision_ref": None, "snapshot": None, "history": [], "summary": "", "notices": []}
    assert not (root / ".opencode").exists()
    assert checks == [(store.head, "read")]
    denied = PlanningStore(ctx, check_access=lambda *args: (_ for _ in ()).throw(PermissionError("denied")))
    with pytest.raises(PermissionError):
        denied.read({})


def test_initial_snapshot_is_actual_human_and_revision_is_canonical(setup):
    root, messages, ctx, store, human, checks = setup
    response = store.update(initial(human))
    revision = response["snapshot"]
    raw = (root / response["revision_ref"]).read_bytes()
    assert raw == c.canonical_bytes(revision)
    assert Path(response["revision_ref"]).stem == c.digest(raw)
    assert revision["revision"] == 1 and revision["previous_revision"] is None
    assert revision["schema_version"] == c.SCHEMA_VERSION
    assert set(revision["state"]) == {"commission", "requirements"}
    snap = revision["state"]["commission"]["source_snapshots"][0]
    assert (root / snap["snapshot_path"]).read_bytes() == c.canonical_bytes(messages.messages(ctx.session_id)[0])
    assert (store.folder / ".lock").read_bytes() == b"\0"
    assert not any(path == messages.path.resolve() for path, permission in checks)
    unchanged = store.update({"expected_revision": response["revision_ref"], "reason": "Same interpretation",
                              "requirements": [requirement(human)]})
    assert unchanged["revision_ref"] == response["revision_ref"]
    assert any("no-change" in notice for notice in unchanged["notices"])
    with pytest.raises(ValueError, match="expected_revision"):
        store.update(initial(human))


def test_requirements_upsert_withdraw_but_never_delete(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    added = store.update({"expected_revision": first["revision_ref"], "reason": "Second goal",
                          "requirements": [requirement(human, "s", "Rank the candidates")]})
    assert [item["id"] for item in added["snapshot"]["state"]["requirements"]] == ["r", "s"]
    withdrawn = store.update({"expected_revision": added["revision_ref"], "reason": "User dropped it",
                              "requirements": [requirement(human, "s", "Rank the candidates", "withdrawn")]})
    assert withdrawn["snapshot"]["state"]["requirements"][1]["disposition"] == "withdrawn"
    for changes in ({"requirements": [requirement(human), requirement(human)]},
                    {"requirements": [dict(requirement(human), source_message_ids=["not-selected"])]},
                    {"frames": []}, {"nodes": []}, {}):
        with pytest.raises(ValueError):
            store.update({"expected_revision": withdrawn["revision_ref"], "reason": "Invalid change", **changes})
    assert store.read({"view": "full"})["revision_ref"] == withdrawn["revision_ref"]


@pytest.mark.parametrize("mutation", [
    lambda args: args.update(extra="unknown"),
    lambda args: args["commission"].update(source_snapshots=[]),
    lambda args: args["commission"].update(summary=" "),
    lambda args: args["commission"].update(summary="x" * 2001),
    lambda args: args["requirements"][0].update(id="invalid.id"),
    lambda args: args["requirements"][0].update(disposition="fulfilled"),
    lambda args: args["requirements"][0].update(reason="x" * 4097),
    lambda args: args.update(requirements=[]),
    lambda args: args.pop("commission"),
])
def test_rejects_unapproved_or_malformed_inputs(setup, mutation):
    root, messages, ctx, store, human, checks = setup
    args = initial(human)
    mutation(args)
    with pytest.raises(ValueError):
        store.update(args)
    assert not store.head.exists()


def test_supplied_commission_must_observe_latest_human_but_omitted_commission_commits_with_notice(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    newer = messages.add_message(ctx.session_id, "user", {"content": "Focus on a narrower question."})
    messages.add_message(ctx.session_id, "user", {"content": "background", "synthetic": True})
    assert store.latest_human_id() == newer["id"]
    stale = copy.deepcopy(first["snapshot"]["state"]["commission"])
    stale.pop("source_snapshots")
    with pytest.raises(ValueError, match="latest human") as rejected:
        store.update({"expected_revision": first["revision_ref"], "reason": "Stale claim", "commission": stale})
    assert newer["id"] in str(rejected.value) and human["id"] in str(rejected.value)
    assert store.read({})["revision_ref"] == first["revision_ref"]
    progressed = change(store, first["revision_ref"], human, "Refine wording")
    assert progressed["snapshot"]["revision"] == 2
    assert progressed["snapshot"]["state"]["commission"]["observed_through_message_id"] == human["id"]
    assert any("新訊息" in notice for notice in progressed["notices"])
    current = copy.deepcopy(first["snapshot"]["state"]["commission"])
    current.pop("source_snapshots")
    current["observed_through_message_id"] = newer["id"]
    current["source_message_ids"].append(newer["id"])
    updated = store.update({"expected_revision": progressed["revision_ref"], "reason": "Narrower question",
                            "commission": current,
                            "requirements": [dict(requirement(human, "n", "Answer the narrower question"),
                                                  source_message_ids=[newer["id"]])]})
    assert not any("新訊息" in notice for notice in updated["notices"])
    assert [item["source"] for item in updated["snapshot"]["state"]["commission"]["source_snapshots"]] == [
        human["id"], newer["id"]]


def test_original_human_only_and_owner_scope(setup):
    root, messages, ctx, store, human, checks = setup
    synthetic = messages.add_message(ctx.session_id, "user", {"content": "notification", "synthetic": True})
    tool = messages.add_message(ctx.session_id, "tool", {"content": "observation"})
    foreign = messages.create_session(directory=str(root), agent="build", model=None, parent_id=ctx.session_id)
    outsider = messages.add_message(foreign["id"], "user", {"content": "Other request"})
    for selected in (synthetic, tool, outsider):
        with pytest.raises(ValueError):
            store.update(initial(selected))
    first = start(setup)
    child_ctx = SimpleNamespace(**vars(ctx))
    child_ctx.session_id = foreign["id"]
    child = PlanningStore(child_ctx, check_access=lambda *args: None)
    assert child.read({})["revision_ref"] is None
    with pytest.raises(ValueError):
        child.read({"revision_ref": first["revision_ref"]})


def test_caps_and_strict_json_numbers_and_duplicates(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}'):
        with pytest.raises(ValueError):
            c.strict_json(raw)
    bad = copy.deepcopy(first["snapshot"])
    bad["revision"] = True
    with pytest.raises(ValueError):
        c.revision(bad, ctx.session_id)
    many = [dict(requirement(human, f"r{i}"), text="x" * 4096) for i in range(70)]
    with pytest.raises(ValueError, match="State exceeds"):
        store.update({"expected_revision": first["revision_ref"], "reason": "Too large", "requirements": many})


def test_cancellation_and_latest_message_race_leave_previous_head(setup, monkeypatch):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    original = store._immutable

    def interrupted(ref, raw, maximum):
        original(ref, raw, maximum)
        ctx.abort.set()
    monkeypatch.setattr(store, "_immutable", interrupted)
    with pytest.raises(PermissionRejected):
        change(store, first["revision_ref"], human, "Cancelled")
    ctx.abort.clear()
    assert store.read({})["revision_ref"] == first["revision_ref"]
    arrived = []

    def new_human(ref, raw, maximum):
        original(ref, raw, maximum)
        if not arrived:
            arrived.append(messages.add_message(ctx.session_id, "user", {"content": "A newer instruction arrived."}))
    monkeypatch.setattr(store, "_immutable", new_human)
    claim = copy.deepcopy(first["snapshot"]["state"]["commission"])
    claim.pop("source_snapshots")
    claim["summary"] = "Investigate evidence; restated"
    with pytest.raises(ValueError, match="latest human"):
        store.update({"expected_revision": first["revision_ref"], "reason": "Race", "commission": claim})
    assert store.read({})["revision_ref"] == first["revision_ref"]
    saved = change(store, first["revision_ref"], human, "Race without claim")
    assert store.read({})["revision_ref"] == saved["revision_ref"] != first["revision_ref"]
    assert any("新訊息" in notice for notice in saved["notices"])


def test_os_lock_is_nonblocking_and_released_after_process_exit(setup):
    root, messages, ctx, store, human, checks = setup
    start(setup)
    script = """import os,sys,time
from pathlib import Path
p=Path(sys.argv[1]); f=p.open('r+b')
if os.name=='nt':
 import msvcrt; msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
else:
 import fcntl; fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
print('locked',flush=True)
sys.stdin.readline()
"""
    child = subprocess.Popen([sys.executable, "-c", script, str(store.folder / ".lock")],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    try:
        assert child.stdout.readline().strip() == "locked"
        with pytest.raises(RuntimeError, match="already being modified"):
            with store._locked():
                pytest.fail("The OS lock was bypassed")
    finally:
        child.terminate()
        child.wait(timeout=10)
    with store._locked():
        pass
    assert (store.folder / ".lock").read_bytes() == b"\0"


def test_concurrent_same_expected_revision_commits_at_most_once(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    barrier = threading.Barrier(2)
    results, errors = [], []

    def submit():
        contender = PlanningStore(ctx, check_access=lambda *args: None)
        barrier.wait()
        try:
            results.append(change(contender, first["revision_ref"], human))
        except (RuntimeError, ValueError) as exc:
            errors.append(exc)
    threads = [threading.Thread(target=submit) for _ in range(2)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=10)
        assert not thread.is_alive()
    assert len(results) == len(errors) == 1
    assert store.read({"view": "full"})["snapshot"]["revision"] == 2


def test_read_rejects_rehashed_invalid_schema_and_broken_history(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    original_head = store.head.read_bytes()
    invalid = copy.deepcopy(first["snapshot"])
    invalid["state"]["requirements"][0]["disposition"] = "successful"
    raw = c.canonical_bytes(invalid)
    ref = f"{store.prefix}/revisions/{c.digest(raw)}.json"
    (root / ref).write_bytes(raw)
    store.head.write_bytes(c.canonical_bytes({"schema_version": c.SCHEMA_VERSION, "revision_ref": ref}))
    with pytest.raises(ValueError, match="disposition"):
        store.read({})
    store.head.write_bytes(original_head)
    orphan = copy.deepcopy(first["snapshot"])
    orphan["reason"] = "An orphan is not committed"
    raw = c.canonical_bytes(orphan)
    orphan_ref = f"{store.prefix}/revisions/{c.digest(raw)}.json"
    (root / orphan_ref).write_bytes(raw)
    with pytest.raises(ValueError, match="committed history"):
        store.read({"revision_ref": orphan_ref})
    (root / first["revision_ref"]).write_bytes(b"invalid")
    with pytest.raises(ValueError, match="hash mismatch"):
        store.read({})


def test_legacy_frame_node_plan_is_reported_not_reinterpreted(setup):
    root, messages, ctx, store, human, checks = setup
    start(setup)
    store.head.write_bytes(c.canonical_bytes({"schema_version": 1, "revision_ref": store.read({})["revision_ref"]}))
    with pytest.raises(c.LegacyPlan, match="removed Frame/Node format"):
        store.read({})


def test_workspace_move_preserves_history_and_source_bytes(setup, tmp_path):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    second = change(store, first["revision_ref"], human)
    target = tmp_path / "moved"
    shutil.copytree(root, target)
    moved_ctx = SimpleNamespace(**vars(ctx))
    moved_ctx.directory = target
    moved = PlanningStore(moved_ctx, check_access=lambda *args: None)
    assert moved.read({"view": "full"}) == store.read({"view": "full"})
    assert moved.read({"view": "history"})["history"][0]["revision_ref"] == second["revision_ref"]


def test_frozen_human_message_survives_common_metadata_changes(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    frozen = first["snapshot"]["state"]["commission"]["source_snapshots"][0]
    original = (root / frozen["snapshot_path"]).read_bytes()
    messages.update_message(ctx.session_id, human["id"], metadata={"later_metadata": True})
    assert store.read({"view": "full"})["snapshot"] == first["snapshot"]
    assert (root / frozen["snapshot_path"]).read_bytes() == original


def test_failed_head_replace_preserves_previous_version_and_rejects_orphan(setup, monkeypatch):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    before = set((store.folder / "revisions").iterdir())

    def failure(*args):
        raise OSError("Injected head replace interruption")
    monkeypatch.setattr("planningkit.storage.os.replace", failure)
    with pytest.raises(OSError, match="Injected"):
        change(store, first["revision_ref"], human, "Interrupted")
    assert store.read({})["revision_ref"] == first["revision_ref"]
    orphan, = set((store.folder / "revisions").iterdir()) - before
    with pytest.raises(ValueError, match="committed history"):
        store.read({"revision_ref": orphan.relative_to(root).as_posix()})
    assert not list(store.folder.glob(".head-*.tmp"))


def test_history_paginates(setup):
    root, messages, ctx, store, human, checks = setup
    first = start(setup)
    current = first
    for i in range(23):
        current = change(store, current["revision_ref"], human, f"Wording {i}", f"Explain observation {i}")
    page = store.read({"view": "history"})
    assert len(page["history"]) == 20
    remaining = store.read({"view": "history", "revision_ref": page["history"][-1]["previous_revision"]})
    assert len(remaining["history"]) == 4
    assert remaining["history"][-1]["revision_ref"] == first["revision_ref"]
    assert store.read({"view": "full", "revision_ref": first["revision_ref"]})["snapshot"] == first["snapshot"]
