"""Deterministic planning tool and automatic projection boundaries; no model calls."""

from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import threading
from types import SimpleNamespace

import jsonschema
import pytest

from opencode.agent import Agent
from opencode.app import _load_local_tools
from opencode.permission import Broker, PermissionDenied, PermissionRejected, Rule
from opencode.store import Store
from planningkit.projection import MAX_CONTEXT_BYTES, TITLE, render
from planningkit.tools import READ_SCHEMA, TOOLS, UPDATE_SCHEMA
from planningkit.turn import PlanningTurn


@pytest.fixture
def case(tmp_path):
    store = Store(tmp_path / "session.db")
    session = store.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    human = store.add_message(session, "user", {"content": "Compare the two documented alternatives."})
    agent = Agent("build", permission=[Rule("*", "*", "allow")])
    abort = threading.Event()
    app = SimpleNamespace(store=store, directory=tmp_path, worktree=tmp_path, agents={"build": agent},
                          default_agent="build", permissions=Broker(auto=True), extra_tools=TOOLS,
                          abort_event=lambda _session: abort)
    ctx = SimpleNamespace(app=app, directory=tmp_path, worktree=tmp_path, agent=agent,
                          session_id=session, abort=abort)
    yield ctx, human["id"]
    store.close()


def call(ctx, name, args):
    return next(tool for tool in TOOLS if tool.name == name).execute(args, ctx)


def decoded(ctx, name, args):
    return json.loads(call(ctx, name, args).output)


def initial(human_id):
    return {"expected_revision": None, "reason": "Record the requested comparison.",
            "commission": {"summary": "Compare alternatives without assuming a preferred outcome.",
                           "source_message_ids": [human_id], "observed_through_message_id": human_id},
            "requirements": [{"id": "comparison", "text": "Compare the documented alternatives.",
                              "source_message_ids": [human_id], "disposition": "active", "reason": "Human request."}]}


def establish(ctx, human_id):
    return decoded(ctx, "planning_update", initial(human_id))


def test_exact_tool_names_and_no_plan_receipt(case):
    ctx, human_id = case
    assert [tool.name for tool in TOOLS] == ["planning_read", "planning_update"]
    result = call(ctx, "planning_read", {})
    assert json.loads(result.output) == {"revision_ref": None, "snapshot": None, "history": [],
                                        "summary": "", "notices": []}
    assert result.metadata == {} and result.attachments == []
    index = ctx.app.store._receipt_index_path(ctx.session_id, "history", "conversation")
    assert PlanningTurn(ctx.app, ctx.session_id, human_id).context() == (
        "目前尚無保存的規劃；規劃為選用。\n"
        f"本會話的對話歷史索引位置：{json.dumps(index.as_posix(), ensure_ascii=False)}\n"
        "真正人類訊息的 ID 已標在 <human id> 標頭；首次建立規劃時直接引用這些 ID，需要核對原文時再讀索引；"
        "此處只提供位置，不表示已讀取來源。")
    assert not (ctx.directory / ".opencode/planning").exists()


def test_update_pretty_receipt_exact_history_summary_and_latest_human_notice(case):
    ctx, human_id = case
    args = initial(human_id)
    args["commission"]["summary"] = "比較兩項方案；保留未知量。"
    receipt = call(ctx, "planning_update", args)
    assert '\n  "' in receipt.output and "比較兩項方案" in receipt.output
    first = json.loads(receipt.output)
    assert set(first) == {"revision_ref", "snapshot", "history", "summary", "notices"}
    assert TITLE in first["summary"] and human_id in first["summary"]
    later = ctx.app.store.add_message(ctx.session_id, "user", {"content": "Pause the comparison and explain existing observations."})
    args = {"expected_revision": first["revision_ref"], "reason": "Record the follow-up before changing scope.",
            "commission": {**args["commission"], "source_message_ids": [human_id, later["id"]],
                           "observed_through_message_id": later["id"], "summary": "Explain the existing observations."}}
    second = decoded(ctx, "planning_update", args)
    old = decoded(ctx, "planning_read", {"view": "summary", "revision_ref": first["revision_ref"]})
    history = decoded(ctx, "planning_read", {"view": "history", "revision_ref": first["revision_ref"]})
    assert old["snapshot"] is None and history["snapshot"] is None
    assert old["summary"] == history["summary"]
    assert "比較兩項方案" in old["summary"] and "Explain the existing observations" not in old["summary"]
    assert first["revision_ref"] in old["summary"] and later["id"] in old["summary"]
    assert "新訊息尚未由規劃修訂對照" in old["summary"]
    assert "新訊息尚未由規劃修訂對照" not in second["summary"]


def test_projection_lists_active_requirements_and_counts_withdrawn(case):
    ctx, human_id = case
    first = establish(ctx, human_id)
    withdrawn = {"id": "extra", "text": "Also rank them.", "source_message_ids": [human_id],
                 "disposition": "withdrawn", "reason": "Human dropped ranking."}
    second = decoded(ctx, "planning_update", {"expected_revision": first["revision_ref"], "reason": "Drop ranking.",
                                              "requirements": [withdrawn]})
    assert "- comparison：Compare the documented alternatives." in second["summary"]
    assert "Also rank them." not in second["summary"]
    assert "active requirements：1；withdrawn：1" in second["summary"]


@pytest.mark.parametrize("name", ["planning_read", "planning_update"])
def test_tools_check_named_permission_and_pass_abort(case, name):
    ctx, human_id = case
    first = establish(ctx, human_id)
    args = {} if name == "planning_read" else {"expected_revision": first["revision_ref"], "reason": "Clarify.",
                                               "requirements": initial(human_id)["requirements"]}
    ctx.agent.permission.append(Rule(name, "*", "deny"))
    with pytest.raises(PermissionDenied, match=name):
        call(ctx, name, args)
    ctx.agent.permission.pop()
    ctx.abort.set()
    with pytest.raises(PermissionRejected, match="stopped"):
        call(ctx, name, args)


@pytest.mark.parametrize("permission,pattern", [("edit", ".opencode/planning/*")])
def test_named_permission_does_not_replace_file_permissions(case, permission, pattern):
    ctx, human_id = case
    args = initial(human_id)
    ctx.agent.permission.append(Rule(permission, pattern, "deny"))
    with pytest.raises(PermissionDenied):
        call(ctx, "planning_update", args)
    assert not (ctx.directory / f".opencode/planning/{ctx.session_id}/head.json").exists()


def test_owner_message_access_does_not_authorize_the_backing_database_as_a_file(case):
    ctx, human_id = case
    ctx.agent.permission.append(Rule("read", "session.db", "deny"))
    first = establish(ctx, human_id)
    assert human_id in first["summary"]
    assert PlanningTurn(ctx.app, ctx.session_id, human_id).context()


def test_explicit_read_uses_broker_cache_but_automatic_projection_does_not(case):
    ctx, human_id = case
    establish(ctx, human_id)
    ctx.agent.permission.append(Rule("planning_read", "*", "ask"))
    asked = []
    ctx.app.permissions = Broker(callback=lambda pending: asked.append(pending.permission) or "always")
    assert decoded(ctx, "planning_read", {})["summary"]
    assert asked == ["planning_read"]
    assert PlanningTurn(ctx.app, ctx.session_id, human_id).context() == ""
    assert asked == ["planning_read"]


@pytest.mark.parametrize("action", ["ask", "deny"])
@pytest.mark.parametrize("pattern", [".opencode/planning/*", "message_blob"])
def test_automatic_projection_skips_any_nonallowed_source_without_asking(case, action, pattern):
    ctx, human_id = case
    saved = decoded(ctx, "planning_update", initial(human_id))
    if pattern == "message_blob":
        pattern = saved["snapshot"]["state"]["commission"]["source_snapshots"][0]["snapshot_path"]
    ctx.agent.permission.append(Rule("read", pattern, action))
    ctx.app.permissions = Broker(callback=lambda _: pytest.fail("Automatic projection must not ask the Broker"))
    ctx.app.permissions._approved.append(Rule("read", pattern, "allow"))
    assert PlanningTurn(ctx.app, ctx.session_id, human_id).context() == ""


def test_session_config_rules_override_agent_rules_without_mutating_them(case):
    ctx, human_id = case
    saved = establish(ctx, human_id)
    message_blob = saved["snapshot"]["state"]["commission"]["source_snapshots"][0]["snapshot_path"]
    original = list(ctx.agent.permission)
    turn = PlanningTurn(ctx.app, ctx.session_id, human_id)
    assert turn.context()
    ctx.app.store.update_session(ctx.session_id, permission=[{"permission": "planning_read", "pattern": "*", "action": "deny"}])
    assert turn.context() == "" and ctx.agent.permission == original
    ctx.agent.permission.append(Rule("planning_read", "*", "deny"))
    ctx.app.store.update_session(ctx.session_id, permission=[{"permission": "planning_read", "pattern": "*", "action": "allow"}])
    assert turn.context()
    ctx.app.store.update_session(ctx.session_id, permission=[{"permission": "read", "pattern": message_blob, "action": "ask"},
                                                            {"permission": "planning_read", "pattern": "*", "action": "allow"}])
    assert turn.context() == ""


def test_existing_corrupt_state_is_an_error_not_an_empty_plan(case):
    ctx, human_id = case
    first = establish(ctx, human_id)
    (ctx.directory / first["revision_ref"]).write_bytes(b'{"bad":true}')
    with pytest.raises(ValueError):
        PlanningTurn(ctx.app, ctx.session_id, human_id).context()
    with pytest.raises(ValueError):
        call(ctx, "planning_read", {})


def test_child_never_resolves_parent_plan_and_can_create_its_own(case):
    ctx, human_id = case
    parent = establish(ctx, human_id)
    child = ctx.app.store.create_session(directory=str(ctx.directory), parent_id=ctx.session_id, agent="build", model=None)["id"]
    child_human = ctx.app.store.add_message(child, "user", {"content": "Inspect only the explicitly delegated observation."})
    child_ctx = SimpleNamespace(**{**vars(ctx), "session_id": child})
    turn = PlanningTurn(ctx.app, child, child_human["id"])
    entry = turn.context()
    child_index = ctx.app.store._receipt_index_path(child, "history", "conversation")
    assert json.dumps(child_index.as_posix(), ensure_ascii=False) in entry
    assert ctx.session_id not in entry and human_id not in entry
    with pytest.raises(ValueError):
        call(child_ctx, "planning_read", {"revision_ref": parent["revision_ref"]})
    own = establish(child_ctx, child_human["id"])
    projected = turn.context()
    assert own["revision_ref"] in projected
    assert parent["revision_ref"] not in projected and human_id not in projected


def test_projection_cap_preserves_identity_new_human_readback_and_omission_counts():
    state = {"commission": {"summary": "委" * 2000, "observed_through_message_id": "msg_old"},
             "requirements": [{"id": f"r{i}", "text": "條" * 200, "disposition": "active"} for i in range(80)]}
    revision = {"owner_session_id": "ses_owner", "revision": 3, "state": state}
    reference = ".opencode/planning/ses_owner/revisions/" + "a" * 64 + ".json"
    result = render(reference, revision, "msg_new", [])
    assert result == render(reference, revision, "msg_new", [])
    assert len(result.encode("utf-8")) <= MAX_CONTEXT_BYTES
    assert "owner：ses_owner" in result and "revision：3" in result
    assert "msg_old" in result and "msg_new" in result and "新訊息尚未由規劃修訂對照" in result
    assert f'planning_read(view="full", revision_ref="{reference}")' in result
    assert "尚有" in result and "項未列出" in result and "已截斷" in result
    assert "委" * 1000 in result and "委" * 1001 not in result
    assert "條" * 160 in result and "條" * 161 not in result


@pytest.mark.parametrize("tool_schema,payload", [
    (READ_SCHEMA, {"session_id": "parent"}),
    (READ_SCHEMA, {"assessment_ref": "somewhere"}),
    (READ_SCHEMA, {"view": "assessment"}),
    (UPDATE_SCHEMA, {"expected_revision": None, "reason": "No changes specified."}),
    (UPDATE_SCHEMA, {"expected_revision": None, "reason": "Old field.", "focus_node_ids": []}),
    (UPDATE_SCHEMA, {"expected_revision": None, "reason": "Old field.", "nodes": []}),
])
def test_tool_schemas_reject_unapproved_or_missing_fields(tool_schema, payload):
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(payload, tool_schema)


def test_tool_schemas_validate_exact_approved_shapes(case):
    _, human_id = case
    jsonschema.validate({}, READ_SCHEMA)
    jsonschema.validate({"view": "history", "revision_ref": "revision"}, READ_SCHEMA)
    jsonschema.validate(initial(human_id), UPDATE_SCHEMA)


def test_standalone_extension_import_does_not_load_researchkit(case):
    ctx, _ = case
    folder = ctx.directory / ".opencode/tools"
    folder.mkdir(parents=True)
    (folder / "planning.py").write_text("from planningkit.tools import TOOLS, TURN_EXTENSION\n", encoding="utf-8")
    loaded, factory = _load_local_tools(ctx.directory)
    assert [tool.name for tool in loaded] == [tool.name for tool in TOOLS] and factory is PlanningTurn
    result = subprocess.run([sys.executable, "-c", "import planningkit.tools, sys; assert not any(x == 'researchkit' or x.startswith('researchkit.') for x in sys.modules)"],
                            capture_output=True, text=True, cwd=Path(__file__).resolve().parents[1])
    assert result.returncode == 0, result.stderr


def test_combined_extension_preserves_research_context_feedback_and_presentation(case):
    from researchkit.planning_adapter import ResearchPlanningTurn, TOOLS as COMBINED_TOOLS
    from researchkit.tools import TOOLS as RESEARCH_TOOLS
    ctx, human_id = case
    establish(ctx, human_id)
    combined = ResearchPlanningTurn(ctx.app, ctx.session_id, human_id)
    combined.research = SimpleNamespace(context=lambda **kwargs: "Existing research context", feedback=lambda: "Original feedback",
                                       present=lambda text, status: f"Original {status}: {text}",
                                       delivery_state=lambda: "clean")
    assert combined.context().startswith("Existing research context\n\n## " + TITLE)
    assert combined.feedback() == "Original feedback"
    assert combined.present("answer", "stopped") == "Original stopped: answer"
    # Without it the loop took v38's clean delivery for none and told the agent to keep working.
    assert combined.delivery_state() == "clean"
    assert [tool.name for tool in COMBINED_TOOLS] == [tool.name for tool in [*RESEARCH_TOOLS, *TOOLS]]
    plain = PlanningTurn(ctx.app, ctx.session_id, human_id)
    assert plain.feedback() is None and plain.present("answer", "completed") == "answer"
