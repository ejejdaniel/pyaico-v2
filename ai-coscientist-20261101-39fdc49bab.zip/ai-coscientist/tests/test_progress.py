"""The host's count of model calls since the work last made progress it can see (opencode/progress.py); no
model is run."""

import os

import pytest

from opencode import progress
from opencode.app import App
from opencode.config import validate_config
from opencode.store import Store


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    (project / "src").mkdir(parents=True)
    (project / "src" / "reflect.py").write_text("def hit(): pass\n", encoding="utf-8")
    store = Store(tmp_path / "session.db")
    app = App(project, store=store, config={"progress": {"stall_after": 3}}, auto_approve=True)
    yield app, project
    store.close()


def step(app, session, name="bash", arguments=None, reply="ok", **metadata):
    """One model call with one tool call and its reply; returns the call's saved time."""
    call = f"call_{len(app.store.messages(session))}"
    message = app.store.add_message(session, "assistant", {"content": "", "tool_calls": [
        {"id": call, "name": name, "arguments": arguments or {"command": "python - <<EOF\nprint(1)\nEOF"}}]})
    app.store.add_message(session, "tool", {"tool_call_id": call, "name": name, "content": reply,
                                            "metadata": metadata})
    return message["created"]


def touch(path, when):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text("x", encoding="utf-8")
    os.utime(path, (when, when))


def test_calls_are_counted_from_the_last_saved_change_in_the_project(case):
    app, project = case
    session = app.create_session()["id"]
    app.store.add_message(session, "user", {"content": "Find why no reflection hits a wall."})
    touch(project / "src" / "reflect.py", 1.0)
    times = [step(app, session) for _ in range(4)]
    assert progress.check(app.store, session, project)[0] == 4
    # A project file changed after the second call: two calls since.
    touch(project / "src" / "reflect.py", times[1] + 0.001)
    assert progress.check(app.store, session, project)[0] == 2
    # The framework's own folders, caches and environments are not the work.
    for skipped in (".opencode/history/x.json", ".git/index", "src/__pycache__/r.pyc", "venv/lib/x.py"):
        touch(project / skipped, times[3] + 1)
    (project / "venv" / "pyvenv.cfg").write_text("home = x", encoding="utf-8")
    os.utime(project / "venv" / "pyvenv.cfg", (times[3] + 1, times[3] + 1))
    assert progress.check(app.store, session, project)[0] == 2
    # A record or any other new project file is.
    touch(project / ".research" / "records" / "r1" / "record.json", times[3] + 0.001)
    assert progress.check(app.store, session, project)[0] == 0


def test_a_new_outside_source_is_progress_and_a_failed_fetch_is_not(case):
    app, project = case
    session = app.create_session()["id"]
    touch(project / "src" / "reflect.py", 1.0)
    step(app, session, "webfetch", {"url": "https://example.org/a"}, "Error: 403", error=True)
    step(app, session)
    assert progress.check(app.store, session, project, {"webfetch"})[0] == 2
    step(app, session, "webfetch", {"url": "https://example.org/b"}, "A table of absorption coefficients")
    step(app, session)
    assert progress.check(app.store, session, project, {"webfetch"})[0] == 1


def test_a_stall_is_reported_in_a_top_session_with_what_its_calls_named(case):
    app, project = case
    session = app.create_session()["id"]
    app.store.add_message(session, "user", {"content": "Design the room."})
    touch(project / "src" / "reflect.py", 1.0)
    step(app, session, "read", {"filePath": str(project / "src" / "reflect.py")})  # read for the first time
    step(app, session, "bash", {"command": "cd src && grep -n hit reflect.py"})
    step(app, session, "read", {"filePath": str(project / "src" / "reflect.py")})
    assert progress.stalled(app, session) == (0, "", [])  # two calls since: under the threshold of three
    app.store.add_message(session, "user", {"content": "Go on from where you stopped."})
    step(app, session, "bash", {"command": "cat > /tmp/dbg.py <<'EOF'\nprint(-0.25 <= 0)\nEOF"})
    count, text, stretch = progress.stalled(app, session)
    assert count == 3
    assert "the last 3 model calls made no progress the host can see" in text
    assert "no project file read that earlier calls had not named" in text
    assert "2 of them came before the latest human message" in text
    assert "Their tool calls: bash 2, read 1." in text
    assert "Project files they name most: src/reflect.py (2)." in text and len(stretch) == 3
    assert "apart from files they kept reworking" not in text  # reflect.py has not changed since
    assert "\n\n" not in text  # one host-facts section
    child = app.store.create_session(directory=str(project), agent="build", model=None, parent_id=session)["id"]
    for _ in range(4):
        step(app, child)
    assert progress.stalled(app, child) == (0, "", [])  # a subagent may be meant to read without saving


def test_rewriting_the_file_the_stall_keeps_naming_is_not_progress(case):
    # Acoustics round 2 (_r2c) rewrote the module it kept probing, once with a backup copy; each reset the count.
    app, project = case
    session = app.create_session()["id"]
    module = project / "src" / "reflect.py"
    touch(module, 1.0)
    probe = {"command": "cd src && python -c 'import reflect; print(reflect.hit())'"}  # named by its import
    times = [step(app, session, "bash", probe) for _ in range(4)]
    touch(module, times[3] + 0.001)  # rewritten after the fourth call
    touch(project / "src" / "reflect_orig.py", times[3] + 0.001)  # and a backup of it
    count, stretch, _, reworked = progress.check(app.store, session, project)
    # The first probe read reflect.py for the first time; the three after it went over it again.
    assert (count, reworked) == (3, {"src/reflect.py", "src/reflect_orig.py"})
    touch(project / "src" / "score.py", times[3] + 0.001)  # a new module of the work is progress
    assert progress.check(app.store, session, project)[0] == 0


def test_a_new_file_the_work_then_uses_is_progress(case):
    # _r2d wrote a test file at its 19th call and ran it; once named twice it was taken for reworking.
    app, project = case
    session = app.create_session()["id"]
    touch(project / "src" / "reflect.py", 1.0)
    for _ in range(3):
        step(app, session)
    test = project / "src" / "test_reflect.py"
    written = step(app, session, "write", {"filePath": str(test), "content": "..."})
    touch(test, written + 0.001)
    for _ in range(2):
        step(app, session, "bash", {"command": "cd src && python test_reflect.py"})
    count, _, _, reworked = progress.check(app.store, session, project)
    assert (count, reworked) == (2, set())  # the two runs after it, not the six calls since reflect.py


def test_reading_a_project_file_no_earlier_call_named_is_progress(case):
    # An investigation (Q1, Q2) saves little and moves on by reading; going over the same files again does not.
    app, project = case
    session = app.create_session()["id"]
    app.store.add_message(session, "user", {"content": "Find where the case went wrong."})
    notes = [project / "notes" / f"day{day}.md" for day in range(4)]
    for note in notes:
        touch(note, 1.0)
        step(app, session, "read", {"filePath": str(note)})
    assert progress.stalled(app, session) == (0, "", [])  # four calls, each reading a file for the first time
    for note in notes[:3]:
        step(app, session, "bash", {"command": f"grep -n cause {note}"})
    count, text, stretch = progress.stalled(app, session)
    assert (count, len(stretch)) == (3, 3) and "Their tool calls: bash 3." in text


def test_calls_after_a_moment_and_the_pause_threshold():
    stretch = [{"created": 1.0}, {"created": 2.0}, {"created": 3.0}]
    assert (progress.since(stretch, 0.0), progress.since(stretch, 2.0), progress.since(stretch, 3.0)) == (3, 1, 0)
    assert progress.pause_after({}) == progress.PAUSE_AFTER
    assert progress.pause_after({"progress": {"pause_after": 4}}) == 4
    with pytest.raises(ValueError, match="progress.pause_after must be a positive integer"):
        validate_config({"progress": {"pause_after": 0}})


def test_a_folder_too_large_to_be_a_workspace_is_not_counted(case, monkeypatch):
    app, project = case
    session = app.create_session()["id"]
    touch(project / "src" / "reflect.py", 1.0)
    for _ in range(4):
        step(app, session)
    assert progress.stalled(app, session)[0] == 4
    monkeypatch.setattr(progress, "MAX_FILES", 0)
    assert progress.stalled(app, session) == (0, "", [])


def test_the_threshold_is_a_positive_whole_number():
    assert progress.stall_after({}) == progress.STALL_AFTER
    assert progress.stall_after({"progress": {"stall_after": 5}}) == 5
    validate_config({"progress": {"stall_after": 5}})
    for bad in ({"stall_after": 0}, {"stall_after": True}, {"stall_after": "5"}):
        with pytest.raises(ValueError, match="progress.stall_after must be a positive integer"):
            validate_config({"progress": bad})
    with pytest.raises(ValueError, match="progress must be an object"):
        validate_config({"progress": []})
