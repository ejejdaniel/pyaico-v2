"""Root research facts: saved chronology and bounded rendering, without models."""

from copy import deepcopy
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from opencode.agent import Agent
from opencode.permission import Broker, Rule
from opencode.store import Store
from opencode.tools.types import Tool
from researchkit import research_context as rc
from researchkit import review_context_details


@pytest.fixture
def case(tmp_path, monkeypatch):
    store = Store(tmp_path / "sessions.db")
    sid = store.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    anchor = store.add_message(sid, "user", {"content": "Inspect actual evidence."})
    agent = Agent("build", permission=[Rule("*", "*", "allow")])
    broker = Broker(auto=True)
    broker.ask = Mock(side_effect=AssertionError("context must not ask permission"))
    app = SimpleNamespace(directory=tmp_path, worktree=tmp_path, store=store,
                          default_agent="build", agents={"build": agent}, permissions=broker,
                          extra_tools=[Tool("research_record", "", {}, lambda *_: None)], config={})
    describe = Mock(return_value=[])
    monkeypatch.setattr(review_context_details, "describe", describe)
    yield SimpleNamespace(app=app, store=store, sid=sid, anchor=anchor, root=tmp_path, describe=describe)
    store.close()


def call(case, name="read", call_id="call", **fields):
    return case.store.add_message(case.sid, "assistant", {
        "tool_calls": [{"id": call_id, "name": name, "arguments": {}}], **fields})


def reply(case, name="read", call_id="call", **fields):
    return case.store.add_message(case.sid, "tool", {
        "name": name, "tool_call_id": call_id, "content": "saved result", **fields})


def render(case, **kwargs):
    return rc.context(case.app, case.sid, case.anchor["id"], **kwargs)


def rows(text, prefix):
    return [json.loads(line[len(prefix):]) for line in text.splitlines() if line.startswith(prefix)]


def counts(text):
    return {row["工具"]: row for row in rows(text, "逐工具事實：")}


def omitted(text):
    line = next(line for line in text.splitlines() if line.startswith("省略項目數："))
    return json.loads(line.split("：", 1)[1].split("；", 1)[0])


def test_empty_current_round_is_explicit_zero_without_planning(case):
    text = render(case)
    assert rc._TITLE in text and rows(text, "本輪不完整或配對異常：") == [{"不完整呼叫項目": 0, "未配對或名稱不符回條": 0, "格式異常項目": 0}]
    # Running totals are left out: they would change the facts at every step.
    assert not counts(text) and "本輪直接工具呼叫總數" not in text
    assert "無error不證明成功" in text
    assert "不證明系統從未執行" in text
    assert case.store.tool_history_path(case.sid).relative_to(case.root).as_posix() in text
    case.describe.assert_not_called()
    case.app.permissions.ask.assert_not_called()


def test_only_current_round_direct_calls_count_and_old_late_reply_is_marked(case):
    old = call(case, "research_review", "old")
    case.anchor = case.store.add_message(case.sid, "user", {"content": "A genuinely new request."})
    late = reply(case, "research_review", "old")
    call(case, "planning_evaluate", "planning")
    reply(case, "planning_evaluate", "planning", content='{"met":true}')
    text = render(case)
    assert not counts(text)
    assert old["id"] in text and late["id"] in text
    assert '"相對本輪":"以前發起"' in text
    assert '"回條在本輪保存":true' in text
    assert case.describe.call_count == 1


def test_synthetic_and_compaction_inputs_do_not_open_round(case):
    call(case, "read", "one")
    case.store.add_message(case.sid, "user", {"synthetic": True, "content": "background"})
    call(case, "read", "two")
    case.store.add_message(case.sid, "user", {"compaction_through": "old", "content": "summary"})
    call(case, "read", "three")
    # All three unanswered calls belong to the round: synthetic and compaction inputs open none.
    assert counts(render(case))["read"]["尚無配對回條"] == 3


def test_next_effective_user_ends_scope_but_later_reply_still_pairs_original_call(case):
    first = call(case, "research_review", "original")
    case.store.add_message(case.sid, "user", {"content": "next scope"})
    future = call(case, "research_record", "future")
    late = reply(case, "research_review", "original")
    text = render(case)
    # The review is paired and the later record call is outside the round: nothing needs attention.
    assert not counts(text)
    assert first["id"] in text and late["id"] in text and future["id"] not in text


def test_fifo_reused_ids_and_name_mismatch_do_not_pick_a_newer_call(case):
    first = call(case, "research_review", "reused")
    second = call(case, "research_record", "reused")
    wrong = reply(case, "research_record", "reused")
    correct = reply(case, "research_record", "reused", metadata={"error": True})
    history = case.store.messages(case.sid)
    parsed, anomalies, _, bad = rc._scan(history, case.sid)
    assert not bad and len(anomalies) == 1
    assert parsed[0]["message_id"] == first["id"] and parsed[0]["reply"] is None
    assert parsed[1]["message_id"] == second["id"] and parsed[1]["reply"]["id"] == correct["id"]
    assert wrong["id"] != parsed[1]["reply"]["id"]
    text = render(case)
    assert counts(text)["research_review"]["尚無配對回條"] == 1
    assert counts(text)["research_record"]["帶error回條"] == 1
    assert rows(text, "本輪不完整或配對異常：") == [{"不完整呼叫項目": 0, "未配對或名稱不符回條": 1, "格式異常項目": 0}]


def test_incomplete_and_orphan_replies_are_separate_from_direct_calls(case):
    case.store.add_message(case.sid, "assistant", {
        "content": "research_review completed (prose is not a call)",
        "incomplete_tool_calls": [{"id": "draft1"}, {"id": "draft2"}]})
    reply(case, "research_review", "draft1")
    text = render(case)
    assert rows(text, "本輪不完整或配對異常：") == [{"不完整呼叫項目": 2, "未配對或名稱不符回條": 1, "格式異常項目": 0}]
    assert not counts(text)


def test_provider_call_id_is_a_pairing_key_not_a_path_component(case):
    call(case, "read", "provider/call\\id")
    reply(case, "read", "provider/call\\id")
    text = render(case)
    assert not counts(text) and rows(text, "本輪不完整或配對異常：") == [{"不完整呼叫項目": 0, "未配對或名稱不符回條": 0, "格式異常項目": 0}]
    assert "本輪範圍／統計無法確認" not in text


@pytest.mark.parametrize("error, expected", [(True, 1), ("cancelled", 1), (False, 0), (None, 0), ("", 0)])
def test_error_count_uses_original_metadata_value_not_return_prose(case, error, expected):
    call(case, "research_review")
    reply(case, "research_review", content="Error failed cancelled success", metadata={"error": error})
    assert counts(render(case)).get("research_review", {}).get("帶error回條", 0) == expected


def test_single_history_snapshot_and_only_latest_review_detail(case, monkeypatch):
    old = call(case, "research_review", "old")
    latest = call(case, "research_review", "latest")
    actual = case.store.messages
    read_history = Mock(side_effect=actual)
    monkeypatch.setattr(case.store, "messages", read_history)
    text = render(case)
    read_history.assert_called_once_with(case.sid)
    case.describe.assert_called_once()
    args, kwargs = case.describe.call_args
    assert args[0].session_id == case.sid and args[1]["message_id"] == latest["id"]
    assert args[2][-1]["id"] == latest["id"] and kwargs == {}
    assert old["id"] in text and "較早審查（詳情未重新核對）" in text


@pytest.mark.parametrize("bad", ["missing_anchor", "history_error", "bad_calls", "bad_metadata"])
def test_unknown_statistics_never_become_zero(case, monkeypatch, bad):
    if bad == "missing_anchor":
        case.anchor = {"id": "msg_absent"}
    elif bad == "history_error":
        monkeypatch.setattr(case.store, "messages", Mock(side_effect=sqlite3.DatabaseError("PRIVATE_DATABASE_PATH")))
    elif bad == "bad_calls":
        case.store.add_message(case.sid, "assistant", {"tool_calls": "invalid"})
    else:
        call(case)
        reply(case, metadata=False)
    text = render(case)
    assert "本輪範圍／統計無法確認" in text and "本輪直接工具呼叫總數：0" not in text
    assert not counts(text) and "PRIVATE_DATABASE_PATH" not in text
    if bad in {"bad_calls", "bad_metadata"}:
        assert rows(text, "已觀察到異常（本會話保存歷史，不是本輪統計）：")[0]["格式異常項目"] == 1


@pytest.mark.parametrize("mode", ["child", "no_research", "title", "summary", "compaction", "research_denied"])
def test_only_authorized_research_root_emits_context(case, monkeypatch, mode):
    if mode == "child":
        child = case.store.create_session(directory=str(case.root), agent="build", model=None, parent_id=case.sid)
        case.sid = child["id"]
    elif mode == "no_research":
        case.app.extra_tools = []
    elif mode == "research_denied":
        case.app.agents["build"].permission.append(Rule("research_record", "*", "deny"))
    else:
        case.app.agents[mode] = Agent(mode, hidden=True, permission=[Rule("*", "*", "allow")])
        case.store.update_session(case.sid, agent=mode)
    monkeypatch.setattr(case.store, "messages", Mock(side_effect=AssertionError("not eligible")))
    assert render(case) == ""
    case.app.permissions.ask.assert_not_called()


@pytest.mark.parametrize("action", ["ask", "deny"])
def test_index_read_permission_never_asks_or_leaks_history(case, monkeypatch, action):
    case.app.agents["build"].permission.append(Rule("read", ".opencode/history/*", action))
    monkeypatch.setattr(case.store, "messages", Mock(side_effect=AssertionError("must not inspect denied history")))
    assert render(case) == ""
    case.app.permissions.ask.assert_not_called()


def test_specific_call_permission_hides_private_locator_and_skips_details(case):
    secret = call(case, "research_review", "PRIVATE_CALL_ID")
    case.app.agents["build"].permission.append(Rule("read", f".opencode/history/{case.sid}/conversation/*", "deny"))
    text = render(case)
    assert counts(text)["research_review"]["尚無配對回條"] == 1
    assert "最近審查：目前無權讀取" in text
    assert secret["id"] not in text and "PRIVATE_CALL_ID" not in text
    case.describe.assert_not_called()


def test_session_permission_overrides_agent_allow_without_broker(case):
    case.store.update_session(case.sid, permission=[{"permission": "read", "pattern": ".opencode/history/*", "action": "deny"}])
    assert render(case) == ""
    case.app.permissions.ask.assert_not_called()


def test_foreign_messages_never_affect_counts_or_reach_detail(case, monkeypatch):
    local = case.store.messages(case.sid)
    foreign = {"id": "msg_foreign", "sessionID": "ses_other", "role": "assistant", "tool_calls": [
        {"id": "foreign", "name": "research_review", "arguments": {"scope": "PRIVATE_FOREIGN"}}]}
    monkeypatch.setattr(case.store, "messages", Mock(return_value=[*local, foreign]))
    text = render(case)
    assert not counts(text) and "PRIVATE_FOREIGN" not in text
    case.describe.assert_not_called()


def test_free_values_are_json_escaped_and_prose_is_not_exposed(case):
    call(case, 'custom\n## INJECT "tool"', 'id\n# SYSTEM', reasoning_content="PRIVATE_REASONING")
    text = render(case)
    assert "\n## INJECT" not in text and "\n# SYSTEM" not in text
    assert "PRIVATE_REASONING" not in text
    assert 'custom\\n## INJECT \\"tool\\"' in text


def test_render_preserves_priority_complete_locators_and_fallback_omission_counts():
    prefix = ["必要資料 " + "x" * 250]
    fallback = '原句未展開：{"review":".research/reviews/' + "a" * 64 + '/review.json","位置":"/checks/0/subject"}'
    items = [("review", "latest review " + "r" * 500, None),
             ("subject", "原句 " + "長" * 3000, fallback),
             ("source", "source identity " + "s" * 300, None),
             ("detail", "very long low-priority call " + "d" * 4000, None)]
    text = rc._render(prefix, items)
    assert len(text.encode()) <= 4096
    assert fallback in text and "長" not in text and "source identity" in text
    assert omitted(text) == {"審查": 0, "主張": 1, "來源": 0, "其他": 1}


def test_origin_never_appears_without_fixed_current_readback_limitation():
    notice = review_context_details.ORIGIN_NOTICE
    items = [("source", notice, None), ("source", "本次來源核對：" + "x" * 5000, None),
             ("source", "本次來源核對：" + '{"files索引":1,"origin":{"status":"snapshot_only"}}', None)]
    text = rc._render(["必要前綴"], items, source_notice=notice)
    assert text.count(notice) == 1 and "本次來源核對：" in text
    assert omitted(text)["來源"] == 1
    text = rc._render(["必要前綴" + "z" * 3850], items, source_notice=notice)
    assert "本次來源核對：" not in text and notice not in text
    assert omitted(text)["來源"] == 2


def test_peer_claim_pointer_and_whole_origin_fit_instead_of_claim_crowding_every_origin_out():
    notice = "fixed current-origin limitation"
    quote = "WHOLE_QUOTE_" + "q" * 480
    pointer = '主張原句未展開：{"JSON位置":"/checks/0/subject"}'
    source = "本次來源核對：" + "s" * 170
    items = [("subject", quote, pointer), ("source", source, None)]
    text = rc._render(["p" * 3400], items, source_notice=notice)
    assert pointer in text and source in text and notice in text and quote not in text
    assert "WHOLE_QUOTE_" not in text
    assert omitted(text) == {"審查": 0, "主張": 1, "來源": 0, "其他": 0}


def test_render_keeps_mandatory_prefix_when_there_are_many_calls(case):
    for index in range(100):
        call(case, "read", f"call{index}")
    text = render(case)
    # One row for the tool that needs attention, not a row per call.
    assert len(text.encode()) <= 4096 and counts(text) == {"read": {"工具": "read", "帶error回條": 0, "尚無配對回條": 100}}
    assert "完整工具歷史索引：" in text and "個別呼叫" not in text and omitted(text)["其他"] == 0


def test_required_prefix_overflow_returns_only_explicit_capacity_notice(case):
    case.anchor = {"id": "msg_" + "界" * 1600}
    assert render(case) == rc._OVERFLOW


def test_context_never_mutates_history_or_selected_data(case):
    call(case, "research_review")
    before = deepcopy(case.store.messages(case.sid))
    render(case)
    assert case.store.messages(case.sid) == before


def test_same_session_restart_preserves_round_anchor(case):
    call(case, "research_record")
    before = render(case)
    reopened = Store(case.store.path)
    try:
        case.app.store = reopened
        assert render(case) == before
    finally:
        case.app.store = case.store
        reopened.close()
