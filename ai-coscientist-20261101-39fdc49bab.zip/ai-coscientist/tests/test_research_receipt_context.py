"""Offline native-receipt handoff readback, without scientific adjudication."""

from copy import deepcopy
import json
from pathlib import Path
from unittest.mock import Mock

import pytest

from opencode.permission import Rule
from opencode.provider import Completion
from opencode.tools.types import Tool
from researchkit import records, reviewer
from researchkit import review_context_details as details
from researchkit.research_context import _scan
from review_case import case, invocation_key, offline


def _begin(case, *, ids=True):
    native_call = {"id": "calculation-call", "name": "bash", "arguments": {"command": "saved calculation"}}
    case.messages.add_message(case.ctx.session_id, "assistant", {"tool_calls": [native_call]})
    case.native_reply = case.messages.add_message(case.ctx.session_id, "tool", {
        "name": "bash", "tool_call_id": native_call["id"], "content": "Native observation: 3.25\n",
        "metadata": {"exit": 0, "truncated": False}})
    arguments = deepcopy(case.args)
    if ids:
        arguments["tool_call_ids"] = [native_call["id"]]
    call = {"id": case.ctx.call_id, "name": "research_review", "arguments": arguments}
    owner = case.messages.add_message(case.ctx.session_id, "assistant", {"tool_calls": [call]})
    case.ctx.message_id = owner["id"]
    key = invocation_key(case.ctx.session_id, owner["id"], case.ctx.call_id)
    case.initial = case.root / ".research/review-runs" / key / "initial"
    case.resolved_path = case.initial.parent / "resolved-arguments.json"
    case.original = arguments
    if ids:
        case.model_value["checks"][0]["evidence"] = [{"file_id": "F4", "start_line": 1, "end_line": 1}]
        case.model.return_value = Completion(text=json.dumps(case.model_value), finish_reason="stop")
    return arguments


def _execute(case):
    return reviewer.execute(case.original, case.ctx)


def _reply(case, content, *, error=False):
    case.messages.add_message(case.ctx.session_id, "tool", {
        "name": "research_review", "tool_call_id": case.ctx.call_id, "content": content,
        "metadata": {"truncated": False, **({"error": True} if error else {})}})


def _read(case, monkeypatch):
    history = case.messages.messages(case.ctx.session_id)
    calls, _, _, _ = _scan(history, case.ctx.session_id)
    call = next(item for item in calls if item["call"]["name"] == "research_review")
    case.model.reset_mock()
    case.model.side_effect = AssertionError("Readback must not call a model")
    case.ctx.app.permissions.ask = Mock(side_effect=AssertionError("Readback must not ask the Broker"))
    with monkeypatch.context() as local:
        local.setattr(case.messages, "messages", Mock(side_effect=AssertionError("Reuse the history snapshot")))
        result = "\n".join(item[1] for item in details.describe(
            case.ctx, call, history))
    case.model.assert_not_called()
    case.ctx.app.permissions.ask.assert_not_called()
    return result


def test_nonempty_receipts_use_resolved_selection_and_wrapped_return(case, monkeypatch):
    original = deepcopy(_begin(case))
    output = json.loads(_execute(case).output)
    _reply(case, json.dumps(output))
    assert json.loads((case.initial / "arguments.json").read_bytes()) == original
    resolved = json.loads(case.resolved_path.read_bytes())
    assert "tool_call_ids" not in resolved
    assert resolved["files"][:-1] == original["files"]
    assert resolved["files"][-1]["record_ref"] == output["receipt_record"]["record_path"]
    actual = _read(case, monkeypatch)
    assert '"resolved-arguments.json":"可讀回核對"' in actual
    assert '"初審三檔":"可讀回核對"' in actual
    assert "審查工具保存返回正文：可讀回核對" in actual
    assert '"JSON位置":"/review/checks/0/subject"' in actual
    assert '"status":"tool_match"' in actual
    assert details.ORIGIN_NOTICE in actual and '"decision"' not in actual
def test_root_summary_consumes_new_handoff_with_existing_capacity(case, monkeypatch):
    from researchkit.research_context import context

    _begin(case)
    output = json.loads(_execute(case).output)
    _reply(case, json.dumps(output))
    app = case.ctx.app
    app.directory = app.worktree = case.root
    app.default_agent = "build"
    app.agents = {"build": case.ctx.agent}
    app.extra_tools = [Tool("research_record", "", {}, lambda *_: None)]
    app.config = {}
    app.permissions.ask = Mock(side_effect=AssertionError("Context must not ask the Broker"))
    messages = Mock(wraps=case.messages.messages)
    monkeypatch.setattr(case.messages, "messages", messages)
    actual = context(app, case.ctx.session_id, case.human["id"])
    assert len(actual.encode()) <= 4096
    assert "與原生返回相符的主張所在檔" in actual
    assert "本次來源核對：" in actual and details.ORIGIN_NOTICE in actual
    assert '"decision"' not in actual
    assert messages.call_count == 1
    app.permissions.ask.assert_not_called()


def test_second_stage_failure_preserves_receipt_selection_and_initial_only(case, monkeypatch):
    _begin(case)
    case.model.side_effect = [Completion(text=json.dumps(case.model_value), finish_reason="stop"),
                              ValueError("Injected second-stage failure")]
    with pytest.raises(ValueError, match="Injected second-stage failure") as failure:
        _execute(case)
    _reply(case, str(failure.value), error=True)
    actual = _read(case, monkeypatch)
    assert '"resolved-arguments.json":"可讀回核對"' in actual
    assert '"初審三檔":"可讀回核對"' in actual
    assert "初審保存的（不代表複核完成）主張所在檔" in actual
    assert "審查工具保存返回正文：可讀回核對" not in actual
    assert '"status":"tool_match"' in actual
def test_preflight_failure_keeps_sidecar_without_claiming_selected_input_valid(case, monkeypatch):
    _begin(case)
    case.original["required_subjects"][0]["quote"] = "This quotation is absent."
    case.messages.update_message(case.ctx.session_id, case.ctx.message_id, tool_calls=[{
        "id": case.ctx.call_id, "name": "research_review", "arguments": case.original}])
    with pytest.raises(ValueError):
        _execute(case)
    assert case.resolved_path.is_file()
    actual = _read(case, monkeypatch)
    assert '"resolved-arguments.json":"可讀回核對"' in actual
    assert "明選快照：內容不符" in actual
    assert "可讀回核對的主張" not in actual and '"status":"tool_match"' not in actual
    assert not (case.initial / "review.json").exists()


@pytest.mark.parametrize("damage", ["scope", "commission", "extra_file", "receipt_record", "receipt_type", "missing_wrapper"])
def test_tampered_resolved_or_returned_receipts_never_validate_by_existence(case, monkeypatch, damage):
    _begin(case)
    output = json.loads(_execute(case).output)
    if damage in {"scope", "commission", "extra_file"}:
        resolved = json.loads(case.resolved_path.read_bytes())
        if damage == "scope":
            resolved["scope"] = "Substituted scope"
        elif damage == "commission":
            resolved["commission_files"] = []
        else:
            resolved["files"].append({"record_ref": output["receipt_record"]["record_path"],
                                      "source_path": output["receipt_record"]["files"][1]["source_path"]})
        case.resolved_path.write_bytes((details._q(resolved) + "\n").encode())
    elif damage == "receipt_record":
        output["receipt_record"]["title"] = "An inconsistent receipt"
    elif damage == "receipt_type":
        entry = output["receipt_record"]["files"][0]
        entry["bytes"] = float(entry["bytes"])
    else:
        output = output["review"]
    _reply(case, json.dumps(output))
    actual = _read(case, monkeypatch)
    assert "審查工具保存返回正文：可讀回核對" not in actual
    if damage in {"scope", "commission", "extra_file"}:
        assert '"resolved-arguments.json":"內容不符"' in actual
        assert '"status":"tool_match"' not in actual
@pytest.mark.parametrize("ids", [None, []])
def test_old_or_empty_mode_keeps_original_return_and_ignores_unrelated_sidecar(case, monkeypatch, ids):
    _begin(case, ids=False)
    if ids is not None:
        case.original["tool_call_ids"] = ids
        case.messages.update_message(case.ctx.session_id, case.ctx.message_id, tool_calls=[{
            "id": case.ctx.call_id, "name": "research_review", "arguments": case.original}])
    output = json.loads(_execute(case).output)
    _reply(case, json.dumps(output))
    case.resolved_path.write_bytes(b"unrelated malformed sidecar")
    actual = _read(case, monkeypatch)
    assert "審查工具保存返回正文：可讀回核對" in actual
    assert "resolved-arguments.json" not in actual
    assert "receipt_record" not in output
@pytest.mark.parametrize("denied", ["sidecar", "native_json", "native_text"])
def test_receipt_readback_respects_current_permission_without_broker(case, monkeypatch, denied):
    _begin(case)
    output = json.loads(_execute(case).output)
    _reply(case, json.dumps(output))
    pattern = ".research/review-runs/*/resolved-arguments.json"
    if denied != "sidecar":
        suffix = ".json" if denied == "native_json" else ".txt"
        pattern = f".opencode/history/{case.ctx.session_id}/tools/{case.native_reply['id']}{suffix}"
    case.ctx.agent.permission.append(Rule("read", pattern, "deny"))
    actual = _read(case, monkeypatch)
    assert '"resolved-arguments.json":"目前無權讀取"' in actual
    assert '"status":"tool_match"' not in actual
