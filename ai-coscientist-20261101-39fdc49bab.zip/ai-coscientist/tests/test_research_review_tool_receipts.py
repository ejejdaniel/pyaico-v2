"""Offline receipt handoff boundaries; scripted outputs do not prove science."""

from copy import deepcopy
import json
from pathlib import Path
import threading
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import jsonschema
import pytest

from opencode.agent import Agent
from opencode.permission import Broker, PermissionDenied, Rule
from opencode.provider import Completion
from opencode.store import Store
from researchkit import records, reviewer, tool_receipts
from review_case import invocation_key
from researchkit.source_provenance import NativeSources


@pytest.fixture
def case(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Receipt handoff tests must not contact a real transport")
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", forbidden)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", forbidden)
    store = Store(tmp_path / "session.db")
    sid = store.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    human = store.add_message(sid, "user", {"content": "Assess the selected claim and actual execution."})
    ctx = SimpleNamespace(directory=tmp_path, worktree=tmp_path, session_id=sid,
                          message_id="msg_review", call_id="call_review", abort=threading.Event(),
                          agent=Agent("build", permission=[Rule("*", "*", "allow")]),
                          app=SimpleNamespace(store=store, permissions=Broker(auto=True), extra_tools=[]))
    replies = {}
    for call_id in ("call-a", " call-b "):
        store.add_message(sid, "assistant", {"tool_calls": [
            {"id": call_id, "name": "bash", "arguments": {"command": "saved command", "timeout": 2000}}]})
        replies[call_id] = store.add_message(sid, "tool", {
            "name": "bash", "tool_call_id": call_id, "content": f"Stored reply for {call_id}\n",
            "metadata": {"exit": 1, "truncated": True, "error": "saved failure", "outputPath": "DO_NOT_READ"}})
    (tmp_path / "report.txt").write_text("A selected claim.\n", encoding="utf-8")
    record = records.publish(tmp_path, kind="notes", title="Report", files=["report.txt"], depends_on=[])
    loc = {"record_ref": record["record_path"], "source_path": "report.txt"}
    args = {"scope": "Assess this claim.", "reviewed_refs": [record["record_path"]], "files": [loc],
            "tool_call_ids": [" call-b ", "call-a"], "commission_files": [deepcopy(loc)],
            "required_subjects": [{**loc, "quote": "A selected claim."}]}
    answer = {"checks": [{"subject": {"required_subject": 1},
                           "evidence": [{"file_id": "F2", "start_line": 1, "end_line": 2}],
                           "decision": "unassessed", "reason": "Scripted handoff test only."}]}
    model = Mock(return_value=Completion(text=json.dumps(answer), finish_reason="stop"))
    monkeypatch.setattr(reviewer, "complete_once", model)
    key = invocation_key(sid, ctx.message_id, ctx.call_id)
    yield SimpleNamespace(root=tmp_path, ctx=ctx, store=store, sid=sid, replies=replies,
                          args=args, model=model, answer=answer, key=key,
                          run=tmp_path / ".research/review-runs" / key)
    store.close()


def test_two_stages_share_one_selection_and_keep_original_arguments(case, monkeypatch):
    original = deepcopy(case.args)
    messages = Mock(wraps=case.store.messages)
    monkeypatch.setattr(case.store, "messages", messages)
    inputs = Mock(wraps=reviewer._input)
    monkeypatch.setattr(reviewer, "_input", inputs)
    published = Mock(wraps=records.publish)
    monkeypatch.setattr(records, "publish", published)
    result = json.loads(reviewer.execute(case.args, case.ctx).output)
    assert list(result) == ["receipt_record", "review"]
    assert set(result["review"]) == {"reviewed_refs", "checks"}
    assert case.model.call_count == 2 and messages.call_count == 1 and inputs.call_count == 1
    assert published.call_count == 1
    receipt = result["receipt_record"]
    assert receipt["kind"] == "source" and receipt["title"] == "Selected tool receipts" and receipt["depends_on"] == []
    assert len(receipt["files"]) == 4
    for index, call_id in enumerate(original["tool_call_ids"]):
        pair = receipt["files"][2 * index:2 * index + 2]
        assert [Path(item["source_path"]).suffix for item in pair] == [".json", ".txt"]
        value = json.loads(Path(pair[0]["snapshot"]).read_bytes())
        assert value[0]["tool_calls"][0]["id"] == call_id
        assert value[1] == case.replies[call_id]
        assert Path(pair[1]["snapshot"]).read_bytes() == case.replies[call_id]["content"].encode()
    saved = json.loads((case.run / "resolved-arguments.json").read_bytes())
    assert saved["files"][:1] == original["files"]
    assert [item["source_path"] for item in saved["files"][1:]] == [i["source_path"] for i in receipt["files"][::2]]
    assert (case.run / "initial/arguments.json").read_bytes() == tool_receipts.compact(original)
    assert set(json.loads((case.run / "initial/review.json").read_bytes())) == {"reviewed_refs", "checks"}
    requests = [call.kwargs["messages"][0]["content"] for call in case.model.call_args_list]
    assert requests[1].startswith(requests[0])
    assert requests[0].count('"status": "tool_match"') == 2
    assert all(item["source_path"] not in requests[0] for item in receipt["files"][1::2])
    assert case.args == original
    # Later readback must use the caller's supplied history and I/O, without a
    # broker request or a second publication.
    history = case.store.messages(case.sid)
    case.ctx.app.permissions.ask = Mock(side_effect=AssertionError("No broker during scoped audit"))
    resolved, actual = tool_receipts.verify_saved(case.ctx, original, case.key, history=history,
        read_bytes=lambda ref: (case.root / ref).read_bytes(), receipt_record=receipt)
    assert resolved == saved and actual == receipt and published.call_count == 1


@pytest.mark.parametrize("ids", [None, "call-a", [None], [1], [""], ["  "], ["call-a", "call-a"],
                                 ["absent"], ["call-b"]])
def test_bad_ids_fail_before_any_save_or_model(case, ids, monkeypatch):
    case.args["tool_call_ids"] = ids
    publish = Mock(wraps=records.publish)
    monkeypatch.setattr(records, "publish", publish)
    with pytest.raises((ValueError, jsonschema.ValidationError)):
        reviewer.execute(case.args, case.ctx)
    assert not case.run.exists()
    publish.assert_not_called()
    case.model.assert_not_called()


@pytest.mark.parametrize("bad", ["duplicate_call", "duplicate_reply", "orphan", "missing", "name", "session"])
def test_only_unique_complete_current_session_pair_is_accepted(case, bad, monkeypatch):
    history = case.store.messages(case.sid)
    owner = next(message for message in history if message.get("tool_calls")
                 and message["tool_calls"][0]["id"] == "call-a")
    reply = next(message for message in history if message.get("tool_call_id") == "call-a")
    if bad == "duplicate_call":
        history.append({**deepcopy(owner), "id": "msg_duplicate"})
    elif bad == "duplicate_reply":
        history.append({**deepcopy(reply), "id": "msg_duplicate"})
    elif bad == "orphan":
        history.remove(owner)
        history.append(owner)
    elif bad == "missing":
        history.remove(reply)
    elif bad == "name":
        reply["name"] = "read"
    elif bad == "session":
        reply["sessionID"] = "different-session"
    monkeypatch.setattr(case.store, "messages", Mock(return_value=history))
    with pytest.raises(ValueError):
        reviewer.execute(case.args, case.ctx)
    assert not case.run.exists()
    assert len(records.inventory(case.root)) == 1
    case.model.assert_not_called()


@pytest.mark.parametrize("permission,pattern", [("read", ".opencode/history/*"),
                                               ("edit", ".research/records/*"),
                                               ("read", ".research/review-runs/*/resolved-arguments.json")])
def test_source_and_save_permissions_remain_authoritative(case, permission, pattern):
    case.ctx.agent.permission.append(Rule(permission, pattern, "deny"))
    with pytest.raises(PermissionDenied):
        reviewer.execute(case.args, case.ctx)
    case.model.assert_not_called()
    assert len(records.inventory(case.root)) == 1


@pytest.mark.parametrize("failure", ["first_model", "second_model", "capacity", "bad_original_file"])
def test_failure_keeps_frozen_receipt_and_sidecar_without_rerun(case, failure):
    if failure == "first_model":
        case.model.side_effect = ValueError("scripted failure")
    elif failure == "second_model":
        case.model.side_effect = [case.model.return_value, ValueError("scripted failure")]
    elif failure == "capacity":
        case.args["scope"] = "x" * reviewer.MAX_BYTES
    else:
        (case.root / "bad.txt").write_bytes("bad selected encoding".encode("utf-16"))
        record = records.publish(case.root, kind="source", title="Bad encoding", files=["bad.txt"], depends_on=[])
        case.args["files"].append({"record_ref": record["record_path"], "source_path": "bad.txt"})
    with pytest.raises(ValueError) as error:
        reviewer.execute(case.args, case.ctx)
    resolved, receipt = tool_receipts.verify_saved(case.ctx, case.args, case.key)
    assert receipt["record_path"] in str(error.value).replace("\\", "/")
    assert "resolved-arguments.json" in str(error.value)
    assert resolved["files"][:len(case.args["files"])] == case.args["files"]
    assert case.model.call_count == {"first_model": 1, "second_model": 2, "capacity": 0, "bad_original_file": 0}[failure]
    if failure == "second_model":
        assert (case.run / "initial/review.json").is_file()
    case.model.reset_mock()
    with pytest.raises(FileExistsError):
        reviewer.execute(case.args, case.ctx)
    case.model.assert_not_called()


def test_duplicate_expanded_locator_preserves_first_position(case):
    selected = NativeSources(case.ctx).selected_receipts(case.args["tool_call_ids"])
    receipt = tool_receipts.publish(case.ctx, selected)
    loc = {"record_ref": receipt["record_path"], "source_path": receipt["files"][0]["source_path"]}
    case.args["files"].insert(0, loc)
    prepared = reviewer.prepare(case.args, case.ctx)
    assert prepared["resolved"]["files"][0] == loc
    assert prepared["resolved"]["files"].count(loc) == 1
    assert len(prepared["resolved"]["files"]) == 3


def test_prepared_dispatch_is_single_use_even_after_first_model_failure(case):
    prepared = reviewer.prepare(case.args, case.ctx)
    case.model.side_effect = ValueError("first model failure")
    with pytest.raises(ValueError, match="first model failure"):
        reviewer.execute(case.args, case.ctx, prepared=prepared)
    with pytest.raises(FileExistsError, match="already dispatched"):
        reviewer.execute(case.args, case.ctx, prepared=prepared)
    assert case.model.call_count == 1


def test_prepared_inputs_keep_same_history_when_store_changes(case):
    prepared = reviewer.prepare(case.args, case.ctx)
    reply = case.replies["call-a"]
    case.store.update_message(case.sid, reply["id"], content="LATER_CHANGED_REPLY")
    reviewer.execute(case.args, case.ctx, prepared=prepared)
    assert case.model.call_count == 2
    for call in case.model.call_args_list:
        assert "LATER_CHANGED_REPLY" not in call.kwargs["messages"][0]["content"]


def test_readback_ignores_only_compacted_marker_without_rewriting_bytes(case):
    result = json.loads(reviewer.execute(case.args, case.ctx).output)
    receipt = result["receipt_record"]
    before = {item["snapshot"]: Path(item["snapshot"]).read_bytes() for item in receipt["files"]}
    reply = case.replies["call-a"]
    case.store.update_message(case.sid, reply["id"], metadata={**reply["metadata"], "compacted": 99})
    _, actual = tool_receipts.verify_saved(case.ctx, case.args, case.key, receipt_record=receipt)
    assert actual == receipt
    assert {path: Path(path).read_bytes() for path in before} == before
    case.store.update_message(case.sid, reply["id"], metadata={**reply["metadata"], "compacted": 99, "exit": 0})
    with pytest.raises(ValueError, match="current-session identity"):
        tool_receipts.verify_saved(case.ctx, case.args, case.key, receipt_record=receipt)


def test_changed_sidecar_prevents_model_before_dispatch(case):
    prepared = reviewer.prepare(case.args, case.ctx)
    (case.run / "resolved-arguments.json").write_bytes(b"{}\n")
    with pytest.raises(ValueError, match="handoff bytes changed"):
        reviewer.execute(case.args, case.ctx, prepared=prepared)
    case.model.assert_not_called()


@pytest.mark.parametrize("tamper", ["scope", "commission", "subject", "files", "returned", "snapshot"])
def test_readonly_verifier_rejects_unapproved_delta_and_changed_bytes(case, tamper):
    result = json.loads(reviewer.execute(case.args, case.ctx).output)
    path = case.run / "resolved-arguments.json"
    resolved = json.loads(path.read_bytes())
    if tamper == "scope":
        resolved["scope"] = "Replacement scope"
    elif tamper == "commission":
        resolved["commission_files"] = []
    elif tamper == "subject":
        resolved["required_subjects"][0]["quote"] = "Replacement claim"
    elif tamper == "files":
        resolved["files"] = list(reversed(resolved["files"]))
    elif tamper == "returned":
        result["receipt_record"]["title"] = "Replacement title"
    else:
        Path(result["receipt_record"]["files"][1]["snapshot"]).write_bytes(b"replacement")
    path.write_bytes(tool_receipts.compact(resolved))
    with pytest.raises(ValueError):
        tool_receipts.verify_saved(case.ctx, case.args, case.key, receipt_record=result["receipt_record"])


@pytest.mark.parametrize("empty", [False, True])
def test_legacy_return_and_no_sidecar_for_omitted_or_empty_ids(case, empty):
    case.args["tool_call_ids"] = []
    if not empty:
        case.args.pop("tool_call_ids")
    case.answer["checks"][0]["evidence"] = []
    case.model.return_value = Completion(text=json.dumps(case.answer), finish_reason="stop")
    result = json.loads(reviewer.execute(case.args, case.ctx).output)
    assert set(result) == {"reviewed_refs", "checks"}
    assert not (case.run / "resolved-arguments.json").exists()
    assert len(records.inventory(case.root)) == 1


