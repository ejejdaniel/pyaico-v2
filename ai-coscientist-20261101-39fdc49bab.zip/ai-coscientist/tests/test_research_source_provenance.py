"""Native research source boundaries, using a real Store and no model calls."""

from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest

from opencode.permission import Broker, Rule
from opencode.store import Store
from researchkit import records
from researchkit.source_provenance import NativeSources, origin_notice
from researchkit.tools import _publish


@pytest.fixture
def case(tmp_path):
    store = Store(tmp_path / "session.db")
    sid = store.create_session(directory=str(tmp_path), agent="build", model=None)["id"]
    ctx = SimpleNamespace(directory=tmp_path, worktree=tmp_path, session_id=sid,
                          message_id="msg_current", agent=SimpleNamespace(permission=[Rule("*", "*", "allow")]),
                          app=SimpleNamespace(store=store, permissions=Broker(auto=True), extra_tools=[]))
    yield SimpleNamespace(root=tmp_path, store=store, sid=sid, ctx=ctx)
    store.close()


def exchange(case, name="bash", text="return\n", call_id="reused", **fields):
    call = case.store.add_message(case.sid, "assistant", {
        "reasoning_content": "PRIVATE_REASONING", "reasoning": "PRIVATE_REASONING_2",
        "tool_calls": [{"id": call_id, "name": name, "arguments": {"command": "actual command"}}]})
    reply = case.store.add_message(case.sid, "tool", {
        "name": name, "tool_call_id": call_id, "content": text, **fields})
    return call, reply


def selection(case, files, ref="record-a"):
    return {(ref, path.relative_to(case.root).as_posix()): data for path, data in files}


def publish(case, files):
    return json.loads(_publish({"kind": "notes", "title": "exact sources", "files": files}, case.ctx).output)


def frozen(record):
    return {item["source_path"]: Path(item["snapshot"]).read_bytes() for item in record["files"]}


@pytest.mark.parametrize("projection", ["missing", "changed"])
@pytest.mark.parametrize("suffix", [".json", ".txt"])
def test_direct_tool_selection_reconstructs_without_changing_projection(case, projection, suffix):
    call, reply = exchange(case, metadata={"truncated": True, "error": "cancelled"})
    path = case.root / ".opencode/history" / case.sid / "tools" / (reply["id"] + suffix)
    if projection == "changed":
        path.parent.mkdir(parents=True)
        path.write_bytes(b"changed projection")
    saved = publish(case, [str(path)])
    contents = frozen(saved)
    assert len(contents) == 2
    assert next(data for name, data in contents.items() if name.endswith(".txt")) == b"return\n"
    receipt = json.loads(next(data for name, data in contents.items() if name.endswith(".json")))
    assert receipt[0] == {"id": call["id"], "role": "assistant", "tool_calls": call["tool_calls"]}
    assert receipt[1] == reply
    assert "PRIVATE_REASONING" not in json.dumps(receipt)
    assert (path.read_bytes() == b"changed projection") if path.exists() else projection == "missing"
    assert set(records.read_record(case.root, saved["record_path"])) == {"kind", "title", "files", "depends_on"}


def test_inline_and_direct_external_source_preserve_same_full_output(case):
    full = case.root / "full-output.txt"
    full.write_bytes(b"complete output\nTAIL")
    _, reply = exchange(case, "websearch", "preview", metadata={"truncated": True, "outputPath": str(full)})
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    assert files == native.resolve_path(files[0][0]) == native.resolve_path(files[1][0])
    assert files[1][1] == full.read_bytes()
    assert "/sources/" in files[0][0].as_posix()
    selected = selection(case, files)
    origins = native.origins(selected)
    assert list(origins.values())[0]["status"] == "tool_match"
    assert list(origins.values())[1] == {"status": "snapshot_only", "content": "retained_text", "session_id": None,
        "message_id": None, "call_message_id": None, "tool_call_id": None, "tool_name": None, "truncated": True}
    # Frozen full text never becomes authenticated by comparing today's outputPath.
    full.write_bytes(b"later changed full output")
    assert NativeSources(case.ctx).origins(selected) == origins
    full.unlink()
    assert NativeSources(case.ctx).origins(selected) == origins
    with pytest.raises(FileNotFoundError):
        NativeSources(case.ctx).resolve_reference(reply["id"])


def test_truncated_text_equal_to_db_content_keeps_truncated_true(case):
    full = case.root / "full.txt"
    full.write_text("preview", encoding="utf-8")
    _, reply = exchange(case, "websearch", "preview", metadata={"truncated": True, "outputPath": str(full)})
    native = NativeSources(case.ctx)
    origin = list(native.origins(selection(case, native.resolve_reference(reply["id"]))).values())[1]
    assert origin["status"] == "tool_match" and origin["content"] == "stored_text" and origin["truncated"] is True


def test_explicit_source_path_does_not_require_historical_tool_still_registered(case):
    full = case.root / "full.txt"
    full.write_text("retained former provider reply", encoding="utf-8")
    _, reply = exchange(case, "removed_provider", "preview", metadata={"truncated": True, "outputPath": str(full)})
    path = case.root / ".opencode/sources" / case.sid / (reply["id"] + ".json")
    native = NativeSources(case.ctx)
    files = native.resolve_path(path)
    assert files[1][1] == full.read_bytes()
    origins = native.origins(selection(case, files))
    assert list(origins.values())[0]["status"] == "tool_match"
    assert list(origins.values())[0]["tool_name"] == "removed_provider"
    assert list(origins.values())[1]["content"] == "retained_text"


@pytest.mark.parametrize("state", [{"error": "aborted", "incomplete_tool_calls": ["pending"]},
                                  {"answer_review_role": "draft"}, {"synthetic": True},
                                  {"compaction_through": "msg_previous", "finish_reason": "stop"}])
def test_saved_conversation_preserves_states_without_reasoning(case, state):
    message = case.store.add_message(case.sid, "assistant", {"content": "working account", "reasoning": "PRIVATE",
                                                             "reasoning_content": "PRIVATE", **state})
    native = NativeSources(case.ctx)
    files = native.resolve_reference(message["id"])
    assert json.loads(files[0][1]) == {key: value for key, value in message.items() if key not in {"reasoning", "reasoning_content"}}
    origin = next(iter(native.origins(selection(case, files)).values()))
    assert origin["status"] == "message_match" and origin["tool_name"] is None


def test_current_assistant_fails_but_current_tool_receipt_can_be_frozen(case):
    call, reply = exchange(case)
    case.ctx.message_id = call["id"]
    with pytest.raises(ValueError, match="current assistant"):
        NativeSources(case.ctx).resolve_reference(call["id"])
    assert len(NativeSources(case.ctx).resolve_reference(reply["id"])) == 2


def test_user_is_host_saved_input_not_authentication_of_human_author(case):
    message = case.store.add_message(case.sid, "user", {"content": "delegated task", "synthetic": True})
    native = NativeSources(case.ctx)
    files = native.resolve_reference(message["id"])
    origin = next(iter(native.origins(selection(case, files)).values()))
    assert json.loads(files[0][1])["synthetic"] is True
    assert "not authenticated human" in origin_notice(files[0][0].relative_to(case.root).as_posix(), origin, case.sid)


def test_fifo_call_reuse_and_only_paired_call_are_preserved(case):
    first, reply1 = exchange(case, "bash", "first")
    second, reply2 = exchange(case, "read", "second")
    for call, reply in [(first, reply1), (second, reply2)]:
        receipt = json.loads(NativeSources(case.ctx).resolve_reference(reply["id"])[0][1])
        assert receipt[0]["id"] == call["id"]
        assert len(receipt[0]["tool_calls"]) == 1
        assert receipt[0]["tool_calls"][0]["name"] == reply["name"]


def test_fifo_does_not_choose_newer_same_id_call_by_tool_name(case):
    calls = [case.store.add_message(case.sid, "assistant", {"tool_calls": [
        {"id": "same-id", "name": name, "arguments": {"order": i}}]})
        for i, name in enumerate(["bash", "read"])]
    reply1 = case.store.add_message(case.sid, "tool", {"tool_call_id": "same-id", "name": "bash", "content": "first"})
    reply2 = case.store.add_message(case.sid, "tool", {"tool_call_id": "same-id", "name": "read", "content": "second"})
    for index, reply in enumerate([reply1, reply2]):
        receipt = json.loads(NativeSources(case.ctx).resolve_reference(reply["id"])[0][1])
        assert receipt[0]["id"] == calls[index]["id"]
    case.store.update_message(case.sid, reply1["id"], name="read")
    with pytest.raises(ValueError, match="tool name mismatch"):
        NativeSources(case.ctx).resolve_reference(reply1["id"])


def test_one_call_from_multi_tool_assistant_does_not_copy_unselected_call(case):
    call = case.store.add_message(case.sid, "assistant", {"tool_calls": [
        {"id": "selected", "name": "bash", "arguments": {"command": "selected"}},
        {"id": "unselected", "name": "read", "arguments": {"filePath": "PRIVATE_UNSELECTED"}}]})
    reply = case.store.add_message(case.sid, "tool", {"tool_call_id": "selected", "name": "bash", "content": "done"})
    files = NativeSources(case.ctx).resolve_reference(reply["id"])
    assert json.loads(files[0][1])[0]["tool_calls"] == [call["tool_calls"][0]]
    assert b"PRIVATE_UNSELECTED" not in files[0][1]


def test_text_mismatch_with_selected_nontruncated_receipt_fails(case):
    _, reply = exchange(case, metadata={"truncated": False})
    native = NativeSources(case.ctx)
    selected = selection(case, native.resolve_reference(reply["id"]))
    selected[next(key for key in selected if key[1].endswith(".txt"))] = b"fabricated return"
    with pytest.raises(ValueError, match="stored tool text bytes differ"):
        native.origins(selected)


@pytest.mark.parametrize("problem", ["missing", "orphan", "name", "conversation_tool", "tools_user", "current", "foreign"])
def test_invalid_explicit_native_publication_fails_before_record(case, problem):
    _, reply = exchange(case)
    mid, lane, sid = reply["id"], "tools", case.sid
    if problem == "missing":
        mid = "msg_missing"
    elif problem == "orphan":
        mid = case.store.add_message(case.sid, "tool", {"name": "bash", "content": "orphan"})["id"]
    elif problem == "name":
        case.store.update_message(case.sid, mid, name="read")
    elif problem == "conversation_tool":
        lane = "conversation"
    elif problem == "tools_user":
        mid = case.store.add_message(case.sid, "user", {"content": "input"})["id"]
    elif problem == "current":
        mid = case.store.add_message(case.sid, "assistant", {"id": case.ctx.message_id, "content": "draft"})["id"]
        lane = "conversation"
    elif problem == "foreign":
        sid = "ses_other"
    with pytest.raises(ValueError):
        publish(case, [f".opencode/history/{sid}/{lane}/{mid}.json"])
    assert records.inventory(case.root) == []


def test_inline_unknown_fails_while_other_code_links_and_fences_do_not_select(case):
    (case.root / "note.md").write_text("`msg_missing`", encoding="utf-8")
    with pytest.raises(ValueError, match="no message in current session"):
        publish(case, ["note.md"])
    (case.root / "note.md").write_text("`prefix msg_missing`\n[link](msg_missing)\n```\nmsg_missing\n```", encoding="utf-8")
    assert len(publish(case, ["note.md"])["files"]) == 1


@pytest.mark.parametrize("denied", ["json", "txt", "full"])
def test_each_paired_and_full_output_permission_is_checked(case, denied):
    full = case.root / "full.txt"
    full.write_text("full", encoding="utf-8")
    _, reply = exchange(case, "websearch", "preview", metadata={"truncated": True, "outputPath": str(full)})
    seen = []
    def permission(ctx, path, action):
        seen.append(path)
        if ((denied == "full" and path == full) or
                (denied != "full" and path.name == reply["id"] + "." + denied)):
            raise PermissionError("selected source denied")
    with patch("researchkit.source_provenance.ensure_access", side_effect=permission):
        with pytest.raises(PermissionError, match="selected source denied"):
            publish(case, [f".opencode/sources/{case.sid}/{reply['id']}.json"])
    assert seen and records.inventory(case.root) == []


def test_ordinary_and_foreign_materials_do_not_touch_store_or_receive_identity(case):
    case.ctx.app.store = Mock()
    case.ctx.app.store.messages.side_effect = AssertionError("must not read session")
    selected = {("a", "claims.txt"): b'{"role":"user","kind":"review","content":"verified"}',
                ("a", ".opencode/history/ses_other/tools/msg_old.json"): b"old frozen material"}
    origins = NativeSources(case.ctx).origins(selected)
    assert all(origin["status"] == "snapshot_only" and origin["session_id"] is None for origin in origins.values())
    assert "not checked across sessions" in origin_notice(next(reversed(selected))[1], next(reversed(origins.values())), case.sid)
    case.ctx.app.store.messages.assert_not_called()


def test_text_requires_same_record_explicit_json_and_does_not_add_sources(case):
    _, reply = exchange(case)
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    selected = selection(case, [files[1]])
    original = deepcopy(selected)
    assert next(iter(native.origins(selected).values()))["status"] == "snapshot_only"
    selected.update(selection(case, [files[0]], "different-record"))
    origins = native.origins(selected)
    assert origins[next(iter(original))]["status"] == "snapshot_only"
    selected.update(selection(case, [files[0]]))
    origins = native.origins(selected)
    assert origins[next(iter(original))]["content"] == "stored_text"
    assert len(origins) == len(selected) == 3


def test_json_formatting_and_only_compacted_metadata_are_ignored(case):
    _, reply = exchange(case, metadata={"truncated": False, "error": "cancelled"})
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    selected = selection(case, files)
    key = next(iter(selected))
    selected[key] = json.dumps(json.loads(selected[key]), sort_keys=True).encode()
    case.store.mark_tools_compacted(case.sid, [reply["id"]], 99)
    # mark_tools_compacted retains errors without adding a marker; explicitly
    # simulate a saved normal presentation marker while keeping the error.
    case.store.update_message(case.sid, reply["id"], metadata={"truncated": False, "error": "cancelled", "compacted": 99})
    origins = NativeSources(case.ctx).origins(selected)
    assert all(origin["status"] == "tool_match" for origin in origins.values())
    case.store.update_message(case.sid, reply["id"], metadata={"truncated": False, "error": "different", "compacted": 99})
    with pytest.raises(ValueError, match="metadata.error"):
        NativeSources(case.ctx).origins(selected)


@pytest.mark.parametrize("marker_in_snapshot", [False, True])
def test_compaction_can_add_metadata_container_but_no_other_field_is_ignored(case, marker_in_snapshot):
    _, reply = exchange(case)
    selected = selection(case, NativeSources(case.ctx).resolve_reference(reply["id"]))
    if marker_in_snapshot:
        key = next(key for key in selected if key[1].endswith(".json"))
        receipt = json.loads(selected[key])
        receipt[1]["metadata"] = {"compacted": 99}
        selected[key] = json.dumps(receipt).encode()
    else:
        case.store.mark_tools_compacted(case.sid, [reply["id"]], 99)
    assert all(origin["status"] == "tool_match" for origin in NativeSources(case.ctx).origins(selected).values())
    # An empty container is only equivalent to the other empty container after
    # removal of compacted; ordinary absent versus empty is never ignored.
    selected = selection(case, NativeSources(case.ctx).resolve_reference(reply["id"]))
    key = next(key for key in selected if key[1].endswith(".json"))
    receipt = json.loads(selected[key])
    receipt[1].pop("metadata", None)
    selected[key] = json.dumps(receipt).encode()
    case.store.update_message(case.sid, reply["id"], metadata={})
    with pytest.raises(ValueError, match="fields differ"):
        NativeSources(case.ctx).origins(selected)


@pytest.mark.parametrize("field, value", [("content", 0), ("content", False), ("content", []),
                                          ("content", {}), ("metadata", 0), ("metadata", False),
                                          ("metadata", []), ("metadata", "")])
def test_falsey_wrong_native_types_fail_instead_of_becoming_empty(case, field, value):
    _, reply = exchange(case)
    # Freeze the valid original first so review validation exercises the Store
    # producer boundary rather than merely mismatching the selected JSON.
    selected = selection(case, NativeSources(case.ctx).resolve_reference(reply["id"]))
    case.store.update_message(case.sid, reply["id"], **{field: value})
    expected = "content is not text" if field == "content" else "metadata is not an object"
    with pytest.raises(ValueError, match=expected):
        NativeSources(case.ctx).resolve_reference(reply["id"])
    with pytest.raises(ValueError, match=expected):
        NativeSources(case.ctx).origins(selected)


def test_null_native_content_and_metadata_keep_existing_empty_text_behavior(case):
    _, reply = exchange(case, text=None, metadata=None)
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    assert files[1][1] == b""
    saved_reply = json.loads(files[0][1])[1]
    assert saved_reply["content"] is None and saved_reply["metadata"] is None
    assert all(origin["status"] == "tool_match" and origin["truncated"] is None
               for origin in native.origins(selection(case, files)).values())


def test_text_only_does_not_read_store_even_when_receipt_is_unavailable(case):
    case.ctx.app.store = Mock()
    case.ctx.app.store.messages.side_effect = AssertionError("unselected receipt must not be read")
    path = f".opencode/history/{case.sid}/tools/msg_missing.txt"
    origin = next(iter(NativeSources(case.ctx).origins({("a", path): b"retained text"}).values()))
    assert origin["status"] == "snapshot_only" and origin["content"] == "file"
    case.ctx.app.store.messages.assert_not_called()


@pytest.mark.parametrize("path", ["conversation/msg_1.txt", "tools/msg_1.xml", "tools/msg_1.json/extra"])
def test_malformed_native_locator_cannot_downgrade_to_plain_file(case, path):
    source_path = f".opencode/history/{case.sid}/{path}"
    with pytest.raises(ValueError, match="Invalid native source locator"):
        NativeSources(case.ctx).origins({("a", source_path): b"ordinary content"})


@pytest.mark.parametrize("change", ["duplicate", "id", "session", "role", "call_owner", "name", "arguments", "content", "boolean_type"])
def test_native_json_mismatch_fails_with_locator_before_model(case, change):
    _, reply = exchange(case, metadata={"truncated": False})
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    selected = selection(case, files)
    key = next(iter(selected))
    data = json.loads(selected[key])
    if change == "duplicate":
        selected[key] = selected[key].replace(b'"role": "tool"', b'"role": "tool", "role": "tool"')
    else:
        if change == "id": data[1]["id"] = "msg_other"
        elif change == "session": data[1]["sessionID"] = "other"
        elif change == "role": data[1]["role"] = "user"
        elif change == "call_owner": data[0]["id"] = "msg_other"
        elif change == "name": data[0]["tool_calls"][0]["name"] = "read"
        elif change == "arguments": data[0]["tool_calls"][0]["arguments"]["command"] = "invented"
        elif change == "content": data[1]["content"] = "invented"
        elif change == "boolean_type": data[1]["metadata"]["truncated"] = 0
        selected[key] = json.dumps(data).encode()
    with pytest.raises(ValueError, match="Native source .opencode/history"):
        native.origins(selected)


def test_old_tool_without_truncated_has_unknown_completeness(case):
    _, reply = exchange(case, text="", error="cancelled")
    native = NativeSources(case.ctx)
    files = native.resolve_reference(reply["id"])
    origins = native.origins(selection(case, files))
    assert all(origin["status"] == "tool_match" and origin["truncated"] is None for origin in origins.values())
    assert json.loads(files[0][1])[1]["error"] == "cancelled"


def test_current_session_native_json_cannot_downgrade_when_db_is_missing(case):
    path = f".opencode/history/{case.sid}/tools/msg_missing.json"
    with pytest.raises(ValueError, match="no message in current session"):
        NativeSources(case.ctx).origins({("a", path): b"[]"})
