"""The review at the end of a round, and the next round reading it (opencode/round_review.py)."""

import json
import time
from types import SimpleNamespace

import pytest
import yaml

from opencode import round_review as reviews
from opencode import task_skills as tasks
from opencode.app import App
from opencode.config import _frontmatter
from opencode.loop import _system
from opencode.store import Store


def write_file(path, meta, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"---\n{yaml.safe_dump(meta)}---\n{body}\n", encoding="utf-8")


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))  # outside the workspace, as in a run
    workspace = tmp_path / "workspace"
    write_file(workspace / ".opencode/skills/sample/SKILL.md", {"name": "sample", "description": "d"}, "Text.")
    (workspace / "brief.md").write_text("The room is 5.6 m long and 3.5 m wide.", encoding="utf-8")
    runtime = App(workspace, store=Store(tmp_path / "state.db"), config={"model": "local/test"})
    runtime.generate_titles = False
    yield runtime
    runtime.store._conn.close()


def calls(store, session_id, *exchanges):
    """One assistant message calling each tool, then each reply: (name, arguments, content, metadata)."""
    ids = [f"call_{time.time_ns()}_{number}" for number in range(len(exchanges))]
    store.add_message(session_id, "assistant", {"content": "", "tool_calls": [
        {"id": id_, "name": name, "arguments": arguments} for id_, (name, arguments, _, _) in zip(ids, exchanges)]})
    for id_, (name, _, content, metadata) in zip(ids, exchanges):
        store.add_message(session_id, "tool", {"tool_call_id": id_, "name": name, "content": content,
                                               "metadata": metadata})


def first_round(app):
    session = app.create_session()["id"]
    app.store.add_message(session, "user", {"content": "Design the room's treatment."})
    calls(app.store, session,
          ("read", {"filePath": "brief.md"}, "The room is 5.6 m long and 3.5 m wide.", {}),
          ("bash", {"command": "python fdtd.py"}, "Traceback (most recent call last):\n"
           "ModuleNotFoundError: No module named 'numpy'", {"exit": 1}))
    return session


class Model:
    """A stand-in for the reviewer's model: the replies it gives, and the requests it got."""

    def __init__(self, *replies):
        self.replies, self.requests = list(replies), []

    def __call__(self, system, message, schema):
        self.requests.append(SimpleNamespace(system=system, message=message, schema=schema))
        reply = self.replies.pop(0)
        return SimpleNamespace(text=reply if isinstance(reply, str) else json.dumps(reply), finish_reason="stop")


def reply(lessons=(), dropped=(), issues=(), description="Set up the solver's environment first."):
    return {"description": description, "lessons": list(lessons), "dropped": list(dropped),
            "framework_issues": list(issues)}


def run(app, session, model, *, round_=1, since=0.0, **facts):
    return reviews.review(model, store=app.store, root=session, directory=app.directory, round_=round_,
                          commission="Design the room's treatment.", request=facts.pop("request", ""),
                          ended=facts.pop("ended", {"status": "completed", "seconds": 61.0, "model_calls": 9}),
                          answer="The treatment is not finished.", since=since, sources=["brief.md"],
                          extra=facts.pop("extra", ()), core=app.skills)


def system_for(app, session):
    # A reviewed task has deep research on: its review skills come with it (opencode/deep.py).
    return _system(app, app.agents["build"], "test", "local", session, deep=True)


def test_a_review_writes_lessons_with_their_evidence_and_the_next_round_reads_them(app):
    session = first_round(app)
    model = Model(reply(
        lessons=[{"lesson": "Install numpy in the task's own environment before running the solver.",
                  "evidence": ["T2"]},
                 {"lesson": "A lesson on a call the package does not hold.", "evidence": ["T99"]},
                 {"lesson": "A lesson without evidence.", "evidence": []}],
        issues=[{"issue": "The solver's environment had no numpy.", "cause": "environment", "evidence": ["t2"]}]))
    record = run(app, session, model, extra=[("B1", "the research board", ".research", "No records yet.")])

    package = model.requests[0].message
    assert "[T2] bash: python fdtd.py -> exit 1" in package and "No module named 'numpy'" in package
    assert "[T1] read: brief.md -> ok" in package
    assert "[S1] task source (brief.md)\nThe room is 5.6 m long" in package
    assert "[C1] the commission" in package and "[B1] the research board (.research)\nNo records yet." in package
    assert "Round 1 of this task. The working agent finished its reply. Time: 61 s." in package
    assert "There is no previous review" in package
    assert "skill charter 0.3" in model.requests[0].system and model.requests[0].schema[0] == "round_review"

    assert record["status"] == "written"
    path = tasks.review_dir(session) / reviews.SKILL / "SKILL.md"
    assert record["skill"] == str(path) and path.is_relative_to(tasks.state_root())
    meta, body = _frontmatter(path.read_text(encoding="utf-8"))
    assert meta["kind"] == "review" and meta["author"] == "reviewer" and meta["round"] == 1
    assert meta["description"] == "Set up the solver's environment first."
    assert "1. Install numpy in the task's own environment" in body and "第 1 輪 T2 bash call" in body
    assert "A lesson on a call" not in body and "A lesson without evidence" not in body
    assert [item["reason"] for item in record["refused"]] == [
        "it cites T99, which the evidence package does not hold (skill charter article 4)",
        "it cites no evidence (skill charter article 4)"]
    assert record["framework_issues"][0]["evidence"][0]["id"] == "T2"  # ids are matched loosely

    issues = reviews.issues_markdown(record)
    assert "## 環境\n\n1. The solver's environment had no numpy." in issues and "## 框架\n\n（無）" in issues
    assert "沒有寫入的項目" in issues and "T99" in issues

    # The next round reads the lessons in its system prompt, and so do its subagents; another task does not.
    assert "Install numpy in the task's own environment" in system_for(app, session)
    assert "written by the reviewer" in system_for(app, session)
    child = app.store.create_session(directory=str(app.directory), agent="build", model=None,
                                     parent_id=session)["id"]
    assert "Install numpy" in system_for(app, child)
    assert "task_review_skill" not in system_for(app, app.create_session()["id"])


def test_the_next_review_keeps_a_lesson_with_its_first_evidence_and_every_version(app):
    session = first_round(app)
    run(app, session, Model(reply(lessons=[
        {"lesson": "Install numpy in the task's own environment before running the solver.", "evidence": ["T2"]},
        {"lesson": "Read the brief twice.", "evidence": ["T1"]}])))
    tasks.set_round(session, 2)
    since = time.time()
    app.store.add_message(session, "user", {"content": "Go on."})
    calls(app.store, session, ("bash", {"command": "python modes.py"}, "Wrote modes.csv", {"exit": 0}),
          ("write", {"filePath": "report.md"}, "Permission denied: report.md", {"error": True}))
    model = Model(reply(lessons=[{"lesson": "Install numpy in the task's own environment first.", "evidence": ["P1"]},
                                 {"lesson": "Write the report under work/.", "evidence": ["T2", "S1"]}],
                        dropped=[{"lesson": "Read the brief twice.", "reason": "Once was enough.",
                                  "evidence": ["P2", "T1"]}]))
    record = run(app, session, model, round_=2, since=since, request="Go on.")

    package = model.requests[0].message
    assert "[P1] a lesson of the previous review (the review written after round 1)" in package
    assert "Its evidence: 第 1 輪 T2 bash call" in package
    assert "[C2] this round's request" in package
    assert "python fdtd.py" not in package  # the first round's calls are the previous review's evidence
    assert "[T1] bash: python modes.py -> ok" in package and "[T2] write: report.md -> error" in package

    body = _frontmatter((tasks.review_dir(session) / reviews.SKILL / "SKILL.md").read_text(encoding="utf-8"))[1]
    assert "第 2 輪結束後由檢討者整理" in body
    assert "1. Install numpy in the task's own environment first.\n   證據：第 1 輪 T2 bash call" in body
    assert "2. Write the report under work/.\n   證據：第 2 輪 T2 write call" in body and "第 2 輪 S1 task source" in body
    assert "Read the brief twice" not in body
    assert record["dropped"][0]["evidence"][0] == {"round": 1, "id": "T1", "title": "read call",
                                                   "where": record["dropped"][0]["evidence"][0]["where"]}
    history = tasks.review_dir(session) / reviews.SKILL / "history/SKILL.1.md"
    assert "Read the brief twice" in history.read_text(encoding="utf-8")
    saved = json.loads(reviews.lessons_path(session).read_text(encoding="utf-8"))
    assert saved["round"] == 2 and len(saved["lessons"]) == 2
    earlier = json.loads((history.parent / "lessons.1.json").read_text(encoding="utf-8"))
    assert earlier["round"] == 1 and earlier["lessons"][1]["lesson"] == "Read the brief twice."


def test_a_reply_that_fails_the_format_gets_one_repair(app):
    session = first_round(app)
    model = Model("Here are my lessons.", reply(lessons=[{"lesson": "Install numpy first.", "evidence": ["T2"]}]))
    assert run(app, session, model)["status"] == "written"
    repair = model.requests[1].message
    assert repair.startswith(model.requests[0].message)
    assert "Your reply could not be used" in repair and "Expected one JSON object" in repair

    model = Model("not json", {"lessons": []})
    with pytest.raises(ValueError, match="failed its one repair: Missing description, dropped, framework_issues"):
        run(app, session, model)


def test_a_review_longer_than_the_charter_allows_is_sent_back(app):
    session = first_round(app)
    long = reply(lessons=[{"lesson": "x" * tasks.charter()["max_chars"], "evidence": ["T2"]}])
    model = Model(long, reply(lessons=[{"lesson": "Install numpy first.", "evidence": ["T2"]}]))
    assert run(app, session, model)["status"] == "written"
    assert "the skill charter allows 12000" in model.requests[1].message


def test_a_review_without_lessons_writes_no_skill(app):
    session = first_round(app)
    record = run(app, session, Model(reply(issues=[{"issue": "x", "cause": "framework", "evidence": ["R1"]}])))
    assert record["status"] == "no lessons" and not (tasks.review_dir(session) / reviews.SKILL).exists()
    assert "task_review_skill" not in system_for(app, session)


def test_a_stopped_round_is_described_as_stopped_not_failed(app):
    session = first_round(app)
    model = Model(reply())
    run(app, session, model, ended={"status": "aborted", "stopped_at": ".research/records/x/record.json",
                                    "stop_at": "mindmap"})
    assert ("The person stopped this round at a stage they chose (a new record of kind 'mindmap', "
            ".research/records/x/record.json); the work after it has not been run yet.") in model.requests[0].message


def test_a_long_round_shows_every_failure_and_counts_the_calls_left_out(app, monkeypatch):
    monkeypatch.setitem(reviews.LIMITS, "tools", 4000)
    session = app.create_session()["id"]
    for number in range(1, 201):
        failed = number in (50, 120)
        calls(app.store, session, ("bash", {"command": f"python step_{number:03}.py --with-a-long-option"},
                                   f"step {number} failed" if failed else "ok", {"exit": 2 if failed else 0}))
    model = Model(reply(lessons=[{"lesson": "Look at step 120.", "evidence": ["T120"]},
                                 {"lesson": "Look at step 100.", "evidence": ["T100"]}]))
    record = run(app, session, model)
    package = model.requests[0].message
    assert "[T50] bash: python step_050.py --with-a-long-option -> exit 2" in package and "step 50 failed" in package
    assert "[T120] bash" in package and "[T1] bash" in package and "[T200] bash" in package
    assert "[T100] bash" not in package and "calls without failure not shown: bash" in package
    # Only the calls shown can be cited.
    assert [item["lesson"] for item in record["lessons"]] == ["Look at step 120."]
    assert "T100, which the evidence package does not hold" in record["refused"][0]["reason"]
