"""Deployment settings in config/runtime.json: defaults, overrides and refusals; no model calls."""

import json

import pytest

from opencode import runtime_settings


def write(tmp_path, value):
    path = tmp_path / "runtime.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    return path


def test_the_shipped_file_keeps_the_values_that_were_fixed_in_the_code():
    shipped = runtime_settings.load(runtime_settings.ROOT / "config" / "runtime.json")
    assert shipped == runtime_settings.DEFAULTS


def test_a_missing_file_or_key_keeps_the_default_and_notes_are_skipped(tmp_path):
    assert runtime_settings.load(tmp_path / "absent.json") == runtime_settings.DEFAULTS
    values = runtime_settings.load(write(tmp_path, {"_說明": "note", "literature_agent": {"_說明": "note", "timeout_s": 900},
                                                    "network": {"max_queries": None}}))
    assert values["literature_agent"] == {"timeout_s": 900, "poll_s": 2}
    assert values["network"]["max_queries"] is None
    assert values["model_request"] == runtime_settings.DEFAULTS["model_request"]


@pytest.mark.parametrize("value, message", [
    ({"netwrok": {}}, "unknown setting group 'netwrok'"),
    ({"compute": {"simulation": 10}}, "unknown setting compute.simulation"),
    ({"compute": {"calc_check_s": 0}}, "compute.calc_check_s must be a positive number"),
    ({"compute": {"inference_s": True}}, "must be a positive number"),
    ({"network": {"max_queries": 20.5}}, "network.max_queries must be a positive whole number or null"),
    ({"model_request": {"max_bytes": "262144"}}, "model_request.max_bytes must be a positive whole number"),
    ({"compute": {"simulation_s": 900}}, "must not exceed compute.simulation_max_s"),
])
def test_unknown_keys_and_invalid_values_are_refused(tmp_path, value, message):
    with pytest.raises(ValueError, match=message):
        runtime_settings.load(write(tmp_path, value))


def test_another_file_can_be_named_in_the_environment(tmp_path, monkeypatch):
    path = write(tmp_path, {"model_request": {"timeout_s": 1200}})
    monkeypatch.setenv("COSCI_RUNTIME_CONFIG", str(path))
    assert runtime_settings.path() == path
    assert runtime_settings.load()["model_request"]["timeout_s"] == 1200
