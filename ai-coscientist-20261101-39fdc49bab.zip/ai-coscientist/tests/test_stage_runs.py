"""Stage tests: cutting a saved run back to a node, and the runner's node snapshots; no model calls."""

from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import sys
import time

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import fork_run  # noqa: E402
from recording import NodeWatcher  # noqa: E402


def record(workspace, name, kind):
    path = workspace / ".research" / "records" / name / "record.json"
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({"kind": kind}), encoding="utf-8")
    return f".research/records/{name}/record.json"


def saved_run(tmp_path):
    """Notes, then a mind map, then later work, created in that order: creation times cannot be set
    afterwards on Windows."""
    run = tmp_path / "run"
    workspace = run / "workspace"
    (workspace / "data").mkdir(parents=True)
    (workspace / "data" / "notes.md").write_text("before\n", encoding="utf-8")
    log = workspace / ".opencode" / "executions.jsonl"
    log.parent.mkdir()
    stamp = lambda when: json.dumps({"time": time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime(when)),
                                     "tool": "bash"}) + "\n"
    log.write_text(stamp(time.time() - 50), encoding="utf-8")
    time.sleep(0.1)
    mindmap = record(workspace, "aa11", "mindmap")
    t0 = (workspace / mindmap).stat().st_mtime - 100
    time.sleep(0.1)
    (run / "state/opencode").mkdir(parents=True)
    with closing(sqlite3.connect(run / "state/opencode/opencode.db")) as db:
        db.execute("CREATE TABLE session (id TEXT PRIMARY KEY, parent_id TEXT, directory TEXT, meta TEXT)")
        db.execute("CREATE TABLE message (id TEXT PRIMARY KEY, session_id TEXT, role TEXT, data TEXT, created REAL)")
        db.execute("CREATE TABLE todo (session_id TEXT, todo_id TEXT, content TEXT, status TEXT, priority TEXT)")
        read = [str(workspace / "data" / "notes.md").lower(), str(workspace / "work" / "later.py").lower()]
        db.execute("INSERT INTO session VALUES ('s1', NULL, ?, ?)", (str(workspace), json.dumps({"read_files": read})))
        messages = [
            ("m1", "user", {"content": "commission"}),
            ("m2", "assistant", {"tool_calls": [{"name": "todowrite", "arguments": {"todos": [
                {"content": "map", "status": "in_progress"}, {"content": "formulas", "status": "pending"}]}}]}),
            ("m3", "assistant", {"tool_calls": [{"name": "research_mindmap"}, {"name": "read"}]}),
            ("m4", "tool", {"name": "research_mindmap", "content": json.dumps({"record_path": mindmap})}),
            ("m5", "tool", {"name": "read", "content": "the other result of the same turn"}),
            ("m6", "assistant", {"tool_calls": [{"name": "todowrite", "arguments": {"todos": [
                {"content": "map", "status": "completed"}, {"content": "formulas", "status": "in_progress"}]}}]}),
            ("m7", "tool", {"name": "todowrite", "content": "ok"}),
        ]
        for number, (key, role, data) in enumerate(messages):
            db.execute("INSERT INTO message VALUES (?, 's1', ?, ?, ?)", (key, role, json.dumps(data), t0 + 10 * number))
        db.execute("INSERT INTO todo VALUES ('s1', '1', 'map', 'completed', NULL)")
        db.commit()
    later = workspace / "work" / "later.py"
    later.parent.mkdir()
    later.write_text("written after the mind map\n", encoding="utf-8")
    with log.open("a", encoding="utf-8") as stream:
        stream.write(stamp(time.time() + 50))  # a command run after the mind map
    (run / "settings.json").write_text("{}", encoding="utf-8")
    return run, workspace, t0


def test_a_fork_keeps_the_conversation_to_the_node_and_removes_later_work(tmp_path):
    run, workspace, _ = saved_run(tmp_path)
    summary = fork_run.fork(run, tmp_path / "checkpoint", at="mindmap")
    out = tmp_path / "checkpoint"
    assert summary["node"]["kind"] == "mindmap" and summary["cut_message"] == "m5"
    assert (summary["messages_kept"], summary["messages_dropped"]) == (5, 2)
    with closing(sqlite3.connect(out / "state/opencode/opencode.db")) as db:
        assert [row[0] for row in db.execute("SELECT id FROM message ORDER BY created")] == ["m1", "m2", "m3", "m4", "m5"]
        assert db.execute("SELECT content, status FROM todo ORDER BY todo_id").fetchall() == [
            ("map", "in_progress"), ("formulas", "pending")]  # as the last to-do list before the cut
        meta = json.loads(db.execute("SELECT meta FROM session").fetchone()[0])
        assert meta["read_files"] == [str(out / "workspace" / "data" / "notes.md").lower()]
    assert (out / "workspace/data/notes.md").read_text(encoding="utf-8") == "before\n"
    assert not (out / "workspace/work/later.py").exists() and "work/later.py" in summary["removed_files"]
    assert len((out / "workspace/.opencode/executions.jsonl").read_text(encoding="utf-8").splitlines()) == 1
    assert json.loads((out / "continuation.json").read_text(encoding="utf-8"))["session_id"] == "s1"
    assert (workspace / "work/later.py").exists()  # the source run is untouched
    with pytest.raises(ValueError, match="already exists"):
        fork_run.fork(run, out, at="mindmap")
    with pytest.raises(ValueError, match="has 0 leaderboard record"):
        fork_run.fork(run, tmp_path / "other", at="leaderboard")


def test_a_fork_points_the_conversation_at_its_own_workspace(tmp_path):
    # A stage run (2026-11-01) took the source workspace from its own compaction summary, found the delivery
    # the source run made after the node, and reported it as its own.
    run, workspace, _ = saved_run(tmp_path)
    old = str(workspace)
    with closing(sqlite3.connect(run / "state/opencode/opencode.db")) as db:
        data = {"content": f"工作區：{old}\\work；JSON 裡寫成 {json.dumps(old)[1:-1]}，也寫成 {workspace.as_posix()}/data。"
                           f"另一個執行 {run}-2 不動。",
                "tool_calls": [{"name": "bash", "arguments": {"command": "ls", "workdir": old.upper()}}]}
        db.execute("UPDATE message SET data = ? WHERE id = 'm3'", (json.dumps(data),))
        db.commit()
    summary = fork_run.fork(run, tmp_path / "checkpoint", at="mindmap")
    new = tmp_path / "checkpoint" / "workspace"
    with closing(sqlite3.connect(tmp_path / "checkpoint/state/opencode/opencode.db")) as db:
        moved = json.loads(db.execute("SELECT data FROM message WHERE id = 'm3'").fetchone()[0])
    assert moved["content"] == (f"工作區：{new}\\work；JSON 裡寫成 {json.dumps(str(new))[1:-1]}，"
                                f"也寫成 {new.as_posix()}/data。另一個執行 {run}-2 不動。")
    assert moved["tool_calls"][0]["arguments"]["workdir"].lower() == str(new).lower()  # Windows paths ignore case
    assert summary["messages_relocated"] == 1
    with closing(sqlite3.connect(run / "state/opencode/opencode.db")) as db:  # the source run is untouched
        assert old in json.loads(db.execute("SELECT data FROM message WHERE id = 'm3'").fetchone()[0])["content"]


def test_a_fork_drops_review_lessons_written_after_its_node(tmp_path):
    run, workspace, _ = saved_run(tmp_path)
    cut = (workspace / ".research/records/aa11/record.json").stat().st_mtime
    folder = run / "state/opencode/task/s1/review/lessons-from-earlier-rounds"
    (folder / "history").mkdir(parents=True)
    for path, text, when in ((folder / "history/SKILL.1.md", "after round 1", cut - 10),
                             (folder / "history/lessons.1.json", '{"round": 1}', cut - 10),
                             (folder / "SKILL.md", "after round 2", cut + 10),
                             (folder / "lessons.json", '{"round": 2}', cut + 10)):
        path.write_text(text, encoding="utf-8")
        os.utime(path, (when, when))
    summary = fork_run.fork(run, tmp_path / "checkpoint", at="mindmap")
    out = tmp_path / "checkpoint/state/opencode/task/s1/review/lessons-from-earlier-rounds"
    assert (out / "SKILL.md").read_text(encoding="utf-8") == "after round 1"
    assert json.loads((out / "lessons.json").read_text(encoding="utf-8")) == {"round": 1}
    assert not list((out / "history").iterdir())
    assert summary["reviews_dropped"] == ["review/lessons-from-earlier-rounds/SKILL.md"]
    assert (folder / "SKILL.md").read_text(encoding="utf-8") == "after round 2"  # the source run is untouched
    # With no version from before the node, the review skill goes.
    os.utime(folder / "history/SKILL.1.md", (cut + 5, cut + 5))
    summary = fork_run.fork(run, tmp_path / "checkpoint-2", at="mindmap")
    assert not (tmp_path / "checkpoint-2/state/opencode/task/s1/review/lessons-from-earlier-rounds").exists()
    assert sorted(summary["reviews_dropped"]) == ["review/lessons-from-earlier-rounds/SKILL.md",
                                                  "review/lessons-from-earlier-rounds/history/SKILL.1.md"]


def test_a_node_snapshot_is_used_when_the_run_saved_one(tmp_path):
    run, workspace, _ = saved_run(tmp_path)
    snapshot = run / "checkpoints" / "aa11" / "workspace"
    (snapshot / "data").mkdir(parents=True)
    (snapshot / "data" / "notes.md").write_text("as it was at the node\n", encoding="utf-8")
    summary = fork_run.fork(run, tmp_path / "checkpoint", at="mindmap")
    assert summary["from_snapshot"] == str(snapshot)
    assert (tmp_path / "checkpoint/workspace/data/notes.md").read_text(encoding="utf-8") == "as it was at the node\n"


def test_the_runner_snapshots_node_records_and_stops_at_the_requested_kind(tmp_path):
    workspace = tmp_path / "workspace"
    record(workspace, "old1", "mindmap")  # saved before the run: neither snapshot nor stop
    stops = []
    watcher = NodeWatcher(workspace, tmp_path / "checkpoints", "history_check", lambda: stops.append(1))
    watcher.start()
    try:
        record(workspace, "hyp1", "hypothesis")
        record(workspace, "calc1", "calc")
        record(workspace, "hc1", "history_check")
        deadline = time.time() + 10
        while not stops and time.time() < deadline:
            time.sleep(0.2)
    finally:
        watcher.halt.set()
        watcher.join(timeout=5)
    assert stops == [1] and watcher.stopped_at == ".research/records/hc1/record.json"
    assert sorted(p.name for p in (tmp_path / "checkpoints").iterdir()) == ["hc1", "hyp1"]


def test_skills_loaded_before_the_cut_get_their_current_text(tmp_path):
    # v34 loaded every skill in its first minutes; a stage continued from its mind map would read old guidance.
    run, workspace, t0 = saved_run(tmp_path)
    installed = workspace / ".opencode" / "skills" / "demo"
    installed.mkdir(parents=True)
    (installed / "SKILL.md").write_text("---\nname: demo\ndescription: d\n---\n\nOld rule: pile it on.\n",
                                        encoding="utf-8")
    current = tmp_path / "current" / "demo"
    current.mkdir(parents=True)
    (current / "SKILL.md").write_text("---\nname: demo\ndescription: d\n---\n\nNew rule: cut first.\n", encoding="utf-8")
    with closing(sqlite3.connect(run / "state/opencode/opencode.db")) as db:
        db.execute("INSERT INTO message VALUES ('m0', 's1', 'tool', ?, ?)", (json.dumps({
            "name": "skill", "content": '<skill_content name="demo">\n# Skill: demo\n\nOld rule: pile it on.\n'}), t0 + 1))
        db.commit()
    summary = fork_run.fork(run, tmp_path / "checkpoint", at="mindmap", current_skills=(tmp_path / "current",))
    assert summary["skills_refreshed"] == ["demo"]
    with closing(sqlite3.connect(tmp_path / "checkpoint/state/opencode/opencode.db")) as db:
        content = json.loads(db.execute("SELECT data FROM message WHERE id = 'm0'").fetchone()[0])["content"]
    assert "New rule: cut first." in content and "Old rule" not in content
    kept = fork_run.fork(run, tmp_path / "kept", at="mindmap", current_skills=())
    assert kept["skills_refreshed"] == []


def test_a_stage_run_continues_the_checkpoint_through_the_one_entry(tmp_path, monkeypatch):
    import run_stage
    from types import SimpleNamespace

    commands = []
    monkeypatch.setattr(run_stage, "PROJECT", tmp_path)
    monkeypatch.setattr(fork_run, "fork", lambda source, checkpoint, at=None, record=None: {
        "node": {"kind": "mindmap", "record": ".research/records/aa11/record.json", "minutes": 1.0},
        "messages_kept": 3, "modified_after_cut": []})
    monkeypatch.setattr(run_stage.subprocess, "run",
                        lambda command, cwd=None: commands.append(command) or SimpleNamespace(returncode=0))
    assert run_stage.main(["--from", str(tmp_path / "run"), "--at", "mindmap", "--until", "history_check",
                           "--name", "stage1", "--no-review"]) == 0
    folder = (tmp_path / "outputs" / "stage1").resolve()
    assert commands[0][3:] == [str(tmp_path / "scripts" / "run_tui.py"), str(folder / "checkpoint"), "--continue",
                               "--record", str(folder / "trace"), "--prompt", str(run_stage.CONTINUE), "--deep",
                               "--stop-at", "history_check", "--no-review"]
