"""Message IDs stay unique when many are made within one clock tick."""

import threading

from opencode.store import new_id


def test_ids_made_in_a_tight_loop_and_across_threads_are_unique_and_keep_their_shape():
    # On Windows the clock can stay on one value for many calls; the old IDs then repeated
    # ("UNIQUE constraint failed: message.id" in the session store, at random in the test suite).
    made = [new_id("msg") for _ in range(50000)]
    found = []

    def burst():
        found.extend(new_id("msg") for _ in range(5000))

    threads = [threading.Thread(target=burst) for _ in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    everything = made + found
    assert len(set(everything)) == len(everything)
    assert all(len(item) == len("msg_") + 13 + 8 for item in everything)
