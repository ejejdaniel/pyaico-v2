"""The task review reaches the round through its messages, and a compaction keeps it (task_skills.opening).

Acoustics round 2 (2026-10-31) had the lessons only in its system prompt, above 315 messages of round 1's
debugging loop, and went on with the loop. No real model is run here.
"""

from types import SimpleNamespace

import pytest

from opencode import deep, loop
from opencode import task_skills as tasks
from opencode.app import App
from opencode.compaction import REVIEW_NOTE, STALL_NOTE, build_prompt
from opencode.provider import Completion, ToolCall
from opencode.store import Store

REVIEW = '<task-review name="lessons" round="1">\nStop the loop.\n\n1. Write one fixed test.\n</task-review>'
REMINDER = '<task-review-reminder name="lessons" round="1">Stop the loop.</task-review-reminder>'


def test_the_review_rides_once_on_the_first_message_and_the_reminder_on_the_newest():
    for pins in (loop._FACT_PINS, loop._REVIEW_PINS):
        pins.pop("r", None)
    human = [{"role": "user", "content": "<human>go on</human>"}]
    one = loop._with_host_facts(human, "Plan x", "r", review=REVIEW, reminder=REMINDER)
    # The round's first request: the review comes after the host facts, and no reminder beside it.
    assert one[-1]["content"] == f"<human>go on</human>\n\n<host-facts>\nPlan x\n</host-facts>\n\n{REVIEW}"
    step = human + [{"role": "assistant", "content": ""}, {"role": "tool", "tool_call_id": "t1", "content": "r1"}]
    two = loop._with_host_facts(step, "Plan x", "r", review=REVIEW, reminder=REMINDER)
    assert two[0] == one[0]  # it stays where it came, so the request prefix stays the same
    assert two[-1]["content"] == f"r1\n\n{REMINDER}"
    later = step + [{"role": "assistant", "content": ""}, {"role": "tool", "tool_call_id": "t2", "content": "r2"}]
    three = loop._with_host_facts(later, "Plan x", "r", review=REVIEW, reminder=REMINDER)
    assert three[:3] == two[:2] + [step[2]] and three[-1]["content"] == f"r2\n\n{REMINDER}"
    assert sum(REVIEW in str(m["content"]) for m in three) == 1
    # A compaction dropped the first message: the review comes again, with the newest one.
    compacted = [{"role": "assistant", "content": "summary"}, {"role": "user", "content": "Continue."}]
    four = loop._with_host_facts(compacted, "Plan x", "r", review=REVIEW, reminder=REMINDER)
    assert four[-1]["content"] == f"Continue.\n\n<host-facts>\nPlan x\n</host-facts>\n\n{REVIEW}"
    # A changed review (a new process reads the next round's) moves too.
    five = loop._with_host_facts(compacted + [{"role": "assistant", "content": ""},
                                              {"role": "tool", "tool_call_id": "t3", "content": "r3"}],
                                 "Plan x", "r", review=REVIEW + "!", reminder=REMINDER)
    assert five[1]["content"] == "Continue.\n\n<host-facts>\nPlan x\n</host-facts>"
    assert five[-1]["content"] == f"r3\n\n{REVIEW}!"


def test_without_host_facts_or_a_message_to_ride_on():
    for pins in (loop._FACT_PINS, loop._REVIEW_PINS):
        pins.pop("s", None)
    human = [{"role": "user", "content": "go on"}]
    assert loop._with_host_facts(human, "", "s", review=REVIEW, reminder=REMINDER)[-1]["content"] == \
        f"go on\n\n{REVIEW}"
    assert loop._with_host_facts(human, "", "s") == human
    ended = human + [{"role": "assistant", "content": "x"}]
    assert loop._with_host_facts(ended, "F", "s", review=REVIEW, reminder=REMINDER)[-1] == {
        "role": "user", "content": f"<host-facts>\nF\n</host-facts>\n\n{REVIEW}"}


@pytest.fixture
def case(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / "a.txt").write_text("alpha", encoding="utf-8")
    store = Store(tmp_path / "session.db")
    app = App(project, store=store, config={}, auto_approve=True)
    app.generate_titles = False
    yield app, project
    store.close()


def model(app, replies, context=131072, output=8000):
    calls = []
    responses = iter(replies)
    provider = SimpleNamespace(id="test", context=context)

    def complete(**kwargs):
        calls.append(kwargs)
        return next(responses)

    app.provider = SimpleNamespace(resolve=lambda target: (provider, target or "test"),
                                   output_limit=lambda p, m: output, complete=complete)
    return calls


def reviewed(app, read=None):
    """A task in its second round, with the review written after its first (which read the file `read`)."""
    session = app.create_session()["id"]
    app.store.add_message(session, "user", {"content": "Design the room."})
    if read:  # reading it again is then not anything new
        app.store.add_message(session, "assistant", {"content": "", "tool_calls": [
            {"id": "round1", "name": "read", "arguments": {"filePath": str(read)}}]})
        app.store.add_message(session, "tool", {"tool_call_id": "round1", "name": "read", "content": "alpha"})
    app.store.add_message(session, "assistant", {"content": "Stopped while debugging."})
    tasks.write_review(session, "lessons-from-earlier-rounds", "Stop the debugging loop; write one test first.",
                       "# Lessons\n\n1. Write one fixed test with a hand-computed answer.", app.skills)
    tasks.set_round(session, 2)
    deep.set_on(app.store, session, True)  # reviews come with deep research (opencode/deep.py)
    return session


def read_then_answer(project):
    return [Completion(tool_calls=[ToolCall("c1", "read", {"filePath": str(project / "a.txt")})],
                       finish_reason="tool-calls"),
            Completion(text="done", finish_reason="stop")]


def texts(call):
    return [str(message.get("content")) for message in call["messages"]]


def test_a_round_gets_the_review_with_its_first_message(case):
    app, project = case
    session = reviewed(app)
    calls = model(app, read_then_answer(project))
    assert app.prompt(session, "Go on from where you stopped.")["text"] == "done"
    first, second = calls
    opening = '<task-review name="lessons-from-earlier-rounds" round="1">\nStop the debugging loop'
    assert texts(first)[-1].startswith("Go on from where you stopped.\n\n" + opening)
    assert "1. Write one fixed test" in texts(first)[-1] and "<task-review-reminder" not in texts(first)[-1]
    # The second step: the same first message; the work is moving, so no reminder.
    assert texts(second)[len(texts(first)) - 1] == texts(first)[-1]
    assert sum("<task-review " in text for text in texts(second)) == 1
    assert not any("<task-review-reminder" in text for text in texts(second))
    # The system prompt keeps the whole text, says it is repeated, and is the same on both steps.
    assert first["system"] == second["system"] and "<task_review_skill" in first["system"]
    assert "comes once more with this round's first message" in first["system"]
    # Nothing of it is saved.
    assert not any("task-review" in str(m.get("content")) for m in app.store.messages(session))


def test_the_reminder_and_the_progress_check_come_when_the_work_stalls(case):
    app, project = case
    app.config["progress"] = {"stall_after": 1}
    app.turn_extension_factory = lambda *args: SimpleNamespace(
        context=lambda: "Plan x", feedback=lambda: None, present=lambda text, status: text)
    session = reviewed(app, read=project / "a.txt")
    calls = model(app, read_then_answer(project))
    app.prompt(session, "Go on from where you stopped.")
    first, second = calls
    assert "Progress check" not in str(first["messages"]) and "<task-review-reminder" not in str(first["messages"])
    # One call read again what round 1 had read: the check and the lessons' one line ride on the newest message.
    newest = texts(second)[-1]
    assert newest.index("Progress check (counted by the host") < newest.index("<task-review-reminder")
    assert "the last 1 model calls made no progress the host can see" in newest
    assert "Project files they name most: a.txt (1)." in newest
    # The rule that gives the check its meaning is in the system prompt's context labels.
    assert "Its weight follows your progress." in second["system"] and first["system"] == second["system"]


def test_a_subagent_and_a_task_without_a_review_get_no_review_messages(case):
    app, project = case
    session = reviewed(app)
    child = app.store.create_session(directory=str(app.directory), agent="build", model=None,
                                     parent_id=session)["id"]
    calls = model(app, read_then_answer(project))
    app.prompt(child, "Read a.txt.")
    assert not any("task-review" in text for call in calls for text in texts(call))
    assert "<task_review_skill" in calls[0]["system"] and "comes once more" not in calls[0]["system"]

    calls = model(app, read_then_answer(project))
    app.prompt(app.create_session()["id"], "Read a.txt.")
    assert not any("task-review" in text for call in calls for text in texts(call) + [call["system"]])


def test_a_stalled_round_pauses_for_a_review_once_per_stretch(case):
    app, project = case
    app.config["progress"] = {"stall_after": 1, "pause_after": 2}
    session = reviewed(app, read=project / "a.txt")
    asked = []

    def pause_review(paused, stall):
        asked.append(stall)
        tasks.write_review(paused, "lessons-from-earlier-rounds", "Compute one reflection by hand first.",
                           "# Lessons\n\n1. Compute one reflection by hand before more probes.", app.skills)
        return {"status": "written"}

    app.pause_review = pause_review
    app.turn_extension_factory = lambda *args: SimpleNamespace(
        context=lambda: "Plan x", feedback=lambda: None, present=lambda text, status: text)
    reads = [Completion(tool_calls=[ToolCall(f"c{n}", "read", {"filePath": str(project / "a.txt")})],
                        finish_reason="tool-calls") for n in range(3)]
    calls = model(app, [*reads, Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Go on from where you stopped.")
    # Two stalled calls after the review: the third request comes after a pause; one more call is not enough.
    assert asked == [2]
    # No message of its own (in _r2d the agent answered one with a summary and stopped): the pause rides on the
    # newest tool result, as a fact in the progress check, with the new review version beside it.
    newest = calls[2]["messages"][-1]
    assert newest["role"] == "tool"
    assert ("The host paused the work for a review after 2 of these calls; the task review in view is the one "
            "written then.") in newest["content"]
    assert "Compute one reflection by hand first." in newest["content"]
    assert sum("<task-review " in text for text in texts(calls[2])) == 1
    assert "When the progress check says the host paused the work for a review" in calls[2]["system"]
    assert not any(m.get("synthetic") for m in app.store.messages(session) if m.get("role") == "user")
    pauses = app.store.get_session(session)["meta"]["pauses"]
    assert [(pause["stall"], pause["status"]) for pause in pauses] == [(2, "written")]


def test_a_task_without_deep_research_gets_none_of_its_reviews(case):
    app, project = case
    session = reviewed(app)
    deep.set_on(app.store, session, False)
    calls = model(app, read_then_answer(project))
    app.prompt(session, "Go on from where you stopped.")
    assert not any("task-review" in text for call in calls for text in texts(call) + [call["system"]])


def test_a_compaction_summary_is_written_knowing_the_review_and_the_review_comes_again(case):
    app, project = case
    session = reviewed(app)
    # The last reply used the whole window (40000 less 8000 for output), so the next step compacts first.
    app.store.add_message(session, "assistant", {"content": "Long work.", "tokens": {"total_tokens": 32000},
                                                 "finish_reason": "stop"})
    calls = model(app, [Completion(text="## Objective\n- Design the room.", finish_reason="stop"),
                        Completion(text="done", finish_reason="stop")], context=40000)
    assert app.prompt(session, "Go on.")["text"] == "done"
    summary, resumed = calls
    assert summary["tools"] is None
    request = texts(summary)[-1]
    assert '<task-review name="lessons-from-earlier-rounds" round="1">' in request and REVIEW_NOTE in request
    assert sum("<task-review " in text for text in texts(resumed)) == 1
    assert "<task-review " in texts(resumed)[-1]  # with the newest message, after the summary
    assert "made no progress the host can see" not in request  # the work had not stalled
    # A task without a review: the summary request is the one it always was.
    assert build_prompt("old") == build_prompt("old", "")
    assert "<task-review" not in build_prompt("old")


def test_a_summary_written_in_a_stall_keeps_its_conclusions_as_hypotheses(case):
    app, project = case
    app.config["progress"] = {"stall_after": 1}
    session = reviewed(app)
    app.store.add_message(session, "assistant", {"content": "", "tool_calls": [
        {"id": "c0", "name": "bash", "arguments": {"command": "python /tmp/dbg.py"}}],
        "tokens": {"total_tokens": 32000}, "finish_reason": "tool-calls"})
    app.store.add_message(session, "tool", {"tool_call_id": "c0", "name": "bash", "content": "REJ"})
    calls = model(app, [Completion(text="## Objective\n- Design the room.", finish_reason="stop"),
                        Completion(text="done", finish_reason="stop")], context=40000)
    app.prompt(session, "Go on.")
    request = texts(calls[0])[-1]
    assert STALL_NOTE.format(count=1) in request
    assert request.index(REVIEW_NOTE) < request.index("made no progress the host can see") < \
        request.index("<template>")
