"""Task skills under the skill charter: session-scoped method and review skills (opencode/task_skills.py)."""

from types import SimpleNamespace

import pytest
import yaml

from opencode import task_skills as tasks
from opencode.app import App
from opencode.config import _frontmatter
from opencode.prompts import load as load_prompt
from opencode.store import Store
from opencode.tools.extra import _skill
from opencode.tools.task_skill import _task_skill


def write_file(path, meta, body):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"---\n{yaml.safe_dump(meta)}---\n{body}\n", encoding="utf-8")


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))  # outside the workspace, as in a run
    workspace = tmp_path / "workspace"
    write_file(workspace / ".opencode/skills/sample/SKILL.md", {"name": "sample", "description": "d"},
               "Three rounds at most.")
    runtime = App(workspace, store=Store(tmp_path / "state.db"), config={"model": "local/test"})
    runtime.generate_titles = False
    runtime.permissions.auto = True
    yield runtime
    runtime.store._conn.close()


def context(app, session_id=None):
    return SimpleNamespace(app=app, session_id=session_id or app.create_session()["id"], agent=app.agents["build"],
                           directory=app.directory, worktree=app.directory)


def method(app, ctx, name="room-modes", body="Solve the room's modes on a grid."):
    return _task_skill({"action": "write", "name": name, "description": f"{name} guidance", "body": body}, ctx)


VERSION = tasks.charter()["version"]


def test_the_charter_states_its_version_and_machine_rules():
    # 0.2 (2026-10-30): the project lead extended the charter to task tools.
    rules = tasks.charter()
    assert rules["version"] == "0.3" and rules["kinds"] == ["method", "review"]
    assert rules["authors"] == ["worker", "reviewer"] and rules["max_chars"] > 0
    assert rules["tool_fields"] == ["assumptions", "applicability", "uncertainty"] and rules["tool_tests_min"] >= 1
    assert "task_skill tool" in load_prompt("skill.txt")


def test_a_method_skill_written_with_the_tool_loads_at_once_with_its_identity(app):
    ctx = context(app)
    result = method(app, ctx)
    path = app.directory / ".task" / ctx.session_id / "skills/room-modes/SKILL.md"
    assert result.metadata["location"] == str(path)
    meta, body = _frontmatter(path.read_text(encoding="utf-8"))
    assert meta == {"name": "room-modes", "description": "room-modes guidance", "kind": "method", "author": "worker",
                    "session": ctx.session_id, "round": 1, "charter": VERSION}
    loaded = _skill({"name": "room-modes"}, ctx).output
    assert "Solve the room's modes on a grid." in loaded
    assert (f"task method skill of this session, from round 1 (skill charter {VERSION}), written by the working "
            "agent") in loaded


def test_a_subagent_shares_its_tasks_skills_and_another_session_does_not_see_them(app):
    ctx = context(app)
    method(app, ctx)
    child = app.store.create_session(directory=str(app.directory), agent="build", model=None,
                                     parent_id=ctx.session_id)["id"]
    assert "Solve the room's modes" in _skill({"name": "room-modes"}, context(app, child)).output
    with pytest.raises(KeyError) as missing:
        _skill({"name": "room-modes"}, context(app))  # another task in the same folder
    assert missing.value.args[0].endswith("Available skills: sample")


@pytest.mark.parametrize("change, article", [
    (lambda full: {"name": "bare", "description": "d"},
     "missing kind, author, session, round, charter (skill charter article 2)"),
    (lambda full: {**full, "kind": "review", "author": "reviewer"}, "a method skill is written by the worker"),
    (lambda full: {**full, "name": "sample"}, "'sample' is the name of a framework skill (skill charter article 1)"),
    (lambda full: {**full, "session": "ses_other"}, "it belongs to another session (skill charter article 3)"),
])
def test_hand_written_task_skills_that_break_the_charter_are_refused_with_the_article(app, change, article):
    ctx = context(app)
    full = {"name": "bare", "description": "d", "kind": "method", "author": "worker", "session": ctx.session_id,
            "round": 1, "charter": "0.1"}
    write_file(tasks.method_dir(app.directory, ctx.session_id) / "bare/SKILL.md", change(full), "Text.")
    listing = _task_skill({"action": "list"}, ctx).output
    assert "Not loaded" in listing and article in listing
    assert "- none yet" in listing


def test_the_tool_refuses_a_framework_name_and_an_overlong_skill(app):
    ctx = context(app)
    with pytest.raises(ValueError, match="framework skill .*article 1"):
        method(app, ctx, name="sample")
    with pytest.raises(ValueError, match="exceed .* characters .*article 3"):
        method(app, ctx, body="x" * (tasks.charter()["max_chars"] + 1))
    with pytest.raises(ValueError, match="lowercase letters"):
        method(app, ctx, name="Room Modes")


def test_review_skills_are_read_only_lessons_in_the_state_and_every_version_is_kept(app):
    ctx = context(app)
    tasks.write_review(ctx.session_id, "lessons", "Lessons from earlier rounds", "Check the drawing's dimensions.",
                       app.skills)
    path = tasks.write_review(ctx.session_id, "lessons", "Lessons from earlier rounds",
                              "Check the drawing's dimensions against its labels.", app.skills)
    assert path.is_relative_to(tasks.state_root()) and not path.is_relative_to(app.directory)
    assert (path.parent / "history/SKILL.1.md").read_text(encoding="utf-8").rstrip().endswith("dimensions.")
    loaded = _skill({"name": "lessons"}, ctx).output
    assert "against its labels" in loaded and "written by the reviewer" in loaded and "read-only" in loaded
    # The working agent cannot shadow a review skill with a method skill of the same name.
    with pytest.raises(ValueError, match="review skill of this task"):
        method(app, ctx, name="lessons")


def test_a_later_round_is_recorded_in_the_skills_it_writes(app):
    ctx = context(app)
    assert tasks.current_round(ctx.session_id) == 1
    tasks.set_round(ctx.session_id, 2)
    method(app, ctx)
    method(app, ctx, body="Solve the modes on a finer grid.")  # rewritten: the round-2 version and its history
    path = tasks.method_dir(app.directory, ctx.session_id) / "room-modes/SKILL.md"
    assert _frontmatter(path.read_text(encoding="utf-8"))[0]["round"] == 2
    assert (path.parent / "history/SKILL.1.md").is_file()
    assert "from round 2" in _skill({"name": "room-modes"}, ctx).output


def test_a_framework_skill_loads_as_before(app):
    result = _skill({"name": "sample"}, context(app))
    assert result.output.startswith('<skill_content name="sample">\n# Skill: sample\n\nThree rounds at most.')
    assert "task skill" not in result.output
