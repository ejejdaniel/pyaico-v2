"""A supervised general-mode turn has a call budget, and every task replies in the person's language (opencode/loop.py).

No real model is run.
"""

from types import SimpleNamespace

import pytest

from opencode import deep, loop
from opencode.app import App
from opencode.config import validate_config
from opencode.provider import Completion, ToolCall
from opencode.store import Store


@pytest.fixture
def project(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    folder = tmp_path / "project"
    folder.mkdir()
    (folder / ".git").mkdir()
    for number in range(12):
        (folder / f"note{number}.md").write_text(f"note {number}", encoding="utf-8")
    yield folder, Store(tmp_path / "session.db")


def app_for(project, *, auto=False, turn=None):
    folder, store = project
    app = App(folder, store=store, config={"turn": turn or {"max_calls": 4, "remind_before": 2}}, auto_approve=auto)
    app.generate_titles = False
    return app


def reading(app, folder, answer="stage summary: notes 0 to 2 read; the cause is not found yet"):
    """A model that reads one more note each call, and answers when it is given no tools."""
    calls = []

    def complete(**kwargs):
        calls.append(kwargs)
        if not kwargs.get("tools"):
            return Completion(text=answer, finish_reason="stop")
        n = len(calls)
        return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(folder / f"note{n}.md")})],
                          finish_reason="tool-calls")

    app.provider = SimpleNamespace(resolve=lambda target: (SimpleNamespace(id="test", context=131072), "test"),
                                   output_limit=lambda p, m: 8000, complete=complete)
    return calls


def newest(call) -> str:
    return str(call["messages"][-1].get("content"))


def test_a_supervised_general_turn_is_told_to_converge_and_ends_with_a_stage_summary(project):
    folder, _ = project
    app = app_for(project)
    calls = reading(app, folder)
    result = app.prompt(app.create_session()["id"], "Why did the notes change?")
    # Four calls: the reminder with two left (calls 2 and 3), and the last one without tools reports.
    assert len(calls) == 4
    assert "回合額度" not in newest(calls[0]) and "第 2/4 次模型呼叫，之後還剩 2 次" in newest(calls[1])
    assert "第 3/4 次模型呼叫，之後還剩 1 次" in newest(calls[2])
    assert calls[3]["tools"] is None and loop.CALL_LIMIT_REPORT in str(calls[3]["messages"])
    assert result["status"] == "call_limit"
    assert result["text"].endswith("\n\nstage summary: notes 0 to 2 read; the cause is not found yet")
    # The person says go on: a new turn has its own calls.
    calls.clear()
    result = app.prompt(result["sessionID"], "Go on.")
    assert len(calls) == 4 and result["status"] == "call_limit"


def test_no_budget_with_deep_research_or_with_nobody_at_the_keyboard(project):
    folder, _ = project
    for auto, on in ((False, True), (True, False)):
        app = app_for(project, auto=auto)
        session = app.create_session()["id"]
        if on:
            deep.set_on(app.store, session, True)
        calls = reading(app, folder)

        def complete(_calls=calls, **kwargs):
            _calls.append(kwargs)
            n = len(_calls)
            if n > 6:
                return Completion(text="done", finish_reason="stop")
            return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(folder / f"note{n}.md")})],
                              finish_reason="tool-calls")

        app.provider.complete = complete
        result = app.prompt(session, "Why did the notes change?")
        assert (result["status"], len(calls)) == ("completed", 7)
        assert not any("回合額度" in newest(call) for call in calls)


def test_a_run_whose_prompts_play_the_person_has_the_budget(project):
    # Nobody approves permissions in such a run, but its prompt files play the person at the keyboard.
    folder, _ = project
    app = app_for(project, auto=True)
    app.supervised = True
    calls = reading(app, folder)
    result = app.prompt(app.create_session()["id"], "Why did the notes change?")
    assert (len(calls), result["status"]) == (4, "call_limit") and calls[3]["tools"] is None


def test_every_task_replies_in_the_persons_language_and_the_budget_is_checked(project):
    app = app_for(project)
    for on in (False, True):
        system = loop._system(app, app.agents["build"], "test", "local", app.create_session()["id"], deep=on)
        assert loop.LANGUAGE in system
    assert loop.LANGUAGE not in loop._system(app, app.agents["title"], "test", "local")
    validate_config({"turn": {"max_calls": 40, "remind_before": 10}})
    for bad, message in (([], "turn must be an object"), ({"max_calls": 1}, "turn.max_calls"),
                         ({"remind_before": -1}, "turn.remind_before")):
        with pytest.raises(ValueError, match=message):
            validate_config({"turn": bad})
    assert loop.TURN_MAX_CALLS == 40 and loop.TURN_REMIND_BEFORE == 10
