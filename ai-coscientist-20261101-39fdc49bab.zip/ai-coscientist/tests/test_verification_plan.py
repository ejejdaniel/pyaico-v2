"""The task's verification plan, written by the reviewer before the first round (opencode/verification.py)."""

import json
from types import SimpleNamespace

import pytest

from opencode import deep
from opencode import round_review as reviews
from opencode import task_skills as tasks
from opencode import verification
from opencode.app import App
from opencode.config import _frontmatter
from opencode.provider import Completion, ToolCall
from opencode.store import Store


class Model:
    """A stand-in for the planner's model: the replies it gives, and the requests it got."""

    def __init__(self, *replies):
        self.replies, self.requests = list(replies), []

    def __call__(self, system, message, schema):
        self.requests.append(SimpleNamespace(system=system, message=message, schema=schema))
        reply = self.replies.pop(0)
        return SimpleNamespace(text=reply if isinstance(reply, str) else json.dumps(reply), finish_reason="stop")


def plan_reply(**extra):
    return {"needed": True, "reason": "The design is a prediction that no measurement of the new room can confirm.",
            "description": "Results are predictions checked by physics and by hand-computable cases.",
            "problem": {"text": "Bring T20 in five bands to 0.25 s plus or minus 0.05 s.", "evidence": ["C1", "S1"]},
            "resources": [{"resource": "Physical laws", "what": "Diffuse-field reverberation formulas", "evidence": ["S1"]},
                          {"resource": "Measurements", "what": "None: every value is a prediction", "evidence": ["S1"]}],
            "checks": [{"layer": "input", "target": "Room dimensions read from the drawing", "methods": "Source "
                        "consistency with the drawing's labels", "strength": "strong", "ready_when": "A saved "
                        "check of the parsed dimensions against the labels", "evidence": ["S1"]},
                       {"layer": "computation", "target": "The reflection proxy", "methods": "Known answers and "
                        "invariants", "strength": "medium", "ready_when": "A mounted task tool whose known-answer "
                        "tests passed", "evidence": ["C1"]},
                       {"layer": "result", "target": "A check citing nothing", "methods": "x", "strength": "weak",
                        "ready_when": "x", "evidence": ["S9"]}],
            "stops": [{"scope": "task", "condition": "Within tolerance or three rounds", "evidence": ["C1"]},
                      {"scope": "work", "condition": "An auxiliary check not ready after its budget becomes a gap",
                       "evidence": ["C1"]}], **extra}


@pytest.fixture
def workspace(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / "goal.md").write_text("The target is T20 = 0.25 s in five octave bands.", encoding="utf-8")
    return project


def test_the_plan_is_written_as_a_review_skill_with_its_evidence(workspace):
    model = Model(plan_reply())
    record = verification.plan(model, root="ses_task", directory=workspace, commission="Design the room.",
                               sources=["goal.md"], core={})
    assert record["status"] == "written"
    request = model.requests[0]
    assert "[C1] the commission" in request.message and "[S1] task source (goal.md)" in request.message
    assert "skill charter 0.3" in request.system and "## 3. 驗證的種類" in request.system  # the framework's method
    assert "## 1. 先看任務的分量" in request.system and "needed: false when a plan would cost more" in request.system
    assert request.schema[0] == "verification_plan"
    path = tasks.review_dir("ses_task") / verification.SKILL / "SKILL.md"
    meta, body = _frontmatter(path.read_text(encoding="utf-8"))
    assert meta["kind"] == "review" and meta["author"] == "reviewer" and meta["round"] == 1
    assert meta["description"].startswith("Results are predictions")
    assert "第 1 輪開工前由檢討者依框架的驗證方法整理" in body
    assert "V1. [輸入｜強] Room dimensions read from the drawing" in body
    assert "V2. [計算｜中] The reflection proxy" in body and "就緒的證據：A mounted task tool" in body
    assert "A check citing nothing" not in body
    assert "- 每段工作：An auxiliary check not ready" in body and "依據：C1 the commission" in body
    assert [item["reason"] for item in record["refused"]] == [
        "it cites S9, which the evidence package does not hold (skill charter article 4)"]
    saved = verification.saved_plan("ses_task")
    assert [check["layer"] for check in saved["checks"]] == ["input", "computation"]
    assert (saved["needed"], saved["round"]) == (True, 1) and verification.planned("ses_task", 5)


def not_needed(**extra):
    return {"needed": False, "reason": "One direct reading of the notes answers it.",
            "description": "No plan: the answer is read from the notes.",
            "problem": {"text": "Say what the notes record for day 3.", "evidence": ["C1"]},
            "resources": [], "checks": [], "stops": [], **extra}


def test_a_task_that_needs_no_plan_gets_none_for_its_round(workspace):
    model = Model(not_needed(checks=plan_reply()["checks"]), not_needed())
    record = verification.plan(model, root="ses_light", directory=workspace, commission="What do the notes say?",
                               sources=["goal.md"], core={})
    # A verdict that none is needed leaves the lists empty; one that writes checks anyway is asked to choose.
    assert "needed is false, so resources, checks and stops stay empty" in model.requests[1].message
    assert (record["status"], record["reason"]) == ("not-needed", "One direct reading of the notes answers it.")
    assert not (tasks.review_dir("ses_light") / verification.SKILL / "SKILL.md").exists()
    assert tasks.load(None, "ses_light", {}, kinds=("review",)) == ({}, [])  # nothing comes to the working agent
    assert verification.saved_plan("ses_light")["checks"] == [] and verification.package_items("ses_light") == []
    # It holds for its round only; the next round is judged again, with its own request.
    assert verification.planned("ses_light", 1) and not verification.planned("ses_light", 2)
    model = Model(plan_reply())
    record = verification.plan(model, root="ses_light", directory=workspace, commission="What do the notes say?",
                               request="Now design the room the notes describe.", round_=2, sources=["goal.md"],
                               core={})
    assert record["status"] == "written" and "before round 2" in model.requests[0].system
    assert "[C2] this round's request (the first request of round 2)" in model.requests[0].message
    assert "第 2 輪開工前由檢討者依框架的驗證方法整理" in (
        tasks.review_dir("ses_light") / verification.SKILL / "SKILL.md").read_text(encoding="utf-8")
    assert verification.planned("ses_light", 3)  # a written plan holds for the task


def test_a_reply_without_a_usable_check_gets_one_repair(workspace):
    nothing = plan_reply(checks=[{"layer": "computation", "target": "x", "methods": "x", "strength": "weak",
                                  "ready_when": "x", "evidence": []}])
    model = Model(nothing, plan_reply())
    assert verification.plan(model, root="ses_task", directory=workspace, commission="Design the room.",
                             sources=["goal.md"], core={})["status"] == "written"
    assert "no check cites evidence the package holds" in model.requests[1].message
    model = Model("not json", {"description": "x"})
    with pytest.raises(ValueError, match="failed its one repair"):
        verification.plan(model, root="ses_other", directory=workspace, commission="c", sources=[], core={})


def test_a_later_review_can_cite_the_plans_checks(workspace):
    verification.plan(Model(plan_reply()), root="ses_task", directory=workspace, commission="Design the room.",
                      sources=["goal.md"], core={})
    items = verification.package_items("ses_task")
    assert [item.id for item in items] == ["V1", "V2"]
    assert "[computation | medium] The reflection proxy" in items[1].text


@pytest.fixture
def app(workspace, tmp_path):
    runtime = App(workspace, store=Store(tmp_path / "state.db"), config={}, auto_approve=True)
    runtime.generate_titles = False
    yield runtime
    runtime.store.close()


def model_calls(app, replies):
    calls = []
    responses = iter(replies)
    provider = SimpleNamespace(id="test", context=131072)

    def complete(**kwargs):
        calls.append(kwargs)
        return next(responses)

    app.provider = SimpleNamespace(resolve=lambda target: (provider, target or "test"),
                                   output_limit=lambda p, m: 8000, complete=complete)
    return calls


def test_the_plan_is_written_before_the_first_step_and_comes_with_the_first_message(app, workspace):
    asked = []

    def plan_verification(session_id):
        asked.append(session_id)
        return verification.plan(Model(plan_reply()), root=session_id, directory=workspace,
                                 commission="Design the room.", sources=["goal.md"], core={})

    app.plan_verification = plan_verification
    session = app.create_session()["id"]
    deep.set_on(app.store, session, True)  # the plan comes with deep research (opencode/deep.py)
    calls = model_calls(app, [Completion(tool_calls=[ToolCall("c1", "read", {"filePath": str(workspace / "goal.md")})],
                                         finish_reason="tool-calls"), Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Design the room.")
    assert asked == [session]  # once: the second step finds the plan
    first = str(calls[0]["messages"][-1]["content"])
    assert first.startswith("Design the room.\n\n<task-review name=\"verification-plan\" round=\"1\">")
    assert "V2. [計算｜中] The reflection proxy" in first
    assert '<task_review_skill name="verification-plan">' in calls[0]["system"]
    # A task that has a plan, and a subagent, are not planned again.
    model_calls(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Go on.")
    child = app.store.create_session(directory=str(workspace), agent="build", model=None, parent_id=session)["id"]
    model_calls(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(child, "Read goal.md.")
    assert asked == [session]


def test_a_round_that_needed_no_plan_is_not_asked_again_but_the_next_round_is(app, workspace):
    asked = []

    def plan_verification(session_id):
        asked.append(tasks.current_round(session_id))
        return verification.plan(Model(not_needed()), root=session_id, directory=workspace,
                                 commission="What do the notes say?", round_=tasks.current_round(session_id),
                                 sources=["goal.md"], core={})

    app.plan_verification = plan_verification
    session = app.create_session()["id"]
    deep.set_on(app.store, session, True)  # the plan comes with deep research (opencode/deep.py)
    for text in ("What do the notes say?", "And on day 4?"):
        calls = model_calls(app, [Completion(text="done", finish_reason="stop")])
        app.prompt(session, text)
        assert "task-review" not in str(calls[0]["messages"]) + calls[0]["system"]
    assert asked == [1]
    tasks.set_round(session, 2)
    model_calls(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Now compare the two days.")
    assert asked == [1, 2]


def test_a_task_without_deep_research_writes_no_plan(app, workspace):
    asked = []
    app.plan_verification = lambda session_id: asked.append(session_id)
    session = app.create_session()["id"]
    calls = model_calls(app, [Completion(text="done", finish_reason="stop")])
    app.prompt(session, "Design the room.")
    assert asked == [] and "task-review" not in str(calls[0]["messages"]) + calls[0]["system"]


def test_the_host_lists_the_checking_evidence_it_can_see(app, workspace, monkeypatch):
    from researchkit.turn import ResearchTurn

    session = app.create_session()["id"]
    turn = ResearchTurn(app, session, "msg")
    assert turn._verification_evidence() == ""  # no plan, no section
    verification.plan(Model(not_needed()), root=session, directory=workspace, commission="What do the notes say?",
                      sources=["goal.md"], core={})
    assert turn._verification_evidence() == ""  # nor when none is needed
    verification.plan(Model(plan_reply()), root=session, directory=workspace, commission="Design the room.",
                      sources=["goal.md"], core={})
    text = turn._verification_evidence()
    assert text.startswith("驗證計畫的就緒證據（宿主依已存紀錄列出，不是判斷）")
    assert "任務工具：無；框架算出的數值與排名紀錄：無。" in text and "\n\n" not in text
    from researchkit.simulation import task_tools
    monkeypatch.setattr(task_tools, "listing", lambda root_dir, root: {"tools": [
        {"id": "task.acoustics.reflections", "status": "mounted", "tests": "2/2 known-answer tests passed"},
        {"id": "task.acoustics.modes", "status": "refused", "tests": "0/1 known-answer tests passed"}]})
    record = workspace / ".research" / "records" / "abc" / "record.json"
    record.parent.mkdir(parents=True)
    record.write_text(json.dumps({"kind": "leaderboard", "title": "Multi-sheet leaderboard"}), encoding="utf-8")
    text = turn._verification_evidence()
    assert "task.acoustics.reflections（2/2 known-answer tests passed）" in text and "modes" not in text
    assert "排名「Multi-sheet leaderboard」" in text
