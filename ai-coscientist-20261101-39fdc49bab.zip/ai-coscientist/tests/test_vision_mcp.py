import base64
import json
import os
import tempfile
import threading
import unittest
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from opencode.mcp import McpHub
from opencode.mcp_oauth import McpAuthStore, OAuthConfig, obtain_token, parse_www_authenticate
from opencode.media import anthropic_media_block
from opencode.provider import _anthropic_messages, openai_messages_from_history
from opencode.tools.files import _read

PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)


class VisionTests(unittest.TestCase):
    def test_read_attaches_png(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            path = root / "dot.png"
            path.write_bytes(PNG)
            from tests.test_core import _ctx

            result = _read({"filePath": str(path)}, _ctx(root))
        self.assertEqual(result.output, "Image read successfully")
        self.assertEqual(result.attachments[0]["mime"], "image/png")
        self.assertTrue(result.attachments[0]["url"].startswith("data:image/png;base64,"))

    def test_tool_image_reaches_openai_and_anthropic(self):
        url = "data:image/jpeg;base64," + base64.standard_b64encode(b"\xff\xd8\xff\xd9").decode()
        history = [
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [{"id": "call_1", "name": "read", "arguments": {}}],
            },
            {
                "role": "tool",
                "tool_call_id": "call_1",
                "content": "Image read successfully",
                "attachments": [{"mime": "image/jpeg", "url": url}],
            },
        ]
        messages = openai_messages_from_history(history)
        self.assertEqual(messages[-1]["role"], "user")
        image = messages[-1]["content"][1]
        self.assertEqual(image["type"], "image_url")
        self.assertEqual(image["image_url"]["url"], url)
        converted = _anthropic_messages(messages)
        blocks = converted[-1]["content"]
        image_block = next(block for block in blocks if block.get("type") == "image")
        self.assertEqual(image_block["source"]["media_type"], "image/jpeg")
        self.assertTrue(image_block["source"]["data"])

    def test_pdf_becomes_document_block(self):
        block = anthropic_media_block({"mime": "application/pdf", "url": "data:application/pdf;base64,JVBERg=="})
        self.assertEqual(block["type"], "document")
        self.assertEqual(block["source"]["media_type"], "application/pdf")


class OAuthTests(unittest.TestCase):
    def test_parse_resource_metadata(self):
        header = 'Bearer realm="mcp", resource_metadata="https://example.test/meta"'
        self.assertEqual(parse_www_authenticate(header), "https://example.test/meta")

    def test_remote_mcp_oauth_then_initialize(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            os.environ["OPENCODE_TEST_HOME"] = str(root / "home")
            callback_port = _free_port()
            server = _AuthMcpServer()
            server.start()
            try:
                origin = f"http://127.0.0.1:{server.port}"
                hub = McpHub(
                    {
                        "mcp": {
                            "demo": {
                                "type": "remote",
                                "url": origin + "/mcp",
                                "oauth": {"callbackPort": callback_port},
                            }
                        }
                    },
                    root,
                    auth_store=McpAuthStore(root / "mcp-auth.json"),
                )
                hub.interactive = True

                def opener(url: str) -> None:
                    query = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
                    redirect = query["redirect_uri"][0]
                    state = query["state"][0]
                    with urllib.request.urlopen(f"{redirect}?code=test-code&state={state}") as response:
                        response.read()

                hub.connect_remote(hub.servers["demo"], opener=opener)
                status = hub.servers["demo"].status()
                self.assertEqual(status["status"], "connected", status)
                self.assertEqual(status["tools"], ["demo_echo"])
                self.assertIn("test-code", server.seen_codes)
                self.assertTrue(any(header.startswith("Bearer ") for header in server.seen_auth))
            finally:
                hub.close()
                server.stop()

    def test_stored_token_skips_browser(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            store = McpAuthStore(root / "mcp-auth.json")
            store.update(
                "demo",
                serverUrl="http://example.test/mcp",
                tokens={"accessToken": "saved", "expiresAt": None},
            )
            token = obtain_token(
                "http://example.test/mcp",
                "demo",
                OAuthConfig(),
                store,
                opener=lambda url: self.fail(url),
            )
            self.assertEqual(token, "saved")


def _free_port() -> int:
    import socket

    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class _AuthMcpServer:
    def __init__(self):
        self.seen_codes: list[str] = []
        self.seen_auth: list[str] = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                return

            def do_GET(self):
                path = urllib.parse.urlparse(self.path).path
                if path == "/.well-known/oauth-protected-resource":
                    self._json({"resource": f"http://127.0.0.1:{outer.port}/mcp", "authorization_servers": [f"http://127.0.0.1:{outer.port}"], "scopes_supported": ["mcp"]})
                    return
                if path == "/.well-known/oauth-authorization-server":
                    base = f"http://127.0.0.1:{outer.port}"
                    self._json(
                        {
                            "issuer": base,
                            "authorization_endpoint": base + "/authorize",
                            "token_endpoint": base + "/token",
                            "registration_endpoint": base + "/register",
                        }
                    )
                    return
                if path == "/authorize":
                    self._json({"ok": True})
                    return
                self.send_response(404)
                self.end_headers()

            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length)
                path = urllib.parse.urlparse(self.path).path
                if path == "/register":
                    self._json({"client_id": "client-1", "token_endpoint_auth_method": "none"})
                    return
                if path == "/token":
                    form = urllib.parse.parse_qs(raw.decode())
                    outer.seen_codes.append((form.get("code") or [""])[0])
                    self._json({"access_token": "token-123", "token_type": "Bearer", "expires_in": 3600})
                    return
                if path == "/mcp":
                    auth = self.headers.get("Authorization") or ""
                    outer.seen_auth.append(auth)
                    if auth != "Bearer token-123":
                        body = b'{"error":"unauthorized"}'
                        self.send_response(401)
                        self.send_header("Content-Type", "application/json")
                        self.send_header("Content-Length", str(len(body)))
                        self.send_header(
                            "WWW-Authenticate",
                            f'Bearer resource_metadata="http://127.0.0.1:{outer.port}/.well-known/oauth-protected-resource"',
                        )
                        self.end_headers()
                        self.wfile.write(body)
                        return
                    payload = json.loads(raw.decode() or "{}")
                    method = payload.get("method")
                    if method == "initialize":
                        result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "instructions": "remote"}
                    elif method == "tools/list":
                        result = {"tools": [{"name": "echo", "description": "Echo", "inputSchema": {"type": "object"}}]}
                    else:
                        result = {}
                    if "id" not in payload:
                        self.send_response(202)
                        self.end_headers()
                        return
                    self._json({"jsonrpc": "2.0", "id": payload["id"], "result": result})
                    return
                self.send_response(404)
                self.end_headers()

            def _json(self, payload):
                body = json.dumps(payload).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


if __name__ == "__main__":
    unittest.main()
