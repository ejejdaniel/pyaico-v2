"""Export the real TUI after a deterministic background delivery, with no model."""

import asyncio
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace

from opencode.app import App
from opencode.provider import Completion
from opencode.store import Store
from opencode.tui import OpenCodeTUI


async def main():
    output = Path("outputs/tui_background_delivery_preview_20261023").resolve()
    output.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="offline-fixture-", dir=output))
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME", "TEMP", "TMP"):
        os.environ[key] = str(root / key)
        Path(os.environ[key]).mkdir(parents=True, exist_ok=True)
    tempfile.tempdir = os.environ["TEMP"]
    project = root / "project"
    project.mkdir()
    (project / ".git").mkdir()
    runtime = App(project, store=Store(root / "session.db"), auto_approve=True, config={})
    runtime.generate_titles = False
    runtime.ensure_mcp = lambda: None
    session = runtime.create_session(title="離線介面驗證：背景正式結果", model="test/offline-fixture")["id"]
    other = runtime.create_session(title="接收期間開啟的另一個對話")["id"]

    class Presenter:
        def context(self):
            return ""

        def feedback(self):
            return None

        def present(self, text, status):
            return ("## 離線背景結果交付驗證\n\n"
                    "這份正文來自明確標示的測試 Presenter；未呼叫模型，也未執行科研工作。\n\n"
                    "- 接收結果時，介面正在顯示另一個對話。\n"
                    "- 切回後保留完整正式正文，事件重送不重印。\n"
                    "- 這個區塊沒有寫入普通訊息歷史；關閉介面後不重建。\n\n" + text)

    runtime.turn_extension_factory = lambda *_: Presenter()
    runtime.provider = SimpleNamespace(
        resolve=lambda _: (SimpleNamespace(id="test", context=200000), "offline-fixture"),
        complete=lambda **_: Completion(text="已完成離線介面測試資料的傳輸。", finish_reason="stop"),
    )
    ui = OpenCodeTUI(runtime, session_id=other)
    try:
        async with ui.run_test(size=(140, 42)) as pilot:
            await ui.show_session(None)
            await pilot.pause()
            (output / "home.svg").write_text(
                ui.export_screenshot(title="OpenCode · 離線介面驗證 · 首頁"), encoding="utf-8")
            await ui.show_session(other)
            await asyncio.to_thread(runtime.prompt, session, "驗證背景結果的完整正文與切換後呈現。")
            for _ in range(100):
                await pilot.pause(0.02)
                if ui.results.get(session):
                    break
            assert ui.results.get(session)
            runtime.bus.publish("session.result", next(iter(ui.results[session].values())))
            await pilot.pause(0.15)
            await ui.show_session(session)
            await pilot.pause()
            (output / "background_delivery.svg").write_text(
                ui.export_screenshot(title="OpenCode · 離線介面驗證 · 無模型及科研執行"), encoding="utf-8")
            await pilot.resize_terminal(88, 30)
            await pilot.pause()
            (output / "narrow.svg").write_text(
                ui.export_screenshot(title="OpenCode · 離線介面驗證 · 窄版背景結果"), encoding="utf-8")
    finally:
        runtime.store.close()
    print(output / "background_delivery.svg")


if __name__ == "__main__":
    asyncio.run(main())
