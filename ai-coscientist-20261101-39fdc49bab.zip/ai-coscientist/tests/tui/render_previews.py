"""Export real Textual widgets using an explicitly isolated offline test fixture.

Run directly from the repository root; no model, network, or service is used.
"""

import asyncio
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace

from opencode.app import App
from opencode.provider import Completion
from opencode.store import Store
from opencode.tui import OpenCodeTUI, PromptInput


async def main():
    output = Path("outputs/tui_core_preview_20261023").resolve()
    output.mkdir(parents=True, exist_ok=True)
    root = Path(tempfile.mkdtemp(prefix="fixture-", dir=output))
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        os.environ[key] = str(root / key)
    project = root / "project"
    project.mkdir()
    (project / ".git").mkdir()
    runtime = App(project, store=Store(root / "session.db"), auto_approve=True, config={})
    runtime.generate_titles = False
    runtime.ensure_mcp = lambda: None

    def respond(**kwargs):
        text = "## Offline interface check\n\nThis reply comes from the deterministic UI test fixture.\n\n- The prompt stays visible while the conversation scrolls.\n- Existing App callbacks deliver the response.\n- No model or scientific workflow was executed.\n\n中文文字與多行內容由實際終端元件呈現。"
        kwargs["on_text"](text)
        return Completion(text=text, finish_reason="stop")

    runtime.provider = SimpleNamespace(resolve=lambda _: (SimpleNamespace(id="test", context=200000), "test"), complete=respond)
    ui = OpenCodeTUI(runtime, model="test/offline-fixture")
    try:
        async with ui.run_test(size=(140, 42)) as pilot:
            await pilot.pause()
            (output / "home.svg").write_text(ui.export_screenshot(title="OpenCode · offline UI fixture · home"), encoding="utf-8")
            ui.query_one(PromptInput).load_text("Inspect the interface layout.\n這是離線介面測試。")
            await pilot.press("enter")
            for _ in range(100):
                await pilot.pause(0.02)
                if ui.session_id and ui.running_session is None:
                    break
            assert ui.session_id and ui.running_session is None
            await pilot.pause()
            (output / "conversation.svg").write_text(ui.export_screenshot(title="OpenCode · offline UI fixture · conversation"), encoding="utf-8")
            await pilot.resize_terminal(88, 30)
            await pilot.pause()
            (output / "narrow.svg").write_text(ui.export_screenshot(title="OpenCode · offline UI fixture · narrow"), encoding="utf-8")
    finally:
        runtime.store.close()
    print(output)


if __name__ == "__main__":
    asyncio.run(main())
