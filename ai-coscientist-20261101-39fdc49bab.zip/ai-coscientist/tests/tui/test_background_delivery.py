"""Real App and headless Textual delivery; scripted transport, no model calls."""

import asyncio
import threading

import pytest

from opencode.provider import Completion
from opencode.tui import HistoryRefresh, OpenCodeTUI, TurnEnded
from test_history_boundary import rendered, review
from test_lifecycle import wait_for
from test_prompt_boundary import provider, runtime


class DocumentPresenter:
    def context(self):
        return ""

    def feedback(self):
        return None

    def present(self, text, status):
        return "OFFLINE_DELIVERY_DOCUMENT\n\n" + text


def scripted(runtime, body="SCRIPTED_BODY"):
    def respond(**kwargs):
        if kwargs.get("on_text"):
            kwargs["on_text"](body)
        return Completion(text=body, finish_reason="stop")
    provider(runtime, respond)


@pytest.mark.parametrize("cached", [False, True])
def test_background_child_and_parent_deliver_documents_while_another_session_is_open(runtime, cached):
    parent = runtime.create_session()["id"]
    other = runtime.create_session()["id"]
    child = runtime.store.create_session(directory=str(runtime.directory), agent="build", model=None,
                                         parent_id=parent)["id"]
    runtime.store.add_message(parent, "user", {"content": "Continue this offline interface test after the child."})
    runtime.turn_extension_factory = lambda *_: DocumentPresenter()
    scripted(runtime)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=parent if cached else other)
        async with ui.run_test(size=(120, 40)) as pilot:
            await ui.show_session(other)
            runtime.spawn_background(child, "Offline child test", "build", 1, parent)
            await wait_for(pilot, lambda: bool(ui.results.get(parent)) and bool(ui.results.get(child)))
            await wait_for(pilot, lambda: parent not in runtime._running and child not in runtime._background)
            assert ui.session_id == other
            assert "OFFLINE_DELIVERY_DOCUMENT" not in rendered(ui, other)
            for sid in (child, parent):
                result = next(iter(ui.results[sid].values()))
                assert result["sessionID"] == sid
                assert result["text"] == "OFFLINE_DELIVERY_DOCUMENT\n\nSCRIPTED_BODY"
                source = next(item for item in runtime.store.messages(sid) if item["id"] == result["messageID"])
                assert source["content"] == "SCRIPTED_BODY"
                await ui.show_session(sid)
                # Parent synthetic notifications are inputs, not parent result.
                assert len(ui.results[sid]) == 1
                assert sum(getattr(item, "renderables", ())[0].plain == "Final response"
                           for item in ui.views[sid] if getattr(item, "renderables", None)) == 1
                assert "OFFLINE_DELIVERY_DOCUMENT" in rendered(ui, sid)
            first = rendered(ui, parent)
            await ui.show_session(other)
            await ui.show_session(parent)
            assert rendered(ui, parent) == first
    asyncio.run(exercise())


def test_two_identical_answers_survive_event_replay_and_cached_history_refresh(runtime):
    sid = runtime.create_session()["id"]
    scripted(runtime, "SAME_ANSWER_BODY")

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            for index in range(2):
                await asyncio.to_thread(runtime.prompt, sid, f"Offline request {index}")
                await wait_for(pilot, lambda: len(ui.results.get(sid, {})) == index + 1
                               and sid not in ui._history_dirty)
            results = list(ui.results[sid].values())
            assert results[0]["messageID"] != results[1]["messageID"]
            assert rendered(ui, sid).count("SAME_ANSWER_BODY") == 2
            runtime.bus.publish("session.result", results[0])
            await pilot.pause(0.15)
            assert len(ui.results[sid]) == 2
            assert rendered(ui, sid).count("SAME_ANSWER_BODY") == 2
            # An old result must resolve its own source even when a later
            # assistant message happens to have the same text as the delivery.
            runtime.bus.publish("session.result", dict(results[0], resultID="replayed-derived-result",
                                text="OLDER_FORMAL_DOCUMENT\n\nSAME_ANSWER_BODY"))
            await wait_for(pilot, lambda: "OLDER_FORMAL_DOCUMENT" in rendered(ui, sid))
            assert rendered(ui, sid).count("SAME_ANSWER_BODY") == 3
            assert len(ui.results[sid]) == 3
    asyncio.run(exercise())


def test_result_arrival_order_is_retained_without_using_message_ids_as_time(runtime):
    sid = runtime.create_session()["id"]
    first = runtime.store.add_message(sid, "assistant", {"id": "z-first", "content": "FIRST_SOURCE"})
    second = runtime.store.add_message(sid, "assistant", {"id": "a-second", "content": "SECOND_SOURCE"})

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            for identity, source, text in (("z-result", second, "SECOND_DOCUMENT"),
                                           ("a-result", first, "FIRST_DOCUMENT")):
                runtime.bus.publish("session.result", {"sessionID": sid, "resultID": identity,
                                    "messageID": source["id"], "text": text, "status": "completed"})
            await wait_for(pilot, lambda: "FIRST_DOCUMENT" in rendered(ui, sid))
            text = rendered(ui, sid)
            assert text.index("FIRST_SOURCE") < text.index("SECOND_SOURCE")
            assert text.index("SECOND_DOCUMENT") < text.index("FIRST_DOCUMENT")
            assert len(ui.results[sid]) == 2
    asyncio.run(exercise())


def test_background_result_and_error_do_not_finish_another_foreground_worker(runtime):
    foreground = runtime.create_session()["id"]
    background = runtime.create_session()["id"]
    entered, release = threading.Event(), threading.Event()

    def respond(**kwargs):
        if "foreground" in str(kwargs["messages"][-1]["content"]):
            entered.set()
            assert release.wait(8)
            return Completion(text="FOREGROUND_RESULT", finish_reason="stop")
        return Completion(text="BACKGROUND_RESULT", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=foreground)
        async with ui.run_test() as pilot:
            await ui.start_prompt("Hold foreground", "build", None)
            await wait_for(pilot, entered.is_set)
            await asyncio.to_thread(runtime.prompt, background, "Return background")
            runtime.bus.publish("session.error", {"sessionID": background, "error": "BACKGROUND_ERROR"})
            await wait_for(pilot, lambda: bool(ui.results.get(background)))
            assert ui.running_session == foreground
            assert ui.statuses[foreground] == "busy"
            await ui.show_session(background)
            assert "BACKGROUND_RESULT" in rendered(ui, background)
            assert "BACKGROUND_ERROR" in rendered(ui, background)
            assert ui.running_session == foreground
            release.set()
            await wait_for(pilot, lambda: ui.running_session is None)
    try:
        asyncio.run(exercise())
    finally:
        release.set()


def test_background_present_failure_has_visible_error_without_result(runtime):
    parent = runtime.create_session()["id"]
    runtime.store.add_message(parent, "user", {"content": "Offline failure boundary."})

    class FailedPresenter(DocumentPresenter):
        def present(self, text, status):
            raise RuntimeError("OFFLINE_PRESENT_FAILURE")

    runtime.turn_extension_factory = lambda *_: FailedPresenter()
    scripted(runtime)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=parent)
        async with ui.run_test() as pilot:
            with runtime._execution_lock:
                runtime._running.add(parent)
            await asyncio.to_thread(runtime._continue_background, parent)
            await wait_for(pilot, lambda: "OFFLINE_PRESENT_FAILURE" in rendered(ui, parent))
            assert not ui.results.get(parent)
            assert "OFFLINE_DELIVERY_DOCUMENT" not in rendered(ui, parent)
    asyncio.run(exercise())


def test_late_older_result_is_retained_while_a_new_turn_is_streaming(runtime):
    sid = runtime.create_session()["id"]
    original = runtime.store.add_message(sid, "assistant", {"content": "EARLIER_SOURCE_BODY"})
    entered, release = threading.Event(), threading.Event()

    def respond(**kwargs):
        kwargs["on_text"]("NEW_TURN_STREAM")
        entered.set()
        assert release.wait(8)
        return Completion(text="NEW_TURN_STREAM", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            await ui.start_prompt("Start a newer offline turn", "build", None)
            await wait_for(pilot, lambda: entered.is_set() and "NEW_TURN_STREAM" in rendered(ui, sid))
            runtime.bus.publish("session.result", {"sessionID": sid, "resultID": "delayed-earlier-result",
                                "messageID": original["id"], "text": "EARLIER_FORMAL_DOCUMENT",
                                "status": "completed"})
            await wait_for(pilot, lambda: "delayed-earlier-result" in ui.results.get(sid, {}))
            assert ui.running_session == sid
            assert "NEW_TURN_STREAM" in rendered(ui, sid)
            assert ui.results[sid]["delayed-earlier-result"]["messageID"] == original["id"]
            release.set()
            await wait_for(pilot, lambda: ui.running_session is None
                           and "EARLIER_FORMAL_DOCUMENT" in rendered(ui, sid))
            assert len(ui.results[sid]) == 2
            assert rendered(ui, sid).count("NEW_TURN_STREAM") == 1
            assert rendered(ui, sid).count("EARLIER_FORMAL_DOCUMENT") == 1
    try:
        asyncio.run(exercise())
    finally:
        release.set()


def test_cached_history_does_not_refresh_unmarked_review_draft(runtime):
    review(runtime)
    sid = runtime.create_session()["id"]
    entered, release = threading.Event(), threading.Event()
    calls = []

    def respond(**kwargs):
        calls.append(True)
        if len(calls) == 1:
            kwargs["on_text"]("PRIVATE_CACHED_DRAFT")
            entered.set()
            assert release.wait(8)
            return Completion(text="PRIVATE_CACHED_DRAFT", finish_reason="stop")
        return Completion(text="CHECKED_CACHED_ANSWER", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            task = asyncio.create_task(asyncio.to_thread(runtime.prompt, sid, "Check cached draft boundary"))
            try:
                await wait_for(pilot, entered.is_set)
                assert runtime.store.messages(sid)[-1].get("answer_review_role") is None
                await pilot.pause(0.15)
                await ui.show_session(None)
                await ui.show_session(sid)
                assert "PRIVATE_CACHED_DRAFT" not in rendered(ui, sid)
                release.set()
                await task
                await wait_for(pilot, lambda: "CHECKED_CACHED_ANSWER" in rendered(ui, sid))
                assert "PRIVATE_CACHED_DRAFT" not in rendered(ui, sid)
            finally:
                release.set()
                await task
    asyncio.run(exercise())


@pytest.mark.parametrize("status", ["aborted", "step_limit"])
def test_host_stop_result_is_preserved_verbatim_and_not_upgraded(runtime, status):
    sid = runtime.create_session()["id"]
    text = f"STOPPED_BODY_{status}\nNo completion is claimed."

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            runtime.bus.publish("session.result", {"resultID": "stop-result", "sessionID": sid,
                                "messageID": None, "text": text, "status": status})
            await wait_for(pilot, lambda: f"STOPPED_BODY_{status}" in rendered(ui, sid))
            assert ui.results[sid]["stop-result"]["text"] == text
            assert ui.results[sid]["stop-result"]["status"] == status
    asyncio.run(exercise())


def test_foreground_completion_is_not_a_second_result_channel_and_compact_remains_independent(runtime, monkeypatch):
    sid = runtime.create_session()["id"]
    monkeypatch.setattr(runtime, "summarize", lambda _: "OFFLINE_COMPACT_SUMMARY")

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            await ui.finish_turn(TurnEnded(sid, result={"text": "DO_NOT_RENDER_PROMPT_RETURN"}))
            await pilot.pause()
            assert "DO_NOT_RENDER_PROMPT_RETURN" not in rendered(ui, sid)
            await ui.slash("/compact")
            await wait_for(pilot, lambda: "OFFLINE_COMPACT_SUMMARY" in rendered(ui, sid))
            assert not ui.results
            assert ui.running_session is None
            await ui.show_session(None)
            await ui.show_session(sid)
            assert rendered(ui, sid).count("OFFLINE_COMPACT_SUMMARY") == 1
    asyncio.run(exercise())


def test_session_switch_and_idle_refresh_serialize_widget_replacement(runtime):
    sid = runtime.create_session()["id"]
    runtime.store.add_message(sid, "assistant", {"content": "SAVED_WIDGET_BODY"})

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            # These are the same concurrent entry points as a session picker
            # worker racing the queued idle refresh after /compact finishes.
            await asyncio.gather(ui.show_session(None), ui.show_session(sid),
                                 ui.refresh_history(HistoryRefresh(sid)))
            await pilot.pause()
            assert ui.session_id == sid
            assert len(ui.query("#conversation .message")) == 1
            assert rendered(ui, sid).count("SAVED_WIDGET_BODY") == 1
    asyncio.run(exercise())


def test_restarting_tui_only_restores_saved_history_without_replaying_present(runtime):
    sid = runtime.create_session()["id"]
    calls = []

    class CountingPresenter(DocumentPresenter):
        def present(self, text, status):
            calls.append(True)
            return super().present(text, status)

    runtime.turn_extension_factory = lambda *_: CountingPresenter()
    scripted(runtime)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test() as pilot:
            await asyncio.to_thread(runtime.prompt, sid, "Offline restart boundary")
            await wait_for(pilot, lambda: "OFFLINE_DELIVERY_DOCUMENT" in rendered(ui, sid))
        restarted = OpenCodeTUI(runtime, session_id=sid)
        async with restarted.run_test() as pilot:
            assert "SCRIPTED_BODY" in rendered(restarted, sid)
            assert "OFFLINE_DELIVERY_DOCUMENT" not in rendered(restarted, sid)
            assert not restarted.results
            assert calls == [True]
    asyncio.run(exercise())
