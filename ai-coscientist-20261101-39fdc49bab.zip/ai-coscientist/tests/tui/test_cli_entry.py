from types import SimpleNamespace

from opencode import cli, tui


def test_tty_interactive_dispatches_without_creating_a_session(monkeypatch):
    args = SimpleNamespace(agent=None, model=None)
    called = []
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(cli.sys.stdout, "isatty", lambda: True)
    monkeypatch.setattr(tui, "run", lambda app, options, **kwargs: called.append((app, options, kwargs)))
    runtime = object()
    cli._interactive(runtime, args)
    assert called == [(runtime, args, {"session_id": None})]


def test_tty_resume_preserves_existing_session_selection(monkeypatch):
    args = SimpleNamespace(agent=None, model=None, session="ses_existing")
    called = []
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(cli.sys.stdout, "isatty", lambda: True)
    monkeypatch.setattr(tui, "run", lambda app, options, **kwargs: called.append(kwargs))
    cli._interactive(object(), args)
    assert called == [{"session_id": "ses_existing"}]


def test_redirected_interactive_keeps_line_mode(monkeypatch, capsys):
    args = SimpleNamespace(agent=None, model=None)
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(cli.sys.stdout, "isatty", lambda: False)
    monkeypatch.setattr(tui, "run", lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("TUI started")))
    monkeypatch.setattr("builtins.input", lambda _: (_ for _ in ()).throw(EOFError()))
    runtime = SimpleNamespace(create_session=lambda **kwargs: {"id": "ses_saved"})
    cli._interactive(runtime, args)
    assert "session ses_saved" in capsys.readouterr().out
