"""The TUI's /deep switch turns deep research on or off for a task (opencode/deep.py); no model or network calls."""

import asyncio

from opencode import deep
from opencode.provider import Completion
from opencode.tools.types import Tool, ToolResult
from opencode.tui import OpenCodeTUI, PromptInput
from test_dialogs import wait_for
from test_prompt_boundary import provider, runtime


def test_slash_deep_turns_deep_research_on_for_the_task_from_its_next_message(runtime):
    runtime.deep = deep.Deep(tools=[Tool("deep_probe", "A stand-in research tool.", {"type": "object", "properties": {}},
                                         lambda args, ctx: ToolResult(output="probed"))])
    seen = []

    def respond(**kwargs):
        seen.append({tool["name"] for tool in kwargs.get("tools") or []})
        return Completion(text="done", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test(size=(120, 42)) as pilot:
            editor = ui.query_one(PromptInput)
            assert ui.deep is False  # off by default
            editor.load_text("first question")
            await pilot.press("enter")
            await wait_for(pilot, lambda: seen and ui.running_session is None)
            assert "deep_probe" not in seen[-1]
            editor.load_text("/deep")
            await pilot.press("enter")
            assert ui.deep is True and deep.is_on(runtime, ui.session_id)
            editor.load_text("second question")
            await pilot.press("enter")
            await wait_for(pilot, lambda: len(seen) == 2 and ui.running_session is None)
            assert "deep_probe" in seen[-1]
            editor.load_text("/deep off")
            await pilot.press("enter")
            assert ui.deep is False and not deep.is_on(runtime, ui.session_id)
            editor.load_text("/deep maybe")
            await pilot.press("enter")
            assert editor.text == "/deep maybe"
            # A new task starts with the switch as it stands; --deep starts the interface with it on.
            editor.load_text("/new")
            await pilot.press("enter")
            editor.load_text("/deep on")
            await pilot.press("enter")
            editor.load_text("third question")
            await pilot.press("enter")
            await wait_for(pilot, lambda: len(seen) == 3 and ui.running_session is None)
            assert deep.is_on(runtime, ui.session_id) and "deep_probe" in seen[-1]

    asyncio.run(exercise())
    assert OpenCodeTUI(runtime, deep=True).deep is True
