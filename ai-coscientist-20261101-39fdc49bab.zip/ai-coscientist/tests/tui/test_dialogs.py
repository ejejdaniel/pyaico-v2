"""Real App pending requests driven by Textual; no model or network calls."""

import asyncio
import threading

import pytest
from textual.widgets import Button, Input, SelectionList

from opencode.permission import PermissionCorrected, PermissionRejected, Rule
from opencode.provider import Completion
from opencode.tui import OpenCodeTUI, PermissionDialog, PromptInput, QuestionDialog
from test_prompt_boundary import provider, runtime


async def wait_for(pilot, predicate):
    for _ in range(100):
        if predicate():
            # push_screen exposes the screen before compose/mount/layout end.
            await pilot.pause()
            return
        await pilot.pause(0.03)
    assert predicate(), "The expected UI/runtime transition did not occur"


async def start_request(ui, pilot, dialog_type):
    ui.query_one(PromptInput).load_text("Run the dialog boundary test")
    await pilot.press("enter")
    await wait_for(pilot, lambda: isinstance(ui.screen, dialog_type))
    return ui.screen


async def click_button(ui, pilot, selector):
    # Textual ignores a repeat click during its button press animation.
    await wait_for(pilot, lambda: not ui.screen.query_one(selector, Button).has_class("-active"))
    assert await pilot.click(selector)


def ask_permission(runtime, session_id, pattern="notes/input.txt"):
    runtime.permissions.ask(
        session_id=session_id,
        permission="read",
        patterns=[pattern],
        always=["notes/*"],
        ruleset=[Rule("read", "*", "ask")],
        metadata={"path": pattern},
    )


def test_permission_once_requires_another_reply_for_the_next_request(runtime):
    runtime.permissions.auto = False
    session_id = runtime.create_session()["id"]
    allowed = []

    def respond(**kwargs):
        for index in range(2):
            ask_permission(runtime, session_id)
            allowed.append(index)
        return Completion(text="Both requested reads were allowed", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            first = await start_request(ui, pilot, PermissionDialog)
            first_id = first.request["id"]
            assert allowed == []
            await click_button(ui, pilot, "#once")
            await wait_for(pilot, lambda: isinstance(ui.screen, PermissionDialog)
                           and ui.screen.request["id"] != first_id)
            assert allowed == [0]
            assert len(runtime.permissions.list_pending()) == 1
            await click_button(ui, pilot, "#once")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert allowed == [0, 1]
            assert runtime.permissions.list_pending() == []
            assert ui.query_one(PromptInput).has_focus

    asyncio.run(exercise())


@pytest.mark.parametrize("reply, reason", [
    ("button", ""),
    ("escape", ""),
    ("button", "Use the already available file"),
])
def test_permission_reject_reaches_the_broker_without_approving(runtime, reply, reason):
    runtime.permissions.auto = False
    session_id = runtime.create_session()["id"]
    outcomes = []

    def respond(**kwargs):
        try:
            ask_permission(runtime, session_id)
        except (PermissionRejected, PermissionCorrected) as error:
            outcomes.append(error)
        else:
            outcomes.append("approved")
        return Completion(text="Permission reply received", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            dialog = await start_request(ui, pilot, PermissionDialog)
            if reason:
                dialog.query_one(Input).value = reason
            if reply == "escape":
                await pilot.press("escape")
            else:
                await click_button(ui, pilot, "#reject")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert len(outcomes) == 1
            assert isinstance(outcomes[0], PermissionCorrected if reason else PermissionRejected)
            if reason:
                assert str(outcomes[0]) == reason
            assert runtime.permissions.list_pending() == []
            assert not runtime.abort_event(session_id).is_set()

    asyncio.run(exercise())


def test_permission_always_requires_confirmation_and_preserves_rule_scope(runtime):
    runtime.permissions.auto = False
    session_id = runtime.create_session()["id"]
    allowed = []

    def respond(**kwargs):
        for path in ("notes/input.txt", "notes/another.txt", "outside/input.txt"):
            ask_permission(runtime, session_id, path)
            allowed.append(path)
        return Completion(text="Scoped permissions applied", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            dialog = await start_request(ui, pilot, PermissionDialog)
            request_id = dialog.request["id"]
            await click_button(ui, pilot, "#always")
            await pilot.pause(0.15)
            assert ui.screen is dialog
            assert allowed == []
            assert runtime.permissions.list_pending()[0]["id"] == request_id
            assert str(dialog.query_one("#always", Button).label) == "Confirm always"
            await click_button(ui, pilot, "#always")
            await wait_for(pilot, lambda: isinstance(ui.screen, PermissionDialog)
                           and ui.screen.request["id"] != request_id)
            assert allowed == ["notes/input.txt", "notes/another.txt"]
            assert ui.screen.request["patterns"] == ["outside/input.txt"]
            await click_button(ui, pilot, "#once")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert allowed == ["notes/input.txt", "notes/another.txt", "outside/input.txt"]
            assert runtime.permissions.list_pending() == []

    asyncio.run(exercise())


def test_questions_single_multiple_custom_and_back_navigation_reach_runtime(runtime):
    session_id = runtime.create_session()["id"]
    answers = []
    questions = [
        {"header": "Single", "question": "Choose one option", "custom": False,
         "options": [{"label": "Alpha"}, {"label": "Beta"}]},
        {"header": "Multiple", "question": "Choose several options", "multiple": True,
         "options": [{"label": "First"}, {"label": "Second"}]},
        {"header": "Custom", "question": "Supply your own answer", "options": []},
    ]

    def respond(**kwargs):
        answers.append(runtime.ask_questions(session_id, questions))
        return Completion(text="Answers received", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            dialog = await start_request(ui, pilot, QuestionDialog)
            options = dialog.query_one(SelectionList)
            assert not dialog.query_one(Input).display
            await pilot.press("space", "down", "space")
            assert options.selected == ["Beta"]
            await click_button(ui, pilot, "#question-next")
            await pilot.press("space", "down", "space")
            assert set(options.selected) == {"First", "Second"}
            assert await pilot.click("#question-custom")
            await pilot.press(*"Extra")
            await click_button(ui, pilot, "#question-next")
            await pilot.press(*"Typed answer")
            await click_button(ui, pilot, "#question-back")
            assert set(options.selected) == {"First", "Second"}
            assert dialog.query_one(Input).value == "Extra"
            await click_button(ui, pilot, "#question-next")
            assert dialog.query_one(Input).value == "Typed answer"
            assert answers == []
            await click_button(ui, pilot, "#question-next")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert answers == [[["Beta"], ["First", "Second", "Extra"], ["Typed answer"]]]
            assert runtime.pending_questions() == []
            assert not runtime.abort_event(session_id).is_set()

    asyncio.run(exercise())


def test_question_escape_clears_edit_and_explicit_stop_supplies_no_answer(runtime):
    session_id = runtime.create_session()["id"]
    answers, errors = [], []

    def respond(**kwargs):
        try:
            answers.append(runtime.ask_questions(session_id, [
                {"question": "Enter an answer", "options": []},
            ]))
        except RuntimeError as error:
            errors.append(str(error))
            raise
        return Completion(text="Unexpected answer", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            dialog = await start_request(ui, pilot, QuestionDialog)
            request_id = dialog.request["id"]
            await click_button(ui, pilot, "#question-next")
            assert ui.screen is dialog
            assert await pilot.click("#question-custom")
            await pilot.press(*"Draft", "escape")
            assert dialog.query_one(Input).value == ""
            assert ui.screen is dialog
            assert runtime.pending_questions()[0]["id"] == request_id
            assert not runtime.abort_event(session_id).is_set()
            assert answers == []
            await click_button(ui, pilot, "#question-stop")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert runtime.abort_event(session_id).is_set()
            assert runtime.pending_questions() == []
            assert answers == []
            assert errors == ["Question cancelled: execution stopped; no answer was supplied"]

    asyncio.run(exercise())


def test_double_escape_aborts_the_running_app_turn(runtime, monkeypatch):
    session_id = runtime.create_session()["id"]
    entered = threading.Event()
    cancelled = []
    results = []
    real_prompt = runtime.prompt

    def record_prompt(*args, **kwargs):
        result = real_prompt(*args, **kwargs)
        results.append(result)
        return result

    def respond(**kwargs):
        entered.set()
        cancelled.append(kwargs["abort_event"].wait(10))
        return Completion(text="Provider stopped", finish_reason="stop")

    monkeypatch.setattr(runtime, "prompt", record_prompt)
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test(size=(120, 42)) as pilot:
            ui.query_one(PromptInput).load_text("Wait until cancelled")
            await pilot.press("enter")
            await wait_for(pilot, entered.is_set)
            await pilot.press("escape")
            assert ui.running_session == session_id
            assert not runtime.abort_event(session_id).is_set()
            await pilot.press("escape")
            await wait_for(pilot, lambda: ui.running_session is None)
            assert cancelled == [True]
            assert runtime.abort_event(session_id).is_set()
            assert len(results) == 1
            assert results[0]["status"] == "aborted"
            assert results[0]["text"] == "Stopped: aborted. Work is saved; no completion is claimed."
            assert ui.statuses[session_id] == "idle"

    asyncio.run(exercise())
