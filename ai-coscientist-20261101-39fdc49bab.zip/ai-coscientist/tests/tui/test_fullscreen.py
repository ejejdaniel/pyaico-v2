"""Deterministic terminal interactions; no real provider or external service."""

import asyncio
from types import SimpleNamespace

from textual import events
from textual.widgets import Input, OptionList

from opencode.provider import Completion
from opencode.tui import ChoiceDialog, OpenCodeTUI, PromptInput
from test_prompt_boundary import provider, runtime


def test_home_multiline_input_focus_resize_and_render(runtime):
    async def exercise():
        ui = OpenCodeTUI(runtime, model="test/model")
        async with ui.run_test(size=(140, 42)) as pilot:
            editor = ui.query_one(PromptInput)
            assert editor.has_focus
            assert ui.session_id is None
            assert ui.query_one("#composer").region.width == 75
            await pilot.press("h", "i", "ctrl+j", "x")
            assert editor.text == "hi\nx"
            await pilot.resize_terminal(88, 28)
            assert editor.has_focus and editor.text == "hi\nx"
            assert ui.query_one("#composer").size.width <= 75
            assert not ui.query_one("#sidebar").display
    asyncio.run(exercise())


def test_the_screen_shows_the_co_scientist_name(runtime):
    from opencode import __version__

    async def exercise():
        ui = OpenCodeTUI(runtime, model="test/model")
        async with ui.run_test(size=(140, 42)):
            assert ui.title == "Co-Scientist"
            assert str(ui.query_one("#sidebar-version").render()) == f"Co-Scientist {__version__}"
            logo = str(ui.query_one("#home-logo").render())
            assert len(logo.splitlines()) == 16 and logo.splitlines()[-1].strip() == "Co-Scientist"
    asyncio.run(exercise())


def test_prompt_stream_and_presented_result_are_visible_once(runtime):
    def respond(**kwargs):
        kwargs["on_text"]("Plain ")
        kwargs["on_text"]("answer")
        return Completion(text="Plain answer", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, model="test/model")
        async with ui.run_test(size=(140, 42)) as pilot:
            await pilot.press("H", "i", "enter")
            for _ in range(30):
                await pilot.pause(0.02)
                if ui.running_session is None and ui.session_id:
                    break
            assert ui.session_id
            assert ui.running_session is None
            assert ui.streamed[ui.session_id] == "Plain answer"
            assert len(ui.views[ui.session_id]) == 2
            assert ui.query_one("#sidebar").display
            assert ui.query_one("#sidebar").region.width == 42
            await pilot.resize_terminal(90, 30)
            assert not ui.query_one("#sidebar").display
            await pilot.press("ctrl+x", "b")
            await pilot.pause()
            assert ui.query_one("#sidebar").display
            assert ui.query_one("#sidebar").has_class("overlay")
            assert ui.query_one(PromptInput).text == ""
    asyncio.run(exercise())


def test_command_palette_search_and_dismiss_returns_editor_focus(runtime):
    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test(size=(100, 35)) as pilot:
            await pilot.press("ctrl+p")
            assert isinstance(ui.screen, ChoiceDialog)
            await pilot.press("m", "o", "d", "e", "l")
            assert ui.screen.query_one(OptionList).option_count == 1
            await pilot.press("escape")
            await pilot.pause()
            assert not isinstance(ui.screen, ChoiceDialog)
            assert ui.query_one(PromptInput).has_focus
    asyncio.run(exercise())


def test_existing_permission_callback_is_restored_on_exit(runtime):
    permission = lambda request: "reject"
    question = lambda questions: []
    runtime.permissions.callback, runtime.question_callback = permission, question

    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test() as pilot:
            assert runtime.permissions.callback is None
            assert runtime.question_callback is None
            await pilot.press("ctrl+d")
    asyncio.run(exercise())
    assert runtime.permissions.callback is permission
    assert runtime.question_callback is question


def test_initial_resume_preserves_explicit_cli_selection(runtime):
    session = runtime.create_session(agent="build", model="test/saved")
    other = runtime.create_session(agent="build", model="test/other")

    async def exercise():
        ui = OpenCodeTUI(runtime, agent="plan", model="test/override", session_id=session["id"])
        async with ui.run_test() as pilot:
            assert (ui.agent, ui.model) == ("plan", "test/override")
            await ui.show_session(other["id"])
            assert (ui.agent, ui.model) == ("build", "test/other")
    asyncio.run(exercise())


def test_configured_command_uses_existing_template_and_selected_model(runtime):
    seen = []
    def respond(**kwargs):
        seen.append(kwargs["messages"][-1]["content"])
        return Completion(text="Command answer", finish_reason="stop")
    provider(runtime, respond)
    runtime.config["command"] = {"inspect": {"template": "Inspect $ARGUMENTS", "agent": "build"}}

    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test() as pilot:
            ui.query_one(PromptInput).load_text("/inspect the local files")
            await pilot.press("enter")
            for _ in range(30):
                await pilot.pause(0.02)
                if ui.session_id and ui.running_session is None:
                    break
            assert ui.query_one(PromptInput).text == ""
            assert seen and "Inspect the local files" in str(seen[0])
    asyncio.run(exercise())


def test_chinese_multiline_paste_survives_edit_and_resize(runtime):
    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test(size=(100, 35)) as pilot:
            text = "中文內容保留\n第二行與全形字元"
            ui.post_message(events.Paste(text))
            await pilot.pause()
            editor = ui.query_one(PromptInput)
            assert editor.text == text
            await pilot.press("ctrl+j", "x")
            assert editor.text == text + "\nx"
            await pilot.resize_terminal(60, 24)
            assert editor.text == text + "\nx"
            assert editor.has_focus
    asyncio.run(exercise())
