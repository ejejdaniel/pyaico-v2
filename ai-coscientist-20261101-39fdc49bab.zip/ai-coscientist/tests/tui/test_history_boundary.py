"""Exercise exact saved/live presentation boundaries with the real App loop."""

import asyncio
from io import StringIO
from pathlib import Path
import threading

import pytest
from rich.console import Console

from opencode._tui_presenter import saved_history
from opencode.provider import Completion
from opencode.tui import OpenCodeTUI, PromptInput
from test_prompt_boundary import provider, runtime


def review(runtime):
    from opencode.skills import discover
    runtime.config["skills"] = {"paths": [str(Path(__file__).resolve().parents[2] / "src/opencode/skill_assets")]}
    runtime.skills = discover(runtime.directory, runtime.worktree, runtime.config)
    runtime.agents["build"].options["answer_review_skill"] = "investigate"
    runtime.agents["build"].steps = 8


def rendered(ui, session_id):
    output = StringIO()
    console = Console(file=output, width=120, color_system=None)
    for item in ui.views.get(session_id, []):
        console.print(item)
    return output.getvalue()


def test_active_child_is_not_hydrated_before_review_marker_is_written(runtime):
    review(runtime)
    parent = runtime.create_session()["id"]
    child = runtime.store.create_session(directory=str(runtime.directory), agent="build", model=None,
                                         parent_id=parent)["id"]
    entered, release = threading.Event(), threading.Event()
    calls, errors = [], []

    def respond(**kwargs):
        calls.append(True)
        if len(calls) == 1:
            kwargs["on_text"]("PRIVATE_DRAFT")
            entered.set()
            assert release.wait(5)
            return Completion(text="PRIVATE_DRAFT", finish_reason="stop")
        return Completion(text="CHECKED_ANSWER", finish_reason="stop")

    provider(runtime, respond)
    def child_work():
        try:
            runtime.prompt(child, "Test the child history boundary", _parent_id=parent)
        except BaseException as error:
            errors.append(error)
    thread = threading.Thread(target=child_work)
    thread.start()
    assert entered.wait(3)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=parent)
        async with ui.run_test(size=(120, 40)) as pilot:
            assert runtime.store.messages(child)[-1]["content"] == "PRIVATE_DRAFT"
            assert "answer_review_role" not in runtime.store.messages(child)[-1]
            await ui.show_session(child)
            assert child not in ui.views
            assert "PRIVATE_DRAFT" not in ui.export_screenshot()
            release.set()
            for _ in range(100):
                await pilot.pause(0.02)
                if child in ui.views:
                    break
            assert "CHECKED_ANSWER" in rendered(ui, child)
            assert "PRIVATE_DRAFT" not in rendered(ui, child)
    try:
        asyncio.run(exercise())
    finally:
        release.set()
        thread.join(3)
    assert not thread.is_alive() and not errors


@pytest.mark.parametrize("failure", [RuntimeError("controlled failure"), KeyboardInterrupt()])
def test_failed_review_history_keeps_error_without_undelivered_partial(runtime, failure):
    review(runtime)
    session_id = runtime.create_session()["id"]
    live = []
    def respond(**kwargs):
        kwargs["on_text"]("PRIVATE_INTERRUPTED_DRAFT")
        raise failure
    provider(runtime, respond)
    with pytest.raises(type(failure)):
        runtime.prompt(session_id, "Inspect the interruption boundary", on_text=live.append)
    original = runtime.store.messages(session_id)[-1]
    assert original["content"] == "PRIVATE_INTERRUPTED_DRAFT"
    assert original.get("answer_review_role") is None
    assert live == []
    assert saved_history(runtime.store, session_id)[-1]["content"] == ""

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test() as pilot:
            text = rendered(ui, session_id)
            assert "PRIVATE_INTERRUPTED_DRAFT" not in text
            assert original["error"] in text
    asyncio.run(exercise())
    assert runtime.store.messages(session_id)[-1] == original


def test_ui_delivers_app_presenter_document_absent_from_saved_prose(runtime):
    class Presenter:
        def context(self):
            return ""
        def feedback(self):
            return None
        def present(self, text, status):
            return "FROZEN_DOCUMENT\n\n" + text
    runtime.turn_extension_factory = lambda *_: Presenter()
    def respond(**kwargs):
        kwargs["on_text"]("Model explanation")
        return Completion(text="Model explanation", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test(size=(120, 40)) as pilot:
            ui.query_one(PromptInput).load_text("Render the returned document")
            await pilot.press("enter")
            for _ in range(100):
                await pilot.pause(0.02)
                if ui.session_id and ui.running_session is None:
                    break
            assert "FROZEN_DOCUMENT" in rendered(ui, ui.session_id)
            assert "FROZEN_DOCUMENT" not in runtime.store.messages(ui.session_id)[-1]["content"]
            await ui.show_session(None)
            await ui.show_session(next(iter(ui.views)))
            assert "FROZEN_DOCUMENT" in rendered(ui, ui.session_id)
    asyncio.run(exercise())
