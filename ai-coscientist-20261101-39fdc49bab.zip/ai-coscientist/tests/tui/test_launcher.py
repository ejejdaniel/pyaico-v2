"""Offline checks of the Co-Scientist launcher's configuration handoff.

Temporary configuration fixtures are protocol tests, not research evidence.
The real loader and composer run; App and the fullscreen UI are replaced before
they can create sessions, start background work, or call a model.
"""

import builtins
from copy import deepcopy
import json
import os
from pathlib import Path
import socket
import sys
from types import SimpleNamespace

import pytest

from opencode import app as app_module, tui
from opencode.agent import build_agents, default_agent_name
from opencode.config import load_config
from scripts import run_tui


PROJECT = Path(__file__).resolve().parents[2]


def guides():
    import planningkit
    import researchkit
    return [str(Path(researchkit.__file__).parent / "skills" / "research-practice" / "SKILL.md"),
            str(Path(planningkit.__file__).parent / "skills" / "work-planning" / "SKILL.md")]



def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


@pytest.fixture
def launch(tmp_path, monkeypatch):
    for key in (
        "OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_CONFIG_DIR",
        "OPENCODE_PERMISSION", "OPENCODE_DISABLE_PROJECT_CONFIG", "OPENCODE_PURE",
        "LOCAL_OPENAI_API_KEY",
    ):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OPENCODE_MODEL", "ambient/should-not-be-selected")
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    for kind in ("CONFIG", "DATA", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{kind}_HOME", str(tmp_path / kind.lower()))
    class TerminalStreams:
        stdin = SimpleNamespace(isatty=lambda: True)
        stdout = SimpleNamespace(isatty=lambda: True)

        def __getattr__(self, name):
            # Pytest swaps capture streams between setup and execution. Keep
            # diagnostics on the active capture stream while controlling TTYs.
            return getattr(sys, name)

    monkeypatch.setattr(run_tui, "sys", TerminalStreams())

    def forbid_network(*_args, **_kwargs):
        raise AssertionError("Offline launcher test attempted a network connection")

    monkeypatch.setattr(socket.socket, "connect", forbid_network)
    monkeypatch.setattr(socket.socket, "connect_ex", forbid_network)
    root = tmp_path / "managed launcher"
    source = json.loads((PROJECT / "config/llm.opencode.json").read_text(encoding="utf-8"))
    config_path = root / "config/llm.opencode.json"
    write_json(config_path, source)
    monkeypatch.setattr(run_tui, "PROJECT_ROOT", root)
    monkeypatch.chdir(root)  # the launcher opens the current folder unless given one
    apps, calls = [], []

    class ObservedApp:
        def __init__(self, directory, *, config):
            self.directory = directory
            self.config = config
            self.agents = build_agents(config, worktree=directory)
            self.default_agent = default_agent_name(config, self.agents)
            apps.append(self)

    monkeypatch.setattr(app_module, "App", ObservedApp)
    monkeypatch.setattr(tui, "run", lambda app, args, **kwargs: calls.append((app, args, kwargs)))
    return SimpleNamespace(root=root, config_path=config_path, source=source,
                           apps=apps, calls=calls)


def test_default_root_is_the_launcher_worktree():
    assert run_tui.PROJECT_ROOT == PROJECT


def test_default_directory_is_the_current_folder_with_the_canonical_configuration(
    launch, tmp_path, monkeypatch,
):
    caller = tmp_path / "unrelated caller"
    caller.mkdir()
    monkeypatch.chdir(caller)

    assert run_tui.main([]) == 0

    assert Path.cwd() == caller
    app, args, kwargs = launch.calls[0]
    assert launch.apps == [app]
    assert app.directory == caller.resolve()
    assert kwargs == {}  # No automatic session restoration.
    # Expected values are the canonical config's own (launch.source), whatever they are.
    root = launch.source["model"]
    assert (args.agent, args.model) == ("build", root)
    assert vars(args) == {"agent": "build", "model": root, "deep": False}  # deep research off unless asked
    expected = launch.source["provider"]["local"]["models"][root.split("/", 1)[1]]
    model = app.config["provider"]["local"]["models"][root.split("/", 1)[1]]
    assert model["options"]["reasoningEffort"] == expected["options"]["reasoningEffort"]
    assert model["limit"]["output"] == expected["limit"]["output"]
    assert app.config["provider"]["local"]["options"]["apiKey"] == "local"
    assert {name: app.agents[name].temperature for name in launch.source["agent"]} == {
        name: agent["temperature"] for name, agent in launch.source["agent"].items()}


@pytest.mark.parametrize("relative", [False, True])
def test_dir_uses_caller_path_but_keeps_launcher_model_source(
    launch, tmp_path, monkeypatch, relative,
):
    caller = tmp_path / "caller"
    workspace = caller / "work with spaces"
    workspace.mkdir(parents=True)
    # A competing file in the target workspace must not become the authority.
    write_json(workspace / "config/llm.opencode.json", {"invalid": "unused fixture"})
    write_json(workspace / "opencode.json", {"instructions": ["workspace-guide.md"]})
    monkeypatch.chdir(caller)
    argument = workspace.name if relative else str(workspace)

    assert run_tui.main(["--dir", argument]) == 0
    assert run_tui.main([argument]) == 0

    app, args, _ = launch.calls[0]
    assert launch.calls[1][0].directory == app.directory == workspace.resolve()
    assert app.config["instructions"] == ["workspace-guide.md"] and app.config["deep"]["instructions"] == guides()
    assert args.model == launch.source["model"]
    assert Path.cwd() == caller


def test_managed_fields_replace_all_normal_overrides_without_losing_other_settings(
    launch, tmp_path, monkeypatch, capsys,
):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    global_config = tmp_path / "config/opencode/opencode.json"
    write_json(global_config, {
        "model": "old/global",
        "provider": {"old": {"options": {"apiKey": "old-secret-never-log"}}},
        "enabled_providers": ["old"],
        "agent": {"build": {"model": "old/build", "temperature": 0.8,
                             "prompt": "Preserve the workspace prompt."}},
        "permission": {"bash": "ask"},
        "instructions": ["global-guide.md"],
    })
    custom = tmp_path / "custom.json"
    write_json(custom, {"model": "old/custom", "instructions": ["custom-guide.md"]})
    monkeypatch.setenv("OPENCODE_CONFIG", str(custom))
    write_json(workspace / "opencode.json", {
        "model": "old/project", "disabled_providers": ["local"],
        "agent": {"researcher": {"model": "old/researcher", "temperature": 1,
                                  "description": "Offline configuration fixture."}},
        "instructions": ["project-guide.md"], "tools": {"webfetch": False},
        "command": {"inspect": {"model": "old/command", "template": "Inspect."}},
    })
    write_json(workspace / ".opencode/opencode.json", {
        "model": "old/dot-directory", "permission": {"edit": "deny"},
        "instructions": ["dot-guide.md"],
    })
    monkeypatch.setenv("OPENCODE_CONFIG_CONTENT", json.dumps({
        "model": "old/content", "agent": {"build": {"temperature": 0.9}},
        "instructions": ["content-guide.md"],
    }))
    monkeypatch.setenv("OPENCODE_PERMISSION", '{"read":"allow"}')
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", "current-secret-never-log")
    before = load_config(workspace)
    assert before["model"] == "old/content"
    assert before["agent"]["build"]["temperature"] == 0.9

    assert run_tui.main(["--dir", str(workspace)]) == 0

    app, args, _ = launch.calls[0]
    assert args.model == launch.source["model"]
    assert set(app.config["provider"]) == {"local"}
    assert "enabled_providers" not in app.config
    assert "disabled_providers" not in app.config
    assert app.config["agent"]["build"] == {
        "temperature": launch.source["agent"]["build"]["temperature"], "prompt": "Preserve the workspace prompt.",
    }
    assert app.config["agent"]["researcher"] == {
        "description": "Offline configuration fixture.",
    }
    for key in ("permission", "tools", "command"):
        assert app.config[key] == before[key]
    assert app.config["permission"] == {"bash": "ask", "edit": "deny", "read": "allow"}
    assert app.config["instructions"] == [
        "global-guide.md", "custom-guide.md", "project-guide.md", "dot-guide.md", "content-guide.md",
    ]
    assert app.config["deep"]["instructions"] == guides()
    assert app.config["provider"]["local"]["options"]["apiKey"] == "current-secret-never-log"
    output = capsys.readouterr()
    assert "old-secret-never-log" not in output.out + output.err
    assert "current-secret-never-log" not in output.out + output.err


def test_selected_default_agent_explicit_model_reaches_tui(launch):
    fragment = deepcopy(launch.source)
    fragment["provider"]["local"]["models"]["offline-plan"] = deepcopy(
        fragment["provider"]["local"]["models"][fragment["model"].split("/", 1)[1]])
    fragment["agent"]["plan"]["model"] = "local/offline-plan"
    write_json(launch.config_path, fragment)
    write_json(launch.root / "opencode.json", {"default_agent": "plan"})

    assert run_tui.main([]) == 0

    app, args, _ = launch.calls[0]
    assert (app.default_agent, args.agent, args.model) == ("plan", "plan", "local/offline-plan")


@pytest.mark.parametrize("existing", ["already-provided", ""])
def test_existing_local_credential_is_preserved(launch, monkeypatch, existing):
    monkeypatch.setenv("LOCAL_OPENAI_API_KEY", existing)

    assert run_tui.main([]) == 0

    assert os.environ["LOCAL_OPENAI_API_KEY"] == existing
    assert launch.apps[0].config["provider"]["local"]["options"]["apiKey"] == existing


def test_file_placeholder_resolves_from_selected_config_directory(launch, tmp_path, capsys):
    fragment = deepcopy(launch.source)
    fragment["provider"]["local"]["options"]["apiKey"] = "{file:credential.txt}"
    write_json(launch.config_path, fragment)
    (launch.config_path.parent / "credential.txt").write_text("selected-file-secret", encoding="utf-8")
    workspace = tmp_path / "separate workspace"
    workspace.mkdir()
    (workspace / "credential.txt").write_text("wrong-directory-secret", encoding="utf-8")

    assert run_tui.main(["--dir", str(workspace)]) == 0

    assert launch.apps[0].config["provider"]["local"]["options"]["apiKey"] == "selected-file-secret"
    output = capsys.readouterr()
    assert "selected-file-secret" not in output.out + output.err


@pytest.mark.parametrize("stream", ["stdin", "stdout"])
def test_nonterminal_fails_before_app_or_model_configuration(launch, monkeypatch, capsys, stream):
    monkeypatch.setattr(getattr(run_tui.sys, stream), "isatty", lambda: False)
    launch.config_path.unlink()  # Terminal validation must precede this error.

    assert run_tui.main([]) != 0

    assert not launch.apps and not launch.calls
    assert "終端" in capsys.readouterr().err


def test_a_file_is_refused_and_a_missing_folder_is_created(launch, tmp_path, capsys):
    target = tmp_path / "invalid workspace"
    target.write_text("This is a file.", encoding="utf-8")

    assert run_tui.main([str(target)]) != 0

    assert not launch.apps and not launch.calls
    assert str(target) in capsys.readouterr().err
    study = tmp_path / "new study" / "photoresist"
    assert run_tui.main([str(study)]) == 0
    assert study.is_dir() and launch.apps[0].directory == study.resolve()


def test_every_folder_gets_the_research_capabilities_without_copies(launch, tmp_path):
    # One entry for every task: the research skills, tools and guides come from this installation, as deep
    # research, which a task has while it is turned on (opencode/deep.py).
    import researchkit
    folder = tmp_path / "ordinary project"
    folder.mkdir()

    assert run_tui.main([str(folder)]) == 0

    config = launch.apps[0].config
    deep = config["deep"]
    assert str(Path(researchkit.__file__).parent / "skills") in deep["skills"]
    assert deep["tool_modules"] == ["researchkit.planning_adapter"] and deep["instructions"] == guides()
    assert "tool_modules" not in config and config.get("instructions") == []
    assert config["tool_output"] == {"max_bytes": 16 * 1024}
    from opencode.deep import load
    installed = load(folder, folder, config)
    assert {tool.name for tool in installed.tools} >= {"research_record", "planning_update"}
    assert installed.extension is not None and {"research-practice", "work-planning"} - set(installed.skills) == set()
    assert list(folder.iterdir()) == []  # nothing is written into the folder


def test_a_folder_from_the_earlier_installer_keeps_its_tools_and_uses_the_current_guides(launch, tmp_path):
    folder = tmp_path / "old study"
    write_json(folder / ".opencode/opencode.json", {"instructions": [
        ".opencode/skills/research-practice/SKILL.md", ".opencode/skills/work-planning/SKILL.md", "notes.md"]})
    (folder / ".opencode/tools").mkdir(parents=True)
    (folder / ".opencode/tools/research.py").write_text(
        "from researchkit.planning_adapter import TOOLS, TURN_EXTENSION\n", encoding="utf-8")

    assert run_tui.main([str(folder)]) == 0

    config = launch.apps[0].config
    assert "tool_modules" not in config and config["deep"]["tool_modules"] == []  # the folder's own tools load
    assert config["instructions"] == ["notes.md"] and config["deep"]["instructions"] == guides()


def test_tools_from_a_folder_file_and_a_configured_module_load_once(tmp_path):
    from researchkit import planning_adapter
    (tmp_path / ".opencode/tools").mkdir(parents=True)
    (tmp_path / ".opencode/tools/research.py").write_text(
        "from researchkit.planning_adapter import TOOLS, TURN_EXTENSION\n", encoding="utf-8")
    tools, factory = app_module._load_local_tools(tmp_path, ["researchkit.planning_adapter"])
    assert factory is planning_adapter.TURN_EXTENSION
    assert [t.name for t in tools] == [t.name for t in planning_adapter.TOOLS]
    with pytest.raises(RuntimeError, match="Cannot load configured tool module no_such_module"):
        app_module._load_local_tools(tmp_path / "empty", ["no_such_module"])


@pytest.mark.parametrize("content,diagnostic", [
    (None, "Unable to read UTF-8 JSON LLM configuration"),
    ("{broken JSON", "Unable to read UTF-8 JSON LLM configuration"),
    ('{"model":"local/missing","provider":{}}', "explicit provider model definition"),
])
def test_missing_or_invalid_model_configuration_has_no_fallback(launch, capsys, content, diagnostic):
    if content is None:
        launch.config_path.unlink()
    else:
        launch.config_path.write_text(content, encoding="utf-8")

    assert run_tui.main([]) != 0

    assert not launch.apps and not launch.calls
    error = capsys.readouterr().err
    assert "Co-Scientist 啟動失敗" in error
    assert diagnostic in error


def test_invalid_workspace_configuration_fails_before_app(launch, capsys):
    write_json(launch.root / "opencode.json", {"compaction": {"tail_turns": -1}})

    assert run_tui.main([]) != 0

    assert not launch.apps and not launch.calls
    assert "compaction.tail_turns" in capsys.readouterr().err


def test_missing_ui_dependency_is_reported_before_app(launch, monkeypatch, capsys):
    original = builtins.__import__

    def without_tui(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "opencode" and "tui" in fromlist:
            raise ModuleNotFoundError("No module named 'textual'", name="textual")
        return original(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", without_tui)

    assert run_tui.main([]) != 0

    assert not launch.apps and not launch.calls
    assert "textual" in capsys.readouterr().err


# --prompt (unattended runs) and --llm-config joined the entry when it became the one entry for every task
# (2026-10-31); a model, agent or session still cannot be chosen around the configuration.
@pytest.mark.parametrize("option", ["--model", "--agent", "--session"])
def test_unapproved_options_are_rejected_before_app(launch, capsys, option):
    with pytest.raises(SystemExit) as error:
        run_tui.main([option, "unused"])

    assert error.value.code != 0
    assert not launch.apps and not launch.calls
    assert option in capsys.readouterr().err


def test_help_is_available_without_a_terminal_or_configuration(launch, monkeypatch, capsys):
    launch.config_path.unlink()
    monkeypatch.setattr(run_tui.sys.stdin, "isatty", lambda: False)

    with pytest.raises(SystemExit) as error:
        run_tui.main(["--help"])

    assert error.value.code == 0
    assert not launch.apps and not launch.calls
    assert "folder" in capsys.readouterr().out


def test_a_folders_own_tool_files_are_named_before_they_load(tmp_path):
    # They run inside the framework's own process; the installed research stub is not the folder's own.
    assert run_tui.folder_tool_warning(tmp_path) is None
    tools = tmp_path / ".opencode/tools"
    tools.mkdir(parents=True)
    (tools / "research.py").write_bytes(b"from researchkit.tools import TOOLS, TURN_EXTENSION\n")
    assert run_tui.folder_tool_warning(tmp_path) is None
    (tools / "mine.py").write_text("TOOLS = []\n", encoding="utf-8")
    warning = run_tui.folder_tool_warning(tmp_path)
    assert ".opencode/tools/mine.py" in warning and "research.py" not in warning
