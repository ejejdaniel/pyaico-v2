"""Cancellation boundaries use real App ownership, with deterministic transport."""

import asyncio
import threading

from opencode.provider import Completion
from opencode.tui import OpenCodeTUI, PromptInput
from test_prompt_boundary import provider, runtime


async def wait_for(pilot, predicate):
    for _ in range(150):
        if predicate():
            return
        await pilot.pause(0.02)
    assert predicate()


def test_exit_cancels_owned_background_after_foreground_return(runtime):
    root = runtime.create_session()["id"]
    child = runtime.store.create_session(directory=str(runtime.directory), agent="build", model=None,
                                         parent_id=root)["id"]
    unrelated = runtime.create_session()["id"]
    entered, unrelated_entered = threading.Event(), threading.Event()
    child_cancelled, unrelated_cancelled = [], []

    def respond(**kwargs):
        text = str(kwargs["messages"][-1]["content"])
        if "child fixture" in text:
            entered.set()
            child_cancelled.append(kwargs["abort_event"].wait(10))
        elif "unrelated fixture" in text:
            unrelated_entered.set()
            unrelated_cancelled.append(kwargs["abort_event"].wait(10))
        else:
            runtime.spawn_background(child, "child fixture", "build", 1, root, _notify=False)
            assert entered.wait(3)
        return Completion(text="Fixture transport returned", finish_reason="stop")

    provider(runtime, respond)
    unrelated_thread = threading.Thread(target=lambda: runtime.prompt(unrelated, "unrelated fixture"))
    unrelated_thread.start()
    assert unrelated_entered.wait(3)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=root)
        async with ui.run_test(size=(120, 40)) as pilot:
            ui.query_one(PromptInput).load_text("Start the owned work")
            await pilot.press("enter")
            await wait_for(pilot, lambda: entered.is_set() and ui.running_session is None)
            assert child in runtime._background
            assert ui.owned_work_active()
            await pilot.press("ctrl+d")
            await wait_for(pilot, lambda: child not in runtime._background)
            assert child_cancelled == [True]
            assert not runtime.abort_event(unrelated).is_set()
            assert unrelated_cancelled == []
        assert runtime.permissions.callback is None
    try:
        asyncio.run(exercise())
    finally:
        runtime.abort(unrelated)
        unrelated_thread.join(3)
    assert not unrelated_thread.is_alive()


def test_exit_during_prompt_registration_reaches_fresh_abort_event(runtime, monkeypatch):
    session_id = runtime.create_session()["id"]
    before_registration, release, provider_entered = threading.Event(), threading.Event(), threading.Event()
    cancelled = []
    real_prompt = runtime.prompt
    def delayed_prompt(*args, **kwargs):
        before_registration.set()
        assert release.wait(5)
        return real_prompt(*args, **kwargs)
    monkeypatch.setattr(runtime, "prompt", delayed_prompt)
    def respond(**kwargs):
        provider_entered.set()
        cancelled.append(kwargs["abort_event"].wait(5))
        return Completion(text="Stopped fixture", finish_reason="stop")
    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=session_id)
        async with ui.run_test() as pilot:
            ui.query_one(PromptInput).load_text("Pause before registration")
            await pilot.press("enter")
            await wait_for(pilot, before_registration.is_set)
            assert session_id not in runtime._running
            await pilot.press("ctrl+d")
            assert ui._exit_requested and runtime.abort_event(session_id).is_set()
            release.set()
            await wait_for(pilot, lambda: ui.running_session is None)
            # A stop can be caught by the loop before transport or by the
            # transport Event after registration; either path must terminate.
            assert not provider_entered.is_set() or cancelled == [True]
            assert runtime.abort_event(session_id).is_set()
    try:
        asyncio.run(exercise())
    finally:
        release.set()
