"""Presentation boundaries only; these checks do not use a model or a terminal."""

from io import StringIO

from rich.console import Console

from opencode._tui_presenter import final_response, message_renderable, visible_history


def test_frozen_delivery_from_prompt_result_is_not_replaced_by_stored_prose():
    messages = [{"id": "source", "role": "assistant", "content": "Work finished."}]
    result = {"text": "Frozen document\n\nWork finished.", "messageID": "source", "status": "completed"}
    assert final_response(result, messages) == result["text"]


def test_plain_answer_with_exact_saved_source_is_not_repeated():
    messages = [{"id": "source", "role": "assistant", "content": "Plain answer"}]
    assert final_response({"text": "Plain answer", "messageID": "source"}, messages) == ""


def test_same_suffix_does_not_hide_a_different_official_delivery():
    messages = [{"id": "source", "role": "assistant", "content": "Longer answer"}]
    assert final_response({"text": "answer", "messageID": "source"}, messages) == "answer"


def test_another_message_with_equal_text_does_not_identify_the_source():
    messages = [{"id": "later", "role": "assistant", "content": "Plain answer"}]
    assert final_response({"text": "Plain answer", "messageID": "earlier"}, messages) == "Plain answer"
    assert final_response({"text": "Plain answer", "messageID": None}, messages) == "Plain answer"


def test_source_need_not_be_the_last_message_and_drafts_never_deduplicate():
    source = {"id": "source", "role": "assistant", "content": "Earlier answer"}
    messages = [source, {"id": "later", "role": "assistant", "content": "Later answer"}]
    assert final_response({"text": "Earlier answer", "messageID": "source"}, messages) == ""
    assert final_response({"text": "Earlier answer", "messageID": "source"},
                          [dict(source, answer_review_role="draft")]) == "Earlier answer"


def test_stopped_result_is_displayed_verbatim_without_claiming_completion():
    text = "Stopped: aborted. Work is saved; no completion is claimed."
    messages = [{"role": "assistant", "content": "partial", "error": "aborted"}]
    assert final_response({"text": text, "status": "aborted", "messageID": None}, messages) == text


def test_saved_draft_is_hidden_but_authoritative_host_notice_and_answer_remain():
    draft = {"role": "assistant", "content": "PRIVATE_DRAFT", "answer_review_role": "draft"}
    notice = {"role": "assistant", "content": "Checking", "synthetic": True}
    answer = {"role": "assistant", "content": "Answer", "answer_review_role": "answer"}
    messages = [draft, notice, answer]
    assert visible_history(messages) == [notice, answer]
    assert messages == [draft, notice, answer]


def test_tool_title_and_output_are_literal_text_not_rich_markup():
    output = StringIO()
    console = Console(file=output, width=100, color_system=None)
    console.print(message_renderable({"role": "tool", "title": "[red]literal[/red]", "content": "[bold]source[/bold]"}))
    assert "[red]literal[/red]" in output.getvalue()
    assert "[bold]source[/bold]" in output.getvalue()
