"""Real App/loop presentation boundaries with scripted transport, no model calls."""

from pathlib import Path
from types import SimpleNamespace

import pytest

from opencode._tui_presenter import final_response, visible_history
from opencode.app import App
from opencode.provider import Completion
from opencode.store import Store


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    for key in ("OPENCODE_TEST_HOME", "OPENCODE_CONFIG_DIR", "XDG_CONFIG_HOME",
                "XDG_DATA_HOME", "XDG_STATE_HOME", "XDG_CACHE_HOME"):
        monkeypatch.setenv(key, str(tmp_path / key))
    project = tmp_path / "project"
    project.mkdir()
    (project / ".git").mkdir()
    instance = App(project, store=Store(tmp_path / "session.db"), auto_approve=True, config={})
    instance.generate_titles = False
    monkeypatch.setattr(instance, "ensure_mcp", lambda: None)
    yield instance
    instance.store.close()


def provider(runtime, respond):
    runtime.provider = SimpleNamespace(
        resolve=lambda _: (SimpleNamespace(id="test", context=200000), "test"),
        complete=respond,
    )


def test_live_text_uses_app_callback_and_final_uses_presenter_result(runtime):
    session_id = runtime.create_session()["id"]
    live = []

    class InstalledPresenter:
        def context(self):
            return ""

        def feedback(self):
            return None

        def present(self, text, status):
            assert status == "completed"
            return "FROZEN_DOCUMENT\n\n" + text

    runtime.turn_extension_factory = lambda *_: InstalledPresenter()

    def respond(**kwargs):
        kwargs["on_text"]("Model explanation")
        return Completion(text="Model explanation", finish_reason="stop")

    provider(runtime, respond)
    result = runtime.prompt(session_id, "Render the returned document", on_text=live.append)
    saved = runtime.store.messages(session_id)

    assert "".join(live) == "Model explanation"
    assert saved[-1]["content"] == "Model explanation"
    assert "FROZEN_DOCUMENT" not in saved[-1]["content"]
    assert final_response(result, saved) == "FROZEN_DOCUMENT\n\nModel explanation"


def test_review_draft_update_can_precede_its_marker_but_never_reaches_live_callback(runtime):
    # Use the same installed review skill and runtime option as existing CLI
    # coverage; the transport below is an explicit, isolated test double.
    runtime.config["skills"] = {"paths": [str(Path(__file__).resolve().parents[2] / "src/opencode/skill_assets")]}
    from opencode.skills import discover
    runtime.skills = discover(runtime.directory, runtime.worktree, runtime.config)
    runtime.agents["build"].options["answer_review_skill"] = "investigate"
    runtime.agents["build"].steps = 8
    session_id = runtime.create_session()["id"]
    live = []
    seen = []
    box = runtime.bus.subscribe()

    def respond(**kwargs):
        if not seen:
            kwargs["on_text"]("PRIVATE_DRAFT")
            in_flight = runtime.store.messages(session_id)[-1]
            assert in_flight["content"] == "PRIVATE_DRAFT"
            assert "answer_review_role" not in in_flight
            assert not live
            events = []
            while not box.empty():
                events.append(box.get_nowait())
            assert any(event["type"] == "message.updated" for event in events)
            seen.append("draft")
            return Completion(text="PRIVATE_DRAFT", finish_reason="stop")
        seen.append("answer")
        return Completion(text="CHECKED_ANSWER", finish_reason="stop")

    provider(runtime, respond)
    try:
        result = runtime.prompt(session_id, "Inspect the presentation boundary", on_text=live.append)
    finally:
        runtime.bus.unsubscribe(box)

    saved = runtime.store.messages(session_id)
    assert seen == ["draft", "answer"]
    assert "PRIVATE_DRAFT" not in "".join(live)
    assert all(message.get("content") != "PRIVATE_DRAFT" for message in visible_history(saved))
    assert final_response(result, saved) == ""
