"""The TUI's search switches hide search tools from the model; no model or network calls."""

import asyncio
from opencode import search_switch
from opencode.provider import Completion
from opencode.tools import extra
from opencode.loop import ToolContext
from opencode.tui import ChoiceDialog, OpenCodeTUI, PromptInput
from test_dialogs import wait_for
from test_prompt_boundary import provider, runtime


def test_switches_round_trip_through_session_rules_and_keep_other_rules():
    other = {"permission": "read", "pattern": "*", "action": "deny"}
    rules = search_switch.apply([other], {"web": False, "literature": True, "private": False})
    assert other in rules
    assert search_switch.states(rules) == {"web": False, "literature": True, "private": False}
    assert search_switch.states(search_switch.apply(rules, {})) == {g: True for g in search_switch.GROUPS}
    assert search_switch.denied(rules) == search_switch.apply([], search_switch.states(rules))
    assert other not in search_switch.denied(rules)


def offered(seen):
    return {tool["name"] for tool in seen[-1]}


def test_slash_search_off_hides_the_tools_from_the_next_prompt_and_on_brings_them_back(runtime):
    seen = []

    def respond(**kwargs):
        seen.append(kwargs.get("tools") or [])
        return Completion(text="done", finish_reason="stop")

    provider(runtime, respond)

    async def exercise():
        ui = OpenCodeTUI(runtime)
        async with ui.run_test(size=(120, 42)) as pilot:
            editor = ui.query_one(PromptInput)
            editor.load_text("/search web off")
            await pilot.press("enter")
            assert ui.search["web"] is False
            editor.load_text("first question")
            await pilot.press("enter")
            await wait_for(pilot, lambda: seen and ui.running_session is None)
            assert "webfetch" not in offered(seen) and "read" in offered(seen)
            session = runtime.store.get_session(ui.session_id)
            assert search_switch.states(session["permission"])["web"] is False

            editor.load_text("/search all on")
            await pilot.press("enter")
            editor.load_text("second question")
            await pilot.press("enter")
            await wait_for(pilot, lambda: len(seen) == 2 and ui.running_session is None)
            assert "webfetch" in offered(seen)

            editor.load_text("/search web maybe")
            await pilot.press("enter")
            assert editor.text == "/search web maybe"

    asyncio.run(exercise())


def test_the_search_dialog_toggles_a_switch_and_shows_it(runtime):
    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=runtime.create_session()["id"])
        async with ui.run_test(size=(120, 42)) as pilot:
            editor = ui.query_one(PromptInput)
            editor.load_text("/search")
            await pilot.press("enter")
            await wait_for(pilot, lambda: isinstance(ui.screen, ChoiceDialog))
            await pilot.press("down", "enter")
            await wait_for(pilot, lambda: ui.search["literature"] is False and isinstance(ui.screen, ChoiceDialog))
            await pilot.press("escape")
            assert "已關閉：文獻搜尋" in str(ui.query_one("#model-line").render())
            permission = runtime.store.get_session(ui.session_id)["permission"]
            assert search_switch.states(permission) == {"web": True, "literature": False, "private": True}

    asyncio.run(exercise())


def test_a_resumed_subagent_follows_the_parents_current_switches(runtime, monkeypatch):
    parent = runtime.create_session()
    child = runtime.create_session(permission=search_switch.apply([], {"web": False}))
    runtime.store.update_session(parent["id"], permission=search_switch.apply([], {"private": False}))
    monkeypatch.setattr(runtime, "run_prompt", lambda *a, **k: {"text": "ok", "status": "completed"})
    ctx = ToolContext(runtime, parent["id"], runtime.agents["build"], None, "call", 0, runtime.directory,
                      runtime.worktree, set(), 0)
    extra._task({"description": "d", "prompt": "p", "subagent_type": "general", "task_id": child["id"]}, ctx)
    assert search_switch.states(runtime.store.get_session(child["id"])["permission"]) == {
        "web": True, "literature": True, "private": False}
