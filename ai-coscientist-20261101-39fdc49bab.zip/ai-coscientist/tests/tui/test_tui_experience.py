"""Tool cards, running status, queued prompts and streaming cost.

Real App and loop with a scripted transport; no model is called.
"""

import asyncio
import threading
from io import StringIO

from rich.console import Console
from rich.text import Text

from opencode._tui_presenter import (ERROR, SUCCESS, TOOL_PREVIEW_LINES, ToolCard, message_renderable,
                                     with_tool_inputs)
from opencode.provider import Completion, ToolCall
from opencode.tui import (LiveMarkdown, OpenCodeTUI, PromptInput, QueueBar, ToolCardView, markdown_split,
                          token_summary)
from test_prompt_boundary import provider, runtime


def plain(renderable, width=120):
    output = StringIO()
    Console(file=output, width=width, color_system=None).print(renderable)
    return output.getvalue()


async def wait_for(pilot, predicate, steps=200):
    for _ in range(steps):
        if predicate():
            return
        await pilot.pause(0.02)
    assert predicate()


def footer(ui):
    return str(ui.query_one("#footer").content)


# --- tool cards -----------------------------------------------------------------

def test_tool_card_summary_names_tool_argument_and_line_count_then_collapses():
    output = "\n".join(f"line {index}" for index in range(30))
    card = message_renderable({"role": "tool", "name": "bash", "title": "ls", "content": output,
                               "input": {"command": "ls -la", "description": "list"}})
    assert isinstance(card, ToolCard)
    text = plain(card)
    first = text.splitlines()[0]
    assert "bash" in first and "ls -la" in first and "30 行" in first
    assert f"line {TOOL_PREVIEW_LINES - 1}" in text and f"line {TOOL_PREVIEW_LINES}" not in text
    assert f"還有 {30 - TOOL_PREVIEW_LINES} 行" in text
    card.expanded = True
    assert "line 29" in plain(card) and "還有" not in plain(card)


def test_short_output_is_not_collapsible_and_title_stands_in_without_arguments():
    card = message_renderable({"role": "tool", "title": "[red]literal[/red]", "content": "one\ntwo"})
    assert not card.collapsible
    assert "[red]literal[/red]" in plain(card) and "還有" not in plain(card)


def test_edit_card_shows_coloured_diff_from_call_arguments():
    card = message_renderable({"role": "tool", "name": "edit", "title": "a.py", "content": "Edit applied successfully.",
                               "input": {"filePath": "a.py", "oldString": "x = 1\ny = 2", "newString": "x = 1\ny = 3"}})
    summary = card.summary()
    assert "+1" in summary.plain and "-1" in summary.plain and "a.py" in summary.plain
    body = card.__rich__().renderables[1].renderable
    assert isinstance(body, Text)
    styles = {body.plain[span.start:span.end].strip(): span.style for span in body.spans}
    assert styles["+y = 3"] == SUCCESS and styles["-y = 2"] == ERROR


def test_write_card_shows_new_content_as_additions_and_errors_show_message_not_diff():
    write = ToolCard("write", "b.txt", "Wrote file successfully.", {}, {"filePath": "b.txt", "content": "a\nb\nc"})
    assert "+3" in write.summary().plain and "-0" in write.summary().plain
    failed = ToolCard("edit", "", "Error: oldString not found", {"error": True},
                      {"filePath": "a.py", "oldString": "q", "newString": "r"})
    text = plain(failed)
    assert "oldString not found" in text and "+r" not in text and text.startswith("✗")


def test_saved_tool_results_get_their_own_call_arguments_by_id():
    messages = [
        {"role": "assistant", "content": "", "tool_calls": [
            {"id": "c1", "name": "read", "arguments": {"filePath": "one.txt"}},
            {"id": "c2", "name": "read", "arguments": {"filePath": "two.txt"}}]},
        {"role": "tool", "tool_call_id": "c2", "name": "read", "content": "2"},
        {"role": "tool", "tool_call_id": "c1", "name": "read", "content": "1"},
    ]
    paired = with_tool_inputs(messages)
    assert paired[1]["input"] == {"filePath": "two.txt"} and paired[2]["input"] == {"filePath": "one.txt"}
    assert "input" not in messages[1]


def test_live_and_saved_edit_cards_through_the_real_loop(runtime):
    target = runtime.directory / "notes.txt"
    target.write_text("alpha\nbeta\n", encoding="utf-8")
    long_file = runtime.directory / "long.txt"
    long_file.write_text("".join(f"row {index}\n" for index in range(40)), encoding="utf-8")
    replies = iter([
        Completion(tool_calls=[ToolCall("e1", "read", {"filePath": str(target)})], finish_reason="tool-calls"),
        Completion(tool_calls=[ToolCall("e2", "edit", {"filePath": str(target), "oldString": "beta",
                                                        "newString": "gamma"})], finish_reason="tool-calls"),
        Completion(tool_calls=[ToolCall("r1", "read", {"filePath": str(long_file)})], finish_reason="tool-calls"),
        Completion(text="Done", finish_reason="stop"),
    ])
    provider(runtime, lambda **kwargs: next(replies))
    sid = runtime.create_session()["id"]
    live = []

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        original = ui.receive_tool

        async with ui.run_test(size=(140, 50)) as pilot:
            ui.query_one(PromptInput).load_text("Change beta")
            await pilot.press("enter")
            await wait_for(pilot, lambda: sum(isinstance(item, ToolCard) for item in ui.views.get(sid, [])) == 3)
            live.extend(item for item in ui.views[sid] if isinstance(item, ToolCard))
            await wait_for(pilot, lambda: ui.running_session is None and sid not in ui._history_dirty)
            await pilot.pause(0.2)
            saved = [item for item in ui.views[sid] if isinstance(item, ToolCard)]
            assert [card.tool for card in saved] == ["read", "edit", "read"]
            assert saved[1].input["newString"] == "gamma" and "+1" in saved[1].summary().plain
            reader = next(view for view in ui.query(ToolCardView) if view.item is saved[2])
            assert reader.item.collapsible and not reader.item.expanded
            await pilot.click(reader)
            assert reader.item.expanded
            collapsible = [card for card in saved if card.collapsible]
            await pilot.press("ctrl+x", "e")  # some are still collapsed: expand all
            assert all(card.expanded for card in collapsible)
            await pilot.press("ctrl+x", "e")  # all open: collapse all
            assert not any(card.expanded for card in collapsible)
    asyncio.run(exercise())
    assert [card.tool for card in live] == ["read", "edit", "read"]
    assert live[1].input == {"filePath": str(target), "oldString": "beta", "newString": "gamma"}
    assert target.read_text(encoding="utf-8") == "alpha\ngamma\n"


# --- running status -------------------------------------------------------------

def test_footer_shows_spinner_elapsed_running_tool_and_reported_tokens(runtime):
    entered, release = threading.Event(), threading.Event()

    def respond(**kwargs):
        entered.set()
        assert release.wait(10)
        return Completion(text="Answer", finish_reason="stop",
                          usage={"prompt_tokens": 1234, "completion_tokens": 56})
    provider(runtime, respond)
    sid = runtime.create_session()["id"]

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test(size=(140, 40)) as pilot:
            ui.query_one(PromptInput).load_text("Work")
            await pilot.press("enter")
            await wait_for(pilot, entered.is_set)
            ui._started[sid] -= 65
            runtime.bus.publish("tool.running", {"sessionID": sid, "tool": "bash", "input": {"command": "pytest -q"}})
            await wait_for(pilot, lambda: "bash pytest -q" in footer(ui))
            text = footer(ui)
            assert "執行中 1m0" in text and text.split("執行中")[0].strip()[-1] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
            runtime.bus.publish("tool.completed", {"sessionID": sid, "tool": "bash", "title": "pytest -q"})
            await wait_for(pilot, lambda: "bash" not in footer(ui))
            release.set()
            await wait_for(pilot, lambda: ui.running_session is None)
            await wait_for(pilot, lambda: "1.2k in · 56 out" in footer(ui))
            assert "執行中" not in footer(ui)
    try:
        asyncio.run(exercise())
    finally:
        release.set()


def test_token_summary_handles_provider_shapes_and_absence():
    assert token_summary({"input_tokens": 900, "output_tokens": 12, "cache_read_input_tokens": 300}) == "1.2k in · 12 out"
    assert token_summary({"total_tokens": 2048}) == "2.0k tokens"
    assert token_summary({}) == "" and token_summary(None) == ""


# --- queued prompts ------------------------------------------------------------

def test_prompt_during_a_turn_is_queued_shown_and_sent_after_it_ends(runtime):
    seen, gates = [], [threading.Event(), threading.Event()]
    entered = threading.Event()

    def respond(**kwargs):
        text = str(kwargs["messages"][-1]["content"])
        seen.append(text)
        entered.set()
        assert gates[len(seen) - 1].wait(10)
        return Completion(text=f"reply {len(seen)}", finish_reason="stop")
    provider(runtime, respond)
    sid = runtime.create_session()["id"]

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test(size=(140, 40)) as pilot:
            editor = ui.query_one(PromptInput)
            editor.load_text("first")
            await pilot.press("enter")
            await wait_for(pilot, entered.is_set)
            editor.load_text("second")
            await pilot.press("enter")
            assert editor.text == ""
            bar = ui.query_one(QueueBar)
            assert bar.display and "排隊中 1" in str(bar.content) and "second" in str(bar.content)
            gates[0].set()
            await wait_for(pilot, lambda: len(seen) == 2)
            assert not ui.query_one(QueueBar).display
            gates[1].set()
            await wait_for(pilot, lambda: ui.running_session is None and not ui.queued)
    try:
        asyncio.run(exercise())
    finally:
        for gate in gates:
            gate.set()
    assert seen[0].endswith("first") and seen[1].endswith("second")


def test_queued_prompts_can_be_cancelled_by_click_or_leader_key(runtime):
    seen, release, entered = [], threading.Event(), threading.Event()

    def respond(**kwargs):
        seen.append(str(kwargs["messages"][-1]["content"]))
        entered.set()
        assert release.wait(10)
        return Completion(text="ok", finish_reason="stop")
    provider(runtime, respond)
    sid = runtime.create_session()["id"]

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test(size=(140, 40)) as pilot:
            editor = ui.query_one(PromptInput)
            for text in ("running", "keep", "drop by click", "drop by key"):
                editor.load_text(text)
                await pilot.press("enter")
                if text == "running":
                    await wait_for(pilot, entered.is_set)
            assert [item["text"] for item in ui.queued] == ["keep", "drop by click", "drop by key"]
            await pilot.press("ctrl+x", "u")
            assert [item["text"] for item in ui.queued] == ["keep", "drop by click"]
            await pilot.click(QueueBar, offset=(5, 1))
            assert [item["text"] for item in ui.queued] == ["keep"]
            release.set()
            await wait_for(pilot, lambda: len(seen) == 2 and ui.running_session is None and not ui.queued)
    try:
        asyncio.run(exercise())
    finally:
        release.set()
    assert seen[1].endswith("keep") and len(seen) == 2


# --- streaming and re-rendering ------------------------------------------------

def test_markdown_split_never_cuts_inside_a_code_fence():
    text = "para one\n\npara two\n\n```\ncode\n\nmore\n"
    assert text[:markdown_split(text)] == "para one\n\npara two\n\n"
    assert markdown_split("no blank line yet") == 0
    assert markdown_split("ends with blank\n\n") == 0  # the tail must keep something to grow


def test_streamed_reply_freezes_finished_blocks_and_rerenders_only_the_tail(runtime):
    chunks = [f"Paragraph {index} " + "word " * 20 + "\n\n" for index in range(12)] + ["final tail"]
    release = threading.Event()
    rendered_lengths = []

    def respond(**kwargs):
        for chunk in chunks:
            kwargs["on_text"](chunk)
        assert release.wait(10)
        return Completion(text="".join(chunks), finish_reason="stop")
    provider(runtime, respond)
    sid = runtime.create_session()["id"]

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test(size=(140, 40)) as pilot:
            ui.query_one(PromptInput).load_text("stream")
            await pilot.press("enter")
            await wait_for(pilot, lambda: ui.streamed.get(sid, "").endswith("final tail"))
            await pilot.pause(0.1)
            live = ui.query_one(LiveMarkdown)
            assert len(live.children) == 13  # 12 frozen blocks and the tail
            assert live.item.text == "".join(chunks)
            assert "final tail" in plain(live.tail.content) and "Paragraph 11" not in plain(live.tail.content)
            release.set()
            await wait_for(pilot, lambda: ui.running_session is None)
    try:
        asyncio.run(exercise())
    finally:
        release.set()


def test_history_refresh_keeps_unchanged_widgets_and_scroll_position(runtime):
    sid = runtime.create_session()["id"]
    for index in range(40):
        runtime.store.add_message(sid, "user" if index % 2 == 0 else "assistant", {"content": f"saved message {index}"})

    async def exercise():
        ui = OpenCodeTUI(runtime, session_id=sid)
        async with ui.run_test(size=(120, 30)) as pilot:
            await pilot.pause()
            conversation = ui.query_one("#conversation")
            before = list(conversation.children)
            assert len(before) == 40
            await wait_for(pilot, lambda: conversation.max_scroll_y > 10 and conversation.scroll_y == conversation.max_scroll_y)
            await pilot.pause(0.1)
            conversation.scroll_to(y=10, animate=False)
            await pilot.pause()
            from opencode.tui import HistoryRefresh
            await ui.refresh_history(HistoryRefresh(sid))
            await pilot.pause()
            assert list(conversation.children) == before
            assert conversation.scroll_y == 10
            runtime.store.add_message(sid, "assistant", {"content": "one more"})
            await ui.refresh_history(HistoryRefresh(sid))
            await pilot.pause()
            after = list(conversation.children)
            assert after[:40] == before and len(after) == 41
            assert conversation.scroll_y == 10
    asyncio.run(exercise())


def test_shell_card_with_nonzero_exit_is_marked_failed():
    failed = ToolCard("bash", "python count.py", "(no output)", {"exit": 49}, {"command": "python count.py"})
    assert failed.error and plain(failed).startswith("✗")
    passed = ToolCard("bash", "ls", "a", {"exit": 0}, {"command": "ls"})
    assert not passed.error and plain(passed).startswith("●")
