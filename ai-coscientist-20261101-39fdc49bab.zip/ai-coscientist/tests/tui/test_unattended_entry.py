"""The one entry (co-scientist) runs a task unattended the way the interface does; no real model is called."""

import socket
from types import SimpleNamespace

import pytest

from opencode import task_skills
from opencode.provider import Client, Completion, ToolCall
from opencode.tools.extra import NO_ANSWER
from researchkit import task_runtime
from scripts import run_tui


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    for key in ("OPENCODE_CONFIG", "OPENCODE_CONFIG_CONTENT", "OPENCODE_PERMISSION", "OPENCODE_PURE"):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("OPENCODE_TEST_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("OPENCODE_CONFIG_DIR", str(tmp_path / "config"))
    for kind in ("CONFIG", "DATA", "STATE", "CACHE"):
        monkeypatch.setenv(f"XDG_{kind}_HOME", str(tmp_path / kind.lower()))
    connect = socket.socket.connect

    def offline(sock, address):
        # Windows asyncio creates a loopback self-pipe through socketpair(); nothing else may connect.
        if isinstance(address, tuple) and address[0] in ("127.0.0.1", "::1"):
            return connect(sock, address)
        raise AssertionError("The unattended entry test attempted a network connection")

    monkeypatch.setattr(socket.socket, "connect", offline)
    requests = []

    def complete(self, **kwargs):
        requests.append(kwargs)
        return Completion(text=f"answer {len(requests)}", finish_reason="stop")

    monkeypatch.setattr(Client, "complete", complete)
    return SimpleNamespace(requests=requests, tmp=tmp_path)


def prompt(tmp_path, name, text):
    path = tmp_path / name
    path.write_text(text, encoding="utf-8")
    return path


def test_an_unattended_task_gets_the_same_agent_and_hooks(isolated, monkeypatch):
    source = isolated.tmp / "case"
    source.mkdir()
    (source / "brief.md").write_text("Room 5.6 m by 3.5 m.", encoding="utf-8")
    folder = isolated.tmp / "task"
    reviewers = []

    def reviewer(app, session_id):
        def complete(system, message, schema):
            reviewers.append(schema[0])
            return SimpleNamespace(text="not json", finish_reason="stop")
        return complete

    monkeypatch.setattr(task_runtime, "model_call", reviewer)
    first, second = prompt(isolated.tmp, "q1.txt", "First question."), prompt(isolated.tmp, "q2.txt", "Follow-up.")
    code = run_tui.main([str(folder), "--from", str(source), "--prompt", str(first), "--prompt", str(second)])
    assert code == 0
    assert (folder / "brief.md").is_file() and (folder / ".git").is_dir()
    # Both questions in one session. Without deep research (opencode/deep.py): the general agent, no research
    # tools, guides or reviewer, and one line saying how to turn deep research on.
    assert len(isolated.requests) == 2
    tools = {tool["name"] for tool in isolated.requests[0]["tools"]}
    assert not tools & {"research_record", "planning_update"} and "research-practice" not in isolated.requests[0]["system"]
    assert "Deep research is off for this task" in isolated.requests[0]["system"]
    humans = [m["content"] for m in isolated.requests[1]["messages"] if m["role"] == "user"]
    assert any("First question." in text for text in humans) and any("Follow-up." in text for text in humans)
    assert reviewers == []
    # With --deep, the research and planning tools and guides of the interface, and the reviewer's hooks: the
    # plan before the first step, the review when the round ends (each failed here after its one repair, and
    # the round's result stands).
    isolated.requests.clear()
    deep_folder = isolated.tmp / "deep-task"
    code = run_tui.main([str(deep_folder), "--from", str(source), "--prompt", str(first), "--deep"])
    assert code == 0
    tools = {tool["name"] for tool in isolated.requests[0]["tools"]}
    assert {"research_record", "planning_update"} <= tools and "research-practice" in isolated.requests[0]["system"]
    assert "Deep research is off" not in isolated.requests[0]["system"]
    assert reviewers == ["verification_plan", "verification_plan", "round_review", "round_review"]


def test_continue_runs_the_folders_last_task_as_its_next_round(isolated):
    folder = isolated.tmp / "task"
    folder.mkdir()
    first = prompt(isolated.tmp, "q1.txt", "Start.")
    assert run_tui.main([str(folder), "--prompt", str(first), "--no-review"]) == 0
    again = prompt(isolated.tmp, "q2.txt", "Go on from where you stopped.")
    assert run_tui.main([str(folder), "--prompt", str(again), "--continue", "--no-review"]) == 0
    from opencode.store import Store
    from opencode.paths import state_dir
    store = Store(state_dir() / "opencode.db")
    try:
        tops = [s for s in store.list_sessions() if s.get("parentID") is None]
        assert len(tops) == 1
        humans = [m["content"] for m in store.messages(tops[0]["id"]) if m["role"] == "user"]
        assert humans == ["Start.", "Go on from where you stopped."]
        assert task_skills.current_round(tops[0]["id"]) == 2
    finally:
        store.close()


def test_a_question_in_an_unattended_run_is_told_that_nobody_can_answer(isolated, monkeypatch):
    replies = iter([Completion(tool_calls=[ToolCall("q1", "question", {"questions": [{"question": "Which room?"}]})],
                               finish_reason="tool-calls"),
                    Completion(text="Assumed the small room.", finish_reason="stop")])
    seen = []

    def complete(self, **kwargs):
        seen.append(kwargs)
        return next(replies)

    monkeypatch.setattr(Client, "complete", complete)
    folder = isolated.tmp / "task"
    folder.mkdir()
    assert run_tui.main([str(folder), "--prompt", str(prompt(isolated.tmp, "q.txt", "Pick a room.")),
                         "--no-review"]) == 0
    reply = [m for m in seen[1]["messages"] if m["role"] == "tool"][-1]
    assert NO_ANSWER in str(reply["content"])  # not a wait for a reply that never comes


def test_a_turn_the_loop_stopped_does_not_keep_the_next_question_back(isolated, monkeypatch):
    # Q1 hit the repeat limit and Q2 was never asked (2026-10-31); a person would have asked it.
    real = run_tui.build_app
    statuses = iter(["repeat_limit", "completed", "aborted"])
    asked = []

    def build(*args, **kwargs):
        app, effective, model = real(*args, **kwargs)

        def stand_in(session_id, text, **_):
            asked.append(text)
            return {"status": next(statuses), "sessionID": session_id, "text": "reply"}

        app.prompt = stand_in
        return app, effective, model

    monkeypatch.setattr(run_tui, "build_app", build)
    folder = isolated.tmp / "task"
    folder.mkdir()
    q1, q2 = prompt(isolated.tmp, "q1.txt", "First."), prompt(isolated.tmp, "q2.txt", "Second.")
    assert run_tui.main([str(folder), "--prompt", str(q1), "--prompt", str(q2), "--no-review"]) == 1
    assert asked == ["First.", "Second."]  # sent after the stopped turn, and still not a full success
    # An aborted turn (a stage stop, a person's stop request, a changed meta region) ends the round.
    asked.clear()
    assert run_tui.main([str(folder), "--prompt", str(q1), "--prompt", str(q2), "--continue", "--no-review"]) == 1
    assert asked == ["First."]


def test_supervised_lets_the_prompt_files_play_the_person_at_the_keyboard(isolated, monkeypatch):
    # The call budget of a general-mode turn (opencode/loop.py), which the interface has whenever someone is there.
    folder = isolated.tmp / "task"
    folder.mkdir()
    for number in range(8):
        (folder / f"note{number}.md").write_text(f"note {number}", encoding="utf-8")
    (folder / "opencode.json").write_text('{"turn": {"max_calls": 3, "remind_before": 1}}', encoding="utf-8")
    seen = []

    def complete(self, **kwargs):
        seen.append(kwargs)
        if not kwargs.get("tools"):
            return Completion(text="stage summary", finish_reason="stop")
        n = len(seen)
        return Completion(tool_calls=[ToolCall(f"r{n}", "read", {"filePath": str(folder / f"note{n}.md")})],
                          finish_reason="tool-calls")

    monkeypatch.setattr(Client, "complete", complete)
    first, second = prompt(isolated.tmp, "q1.txt", "First question."), prompt(isolated.tmp, "q2.txt", "Follow-up.")
    assert run_tui.main([str(folder), "--prompt", str(first), "--prompt", str(second), "--supervised"]) == 1
    # Each prompt is a turn of three calls, the last without tools; the second prompt still comes.
    assert len(seen) == 6 and seen[2]["tools"] is None and seen[5]["tools"] is None
    assert any("Follow-up." in str(m.get("content")) for m in seen[3]["messages"] if m["role"] == "user")


def test_interactive_only_options_and_unattended_mistakes(isolated, capsys):
    folder = isolated.tmp / "task"
    with pytest.raises(SystemExit):
        run_tui.main([str(folder), "--continue"])  # --continue goes with --prompt
    assert "--prompt" in capsys.readouterr().err
    folder.mkdir()
    (folder / "existing.txt").write_text("x", encoding="utf-8")
    source = isolated.tmp / "case"
    source.mkdir()
    q = prompt(isolated.tmp, "q.txt", "Question.")
    assert run_tui.main([str(folder), "--from", str(source), "--prompt", str(q)]) == 1
    assert "--from needs a new or empty folder" in capsys.readouterr().err
    assert run_tui.main([str(isolated.tmp / "other"), "--prompt", str(q), "--continue"]) == 1
    assert "Nothing to continue" in capsys.readouterr().err
